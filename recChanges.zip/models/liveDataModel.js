// models/liveData.model.js
const mongoose = require("mongoose");

const liveDataSchema = new mongoose.Schema(
  {
    tagname: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
    },
    datatype: {
      type: String,
      enum: ["string", "struct", "number", "boolean", "null", "unknown"],
      default: "unknown",
    },
    // latestValue: { type: Number, default: null },
    latestValue: { type: mongoose.Schema.Types.Mixed, default: null },
    ranges: {
      minValue: {
        type: Number,
        default: null,
      },
      maxValue: {
        type: Number,
        default: null,
      },
    },
    unit: {
      type: String,
    },
    plcName: {
      type: String,
      required: true,
    },
    assetId: [
      {
        type: mongoose.Schema.Types.ObjectId,
      },
    ],
    health: {
      type: Boolean,
      default: true,
    },
    plcMetadata: {
      dbAddress: {
        type: String,
      },
    },
    db: {
      type: Number,
    },
    source: {
      type: String,
      default: "PLC",
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    lastUpdated: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
    // collection: "liveData",
    collection: "tag_lives",
  },
);

liveDataSchema.index({ plcName: 1, tagname: 1 }, { unique: true });

// const LiveData = mongoose.model("liveData", liveDataSchema);
const LiveData = mongoose.model("tag_lives", liveDataSchema);

function getLiveDataEntriesCollection() {
  const db = mongoose.connection.db;
  // return db.collection("liveDataEntries");
  return db.collection("liveData_test");
}
module.exports = { LiveData, getLiveDataEntriesCollection };
