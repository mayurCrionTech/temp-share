const plcManager = require("../managers/plcManager");
const { updateLastReceived } = require("../utils/data.monitor");
const logger = require("../utils/logger");

const saveData = async (req, res) => {
  try {
    const result = await plcManager.savePLCData(req.body);
    updateLastReceived();

    res.status(201).json({
      success: true,
      message: "✅ Data saved successfully to file and MongoDB",
      data: result,
    });
  } catch (error) {
    logger.error("❌ Error saving PLC data:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to save data",
      error: process.env.NODE_ENV === "development" ? error.message : "Internal server error",
    });
  }
};

const getLatestData = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const data = await plcManager.getLatestPLCData(limit);
    res.status(200).json({
      success: true,
      source: "mongo",
      data,
      count: data.length,
    });
  } catch (error) {
    logger.error("❌ Error fetching latest PLC data:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to fetch latest data",
      error: process.env.NODE_ENV === "development" ? error.message : "Internal server error",
    });
  }
};

module.exports = {
  saveData,
  getLatestData,
};
