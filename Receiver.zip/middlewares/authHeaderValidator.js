function validateAPIKey(req, res, next) {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey || apiKey !== process.env.PLC_API_KEY) {
    return res.status(403).json({
      success: false,
      message: "Unauthorized: Invalid or missing API key",
    });
  }

  next();
};

module.exports={
  validateAPIKey
}
