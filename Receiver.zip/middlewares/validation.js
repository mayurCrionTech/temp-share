const logger = require("../utils/logger");

const validatePLCData = (req, res, next) => {
  const { body } = req;
  
  // Log incoming request
  logger.info(`📨 Received PLC data request from ${req.ip}`);
  
  // Check if body exists
  if (!body) {
    return res.status(400).json({
      success: false,
      message: "Request body is required"
    });
  }

  // Check if body is array
  if (!Array.isArray(body)) {
    return res.status(400).json({
      success: false,
      message: "Request body must be an array"
    });
  }

  // Check array length
  if (body.length > 1000) {
    return res.status(400).json({
      success: false,
      message: "Maximum 1000 entries allowed per request"
    });
  }

  next();
};

module.exports = {
  validatePLCData
};