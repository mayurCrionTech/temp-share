const express = require("express");
const morgan = require("morgan");
const cors = require("cors");
require("dotenv").config();
const plcRoutes = require("./routes/plcRoutes");
const logger = require("./utils/logger");
const connectDB = require("./utils/database");
const { PORT } = require("./config/serverConfig");
const monitorPLC = require("./utils/monitor");
const { initLiveDataEntries } = require("./utils/scripts/initTimeSeries");

const app = express();


// Middleware
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(morgan("dev"));

// Routes
app.get("/", (req, res) => {
  res.status(200).json({ 
    message: "PLC Data Receiver is running (File-based)",
    timestamp: new Date().toISOString(),
    version: "1.0.0"
  });
});

app.use("/api/v1/plc", plcRoutes);


// Global error handler
app.use((err, req, res, next) => {
  logger.error("Unhandled error:", err.message);
  res.status(500).json({ 
    message: "Internal Server Error",
    error: process.env.NODE_ENV === "development" ? err.message : "Something went wrong"
  });
});

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({ message: "Route not found" });
});

// Start server
const startServer = async () => {
  try {
   const now = new Date();
const istTime = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });


    await connectDB()
    await initLiveDataEntries()
    monitorPLC()
    //  await plcController.init(); 
    app.listen(PORT, () => {
      logger.info(`Server running on port ${PORT}`);
    });
  } catch (error) {
    logger.error("Failed to start server:", error.message);
    process.exit(1);
  }
};

startServer();