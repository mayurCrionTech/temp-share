const mongoose = require("mongoose");

const plcDataSchema = new mongoose.Schema(
  {
    tagname: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    // value: {
    //   type: Number,
    //   required: true,
    // },
    value: {
      type: mongoose.Schema.Types.Mixed,
      required: true,
    },
    timestamp: {
      type: String,
      required: true,
    },
    // dataType: {
    //   type: String,
    //   enum: ["BOOL", "INT", "REAL", "STRING", "DINT"],
    //   default: "REAL"
    // },
    dataType: {
      type: String,
      enum: ["string", "struct", "number", "boolean", "null", "unknown"],
      default: "unknown",
    },
    // quality: {
    //   type: String,
    //   enum: ["GOOD", "BAD", "UNCERTAIN"],
    //   default: "GOOD"
    // },
    source: {
      type: String,
      default: "PLC",
    },
    plcName: {
      type: String,
      required: false,
    },
    unit: {
      type: String,
      required: false,
    },
    db: {
      type: Number,
      required: false,
    },
  },
  {
    timestamps: true,
    collection: "plcDataEntries",
  },
);

// plcDataSchema.index({ tagname: 1, timestamp: -1 });
// plcDataSchema.index({ createdAt: -1 });

module.exports = mongoose.model("PLCData", plcDataSchema);
