const axios = require("axios");
const templates = require("../utils/email.templates");

const ONESIGNAL_APP_ID = process.env.ONESIGNAL_APP_ID;
const ONESIGNAL_API_KEY = process.env.ONESIGNAL_API_KEY;
const DEFAULT_TO_EMAIL = process.env.ALERT_EMAIL || "mayur.criontech@gmail.com";
  const sendEmail= async (type, data, toEmail = [DEFAULT_TO_EMAIL])=> {
    if (!ONESIGNAL_APP_ID || !ONESIGNAL_API_KEY) {
      throw new Error("OneSignal credentials missing in environment variables");
    }
    
    const templateFn = templates[type];
    if (!templateFn) {
      throw new Error(`Unknown email template type: ${type}`);
    }

    const { subject, html } = templateFn(data);

    const payload = {
      app_id: ONESIGNAL_APP_ID,
      include_email_tokens: toEmail,
      email_subject: subject,
      email_body: html,
      include_unsubscribed: true // allow transactional emails
    };

    try {
      const { data: res } = await axios.post(
        "https://onesignal.com/api/v1/notifications",
        payload,
        {
          headers: {
            Authorization: `Basic ${ONESIGNAL_API_KEY}`,
            "Content-Type": "application/json"
          }
        }
      );
      console.log("📧 Email sent:", res.id || res);
      return res;
    } catch (err) {
      console.error("❌ Email send failed:", err.response?.data || err.message);
      throw err;
    }
  }

  


module.exports = sendEmail;
