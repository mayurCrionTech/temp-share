// const sendEmail = require("../services/emailServices");
// const { getLastReceived } = require("./data.monitor");

// let lastEmailSentAt = null; // track last email timestamp
// const OFFLINE_NOTIFY_INTERVAL = Number(process.env.OFFLINE_NOTIFY_INTERVAL_MS)
// const INITIAL_OFFLINE_THRESHOLD = Number(process.env.INITIAL_OFFLINE_THRESHOLD_MS)
// const DEFAULT_TO_EMAIL = process.env.ALERT_EMAILS
//   ? process.env.ALERT_EMAILS.split(",").map(email => email.trim())
//   : ["harish.crion@gmail.com"];

// function monitorPLC() {

//   setInterval(async () => {
//     const lastReceived = getLastReceived(); // should return Date or null
//     if (!lastReceived) return; // no data yet

//     const now = new Date();
//     const diffMs = now - lastReceived;
//     const diffMinutes = Math.floor(diffMs / 60000);
//     const diffHours = Math.floor(diffMinutes / 60);
//     const diffMinutesRemaining = diffMinutes % 60;

//     // Determine if we should send an email
//     const shouldSendEmail =
//       (diffMs > INITIAL_OFFLINE_THRESHOLD && !lastEmailSentAt) || // first offline email
//       (lastEmailSentAt && diffMs - (lastEmailSentAt - lastReceived) >= OFFLINE_NOTIFY_INTERVAL); // repeated email

//     if (diffMs > INITIAL_OFFLINE_THRESHOLD && shouldSendEmail) {
//       console.log("⚠️ No PLC data received for 20+ seconds, sending email...");

//       try {
//         await sendEmail("transmitterStatus", {
//           status: "disconnected",
//           lastReceived: lastReceived.toLocaleString(),
//           details: {
//             "Current Time": now.toLocaleString(),
//             "Offline Duration": diffHours > 0
//               ? `${diffHours}h ${diffMinutesRemaining}m`
//               : `${diffMinutes}m`,
//             message: "No data received from transmitter."
//           }
//         }, DEFAULT_TO_EMAIL);

//         lastEmailSentAt = new Date(); // update last sent timestamp
//       } catch (err) {
//         console.error("❌ Failed to send email:", err.message);
//       }
//     }

//     // Reset lastEmailSentAt if data resumes
//     if (diffMs <= INITIAL_OFFLINE_THRESHOLD) {
//       if (lastEmailSentAt) {
//         console.log("✅ PLC data resumed, resetting notification timestamp.");
//       }
//       lastEmailSentAt = null;
//     }
//   }, 5000); // check every 5 seconds
// }

// module.exports = monitorPLC;

const sendEmail = require("../services/emailServices");
const { getLastReceived } = require("./data.monitor");

let lastEmailSentAt = null;
let disconnectedAt = null; // track when transmitter first went offline

const OFFLINE_NOTIFY_INTERVAL = Number(process.env.OFFLINE_NOTIFY_INTERVAL_MS);
const INITIAL_OFFLINE_THRESHOLD = Number(
  process.env.INITIAL_OFFLINE_THRESHOLD_MS,
);
const DEFAULT_TO_EMAIL = process.env.ALERT_EMAILS
  ? process.env.ALERT_EMAILS.split(",").map((email) => email.trim())
  : ["mayur.criontech@gmail.com"];

// Format time in local timezone (e.g. India)
function formatLocalTime(date) {
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    dateStyle: "medium",
    timeStyle: "medium",
  }).format(date);
}

function monitorPLC() {
  setInterval(async () => {
    const lastReceived = getLastReceived();
    if (!lastReceived) return;

    const now = new Date();
    const diffMs = now - lastReceived;
    const diffMinutes = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMinutes / 60);
    const diffMinutesRemaining = diffMinutes % 60;

    const shouldSendEmail =
      (diffMs > INITIAL_OFFLINE_THRESHOLD && !lastEmailSentAt) ||
      (lastEmailSentAt &&
        diffMs - (lastEmailSentAt - lastReceived) >= OFFLINE_NOTIFY_INTERVAL);

    //  Transmitter went offline
    if (diffMs > INITIAL_OFFLINE_THRESHOLD && shouldSendEmail) {
      if (!disconnectedAt) disconnectedAt = new Date();

      console.log(
        "⚠️ No PLC data received for threshold duration, sending offline email...",
      );

      try {
        await sendEmail(
          "transmitterStatus",
          {
            status: "disconnected",
            lastReceived: formatLocalTime(lastReceived),
            details: {
              "Current Time": formatLocalTime(now),
              "Offline Duration":
                diffHours > 0
                  ? `${diffHours}h ${diffMinutesRemaining}m`
                  : `${diffMinutes}m`,
              message: "No data received from transmitter.",
            },
          },
          DEFAULT_TO_EMAIL,
        );

        lastEmailSentAt = new Date();
      } catch (err) {
        console.error("❌ Failed to send offline email:", err.message);
      }
    }

    //  Transmitter resumed
    if (diffMs <= INITIAL_OFFLINE_THRESHOLD && disconnectedAt) {
      const reconnectedAt = new Date();
      const totalDownMs = reconnectedAt - disconnectedAt;
      const totalDownMinutes = Math.floor(totalDownMs / 60000);
      const totalDownHours = Math.floor(totalDownMinutes / 60);
      const totalDownMinutesRemaining = totalDownMinutes % 60;

      console.log("✅ PLC data resumed, sending reconnection email...");

      try {
        await sendEmail(
          "transmitterStatus",
          {
            status: "reconnected",
            lastReceived: formatLocalTime(lastReceived),
            details: {
              "Disconnected Since": formatLocalTime(disconnectedAt),
              "Reconnected At": formatLocalTime(reconnectedAt),
              "Total Downtime":
                totalDownHours > 0
                  ? `${totalDownHours}h ${totalDownMinutesRemaining}m`
                  : `${totalDownMinutes}m`,
              message: "Transmitter connection has resumed.",
            },
          },
          DEFAULT_TO_EMAIL,
        );
      } catch (err) {
        console.error("❌ Failed to send reconnection email:", err.message);
      }

      // reset flags
      disconnectedAt = null;
      lastEmailSentAt = null;
    }
  }, 5000);
}

module.exports = monitorPLC;
