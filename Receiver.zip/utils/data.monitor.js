let lastReceivedAt = null;

function updateLastReceived() {
  lastReceivedAt = new Date();
  console.log("✅ PLC data received at:", lastReceivedAt.toISOString());
}

function getLastReceived() {
  return lastReceivedAt;
}

module.exports = { updateLastReceived, getLastReceived };
