// scripts/initTimeSeries.js
const mongoose = require("mongoose"); // Add this at the top

async function initLiveDataEntries() {
  try {
    const db = mongoose.connection.db;
    const collections = await db.listCollections().toArray();
    const exists = collections.some((c) => c.name === "liveData_test"); // was: "liveDataEntries"

    if (!exists) {
      console.log("⏳ Creating time-series collection: liveData_test");
      await db.createCollection("liveData_test", {
        // was: "liveDataEntries"
        timeseries: {
          timeField: "timestamp",
          metaField: "tag_id",
          granularity: "seconds",
        },
      });
      console.log("✅ Time-series collection created successfully");
    } else {
      console.log("✅ liveData_test already exists - skipping creation"); // was: "liveDataEntries..."
    }
  } catch (err) {
    // console.error(err.message);
  }
}
module.exports = { initLiveDataEntries };
