function transmitterLayout({ status, lastReceived, uptime, details }) {
  // details = object { key: value, ... } to render in table
  const detailsHtml = details
    ? `<table style="width:100%;border-collapse:collapse;margin-top:12px;">
        ${Object.entries(details)
          .map(
            ([k, v]) => `
              <tr>
                <td style="padding:8px;border:1px solid #e2e8f0;background:#f8fafc;font-weight:600;color:#1e293b;text-transform:capitalize;">
                  ${k}
                </td>
                <td style="padding:8px;border:1px solid #e2e8f0;color:#334155;">
                  ${v ?? "-"}
                </td>
              </tr>`
          )
          .join("")}
      </table>`
    : "";

  // choose color and icon based on status
  let color = "#16a34a", icon = "✅", title = "Transmitter Online";
  if (status === "disconnected") {
    color = "#dc2626";
    icon = "❌";
    title = "Transmitter Disconnected";
  } else if (status === "warning") {
    color = "#f59e0b";
    icon = "⚠️";
    title = "Transmitter Warning";
  }

  return `
  <div style="font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:#f1f5f9;padding:20px;">
    <div style="max-width:600px;margin:auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 6px 18px rgba(0,0,0,0.08);">
      
      <!-- Header -->
      <div style="background:${color};color:#fff;padding:16px 20px;font-size:18px;font-weight:bold;display:flex;align-items:center;">
        <span style="font-size:22px;margin-right:10px;">${icon}</span> ${title}
      </div>

      <!-- Body -->
      <div style="padding:20px;">
        <p style="margin:0 0 14px;font-size:15px;color:#334155;line-height:1.5;">
          Transmitter status: <strong>${status.toUpperCase()}</strong>
        </p>
        ${lastReceived ? `<p>Last data received at: <strong>${lastReceived}</strong></p>` : ""}
        ${uptime ? `<p>Uptime: <strong>${uptime}</strong></p>` : ""}
        ${detailsHtml}
      </div>

      <!-- Footer -->
      <div style="background:#f8fafc;color:#64748b;font-size:12px;padding:12px 20px;text-align:center;">
        This is an automated email from <strong>CrionTech Transmitter Monitor</strong>. 
        <br/>Do not reply directly.
      </div>
    </div>
  </div>`;
}

module.exports = {
  transmitterStatus: ({ status, lastReceived, uptime, details }) => ({
    subject: `${status === "disconnected" ? "❌" : status === "warning" ? "⚠️" : "✅"} Transmitter ${status.toUpperCase()}`,
    html: transmitterLayout({ status, lastReceived, uptime, details })
  }),

  custom: ({ subject, html }) => ({
    subject,
    html
  })
};
