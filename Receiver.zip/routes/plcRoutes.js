const express = require("express");
const router = express.Router();
const plcController = require("../controllers/plcController");
const { validateAPIKey } = require("../middlewares/authHeaderValidator");

router
  .route("/data")
  .post(validateAPIKey, plcController.saveData)
//   .get(validateAPIKey, plcController.getLatestData);

const plcRoutes = router;
module.exports = plcRoutes;
