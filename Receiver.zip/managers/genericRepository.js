class GenericRepository {
  constructor(model) {
    this.model = model;
  }

  async insertMany(data) {
    return await this.model.insertMany(data);
  }

  async findLatest(limit = 10, sortField = 'timestamp') {
    return await this.model.find({})
      .sort({ [sortField]: -1 })
      .limit(limit)
      .lean();
  }

  async create(data) {
    const doc = new this.model(data);
    return await doc.save();
  }  

  /** Find documents by query */
  async find(query = {}, options = {}) {
    return await this.model.find(query, null, options).lean();
  }

  /** Find one document by query */
  async findOne(query = {}, options = {}) {
    return await this.model.findOne(query, null, options).lean();
  }

  /** Find by ID */
  async findById(id) {
    return await this.model.findById(id).lean();
  }

  /** Update a document by query */
  async updateOne(query, update, options = {}) {
    return await this.model.updateOne(query, update, options);
  }

  /** Update by ID */
  async updateById(id, update, options = {}) {
    return await this.model.findByIdAndUpdate(id, update, { new: true, ...options }).lean();
  }

  /** Delete documents by query */
  async deleteMany(query) {
    return await this.model.deleteMany(query);
  }

  /** Delete one document by query */
  async deleteOne(query) {
    return await this.model.deleteOne(query);
  }

  /** Delete by ID */
  async deleteById(id) {
    return await this.model.findByIdAndDelete(id).lean();
  }
}

module.exports = GenericRepository;
