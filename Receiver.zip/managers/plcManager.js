const path = require("path");
const GenericRepository = require("./genericRepository");
const PLCData = require("../models/PLCData");
const logger = require("../utils/logger");
const { updateLastReceived } = require("../utils/data.monitor");
const {
  LiveData,
  getLiveDataEntriesCollection,
} = require("../models/liveDataModel");

const plcRepo = new GenericRepository(PLCData);
/*
const ensureDataDirectory = async () => {
  try {
    await fs.mkdir(dataDir, { recursive: true });
  } catch (err) {
    logger.error("Error creating data directory:", err.message);
  }
};


ensureDataDirectory().catch(logger.error);
*/

const savePLCData = async (payloadRaw) => {
  try {
    const payloadArray = Array.isArray(payloadRaw) ? payloadRaw : [payloadRaw];
    const timestamp = new Date();
    const liveDataEntries = await getLiveDataEntriesCollection();

    const enrichedData = [];

    for (const entry of payloadArray) {
      let tag = await LiveData.findOne({
        plcName: entry.plcName || "UNKNOWN_PLC",
        tagname: entry.tagname,
      });

      if (!tag) {
        // Create new tag
        tag = await LiveData.create({
          tagname: entry.tagname,
          plcName: entry.plcName || "UNKNOWN_PLC",
          dataType: entry.dataType || "unknown",
          unit: entry.unit || null,
          latestValue: entry.value,
          ranges: {
            minValue: entry.ranges?.minValue ?? null,
            maxValue: entry.ranges?.maxValue ?? null,
          },
          lastUpdated: entry.timestamp,
        });

        logger.info(`🆕 Created new tag: ${entry.tagname}`);
      } else {
        // Always update latest value
        tag.latestValue = entry.value;
        tag.lastUpdated = entry.timestamp;

        // Update ranges only if transmitter sent them
        if (entry.ranges) {
          tag.ranges = {
            minValue: entry.ranges.minValue ?? tag.ranges?.minValue ?? null,
            maxValue: entry.ranges.maxValue ?? tag.ranges?.maxValue ?? null,
          };
        }

        // Optional updates
        if (entry.dataType) {
          tag.dataType = entry.dataType;
        }

        if (entry.unit) {
          tag.unit = entry.unit;
        }

        if (entry.plcName) {
          tag.plcName = entry.plcName;
        }

        await tag.save();
      }

      enrichedData.push({
        tag_id: tag._id,
        timestamp: new Date(entry.timestamp),
        value: entry.value,
      });
    }

    if (enrichedData.length > 0) {
      await liveDataEntries.insertMany(enrichedData);
      updateLastReceived();
      logger.info(`🍃 Saved ${enrichedData.length} entries to Time-Series DB`);
    } else {
      logger.warn("⚠️ No valid entries to insert into Time-Series DB");
    }

    return {
      timestamp: timestamp.toISOString(),
      savedTo: {
        mongo: true,
      },
    };
  } catch (error) {
    throw error;
  }
};

const getLatestPLCData = async (limit = 10) => {
  return await plcRepo.findLatest(limit);
};

module.exports = {
  savePLCData,
  getLatestPLCData,
};
