const sqlite3 = require("sqlite3").verbose();
const fs = require("fs");
const path = require("path");
const config = require("../config");
// const logger = require("../utils/logger");

class SQLiteHandler {
  constructor() {
    this.currentDb = null;
    this.currentDbPath = null;
    this.baseDir = config.database.dataDir;
  }

  // db file creation - old 1hr file
  // getDbPath(date = new Date()) {
  //   const y = date.getFullYear();
  //   const m = String(date.getMonth() + 1).padStart(2, "0");
  //   const d = String(date.getDate()).padStart(2, "0");
  //   const h = String(date.getHours()).padStart(2, "0");

  //   return path.join(this.baseDir, `${y}-${m}-${d}`, `${h}.db`);
  // }

  // db file creation new - 1 file
  getDbPath() {
    return path.join(this.baseDir, "plc_data.db");
  }

  async getDatabase(date = new Date()) {
    // const dbPath = this.getDbPath(date);

    // if (this.currentDb && this.currentDbPath === dbPath) {
    //   return this.currentDb;
    // }

    // if (this.currentDb) {
    //   await new Promise((res) => this.currentDb.close(res));
    //   logger.info(`Closed database: ${this.currentDbPath}`);
    // }

    const dbPath = this.getDbPath();
    if (this.currentDb) {
      return this.currentDb;
    }

    fs.mkdirSync(path.dirname(dbPath), { recursive: true });

    this.currentDb = new sqlite3.Database(dbPath);
    this.currentDbPath = dbPath;

    await this.exec(`
      CREATE TABLE IF NOT EXISTS tag_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plc_name TEXT,
        tag_name TEXT NOT NULL,
        value TEXT,
        value_type TEXT,
        min_value REAL,
        max_value REAL,
        timestamp TEXT NOT NULL,
        synced INTEGER DEFAULT 0
      );
      CREATE INDEX IF NOT EXISTS idx_plc_name ON tag_data(plc_name);
      CREATE INDEX IF NOT EXISTS idx_tag_name ON tag_data(tag_name);
      CREATE INDEX IF NOT EXISTS idx_timestamp ON tag_data(timestamp);
      CREATE INDEX IF NOT EXISTS idx_synced ON tag_data(synced);
    `);

    // Migration safety net: if an older DB file already exists without
    // value_type/min_value/max_value, add them; and drop plc_ip/plc_slot
    // if they're still there from before. Safe to call every startup.
    await this.ensureValueTypeColumn();

    console.log(`Opened database: ${dbPath}`);
    return this.currentDb;
  }

  // Adds value_type to pre-existing databases created before this
  // column existed. Safe to call every startup (checks first).
  async ensureValueTypeColumn() {
    const columns = await new Promise((resolve, reject) => {
      this.currentDb.all("PRAGMA table_info(tag_data)", (err, rows) =>
        err ? reject(err) : resolve(rows),
      );
    });

    const hasValueType = columns.some((c) => c.name === "value_type");
    if (!hasValueType) {
      await this.exec("ALTER TABLE tag_data ADD COLUMN value_type TEXT;");
      console.log("Migrated tag_data: added value_type column");
    }

    const hasMinValue = columns.some((c) => c.name === "min_value");
    if (!hasMinValue) {
      await this.exec("ALTER TABLE tag_data ADD COLUMN min_value REAL;");
      console.log("Migrated tag_data: added min_value column");
    }

    const hasMaxValue = columns.some((c) => c.name === "max_value");
    if (!hasMaxValue) {
      await this.exec("ALTER TABLE tag_data ADD COLUMN max_value REAL;");
      console.log("Migrated tag_data: added max_value column");
    }

    // Older DB files may still have plc_ip / plc_slot from before we
    // dropped them (plc_name alone is enough to identify the PLC).
    // Requires SQLite 3.35+ (bundled with sqlite3 5.x) for DROP COLUMN;
    // if it fails on an older engine, just leave the columns unused.
    const hasPlcIp = columns.some((c) => c.name === "plc_ip");
    if (hasPlcIp) {
      try {
        await this.exec("ALTER TABLE tag_data DROP COLUMN plc_ip;");
        console.log("Migrated tag_data: dropped plc_ip column");
      } catch (err) {
        console.warn("Could not drop plc_ip column (leaving it unused):", err.message);
      }
    }

    const hasPlcSlot = columns.some((c) => c.name === "plc_slot");
    if (hasPlcSlot) {
      try {
        await this.exec("ALTER TABLE tag_data DROP COLUMN plc_slot;");
        console.log("Migrated tag_data: dropped plc_slot column");
      } catch (err) {
        console.warn("Could not drop plc_slot column (leaving it unused):", err.message);
      }
    }
  }

  exec(sql) {
    return new Promise((resolve, reject) => {
      this.currentDb.exec(sql, (err) => (err ? reject(err) : resolve()));
    });
  }

  async saveTagData(records) {
    if (!records || records.length === 0) return;

    const db = await this.getDatabase();

    return new Promise((resolve, reject) => {
      db.serialize(() => {
        db.run("BEGIN TRANSACTION");

        const stmt = db.prepare(`
        INSERT INTO tag_data
        (plc_name, tag_name, value, value_type, min_value, max_value, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);

        try {
          for (const r of records) {
            // By the time records get here, dataCollector has already
            // run them through bufferDecoder, so r.value is a plain
            // string/number/boolean/null, or a hex string for opaque
            // structs. Anything still an object (e.g. records saved
            // via a caller that skipped decoding) falls back to JSON.
            const valueStr =
              r.value !== null && typeof r.value === "object"
                ? JSON.stringify(r.value)
                : String(r.value);

            stmt.run(
              r.plcName || null,
              r.name,
              valueStr,
              r.valueType || null,
              r.ranges?.minValue ?? null,
              r.ranges?.maxValue ?? null,
              r.timestamp,
            );
          }

          stmt.finalize((err) => {
            if (err) throw err;

            db.run("COMMIT", (err) => {
              if (err) {
                db.run("ROLLBACK");
                reject(err);
              } else {
                resolve();
              }
            });
          });
        } catch (err) {
          db.run("ROLLBACK");
          reject(err);
        }
      });
    });
  }

  // old
  // async getUnsentRecords(limit = 100) {
  //   const results = [];

  //   if (!fs.existsSync(this.baseDir)) return results;

  //   const dates = fs.readdirSync(this.baseDir).sort();

  //   for (const d of dates) {
  //     const dayDir = path.join(this.baseDir, d);
  //     if (!fs.statSync(dayDir).isDirectory()) continue;

  //     for (const f of fs.readdirSync(dayDir).sort()) {
  //       if (!f.endsWith(".db")) continue;

  //       const dbPath = path.join(dayDir, f);
  //       if (dbPath === this.currentDbPath) continue;

  //       const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READONLY);

  //       const rows = await new Promise((resolve, reject) =>
  //         db.all(
  //           `SELECT id, plc_name, plc_ip, plc_slot, tag_name, value, timestamp
  //            FROM tag_data
  //            WHERE synced = 0
  //            ORDER BY timestamp
  //            LIMIT ?`,
  //           [limit - results.length],
  //           (err, rows) => (err ? reject(err) : resolve(rows)),
  //         ),
  //       );

  //       db.close();

  //       for (const row of rows) {
  //         results.push({ ...row, dbPath });
  //         if (results.length >= limit) return results;
  //       }
  //     }
  //   }

  //   return results;
  // }

  // new
  async getUnsentRecords(limit = 100) {
    const db = await this.getDatabase();

    return new Promise((resolve, reject) => {
      db.all(
        `SELECT id,
              plc_name,
              tag_name,
              value,
              value_type,
              min_value,
              max_value,
              timestamp
       FROM tag_data
       WHERE synced = 0
       ORDER BY id
       LIMIT ?`,
        [limit],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        },
      );
    });
  }

  // old
  // async markAsSynced(records) {
  //   const grouped = records.reduce((m, r) => {
  //     (m[r.dbPath] ||= []).push(r.id);
  //     return m;
  //   }, {});

  //   for (const [dbPath, ids] of Object.entries(grouped)) {
  //     const db = new sqlite3.Database(dbPath);
  //     await new Promise((res) => db.exec("BEGIN TRANSACTION", res));

  //     const stmt = await new Promise((res) =>
  //       db.prepare("UPDATE tag_data SET synced = 1 WHERE id = ?", () => res()),
  //     );

  //     for (const id of ids) stmt.run(id);

  //     stmt.finalize();
  //     await new Promise((res) => db.exec("COMMIT", res));
  //     db.close();
  //   }
  // }

  // new
  async markAsSynced(records) {
    if (!records.length) return;

    const db = await this.getDatabase();

    return new Promise((resolve, reject) => {
      db.serialize(() => {
        db.run("BEGIN TRANSACTION");

        const stmt = db.prepare("UPDATE tag_data SET synced = 1 WHERE id = ?");

        for (const record of records) {
          stmt.run(record.id);
        }

        stmt.finalize((err) => {
          if (err) {
            db.run("ROLLBACK");
            return reject(err);
          }

          db.run("COMMIT", (err) => {
            if (err) {
              db.run("ROLLBACK");
              reject(err);
            } else {
              resolve();
            }
          });
        });
      });
    });
  }

  async close() {
    if (this.currentDb) {
      await new Promise((res) => this.currentDb.close(res));
      this.currentDb = null;
      // this.currentDbPath = null;
      console.log("SQLite closed");
    }
  }
}

module.exports = new SQLiteHandler();