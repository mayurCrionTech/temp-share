const config = require("../config");
const plcClient = require("../plc/plcClient");
const sqliteHandler = require("../database/sqliteHandler");
const { decodeTagRecords } = require("../utils/bufferDecoder");
// const logger = require("../utils/logger");

/**
 * Data Collector Service
 * Polls PLC at configured intervals and saves data to SQLite
 */
class DataCollector {
  constructor() {
    this.pollInterval = null;
    this.isRunning = false;
  }

  /**
   * Start the data collection service
   */
  async start() {
    if (this.isRunning) {
      console.warn("Data collector is already running");
      return;
    }

    console.log("Starting data collector service...");

    try {
      // Connect to PLC
      await plcClient.connect();

      // Wait a moment for initial connection
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Start polling loop
      this.isRunning = true;
      this.poll();

      console.log(
        `Data collector started - polling every ${config.polling.intervalMs}ms`,
      );
    } catch (error) {
      console.error("Failed to start data collector:", error);
      throw error;
    }
  }

  /**
   * Poll PLC and save data
   */
  async poll() {
    if (!this.isRunning) {
      return;
    }

    try {
      // Retry any PLCs that are currently disconnected
      await plcClient.reconnectDisconnectedPLCs();
      
      // Check if any PLCs are connected
      const connectedPLCs = plcClient.getConnectedPLCs();

      if (connectedPLCs.length > 0) {
        console.log(`Polling connected tp PLC(s): ${connectedPLCs.join(", ")}`);

        // Read all tags (async operation)
        const tagData = await plcClient.readAllTags();
        
        if (tagData.length > 0) {

          // Convert raw values (incl. Rockwell STRING buffers) into
          // clean, storable values BEFORE writing to SQLite.
          const decodedTagData = decodeTagRecords(tagData);

          // Save to SQLite
          await sqliteHandler.saveTagData(decodedTagData);
           const countByPlc = {};
          for(const row of tagData){
            countByPlc[row.plcName] = (countByPlc[row.plcName] || 0) + 1;
          }
          const summary = Object.entries(countByPlc)
          .map(([plcName, count])=>`${plcName}: ${count}`)
          .join(", ");

          console.log(`Collected tag values:-> ${summary}`);
        } else {
          console.log("No tag values collected this cycle")
        }   
      } else {
        console.log("No PLCs connected, skipping poll");
      }
    } catch (error) {
      console.error("Error during poll:", error);
    }

    // Schedule next poll
    this.pollInterval = setTimeout(
      () => this.poll(),
      config.polling.intervalMs,
    );
  }

  /**
   * Stop the data collection service
   */
  stop() {
    console.log("Stopping data collector service...");

    this.isRunning = false;

    if (this.pollInterval) {
      clearTimeout(this.pollInterval);
      this.pollInterval = null;
    }

    plcClient.disconnect();
    sqliteHandler.close();

    console.log("Data collector stopped");
  }
}

// Export singleton instance
module.exports = new DataCollector();
