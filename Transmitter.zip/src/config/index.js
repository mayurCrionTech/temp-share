require("dotenv").config();

/**
 * Configuration module - loads and validates environment variables
 *
 * Note: PLC connection details (IP, slot, tags) are configured in
 * src/tags/tagList.js for multi-PLC support
 */

const path = require("path");

const baseDir = process.pkg
  ? path.dirname(process.execPath) // Folder containing the .exe
  : process.cwd(); // Project root while developing

const config = {
  // Data Collection
  polling: {
    intervalMs: parseInt(process.env.POLL_INTERVAL_MS, 10) || 5000,
  },

  // PLC reconnect behavior
  plc: {
    reconnectIntervalMs: parseInt(process.env.RECONNECT_INTERVAL_MS, 10) || 30000,
  },

  // SQLite Storage
  // database: {
  //   dataDir: process.env.DATA_DIR || "./data",
  // },

  database: {
    dataDir: process.env.DATA_DIR || path.join(baseDir, "data"),
  },

  // API Sync
  api: {
    baseUrl: process.env.API_BASE_URL || "http://localhost:3000/api/plc-data",
    syncIntervalMs: parseInt(process.env.API_SYNC_INTERVAL_MS, 10) || 60000,
    batchSize: parseInt(process.env.API_SYNC_BATCH_SIZE, 10) || 100,
  },

  // Logging
  logging: {
    level: process.env.LOG_LEVEL || "info",
  },
};

module.exports = config;
