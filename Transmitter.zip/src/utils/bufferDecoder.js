/**
 * bufferDecoder.js
 * ================
 *
 * Converts raw PLC tag values into clean, storable values.
 *
 * WHY THIS EXISTS
 * ----------------
 * Several tags come back from the PLC as Node Buffers (shown in logs /
 * JSON dumps as `{"type":"Buffer","data":[...]}`). Two very different
 * kinds of tags look like this:
 *
 *  1. TRUE Rockwell STRING tags (e.g. Hanger_RFID_Data[n],
 *     RB_File[n].Serial_No_VIN_1/2, Cab_Body_Code, Color_Code1).
 *     Layout: first 4 bytes = DINT length (little-endian), followed by
 *     that many ASCII character bytes (see the Rockwell STRING ASCII
 *     reference table). These CAN be safely decoded to plain text.
 *
 *  2. Multi-field UDTs (e.g. P001_LVS_111, P101_LVS_801, P001_PUF_471).
 *     These just happen to start with a 4-byte value that looks like a
 *     length, but the rest of the bytes are packed DINTs/REALs/flags
 *     from the tag's struct definition — NOT ASCII. There is no way to
 *     correctly decode these without the actual UDT (User Defined Type)
 *     layout from the Studio 5000 project, so we do NOT attempt to
 *     interpret them. We keep the raw bytes (as hex) and flag them as
 *     "struct" so nobody mistakes a guess for a real value.
 *
 * The distinguishing test: for a real STRING, every one of the
 * `length` payload bytes must be a printable ASCII character (32-126)
 * or a null padding byte. UDT structs fail this check almost
 * immediately because they contain raw binary numbers.
 */

const MAX_STRING_LEN = 256; // sane upper bound for a Rockwell STRING tag

/**
 * Normalize anything that looks like a Buffer (real Buffer instance,
 * OR the {type:"Buffer", data:[...]} shape you get after JSON
 * round-tripping) into an actual Buffer. Returns null if `v` isn't
 * buffer-shaped at all.
 */
function toBuffer(v) {
  if (Buffer.isBuffer(v)) return v;

  if (v && typeof v === "object" && v.type === "Buffer" && Array.isArray(v.data)) {
    return Buffer.from(v.data);
  }

  return null;
}

/**
 * Decode a single raw tag value.
 *
 * Returns: { value, valueType, raw? }
 *   - valueType: "string" | "struct" | "number" | "boolean" | "null" | "unknown"
 *   - value: the usable value (decoded string, original primitive, or
 *            hex string for opaque structs)
 *   - raw: (structs only) the original hex bytes, kept for later
 *          decoding once the UDT layout is known
 */
function decodeTagValue(rawValue) {
  const buf = toBuffer(rawValue);

  if (buf) {
    // Needs at least a 4-byte length header to even try STRING decoding
    if (buf.length >= 4) {
      const len = buf.readInt32LE(0);
      const payload = buf.slice(4);

      if (len >= 0 && len <= payload.length && len <= MAX_STRING_LEN) {
        const slice = payload.slice(0, len);
        const isPrintableAscii = slice.every(
          (b) => b === 0 || (b >= 32 && b <= 126),
        );

        if (isPrintableAscii) {
          const text = slice.toString("ascii").replace(/\u0000+$/, "");
          return { valueType: "string", value: text };
        }
      }
    }

    // Doesn't look like a valid Rockwell STRING -> opaque UDT/struct.
    // Keep the bytes so it can be decoded later once the UDT layout
    // (from the PLC's Studio 5000 project) is available.
    return {
      valueType: "struct",
      value: buf.toString("hex"),
      byteLength: buf.length,
    };
  }

  if (rawValue === null || rawValue === undefined) {
    return { valueType: "null", value: null };
  }

  if (typeof rawValue === "boolean") {
    return { valueType: "boolean", value: rawValue };
  }

  if (typeof rawValue === "number") {
    return { valueType: "number", value: rawValue };
  }

  if (typeof rawValue === "string") {
    return { valueType: "string", value: rawValue };
  }

  // Fallback for anything unexpected (e.g. some other object shape)
  return { valueType: "unknown", value: JSON.stringify(rawValue) };
}

/**
 * Convenience helper: decode an entire array of tag records
 * ({ name, value, ... }) in place, returning new records with
 * `value` replaced by the decoded value and a `valueType` field added.
 */
function decodeTagRecords(records) {
  return records.map((r) => {
    const { value, valueType, byteLength } = decodeTagValue(r.value);
    return {
      ...r,
      value,
      valueType,
      ...(byteLength !== undefined ? { byteLength } : {}),
    };
  });
}

module.exports = { decodeTagValue, decodeTagRecords, toBuffer };
