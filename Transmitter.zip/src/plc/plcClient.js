/**
 * PLCClient
 * =========
 *
 * This module handles READ-ONLY communication with one or more
 * Allen-Bradley PLCs using the st-ethernet-ip library.
 *
 * PRIMARY GOALS:
 *  - Safely read LARGE tag counts (1500–2000 tags per PLC)
 *  - Avoid PLC overload by batching reads
 *  - Track working / non-working tags
 *  - Support long-running, restart-safe operation
 *
 * IMPORTANT DESIGN DECISIONS:
 *  - NO write operations (read-only safety)
 *  - Sequential batch reads (PLC-safe)
 *  - Centralized tag health tracking
 */

const { Controller, Tag, TagGroup, TagList } = require("st-ethernet-ip");
const EventEmitter = require("events");
const plcConfig = require("../tags/tagList");
const config = require("../config");
// const logger = require("../utils/logger");
// const tagHealth = require("../utils/tagHealthTracker");

/**
 * ==========================
 * BATCHING CONFIGURATION
 * ==========================
 *
 * TAG_BATCH_SIZE:
 *  - Maximum number of tags per TagGroup
 *  - Must stay low enough to avoid CIP packet size limits
 *
 * BATCH_DELAY_MS:
 *  - Small delay between consecutive group reads
 *  - Prevents PLC CPU/network overload
 */
const TAG_BATCH_SIZE = 150; // SAFE batch size for EtherNet/IP
const BATCH_DELAY_MS = 30; // Delay between batch reads (ms)

/**
 * Utility function to split an array into chunks.
 *
 * Example:
 *   chunkArray([1,2,3,4,5], 2)
 *   → [[1,2], [3,4], [5]]
 *
 * Used to split large tag lists into PLC-safe batches.
 */
function chunkArray(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

/**
 * PLCClient class
 *
 * Extends EventEmitter so that higher layers can listen to:
 *  - connected
 *  - disconnected
 *  - error (if needed later)
 */
class PLCClient extends EventEmitter {
  constructor() {
    super();

    /**
     * controllers Map
     * ----------------
     * Key   → PLC name
     * Value → Object containing:
     *   - controller     (st-ethernet-ip Controller)
     *   - config         (PLC config from tagList.js)
     *   - tagNames       (Array of tag names)
     *   - tagGroups      (Array of TagGroup batches)
     *   - tagInstances   (Map of tagName → Tag instance)
     */
    this.controllers = new Map();

    /**
     * isConnected Map
     * ----------------
     * Tracks connection state per PLC
     */
    this.isConnected = new Map();

    /**
     * lastReconnectAttempt
     * --------------------
     * Global timestamp (ms) of the last reconnect sweep.
     * Prevents retrying disconnected PLCs on every single poll cycle.
     */
    this.lastReconnectAttempt = 0;
  }

  /**
   * Connect to all PLCs defined in tagList.js
   */
  async connect() {
    console.log(`Connecting to ${plcConfig.length} PLC(s)...`);

    for (const plc of plcConfig) {
      await this.connectToPLC(plc);
    }

    return true;
  }

  /**
   * Connect to a single PLC (READ-ONLY)
   *
   * Steps:
   *  1. Create controller
   *  2. Connect to PLC
   *  3. Discover or load tag list
   *  4. Split tags into batches
   *  5. Create TagGroups
   */
  async connectToPLC(plc) {
    const { name, ipAddress, slot = 0, autoDiscover = false, tags = [] } = plc;

    console.log(`Connecting to PLC "${name}" at ${ipAddress}, slot ${slot}`);

    try {
      const existing = this.controllers.get(name);
      if (existing?.controller) {
        try {
          existing.controller.destroy();
        } catch {
          // ignore cleanup errors on a dead/stale controller
        }
      }
      const controller = new Controller();

      // Establish connection to PLC
      await controller.connect(ipAddress, slot);
      this.isConnected.set(name, true);
      console.log(`Connected to PLC "${name}"`);

      /**
       * STEP 1: Determine tag list
       *
       * Each entry in plcConfig.json's "tags" array can be either:
       *   - a plain string:              "TagName"
       *   - an object with a range:      { "name": "TagName", "ranges": { "minValue": 0.9, "maxValue": 1.1 } }
       *
       * tagRanges maps tagName -> ranges object, so readAllTags() can
       * attach the configured range to every reading of that tag.
       */
      let tagNames = [];
      const tagRanges = new Map();

      if (autoDiscover) {
        // Fetch all controller tags dynamically
        const tagListObj = new TagList();
        await controller.getControllerTagList(tagListObj);

        for (const tag of tagListObj.tags) {
          if (
            tag?.name &&
            !tag.name.startsWith("__") && // Ignore system tags
            !tag.type?.reserved // Ignore reserved tags
          ) {
            tagNames.push(tag.name);
          }
        }
      } else {
        // Use static tag list from config (strings or {name, ranges} objects)
        for (const entry of tags) {
          if (typeof entry === "string") {
            tagNames.push(entry);
          } else if (entry && typeof entry === "object" && entry.name) {
            tagNames.push(entry.name);
            if (entry.ranges) {
              tagRanges.set(entry.name, entry.ranges);
            }
          }
        }
      }

      console.log(`"${name}" → ${tagNames.length} tags`);

      /**
       * STEP 2: Create TagGroups in batches
       *
       * Each TagGroup holds only TAG_BATCH_SIZE tags
       * to avoid PLC packet-size limits.
       */
      const tagGroups = [];
      const tagInstances = new Map();

      const batches = chunkArray(tagNames, TAG_BATCH_SIZE);

      for (const batch of batches) {
        const tg = new TagGroup();

        for (const tagName of batch) {
          try {
            const tag = new Tag(tagName);
            tg.add(tag);
            tagInstances.set(tagName, tag);
          } catch (err) {
            // Tag creation failure → mark as NOT_WORKING
            console.warn(`Tag create failed "${tagName}": ${err.message}`);
            /** 
            tagHealth.markNotWorking(
              `${name}:${tagName}`,
              `Tag creation failed: ${err.message}`,
            );
            */
          }
        }

        tagGroups.push(tg);
      }

      /**
       * STEP 3: Store PLC runtime state
       */
      this.controllers.set(name, {
        controller,
        config: plc,
        tagNames,
        tagGroups,
        tagInstances,
        tagRanges,
      });

      this.emit("connected", {
        plcName: name,
        tagCount: tagNames.length,
        batches: tagGroups.length,
      });
    } catch (err) {
      console.error(`PLC "${name}" connection failed: ${err.message}`);
      this.isConnected.set(name, false);
    }
  }

  /**
   * Attempt to reconnect any PLC that is currently disconnected.
   * Called on every poll cycle — retries immediately, no delay.
   */
  // async reconnectDisconnectedPLCs() {
  //   for (const plc of plcConfig) {
  //     if (this.isConnected.get(plc.name)) {
  //       continue; // already connected, skip
  //     }

  //     console.log(`Retrying connection to "${plc.name}"...`);
  //     await this.connectToPLC(plc);
  //   }
  // }

  async reconnectDisconnectedPLCs() {
    const now = Date.now();
    const reconnectIntervalMs = config.plc.reconnectIntervalMs;

    if (now - this.lastReconnectAttempt < reconnectIntervalMs) {
      return; // not time yet, skip this sweep
    }

    this.lastReconnectAttempt = now;

    console.log("Checking disconnected PLCs...");

    for (const plc of plcConfig) {
      if (this.isConnected.get(plc.name)) {
        continue;
      }

      console.log(`Retrying connection to "${plc.name}"...`);
      await this.connectToPLC(plc);
    }
  }

  /**
   * Read all tags from all connected PLCs
   *
   * IMPORTANT:
   *  - Reads batches SEQUENTIALLY
   *  - NEVER parallelizes TagGroup reads
   *  - Marks tag health per batch
   */
  async readAllTags() {
    const timestamp = new Date().toISOString();
    const allTagData = [];

    for (const [plcName, plcInfo] of this.controllers) {
      if (!this.isConnected.get(plcName)) continue;

      const { controller, tagGroups, tagRanges } = plcInfo;

      /**
       * Read each TagGroup sequentially
       */
      for (const tg of tagGroups) {
        try {
          await controller.readTagGroup(tg);

          // SUCCESS: all tags in this batch are working
         tg.forEach((tag)=>{
             const ranges = tagRanges?.get(tag.name);
             allTagData.push({
              plcName,
              name: tag.name,
              value:tag.value,
              timestamp,
              ...(ranges ? { ranges } : {}),
          })
        })

          // Small pause before next batch
          await new Promise((r) => setTimeout(r, BATCH_DELAY_MS));
        } catch (err) {
          // FAILURE: mark all tags in this batch as NOT_WORKING
          console.error(`Batch read failed "${plcName}": ${err.message}`);

          // GROUP READ FAILED → MARK ALL TAGS AS NOT WORKING
          /** 
          for (const tag of tg.tags) {
            tagHealth.markNotWorking(
              `${plcName}:${tag.name}`,
              err.message || "Batch read failed",
            );
          }
            */
        }
      }
    }

    return allTagData;
  }

  // async  readAllTags(){
  //   const timestamp = new Date().toISOString();
  //   const allTagData = [];

  //   for(const [plcName, plcInfo] of this.controllers){
  //     if (!this.isConnected.get(plcName)) continue;

  //     const { controller, config, tagGroups } = plcInfo;
  //     for (const tg of tagGroups) {
  //       try {
  //         await controller.readTagGroup(tg);

  //         tg.forEach((tag)=>{
  //            allTagData.push({
  //             plcName,
  //             plcIp: config.ipAddress,
  //             plcSlot: config.slot,
  //             name: tagName,
  //             value,
  //             timestamp,
  //         })
  //       })
  //       await new Promise((r) => setTimeout(r, BATCH_DELAY_MS));
  //       } catch (error) {
  //        console.error(`Batch read failed "${plcName}": ${err.message}`);
  //       }
  //     }
  //   }
  // }

  /**
   * Get list of connected PLC names
   */
  getConnectedPLCs() {
    return [...this.controllers.keys()].filter((name) =>
      this.isConnected.get(name),
    );
  }

  /**
   * Check whether a specific PLC is connected
   */
  isPLCConnected(plcName) {
    return this.isConnected.get(plcName) || false;
  }

  /**
   * Disconnect from all PLCs
   *
   * Called during shutdown or restart.
   */
  disconnect() {
    for (const [name, plcInfo] of this.controllers) {
      try {
        plcInfo.controller.destroy();
        this.isConnected.set(name, false);
      } catch {
        // Ignore cleanup errors
      }
    }

    this.controllers.clear();
  }
}

// Export singleton instance
module.exports = new PLCClient();

// ---------------------- MOCK -------------------------------------

// mock plc client for testing without plc

// const EventEmitter = require("events");
// const plcConfig = require("../tags/tagList");

// class MockPLCClient extends EventEmitter {
//   constructor() {
//     super();

//     this.controllers = new Map();
//     this.isConnected = new Map();
//   }

//   async connect() {
//     console.log("Starting Mock PLC...");

//     for (const plc of plcConfig) {
//       const tagNames = plc.tags || [];

//       this.controllers.set(plc.name, {
//         config: plc,
//         tagNames,
//       });

//       this.isConnected.set(plc.name, true);

//       console.log(
//         `Mock PLC "${plc.name}" Connected (${tagNames.length} tags)`
//       );

//       this.emit("connected", {
//         plcName: plc.name,
//         tagCount: tagNames.length,
//         batches: Math.ceil(tagNames.length / 150),
//       });
//     }

//     return true;
//   }

//   getConnectedPLCs() {
//     return [...this.controllers.keys()].filter((name) =>
//       this.isConnected.get(name)
//     );
//   }

//   isPLCConnected(plcName) {
//     return this.isConnected.get(plcName) || false;
//   }

//   async readAllTags() {
//     const timestamp = new Date().toISOString();
//     const allData = [];

//     for (const [plcName, plcInfo] of this.controllers) {
//       if (!this.isConnected.get(plcName)) continue;

//       const { config, tagNames } = plcInfo;

//       for (const tagName of tagNames) {
//         allData.push({
//           plcName,
//           plcIp: config.ipAddress || "127.0.0.1",
//           plcSlot: config.slot || 0,
//           name: tagName,
//           value: this.generateValue(tagName),
//           timestamp,
//         });
//       }
//     }

//     return allData;
//   }

//   generateValue(tagName) {
//     const name = tagName.toLowerCase();

//     if (name.includes("temperature") || name.includes("temp"))
//       return Number((25 + Math.random() * 15).toFixed(2));

//     if (name.includes("pressure"))
//       return Number((2 + Math.random() * 6).toFixed(2));

//     if (name.includes("speed"))
//       return Math.floor(1000 + Math.random() * 500);

//     if (name.includes("count"))
//       return Math.floor(Math.random() * 100000);

//     if (
//       name.includes("motor") ||
//       name.includes("running") ||
//       name.includes("status") ||
//       name.includes("alarm")
//     )
//       return Math.random() > 0.2;

//     if (name.includes("level"))
//       return Number((Math.random() * 100).toFixed(2));

//     if (name.includes("flow"))
//       return Number((20 + Math.random() * 80).toFixed(2));

//     return Number((Math.random() * 100).toFixed(2));
//   }

//   disconnect() {
//     this.controllers.clear();
//     this.isConnected.clear();

//     console.log("Mock PLC Disconnected");
//   }
// }

// module.exports = new MockPLCClient();