/**
 * Test script to insert sample data into SQLite
 * Run with: node scripts/testSqlite.js
 */

const sqliteHandler = require('../src/database/sqliteHandler');
// const logger = require('../src/utils/logger');

// Sample test data simulating PLC readings
const testData = [
    {
        plcName: 'Test_PLC_1',
        plcIp: '192.168.1.100',
        plcSlot: 0,
        name: 'Temperature_PV',
        value: 75.5,
        timestamp: new Date().toISOString(),
    },
    {
        plcName: 'Test_PLC_1',
        plcIp: '192.168.1.100',
        plcSlot: 0,
        name: 'Pressure_PV',
        value: 120.3,
        timestamp: new Date().toISOString(),
    },
    {
        plcName: 'Test_PLC_2',
        plcIp: '192.168.1.101',
        plcSlot: 2,
        name: 'Motor_Speed',
        value: 1450,
        timestamp: new Date().toISOString(),
    },
    {
        plcName: 'Test_PLC_1',
        plcIp: '192.168.1.100',
        plcSlot: 0,
        name: 'Tank_Level',
        value: 85.2,
        timestamp: new Date().toISOString(),
    },
];

console.log('='.repeat(50));
console.log('SQLite Test - Inserting sample PLC data');
console.log('='.repeat(50));

try {
    // Insert test data
    sqliteHandler.saveTagData(testData);
    console.log(`✅ Inserted ${testData.length} test records`);

    // Show where the database was created
    const dbPath = sqliteHandler.getDbPath();
    console.log(`📂 Database file: ${dbPath}`);

    // Close the handler
    sqliteHandler.close();

    console.log('\n✅ Test complete! Check the data directory for the .db file');
    console.log('You can open it with any SQLite browser (e.g., DB Browser for SQLite)');
} catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
}
