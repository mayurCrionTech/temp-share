const dataCollector = require('./src/services/dataCollector');
const apiSync = require('./src/services/apiSync');
// const logger = require('./src/utils/logger');

/**
 * Allen-Bradley PLC Data Bridge
 * 
 * Main entry point that starts:
 * 1. Data Collector - polls PLC and saves to SQLite
 * 2. API Sync - syncs collected data to server API
 */

// Graceful shutdown handler
let isShuttingDown = false;

async function shutdown(signal) {
    if (isShuttingDown) return;
    isShuttingDown = true;

    console.log(`Received ${signal}, shutting down gracefully...`);

    try {
        dataCollector.stop();
        apiSync.stop();
        console.log('Shutdown complete');
        process.exit(0);
    } catch (error) {
        console.error('Error during shutdown:', error);
        process.exit(1);
    }
}

// Register shutdown handlers
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Handle uncaught errors
process.on('uncaughtException', (error) => {
    console.error('Uncaught exception:', error);
    shutdown('uncaughtException');
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled rejection at:', promise, 'reason:', reason);
});

// Main startup
async function main() {
    console.log('='.repeat(50));
    console.log('Allen-Bradley PLC Data Bridge');
    console.log('='.repeat(50));

    try {
        // Start data collector (PLC polling)
        await dataCollector.start();

        // Start API sync service
        apiSync.start();

        console.log('All services started successfully');
    } catch (error) {
        console.error('Failed to start services:', error);
        process.exit(1);
    }
}

// Run
main();

// const { Controller, Tag } = require("st-ethernet-ip");

// // ===== CONFIG =====
// const PLC_IP = "192.168.1.9";
// const SLOT = 0;
// const POLL_INTERVAL_MS = 1000; // 1 second

// // List of tags to read
// const TAG_NAMES = [
//   "Ch5Data",
// ];

// // ==================

// async function startPolling() {
//   const plc = new Controller();

//   try {
//     // Connect to PLC
//     await plc.connect(PLC_IP, SLOT);
//     console.log("✅ Connected to PLC");

//     // Create Tag objects once
//     const tags = TAG_NAMES.map(name => new Tag(name));

//     // Poll loop
//     setInterval(async () => {
//       try {
//         for (const tag of tags) {
//           await plc.readTag(tag);
//           console.log(`${tag.name}:`, tag.value);
//         }
//         console.log("----");
//       } catch (readErr) {
//         console.error("❌ Read error:", readErr.message);
//       }
//     }, POLL_INTERVAL_MS);

//   } catch (err) {
//     console.error("❌ PLC Connection Error:", err);
//     plc.disconnect();
//   }
// }

// startPolling();
