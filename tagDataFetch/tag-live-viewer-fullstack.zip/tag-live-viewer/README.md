# Tag Live Data Viewer

Full-stack React + Vite + Express + MongoDB application for browsing `tag_lives` and querying `liveData_test`.

## Features

- Load all tags from `tag_lives`
- Search/filter tags
- Select a tag by name
- Enter Start Time and End Time
- Query MongoDB time-series data from `liveData_test`
- Display results in a polished table
- IST timestamps in the UI
- Summary cards for records, min, max and average
- Export the selected result set as CSV
- Pagination on the backend
- MongoDB URI stored in `.env`

## Project structure

- `backend/` - Express API + MongoDB
- `frontend/` - React + Vite UI

## 1. Backend setup

```bash
cd backend
npm install
```

Create `backend/.env`:

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017
MONGO_DB_NAME=AGI
```

If your MongoDB is remote, put your complete connection string in `MONGO_URI`.

Start backend:

```bash
npm run dev
```

or:

```bash
npm start
```

Backend runs on `http://localhost:5000`.

## 2. Frontend setup

```bash
cd frontend
npm install
npm run dev
```

Open the URL printed by Vite, normally `http://localhost:5173`.

The frontend expects the backend at `http://localhost:5000`. You can change it with:

```env
VITE_API_BASE_URL=http://localhost:5000/api
```

Create `frontend/.env` if needed.

## API

### Get tags

`GET /api/tags`

### Get live data

`GET /api/live-data?tagId=<id>&startTime=<ISO>&endTime=<ISO>&page=1&limit=1000`

### Export CSV

`GET /api/live-data/export?tagId=<id>&startTime=<ISO>&endTime=<ISO>`

## MongoDB collections

Tags:

```text
tag_lives
```

Live time-series data:

```text
liveData_test
```

The application assumes:

```js
tag_lives._id === liveData_test.tag_id
```

The UI displays timestamps as IST (`Asia/Kolkata`) while MongoDB queries use ISO timestamps.

## Notes

For very large ranges, use the UI's pagination and export only the required time range. For production, add authentication and an upper limit for export size.
