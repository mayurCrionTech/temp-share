import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Database,
  Download,
  Gauge,
  RefreshCw,
  Search,
  Server,
  SlidersHorizontal,
  Sparkles,
  Table2,
  X
} from "lucide-react";

const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";

function formatIST(iso) {
  if (!iso) return "-";
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).format(new Date(iso));
}

function toInputDateTime(date) {
  const d = new Date(date);
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  }).formatToParts(d);

  const map = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${map.year}-${map.month}-${map.day}T${map.hour}:${map.minute}`;
}

function defaultRange() {
  const end = new Date();
  const start = new Date(end.getTime() - 3 * 60 * 60 * 1000);
  return { start: toInputDateTime(start), end: toInputDateTime(end) };
}

function numberValue(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

export default function App() {
  const initialRange = defaultRange();

  const [tags, setTags] = useState([]);
  const [tagSearch, setTagSearch] = useState("");
  const [selectedTag, setSelectedTag] = useState(null);
  const [startTime, setStartTime] = useState(initialRange.start);
  const [endTime, setEndTime] = useState(initialRange.end);
  const [rows, setRows] = useState([]);
  const [pagination, setPagination] = useState({
    page: 1, limit: 1000, total: 0, totalPages: 0
  });
  const [page, setPage] = useState(1);
  const [loadingTags, setLoadingTags] = useState(true);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState("");
  const [loadedOnce, setLoadedOnce] = useState(false);

  useEffect(() => {
    fetchTags();
  }, []);

  async function fetchTags() {
    setLoadingTags(true);
    setError("");
    try {
      const res = await fetch(`${API}/tags`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Could not load tags");
      setTags(json.data || []);
      if (!selectedTag && json.data?.length) setSelectedTag(json.data[0]);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoadingTags(false);
    }
  }

  async function fetchData(targetPage = 1) {
    if (!selectedTag) {
      setError("Select a tag first.");
      return;
    }

    const start = new Date(startTime);
    const end = new Date(endTime);

    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      setError("Please enter valid start and end times.");
      return;
    }
    if (start >= end) {
      setError("Start time must be earlier than end time.");
      return;
    }

    setLoadingData(true);
    setError("");
    try {
      const params = new URLSearchParams({
        tagId: selectedTag.id,
        startTime: start.toISOString(),
        endTime: end.toISOString(),
        page: String(targetPage),
        limit: "1000"
      });

      const res = await fetch(`${API}/live-data?${params}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Could not fetch data");

      setRows(json.data || []);
      setPagination(json.pagination);
      setPage(targetPage);
      setLoadedOnce(true);
    } catch (e) {
      setError(e.message);
      setRows([]);
    } finally {
      setLoadingData(false);
    }
  }

  function exportCsv() {
    if (!selectedTag) return;
    const params = new URLSearchParams({
      tagId: selectedTag.id,
      startTime: new Date(startTime).toISOString(),
      endTime: new Date(endTime).toISOString()
    });
    window.open(`${API}/live-data/export?${params}`, "_blank");
  }

  const filteredTags = useMemo(() => {
    const q = tagSearch.toLowerCase().trim();
    if (!q) return tags;
    return tags.filter(t =>
      t.tagname.toLowerCase().includes(q) ||
      t.id.toLowerCase().includes(q)
    );
  }, [tags, tagSearch]);

  const stats = useMemo(() => {
    const values = rows.map(r => numberValue(r.value)).filter(v => v !== null);
    if (!values.length) return { min: "-", max: "-", avg: "-" };
    const min = Math.min(...values);
    const max = Math.max(...values);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    const fmt = v => Number.isInteger(v) ? String(v) : v.toFixed(3);
    return { min: fmt(min), max: fmt(max), avg: fmt(avg) };
  }, [rows]);

  const tagIndex = selectedTag
    ? tags.findIndex(t => t.id === selectedTag.id) + 1
    : 0;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Activity size={20} /></div>
          <div>
            <div className="brand-name">TagScope</div>
            <div className="brand-sub">Live Data Explorer</div>
          </div>
        </div>

        <div className="side-section">
          <div className="side-label">
            <span>TAG DIRECTORY</span>
            <span className="count">{tags.length}</span>
          </div>

          <div className="search-box">
            <Search size={16} />
            <input
              value={tagSearch}
              onChange={e => setTagSearch(e.target.value)}
              placeholder="Search tags..."
            />
            {tagSearch && <button onClick={() => setTagSearch("")}><X size={14}/></button>}
          </div>

          <div className="tag-list">
            {loadingTags ? (
              <div className="empty-side">Loading tags...</div>
            ) : filteredTags.length === 0 ? (
              <div className="empty-side">No matching tags</div>
            ) : filteredTags.map(tag => (
              <button
                className={`tag-item ${selectedTag?.id === tag.id ? "selected" : ""}`}
                key={tag.id}
                onClick={() => {
                  setSelectedTag(tag);
                  setLoadedOnce(false);
                  setRows([]);
                }}
              >
                <span className={`status-dot ${tag.isActive ? "active" : ""}`}></span>
                <span className="tag-copy">
                  <span className="tag-name">{tag.tagname}</span>
                  <span className="tag-meta">{tag.unit || "No unit"} · {tag.plcName || "PLC"}</span>
                </span>
                {selectedTag?.id === tag.id && <ChevronRight size={15} />}
              </button>
            ))}
          </div>
        </div>

        <div className="sidebar-footer">
          <div className="connection">
            <span className="pulse"></span>
            <span>MongoDB API connected</span>
          </div>
          <button className="refresh-btn" onClick={fetchTags}>
            <RefreshCw size={14}/> Refresh tags
          </button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="eyebrow">DATA EXPLORER</div>
            <h1>Live Data</h1>
            <p>Inspect time-series values from your PLC tags.</p>
          </div>
          <div className="top-actions">
            <div className="timezone">IST · Asia/Kolkata</div>
            <button className="icon-btn" onClick={fetchTags} title="Refresh tags">
              <RefreshCw size={17}/>
            </button>
          </div>
        </header>

        {error && (
          <div className="error-banner">
            <span>{error}</span>
            <button onClick={() => setError("")}><X size={16}/></button>
          </div>
        )}

        <section className="control-card">
          <div className="control-heading">
            <div className="control-icon"><SlidersHorizontal size={18}/></div>
            <div>
              <h2>Query data</h2>
              <p>Choose a tag and time window to inspect its values.</p>
            </div>
          </div>

          <div className="controls-grid">
            <div className="field tag-field">
              <label>Selected tag</label>
              <div className="selected-tag">
                <div className="tag-symbol"><Database size={17}/></div>
                <div className="selected-copy">
                  <strong>{selectedTag?.tagname || "Select a tag"}</strong>
                  <span>{selectedTag?.id || "No tag selected"}</span>
                </div>
                <span className="tag-number">{tagIndex > 0 ? `#${tagIndex}` : ""}</span>
              </div>
            </div>

            <div className="field">
              <label>Start time <span>IST</span></label>
              <input
                type="datetime-local"
                value={startTime}
                onChange={e => setStartTime(e.target.value)}
              />
            </div>

            <div className="field">
              <label>End time <span>IST</span></label>
              <input
                type="datetime-local"
                value={endTime}
                onChange={e => setEndTime(e.target.value)}
              />
            </div>

            <div className="query-actions">
              <button
                className="primary-btn"
                disabled={loadingData || !selectedTag}
                onClick={() => fetchData(1)}
              >
                {loadingData ? <RefreshCw size={17} className="spin"/> : <Sparkles size={17}/>}
                {loadingData ? "Fetching..." : "Fetch data"}
              </button>
              <button
                className="secondary-btn"
                disabled={!loadedOnce || !pagination.total}
                onClick={exportCsv}
              >
                <Download size={17}/> Export CSV
              </button>
            </div>
          </div>

          <div className="quick-range">
            <span>Quick range</span>
            {[
              ["15m", 15],
              ["1h", 60],
              ["3h", 180],
              ["6h", 360],
              ["24h", 1440]
            ].map(([label, mins]) => (
              <button
                key={label}
                onClick={() => {
                  const end = new Date();
                  const start = new Date(end.getTime() - mins * 60000);
                  setStartTime(toInputDateTime(start));
                  setEndTime(toInputDateTime(end));
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        <section className="summary-grid">
          <SummaryCard icon={<Table2/>} label="Records in page" value={rows.length.toLocaleString()} detail={`of ${pagination.total.toLocaleString()} total`} />
          <SummaryCard icon={<Gauge/>} label="Average value" value={stats.avg} detail={selectedTag?.unit || "Value"} />
          <SummaryCard icon={<Activity/>} label="Minimum" value={stats.min} detail={selectedTag?.unit || "Value"} />
          <SummaryCard icon={<Activity/>} label="Maximum" value={stats.max} detail={selectedTag?.unit || "Value"} />
        </section>

        <section className="data-card">
          <div className="data-header">
            <div>
              <h2>Data points</h2>
              <p>
                {loadedOnce
                  ? `${pagination.total.toLocaleString()} records found · sorted newest first`
                  : "Run a query to load data"}
              </p>
            </div>
            {selectedTag && (
              <div className="tag-chip">
                <span className="status-dot active"></span>
                {selectedTag.tagname}
              </div>
            )}
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Timestamp <span className="th-muted">IST</span></th>
                  <th>Value</th>
                  <th>Tag ID</th>
                  <th>Record ID</th>
                </tr>
              </thead>
              <tbody>
                {loadingData ? (
                  <tr><td colSpan="5" className="table-empty">
                    <div className="loader"></div>
                    Loading data...
                  </td></tr>
                ) : rows.length === 0 ? (
                  <tr><td colSpan="5" className="table-empty">
                    <div className="empty-icon"><Database size={22}/></div>
                    <strong>{loadedOnce ? "No records found" : "No data loaded yet"}</strong>
                    <span>{loadedOnce ? "Try another time range." : "Select a tag and click Fetch data."}</span>
                  </td></tr>
                ) : rows.map((row, index) => (
                  <tr key={row.id || `${row.timestamp}-${index}`}>
                    <td className="row-num">{(page - 1) * pagination.limit + index + 1}</td>
                    <td className="timestamp">{formatIST(row.timestamp)}</td>
                    <td><span className="value-pill">{String(row.value)}</span></td>
                    <td className="mono">{row.tagid}</td>
                    <td className="mono muted">{row.id}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pagination">
            <span>
              {pagination.total
                ? `Showing ${(page - 1) * pagination.limit + 1}–${Math.min(page * pagination.limit, pagination.total)} of ${pagination.total.toLocaleString()}`
                : "0 records"}
            </span>
            <div className="page-actions">
              <button
                disabled={page <= 1 || loadingData}
                onClick={() => fetchData(page - 1)}
              ><ChevronLeft size={16}/></button>
              <span>Page {page} / {Math.max(pagination.totalPages, 1)}</span>
              <button
                disabled={page >= pagination.totalPages || loadingData}
                onClick={() => fetchData(page + 1)}
              ><ChevronRight size={16}/></button>
            </div>
          </div>
        </section>

        <footer>
          <span><Server size={13}/> Express + MongoDB</span>
          <span>TagScope · Live Data Explorer</span>
        </footer>
      </main>
    </div>
  );
}

function SummaryCard({ icon, label, value, detail }) {
  return (
    <div className="summary-card">
      <div className="summary-icon">{icon}</div>
      <div className="summary-copy">
        <span>{label}</span>
        <strong>{value}</strong>
        <small>{detail}</small>
      </div>
    </div>
  );
}