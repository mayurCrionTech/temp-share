require("dotenv").config();

const express = require("express");
const cors = require("cors");
const { MongoClient, ObjectId } = require("mongodb");
const { stringify } = require("csv-stringify/sync");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = Number(process.env.PORT || 5000);
const MONGO_URI = process.env.MONGO_URI;
const DB_NAME = process.env.MONGO_DB_NAME;

if (!MONGO_URI || !DB_NAME) {
  console.error("Missing MONGO_URI or MONGO_DB_NAME in backend/.env");
  process.exit(1);
}

const client = new MongoClient(MONGO_URI);
let db;

function validObjectId(id) {
  return typeof id === "string" && ObjectId.isValid(id);
}

function parseDate(value, fieldName) {
  const date = new Date(value);
  if (!value || Number.isNaN(date.getTime())) {
    const error = new Error(`${fieldName} must be a valid date/time`);
    error.status = 400;
    throw error;
  }
  return date;
}

function tagProjection() {
  return {
    _id: 1,
    tagname: 1,
    datatype: 1,
    unit: 1,
    plcName: 1,
    isActive: 1,
    health: 1,
    source: 1
  };
}

app.get("/api/health", async (req, res) => {
  res.json({ ok: true, mongoConnected: Boolean(db) });
});

app.get("/api/tags", async (req, res, next) => {
  try {
    const search = String(req.query.search || "").trim();
    const filter = search
      ? { tagname: { $regex: search, $options: "i" } }
      : {};

    const tags = await db.collection("tag_lives")
      .find(filter, { projection: tagProjection() })
      .sort({ tagname: 1 })
      .toArray();

    res.json({
      success: true,
      total: tags.length,
      data: tags.map(tag => ({
        id: tag._id.toString(),
        tagname: tag.tagname || "",
        datatype: tag.datatype || "",
        unit: tag.unit || "",
        plcName: tag.plcName || "",
        isActive: tag.isActive !== false,
        health: tag.health !== false,
        source: tag.source || ""
      }))
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/live-data", async (req, res, next) => {
  try {
    const { tagId } = req.query;
    const startTime = parseDate(req.query.startTime, "startTime");
    const endTime = parseDate(req.query.endTime, "endTime");

    if (!validObjectId(tagId)) {
      return res.status(400).json({ success: false, message: "Invalid tagId" });
    }

    if (startTime >= endTime) {
      return res.status(400).json({
        success: false,
        message: "startTime must be earlier than endTime"
      });
    }

    const page = Math.max(Number(req.query.page || 1), 1);
    const limit = Math.min(Math.max(Number(req.query.limit || 1000), 1), 5000);
    const skip = (page - 1) * limit;
    const tagObjectId = new ObjectId(tagId);

    const collection = db.collection("liveData_test");
    const match = {
      tag_id: tagObjectId,
      timestamp: { $gte: startTime, $lte: endTime }
    };

    const [tag, total, rows] = await Promise.all([
      db.collection("tag_lives").findOne(
        { _id: tagObjectId },
        { projection: tagProjection() }
      ),
      collection.countDocuments(match),
      collection.find(match)
        .sort({ timestamp: -1 })
        .skip(skip)
        .limit(limit)
        .toArray()
    ]);

    if (!tag) {
      return res.status(404).json({
        success: false,
        message: "Tag not found in tag_lives"
      });
    }

    res.json({
      success: true,
      tag: {
        id: tag._id.toString(),
        tagname: tag.tagname || "",
        unit: tag.unit || "",
        datatype: tag.datatype || "",
        plcName: tag.plcName || ""
      },
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      },
      data: rows.map(row => ({
        id: row._id?.toString() || "",
        tagname: tag.tagname || "",
        tagid: row.tag_id.toString(),
        value: row.value,
        timestamp: row.timestamp.toISOString()
      }))
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/live-data/export", async (req, res, next) => {
  try {
    const { tagId } = req.query;
    const startTime = parseDate(req.query.startTime, "startTime");
    const endTime = parseDate(req.query.endTime, "endTime");

    if (!validObjectId(tagId)) {
      return res.status(400).json({ success: false, message: "Invalid tagId" });
    }

    if (startTime >= endTime) {
      return res.status(400).json({
        success: false,
        message: "startTime must be earlier than endTime"
      });
    }

    const tagObjectId = new ObjectId(tagId);

    const tag = await db.collection("tag_lives").findOne(
      { _id: tagObjectId },
      { projection: tagProjection() }
    );

    if (!tag) {
      return res.status(404).json({
        success: false,
        message: "Tag not found in tag_lives"
      });
    }

    const rows = await db.collection("liveData_test")
      .find({
        tag_id: tagObjectId,
        timestamp: { $gte: startTime, $lte: endTime }
      })
      .sort({ timestamp: 1 })
      .toArray();

    const csvRows = rows.map(row => ({
      tagname: tag.tagname || "",
      tagid: row.tag_id.toString(),
      value: row.value ?? "",
      timestamp_utc: row.timestamp.toISOString(),
      timestamp_ist: new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Kolkata",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23"
      }).format(row.timestamp).replace(",", "")
    }));

    const csv = stringify(csvRows, {
      header: true,
      columns: [
        "tagname",
        "tagid",
        "value",
        "timestamp_utc",
        "timestamp_ist"
      ]
    });

    const safeName = (tag.tagname || "tag")
      .replace(/[^a-z0-9_-]+/gi, "_")
      .slice(0, 80);

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${safeName}_live_data.csv"`
    );
    res.send(csv);
  } catch (error) {
    next(error);
  }
});

app.use((error, req, res, next) => {
  console.error(error);
  res.status(error.status || 500).json({
    success: false,
    message: error.message || "Internal server error"
  });
});

async function start() {
  await client.connect();
  db = client.db(DB_NAME);

  // Useful index for the time-series lookup pattern.
  try {
    await db.collection("liveData_test").createIndex({
      tag_id: 1,
      timestamp: 1
    });
  } catch (error) {
    console.warn("Index creation skipped:", error.message);
  }

  app.listen(PORT, () => {
    console.log(`API running on http://localhost:${PORT}`);
    console.log(`MongoDB database: ${DB_NAME}`);
  });
}

start().catch(error => {
  console.error("Failed to start:", error);
  process.exit(1);
});

process.on("SIGINT", async () => {
  await client.close();
  process.exit(0);
});