require('dotenv').config();
const { MongoClient, ObjectId } = require('mongodb');
const fs = require('fs');
const path = require('path');

// ---------------- CONFIG ----------------
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017';
const DB_NAME = process.env.DB_NAME || 'your_db_name';
const POLL_INTERVAL_MS = parseInt(process.env.POLL_INTERVAL_MS || '30000', 10);
const OUTPUT_DIR = path.resolve(process.env.OUTPUT_DIR || path.join(__dirname, 'output'));
const STATE_FILE = path.join(OUTPUT_DIR, '_state.json');
const PLC_NAMES = ['PT Production_PLC', 'ED Production_PLC'];
const BACKFILL_MINUTES = parseInt(process.env.BACKFILL_MINUTES || '0', 10);
const TAG_REFRESH_MS = 10 * 60 * 1000; // re-read tag_lives every 10 min

// -----------------------------------------

let db;
let tagMap = new Map();   // tag_id (string) -> { tagname, plcName, filePath }
let state = {};           // tag_id (string) -> ISO timestamp of last row written

function sanitizeFileName(name) {
  return String(name).replace(/[^a-zA-Z0-9_\-]/g, '_');
}

// IST = UTC+5:30, no DST. Formats as "YYYY-MM-DD HH:mm:ss".
function toIST(date) {
  const IST_OFFSET_MS = (5 * 60 + 30) * 60 * 1000;
  const ist = new Date(date.getTime() + IST_OFFSET_MS);
  const pad = (n) => String(n).padStart(2, '0');
  return `${ist.getUTCFullYear()}-${pad(ist.getUTCMonth() + 1)}-${pad(ist.getUTCDate())} ` +
         `${pad(ist.getUTCHours())}:${pad(ist.getUTCMinutes())}:${pad(ist.getUTCSeconds())}`;
}

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      console.log(`Loaded state for ${Object.keys(state).length} tags`);
    }
  } catch (err) {
    console.error('Could not read state file, starting fresh:', err.message);
    state = {};
  }
}

function saveState() {
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  } catch (err) {
    console.error('Could not save state file:', err.message);
  }
}

async function loadTags() {
  const tags = await db.collection('tag_lives').find({
    plcName: { $in: PLC_NAMES },
    isActive: true
  }).toArray();

  tagMap = new Map();

  for (const tag of tags) {
    const tagIdStr = tag._id.toString();
    const plcFolder = tag.plcName.startsWith('PT') ? 'PT' : 'ED';
    const folderPath = path.join(OUTPUT_DIR, plcFolder);
    if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });

    const filePath = path.join(folderPath, `${sanitizeFileName(tag.tagname)}.csv`);
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, 'tagname,tagid,value,timestamp_utc,timestamp_ist\n');
    }

    tagMap.set(tagIdStr, { tagname: tag.tagname, plcName: tag.plcName, filePath });

    if (!state[tagIdStr]) {
      const since = BACKFILL_MINUTES > 0
        ? new Date(Date.now() - BACKFILL_MINUTES * 60 * 1000)
        : new Date();
      state[tagIdStr] = since.toISOString();
    }
  }

  console.log(`Tracking ${tagMap.size} tags (PT + ED)`);
}

async function pollOnce() {
  if (tagMap.size === 0) return;

  const tagIds = [...tagMap.keys()].map((id) => new ObjectId(id));
  const earliestSince = new Date(Math.min(...Object.values(state).map((t) => new Date(t).getTime())));

  const docs = await db.collection('liveData_test').find({
    tag_id: { $in: tagIds },
    timestamp: { $gt: earliestSince }
  }).sort({ timestamp: 1 }).toArray();

  const buffers = new Map(); // filePath -> lines[]
  let newCount = 0;

  for (const doc of docs) {
    const tagIdStr = doc.tag_id.toString();
    const tagInfo = tagMap.get(tagIdStr);
    if (!tagInfo) continue;

    const lastSeen = new Date(state[tagIdStr]);
    if (doc.timestamp <= lastSeen) continue; // already written this one

    const line = [
      tagInfo.tagname,
      tagIdStr,
      doc.value,
      doc.timestamp.toISOString(),
      toIST(doc.timestamp)
    ].join(',') + '\n';

    if (!buffers.has(tagInfo.filePath)) buffers.set(tagInfo.filePath, []);
    buffers.get(tagInfo.filePath).push(line);

    state[tagIdStr] = doc.timestamp.toISOString();
    newCount++;
  }

  for (const [filePath, lines] of buffers) {
    fs.appendFileSync(filePath, lines.join(''));
  }

  saveState();
  console.log(`[${new Date().toISOString()}] +${newCount} rows across ${buffers.size} tag files`);
}

async function main() {
  const client = new MongoClient(MONGO_URI);
  await client.connect();
  db = client.db(DB_NAME);
  console.log('Connected to MongoDB:', DB_NAME);

  if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  loadState();
  await loadTags();

  setInterval(() => {
    loadTags().catch((err) => console.error('Tag refresh failed:', err.message));
  }, TAG_REFRESH_MS);

  await pollOnce();
  setInterval(() => {
    pollOnce().catch((err) => console.error('Poll failed:', err.message));
  }, POLL_INTERVAL_MS);

  process.on('SIGINT', async () => {
    console.log('\nShutting down, saving state...');
    saveState();
    await client.close();
    process.exit(0);
  });
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
