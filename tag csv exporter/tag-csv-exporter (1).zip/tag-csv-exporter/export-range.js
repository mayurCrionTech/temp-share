require('dotenv').config();
const { MongoClient, ObjectId } = require('mongodb');
const fs = require('fs');
const path = require('path');

// ---------------- CONFIG ----------------
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017';
const DB_NAME = process.env.DB_NAME || 'your_db_name';
const OUTPUT_DIR = path.resolve(process.env.OUTPUT_DIR || path.join(__dirname, 'output'));
const PLC_NAMES = ['PT Production_PLC', 'ED Production_PLC'];

// Usage: node export-range.js [YYYY-MM-DD] [HH:mm] [HH:mm]
// All three are IST. Defaults to today, 14:00 to 14:30 IST if omitted.
const [, , argDate, argStart, argEnd] = process.argv;

function todayIST() {
  const IST_OFFSET_MS = (5 * 60 + 30) * 60 * 1000;
  const ist = new Date(Date.now() + IST_OFFSET_MS);
  const pad = (n) => String(n).padStart(2, '0');
  return `${ist.getUTCFullYear()}-${pad(ist.getUTCMonth() + 1)}-${pad(ist.getUTCDate())}`;
}

const DATE = argDate || todayIST();     // e.g. 2026-09-04
const START_IST = argStart || '14:00';  // e.g. 14:00
const END_IST = argEnd || '14:30';      // e.g. 14:30

// Convert a "YYYY-MM-DD" + "HH:mm" IST pair into a UTC Date.
function istToUtcDate(dateStr, timeStr) {
  // IST is UTC+5:30 with no DST, so build the ISO string with the +05:30
  // offset directly and let Date parse it into the correct UTC instant.
  return new Date(`${dateStr}T${timeStr}:00+05:30`);
}

function sanitizeFileName(name) {
  return String(name).replace(/[^a-zA-Z0-9_\-]/g, '_');
}

function toIST(date) {
  const IST_OFFSET_MS = (5 * 60 + 30) * 60 * 1000;
  const ist = new Date(date.getTime() + IST_OFFSET_MS);
  const pad = (n) => String(n).padStart(2, '0');
  return `${ist.getUTCFullYear()}-${pad(ist.getUTCMonth() + 1)}-${pad(ist.getUTCDate())} ` +
         `${pad(ist.getUTCHours())}:${pad(ist.getUTCMinutes())}:${pad(ist.getUTCSeconds())}`;
}

async function main() {
  const startUtc = istToUtcDate(DATE, START_IST);
  const endUtc = istToUtcDate(DATE, END_IST);

  if (isNaN(startUtc) || isNaN(endUtc)) {
    console.error('Could not parse date/time. Use: node export-range.js YYYY-MM-DD HH:mm HH:mm');
    process.exit(1);
  }
  if (endUtc <= startUtc) {
    console.error('End time must be after start time.');
    process.exit(1);
  }

  console.log(`Exporting ${DATE} ${START_IST}\u2013${END_IST} IST  (UTC: ${startUtc.toISOString()} to ${endUtc.toISOString()})`);

  const client = new MongoClient(MONGO_URI);
  await client.connect();
  const db = client.db(DB_NAME);

  const tags = await db.collection('tag_lives').find({
    plcName: { $in: PLC_NAMES },
    isActive: true
  }).toArray();

  console.log(`Found ${tags.length} tags across PT / ED`);

  const runFolder = `range_${DATE}_${START_IST.replace(':', '')}-${END_IST.replace(':', '')}`;
  const runDir = path.join(OUTPUT_DIR, runFolder);

  const tagIds = tags.map((t) => t._id);
  const docs = await db.collection('liveData_test').find({
    tag_id: { $in: tagIds },
    timestamp: { $gte: startUtc, $lt: endUtc }
  }).sort({ timestamp: 1 }).toArray();

  console.log(`Fetched ${docs.length} data points in range`);

  // Group docs by tag_id
  const byTag = new Map();
  for (const doc of docs) {
    const key = doc.tag_id.toString();
    if (!byTag.has(key)) byTag.set(key, []);
    byTag.get(key).push(doc);
  }

  let filesWritten = 0;

  for (const tag of tags) {
    const tagIdStr = tag._id.toString();
    const plcFolder = tag.plcName.startsWith('PT') ? 'PT' : 'ED';
    const folderPath = path.join(runDir, plcFolder);
    if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });

    const filePath = path.join(folderPath, `${sanitizeFileName(tag.tagname)}.csv`);
    const rows = byTag.get(tagIdStr) || [];

    const lines = ['tagname,tagid,value,timestamp_utc,timestamp_ist'];
    for (const doc of rows) {
      lines.push([
        tag.tagname,
        tagIdStr,
        doc.value,
        doc.timestamp.toISOString(),
        toIST(doc.timestamp)
      ].join(','));
    }

    fs.writeFileSync(filePath, lines.join('\n') + '\n');
    filesWritten++;
  }

  console.log(`Done. Wrote ${filesWritten} files to ${runDir}`);
  await client.close();
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
