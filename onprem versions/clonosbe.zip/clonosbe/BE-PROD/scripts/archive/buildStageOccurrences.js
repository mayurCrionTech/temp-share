/**
 * buildStageOccurrences.js  (DRY RUN — prints only, writes nothing)
 *
 * This is the core logic the whole Analytics search/correlation feature
 * is built on: turn raw identity-tag history into "vehicle X was at stage
 * Y from time A to time B" records.
 *
 * Usage:
 *   node scripts/buildStageOccurrences.js <stageId> <fromISO> <toISO>
 *   node scripts/buildStageOccurrences.js PT-1 2026-08-13T00:00:00Z 2026-08-13T23:59:59Z
 *
 * HOW IT WORKS
 * For a stage's asset, its identity tags (Hanger_RFID_Data[N] plus the
 * RB_File[M].Cab_Body_Code / .Color_Code1 / .Serial_No_VIN_1 /
 * .Dip_Paint_skid that share that assetId) get written to liveData_test
 * on the same ~10s cadence as every other tag on that asset — confirmed
 * from your last run (5 consecutive points, same value, ~11s apart).
 *
 * So: walk each identity tag's ordered history and collapse consecutive
 * identical values into one run = one vehicle's dwell period. A run
 * starting after a blank ("") value is treated as a real occurrence;
 * blank runs themselves (nothing at the stage) are dropped.
 *
 * Then take the INTERSECTION of the Hanger run and the VIN/Type/Colour/
 * Skid runs at this asset — where they all agree in time — as one
 * occurrence record. This script only prints the result; nothing is
 * persisted. Once you confirm the output looks right against a shift you
 * remember, we'll turn this into the real ingestion job that populates a
 * VehicleStageOccurrence collection for the search APIs to query.
 */

const mongoose = require("mongoose");
const dbConfig = require("../src/configs/mongoDb_config");

// mongoDb_config.js builds its URL from process.env.MONGO_DB_PROTOCOL directly
// (not the resolved default), so if .env isn't found in the current working
// directory (e.g. you ran `cd scripts` first) MONGO_DB_URL comes out as
// "undefined://...". ANALYTICS_MONGO_URL is a plain override for these
// diagnostic/seed scripts only — set it once here (or export it as an env
// var) to whatever connection string you've confirmed works, and it's used
// regardless of where you run the script from.
const ANALYTICS_MONGO_URL =
  process.env.ANALYTICS_MONGO_URL || "mongodb://localhost:27017/paintddt";
const resolvedMongoUrl =
  dbConfig.MONGO_DB_URL && !dbConfig.MONGO_DB_URL.startsWith("undefined://")
    ? dbConfig.MONGO_DB_URL
    : ANALYTICS_MONGO_URL;
const { TagLive, TagHistory } = require("../src/models/mongoDB/tags/tagsModel");
const AnalyticsStageTagMaster = require("../src/models/mongoDB/analyticsManagement/analyticsStageTagMaster_model");
const { Assets: Asset } = require("../src/models/mongoDB/assetManagement/asset_model");

// Confirmed directly against your live DB dump — real asset numbers, not
// guessed from the doc's stage names (which don't match asset names
// reliably: doc says "Degreasing Spray", real asset is "PRE DEGREASE-SPRAY";
// doc says "DI Water Spray", real asset is "DI RINSE"). Two PT pairs share
// one physical asset (WATER RINSE 1&2 covers both PT-3 and PT-4; WATER
// RINSE 3&4 covers both PT-7 and PT-8).
//
// ED-2 (Anolyte), ED-3 (UF System) and ED-4 (After DI Rinse) never showed
// up in the identity-tag clusters at all — meaning those specific assets
// may not carry a co-located Hanger_RFID/RB_File reader. Left blank here
// until confirmed with listLineAssets.js; buildStageOccurrences.js will
// fall back to name matching for anything not in this map, which will
// likely fail the same way PT-1 just did — that's expected until we fill
// these in.
const STAGE_ASSET_NUMBER = {
  "PT-1": "40201", // PRE DEGREASE-SPRAY
  "PT-2": "40202", // DEGREASE DIP
  "PT-3": "40203", // WATER RINSE 1&2
  "PT-4": "40203", // WATER RINSE 1&2 (shared asset with PT-3)
  "PT-5": "40204", // SURFACE ACTIVATION
  "PT-6": "40205", // PHOSPHATING
  "PT-7": "40206", // WATER RINSE 3&4
  "PT-8": "40206", // WATER RINSE 3&4 (shared asset with PT-7)
  "PT-9": "40207", // WATER RINSE 5
  "PT-10": "40208", // DI RINSE
  "ED-1": "40301", // E-COAT
  "ED-5": "40304", // RCDI WATER SPRAY
  "ED-6": "40302", // UF RINSE-1 (SPRAY)
  "ED-7": "40303", // UF RINSE-2 (DIP)
};

const [, , stageIdArg, fromArg, toArg] = process.argv;

if (!stageIdArg || !fromArg || !toArg) {
  console.error("Usage: node buildStageOccurrences.js <stageId> <fromISO> <toISO>");
  process.exit(1);
}

/**
 * Collapse an ordered [{timestamp, value}] series into runs of consecutive
 * identical values: [{ value, entryTime, exitTime }]. Blank/empty/zero
 * values are dropped (nothing occupying the stage during that run).
 */
function toRuns(points, isEmpty) {
  const runs = [];
  let current = null;

  for (const p of points) {
    const empty = isEmpty(p.value);
    if (empty) {
      current = null;
      continue;
    }
    if (current && current.value === p.value) {
      current.exitTime = p.timestamp;
    } else {
      current = { value: p.value, entryTime: p.timestamp, exitTime: p.timestamp };
      runs.push(current);
    }
  }
  return runs;
}

const isEmptyString = (v) => v === "" || v === null || v === undefined;
const isEmptyNumber = (v) => !v || v === 0;

/** Do two time ranges overlap at all? */
function overlaps(a, b) {
  return a.entryTime <= b.exitTime && b.entryTime <= a.exitTime;
}

async function fetchRuns(tagId, isEmpty) {
  if (!tagId) return [];
  const points = await TagHistory.find({ tag_id: tagId })
    .sort({ timestamp: 1 })
    .select("timestamp value")
    .lean();
  return toRuns(points, isEmpty);
}

async function run() {
  await mongoose.connect(resolvedMongoUrl);
  console.log("Connected.\n");

  const stage = await AnalyticsStageTagMaster.findOne({ stageId: stageIdArg }).lean();
  if (!stage) {
    console.error(`No stage master record for "${stageIdArg}" — run seedAnalyticsStageTagMaster.js first.`);
    process.exit(1);
  }

  // Prefer the confirmed asset-number map; fall back to name matching only
  // for stages we haven't confirmed yet (this will likely fail the same
  // way it just did for anything not in STAGE_ASSET_NUMBER — that's the
  // signal to go run listLineAssets.js and fill the map in).
  let asset;
  const knownNumber = STAGE_ASSET_NUMBER[stage.stageId];
  if (knownNumber) {
    asset = await Asset.findOne({ "generalDetails.number": knownNumber }).lean();
  }
  if (!asset) {
    const nameRegex = new RegExp(stage.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
    asset = await Asset.findOne({ "generalDetails.name": nameRegex }).lean();
  }

  if (!asset) {
    console.error(
      `Could not find an asset whose name matches "${stage.name}" — the naming convention may differ ` +
        `for this stage. Tell me its real asset name/number and I'll hardcode the mapping instead of guessing by name.`,
    );
    process.exit(1);
  }

  console.log(`Stage ${stage.stageId} (${stage.name}) -> asset "${asset.generalDetails.name}" (#${asset.generalDetails.number})\n`);

  const identityTags = await TagLive.find({ assetId: asset._id })
    .select("_id tagname")
    .lean();

  const findTag = (re) => identityTags.find((t) => re.test(t.tagname));

  const hangerTag = findTag(/^hanger_rfid_data/i);
  const vinTag = findTag(/serial_no_vin_1/i);
  const typeTag = findTag(/cab_body_code/i);
  const skidTag = findTag(/dip_paint_skid/i);

  // Color_Code1 is NOT attached to the line asset (each asset only carries
  // 5 identity tags), but it exists as RB_File[N].Color_Code1 — use the
  // same RB_File index N as this asset's Cab_Body_Code tag.
  let colourTag = findTag(/color_code1/i);
  if (!colourTag && typeTag) {
    const n = typeTag.tagname.match(/RB_File\[(\d+)\]/i)?.[1];
    if (n) {
      colourTag = await TagLive.findOne({ tagname: `RB_File[${n}].Color_Code1` })
        .select("_id tagname")
        .lean();
    }
  }

  console.log("Identity tags found on this asset:");
  console.log({
    hanger: hangerTag?.tagname,
    vin: vinTag?.tagname,
    type: typeTag?.tagname,
    colour: colourTag?.tagname,
    skid: skidTag?.tagname,
  });

  const from = new Date(fromArg);
  const to = new Date(toArg);
  const inWindow = (r) => r.entryTime <= to && r.exitTime >= from;

  const [hangerRuns, vinRuns, typeRuns, colourRuns, skidRuns] = await Promise.all([
    fetchRuns(hangerTag?._id, isEmptyString),
    fetchRuns(vinTag?._id, isEmptyString),
    fetchRuns(typeTag?._id, isEmptyString),
    fetchRuns(colourTag?._id, isEmptyString),
    fetchRuns(skidTag?._id, isEmptyNumber),
  ]);

  const vinRunsInWindow = vinRuns.filter(inWindow);
  console.log(`\n${vinRunsInWindow.length} VIN run(s) in the requested window:\n`);

  for (const vRun of vinRunsInWindow) {
    const hanger = hangerRuns.find((r) => overlaps(r, vRun));
    const type = typeRuns.find((r) => overlaps(r, vRun));
    const colour = colourRuns.find((r) => overlaps(r, vRun));
    const skid = skidRuns.find((r) => overlaps(r, vRun));

    console.log({
      vehicleNumber: vRun.value,
      hanger: hanger?.value ?? "(no overlapping hanger run)",
      type: type?.value ?? "(no overlapping type run)",
      colour: colour?.value ?? "(no overlapping colour run)",
      skid: skid?.value ?? "(no overlapping skid run)",
      entryTime: vRun.entryTime.toISOString(),
      exitTime: vRun.exitTime.toISOString(),
      dwellSeconds: Math.round((vRun.exitTime - vRun.entryTime) / 1000),
    });
  }

  await mongoose.disconnect();
  console.log("\nDone — does this match a vehicle/shift you actually remember from that window?");
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
