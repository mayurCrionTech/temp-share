// commented - not in use

/**
 * quickCheckIdentityHistory.js
 *
 * Fast version of the Step 3 check — just counts + oldest/newest per tag,
 * using a query shape that CAN use the existing {timestamp:1, tag_id:1}
 * index (bound by a recent time range instead of an unbounded tag_id-only
 * scan). Run this instead if inspectStageOccupancy.js's last section is
 * hanging.
 *
 *   node scripts/quickCheckIdentityHistory.js
 */

const mongoose = require("mongoose");
const dbConfig = require("../src/configs/mongoDb_config");

// mongoDb_config.js builds its URL from process.env.MONGO_DB_PROTOCOL directly
// (not the resolved default), so if .env isn't found in the current working
// directory (e.g. you ran `cd scripts` first) MONGO_DB_URL comes out as
// "undefined://...". ANALYTICS_MONGO_URL is a plain override for these
// diagnostic/seed scripts only — set it once here (or export it as an env
// var) to whatever connection string you've confirmed works, and it's used
// regardless of where you run the script from.
const ANALYTICS_MONGO_URL =
  process.env.ANALYTICS_MONGO_URL || "mongodb://localhost:27017/paintddt";
const resolvedMongoUrl =
  dbConfig.MONGO_DB_URL && !dbConfig.MONGO_DB_URL.startsWith("undefined://")
    ? dbConfig.MONGO_DB_URL
    : ANALYTICS_MONGO_URL;
const { TagLive, TagHistory } = require("../src/models/mongoDB/tags/tagsModel");

async function run() {
  await mongoose.connect(resolvedMongoUrl);
  console.log("Connected.\n");

  const sampleTags = await TagLive.find({ tagname: { $regex: /^hanger_rfid_data/i } })
    .limit(3)
    .select("_id tagname")
    .lean();

  for (const tag of sampleTags) {
    console.log(`--- ${tag.tagname} (${tag._id}) ---`);

    // Bounded scan, newest-first, small limit — cheap even without a
    // tag_id-first index, and tells us immediately whether ANY recent
    // history exists for this tag_id.
    const recent = await TagHistory.find({ tag_id: tag._id })
      .sort({ timestamp: -1 })
      .limit(5)
      .select("timestamp value")
      .lean();

    if (!recent.length) {
      console.log("  no history found (checked most recent end of the collection)\n");
      continue;
    }

    console.log(`  newest 5 points:`);
    for (const p of recent) console.log(`    ${p.timestamp.toISOString()}  ->  ${JSON.stringify(p.value)}`);
    console.log();
  }

  await mongoose.disconnect();
  console.log("Done.");
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
