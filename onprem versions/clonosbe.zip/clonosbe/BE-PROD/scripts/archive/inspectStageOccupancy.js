// commented - not in use

/**
 * inspectStageOccupancy.js
 *
 * Diagnostic only — reads data, changes nothing. Run this once against the
 * real DB and paste me the console output (or the JSON it writes).
 *
 *   node scripts/inspectStageOccupancy.js
 *
 * WHY THIS SCRIPT EXISTS
 * The functional doc's stage journey needs a Stage-Entry / Stage-Exit
 * timestamp per vehicle per stage. Nothing in the tag_lives sample you
 * gave me has an explicit "vehicle arrived / left" tag — but I noticed
 * something that's probably the mechanism:
 *
 *   - tag_lives.assetId is a REAL reference to the `assets` collection
 *     (src/models/mongoDB/assetManagement/asset_model.js), not just a
 *     free-floating id.
 *   - The identity tags (Hanger_RFID_Data[N], RB_File[N].Cab_Body_Code,
 *     .Serial_No_VIN_1, .Dip_Paint_skid) share an assetId with a small
 *     cluster of ordinary process tags (e.g. one cluster had
 *     "DI Water Spray Flow After DI Spray" + Hanger_RFID_Data[16] +
 *     RB_File[187].* all under the same assetId).
 *
 * That suggests: each assetId is a physical point on the line, tagged
 * with both its process sensors AND whichever hanger/vehicle identity
 * is currently sitting there. If that's right, then watching the
 * identity tag's VALUE CHANGES over time in liveData_test *is* the
 * entry/exit log — a value change = a new vehicle arrived.
 *
 * This script checks that theory two ways:
 *   1. Pulls the real `assets` documents for those clustered assetIds, so
 *      we can see their actual name/number (is it "PT-6 Phosphating" or
 *      something else entirely — e.g. a hanger-slot label).
 *   2. Samples liveData_test for a couple of those identity tag_ids over
 *      a lookback window and prints only the VALUE-CHANGE points, so we
 *      can see the dwell time between changes (should look like a plant
 *      cycle time, e.g. tens of seconds to a few minutes, if this is a
 *      real occupancy signal).
 */

const mongoose = require("mongoose");
const dbConfig = require("../src/configs/mongoDb_config");
const { TagLive, TagHistory } = require("../src/models/mongoDB/tags/tagsModel");
const { Assets: Asset } = require("../src/models/mongoDB/assetManagement/asset_model");

// How far back to sample for the value-change check. Adjust freely —
// wider windows just take longer and print more transitions.
const LOOKBACK_HOURS = 6;

// How many distinct identity-tag_ids to sample in detail (keep this
// small — this is a diagnostic, not a bulk pull).
const SAMPLE_TAG_COUNT = 3;

async function run() {
  await mongoose.connect(dbConfig.MONGO_DB_URL);
  console.log("Connected.\n");

  // ── Step 1: find every identity tag and group by assetId ──────────────
  const identityTags = await TagLive.find({
    tagname: { $regex: /hanger_rfid|rb_file/i },
  })
    .select("_id tagname assetId latestValue")
    .lean();

  console.log(`Found ${identityTags.length} identity tags (Hanger_RFID_Data / RB_File).\n`);

  const byAsset = new Map();
  for (const t of identityTags) {
    for (const aid of t.assetId || []) {
      const key = aid.toString();
      if (!byAsset.has(key)) byAsset.set(key, []);
      byAsset.get(key).push(t);
    }
  }

  console.log(`These fall under ${byAsset.size} distinct assetIds.\n`);

  // ── Step 2: pull the real asset docs for those ids ─────────────────────
  const assetIds = [...byAsset.keys()];
  const assets = await Asset.find({ _id: { $in: assetIds } })
    .select("_id generalDetails.name generalDetails.number")
    .lean();
  const assetById = new Map(assets.map((a) => [a._id.toString(), a]));

  console.log("=== Asset clusters (assetId -> real asset name/number + its tags) ===");
  let printed = 0;
  for (const [assetIdStr, tags] of byAsset.entries()) {
    const asset = assetById.get(assetIdStr);
    console.log(
      `\nasset ${assetIdStr}  ->  ${asset ? `"${asset.generalDetails?.name}" (#${asset.generalDetails?.number})` : "(no matching asset doc found)"}`,
    );
    for (const t of tags) {
      console.log(`    ${t.tagname}  = ${JSON.stringify(t.latestValue)}`);
    }
    printed++;
  }

  // ── Step 3: find each tag's ACTUAL data range first, then sample changes ──
  // (a fixed lookback is meaningless if the DB hasn't had fresh writes
  // recently — check what's really there before concluding anything)
  console.log(`\n\n=== Value-change history for ${SAMPLE_TAG_COUNT} sample tags ===`);

  const sampleTags = identityTags
    .filter((t) => /hanger_rfid/i.test(t.tagname)) // start with the hanger id tags, easiest to read
    .slice(0, SAMPLE_TAG_COUNT);

  for (const tag of sampleTags) {
    const totalCount = await TagHistory.countDocuments({ tag_id: tag._id });
    const [oldest] = await TagHistory.find({ tag_id: tag._id }).sort({ timestamp: 1 }).limit(1).select("timestamp").lean();
    const [newest] = await TagHistory.find({ tag_id: tag._id }).sort({ timestamp: -1 }).limit(1).select("timestamp").lean();

    console.log(`\n--- ${tag.tagname} (${tag._id}) ---`);
    console.log(`  total history docs: ${totalCount}`);
    console.log(`  oldest: ${oldest ? oldest.timestamp.toISOString() : "(none)"}`);
    console.log(`  newest: ${newest ? newest.timestamp.toISOString() : "(none)"}`);

    if (!totalCount) {
      console.log("  -> no history at all for this tag_id in liveData_test.");
      continue;
    }

    // Sample the most recent 500 points instead of a fixed time window,
    // so this works regardless of how stale or fresh the DB is.
    const points = await TagHistory.find({ tag_id: tag._id })
      .sort({ timestamp: -1 })
      .limit(500)
      .select("timestamp value")
      .lean();
    points.reverse();

    let last = undefined;
    let changes = 0;
    for (const p of points) {
      if (p.value !== last) {
        console.log(`  ${p.timestamp.toISOString()}  ->  ${JSON.stringify(p.value)}`);
        last = p.value;
        changes++;
      }
    }
    console.log(`  (${changes} value changes across ${points.length} raw points)`);
  }

  await mongoose.disconnect();
  console.log("\nDone — paste this output back and I'll take it from here.");
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
