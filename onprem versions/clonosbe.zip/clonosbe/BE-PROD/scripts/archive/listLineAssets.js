// commented - not in use

/**
 * listLineAssets.js  (read-only diagnostic)
 *
 * Lists every asset numbered 402xx / 403xx (the PT/ED line, based on the
 * confirmed pattern: PRE DEGREASE-SPRAY=40201 ... DI RINSE=40208,
 * E-COAT=40301 ... RCDI WATER SPRAY=40304) and, for each, whether it has
 * a Hanger_RFID_Data / RB_File tag attached.
 *
 * Two things this answers:
 *   1. What are the real names/numbers for ED-2 (Anolyte), ED-3 (UF
 *      System), ED-4 (After DI Rinse) — they didn't show up in the last
 *      identity-tag dump, so either the numbering skips past them or
 *      they exist but genuinely have no identity reader attached.
 *   2. Whether EVERY stage's asset carries identity tags, or only some
 *      do. If some stages have no identity reader at all, the vehicle's
 *      presence there can't be read directly — it has to be inferred
 *      from the nearest upstream/downstream stage that DOES have one,
 *      using known transit time. Worth knowing before building the full
 *      correlation engine, not after.
 *
 *   node scripts/listLineAssets.js
 */

const mongoose = require("mongoose");
const dbConfig = require("../src/configs/mongoDb_config");
const ANALYTICS_MONGO_URL =
  process.env.ANALYTICS_MONGO_URL || "mongodb://localhost:27017/paintddt";
const resolvedMongoUrl =
  dbConfig.MONGO_DB_URL && !dbConfig.MONGO_DB_URL.startsWith("undefined://")
    ? dbConfig.MONGO_DB_URL
    : ANALYTICS_MONGO_URL;

const { TagLive } = require("../src/models/mongoDB/tags/tagsModel");
const { Assets: Asset } = require("../src/models/mongoDB/assetManagement/asset_model");

async function run() {
  await mongoose.connect(resolvedMongoUrl);
  console.log("Connected.\n");

  const assets = await Asset.find({
    "generalDetails.number": { $regex: /^40[23]/ },
  })
    .select("_id generalDetails.name generalDetails.number")
    .sort({ "generalDetails.number": 1 })
    .lean();

  console.log(`Found ${assets.length} assets numbered 402xx/403xx:\n`);

  for (const asset of assets) {
    const identityTags = await TagLive.find({
      assetId: asset._id,
      tagname: { $regex: /hanger_rfid|rb_file/i },
    })
      .select("tagname")
      .lean();

    const flag = identityTags.length ? "" : "   <-- NO identity tag on this asset";
    console.log(
      `#${asset.generalDetails.number}  ${asset.generalDetails.name}  (${identityTags.length} identity tags)${flag}`,
    );
  }

  await mongoose.disconnect();
  console.log("\nDone.");
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
