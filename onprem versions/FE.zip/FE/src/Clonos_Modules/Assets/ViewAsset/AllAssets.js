import {
	checkUserHasPermission,
	commonPageState,
	generateSkeletonColumns,
	getFormatedDate,
	getUser,
	handleLoginExpiry,
	handleSegregateURL,
	loginJumpLoadingStopper,
	modifyString,
	setSerialNumber,
} from "../../../utils/clonosCommon";
import {
	getAllAssetsDataMethod,
} from "../../../utils/AssetsMethods/AssetsList";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import React, { Suspense, useEffect, useState } from "react";
import { updateLayout } from "../../../utils/clonosCommon";
import useToggler from "../../../CustomHooks/TogglerHook";
import NOIMAGE from "../../../assets/images/noImg.jpg"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { Task } from "../../../assets/svg/Task";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { Card } from "@material-ui/core";
// import ClonosGridNav from "../../../utils/ClonosGridNav";
import { doGetApiCall, doPutApiCall } from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";
import { MaintenanceTasksListModal } from "../../ScheduledMaintenance/MaintenanceTasksListModal/MaintenanceTasksListModal";
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog";
import { handleDeleteAsset } from "../../../utils/AssetsMethods/AssetRegister";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
import { AssetsUnderMaintenanceIcon } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { assetListSkeletonColumns, assetStatusWithColors } from "../../../utils/AssetsMethods/constants";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_ASSETS } from "../../../Constants/Constant";
import { AlertRedFilledCircleIcon } from "../../../assets/AssetsSVGComponents/AlertRedFilledCircleIcon";
import { CompleteAssetAlert } from "./CompleteAssetAlert/CompleteAssetAlert";
import { statusStyleStaticData } from "../../../Constants/StaticData";

const params = {
	assetImages: 1,
	assetLayoutImage: 1,
	asset3DModel: 1,
	location: 1,
	runningMode: 1,
	assetDepartment: 1,
	criticalityLevel: 1,
	functionalArea: 1,
	createdBy: 1,
	assetOwner: 1,
	parentAsset: 1,
	assetTermsAndConditions: 1,
}

const ClonosGridNav = React.lazy(() => import("../../../utils/ClonosGridNav"))

const AllAssets = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();
	const URL = handleSegregateURL();
	const [allAssets, setAllAssets] = useState([{
		"index":1,
		"_id": "ast-65b8dada893b062c8155256e",
		"plant3DId": "p3d-65fa9fc1f18b906742d68a3f",
		"assetName": "ANALYSER TRANSMITTER ",
		"assetNumber": "AT-105A",
		"assetDescription": "\"The Rosemount 6888 In Situ Oxygen Analyzer provides a continuous, accurate measurement of the oxygen remaining in flue gases coming from any combustion process. Accurate measurements of furnace exhaust excess oxygen are critical for combustion optimization, resulting in reduced energy costs, increased safety, and lower emissions. \\r\\n\\r\\nOutstanding accuracy: ±0.75% of reading or ±0.05% O2.\\r\\n\\r\\nRugged explosion-proof design for hazardous area approvals\\r\\nsatisfies ATEX/IECEX Ex d and CSA Class 1, Division",
		"assetMode": "asm-001",
		"runningMode": "run-002",
		"assetDepartment": "adp-002",
		"workOrders": [
		  "wo-0bff72ca-fe99-4ba9-931d-0a22caf409b2"
		],
		"assetCategory": "act-010",
		"criticalityLevel": "cri-002",
		"functionalArea": "fun-003",
		"assetOwner": "usr-de23470d-b373-4ad0-9b04-2bd6b2d1ddcb",
		"censusNumber": "T_AT-105A",
		"assetType": "aty-001",
		"assetTermsAndConditions": [
		  "atc-f1744a8f-d18c-46eb-a2e9-6f867572557c"
		],
		"assetImages": [
		  "asi-41c983c5-697d-4ca5-9af2-e9c56c5a06a6"
		],
		"assetMake": "Rosemount",
		"assetModel": "Rosemount 6888",
		"serialNumber": "T_123456",
		"manufacturer": "Emerson",
		"installationDate": {
		  "$date": "2024-01-31T00:00:00.000Z"
		},
		"serviceLiquid": "Natural gas",
		"hazardousAreaDetails": {
		  "zoneClassification": "Zone 1",
		  "gasGroup": "D",
		  "temperatureClassification": "T2"
		},
		"isWarrantyIncluded": true,
		"warrantyPeriodNumber": 24,
		"warrantyPeriodDurr": "months",
		"supplierName": "Test1Supplier",
		"supplierEmail": "manogaran26@gmail.com",
		"warrantyEndDate": {
		  "$date": "2026-01-31T00:00:00.000Z"
		},
		"location": "loc-809e1938-d038-43eb-92ef-f64ce5b7889d",
		"geoLocation": {
		  "longitude": 80.15,
		  "latitude": 13.21,
		  "elevation": 5
		},
		"assetTags": [
		  "atg-65bd86ccc5465ee9603b1a45"
		],
		"assetLevel": 1,
		"isActive": true,
		"createdBy": "usr-de23470d-b373-4ad0-9b04-2bd6b2d1ddcb",
		"updatedBy": "usr-e6df8bf2-22d7-478a-af6f-3aafe3c04756",
		"createdDate": {
		  "$date": "2024-01-30T11:17:46.573Z"
		},
		"updatedDate": {
		  "$date": "2024-06-05T17:07:45.999Z"
		},
		"assetStatus": "Active",
		"incrementId": 1,
		"__v": 0
	  }])
	const [isLoading, setIsLoading] = useToggler();
	const [totalCount, setTotalCount] = useState(0);
	const [refreshApi, setRefreshApi] = useToggler();
	const [selectedRows, setSelectedRows] = useState([]);
	const [selectedAsset, setSelectedAsset] = useState({})
	const [showDeleteDailog, setShowDeleteDailog] = useToggler();
	const [pagination, setPagination] = useState(commonPageState);
	const [showFillAssetAlert, setShowFillAssetAlert] = useState(false);
	const [selelctedRowAssetId, setSelectedRowAssetId] = useState(null)
	const [showMaintenanceModal, setShowMaintenanceModal] = useToggler();
	const [showAssetCountsLoading, setShowAssetCountsLoading] = useToggler();
	const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS);
	const [counts, setCounts] = useState({
		allAssets: 0,
		activeAssets: 0,
		assetsUnderMaintenance: 0
	});

	const columns = [
		{
			field: "index",
			headerName: "SI.NO",
			width: "50",
			disableColumnFilter: true,
			headerClassName: "ast_column_header",
			hideable: false
		},
		{
			field: "assetImage",
			headerName: "",
			width: "100",
			disableColumnFilter: true,
			headerClassName: "ast_column_header",
			filterPanelClassName: "ast_column_filterPanel",
			renderCell: (params) => {
				return <img height={30} width={30} src={params?.row?.assetImages?.length > 0 ? params?.row?.assetImages[0]?.imageUrl : NOIMAGE} />
			}
		},
		{
			field: "assetNumber",
			headerName: "Asset Number",
			// width:"100",
			flex: 1,
			disableColumnFilter: true,
			headerClassName: "ast_column_header",
			filterPanelClassName: "ast_column_filterPanel",
			renderCell: (params) => (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ }) ? <div
				style={{ cursor: "pointer", color: "#0A5FFF" }}
				onClick={() =>
					navigate(`/view-asset/${params?.row?.assetName}`, {
						state: {
							assetId: params?.row?._id,
							parentId: params?.row?.parentAsset,
							// activePage,
							// limit,
						}
					})
				}
			>
				{params?.row?.assetNumber}
			</div> : <div>{params?.row?.assetNumber}</div>
			),
		},
		{
			field: " ",
			headerName: "",
			width: "50",
			headerClassName: "ast_column_header",
			renderCell: (param) => {
				const showAlert = param?.row?.isAsset3DDetailsPresent && param?.row?.isAssetDocumentsPresent && param?.row?.isAssetParametersPresent && param?.row?.isAssetReferenceManualsPresent ? true : false;
				return !showAlert ? <div style={{ position: "relative", cursor: "pointer" }} onClick={() => {
					setShowFillAssetAlert(true);
					setSelectedAsset(param?.row)
				}}>
					<AlertRedFilledCircleIcon />
				</div> : <></>
			}
		},
		{
			field: "assetName",
			headerName: "Asset Name",
			// width:"250",
			flex: 1,
			headerClassName: "ast_column_header",
		},
		{
			field: "assetDepartment",
			headerName: "Department",
			// width:"200",
			flex: 1,
			headerClassName: "ast_column_header",
			valueGetter: (params) => params?.row?.assetDepartment?.dropdownValues || "-",
		},
		{
			field: "criticalityLevel",
			headerName: "Criticality Level",
			// width:"200",
			flex: 1,
			headerClassName: "ast_column_header",
			valueGetter: (params) => params?.row?.criticalityLevel?.dropdownValues || "-",
		},
		{
			field: "assetStatus",
			headerName: "Status",
			headerClassName: "ast_column_header",
			flex: 1,
			align: 'center',
			headerAlign: 'center',
			renderCell: (param) => {
				const status = modifyString(param?.row?.assetStatus, "camelcase");
			
				return <div style={{ background: statusStyleStaticData[status]?.backgroundColor, color: statusStyleStaticData[status]?.color, padding: "0.4rem 1rem", borderRadius: "6px" }}>{param?.row?.assetStatus}</div>
			}
		},
		{
			field: "assetOwner",
			headerName: "Owner",
			// width:"200",
			flex: 1,
			headerClassName: "ast_column_header",
			valueGetter: (params) => params?.row?.assetOwner?.name || "-",
		},
		{
			field: "maintenancePlan",
			headerName: "Maintenance Plan",
			// minWidth:"200",
			flex: 1,
			headerClassName: "ast_column_header",
			renderCell: (val) => {
				return <>
					<div className="c-pointer" style={{ textDecoration: "underline", color: "#0A5FFF" }} onClick={() => {
						setShowMaintenanceModal(true);
						setSelectedRowAssetId(val?.row?._id)
					}}>View Maintenance Plan</div>
				</>
			}
		},
		{
			field: "createdDate",
			headerName: "Created Date",
			// minWidth:"150",
			flex: 1,
			valueGetter: (params) => getFormatedDate(params.value),
			headerClassName: "ast_column_header",
		},
	];

	// useEffect(() => {
	// 	setIsLoading();
	// 	// setAllAssets([]);
	// 	doGetApiCall(AppUrl.getAssets, { ...params, ...pagination })
	// 		.then(res => {
	// 			// setAllAssets(setSerialNumber(res?.data?.result?.data || [], pagination.page, pagination.limit));
	// 			setTotalCount(res?.data?.result?.totalDataCount || res?.data?.result?.data?.length || 0);
	// 		})
	// 		.finally(setIsLoading)
	// }, [pagination, refreshApi]);

	const doDelete = () => {
		setShowDeleteDailog()
		const user = getUser();
		setIsLoading();
		const payload = { assetIds: selectedRows, updatedBy: user?.userId };
		doPutApiCall(AppUrl.deleteAssets, payload)
			.then(res => {
				commonActions.handleSnackbar({
					show: true,
					message: `Successfully Deleted`,
					type: "success",
				});
				setRefreshApi();
			})
			.finally(setIsLoading)
	}

	useEffect(() => {
		setShowAssetCountsLoading()
		doGetApiCall(AppUrl.getAssetsCounts).then((res) => {
			setCounts({
				allAssets: res?.data?.result?.totalAssets,
				activeAssets: res?.data?.result?.activeAssets,
				assetsUnderMaintenance: res?.data?.result?.underMaintenanceAssets
			})
		}).catch((err) => {
			handleLoginExpiry(err, dispatch);
		}).finally(setShowAssetCountsLoading)
	}, []);


	if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
		return <>
			{
				(!URL?.unity && !URL?.AR && !URL?.VR) &&

				<ClonosGridNav isLoading={showAssetCountsLoading} items={[
					{
						icon: TotalAssetsIcon,
						iconBg: '#E7EFFF',
						title: 'Total Assets',
						count: counts?.allAssets || 0,
					},
					{
						icon: ActiveAssetsIcon,
						iconBg: '#EBFAEC',
						title: 'Active Assets',
						count: counts?.activeAssets || 0
					},
					{
						icon: AssetsUnderMaintenanceIcon,
						iconBg: '#F7E9BF',
						title: 'Assets under Maintenance',
						count: counts?.assetsUnderMaintenance || 0
					}
				]}>
					<div className="d-fl-al-cen">
						{checkUserHasPermission({ moduleName: 'maintenancePlan', action: CLONOS_GLOBAL_ACTION_CREATE }) ? showAssetCountsLoading ? <ClonosSkeletonLoading variant="rounded" width="50%" height="40px" animation="wave" /> : <ClonosButton onClick={() => navigate("/create-scheduled-maintenance")} variant={"outlined"}>Schedule Maintenance Plan</ClonosButton> : <></>}
						{checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? showAssetCountsLoading ? <ClonosSkeletonLoading variant="rounded" width="40%" height="40px" animation="wave" /> : <ClonosButton className="ml-half" onClick={() => navigate("/create-asset")} variant={"filled"}>Create New Asset</ClonosButton> : <></>}
					</div>
				</ClonosGridNav>
			}
			<Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", padding: "1rem", overflowY: "scroll" }}>
				<ClonosDataGrid
					handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
					rows={allAssets}
					columns={columns}
					uniqueIdField={"_id"}
					totalCount={totalCount}
					pageLimit={pagination.limit}
					isEditMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => navigate("/edit-asset", {
						state: {
							assetId: selectedRows[0],
						}
					}) : false}
					isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowDeleteDailog : false}
					onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
					loading={isLoading}
				/>
			</Card>
			<ClonosConfirmationBox isOpen={showDeleteDailog} headerTitle={"Delete Asset"} message={"Are you sure you want to Delete?"} closeModalMethod={setShowDeleteDailog} confirmingMethod={doDelete} />
			<MaintenanceTasksListModal assetId={selelctedRowAssetId} open={showMaintenanceModal} closeModalMethod={setShowMaintenanceModal} />
			<CompleteAssetAlert isOpen={showFillAssetAlert} closeMethod={setShowFillAssetAlert} asset={selectedAsset} />
		</>
	}
	return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default AllAssets;