import { useEffect, useState } from "react";
import Styles from "../../../ModuleStyles/Assets/viewAsset.module.css";
import FiltersStyles from "../../../ModuleStyles/Assets/assets.module.css";
import { getWorkOrdersAssociatedWithAsset } from "../../../Api/Asset/assetApi";
import { useLocation } from "react-router-dom";
import { getFormatedDate, handleLoginExpiry } from "../../../utils/clonosCommon";
import { BsSearch } from "react-icons/bs";
import { useDispatch, useSelector } from "react-redux";
import { handleGetWorkOrder } from "../../../utils/WorkOrderMethods/WorkOrderMethods";
import { workOrderStateManagementActions } from "../../../Store/Reducers/ClonosWorkOrderReducer";
import { UnderDevelopmentPage } from "../../../components/CommonComponents/UnderDevelopmentPage/UnderDevelopmentPage";
import { getWorkOrdersOfAsset } from "../../../Api/WorkOrder/WorkOrderApi";
export const ViewAssetHistory = ({data}) => {
//   const [workOrders, setWorkOrders] = useState([]);
  const Location = useLocation();
  const dispatch = useDispatch();
  const arr = new Array(10).fill(1)
  const [filters, setFilters] = useState({});
  const [totalWorkOrder,setTotalWorkOrder] =useState()
  const [currentPage,setCurrentPage]= useState(1)
  const [workOrders,setWorkOrders] = useState([])
  const status = ["Completed","Draft","Accepted","Scheduled","On Hold","All"]
  const handleChangeFilters = (e) => {
    const {name,value} = e.target;
    setFilters((prev) => {
        return {
            ...prev,
            [name] : value
        }
    })
  }

  useEffect(() => {
    getWorkOrdersOfAsset({assetId:data?._id}).then((res) => {
      setWorkOrders(res?.data?.result?.workOrders)
    })
    .catch((err) => {
      handleLoginExpiry(err,dispatch)
    })
  },[filters])

  useEffect(() => {

  },[dispatch])
  return (
    <div className={Styles.astHistoryContainer}>
      <div className={Styles.stteper_container}>
        {
          arr?.map((step,index) => {
            return <div className={Styles.step_wrapper}>
            <div className={Styles.left}>12 September 2021</div>
            <div className={Styles.center}>
              <div className={Styles.circle}>{index+1}</div>
              {index < arr.length - 1 && (
                <div className={Styles.line}>
                  <p></p>
                </div>
              )}
            </div>
            <div className={Styles.right}>
              <h5>Purchased On</h5>
              <p>Step Description</p>
            </div>
          </div>
          })
        }
      </div>
    </div>
  );
};
