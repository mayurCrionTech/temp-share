import { useEffect, useState } from "react";
import { UnderDevelopmentPage } from "../../../components/CommonComponents/UnderDevelopmentPage/UnderDevelopmentPage";
import { getAssetDocuments } from "../../../Api/Asset/assetApi";
import {
  commonPageState,
  getToken,
  handleLoginExpiry,
} from "../../../utils/clonosCommon";
import { useDispatch } from "react-redux";
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog";
import { deleteMultipleDocumentAPI } from "../../../Api/Documents/DocumentApi";
import configs from "../../../config";
import { Card, Tooltip } from "@mui/material";
import { doGetApiCall } from "../../../utils/ClonosApi";
import useToggler from "../../../CustomHooks/TogglerHook";

export const ViewAssetDocuments = ({ data }) => {
  const [rows, setRows] = useState([]);
  const dispatch = useDispatch();
  const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [pagination, setPagination] = useState(commonPageState);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useToggler();
  const columns = [
    {
      field: "index",
      headerName: "SI.NO",
      width: 100,
      renderCell: (val) => {
        return <p>{val?.row?.index || "-"}</p>;
      },
    },
    {
      field: "documentNumber",
      headerName: "DOCUMENT NUMBER",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.documentNumber}>
            <p>{val?.row?.documentNumber || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "documentTitle",
      headerName: "DOCUMENT NAME",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.documentName}>
            <p>{val?.row?.documentName || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "documentType",
      headerName: "DOCUMENT TYPE",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.documentType?.name}>
            <p>{val?.row?.documentType?.name || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "status",
      headerName: "DOCUMENT STATUS",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.status?.name}>
            <p>{val?.row?.status?.name || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "revisionNumber",
      headerName: "REVISION NUMBER",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.revisionNumber}>
            <p>{val?.row?.revisionNumber || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "viewDoc",
      headerName: "VIEW DOCUMENT",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.fileName}>
            <p
              onClick={() => handleViewDocument(val?.row?.docId)}
              style={{ color: "#0a5fff", textDecoration: "underline" }}
            >
              {val?.row?.fileName || "-"}
            </p>
          </Tooltip>
        );
      },
    },
  ];

  const handleViewDocument = (docId) => {
    const token = getToken();
    window.open(`${configs.url}/?astDocId=${docId}&token=${token}`);
  };

  const handleDelete = () => {
    deleteMultipleDocumentAPI({ payload: selectedRows })
      .then((res) => {
      })
      .catch((err) => {
        handleLoginExpiry(err, dispatch);
      });
  };

  useEffect(() => {
    setIsLoading();
    if (data?._id) {
      const url = `/assetDocuments/list/${data?._id}?status=true`;
      doGetApiCall(url, pagination)
        .then((res) => {
          setRows(res?.data?.result?.data);
          setTotalCount(
            res?.data?.result?.totalDataCount || res?.data?.result?.data?.length
          );
        })
        .finally(setIsLoading);
    }
  }, [data?._id]);
  return (
    <>
      <Card
        style={{
          flex: 1,
          height:"90%",
          margin:"1rem 1rem 0rem 1rem",
          padding: "1rem",
        }}
      >
        <ClonosDataGrid
          isLoading={isLoading}
          onPageChange={(e) =>
            setPagination({ page: e.page + 1, limit: e.pageSize })
          }
          checkboxSelection={false}
          handleGetSelectedRowsMethod={(val) =>
            setSelectedRows(val?.selectedRows)
          }
          rows={rows?.map((row, index) => ({ ...row, index: index + 1 }))}
          columns={columns}
          uniqueIdField={"docId"}
          pageLimit={10}
          isEdit={false}
          isDelete={false}
        />
      </Card>
      <ClonosConfirmationDialog
        Open={showConfirmationDailog}
        CloseDialog={() => setShowConfirmationDailog(false)}
        Title="Delete Document"
        Content="Are you sure you want to delete?"
        ProceedDialog={handleDelete}
      />
      {/* <UnderDevelopmentPage/> */}
    </>
  );
};
