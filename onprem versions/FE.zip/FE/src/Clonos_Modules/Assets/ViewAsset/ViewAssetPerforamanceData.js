export const ViewAssetPerformanceData = () => {
    return <></>
}