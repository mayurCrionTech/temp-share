import { useLocation, useNavigate } from "react-router-dom";
import Styles from "../../../ModuleStyles/Assets/viewAsset.module.css";
import CommonNavigator from "../../../components/CommonComponents/Navigator/Navigator";
import { ViewAssetGeneralDetails } from "./ViewAssetGeneralDetails";
import { useEffect } from "react";
import { getSingleAsset } from "../../../Api/Asset/assetApi";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import { ViewAssetHistory } from "./ViewAssetHistory";
import { ViewAssetPerformanceData } from "./ViewAssetPerforamanceData";
import { ViewAssetDocuments } from "./ViewAssetDocuments";
import { ViewAssetSparesAndInventory } from "./ViewAssetSparesAndInventory";
import { checkUserHasPermission, getUser, globalhandlerOutsideRequest, handleAllowDirectAccessPage, handleEncryptionURLKeys, handleLoginExpiry, handleSegregateURL, handleShowErrorAndWarning, updateLayout } from "../../../utils/clonosCommon";
import { ViewAsset3DDetails } from "./ViewAsset3DDetails";
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog";
import {
  handleDeleteAsset,
  handleEditAsset,
} from "../../../utils/AssetsMethods/AssetRegister";
import { optionalParamsForSingleAsset } from "../../../utils/AssetsMethods/constants";
import { lcHandleDummyEncryption } from "../../../utils/WorkOrderMethods/WorkOrderMethods";
import ViewAssetParameters from "./ViewAssetParameters";
import ViewAssetReferenceManuals from "./ViewAssetReferenceManuals";
import { ViewMaintenanceTask } from "./ViewMaintenanceTask";
import Subbar from "../../../components/CommonComponents/ClonosSubbar/Subbar";
import { Card } from "@material-ui/core";
import { QRCode } from "../../../assets/AssetsSVGComponents/QRCode";
import { QRCodeModal } from "../../../components/CommonComponents/QRCodeModal/QRCodeModal";
import { doGetApiCall } from "../../../utils/ClonosApi";
import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_ASSETS } from "../../../Constants/Constant";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";

const navigatorValues = [
  { value: "General Details", status: true },
  { value: "Parameters", status: false },
  { value: "Reference Manuals", status: false },
  { value: "3D", status: false },
  { value: "History", status: false },
  { value: "Performance Data", status: false },
  { value: "Spares & Inventory", status: false },
  { value: "Documents", status: false },
  { value: "Maintenance Task", status: false },
];

const ViewAsset = () => {
  const { mainLayoutChildrenPositionsToolkitState } = useSelector(
    (store) => store.globalEntitiesStateManagement
  );
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS)
  const [selectedFilter, setSelectedFilter] = useState("General Details");
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const [qrCodeDetails, setQrCodeDetails] = useState(null)
  const user = getUser();
  const assetDetails = useSelector(store => store.assetData?.assetDetail);
  const [isLoading, setIsLoading] = useState(false);
  const [showDeleteDailog, setShowDeleteDailog] = useState(false);
  const [showQRCodeModal, setShowQRCodeModal] = useState(false)
  const Location = useLocation();
  const URL = handleSegregateURL();  //Segregate URL parameters
  const handleDecommission = () => {
    const currentDate = new Date();
    const isoFormattedDate = currentDate.toISOString();
    handleEditAsset({
      assetId: assetDetails?._id,
      formData: { assetStatus: "Decommissioned", decommissionedDate: isoFormattedDate },
      loggedUser: user?.userId,
      dispatch,
      Navigate,
      page: 1,
      limit: 10
    });
  };

  const buttons = [
    {
      isActive: checkUserHasPermission({moduleName:'asset',action:'decommission'}),
      buttonMethod: assetDetails?.assetStatus !== "Decommissioned" ? handleDecommission : () => { },
      buttonText:
        assetDetails?.assetStatus === "Decommissioned"
          ? "Restore Asset"
          : assetDetails?.assetStatus === "scheduled"
            ? "Decommission"
            : "Decommission",
    },
  ];


  const getSelectedValue = (value) => {

    setSelectedFilter(value);
  };

  const handleQRCodeView = async () => {
    setShowQRCodeModal(true);
    if (qrCodeDetails === null) {
      const url = `assets/assetId/${assetDetails?._id}/qrcode`;
      try {
        const response = await doGetApiCall(url);
        // const dataUrl = `data:image/png;base64,${Buffer.from(response.data).toString('base64')}`;
        setQrCodeDetails(response?.data?.result.url)
      } catch (err) {
        handleLoginExpiry(err, dispatch);
        if (err?.response?.data.status !== 401) {
          handleShowErrorAndWarning(({ dispatch, type: "error", message: "Failed to fetch QR Code Details!", showTime: "5000" }))
        }
      }
    }
  }


  useEffect(() => {
    //Check if Unity is enabled in the URL
    if ((URL?.unity && URL?.assetId) || (URL?.AR && URL?.assetId) || (URL?.VR && URL?.assetId)) {
      (async () => {
        try {
          //Allow direct access and fetch the asset ID
          // const assetId = await handleAllowDirectAccessPage({ keyName: "assetId" });
          //Get and update the single asset based on the obtained ID
          setIsLoading(true);
          let res = await getSingleAsset(URL?.assetId, optionalParamsForSingleAsset);
          dispatch(assetActions.getSingleAsset(res?.data?.result))
        } catch (err) {
          handleLoginExpiry(err, dispatch);
          if (err?.response?.data?.status !== 401) {
            if (err?.response?.data?.status === 400 || err?.response?.data?.status === 500) {
              handleShowErrorAndWarning({ dispatch, type: "error", message: "Internal Server Error!" })
            } else {
              handleShowErrorAndWarning({ dispatch, type: "error", message: "Failed to Fetch Asset Details!" })
            }
          }
        } finally {
          setIsLoading(false)
        }
      })();
    } else {
      (async () => {
        try {
          setIsLoading(true)
          let res = await getSingleAsset(Location?.state?.assetId, optionalParamsForSingleAsset);
          dispatch(assetActions.getSingleAsset(res?.data?.result))
        } catch (err) {
          handleLoginExpiry(err, dispatch);
          if (err?.response?.data?.status !== 401) {
            if (err?.response?.data?.status === 400 || err?.response?.data?.status === 500) {
              handleShowErrorAndWarning({ dispatch, type: "error", message: "Internal Server Error!" })
            } else {
              handleShowErrorAndWarning({ dispatch, type: "error", message: "Failed to Fetch Asset Details!" })
            }
          }
        } finally {
          setIsLoading(false)
        }
      })()
    }
    updateLayout({ dispatch });
    const encryptedValue = handleEncryptionURLKeys({ needToEncrypt: Location?.state?.assetId })

    return () => {
      dispatch(assetActions.getSingleAsset({}))
    }

  }, []);

  if (checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_READ})) {
    return (
      <>
        {
          // Object?.keys(assetDetails)?.length ?
            <>
              {
                !globalhandlerOutsideRequest() && isLoading ? <div style={{width:"100%",height:"80px",background:"#FFF",padding:'1rem 2rem',display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <ClonosSkeletonLoading variant="rounded" width="20%" height="40px" animation="wave"/>
                  <ClonosSkeletonLoading variant="rounded" width="15%" height="40px" animation="wave"/>
                </div> :<Subbar
                isStatus={true}
                isCreatedOn={assetDetails?.assetStatus === "Decommissioned" ? false : true}
                isDelete={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE})}
                isDeleteMethod={() => setShowDeleteDailog(true)}
                isEdit={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE})}
                isEditMethod={() =>
                  Navigate("/edit-asset", {
                    state: {
                      assetId: assetDetails?._id,
                      activePage: Location?.state?.activePage,
                      limit: Location?.state?.limit,
                    },
                  })
                }
                isHollow={true}
                subbarData={assetDetails}
                buttonText={"Decommission"}
                buttons={buttons}
                htmlElements={[<div onClick={() => handleQRCodeView()}><QRCode /></div>]}
              />
              }
              <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem", height: "100vh" }}>
                <CommonNavigator
                  web={true}
                  values={navigatorValues}
                  getSelectedValue={getSelectedValue}
                />
                {/* //`${mainLayoutChildrenPositions ToolkitState?.pixelUnit?.remainingPart?.height.split("p")[0] - 164}px` */}
                <div className={Styles.v_a_tab_content_wrapper} style={{ height: "90%" }}>  
                  {selectedFilter === "General Details" ? (
                    <ViewAssetGeneralDetails data={assetDetails} isLoading={isLoading}/>
                  ) : (
                    <></>
                  )}
                  {selectedFilter === "3D" ? (
                    <ViewAsset3DDetails data={assetDetails} />
                  ) : (
                    <></>
                  )}
                  {selectedFilter === "History" ? (
                    <ViewAssetHistory data={assetDetails} />
                  ) : (
                    <></>
                  )}
                  {selectedFilter === "Performance Data" ? (
                    <ViewAssetPerformanceData data={assetDetails} />
                  ) : (
                    <></>
                  )}
                  {selectedFilter === "Spares & Inventory" ? (
                    <ViewAssetSparesAndInventory data={assetDetails} />
                  ) : (
                    <></>
                  )}
                  {selectedFilter === "Parameters" ? (
                    <ViewAssetParameters data={assetDetails} />
                  ) : (
                    <></>
                  )}
                  {selectedFilter === "Reference Manuals" ? (
                    <ViewAssetReferenceManuals data={assetDetails} />
                  ) : (
                    <></>
                  )}
                  {selectedFilter === "Documents" ? <ViewAssetDocuments data={assetDetails} /> : <></>}
                  {selectedFilter === "Maintenance Task" ? <ViewMaintenanceTask data={assetDetails} /> : <></>}
                </div>
                {/* </div> */}
              </Card>
              <ClonosConfirmationDialog
                Open={showDeleteDailog}
                CloseDialog={() => {
                  setShowDeleteDailog(false);
                }}
                Title="Delete Asset"
                Content={"Are you sure you want to delete"}
                ProceedDialog={() => {
                  handleDeleteAsset({
                    payload: { assetIds: [assetDetails?._id], updatedBy: user?.userId },
                    activePage: 1,
                    imit: 10,
                    dispatch,
                    setShowDeleteDailog,
                    Navigate,
                  });
                }}
              />
              <QRCodeModal Open={showQRCodeModal} CloseDialog={() => setShowQRCodeModal(false)} assetId={assetDetails?._id} qrCodeDetails={qrCodeDetails} />
            </>
            // :  isLoading ? <div className={Styles.loaderWrapper}><ClonosSpinner /></div> : <div>No Data</div>
        }
      </>
    );
  }
  return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
};

export default ViewAsset;
