export const ViewAssetSparesAndInventory = () => {
    return <></>
}