import { useEffect, useState } from "react"
import { UnderDevelopmentPage } from "../../../components/CommonComponents/UnderDevelopmentPage/UnderDevelopmentPage"
import { getAllScheduledMaintenanceOfAsset } from "../../../Api/ScheduleMaintenance/ScheduleMaintenance"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { commonPageState, getFormatedDate } from "../../../utils/clonosCommon"
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog"
import { Card, Tooltip } from "@mui/material"
import { doGetApiCall } from "../../../utils/ClonosApi"
import useToggler from "../../../CustomHooks/TogglerHook"

export const ViewMaintenanceTask = ({data}) => {
    const [maintenanceTasksList,setMaintenanceTasksList] = useState([]);
    const [showConfirmationDailog,setShowConfirmationDailog] = useState(false);
    const [pagination, setPagination] = useState(commonPageState);
    const [totalCount, setTotalCount] = useState(0);
    const [isLoading, setIsLoading] = useToggler();
    const columns = [ 
          {
            field: "index",
            headerName: "SI.NO",
            width: 100,
            renderCell: (val) => {
              return (
                <p>
                  {val?.row?.index}
                </p>
              );
            },
          },
          {
            field: "maintenancePlanName",
            headerName: "Maintenance Plan Name",
            flex: 1,
            renderCell: (val) => {
              return (
                <Tooltip title={val?.row?.maintenancePlanName}> 
                  <p >
                  {val?.row?.maintenancePlanName || "-"}
                  </p>
                </Tooltip>
              );
            },
          },
          {
            field: "assignee",
            headerName: "Assignee",
            flex: 1,
            renderCell: (val) => {
              return (
                <Tooltip title={val?.row?.assignee?.name}> 
                  <p >
                  {val?.row?.assignee?.name || "-"}
                </p>
                </Tooltip>
                
              );
            },
          },
          {
            field: "priority",
            headerName: "Priority",
            flex: 1,
            renderCell: (val) => {
              return (
                <Tooltip title={val?.row?.priority?.name }> 
                  <p >
                  {val?.row?.priority?.name || "-"}
                </p>
                </Tooltip>
                
              );
            },
          },
          {
            field: "isRecurring",
            headerName: "Frequency",
            flex: 1,
            renderCell: (val) => {
              return (
                <Tooltip title={val?.row?.isRecurring }> 
                  <p>
                    {val?.row?.isRecurring ? "Recurring" : "Not Recurring"}
                  </p>
                </Tooltip>
                
              );
            },
          },
          {
            field: "status",
            headerName: "STATUS",
            flex: 1,
            renderCell: (val) => {
              return (
                <Tooltip title={val?.row?.status }> 
                  <p >
                    {val?.row?.status || "-"}
                  </p>
                </Tooltip>
                
              );
            },
          },
          {
            field: "createdOn",
            headerName: "CREATED ON",
            flex: 1,
            renderCell: (val) => {
              return (
                <Tooltip title={getFormatedDate(val?.row?.createdDate)}>
                  <p >{getFormatedDate(val?.row?.createdDate) || "-"}</p>
                </Tooltip>
              );
            },
          },
          
    ]



    useEffect(() => {
      setIsLoading();
      const url = `/scheduleMaintenance/lists/${data?._id}/`
      doGetApiCall(url, pagination).then((res) => {
          let data = res?.data?.result?.data
            setMaintenanceTasksList(data)
        }).finally (setIsLoading)
    },[data?._id])

    return <> 
        <Card style={{
          flex: 1,
          height:"90%",
          margin:"1rem 1rem 0rem 1rem",
          padding: "1rem",
        }}>
            <ClonosDataGrid isLoading={isLoading} onPageChange={ e => setPagination({ page: e.page + 1, limit: e.pageSize }) } checkboxSelection={false} handleGetSelectedRowsMethod={(val) => {}} rows={maintenanceTasksList?.map((tsk,index) => ({...tsk,index:index+1}))} columns={columns} uniqueIdField={"maintenanceId"}  pageLimit={10} height={600} isEdit={false} isDelete={true} deletePermission="doc003" isDeleteMethod={() => setShowConfirmationDailog(true)}  />
        </Card>
        <ClonosConfirmationDialog open={showConfirmationDailog} CloseDialog={() => setShowConfirmationDailog(false)} Title="Delete Maintenance Task" Content={'Are you sure you want to delete?'} ProceedDialog={() => {}} />
        {/* <UnderDevelopmentPage/> */}
    </>
}
