import { useState } from "react";
import Styles from "../../../ModuleStyles/Assets/viewAsset.module.css";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import { ViewAssetHierarchy } from "./ViewAssetHierarchy";
import {
  getFormatedDate,
  getToken,
  handleLoggedInUser,
  handleLoginExpiry,
  handleShowErrorAndWarning,
} from "../../../utils/clonosCommon";
import NOIMAGE from "../../../assets/images/No_image_available.png";
import { useEffect } from "react";
import { editAsset, getAssetHierarchy, getSingleAsset } from "../../../Api/Asset/assetApi";
import { useDispatch } from "react-redux";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import { CircularProgress, Tooltip } from "@material-ui/core";
import { ImagePreviewModal } from "../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal";
import { useNavigate } from "react-router-dom";
import configs from "../../../config";
import { ImmediateParentChildAssetTree } from "../ImidiateParentChildAssetTree/ImmediateParentChildAssetTree";
import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
import { optionalParamsForSingleAsset } from "../../../utils/AssetsMethods/constants";
import useToggler from "../../../CustomHooks/TogglerHook";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

const skeletonFieldsDimensions = {height:"1.5rem",width:"300px"}
export const ViewAssetGeneralDetails = ({ data,isLoading }) => {
  const [genDetailsLoading,setGenDetailsLoading] = useToggler();
  const [assetGeneralDetails, setAssetGeneralDetails] = useState({ ...data });
  const [showHierarchyModal, setShowHierarchyModal] = useState(false);
  const [showImagePreviewModal, setShowImagePreviewModal] = useState(false);
  const dispatch = useDispatch();
  const [activeImage,setActiveImage] = useState(0)
  const handleViewTermsAndCondition = ({ documentId, type }) => {
    const token = getToken();
    if (type === "png" || type === "jpg" || type === "jpeg") {
    } else {
      window.open(
        `${configs.url}/?atcId=${documentId}&token=${token}`
      );
    }
  };

  const handleImagePreview = (activeImageIndex) => {
    setActiveImage(activeImageIndex);
    setShowImagePreviewModal(true);
  } 


  const handleDeleteAssetImage = async (image) => {
    try {
        let assetImagesToDelete = [image?.imageId];
        if(!image?.assetId){
            handleShowErrorAndWarning({dispatch,type:"error",message:"No asset id present!"})
        } else if(!image?.imageId){
            handleShowErrorAndWarning({dispatch,type:"error",message:"No image id present!"})
        } else if(image?.imageId && image?.assetId){
            const formData = new FormData();
            formData.append('assetId',image?.assetId)
            formData.append('assetImagesToDelete',JSON.stringify(assetImagesToDelete))
            let response = await editAsset(formData);
            if(response?.data?.status === 200){
                handleShowErrorAndWarning({dispatch,type:"success",message:"Image deleted successfully."});
                updatedAssetImages(image);
                setShowImagePreviewModal(false)
            }
        }
    } catch (error) {
        handleLoggedInUser(error,dispatch);
        if(error?.response?.data?.status !== 401){
            handleShowErrorAndWarning({dispatch,type:"error",message:"Failed to Delete Image."})
        }
    }
}

const updatedAssetImages = async (image) => {
    try {
      let res = await getSingleAsset(image?.assetId, optionalParamsForSingleAsset);
      dispatch(assetActions.getSingleAsset(res?.data?.result))
    } catch (err) {
      handleLoginExpiry(err,dispatch);
      if(err?.response?.data?.status !== 401) {
        if(err?.response?.data?.status === 400 || err?.response?.data?.status === 500){
          handleShowErrorAndWarning({dispatch,type:"error",message:"Internal Server Error!"})
        } else {
          handleShowErrorAndWarning({dispatch,type:"error",message:"Failed to Fetch updated Details!"})
        }
      }
    } 
  }


  useEffect(() => {
    setAssetGeneralDetails({ ...data });
  }, [data]);
  
  return (
    <>
      <div className={Styles.view_ast_details_container}>
        <div className={Styles.view_ast_details_leftcontainer}>
          <div className={Styles.view_ast_general_details}>
            {isLoading ? <ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /> : <h4 className={Styles.detail_header}>General Details</h4>}
            <div className={Styles.details_listbox}>
              <div>
                { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Asset Name</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetName || "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Asset Number</h4>}
              {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetNumber || "-"}
                </h4>} 
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Asset Description</h4>}
              {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetDescription || "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Asset Mode</h4>}
              {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetMode?.dropdownValues ||
                    "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Running Mode</h4>}
              {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.runningMode?.dropdownValues ||
                    "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Department</h4>}
              {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetDepartment?.dropdownValues ||
                    "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Criticality Level</h4>}
              {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.criticalityLevel?.dropdownValues ||
                    "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Asset Owner</h4>}
              {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetOwner?.name ||
                    "-"}
                </h4>}
              </div>
              <div>
                { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Census Number</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.censusNumber || "-"}
                </h4>}
              </div>
            </div>
          </div>
          <div className={Styles.view_ast_general_details}>
            { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.detail_header}>Specifications</h4>}
            
            <div className={Styles.details_listbox}>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Asset Make</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetMake || "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Asset Model</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.assetModel || "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Serial Number</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.serialNumber || "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Manufacturer</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.manufacturer || "-"}
                </h4>} 
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Installation Date</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.installationDate
                    ? getFormatedDate(assetGeneralDetails?.installationDate)
                    : "-"}
                </h4>}    
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Service Liquid</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.serviceLiquid || "-"}
                </h4>}
              </div>
            </div>
          </div>
          <div className={Styles.view_ast_general_details}>
          { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.detail_header}>Hazardous Area Details</h4>}
            <div className={Styles.details_listbox}>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Zone Classification</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.hazardousAreaDetails?.zoneClassification || "-"}
                </h4>}
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Gas Group</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.hazardousAreaDetails?.gasGroup || "-"}
                </h4>}  
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Temperature Classification</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.hazardousAreaDetails?.temperatureClassification ||
                    "-"}
                </h4>}  
              </div>
            </div>
          </div>
          <div className={Styles.view_ast_general_details}>
          { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.detail_header}>Warranty Details</h4>}
            <div className={Styles.details_listbox}>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Supplier Name</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.supplierName || "-"}
                </h4>}  
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Email Id</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {assetGeneralDetails?.supplierEmail || "-"}
                </h4>} 
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Warranty Period</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {`${assetGeneralDetails?.warrantyPeriodNumber} ${assetGeneralDetails?.warrantyPeriodDurr}` || "-"}
                </h4>}    
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Warranty End Date</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {getFormatedDate(assetGeneralDetails?.warrantyEndDate) || "-"}
                </h4>}  
              </div>
              <div>
              { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Terms & Conditions</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                  {
                    assetGeneralDetails?.assetTermsAndConditions?.length > 0 ? <p
                    onClick={() =>
                      handleViewTermsAndCondition({
                        documentId:assetGeneralDetails?.assetTermsAndConditions[0]
                          ?.termsAndConditionsId,
                        type:assetGeneralDetails?.assetTermsAndConditions[0]
                          ?.termsAndConditionsType
                      })
                    }
                    className={Styles.linkText}
                  >
                    View Document
                  </p> : "-"
                  }
                </h4>}
              </div>
            </div>
          </div>
        </div>
        <div className={Styles.view_ast_details_rightcontainer}>
          <div className={Styles.astImageContainer}>
          {isLoading ? <ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /> : <h4 className={Styles.detail_header}>Asset Image</h4>}
            <div onClick={() =>  assetGeneralDetails?.assetImages?.length && handleImagePreview(0)} className={Styles.thumbnailHolder}>
              {
                isLoading ? <div><ClonosSkeletonLoading variant="rounded" width="100%"  height="350px" animation="wave" /></div> : <img
                src={
                  assetGeneralDetails?.assetImages?.length > 0
                    ? assetGeneralDetails?.assetImages[0]?.imageUrl
                    : NOIMAGE
                }
              />
              }
            </div>
            <div className={Styles.imgListContainer}>
              {assetGeneralDetails?.assetImages?.length > 1 && (
                <div  className={Styles.imgItemBox}>
                  <div onClick={() => handleImagePreview(1)}className={Styles.imgHolder}>
                    {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width="120px"  height="120px" animation="wave" /></div>  : <img
                      src={
                        assetGeneralDetails?.assetImages?.length > 1
                          ? assetGeneralDetails?.assetImages[1]?.imageUrl
                          : NOIMAGE
                      }
                    />}
                  </div>
                  <Tooltip
                    title={`${assetGeneralDetails?.assetImages[1]?.imageName}.${assetGeneralDetails?.assetImages[1]?.imageType}`}
                  >
                    {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width="120px"  height="20px" animation="wave" /></div> : <p>
                      {assetGeneralDetails?.assetImages[1]?.imageName}.
                      {assetGeneralDetails?.assetImages[1]?.imageType}
                    </p>}
                    
                  </Tooltip>
                </div>
              )}
              {assetGeneralDetails?.assetImages?.length > 2 && (
                <div className={Styles.imgItemBox}>
                  <div onClick={() => handleImagePreview(2)} className={Styles.imgHolder}>
                    {
                      isLoading ? <div><ClonosSkeletonLoading variant="rounded" width="120px"  height="120px" animation="wave" /></div> : <img
                      src={
                        assetGeneralDetails?.assetImages?.length > 2
                          ? assetGeneralDetails?.assetImages[2]?.imageUrl
                          : NOIMAGE
                      }
                    />
                    }
                  </div>
                  <Tooltip
                    title={`${assetGeneralDetails?.assetImages[2]?.imageName}.${assetGeneralDetails?.assetImages[2]?.imageType}`}
                  >
                    {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width="120px"  height="20px" animation="wave" /></div> : <p>
                      {assetGeneralDetails?.assetImages[2]?.imageName}.
                      {assetGeneralDetails?.assetImages[2]?.imageType}
                    </p>}
                  </Tooltip>
                </div>
              )}
              {assetGeneralDetails?.assetImages?.length > 3 && (
                <div className={Styles.imgItemBox}>
                  <div
                    style={{
                      height: "120px",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <p
                      onClick={() => handleImagePreview(0)}
                      className={Styles.linkText}
                    >
                      View All
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className={Styles.view_location_details_container}>
          { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.detail_header}>Location Details</h4> }
            <div className={Styles.view_location_subcontainer}>
              <div className={Styles.details_listbox}>
                <div>
                { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"200px"}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Location</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"100px"}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                    {assetGeneralDetails?.location?.name_of_city ||
                      "-"}
                  </h4>}  
                </div>
                { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={skeletonFieldsDimensions?.width}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.detail_header}>Geographical Coordinates</h4>}
                <div>
                { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"200px"}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Latitude</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"100px"}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                    {assetGeneralDetails?.geoLocation?.latitude ||
                      "-"}
                  </h4>}   
                </div>
                <div>
                { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"200px"}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Longitude</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"100px"}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :  <h4 className={Styles.details_listitem_value}>
                    {assetGeneralDetails?.geoLocation?.longitude ||
                      "-"}
                  </h4>}
                </div>
                <div>
                { isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"200px"}  height={skeletonFieldsDimensions?.height} animation="wave" /></div> :<h4 className={Styles.details_listitem_field}>Elevation</h4>}
                {isLoading ? <div><ClonosSkeletonLoading variant="rounded" width={"100px"}   height={skeletonFieldsDimensions?.height} animation="wave" /></div> : <h4 className={Styles.details_listitem_value}>
                    {assetGeneralDetails?.geoLocation?.elevation ||
                      "-"}
                  </h4>}  
                </div>
              </div>
            </div>
          </div>
          {
            isLoading ?  <div style={{width:"100%"}}><ClonosSkeletonLoading variant="rounded" width={"100%"}  height={"200px"} animation="wave" /></div>
            : <div className={Styles.view_hierarchy_container}>
            <h4 className={Styles.detail_header}>Hierarchy</h4>
            <div className={Styles.astTreeContainer}>
              <div>
                <ImmediateParentChildAssetTree
                  assetGeneralDetails={assetGeneralDetails}
                  dispatch={dispatch}
                />
              </div>
              {assetGeneralDetails?.parentAsset?._id && (
                <p
                  onClick={() => setShowHierarchyModal(true)}
                  className={Styles.linkText}
                >
                  View Full Hierarchy
                </p>
              )}
            </div>
          </div>
          }
        </div>
      </div>
      {showHierarchyModal ? (
        <Modal
          isOpen={showHierarchyModal}
          closeModalMethod={() => setShowHierarchyModal(false)}
        >
          <ViewAssetHierarchy
            OnClose={() => setShowHierarchyModal(false)}
            selectedAsset={{
              assetName: data?.assetName,
              assetNumber: data?.assetNumber,
              assetId: data?._id,
            }}
          />
        </Modal>
      ) : (
        <></>
      )}
      <ImagePreviewModal
        activeImageIndex={activeImage}
        open={showImagePreviewModal}
        closeModalMethod={setShowImagePreviewModal}
        images={assetGeneralDetails?.assetImages}
        deleteMethod={handleDeleteAssetImage}
      />
    </>
  );
};
