import { useEffect, useState } from "react"
import { AlertRedFilledCircleIcon } from "../../../../assets/AssetsSVGComponents/AlertRedFilledCircleIcon"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { WarningIcon } from "../../../../assets/Clonos Common Indicators/Icon_Components/WarningIcon"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "./CompleteAssetAlert.module.css"
export const CompleteAssetAlert = ({isOpen,closeMethod,asset}) => {
    const [assetDetails,setAssetDetails] = useState({})
    const modules = [{title:"Add Required Documents",status:!asset?.isAssetDocumentsPresent},{title:"Add 3D Details",status:asset?.isAsset3DDetailsPresent},{title:"Add Parameters",status:!asset?.isAssetParametersPresent},{title:"Add ReferenceManuals",status:asset?.isAssetReferenceManualsPresent}]

    useEffect(() => {
        setAssetDetails(asset);

        return () => {
            setAssetDetails({})
        }
    },[asset])
    
    return <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
            <div className={Styles.alert_container}>
                    <div className={Styles.alert_header}>
                            <WarningIcon/>
                        <h4>Complete Asset Registration</h4>
                    </div>
                    <div className={Styles.alert_section}>
                        <div className={Styles.alert_module_wrapper}>
                            {
                                modules?.map((module) => {
                                    return module?.status ? <div >
                                        <AlertRedFilledCircleIcon/>
                                        <h4>{module?.title}</h4>
                                    </div> : <></>
                                })
                            }
                        </div>
                        <div className={Styles.btn_wrapper}>
                            <ClonosButton onClick={() => closeMethod(false)} style={{border:"1px solid #E0606A",color:"#E0606A",padding:"1rem 2rem"}}>Cancel</ClonosButton>
                            <ClonosButton style={{padding:"1rem 2rem"}} variant="filled">Edit Asset</ClonosButton>
                        </div>
                    </div>
                    <div className={Styles.alert_close}>
                        <CloseIcon onClick={() => closeMethod(false)}/>
                    </div>
            </div>
    </Modal>
}
