import { memo } from "react";
import Styles from "../../../ModuleStyles/Assets/assetParameters.module.css";
import { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { useEffect } from "react";
import PARAMETER_CREATION_REMOVEROW from "../../../assets/UIUX/icons/Checklist/circle-minus.svg";
import { handleShowErrorAndWarning, restrictSpecialCharacters } from "../../../utils/clonosCommon";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import { useDispatch } from "react-redux";

const EditAssetParameters = ({
  getData,
  data,
  getChangedValues,
  changedData,
}) => {

  const [assetParameters, setAssetParameters] = useState([]);
  const [assetParametersToDelete, setAssetParametersToDelete] = useState([]);
  const dispatch = useDispatch();

  const handleGetValues = (val, parameterId) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = val;
    if(type === "text"){
        setAssetParameters((prev) => {
            let temp = prev?.map((param) => {

              if(uniqueKey === "name" && param?.name === updatedValue){
                handleShowErrorAndWarning({dispatch,type:"error",message:"Parameter's Name should be unique.",showTime:'10000'})
              }

                if(param?.assetParameterId === parameterId){
                    let tempParam = {
                        ...param,
                        [uniqueKey] : updatedValue
                    }
                    return tempParam
                } else {
                    return param
                }
            })
            getData({...data,assetParameters:temp})
            getChangedValues({...changedData,assetParameters:temp})
            return temp
        })
    }
  };

  
  const handleAddParameter = () => {
    let parameter = {
      assetParameterId: uuidv4(),
      name: "",
      description: "",
      unit: "",
    };
    setAssetParameters((prev) => {
      let temp = [...prev, parameter];
      let tempData = { ...data, assetParameters: temp };
      // getData(tempData)
      return temp;
    });
  };

  const handleRemoveParameter = (param) => {
    setAssetParameters((prev) => {
      let remainingParameters = assetParameters?.filter(
        (prm) => prm?.assetParameterId !== param?.assetParameterId
      );
      if (param?.isActive) {
        getData({ ...data, assetParameters: remainingParameters });
        let assetParametersToDelete =
          changedData?.assetParametersToDelete?.length > 0
            ? [...data?.assetParametersToDelete, param?.assetParameterId]
            : [param?.assetParameterId];
        getChangedValues({
          ...changedData,
          assetParametersToDelete: assetParametersToDelete,
          assetParameters: remainingParameters,
        });
      } else {
        getData({ ...data, assetParameters: remainingParameters });
      }
      return remainingParameters;
    });
  };
  useEffect(() => {
    setAssetParameters(data?.assetParameters || []);
  }, []);
  return (
    <div
      aria-label="container to add parameters"
      className={Styles.ast_prms_contanier}
    >
      <div className={Styles.ast_prms_header}>
        <h4 className={Styles.ast_prms_header_title}>
          Technical Specifications
        </h4>
      </div>
      <div className={Styles.ast_prms_inner_container}>
        <div className={Styles.ast_prms_add_parameters}>
          <div>
            <span>+</span>
            <span onClick={() => handleAddParameter()}>Add Parameter</span>
          </div>
        </div>
        <div className={Styles.ast_prms_list_container}>
          {assetParameters?.map((parameter, index) => {
            return (
              <div
                key={parameter?.assetParameterId}
                className={Styles.ast_prms_single_param}
              >
                <ClonosInput
                  type="text"
                  handleGetValues={(val) =>
                    handleGetValues(val, parameter?.assetParameterId)
                  }
                  value={parameter?.name}
                  uniqueKey="name"
                  isSpecialCharacterAllow={true}
                  onlyAllowTheseSpecialCharacters={["_", "-", "."]}
                  placeholder={`Parameter ${index + 1}`}
                  containerStyle={{ width: "20%" }}
                />
                <ClonosInput
                  type="text"
                  handleGetValues={(val) =>
                    handleGetValues(val, parameter?.assetParameterId)
                  }
                  value={parameter?.description}
                  uniqueKey="description"
                  placeholder="Description"
                  isSpecialCharacterAllow={true}
                  onlyAllowTheseSpecialCharacters={["_", "-", "."]}
                  containerStyle={{ width: "60%" }}
                />
                <ClonosInput
                  type="text"
                  handleGetValues={(val) =>
                    handleGetValues(val, parameter?.assetParameterId)
                  }
                  value={parameter?.unit}
                  uniqueKey="unit"
                  isSpecialCharacterAllow={true}
                  onlyAllowTheseSpecialCharacters={["_", "-", "."]}
                  placeholder="Units"
                  containerStyle={{ width: "10%" }}
                />
                <div onClick={() => handleRemoveParameter(parameter)}>
                  <img src={PARAMETER_CREATION_REMOVEROW} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default memo(EditAssetParameters);
