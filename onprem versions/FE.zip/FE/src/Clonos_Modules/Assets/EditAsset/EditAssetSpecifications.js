import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import {
  handleGetValueFromSelect,
  validateForm,
  validatedFiles,
} from "../../../utils/AssetsMethods/AssetRegister";
import { useState } from "react";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import { useDispatch, useSelector } from "react-redux";
import DeleteIcon from "@material-ui/icons/Delete";
import { getFormatedDate, getUser, getYYYYMMDD_Format } from "../../../utils/clonosCommon";
import DOWNANGLE from "../../../assets/UIUX/icons/chevron-down.svg";
import { useEffect } from "react";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import { ClonosInputWithSelect } from "../../../components/CommonComponents/ClonosInputWithSelect/ClonosInputWithSelect";
export const EditAssetSpecifications = ({ getData, data,getChangedValues,changedData,defaultData,errorhandlerObject }) => {
  const user = getUser();
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({ ...data });
  const [errors, setErrors] = useState({});


  const handleGetUploadedfiles = (val) => {
    if(val?.name === "needToDeleteDocuments"){
      let prevFiles = formData?.assetImages;
      const filesTobeDeleted = val?.selectedOption || [];
      delete formData.assetTermsAndConditions
      let temp = {
        ...formData,
        assetTermsAndConditionsToDelete: filesTobeDeleted,
      };
      let changeIn = {
        ...changedData,
        assetTermsAndConditionsToDelete: filesTobeDeleted,
      };
      getData(temp);
      getChangedValues(changeIn);
    } else {
      let files = val?.files;
      // let temp = {
      //   ...formData,
      //   assetTermsAndConditions: [...files]
      // }
      let changeIn = {
        ...changedData,
        assetTermsAndConditions: [...files]
      };
      // getData(temp)
      getChangedValues(changeIn);
    }
  }

  // TO MANAGE ASSET TYPE VALUE
  const handleChangeRadioButtons = ({ e, label }) => {
    const { name, value, placeholder } = e.target;
    setFormData((prevData) => {
      let temp = {
        ...prevData,
        [name] : value
      }
      let changeIn = {...changedData,[name]:value};
      validateForm({ name, formData: temp, setErrors, label });
      getData(temp);
      getChangedValues(changeIn);
      return temp;
    });
  };
  
  // TO HANDLE WARRANTY IS INCLUDED OR NOT
  const handleChangeWarrantyInclusion = () => {
    setFormData((prev) => {
      let temp = {...prev,isWarrantyIncluded:!prev.isWarrantyIncluded};
      let changeIn = {...changedData,isWarrantyIncluded:!prev.isWarrantyIncluded}
      getData(temp);
      getChangedValues(changeIn);
      return temp
    })
  }

// HELPER FUNCTION TO UPDATE LOCAL & CHANGED STATES VALUES
  const updateLocalAndParentState = ({uniqueKey,value}) => {
    if(uniqueKey === "zoneClassification" || uniqueKey === "gasGroup" || uniqueKey === "temperatureClassification"){
      setFormData((prev) => {
        let hazardousAreaDetails = formData?.hazardousAreaDetails || {};
        hazardousAreaDetails[uniqueKey] = value;
        let temp = {...prev, hazardousAreaDetails}
        let changeIn = {...changedData,hazardousAreaDetails}
        getData(temp);
        getChangedValues(changeIn)
        return temp
      })
    } else {
      setFormData((prev) => {
        let temp = {...prev, [uniqueKey]:value}
        let changeIn = { ...changedData,[uniqueKey]:value}
        getData(temp)
        getChangedValues(changeIn)
        return temp
      })
    }
  }

  // TO CHECK ERROR HANDLING FOR MANDATORY FIELDS
  const handleErrorObjectModifier = ({ uniqueKey, response}) => {
    if (response === null) {
      errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": false } }
      return false
    } else {
      if(uniqueKey === "supplierEmail"){
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
        if(!emailRegex.test(response)){
          errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": false } }
        }
      }
      errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": true } }
      return true
    }
  }

// TO HANDLE CHANGED VALUES 
  const handleGetValues = (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;
    if (type === "dynamicDropdown") {
      handleErrorObjectModifier({ uniqueKey, response: selectedOption, });
      // let value = valueSetter ? {name:selectedOption[0]?.name,id:selectedOption[0]?.id} : null
      updateLocalAndParentState({uniqueKey,value:{name:selectedOption[0]?.name,id:selectedOption[0]?.id}})
      
    }
    else if (type === "select") {
      handleErrorObjectModifier({ uniqueKey, response: updatedValue, });
      // let value =  valueSetter ? {name:updatedValue?.label,id:updatedValue?.value} : null
      updateLocalAndParentState({uniqueKey,value:{name:updatedValue?.label,id:updatedValue?.value}})
    }

    else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email") {
      handleErrorObjectModifier({ uniqueKey, response: updatedValue });
      // let value =  valueSetter ? updatedValue : null
      updateLocalAndParentState({uniqueKey,value:updatedValue})
    } else if(type === "inputWithSelect"){
      updateLocalAndParentState({uniqueKey,value:updatedValue})
    }
  };

  // TO GET INFORMATION OF COMPONENT HAVING VALUE OR NOT, TO HANDLE ERRORS
  const handleGetErrorActivatorInformation = (props) => {
    errorhandlerObject = { ...errorhandlerObject, [props.uniqueKey]: props }
  }


  // TO WARRANTY END DATE DYNAMICALLY BASED ON INSTALLATION DATE
  useEffect(() => {
    if (formData?.warrantyPeriodNumber && formData?.warrantyPeriodDurr && formData?.installationDate) {
      let months = 0;
      if (formData?.warrantyPeriodDurr?.name === "Years") {
        months = formData?.warrantyPeriodNumber * 12;
      } else {
        months = formData?.warrantyPeriodNumber;
      }
      let installationDate = formData?.installationDate;
      let date = new Date(installationDate);
      date.setMonth(date.getMonth() + Number(months));
      let updatedDate = date?.toISOString().slice(0, 10);
      setFormData((prev) => {
        let temp = {...prev,warrantyEndDate: updatedDate, defaultWarrantyEndDate: updatedDate,};
        validateForm(temp, setErrors);
        getData(temp);
        return temp;
      });
    }
  }, [formData?.warrantyPeriodDurr,formData?.warrantyPeriodNumber,formData?.installationDate,]);

  return (
    <>
      <div className={Styles.specificationsContainer}>
        <div>
          <div className={Styles.specsDetails_top}>
            <div className={Styles.manufacturingDetailsLeftContainer}>
              <h4>Manufacturing Details</h4>
              <div className={Styles.inputFieldContainer}>
                <label>
                  Asset Type <span style={{ color: "red" }}>*</span>
                </label>
                <div className={Styles.radioContainer}>
                  {/* <label name="assetType"> */}
                  <div>
                    <input
                      checked={formData?.assetType === "aty-001" ? true : false}
                      name="assetType"
                      id="standardAsset"
                      value={"aty-001"}
                      type="radio"
                      onChange={(e) => handleChangeRadioButtons({ e, label: "Asset Type" })}
                    />
                    <label>Standard Asset</label>
                  </div>
                  <div>
                    <input
                      name="assetType"
                      checked={formData?.assetType === "aty-002" ? true : false}
                      id="fabricatedAsset"
                      value={"aty-002"}
                      type="radio"
                      onChange={(e) => handleChangeRadioButtons({ e, label: "Asset Type" })}
                    />
                    <label>Fabricated Asset</label>
                  </div>
                  {/* </label> */}
                </div>
                {errors.assetType && (
                  <span className={Styles.error}>{errors.assetType}</span>
                )}
              </div>
              <div className={Styles.inputFieldContainer}>
              <ClonosInput
                  isLabel={true}
                  label={"Asset Make"}
                  isMandatory={formData?.assetType === "aty-001"}
                  defaultValue={defaultData?.assetMake}
                  value={formData?.assetMake}
                  type="text"
                  placeholder="Asset Make"
                  uniqueKey="assetMake"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Asset Make is Required!."}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
              <ClonosInput
                  isLabel={true}
                  label={"Asset Model"}
                  isMandatory={formData?.assetType === "aty-001"}
                  type="text"
                  value={formData?.assetModel}
                  defaultValue={defaultData?.assetModel}
                  placeholder="Asset Modal"
                  uniqueKey="assetModel"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Asset Model is Required!."}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
              <ClonosInput
                  isLabel={true}
                  label={"Serial Number"}
                  type="text"
                  value={formData?.serialNumber}
                  defaultValue={defaultData?.serialNumber}
                  placeholder="Serial Number"
                  uniqueKey="serialNumber"
                  handleGetValues={handleGetValues}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
              <ClonosInput
                  isLabel={true}
                  label={"Manufacturer"}
                  isMandatory={true}
                  value={formData?.manufacturer}
                  defaultValue={defaultData?.manufacturer}
                  type="text"
                  placeholder="Manufacturer"
                  uniqueKey="manufacturer"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Manufacturer is Required!."}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
              <ClonosInput
                  isLabel={true}
                  label={"Installation Date"}
                  isMandatory={true}
                  defaultValue={getYYYYMMDD_Format(defaultData?.installationDate)}
                  value={formData?.installationDate?.includes("T") ? getYYYYMMDD_Format(formData?.installationDate) : formData?.installationDate}
                  placeholder="Installation Date"
                  uniqueKey="installationDate"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Installation Date is Required!."}
                  type="date"
                  isMinimum={false}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
              <ClonosInput
                  isLabel={true}
                  label={"Service Liquid"}
                  isMandatory={true}
                  type="text"
                  defaultValue={defaultData?.serviceLiquid}
                  value={formData?.serviceLiquid}
                  placeholder="Service Liquid"
                  uniqueKey="serviceLiquid"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Service Liquid is Required!."}
                />
              </div>
              <div className={Styles.areaDetailsContainer}>
                <h4>Hazardous Area Details</h4>
                <div>
                  <div>
                  <ClonosInput
                    isLabel={true}
                    label={"Zone Classification"}
                    isMandatory={true}
                    type="text"
                    defaultValue={defaultData?.hazardousAreaDetails?.zoneClassification}
                    value={formData?.hazardousAreaDetails?.zoneClassification}
                    placeholder="Zone Classification"
                    uniqueKey="zoneClassification"
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Zone Classification is Required!."}
                  />
                  </div>
                  <div>
                  <ClonosInput
                    isLabel={true}
                    label={"Gas Group"}
                    isMandatory={true}
                    type="text"
                    defaultValue={defaultData?.hazardousAreaDetails?.gasGroup}
                    value={formData?.hazardousAreaDetails?.gasGroup}
                    placeholder="Gas Group"
                    uniqueKey="gasGroup"
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Gas Group is Required!."}
                  />
                  </div>
                  <div>
                  <ClonosInput
                      isLabel={true}
                      label={"Temperature Classification"}
                      isMandatory={true}
                      type="text"
                      defaultValue={defaultData?.hazardousAreaDetails?.temperatureClassification}
                      value={formData?.hazardousAreaDetails?.temperatureClassification}
                      placeholder="Temperature Classification"
                      uniqueKey="temperatureClassification"
                      handleGetValues={handleGetValues}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      errorMessage={"Temperature Classification is Required!."}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={Styles.manufacturingDetailsRightContainer}>
                <ClonosInput
                  isLabel={true}
                  label={"Last Calibration Date"}
                  isMandatory={true}
                  defaultValue={getYYYYMMDD_Format(formData?.lastCalibrationDate)}
                  placeholder="Last Calibration Date"
                  uniqueKey="lastCalibrationDate"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Last Calibration Date is Required!."}
                  isMinimum={false}
                  type="date"
                />
                <ClonosInputWithSelect
                  label={"Calibration Cycle"}
                  isLabel={true} 
                  type={"inputWithSelect"}
                  uniqueKey={"calibrationCycle"}
                  isMandatory={true}
                  defaultValue={formData?.calibrationCycle}
                  inputProps={{placeholder:"0",type:"number",}}
                  handleGetValues={handleGetValues}
                  selectProps={{placeholder:"months",data:[{name:"Months",id:"months"},{name:"Years",id:"years"}]}}
                />
                <ClonosInput
                  isLabel={true}
                  label={"Corrosion Check Date"}
                  isMandatory={true}
                  defaultValue={getYYYYMMDD_Format(formData?.corrosionCheckDate)}
                  placeholder="Corrosion Check Date"
                  uniqueKey="corrosionCheckDate"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Corrosion Check Date is Required!."}
                  isMinimum={false}
                  type="date"
                />
                <ClonosInputWithSelect
                label={"Corrosion Cycle"}
                isLabel={true}
                type={"inputWithSelect"}
                uniqueKey={"corrosionCycle"} 
                defaultValue={formData?.corrosionCycle}
                isMandatory={true}
                inputProps={{placeholder:"0",type:"number",}}
                handleGetValues={handleGetValues}
                selectProps={{placeholder:"months",data:[{name:"Months",id:"months"},{name:"Years",id:"years"}]}}
                />
                <div style={{display:'flex',alignItems:'center',gridGap:'1rem'}}>
                  <ClonosInputWithSelect
                  label={"Design Thickness"}
                  isLabel={true}
                  type={"inputWithSelect"}
                  defaultValue={formData?.designThickness}
                  uniqueKey={"designThickness"} 
                  isMandatory={true}
                  inputProps={{placeholder:"0",type:"number",}}
                  handleGetValues={handleGetValues}
                  selectProps={{placeholder:"mm",data:[{name:"Inches",id:"inches"}]}}
                  />
                  <ClonosInputWithSelect
                  label={"Allowable Thickness"}
                  isLabel={true}
                  defaultValue={formData?.allowableThickness}
                  type={"inputWithSelect"}
                  uniqueKey={"allowableThickness"} 
                  isMandatory={true}
                  inputProps={{placeholder:"0",type:"number",}}
                  handleGetValues={handleGetValues}
                  selectProps={{placeholder:"mm",data:[{name:"Inches",id:"inches"}]}}
                  />
                </div>
                <ClonosInput
                  isLabel={true}
                  label={"MTTR"}
                  isMandatory={true}
                  defaultValue={formData?.mttr}
                  placeholder="0"
                  uniqueKey="mttr"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"MTTR is Required!."}
                  type="number"
                />
                <ClonosInput
                  isLabel={true}
                  label={"MTBF"}
                  isMandatory={true}
                  defaultValue={formData?.mtbf}
                  placeholder="0"
                  uniqueKey="mtbf"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"MTBF is Required!."}
                  type="number"
                />
                <ClonosInput
                  isLabel={true}
                  label={"Last Audit Date"}
                  isMandatory={true}
                  defaultValue={getYYYYMMDD_Format(formData?.lastAuditDate)}
                  placeholder="Last Audit Date"
                  uniqueKey="lastAuditDate"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Last Audit Date is Required!."}
                  isMinimum={false}
                  type="date"
                />
            </div>
          </div>
          <div className={Styles.divBraker}></div>
          <div className={Styles.warrantyDetailsContainer}>
            <div className={Styles.warrantyDetailsLeftContainer}>
              <h4>Warranty Details</h4>
              <div className={Styles.warrantyInclusionBox}>
                <input
                  onChange={(e) =>handleChangeWarrantyInclusion(formData)}
                  name="isWarrantyIncluded"
                  type="checkbox"
                  checked={formData?.isWarrantyIncluded}
                />
                <label>Warranty Included</label>
              </div>
              <div className={Styles.warrantySubContainer}>
                <div>
                  <ClonosInput
                    isLabel={true}
                    label={"Supplier Name"}
                    isMandatory={formData?.isWarrantyIncluded}
                    value={formData?.supplierName}
                    defaultValue={defaultData?.supplierName}
                    type="text"
                    placeholder="Supplier Name"
                    uniqueKey="supplierName"
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Supplier Name is Required!."}
                  />
                </div>
                <div>
                  <ClonosInput
                    isLabel={true}
                    label={"Email ID"}
                    isMandatory={formData?.isWarrantyIncluded}
                    value={formData?.supplierEmail}
                    defaultValue={defaultData?.supplierEmail}
                    type="email"
                    placeholder="Email ID"
                    uniqueKey="supplierEmail"
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Email ID is Required!."}
                  />
                </div>
                <div>
                  <div className={Styles.wrntTimeContainer}>
                    <div className={Styles.wrntyPeriod}>
                      <label className={Styles.clonosLabelStyle}>
                        Warranty Period{" "}
                        <span
                          style={{
                            display: formData?.isWarrantyIncluded
                              ? "inline-block"
                              : "none",
                            color: "red",
                          }}
                        >
                          *
                        </span>
                      </label>
                      <div>
                      <ClonosInput
                        isMandatory={formData?.isWarrantyIncluded}
                        value={formData?.warrantyPeriodNumber}
                        defaultValue={defaultData?.warrantyPeriodNumber}
                        // placeholder="Warranty Period"
                        type="number"
                        uniqueKey="warrantyPeriodNumber"
                        handleGetValues={handleGetValues}
							          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        errorMessage={"Required!"}
                        wrapperStyle={{width: "50%", padding: "0.5rem"}}
                      />
                        
                    <ClonosSelect
                      type="select"
                      placeholder="Select"
                      defaultValue={formData?.warrantyPeriodDurr?.name}
                      isMandatory={formData?.isWarrantyIncluded}
                      options={[
                      { label: "Months", value: "months" },
                      { label: "Years", value: "years" },
                      ]?.map((opt) => ({
                      label: opt?.label,
                      value: opt?.value,
                      isNeeded: true,
                      }))}
                      icon={DOWNANGLE}
                      uniqueKey="warrantyPeriodDurr"
                      errorMessage={"Required!"}
                      handleGetValues={handleGetValues}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                         
                      </div>
                    </div>
                    <div className={Styles.wrntyEndDate}>
                      <ClonosInput
                        isLabel={true}
                        label="Warranty End Date"
                        isMandatory={formData?.isWarrantyIncluded}
                        defaultValue={defaultData?.warrantyEndDate}
                        value={formData?.warrantyEndDate}
                        placeholder="Warranty End Date"
                        uniqueKey="warrantyEndDate"
                        handleGetValues={handleGetValues}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        errorMessage={"Warranty End Date is Required!."}
                        type="date"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={Styles.warrantyDetailsRightContainer}>
              <div>
                <FileUploader
                  label={"Terms & Conditions"}
                  title={"assetTermsAndConditions"}
                  typeOfRecord={"File"}
                  isMandatory={false}
                  limit={1}
                  acceptableFileTypes={[".pdf", ".doc", ".xls", ".ppt"]}
                  fileSizeInMB={10}
                  defaultValue={formData?.assetTermsAndConditions}
                  localPreviousPageFiles={changedData?.assetTermsAndConditions}
                  handleGetSelectedData={(value) =>
                    handleGetUploadedfiles(value)
                  }
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
