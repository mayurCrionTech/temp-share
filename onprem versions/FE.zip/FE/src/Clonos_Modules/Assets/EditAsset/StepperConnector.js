import { StepConnector, makeStyles, withStyles } from "@material-ui/core";
import AdjustIcon from '@material-ui/icons/Adjust';
import {clsx} from 'clsx';
import { validGeneralDetails, validLocationDetails, validSpecificationsDetails, validate3DDetails, validateAssetDocuments, validateAssetParametersValue, validateParameterNameUniqueness, validateReferenceManualsValue } from "../../../utils/AssetsMethods/AssetRegister";
import PropTypes from 'prop-types';
import CheckIcon from "@material-ui/icons/Check";
import FiberManualRecordIcon from '@material-ui/icons/FiberManualRecord';
import { useDispatch } from "react-redux";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import { handleStepperActiveStep } from "../../../utils/AssetsMethods/StepperMethods";
export const StepperConnector = withStyles({
    alternativeLabel: {
      top: 22,
    },
    active: {
      '& $line': {
        // backgroundImage:
        //   'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
        // backgroundColor:"#3f51b5"
        border:"1px solid #06337E"
      },
    },
    completed: {
      '& $line': {
        // backgroundImage:
        //   'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
        // backgroundColor:"#3f51b5"
        border:"1px solid #06337E"
      },
    },
    line: {
      height: 3,
      border: 0,
      backgroundColor: '#eaeaf0',
      borderRadius: 1,
    },
  })(StepConnector);
  
  const useStepIconStyles = makeStyles({
    root: {
      backgroundColor: '#ccc',
      zIndex: 1,
      color: '#fff',
      width: 30,
      height: 30,
      display: 'flex',
      borderRadius: '50%',
      justifyContent: 'center',
      alignItems: 'center',
    },
    active: {
      border:"1px solid #06337E",
      color:"#06337E"
    },
    completed: {
      border:"1px solid #06337E",
      color:"#06337E"
    },
  });
  
  export const StepIcon = (props) => {
    const classes = useStepIconStyles();
    const dispatch = useDispatch()
    const { active, completed ,handleSetActiveStep,activeStep,formData,index,changedData} = props;

    const renderIcon = (condition) => condition ? <CheckIcon fontSize="small" /> : <FiberManualRecordIcon fontSize="small" />;
    const icons = {
      1: renderIcon(validGeneralDetails(formData)),
      2: renderIcon(validSpecificationsDetails(formData)),
      3: renderIcon(validLocationDetails(formData)),
      4: renderIcon(activeStep > index || validate3DDetails(formData, changedData)),
      5: renderIcon(activeStep > index || validateAssetDocuments(formData?.documents)),
      6: renderIcon(activeStep > index || (formData?.assetParameters?.length && validateAssetParametersValue(formData) && validateParameterNameUniqueness(formData?.assetParameters))),
      7: renderIcon(activeStep > index || (formData?.referenceManuals && validateReferenceManualsValue(formData))),
      8: renderIcon(activeStep > index)
    };

    const handleActiveStep = (activeStep,index) => {
      handleStepperActiveStep({index,activeStep,dispatch,formData,proceedNext:handleSetActiveStep})
    }
    return (
      <div
        className={clsx(classes.root, {
          [classes.active]: active,
          [classes.completed]: completed,
        })}
        onClick={() => handleActiveStep(activeStep,index)}
      >
        {icons[String(props.icon)]}
      </div>
    );
  }
  
  StepIcon.propTypes = {
    /**
     * Whether this step is active.
     */
    active: PropTypes.bool,
    /**
     * Mark the step as completed. Is passed to child components.
     */
    completed: PropTypes.bool,
    /**
     * The label displayed in the step icon.
     */
    icon: PropTypes.node,
  };