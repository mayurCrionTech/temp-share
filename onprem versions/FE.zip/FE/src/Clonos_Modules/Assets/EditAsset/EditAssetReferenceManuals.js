import { memo, useRef } from "react";
import Styles from "../../../ModuleStyles/Assets/assetReferenceManual.module.css";
import { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { useEffect } from "react";
import REFERENCE_MANUAL_FILE_TEXT from "../../../assets/UIUX/icons/file-text.svg";
import REFERENCE_MANUAL_MP3 from "../../../assets/UIUX/icons/music.svg";
import REFERENCE_MANUAL_MP4 from "../../../assets/UIUX/icons/movie.svg";

import REFERENCE_MANUAL_RED_TRASH from "../../../assets/UIUX/icons/redTrash.svg";
import { Accordion, AccordionDetails, AccordionSummary } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import REFERENCE_MANUAL_PAPER_CLIP from "../../../assets/UIUX/icons/paperclip.svg";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { handleShowErrorAndWarning, restrictSpecialCharacters } from "../../../utils/clonosCommon";
import REFERENCE_MANUAL_CREATION_REMOVEROW from "../../../assets/UIUX/icons/Checklist/circle-minus.svg";
import { Tooltip } from "@material-ui/core";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import { useDispatch } from "react-redux";
import REFERENCE_MANUAL_PENCIL from "../../../assets/UIUX/icons/Checklist/pencil.svg";
import REFERENCE_MANUAL_CHECK from "../../../assets/UIUX/icons/check-icon.svg";

const EditAssetReferenceManuals = ({getData,data,getChangedValues,changedData}) => {
  const [instructionsDocument, setInstructionsDocument] = useState({});
  const [instructionDocumentName,setInstructionsDocumentName] = useState("")
  const [showDocumentNameModal,setShowDocumentNameModal] = useState(false);
  const insDocumentNameRef = useRef(null) 
  const [error,setError] = useState(false);
  const [showRefDocNameInput,setShowRefDocNameInput] = useState(false);
  const [editedData,setEditedData] = useState({})
  const dispatch = useDispatch()

  const handleGetValues = (val, instructionId, docId) => {
    const {type,uniqueKey,updatedValue} = val;
    if(type === "text"){
      if(uniqueKey === "instruction"){
        setInstructionsDocument((prev) => {
          if(prev?.id?.includes("rfm")){         // To Check, it should be created ot eddited 
            if(!changedData?.referenceManualId) changedData.referenceManualId = docId
            let tempInstructions = prev?.instructions?.map((inst) => {
            if(inst?._id === instructionId){
                let changedInstructions = changedData?.instructions || {};
                if(changedInstructions[`${instructionId}`]){
                  changedInstructions[`${instructionId}`] = {...changedInstructions[`${instructionId}`],instruction:updatedValue,isTitleChanged:true}
                } else {
                  changedInstructions[`${instructionId}`] = {...inst,instruction:updatedValue,isTitleChanged:true}
                }
                getChangedValues({...changedData,instructions:changedInstructions})
              return { ...inst, instruction:updatedValue }
            } else { return inst}
          })
          return {...prev,instructions:tempInstructions}
        } else {
          let tempInstructions = prev?.instructions?.map((inst) => {
            if(inst?._id === instructionId){
              return { ...inst, instruction:updatedValue }
            } else { return inst}
          })
          let tempInsDoc = {...prev,instructions:tempInstructions};
          getData({...data,referenceManuals:tempInsDoc});
          getChangedValues({...changedData,referenceManualsToCreate:tempInsDoc});
          return tempInsDoc
        }
        })
      } 
    }
  };  


  const handleAddInstructionDocument = () => {
    if(!instructionDocumentName){
      setError(true)
    } else {
      let document = {
        id: uuidv4(),
        name:instructionDocumentName,
        instructions: [
          {
            _id: uuidv4(),
            instruction: "",
            instructionFile: null,
          },
        ],
      };
      setInstructionsDocument((prev) => {
        let temp = {...data,referenceManuals:document}
        getData(temp);
        getChangedValues({...changedData,referenceManualsToCreate:document})
        return document
      });
      setShowDocumentNameModal(false)
    }
  };

  const handleChangeInstructionDocumentName = (e) => {
    const {name,value} = e.target;
    const specialCharacters = `!"#$%&'()*+,./:;<=>?@[\\]^\`{|}~`;
    const newValue = restrictSpecialCharacters({value,specialCharacters});
    if (newValue) {
      setInstructionsDocumentName(newValue);
      setError(false);
    } else {
      setError(true);
    }
  }

  const handleRemoveInstructionsDocument = (id) => {
    setInstructionsDocument({});
    getData({...data,referenceManuals:{}});
    delete changedData?.name;
    delete changedData?.instructions;
    delete changedData?.instructionsToDelete
    getChangedValues({...changedData,referenceManualToDelete:id,referenceManualId:id})
  }

  const handleAddInstructions = () => {
    setInstructionsDocument((prev) => {
        let temp = {
          ...prev,
          instructions:[...prev?.instructions,{_id: uuidv4(),instruction: "",instructionFile: "",originalName:""}]
      }
        getData({...data,referenceManuals:temp})
        return temp
    })
  }

  const handleRemoveInstruction = (instructionId) => {
    setInstructionsDocument((prev) => {
      if(prev?.id?.includes("rfm")){
            if(!changedData?.referenceManualId) changedData.referenceManualId = prev?.id
            if(changedData?.instructions?.length) delete changedData?.instructions[instructionId];
            prev?.instructions?.map((instruction) => {
              if(instruction?.isActive){
                let instructionsToDelete = changedData?.instructionsToDelete?.length ?  [...changedData?.instructionsToDelete,instructionId] :[instructionId];
                getChangedValues({...changedData,instructionsToDelete})
              }
            })
            let temp = {
              ...prev,
              instructions:prev?.instructions?.filter((instruction) => instruction?._id !== instructionId)
            }
            getData({...data,referenceManuals:temp})
            return temp
      } else {
            let temp = {
              ...prev,
              instructions:prev?.instructions?.filter((instruction) => instruction?._id !== instructionId)
            }
            getData({...data,referenceManuals:{...temp}});
            getChangedValues({...changedData,referenceManualsToCreate:{...temp}})
            return temp
      }
  })
  }

  const handleUploadFile = (e,instructionId) => { 
    let file = e.target.files[0];
    const fileSizeInBytes = file.size;
    const fileSizeInMB = fileSizeInBytes/(1024 * 1024);
    const allowedMimeTypes = [
      'audio/*',
      'video/*',
      'image/png',
      'image/jpeg',
      'audio/wav',
      'audio/mpeg',  // for .mp3
      'video/quicktime',  // for .mov
    ];

    const isValidFileType = allowedMimeTypes.some((type) => file.type === type || file.type.startsWith(type.split('/')[0]));
    if(fileSizeInMB <= 20){
      if(isValidFileType){
        setInstructionsDocument((prev) => {
          if(prev?.id?.includes("rfm")){         // TO CHECK IT SHOULD BE CREATED OR EDITED
            if(changedData && !changedData?.referenceManualId) changedData.referenceManualId = prev?.id
            let tempInstructions = prev?.instructions?.map((inst) => {
              if(inst?._id === instructionId){
                  let changedInstructions = changedData?.instructions || {};
                  if(changedInstructions[`${instructionId}`]){
                    changedInstructions[`${instructionId}`] = {...changedInstructions[`${instructionId}`],instructionFile:file,originalName:file?.name,isFileChanged:true}
                  } else {
                    changedInstructions[`${instructionId}`] = {...inst,instructionFile:file,originalName:file?.name,isFileChanged:true}
                  }
                  getChangedValues({...changedData,instructions:changedInstructions})
                return {
                  ...inst,
                  instructionFile:file,
                  originalName:file?.name
                }
              } else {
                return inst
              }
            })
            return {
              ...prev,
              instructions:tempInstructions
            }
        } else {
          let tempInstructions = prev?.instructions?.map((inst) => {
            if(inst?._id === instructionId){
              return {...inst,instructionFile:file,originalName:file?.name}
            } else {
              return inst
            }
          })
          let tempInsDoc = {...prev,instructions:tempInstructions}
          getChangedValues({...changedData,referenceManualsToCreate : tempInsDoc})
          return tempInsDoc
        }
        })
      } else {
        handleShowErrorAndWarning({
          dispatch,
          type: "error",
          message: "Please upload valid file.",
          showTime: "5000",
        });
      }
    } else {
      handleShowErrorAndWarning({dispatch,type:"error",message:"File size limit exceeded. Max size: 20MB.",showTime:"5000"})
    }
    
  }

  const handleRemoveUploadedFile = (instructionId,docId) => {
    setInstructionsDocument((prev) => {
      let tempInstructions = prev?.instructions?.map((instruction) => {
        if(instruction?._id === instructionId){
          if(instructionId.slice(0,3) === "rfi"){
            let changedInstructions = changedData?.instructions || {};
              if(changedInstructions[`${instructionId}`]){
                changedInstructions[`${instructionId}`] = {...changedInstructions[`${instructionId}`],isFileToBeDeleted:true,isFileChanged:true}
              } else {
                changedInstructions[`${instructionId}`] = {...instruction,isFileToBeDeleted:true}
              }
              getChangedValues({...changedData,instructions:changedInstructions,referenceManualId:docId})
          }
          return {...instruction,instructionFile:null, originalName:null}
        } else {
          return instruction
        }
      })
      let temp = {
        ...prev,
        instructions:tempInstructions
      }
      getData({...data,referenceManuals:temp})
      return temp
    })
  }

  const handleSaveInsDocumentName = (e) => {
    e.stopPropagation();
    const insDocName = insDocumentNameRef.current.value;
    setInstructionsDocument((prev) => {
      let temp = {...data?.referenceManuals,name:insDocName}
      getData({...data,referenceManuals:temp});
      getChangedValues({...changedData,name:insDocName,referenceManualId:prev?.id})
      return temp
    });
    setShowRefDocNameInput(false)
  }


  useEffect(() => {
    setInstructionsDocument(data?.referenceManuals || {})
  },[])

  return (
    <>
    <div
      aria-label="container to add reference manual"
      className={Styles.ast_rfml_contanier}
    >
      <div className={Styles.ast_rfml_header}>
        <h4 className={Styles.ast_rfml_header_title}>Instructions</h4>
      </div>
      <div className={Styles.ast_rfml_inner_container}>
        {!instructionsDocument?.id && <div className={Styles.ast_rfml_documents}>
          <div onClick={() => setShowDocumentNameModal(true)}>
            <span>+</span>
            <span >
              Create New Instruction Document
            </span>
          </div>
        </div>}
        <div className={Styles.ast_rfml_doclist_container}>
          {instructionsDocument?.id ?
            // (instructionsDocument?.map((doc) => {
            //   return (
                <div key={instructionsDocument?.id} className={Styles.ast_rfml_singledoc}>
                  <Accordion>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel1a-content"
                      id="panel1a-header"
                    >
                      <div className={Styles.ast_rfml_doc_header}>
                        <div className={Styles.ast_rfml_doc_header_left}>
                          <div>
                            <img src={REFERENCE_MANUAL_FILE_TEXT} />
                          </div>
                          {showRefDocNameInput ? <div className={Styles.ast_rfml_doc_header_left_input}><input ref={insDocumentNameRef} defaultValue={instructionsDocument?.name}/></div> : <Tooltip title={instructionsDocument?.name}><p >{instructionsDocument?.name}</p></Tooltip>}
                        </div>
                        <div className={Styles.ast_rfml_doc_header_right}>
                          <div className={Styles.ast_rfml_doc_header_right_icons_wrapper}>
                            <div onClick={(e) => showRefDocNameInput ? handleSaveInsDocumentName(e) : setShowRefDocNameInput(true)}>
                              <img src={showRefDocNameInput ? REFERENCE_MANUAL_CHECK :  REFERENCE_MANUAL_PENCIL}/>
                            </div>
                            <div onClick={() => handleRemoveInstructionsDocument(instructionsDocument?.id)}>
                              <img src={REFERENCE_MANUAL_RED_TRASH} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </AccordionSummary>
                    <AccordionDetails>
                      <div className={Styles.ast_rfml_instruction_list}>
                        {instructionsDocument?.instructions?.map((instruction, index) => {
                          return (
                            <div key={instruction?._id} className={Styles.ast_rfml_single_instruction}>
                              <ClonosInput
                                type="text"
                                isMandatory={false}
                                isLabel={false}
                                value={instruction?.instruction}
                                placeholder={`Instruction ${index+1}`}
                                uniqueKey="instruction"
                                handleGetValues={(val) => handleGetValues(val,instruction?._id,instructionsDocument?.id)}
                                containerStyle = {{width:"70%"}}
                                isSpecialCharacterAllow={true}
                                onlyAllowTheseSpecialCharacters={["_","-","."]}
                                // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                              />
                              <div className={Styles.ast_rfml_instruction_remover} onClick={() => handleRemoveInstruction(instruction?._id)}><img src={REFERENCE_MANUAL_CREATION_REMOVEROW}/></div>
                              {
                                instruction?.originalName ? <div className={Styles.ast_rfml_file_preview}>
                                  <div>
                                    <img src={instruction?.originalName?.type?.includes("mp4") ? REFERENCE_MANUAL_MP4 : instruction?.originalName?.type?.includes("mp3") ? REFERENCE_MANUAL_MP3 : ""} />
                                  </div>
                                  <Tooltip title={instruction?.originalName}>
                                  <p className={Styles.ast_rfml_filename_preview}>
                                  {instruction?.originalName}
                                  </p>
                                  </Tooltip>
                                  <div onClick={() => handleRemoveUploadedFile(instruction?._id,instructionsDocument?.id)} className={Styles.ast_rfml_instructionfile_remover}>
                                    <img src={REFERENCE_MANUAL_RED_TRASH}/>
                                  </div>
                                </div> : <div className={Styles.ast_rfml_instructionfile_taker_container}>
                                <label
                                  htmlFor={`instruction-${index + 1}`}
                                  name={`instruction-${index + 1}`}
                                >
                                  <div
                                    className={
                                      Styles.ast_rfml_instructionfile_taker
                                    }
                                  >
                                    <div>
                                      <img src={REFERENCE_MANUAL_PAPER_CLIP} />
                                    </div>
                                    <p className={Styles.ast_rfml_filename_preview}>Attach File</p>
                                    <input
                                      type="file"
                                      accept="audio/*, video/*,.png, .jpg, .jpeg"
                                      name={`instruction-${index + 1}`}
                                      id={`instruction-${index + 1}`}
                                      onChange={(e) => handleUploadFile(e,instruction?._id)}
                                    />
                                  </div>
                                </label>
                              </div>
                              }
                            </div>
                          );
                        })}
                      </div>
                      <div className={Styles.ast_rfml_instruction_controller}>
                        <div  className={Styles.ast_rfml_instruction_controller_btn}>
                          <span>+</span>
                          <span onClick={() => handleAddInstructions({docId:instructionsDocument?.id})}>
                            Add Instruction
                          </span>
                        </div>
                      </div>
                    </AccordionDetails>
                  </Accordion>
                </div>
            //   );
            // }))
          : <h4 style={{ color: "#3f51b5", textAlign: "center" }}>
          Add New Instrunction Document to create.
        </h4>
           }
        </div>
      </div>
    </div>
    <Modal isOpen={showDocumentNameModal} closeModalMethod={setShowDocumentNameModal} stopOverlayCloser={false}>
          <div className={Styles.ast_rfmlmodal_sub_container}>
              <h4>New Document</h4>
              <div>
                <div className={Styles.ast_rfmlmodal_input_controller}>
                  <label>Document Name <span className={Styles.required}>*</span></label>
                  <div>
                    <input onChange={handleChangeInstructionDocumentName} onBlur={() => setError(instructionDocumentName ? false : true)} name="instructionDocumentName" placeholder="Document Name"/>
                  </div>
                  {error && <span className={Styles.required}>Please provide document name!</span>}
                </div>
                <div className={Styles.ast_rfmlmodal_btn_controller}>
                  <ClonosButton onClick={handleAddInstructionDocument}>Create New Document</ClonosButton>
                </div>
              </div>
          </div>
    </Modal>
    </>
  );
};

export default memo(EditAssetReferenceManuals);