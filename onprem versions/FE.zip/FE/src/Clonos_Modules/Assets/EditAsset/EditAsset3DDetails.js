import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { LinkIcon } from "../../../assets/Clonos Common Indicators/Icon_Components/LinkIcon";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import { Plant3DLibraryModal } from "../../Plant3D/Plant3DLibraryModal/Plant3DLibraryModal";
import { AddFrom3DLibraryModal } from "../../Plant3D/components/AddFrom3DLibrary/AddFrom3DLibraryModal";
import { ClonosDropdownButton } from "../../../components/CommonComponents/ClonosDropdownButton/ClonosDropdownButton";
import useToggler from "../../../CustomHooks/TogglerHook";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import { getStandard3DOjectsMethod, getUserUploaded3DOjectsMethod } from "../../../utils/Plant3DMethods/Plant3DMethods";
export const EditAsset3DDetails = ({ getData, data,getChangedValues,changedData,defaultData,errorhandlerObject }) => {
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({ ...data });
  const [pagination,setPagination] = useState({page:1,limit:15})
  const [showPlant3DLibrary,setShowPlant3DLibrary] = useToggler();
  const [showUserUploadedLibraryModal,setShowUserUploadedLibraryModal] = useState(false);
  const [showStandardLibraryModal,setShowStandardLibraryModal] = useState(false);
  const [all3DObjects,setAll3DObjects] = useState({userUploaded:[],standard:[]})
  const AddFrom3DLibraryDropdownList = [
    {id:1,title:"User Uploaded",onClickMethod:() => setShowUserUploadedLibraryModal(true)},
    {id:2,title:"Standard",onClickMethod:() => setShowStandardLibraryModal(true)}
  ]
  const handleGetValues = (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;
    if(type === "text" || type === "number"){
      setFormData((prev) => {
        let asset3DmodelPosition = prev?.asset3DmodelPosition || {};
        let asset3DmodelRotation = prev?.asset3DmodelRotation || {};
        let temp = {};
        let changeIn = {};
        if(uniqueKey === "asset3DmodelPositionX"){
          asset3DmodelPosition.x = updatedValue;
          temp = {...prev,asset3DmodelPosition };
          changeIn = {...changedData,asset3DmodelPosition}
        } else if (uniqueKey === "asset3DmodelPositionY"){
          asset3DmodelPosition.y = updatedValue;
          temp = {...prev,asset3DmodelPosition };
          changeIn = {...changedData,asset3DmodelPosition}
        } else if(uniqueKey === "asset3DmodelPositionZ") {
          asset3DmodelPosition.z = updatedValue;
          temp = {...prev,asset3DmodelPosition };
          changeIn = {...changedData,asset3DmodelPosition}
        } else if(uniqueKey === "asset3DmodelRotationX") {
          asset3DmodelRotation.x = updatedValue;
          temp = {...prev,asset3DmodelRotation };
          changeIn = {...changedData,asset3DmodelRotation}
        } else  if (uniqueKey === "asset3DmodelRotationY") {
          asset3DmodelRotation.y = updatedValue;
          temp = {...prev,asset3DmodelRotation };
          changeIn = {...changedData,asset3DmodelRotation}
        } else if (uniqueKey === "asset3DmodelRotationZ") {
          asset3DmodelRotation.z = updatedValue;
          temp = {...prev,asset3DmodelRotation };
          changeIn = {...changedData,asset3DmodelRotation}
        }
        getData(temp);
        getChangedValues(changeIn)
        return temp
      })
    }
  };

  const getFileFromPlant3DLibrary = (val) => {
    setFormData((prev) => {
      let temp = {...prev,asset3DmodelPosition:val?.position,asset3DmodelRotation:val?.rotation,intractability:val?.intractability?.id,asset3DModel:val?.model?.model3d,assetLayoutImage:val?.model?.model2d};
      let changeIn = {...changedData,asset3DmodelPosition:val?.position,asset3DmodelRotation:val?.rotation,intractability:val?.intractability?.id,asset3DModel:val?.model?.model3d,assetLayoutImage:val?.model?.model2d}
      getData(temp);
      getChangedValues(changeIn)
      return temp
    } )
  }

  const getFileFrom3DLibrary = (val) => {
    setFormData((prev) => {
      let temp = {...prev,asset3DModel:val?.model?.model3d,assetLayoutImage:val?.model?.model2d};
      let changeIn = {...changedData,asset3DModel:val?.model?.model3d,assetLayoutImage:val?.model?.model2d}
      getData(temp)
      getChangedValues(changeIn)
      return temp
    })
    if(val?.name === "User Uploaded") setShowUserUploadedLibraryModal(false) 
    if(val?.name === "Standard") setShowStandardLibraryModal(false)
  }
  
  const handleGetUploadedfile = (val,name) => {
    if(name === "asset3DModel"){
      if(val?.name === "needToDeleteDocuments"){
        let prevFiles = formData?.assetImages;
        delete formData.asset3DModel
        const filesTobeDeleted = val?.selectedOption || [];
        let temp = {...formData,asset3DModelToDelete: filesTobeDeleted};
        let changeIn = {...changedData,asset3DModelToDelete: filesTobeDeleted};
        getData(temp);
        getChangedValues(changeIn);
      } else {
        let files = val?.files;
        let changeIn = {...changedData,asset3DModel: [...files]};
        // getData(temp)
        getChangedValues(changeIn);
      }
    } 
    if(name === "assetlayoutimage"){
      if(val?.name === "needToDeleteDocuments"){
        let prevFiles = formData?.assetImages;
        delete formData.assetLayoutImage
        const filesTobeDeleted = val?.selectedOption || [];
        let temp = {...formData, assetLayoutImageToDelete: filesTobeDeleted};
        let changeIn = {...changedData,assetLayoutImageToDelete: filesTobeDeleted};
        getData(temp);
        getChangedValues(changeIn);
      } else {
        let files = val?.files;
        let changeIn = {...changedData,assetLayoutImage: [...files]};
        // getData(temp)
        getChangedValues(changeIn);
      }
    }
  }

  useEffect(() => {
    const fetchData = async () => {
        const userUploadedRes = await getUserUploaded3DOjectsMethod({dispatch, pagination});
        if (userUploadedRes?.data?.length) {
            setAll3DObjects(prev => ({...prev, userUploaded: userUploadedRes?.data}));
        }

        const standardRes = await getStandard3DOjectsMethod({dispatch, pagination});
        if (standardRes?.data?.length) {
            setAll3DObjects(prev => ({...prev, standard: standardRes?.data}));
        }
    };

    fetchData();
},[]);



  return (
    <>
      <div className={Styles.asset3DDetailsContainer}>
        <div className={Styles.asset3DDetailsLeftContainer}>
          <div className={Styles.btn_wrapper1}>
            <div onClick={() => setShowPlant3DLibrary()}> <span><LinkIcon/></span> Link data from Plant 3D</div>
          </div>
          <div className={Styles.locDetailsContainer}>
              <ClonosSelect
                isLabel={true}
                label="Intractability"
                isMandatory={true}
                placeholder="Select"
              />
              <div>
                <label className={Styles.clonosLabelStyle}>Position</label>
                <div className={Styles.geoLocation}>
                  <ClonosInput
                    type="number"
                    isLabel={true}
                    label={"X"}
                    defaultValue={defaultData?.asset3DmodelPosition?.x}
                    value={formData?.asset3DmodelPosition?.x}
                    placeholder="x"
                    uniqueKey="asset3DmodelPositionX"
                    handleGetValues={handleGetValues}
                  />
                  <ClonosInput
                    type="number"
                    isLabel={true}
                    label={"Y"}
                    defaultValue={defaultData?.asset3DmodelPosition?.y}
                    value={formData?.asset3DmodelPosition?.y}
                    uniqueKey="asset3DmodelPositionY"
                    placeholder="y"
                    handleGetValues={handleGetValues}
                  />
                  <ClonosInput
                    type="number"
                    isLabel={true}
                    label={"Z"}
                    defaultValue={defaultData?.asset3DmodelPosition?.z}
                    value={formData?.asset3DmodelPosition?.z}
                    uniqueKey="asset3DmodelPositionZ"
                    placeholder="z"
                    handleGetValues={handleGetValues}
                  />
                </div>
              </div>
              <div>
                <label className={Styles.clonosLabelStyle}>Rotation (Degree)</label>
                <div className={Styles.geoLocation}>
                  <ClonosInput
                    type="number"
                    isLabel={true}
                    label={"X"}
                    defaultValue={defaultData?.asset3DmodelRotation?.x}
                    value={formData?.asset3DmodelRotation?.x}
                    placeholder="x"
                    uniqueKey="asset3DmodelRotationX"
                    handleGetValues={handleGetValues}
                  />
                  <ClonosInput
                    type="number"
                    isLabel={true}
                    label={"Y"}
                    defaultValue={defaultData?.asset3DmodelRotation?.y}
                    value={formData?.asset3DmodelRotation?.y}
                    uniqueKey="asset3DmodelRotationY"
                    placeholder="y"
                    handleGetValues={handleGetValues}
                  />
                    <ClonosInput
                    type="number"
                    isLabel={true}
                    label={"Z"}
                    defaultValue={defaultData?.asset3DmodelRotation?.z}
                    value={formData?.asset3DmodelRotation?.z}
                    uniqueKey="asset3DmodelRotationZ"
                    placeholder="z"
                    handleGetValues={handleGetValues}
                  />
                </div>
              </div>
          </div>
        </div>
        <div className={Styles.asset3DDetailsRightContainer}>
          <div className={Styles.btn_wrapper2}>
              <ClonosDropdownButton buttonTitle={"+ Add From Library"} dropdownItems={AddFrom3DLibraryDropdownList}/>
          </div>
          <div className={Styles.file_uploader_wrapper}>
          <div>
              <FileUploader defaultValue={ formData?.asset3DModel && [formData?.asset3DModel]} localPreviousPageFiles={changedData?.asset3DModel &&  changedData?.asset3DModel} label={"3D Modal"} title={"asset3DModel"} typeOfRecord={"Image"} isMandatory={false} limit={1} acceptableFileTypes={[".fbx"]} fileSizeInMB={10} handleGetSelectedData={(value) => handleGetUploadedfile(value,"asset3DModel")}/>
            </div>
            <div>
              <FileUploader defaultValue={formData?.assetLayoutImage && [formData?.assetLayoutImage]} localPreviousPageFiles={changedData?.assetLayoutImage && changedData?.assetLayoutImage} label={"Layout Image"} title={"assetLayoutImage"} typeOfRecord={"Image"} isMandatory={false} limit={1} acceptableFileTypes={[".png",".jpg",".jpeg"]} fileSizeInMB={10} handleGetSelectedData={(value) => handleGetUploadedfile(value,"assetlayoutimage")}/>
            </div>
          </div>
            
        </div>
      </div>
      <Plant3DLibraryModal isOpen={showPlant3DLibrary} closeMethod={setShowPlant3DLibrary} getSelectedValue={getFileFromPlant3DLibrary} />
      <AddFrom3DLibraryModal isOpen={showUserUploadedLibraryModal} closeMethod={setShowUserUploadedLibraryModal} getUploadedValue={getFileFrom3DLibrary} data={all3DObjects?.userUploaded} type={'User Uploaded'}/>
      <AddFrom3DLibraryModal isOpen={showStandardLibraryModal} closeMethod={setShowStandardLibraryModal} getUploadedValue={getFileFrom3DLibrary} data={all3DObjects?.standard} type={'Standard'}/>
    </>
  );
};








