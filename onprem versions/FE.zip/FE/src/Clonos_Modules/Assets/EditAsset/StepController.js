import { useSelector } from "react-redux"
import Styles from "../../../ModuleStyles/Assets/stepper.module.css"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
export const StepController = ({handleBack,handleNext,activeStep,steps}) => {
    const {showAssetEditLoading} = useSelector((store) => store.assetData);
    return (
        <>
            <div className={Styles.controller_btn}>
                <div>
                {/* <button disabled={activeStep === 0} onClick={() => handleBack()}>{activeStep === steps?.length -1 ? "Cancel" : "Previous"}</button> */}
                <ClonosButton isDisabled={activeStep === 0} onClick={() => handleBack()}>{activeStep === steps.length - 1 ? "Cancel" : "Previous"}</ClonosButton>
                </div>
                <div>
                {/* <button  onClick={() => handleNext()}>{activeStep === steps.length - 1 ? 'Update' : 'Next'}</button> */}
                <ClonosButton loading={showAssetEditLoading} onClick={() => handleNext()}>{activeStep === steps.length - 1 ? 'Update' : 'Next'}</ClonosButton>
                </div>
            </div>
        </>
    )   
}