import { useState } from "react";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { Card, Tooltip } from "@material-ui/core";
import { UploadDocumentModal } from "../RegisterAsset/UploadDocumentModal";
import ClonosTooltip from "../../../components/CommonComponents/ClonosTooltip/ClonosTooltip";
import { getToken } from "../../../utils/clonosCommon";
import configs from "../../../config";
import { Box } from "@mui/material";
import Styles from "../../../ModuleStyles/Assets/associatedDocs.module.css";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";


const getSelectedRow = (val,setSelectedRow) => {    // USED HERE TO RENDER DOCUMENT DETAILS PROPERLY.
  setSelectedRow({...val})
}


export const EditAssociatedDocuments = ({ getData, data,getChangedValues,changedData,errorhandlerObject }) => {
  const dispatch = useDispatch();
  const [showUploadModal,setShowUploadModal] = useState(false);
  const [rows, setRows] = useState([]);
  const [selectedRow,setSelectedRow] = useState(null)
  const defaultColumns = [
    {
      field: "index",
      headerName: "SI.NO",
      width: 100,
      headerClassName: "asso_doc_text_content",
    },
    {
      field: "documentNumber",
      headerName: "DOCUMENT NUMBER",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell:(val) => {
        return <p >{val?.row?.documentNumber || "-"}</p>
      }
    },
    {
      field: "documentName",
      headerName: "DOCUMENT NAME",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell:(val) => {
        return <p >{val?.row?.documentName || "-"}</p>
      }
    },
    {
      field: "documentType",
      headerName: "DOCUMENT TYPE",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell : (val) => {
        return <p >{val?.row?.documentType?.name || "-"}</p>
      }
    },
    {
      field: "status",
      headerName: "DOCUMENT STATUS",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell : (val) => {
        return <p >{val?.row?.status?.name || "-"}</p>
      }
    },
    {
      field: "revisionNumber",
      headerName: "REVISION NUMBER",
      flex: 1,
      headerClassName:  "asso_doc_text_content",
      renderCell:(val) => {
        return <p >{val?.row?.revisionNumber || "-"}</p>
      }
    },
    {
      field: "viewDoc",
      headerName: "VIEW DOCUMENT",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell : (val) => {
        return <Tooltip title={val?.row?.fileName}>
          <p onClick={() => handleViewDocument(val?.row)} style={{color: val?.row?.fileName ? "#3f51b5" : "#000",textDecoration: val?.row?.fileName ? "underline" : "none",cursor:"pointer"}}>{val?.row?.fileName || "-"}</p>
        </Tooltip>
      }
    },
    {
      field:"action",
      headerName:"ACTION",
      flex:1,
      headerClassName:"asso_doc_text_content",
      renderCell:(val) => <p onClick={() => {
        getSelectedRow({...val.row},setSelectedRow)
        setShowUploadModal(true)
      } } style={{color: val?.row?.fileName ? "#3f51b5" : "#000",textDecoration: val?.row?.fileName ? "underline" : "none",cursor:"pointer"}}>{val?.row?.fileName ? "EDIT" : "UPLOAD"}</p>
    }
  ];


  const getDocumentData = (val) => {

    let documents = [];
    if(val?.isNewAdded){
      let isDocumentPresent = false;
      documents = rows?.length ? rows?.map((doc) => {
        if(doc?.id === val?.id){
          isDocumentPresent = true;
          return val
        } else {
          return doc
        }
      }) : [val]
      if(!isDocumentPresent && rows?.length) documents.push(val)
    } else {
      documents = rows?.map((doc) => {
        if (doc.id === val.id) {
          return val;
        } else {
          return doc;
        }
      });
    }
 
    setRows([...documents]);
    getData({ ...data, documents });
  };

  const getChangedDocuments = (val) => {

    let changedDocuments = changedData?.documents || {};
    changedDocuments[val?.id] = {...val}
    getChangedValues({...changedData,documents:changedDocuments})
  }

  const handleCloseModal = () => {
    setShowUploadModal(false)
  }

  const handleViewDocument = (document) => {
    if(document?.isActive){
      const token = getToken();
      window.open(`${configs.url}/?astDocId=${document?.id}&token=${token}`);
    } else {
      document.file?.name && window.open(URL.createObjectURL(document?.file), '_blank')
    }
  }


  // useEffect(() => {
  //  if(data?._id){
  //   getAssetDocuments(data?._id).then((res) => {
  //     let documents = res?.data?.result?.data;
  //     let documentsMap = {};
  //     documents?.length && documents?.forEach((doc) => {
  //       documentsMap[doc.documentName] = doc
  //     })
  //     getDocumentsListOfAssetCategory(data?.assetCategory?.id).then((response) => {
  //       let assetCategoryDocuments = response?.data?.result?.data || [];
  //       assetCategoryDocuments = assetCategoryDocuments?.map((doc,index) => {
  //       let tempDoc = {};
  //       let chekDocKey = doc?.documentName;
  //       if(documents?.length && documentsMap[chekDocKey]){
  //         const {documentName,documentType,documentNumber,revisionNumber,status,fileName,docId,isDeleted} = documentsMap[doc?.documentName]
  //         tempDoc = {  documentName,
  //           id:docId,
  //           index:index +1,
  //           documentType,
  //           status,
  //           documentNumber,
  //           revisionNumber,
  //           file:null,
  //           fileName,
  //           action:"EDIT",
  //           isActive:true,
  //         }
  //       } else {
  //         tempDoc = {  documentName:doc?.documentName,
  //           id:doc?._id,
  //           index:index +1,
  //           documentType:null,
  //           status:null,
  //           documentNumber:null,
  //           revisionNumber:null,
  //           file:null,
  //           action:"UPLOAD"
  //         }
  //       }
  //         return tempDoc              
  //       })
  //       getData({...data,documents:assetCategoryDocuments})

  //     })
  //   })
  //   .catch((err) => {
  //     handleLoginExpiry(err,dispatch);
  //     if(err?.response?.data?.status !== 401){
  //       handleShowErrorAndWarning({dispatch,message:"Encountered a server error while fetching asset documents.",type:"error",showTime:"5000"})
  //     }
  //   })
  //  }
  // },[data?._id])
  
  useEffect(() => {
    setRows(data?.documents)
  },[data?.documents?.length])


  return (
    <>
      {/* <Card style={{ flex: 1,width:"90%", margin: "auto",height:"100%" }}>
      <div className={Styles.datagridContainer}>
            {
              rows?.length > 0 ? <Box sx={{ height: 650, width: "100%" }}>
                      <ClonosDataGrid checkboxSelection={false}  rows={rows?.map((doc,index) =>({...doc,index:index+1}) )} columns={columns} uniqueIdField={"id"}  pageLimit={10}  />
            </Box> : <div className={Styles.no_data_error_message}>
              <h4>Oops! It seems there are no documents available for selected Asset Category.</h4>
            </div>
            }
          </div>
      </Card>
      <UploadDocumentModal open={showUploadModal} data={selectedRow} closeModalMethod={handleCloseModal} getDocumentData={getDocumentData} getChangedValues={getChangedDocuments} mode={"edit"} errorhandlerObject={errorhandlerObject}/> */}
      <div className={Styles.associatedDocsContainer}>
        <div className={Styles.associatedDocsSubContainer}>
          <div className={Styles.addRowContainer}>
          <ClonosButton onClick={() => setShowUploadModal(true)}>+ Add Document</ClonosButton>
        </div>
          <div className={Styles.datagridContainer}>
              <Box sx={{height:"100%",width: "100%" }}>
              <ClonosDataGrid
                rows={rows?.map((a,i) => ({...a,index:i+1})) || []}
                columns={defaultColumns}
                autoPageSize={true}
                checkboxSelection={false}
                disableRowSelectionOnClick
                uniqueIdField={"id"}
              />
            </Box>
          </div>
        </div>
      </div>
      <UploadDocumentModal
        open={showUploadModal}
        data={selectedRow === null ? {isNewAdded:true} : selectedRow}
        closeModalMethod={handleCloseModal}
        getDocumentData={getDocumentData}
        getData={getData}
        getChangedValues={getChangedDocuments}
        mode={"edit"}
      />
    </>
  );
};
