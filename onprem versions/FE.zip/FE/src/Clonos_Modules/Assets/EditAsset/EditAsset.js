import { ClonosStepperEditAsset } from "./ClonosStepperEditAsset";
import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import { checkUserHasPermission, getUser, handleLoginExpiry, handleShowErrorAndWarning, updateLayout } from "../../../utils/clonosCommon";
import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { getAssetDocuments, getDocumentsListOfAssetCategory, getReferenceManualForAsset, getSingleAsset } from "../../../Api/Asset/assetApi";
import { useDispatch, useSelector } from "react-redux";
import { optionalParamsForSingleAsset } from "../../../utils/AssetsMethods/constants";
import { referenceManualsOptionalParams } from "../../../SharedEnums/ReferencemanualsEnums";
import { Card } from "@material-ui/core";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import { CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_ASSETS } from "../../../Constants/Constant";


 const EditAsset = () => {
  const user = getUser();
  const Location = useLocation();
  const dispatch = useDispatch();
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS)
  const [assetDetails, setAssetDetails] = useState({});
  const [defaultAssetResponse,setDefaultAssetResponse] = useState({})

  const modifyAssetResponse = async () => {
    try {
      let assetDetailsResponse = await getSingleAsset(Location?.state?.assetId, optionalParamsForSingleAsset);
      let temp = { ...assetDetailsResponse?.data?.result };
        const dropDrowns = ["assetMode","runningMode","assetDepartment","criticalityLevel","functionalArea","assetCategory"];
        dropDrowns?.forEach((dropdown) => {
          temp[dropdown] = {...temp[dropdown],["name"]:temp[dropdown]?.dropdownValues,["id"]:temp[dropdown]?.dropdownId}
        })
        temp["location"] = {...temp?.location,name:temp?.location?.name_of_city,id:temp?.location?.locationId}
        if(temp?.warrantyPeriod){
          const [warrantyPeriodNumber,warrantyPeriodDurr] = temp?.warrantyPeriod.split(" ");
          temp.warrantyPeriodNumber = Number(warrantyPeriodNumber);
          temp.warrantyPeriodDurr = warrantyPeriodDurr
        }
        if(temp?.assetImages?.length) {
          temp.assetImages = temp?.assetImages.map((image) => ({...image,docId:image?.imageId})) 
        }
        if(temp?.assetTermsAndConditions?.length){
          temp.assetTermsAndConditions = [{...temp?.assetTermsAndConditions[0],docId:temp?.assetTermsAndConditions[0]?.termsAndConditionsId}]
        }
        if(temp?.asset3DModel?.position){
          let position = temp?.asset3DModel?.position;
          temp.asset3DmodelPosition = position
        }
        if(temp?.assetLayoutImage?.imageId){
          temp.assetLayoutImage = {...temp?.assetLayoutImage,docId:temp?.assetLayoutImage?.imageId}
        }
        if(temp?.asset3DModel?.rotation){
          let rotation = temp?.asset3DModel?.rotation;
          temp.asset3DmodelRotation = rotation
        }  
        if(temp?.asset3DModel?.modelId){
          let tempModel = {...temp.asset3DModel,docId:temp?.asset3DModel?.modelId}
          temp.asset3DModel = tempModel
        }
        if(temp?.isWarrantyIncluded){
          temp.warrantyPeriodDurr = {id:temp?.warrantyPeriodDurr.toLowerCase(),name:temp?.warrantyPeriodDurr}
        }
        if(temp?.parentAsset){
          temp.parentAsset.id = temp?.parentAsset?._id
        }
  
        setAssetDetails({...temp})
        setDefaultAssetResponse({...temp})

        getDocumentsDetails(temp);
        getReferenceManualsDetails();
    } catch (error) {
        handleLoginExpiry(error,dispatch);
        error?.response?.data?.status !== 401 && handleShowErrorAndWarning({dispatch,type:"error",message:"Encountered a server error while fetching Asset  Details.",showTime:"5000"})
    }
  }

  const getDocumentsDetails = async (temp) => {
    try {
        let astDocumentsResponse = await getAssetDocuments(Location?.state?.assetId);
        let documents = astDocumentsResponse?.data?.result?.data;
        let documentsMap = {};
        documents?.length > 0 && documents?.forEach((doc) => {
          if(doc?.documentName ) {
            documentsMap[doc.documentName] = doc
          }
        })  
        
        let astCateGoryDocumentsResponse = await getDocumentsListOfAssetCategory(temp?.assetCategory?.id);
        let assetCategoryDocuments = astCateGoryDocumentsResponse?.data?.result?.data || [];
        assetCategoryDocuments = assetCategoryDocuments?.length ?  assetCategoryDocuments?.map((doc,index) => {
        let tempDoc = {};
        let chekDocKey = doc?.documentName;
        if(documents?.length && documentsMap[chekDocKey]){
          const {documentName,documentType,documentNumber,revisionNumber,status,fileName,docId,isDeleted} = documentsMap[doc?.documentName]
          tempDoc = {  documentName,id:docId,index:index +1,documentType,status,documentNumber,revisionNumber,file:null,fileName,action:"EDIT",isActive:true,}
        } else {
          tempDoc = {  documentName:doc?.documentName,id:doc?._id,index:index +1,documentType:null,status:null,documentNumber:null,revisionNumber:null,file:null,action:"UPLOAD"}
        }
          return tempDoc              
        }) : documents?.map((doc,index) => {
          const {documentName,documentType,documentNumber,revisionNumber,status,fileName,docId,isDeleted} = doc
          let temp = {  documentName,id:docId,index:index +1,documentType,status,documentNumber,revisionNumber,file:null,fileName,action:"EDIT",isActive:true,}
          return temp
        })
        setAssetDetails((prev) => ({...prev,documents:assetCategoryDocuments}))
        setDefaultAssetResponse((prev) => ({...prev,documents:assetCategoryDocuments}))
    } catch (error) {
        handleLoginExpiry(error,dispatch);
        error?.response?.data?.status !== 401 &&  handleShowErrorAndWarning({dispatch,type:"error",message:"Encountered a server error while fetching Documents.",showTime:"5000"})
    }
  }

  const getReferenceManualsDetails = async () => {
    try {
        let referenceManualsResponse = await getReferenceManualForAsset(Location?.state?.assetId,referenceManualsOptionalParams);
        let refsData = referenceManualsResponse?.data?.result?.data;
        setAssetDetails((prev) => ({...prev,referenceManuals:refsData[0]}))
        setDefaultAssetResponse((prev) => ({...prev,referenceManuals:refsData[0]}))
    } catch (error) {
        handleLoginExpiry(error,dispatch);
        error?.response?.data?.status !== 401 && handleShowErrorAndWarning({dispatch,type:"error",message:"Encountered a server error while fetching Reference Manuals.",showTime:"5000"})
    }
  }


  useEffect(() => {
    modifyAssetResponse()
  }, []);

  if (checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE}))

    return <Card variant="outlined" style={{ flex: 1, margin: "1rem", margin: "1rem", overflow: 'scroll' }} bodyStyle={{ height: "100%" }}>
          <div style={{ marginTop: "1rem" }}>
          <ClonosStepperEditAsset
            data={assetDetails}
            defaultData={defaultAssetResponse}
            page={Location?.state?.activePage}
            limit={Location?.state?.limit}
          />
          </div>
        </Card>

  return (<UnAuthorizedModal type={"NOT_AUTHORIZED"}/>);
};

export default EditAsset