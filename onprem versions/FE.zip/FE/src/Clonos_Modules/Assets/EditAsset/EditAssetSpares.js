import { useState } from "react"
import Styles from "../../../ModuleStyles/Assets/assetSparesCreation.module.css"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { UploadSpareModal } from "../../SparesAndInventory/Components/UploadSpareModal/UploadSpareModal"
import { setSerialNumber } from "../../../utils/clonosCommon"
export const EditAssetSpares = ({getData,data}) => {
    const [showSpareModal,setShowSpareModal] = useState(false);
    const [selectedSpare,setSelectedSpare] = useState({})
    const [rows,setRows] = useState([]);
    const [pagination,setPagination] = useState({page:1,limit:4})
    const sparesColumns = [
        {
            field:"index",
            headerName:"SI.NO",
            hideable:false
        }, 
        {
            field:"spareName",
            headerName:"SPARE NAME",
            flex:1,
            renderCell: (param) => {

            }
        },
        {
            field:"quantity",
            headerName:"QUANTITY",
            flex:1,
        },
        {
            field:"replacementFrequency",
            headerName:"REPLACEMENT FREQUENCY",
            flex:1,
            renderCell: (param) => {
                return <p>{param?.row?.replacementFrequency?.countValue}{" "}{param?.row?.replacementFrequency?.dropdownValue?.name}</p>
            }
        },
        {
            field:"cycleFrequency",
            headerName:"CYCLE FREQUENCY",
            flex:1,
            renderCell: (param) => {
                return <p>{param?.row?.cycleFrequency?.countValue}{" "}{param?.row?.cycleFrequency?.dropdownValue?.name}</p>
            }
        },
        {
            field:"edit",
            headerName:"EDIT",
            width:"200",
            renderCell: (param) => {
                return <p onClick={() => {
                    setShowSpareModal(true);
                    setSelectedSpare(param?.row)
                }} style={{color:"#06337E",fontWeight:"600",cursor:"pointer"}}>EDIT</p>
            }
        },

    ]

    const handleGetSpareDetails = (val) => {

        let tempRows = rows?.length ? rows : [val]
        let isSparePresent = false;
        let updatedRows =  tempRows?.map((row) => {
            if(row?.id === val?.id){
                isSparePresent = true;
                return val
            } else {
                return row
            }
        })
        if(!isSparePresent){
            updatedRows.push(val)
        }
        setRows(updatedRows);
        getData({...data,spares:updatedRows})
    }

    return (
      <>
        <div className={Styles.a_c_spares_container}>
          <div className={Styles.a_c_spares_header}>
            <h4>Spares & Inventory</h4>
          </div>
          <div className={Styles.a_c_spares_add_btn}>
            <ClonosButton onClick={() => setShowSpareModal(true)}>+ Add Spare</ClonosButton>
          </div>
          <div className={Styles.a_c_spares_datagrid_wrapper}>
            <ClonosDataGrid
              columns={sparesColumns}
              rows={ rows?.length ? setSerialNumber(rows, pagination?.page, pagination?.limit) : []}
              checkboxSelection={false}
              uniqueIdField={"id"}
              paginationMode={"client"}
              onPageChange={(e) =>setPagination({ page: e.page + 1, limit: e.pageSize }) }
              pageLimit={pagination.limit}
            />
          </div>
        </div>
        {showSpareModal ? (
          <UploadSpareModal isOpen={showSpareModal} closeMethod={setShowSpareModal} getFilledValue={handleGetSpareDetails} selectedSpare={selectedSpare} />
        ) : (
          <></>
        )}
      </>
    );
}