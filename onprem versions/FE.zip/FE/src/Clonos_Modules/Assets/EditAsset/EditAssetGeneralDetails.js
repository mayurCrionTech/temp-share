import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import { LinearProgress } from "@material-ui/core";
import { useEffect, useState, memo } from "react";
import {
  handleGetValueFromSelect,
  handleGetValuesMethod,
  validateForm,
  validatedFiles,
} from "../../../utils/AssetsMethods/AssetRegister";
import { useDispatch } from "react-redux";
import { useRef } from "react";
import DOWNANGLE from "../../../assets/UIUX/icons/chevron-down.svg";
import SEARCHICON from "../../../assets/UIUX/icons/search (1).svg";
import { CustomSelect } from "../../../components/CommonComponents/CustomSelect/CustomSelect";
import { handleGetStaticDropdownValues } from "../../../utils/DropdownsMethods/DropdownsMethods";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import DynamicDropdown from "../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import { handleGetUsersDropdownData } from "../../../utils/WorkOrderMethods/WorkOrderMethods";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosTextarea from "../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
let primaryObject = {};
const EditAssetGeneralDetails = ({
  getData,
  data,
  defaultData,
  getChangedValues,
  changedData,
  errorhandlerObject
}) => {
  const [progress, setProgress] = useState({
    show: false,
    percent: 0,
  });
  const [showUserModal, setShowUserModal] = useState(false);
  const [assetDepartmentDropdwon, setAssetDepartmentDropdown] = useState([]);
  const [functionalAreaDropdown, setFunctionalAreaDropdown] = useState([]);
  const [criticalityLevelDropdown, setCriticalityDropdown] = useState([]);
  const [assetCategoryDropdownDown, setAssetCategoryDropdown] = useState([]);
  const [showCategoryChangeConfirmation,setShowCategoryChangeConfirmation] = useState(false)
  const [assetMode, setAssetMode] = useState([]);
  const [runningMode, setRunningMode] = useState([]);
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({ ...data });
  const fileTypes = ["jpg", "jpeg", "png"];
  const [assetPaginationCurrentPage, setAssetPaginationCurrentPage] =
    useState(1);
  const [usersDropdownData, setUsersDropdownData] = useState([]);

  const handleFieldsError = (err) => {
    if (err.uniqueKey === "assetowner") {
      primaryObject = {
        ...primaryObject,
        [err.uniqueKey]: {
          ...err,
          value: formData["assetOwner"]?.name ? true : false,
        },
      };
    } else {
      primaryObject = {
        ...primaryObject,
        [err.uniqueKey]: {
          ...err,
          value: formData[err.uniqueKey] ? true : false,
        },
      };
    }
  };


  const handleMoreData = ({ isActivator }) => {
    if (isActivator) {
      setAssetPaginationCurrentPage((prev) => {
        let updatedPageCount = prev + 1;
        handleGetUsersDropdownData({
          setUsersDropdownData,
          usersDropdownData,
          assetPaginationCurrentPage: updatedPageCount,
          dispatch,
        });
        return updatedPageCount;
      });
    }
  };

  const handleGetUploadedFiles = (val) => {
    if (val?.name === "needToDeleteDocuments") {
      let prevFiles = formData?.assetImages;
      const filesTobeDeleted = val?.selectedOption || [];
      let newFiles = prevFiles?.filter((file) => {
        return !filesTobeDeleted.includes(file?.imageId);
      });
      let temp = {
        ...formData,
        assetImagesToDelete: filesTobeDeleted,
        assetImages: formData?.assetImages?.filter((file) => {
          return !filesTobeDeleted.includes(file?.imageId);
        }),
      };
      getData(temp);
      let changeIn = {
        ...changedData,
        assetImagesToDelete: filesTobeDeleted,
      };
      getChangedValues(changeIn);
    } else {
      let files = val?.files;
      let changeIn = {
        ...changedData,
        assetImages: [...files],
      };
      getChangedValues(changeIn);
    }
  };

  const handleErrorObjectModifier = ({ uniqueKey, response }) => {
    if (response === null) {
      errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": false } }
      return false
    }
    else {
      errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": true } }
      return true
    }
  }


  const updateLocalAndParentState = ({uniqueKey,value}) => {
    setFormData((prev) => {
      let temp = {
        ...prev, [uniqueKey]:value
      }
      let changeIn = {
        ...changedData,
        [uniqueKey] : value
      }
      getData(temp)
      getChangedValues(changeIn)
      return temp
    })

  }



  const handleGetValues = (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;
    if (type === "dynamicDropdown") {
      handleErrorObjectModifier({ uniqueKey, response: selectedOption });
      updateLocalAndParentState({uniqueKey,value: selectedOption !== null ? {name:selectedOption[0]?.name,id:selectedOption[0]?.id} : null})
    } else if (type === "select") {
      if(uniqueKey === "assetCategory"){
        setShowCategoryChangeConfirmation(true)
      }
      handleErrorObjectModifier({ uniqueKey, response: updatedValue });
      updateLocalAndParentState({uniqueKey,value:{name:updatedValue?.label,id:updatedValue?.value}})
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
      handleErrorObjectModifier({ uniqueKey, response: updatedValue });
      updateLocalAndParentState({uniqueKey,value:updatedValue})
    }
  };

  const handleGetErrorActivatorInformation = (props) => {
    errorhandlerObject = { ...errorhandlerObject, [props.uniqueKey]: props }
  }

  useEffect(() => {
    handleGetUsersDropdownData({
      setUsersDropdownData,
      usersDropdownData,
      dispatch,
    });
    handleGetStaticDropdownValues({
      staticDropdownNameOrId: "AssetMode",
      dispatch,
      setterFunctionForValues: setAssetMode,
    });
    handleGetStaticDropdownValues({
      staticDropdownNameOrId: "RunningMode",
      dispatch,
      setterFunctionForValues: setRunningMode,
    });
    handleGetStaticDropdownValues({
      staticDropdownNameOrId: "FunctionalArea",
      dispatch,
      setterFunctionForValues: setFunctionalAreaDropdown,
    });
    handleGetStaticDropdownValues({
      staticDropdownNameOrId: "AssetDepartment",
      dispatch,
      setterFunctionForValues: setAssetDepartmentDropdown,
    });
    handleGetStaticDropdownValues({
      staticDropdownNameOrId: "CriticalityLevel",
      dispatch,
      setterFunctionForValues: setCriticalityDropdown,
    });
    handleGetStaticDropdownValues({
      staticDropdownNameOrId: "AssetCategory",
      dispatch,
      setterFunctionForValues: setAssetCategoryDropdown,
    });
  }, []);

  useEffect(() => {
    setFormData(data);
  }, [Object.keys(data)?.length]);

  useEffect(() => {
    setFormData({...data})
  }, [Object.keys(data).length]);
  return (
    <>
      <div className={Styles.generalDetailsContainer}>
        <div>
          <div className={Styles.generalDetails_left}>
            <div>
              <ClonosInput
                isLabel={true}
                label={"Asset Name"}
                isMandatory={true}
                defaultValue={defaultData?.assetName}
                value={formData?.assetName}
                placeholder="Asset Name"
                uniqueKey="assetName"
                type="text"
                limit="100"
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                errorMessage={"Asset Name is Required!."}
              />
            </div>
            <div>
              <ClonosInput
                isMandatory={true}
                isLabel={true}
                label={"Asset Number"}
                defaultValue={defaultData?.assetNumber}
                value={formData?.assetNumber}
                placeholder="Asset Number"
                type="text"
                uniqueKey="assetNumber"
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                errorMessage={"Asset Number is Required!."}
              />
            </div>
            <div>
              <ClonosTextarea
                isLabel={true}
                label={"Asset Description"}
                rows="4"
                type="text"
                defaultValue={defaultData?.assetDescription}
                value={formData?.assetDescription}
                placeholder="Asset Description"
                uniqueKey="assetDescription"
                handleGetValues={handleGetValues}
              ></ClonosTextarea>
            </div>
            <div>
              <ClonosSelect
                type="select"
                placeholder="Select"
                label={"Asset Mode"}
                isLabel={true}
                uniqueKey="assetMode"
                defaultValue={formData?.assetMode?.name}
                isMandatory={false}
                options={assetMode?.map((opt) => ({
                  label: opt?.name,
                  value: opt?.id,
                  isNeeded: true,
                }))}
                errorMessage={"Asset Mode is Required!."}
                icon={DOWNANGLE}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                placeholder="Select"
                label={"Running Mode"}
                isLabel={true}
                uniqueKey="runningMode"
                defaultValue={formData?.runningMode?.name}
                isMandatory={false}
                options={runningMode?.map((opt) => ({
                  label: opt?.name,
                  value: opt?.id,
                  isNeeded: true,
                }))}
                errorMessage={"Running Mode is Required!."}
                icon={DOWNANGLE}
                handleGetValues={handleGetValues}
                // handleGetErrorActivatorInformation={(err) => handleFieldsError(err)}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                placeholder="Select"
                label={"Asset Department"}
                isLabel={true}
                uniqueKey="assetDepartment"
                defaultValue={formData?.assetDepartment?.name}
                isMandatory={true}
                options={assetDepartmentDropdwon?.map((opt) => ({
                  label: opt?.name,
                  value: opt?.id,
                  isNeeded: true,
                }))}
                errorMessage={"Asset Department is Required!."}
                icon={DOWNANGLE}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                placeholder="Select"
                label={"Asset Category"}
                isLabel={true}
                uniqueKey="assetCategory"
                defaultValue={formData?.assetCategory?.name}
                isMandatory={true}
                options={assetCategoryDropdownDown?.map((opt) => ({
                  label: opt?.name,
                  value: opt?.id,
                  isNeeded: true,
                  disabled:true
                }))}
                errorMessage={"Asset Category is Required!."}
                icon={DOWNANGLE}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                placeholder="Select"
                label={"Criticality Level"}
                isLabel={true}
                uniqueKey="criticalityLevel"
                defaultValue={formData?.criticalityLevel?.name}
                isMandatory={true}
                errorMessage={"Criticality Level is Required!."}
                options={criticalityLevelDropdown?.map((opt) => ({
                  label: opt?.name,
                  value: opt?.id,
                  isNeeded: true,
                }))}
                icon={DOWNANGLE}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                placeholder="Select"
                label={"Functional Area"}
                isLabel={true}
                uniqueKey="functionalArea"
                defaultValue={formData?.functionalArea?.name}
                isMandatory={true}
                options={functionalAreaDropdown?.map((opt) => ({
                  label: opt?.name,
                  value: opt?.id,
                  isNeeded: true,
                }))}
                icon={DOWNANGLE}
                errorMessage={"Functional Area is Required!."}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <DynamicDropdown
              title="Asset Owner"
              uniqueKey={"assetOwner"}
              labelActivator={"User Name"}
              isOpen={showUserModal}
              isOpenMethod={setShowUserModal}
              heading={"Select from User Library"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={false}
              isUser={true}
              isDynamicLoad={true}
              data={usersDropdownData}
              isActivator={true}
              isMandatory={true}
              url={SEARCHICON}
              defaultValue={
                formData?.assetOwner?.name && [formData?.assetOwner]
              }
              handleMoreData={handleMoreData}
              errorMessage={"Asset Owner is Required!."}
              handleGetValues={handleGetValues}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />
            <div>
            <ClonosInput
                isLabel={true}
                type="text"
                label={"Census Number"}
                defaultValue={defaultData?.censusNumber}
                value={formData?.censusNumber}
                placeholder="Enter Census Number"
                uniqueKey="censusNumber"
                handleGetValues={handleGetValues}
              />
            </div>
          </div>
          <div className={Styles.generalDetails_right}>
            <div>
              <FileUploader
                defaultValue={formData?.assetImages}
                localPreviousPageFiles={changedData?.assetImages || []}
                label={"Asset Image"}
                uniqueKey={"assetImge"}
                typeOfRecord={"images"}
                isMandatory={false}
                limit={10}
                acceptableFileTypes={[".jpg", ".png", ".jpeg"]}
                fileSizeInMB={10}
                handleGetSelectedData={(value) => handleGetUploadedFiles(value)}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditAssetGeneralDetails;