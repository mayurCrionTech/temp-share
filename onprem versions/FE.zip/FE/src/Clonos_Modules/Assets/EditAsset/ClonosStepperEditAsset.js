import {
  Step,
  StepConnector,
  StepLabel,
  Stepper,
  makeStyles,
} from "@material-ui/core";
import { StepIcon } from "./StepperConnector";
import { useEffect, useState } from "react";
import Styles from "../../../ModuleStyles/Assets/stepper.module.css";
import { useDispatch, useSelector } from "react-redux";
import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
import EditAssetGeneralDetails from "./EditAssetGeneralDetails";
import { EditAssetSpecifications } from "./EditAssetSpecifications";
import { EditAssetLocationAndHierarchy } from "./EditAssetLocationAndHierarchy";
import { StepController } from "./StepController";
import { getUser, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import {
  handleEditAsset,
  validGeneralDetails,
  validLocationDetails,
  validSpecificationsDetails,
} from "../../../utils/AssetsMethods/AssetRegister";
import { useNavigate } from "react-router-dom";
import { EditAsset3DDetails } from "./EditAsset3DDetails";
import { EditAssociatedDocuments } from "./EditAssociatedDocuments";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog";
import EditAssetParameters from "./EditAssetParameters";
import EditAssetReferenceManuals from "./EditAssetReferenceManuals";
import { AssetCreationSuccessModal } from "../RegisterAsset/AssetCreationSuccessModal";
import { EditAssetSpares } from "./EditAssetSpares";
import { RenderAssetSteps } from "../Components/RenderAssetSteps";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "50%",
    margin: "auto",
    backgroundColor: "#fafafa",
    marginBottom: "2em",
  },
  button: {
    marginRight: theme.spacing(1),
  },
  instructions: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
}));
export const ClonosStepperEditAsset = ({data,defaultData, page,limit}) => {
 
  const [formData, setFormData] = useState({...data});
  const errorhandlerObject = {};
  const loggedUser = getUser();
  const Navigate = useNavigate();
  const steps = ["General Details", "Specifications", "Location & Hierarchy","3D","Documents","Parameters","Reference Manuals","Spares"];
  const [showAssetCreationSuccessModal, setShowAssetCreationModal] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const dispatch = useDispatch();
  const [changeIN, setChangeIN] = useState({});
  const [updatedAssetResponse, setUpdatedAssetResponse] = useState({});
  const [showConfirmationDailaog,setShowConfirmationDailog] = useState(false)
  const getUpdatedStatusOFAssetEdit = (val) => {
    setShowAssetCreationModal(val);
  };

  const getUpdatedAssetDetails = (res) => {
    setUpdatedAssetResponse(res);
  };

  const showRequiredFieldError = () => {
    dispatch(
      commonActions.handleSnackbar({
        show: true,
        message: `Please fill all the required fields`,
        type: "error",
        closeIn: 2000,
      })
    );
  }
  const handleNext = () => {
    if(activeStep === 0){
      if(validGeneralDetails(formData)){
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        setFormData((prev) => {
          let temp = {...prev,showSpecificationFieldErrors: true,};
          getChildData(temp);
          return temp;
        });
        showRequiredFieldError();
      }
    } else if (activeStep === 1){
      if(validSpecificationsDetails(formData)){
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if(!emailRegex.test(formData?.supplierEmail)){
          handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide valid Email Id!",showTime:"5000"})
        } else {
          showRequiredFieldError();
        }
      }
    } else if (activeStep === 2){
      if(validLocationDetails(formData)){
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        showRequiredFieldError()
      }
    }  else if (activeStep === 3 ){
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else if (activeStep === 4) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else if (activeStep === 5) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else if(activeStep === 6){
      handleEditAsset({assetId:data?._id,formData:changeIN, loggedUser, dispatch, Navigate,page,limit,getUpdatedStatusOFAssetEdit,
        operationType:"updated",
        getUpdatedAssetDetails: (res) => getUpdatedAssetDetails(res)});
    }
  };

  const handleBack = () => {
    if (activeStep === 6) {
      setShowConfirmationDailog(true)
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  const getChildData = (value) => {
    setFormData({ ...value });
  };
  const getChangedValues = (value) => {
    setChangeIN(value);
  };

  useEffect(() => {
    setFormData(data);
  }, [data]);
  return (
    <>
      <div className={Styles.StepperWrapper}>
        <Stepper
          alternativeLabel
          activeStep={activeStep}
          connector={<StepConnector />}
          style={{ background: "none" }}
        >
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel
                StepIconComponent={(props) => (
                  <StepIcon
                    {...props}
                    handleSetActiveStep={() => setActiveStep(index)}
                    activeStep={activeStep}
                    index={index}
                    formData={formData}
                    changedData={changeIN}
                  />
                )}
              >
                {label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </div>
      <RenderAssetSteps
        mode={"edit"}
        step={activeStep}
        formData={formData}
        getChildData={getChildData}
        changeIN={changeIN}
        defaultData={defaultData}
        getChangedValues={getChangedValues}
        errorhandlerObject={errorhandlerObject}
      />
      <StepController
        handleBack={handleBack}
        handleNext={handleNext}
        activeStep={activeStep}
        steps={steps}
      />
      {showAssetCreationSuccessModal && (
        <AssetCreationSuccessModal
          label={"Asset"}
          libraryURL={"assets"}
          state={updatedAssetResponse}
          name={formData?.assetName}
          number={formData?.assetNumber}
          open={showAssetCreationSuccessModal}
          closeModalMethod={setShowAssetCreationModal}
          viewItemURL={`view-asset/${formData?.assetName}`}
        />
      )}
      {
        <ClonosConfirmationDialog
          Title={"Cancel Edit."}
          Open={showConfirmationDailaog}
          ProceedDialog={() => Navigate(-1)}
          Content={"Are you sure you want to cancel ?"}
          CloseDialog={() => setShowConfirmationDailog(false)}
        />
      }
    </>
  );
};