const MANUFACTURING_FIELDS = ["assetType","assetMake","assetModel","serialNumber","manufacturer","installationDate","serviceLiquid"]
const CALIBRATION_FIELDS = ["lastCalibrationDate","calibrationCycle","corrosionCheckDate","corrosionCycle","designThickness","allowableThickness","mttr","mtbf","lastAuditDate"];
const WARRANTY_FIELDS = ["supplierName","emailId","warrantyPeriodNumber","warrantyPeriodDurr","warrantyEndDate"];


export const handleSpeacificationDetailsCatogories = ({setFormData,uniqueKey,value,updateGlobalState,detailsCategory}) => {
    setFormData((prev) => {
        let temp = {...prev,specifications:{...prev?.specifications || {},[detailsCategory]:{...prev?.specifications?.[detailsCategory] || {},[uniqueKey]:value}}};
        updateGlobalState(temp);
        return temp
    })
}




// HELPER FUNCTION TO UPDATE LOCAL & CHANGED STATES VALUES
export const updateLocalAndParentState = ({setFormData,formData,getData,uniqueKey,value}) => {
    let hazardousAreaDetails = formData?.hazardousAreaDetails || {};
    const [mainKey,subKey] = uniqueKey?.split("_");   // To handle the two fields which falling into single main field
    
    if(uniqueKey === "zoneClassification" || uniqueKey === "gasGroup" || uniqueKey === "temperatureClassification"){
      hazardousAreaDetails[uniqueKey] = value;
      setFormData((prev) => {
        let temp = {...prev, specifications:{...prev?.specifications,hazardousAreaDetails}}
        getData(temp)
        return temp
      })
    } else {
      if(MANUFACTURING_FIELDS?.includes(uniqueKey)){
        handleSpeacificationDetailsCatogories({setFormData,uniqueKey,value,updateGlobalState:getData,detailsCategory:"manufacturingDetails"})
      } else if(CALIBRATION_FIELDS?.includes(mainKey)){
        let tempValue = "";
        if(subKey){
        }

        handleSpeacificationDetailsCatogories({setFormData,uniqueKey,value,updateGlobalState:getData,detailsCategory:"calibrationDetails"})
      } else if(WARRANTY_FIELDS?.includes(uniqueKey)){

      }
    } 
  }