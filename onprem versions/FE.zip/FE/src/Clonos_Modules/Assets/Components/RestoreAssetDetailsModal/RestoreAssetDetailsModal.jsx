import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "./restoreAssetDetailsModal.module.css"
export const RestoreAssetDetailsModal = ({isOpen,closeMothod}) => {
    return <Modal isOpen={isOpen} closeModalMethod={closeMothod} stopOverlayCloser={true}>
        <div className={Styles.container}>
            
        </div>
    </Modal>
}