import {useState } from "react";
import { StepIcon } from "./StepperConnector";
import { StepController } from "./StepController";
import { useDispatch, useSelector } from "react-redux";
import { RenderAssetSteps } from "../Components/RenderAssetSteps";
import Styles from "../../../ModuleStyles/Assets/stepper.module.css";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import { AssetCreationSuccessModal } from "./AssetCreationSuccessModal";
import { getUser, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import {Step, StepConnector, StepLabel, Stepper, makeStyles,} from "@material-ui/core";
import { createNewAsset, validGeneralDetails, validLocationDetails, validSpecificationsDetails, validateAssetParametersValue, validateParameterNameUniqueness,} from "../../../utils/AssetsMethods/AssetRegister";


export const ClonosStepper = () => {
  const loggedUser = getUser();
  const errorhandlerObject = {};
  const dispatch = useDispatch();
  const [activeStep, setActiveStep] = useState(0);
  const [createdAssetResponse, setCreatedAssetResponse] = useState({});
  const assetData = useSelector((state) => state.assetData.assetData);
  const [formData, setFormData] = useState({
    showGeneralDetailsFieldErrors: false,
    showSpecificationFieldErrors: false,
  });
  const getUpdatedStatusOFAssetCreation = (val) => setShowAssetCreationModal(val);
  const [showAssetCreationSuccessModal, setShowAssetCreationModal] = useState(false);
  const steps = ["General Details","Specifications","Location & Hierarchy","3D","Documents","Parameter","Reference Manuals","Spares"];

  const getCreatedAssetDetails = (res) => setCreatedAssetResponse(res);
  
  const showRequiredFieldError = () => dispatch(commonActions.handleSnackbar({show: true,message: `Please fill all the required fields`,type: "error",closeIn: 2000}));
  
  const handleNext = () => {
    if (activeStep === 0) {
      if (validGeneralDetails(formData)) {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        showRequiredFieldError();
      }
    } else if (activeStep === 1) {
      if (validSpecificationsDetails(formData)) {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
          if(formData?.isWarrantyIncluded && formData?.supplierEmail && !emailRegex.test(formData?.supplierEmail)){
            handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide valid Email Id. ",showTime:"5000"})
          } else {
            showRequiredFieldError();
          }
      }
    } else if (activeStep === 2) {
      if (validLocationDetails(formData)) {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        showRequiredFieldError();
      }
    } else if (activeStep === 3) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else if (activeStep === 4) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else if (activeStep === 5) {
      if(validGeneralDetails(formData) && validSpecificationsDetails(formData) && validLocationDetails(formData) ) {
        if(formData?.assetParameters?.length && !validateAssetParametersValue(formData)){
          handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide all details for added parameters.",showTime:"10000"})
        } else if(formData?.assetParameters?.length && validateAssetParametersValue(formData) && !validateParameterNameUniqueness(formData?.assetParameters)){
          handleShowErrorAndWarning({dispatch,type:"error",message:"Parameter's Name should be unique! ",showTime:"10000"})
        } else if (validateAssetParametersValue(formData) && validateParameterNameUniqueness(formData?.assetParameters)){
          setActiveStep((prevActiveStep) => prevActiveStep + 1);
        }
      } else {
        showRequiredFieldError()
      }
    } else if (activeStep === 6) {
      if(validGeneralDetails(formData) && validSpecificationsDetails(formData) && validLocationDetails(formData) ){
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      }
    } else if(activeStep === 7) {
      createNewAsset({formData,loggedUser,dispatch,getUpdatedStatusOFAssetCreation,operationType: "created",getCreatedAssetDetails: (res) => getCreatedAssetDetails(res),setShowAssetCreationModal,});
    }
  };

  const handleBack = () => {
    if (activeStep === 7) {
      formData.assetStatus = "Draft";
      createNewAsset({formData,loggedUser,dispatch,getUpdatedStatusOFAssetCreation,operationType: "drafted",getCreatedAssetDetails: (res) => getCreatedAssetDetails(res),setShowAssetCreationModal,});
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }
  };

  const getChildData = (value) => {
    if (value) {
      setFormData(value);
    }
  };

  return (
    <>
      <div className={Styles.StepperWrapper}>
        <Stepper
          alternativeLabel
          activeStep={activeStep}
          connector={<StepConnector />}
          style={{ background: "none" }}
        >
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel
                StepIconComponent={(props) => {
                  return <StepIcon
                    {...props}
                    handleSetActiveStep={() => setActiveStep(index)}
                    activeStep={activeStep}
                    formData={formData}
                    index={index}
                  />
                }}
              >
                {label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </div>
      <RenderAssetSteps
        steps={steps}
        changeIN={{}}
        mode={"create"}
        defaultData={{}}
        step={activeStep}
        formData={formData}
        getChildData={getChildData}
        getChangedValues={() => {}}
        setActiveStep={setActiveStep}
        errorhandlerObject={errorhandlerObject}
      />
      {/* <StepController
        steps={steps}
        handleBack={handleBack}
        handleNext={handleNext}
        activeStep={activeStep}
      /> */}
      {showAssetCreationSuccessModal && (
        <AssetCreationSuccessModal
          label={"Asset"}
          libraryURL={"assets"}
          name={formData?.assetName}
          state={createdAssetResponse}
          number={formData?.assetNumber}
          open={showAssetCreationSuccessModal}
          closeModalMethod={setShowAssetCreationModal}
          viewItemURL={`view-asset/${formData?.assetName}`}
        />
      )}
      
    </>
  );
};
