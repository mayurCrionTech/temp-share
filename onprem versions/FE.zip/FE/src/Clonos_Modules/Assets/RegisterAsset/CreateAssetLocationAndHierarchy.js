import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import SearchIcon from "@material-ui/icons/Search";
import {
  handleShowErrorAndWarning,
} from "../../../utils/clonosCommon";
import DOWNANGLE from "../../../assets/UIUX/icons/chevron-down.svg";
import { handleGetAssetDropdown } from "../../../utils/WorkOrderMethods/WorkOrderMethods";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import DynamicDropdown from "../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import { ImmediateParentChildAssetTree } from "../ImidiateParentChildAssetTree/ImmediateParentChildAssetTree";
let primaryObject = {};


export const CreateAssetLocationAndHierarchy = ({ getData, data, errorhandlerObject }) => {
  const dispatch = useDispatch();
  const [locationsDropdown, setLocationsDropdown] = useState([
    {
      id: 1,
      locationId: "loc-203bc829-262c-4a77-b8cf-b15e89448776",
      name_of_city: "Mandapeta",
    },
    {
      id: 2,
      locationId: "loc-809e1938-d038-43eb-92ef-f64ce5b7889d",
      name_of_city: "Tatipaka",
    },
  ]);
  const [showHierarchyModal, setShowHierarchyModal] = useState(false);
  const [locationData, setLocationData] = useState({ ...data });
  const [assetPaginationCurrentPage, setAssetPaginationCurrentPage] = useState(1);
  const [assetDropdownData, setAssetDropdownData] = useState([]);

  const handleSetParent = (id) => {
    setLocationData((prev) => {
      let temp = {
        ...prev,
        parentAsset: id,
      };
      getData(temp);
      return temp;
    });
    setShowHierarchyModal(false);
  };


  const handleMoreData = ({ isActivator }) => {
    if (isActivator) {
      setAssetPaginationCurrentPage((prev) => {
        let updatedPageCount = prev + 1;
        handleGetAssetDropdown({
          setAssetDropdownData,
          assetDropdownData,
          assetPaginationCurrentPage: updatedPageCount,
          dispatch,
        });
        return updatedPageCount;
      });
    }
  };

  const handleGetErrorActivatorInformation = (props) => {
    errorhandlerObject = { ...errorhandlerObject, [props.uniqueKey]: props }
  }


  const updateLocalAndParentState = ({uniqueKey,value}) => {
    setLocationData((prev) => {
      if(uniqueKey === "latitude" || uniqueKey === "longitude" || uniqueKey === "elevation"){
          let temp = {...prev, geoLocation : {...prev?.geoLocation,[uniqueKey]:value}};
          getData(temp);
          return temp
      } else{
          let temp = {
            ...prev, [uniqueKey]:value
          }
          getData(temp);
          return temp
      }

      })
  }

  const handleErrorObjectModifier = ({ uniqueKey, response}) => {
    if (response === null) {
      errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": false } }
      return false
    } else {
      if(uniqueKey === "supplierEmail"){
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
        if(!emailRegex.test(response)){
          errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": false } }
        }
      }
      errorhandlerObject = { ...errorhandlerObject, [uniqueKey]: { ...errorhandlerObject[uniqueKey], "value": true } }
      return true
    }
  }


  const handleGetValues = (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;
    if (type === "dynamicDropdown") {
      handleErrorObjectModifier({ uniqueKey, response: selectedOption,errorhandlerObject });
      // let value = valueSetter ? {name:selectedOption[0]?.name,id:selectedOption[0]?.id} : null
      updateLocalAndParentState({uniqueKey,value:{name:selectedOption[0]?.name,id:selectedOption[0]?.id}})
      
    }
    else if (type === "select") {
      handleErrorObjectModifier({ uniqueKey, response: updatedValue,errorhandlerObject });
      // let value =  valueSetter ? {name:updatedValue?.label,id:updatedValue?.value} : null
      updateLocalAndParentState({uniqueKey,value:{name:updatedValue?.label,id:updatedValue?.value}})
    }

    else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email") {
      handleErrorObjectModifier({ uniqueKey, response: updatedValue,errorhandlerObject });
      // let value =  valueSetter ? updatedValue : null
      updateLocalAndParentState({uniqueKey,value:updatedValue})
    }
  };


  const handleHierarchy = (type) => {
    if (type === "remove") {
      handleSetParent(null);
    } else if (type === "change") {
      setShowHierarchyModal(true);
    }
  };


  useEffect(() => {
    // getLocations().then((res) => {
    //   setLocationsDropdown(res?.data?.result);
    // });
    handleGetAssetDropdown({
      setAssetDropdownData,
      assetDropdownData,
      assetPaginationCurrentPage,
      dispatch,
    });
  }, []);


  return (
    <>
      <div className={Styles.locationContainer}>
        <div className={Styles.locationAndHierarchyLeftContainer}>
          <h4>Location Details</h4>
          <div className={Styles.locDetailsContainer}>
            <div>
              <ClonosSelect
                type="select"
                placeholder="Select"
                label={"Location"}
                isLabel={true}
                uniqueKey="location"
                defaultValue={locationData?.location?.name}
                isMandatory={true}
                options={locationsDropdown?.map((opt) => ({
                  label: opt?.name_of_city,
                  value: opt?.locationId,
                  isNeeded: true,
                }))}
                icon={DOWNANGLE}
                errorMessage={"Location is Required!."}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <div className={Styles.geoLocationTitleContainer}>
                <label>
                  Geographical Co-ordinates{" "}
                  <span style={{ color: "red" }}>*</span>
                </label>
                <div className={Styles.arLocationLink}>
                  <p>Get the location from AR</p>
                </div>
              </div>
              <div className={Styles.geoLocation}>
                <div>
                <ClonosInput
                  isLabel={true}
                  label={"Latitude(deg)"}
                  isMandatory={true}
                  value={locationData?.geoLocation?.latitude}
                  placeholder="Latitude"
                  uniqueKey="latitude"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Latitude is Required!."}
                  type="number"
                />
                </div>
                <div>
                <ClonosInput
                  isLabel={true}
                  label={"Longitude(deg)"}
                  isMandatory={true}
                  value={locationData?.geoLocation?.longitude}
                  placeholder="Longitude"
                  uniqueKey="longitude"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Longitude is Required!."}
                  type="number"
                />
                </div>
                <div>
                <ClonosInput
                  isLabel={true}
                  label={"Elevation(m)"}
                  isMandatory={true}
                  value={locationData?.geoLocation?.elevation}
                  placeholder="Elevation"
                  uniqueKey="elevation"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Elevation is Required!."}
                  type="number"
                />
                </div>
              </div>
            </div>
          </div>
          <h4>
            {locationData?.parentAsset ? "Asset Hierarchy" : "Set Hierarchy"}
          </h4>
          {!locationData?.parentAsset ? (
            <div className={Styles.setParentBtn}>
              <button
                variant="filled"
                onClick={() => {
                  if (locationData?.assetName) {
                    setShowHierarchyModal(true);
                  } else {
                    handleShowErrorAndWarning({
                      dispatch,
                      type: "error",
                      message: "To set Parent, First provide Asset Name.",
                      showTime: 5000,
                    });
                  }
                }}
              >
                Set Parent
              </button>
            </div>
          ) : (
            <></>
          )}
          {locationData?.assetName ? (
            <div className={Styles.currentHierarchyTree}>
              <ImmediateParentChildAssetTree
                assetGeneralDetails={locationData}
                dispatch={dispatch}
              />
              {locationData?.parentAsset ? (
                <div className={Styles.hierarchyControlers}>
                  <button onClick={() => handleHierarchy("remove")}>
                    Remove Hierarchy
                  </button>
                  <button onClick={() => handleHierarchy("change")}>
                    Change Hierarchy
                  </button>
                </div>
              ) : (
                <></>
              )}
            </div>
          ) : (
            <></>
          )}
        </div>
      </div>
      <DynamicDropdown
        uniqueKey={"parentAsset"}
        labelActivator={""}
        isOpen={showHierarchyModal}
        isOpenMethod={setShowHierarchyModal}
        heading={"Select from Asset Library"}
        placeholder={"Search"}
        isSearchable={true}
        isCheckbox={false}
        isDynamicSearch={false}
        isDynamicLoad={false}
        data={assetDropdownData}
        isActivator={false}
        isMandatory={false}
        url={SearchIcon}
        handleMoreData={handleMoreData}
        handleGetValues={handleGetValues}
      />
    </>
  );
};
