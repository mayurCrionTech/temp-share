import { StepConnector, makeStyles, withStyles } from "@material-ui/core";
import { clsx } from "clsx";
import PropTypes from "prop-types";
import FiberManualRecordIcon from "@material-ui/icons/FiberManualRecord";
import CheckIcon from "@material-ui/icons/Check";
import {
  validGeneralDetails,
  validLocationDetails,
  validSpecificationsDetails,
  validate3DDetails,
  validateAssetDocuments,
  validateAssetParametersValue,
  validateParameterNameUniqueness,
  validateReferenceManualsValue,
} from "../../../utils/AssetsMethods/AssetRegister";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import { useDispatch } from "react-redux";
import { handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import { handleStepperActiveStep } from "../../../utils/AssetsMethods/StepperMethods";
export const StepperConnector = withStyles({
  alternativeLabel: {
    top: 22,
  },
  active: {
    "& $line": {
      // backgroundImage:
      //   'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
      // backgroundColor:"#3f51b5"
      border: "1px solid #06337E",
    },
  },
  completed: {
    "& $line": {
      // backgroundImage:
      //   'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
      // backgroundColor:"#3f51b5"
      border: "1px solid #06337E",
    },
  },
  line: {
    height: 3,
    border: 0,
    backgroundColor: "#eaeaf0",
    borderRadius: 1,
  },
})(StepConnector);

const useStepIconStyles = makeStyles({
  root: {
    backgroundColor: "#ccc",
    zIndex: 1,
    color: "#fff",
    width: 30,
    height: 30,
    display: "flex",
    borderRadius: "50%",
    justifyContent: "center",
    alignItems: "center",
  },
  active: {
    // backgroundImage:
    //   'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
    // boxShadow: '0 4px 10px 0 rgba(0,0,0,.25)',
    // backgroundColor:"#3f51b5"
    border: "1px solid #06337E",
    color: "#06337E",
  },
  completed: {
    // backgroundImage:
    //   'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
    // backgroundColor:"#3f51b5"
    border: "1px solid #06337E",
    color: "#06337E",
  },
});

export const StepIcon = (props) => {
  const classes = useStepIconStyles();
  const dispatch = useDispatch();
  const {
    active,
    completed,
    handleSetActiveStep,
    activeStep,
    formData,
    index,
  } = props;
  const renderIcon = (condition) => condition ? <CheckIcon fontSize="small" /> : <FiberManualRecordIcon fontSize="small" />;
    const icons = {
      1: renderIcon(validGeneralDetails(formData)),
      2: renderIcon(validSpecificationsDetails(formData)),
      3: renderIcon(validLocationDetails(formData)),
      4: renderIcon(activeStep > index || validate3DDetails(formData)),
      5: renderIcon(activeStep > index || validateAssetDocuments(formData?.documents)),
      6: renderIcon(activeStep > index || (formData?.assetParameters?.length && validateAssetParametersValue(formData) && validateParameterNameUniqueness(formData?.assetParameters))),
      7: renderIcon(activeStep > index || (formData?.instructionsDocuments && validateReferenceManualsValue(formData))),
      8: renderIcon(activeStep > index)
    };

  return (
    <div
      className={clsx(classes.root, {
        [classes.active]: active,
        [classes.completed]: completed,
      })}
      onClick={() => {
        handleStepperActiveStep({ index, activeStep, dispatch, formData, proceedNext: handleSetActiveStep })
      }}
    >
      {icons[String(props.icon)]}
    </div>
  );
};

StepIcon.propTypes = {
  /**
   * Whether this step is active.
   */
  active: PropTypes.bool,
  /**
   * Mark the step as completed. Is passed to child components.
   */
  completed: PropTypes.bool,
  /**
   * The label displayed in the step icon.
   */
  icon: PropTypes.node,
};
