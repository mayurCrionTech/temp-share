import Styles from "../../../ModuleStyles/Assets/uploadDoumentModal.module.css";
import CLOSEICON from "../../../assets/UIUX/icons/x-circle-fill.svg";
import DOWNANGLE from "../../../assets/UIUX/icons/chevron-down.svg";
import { useState } from "react";
import { useRef } from "react";
import { useEffect } from "react";
import { handleGetStaticDropdownValues } from "../../../utils/DropdownsMethods/DropdownsMethods";
import { useDispatch } from "react-redux";
import UPLOADFILEICON from "../../../assets/UIUX/icons/fileuploadIcon.svg";
import FILE from "../../../assets/UIUX/icons/file.svg";
import DELETEICON from "../../../assets/UIUX/icons/redTrash.svg";
import { Tooltip } from "@material-ui/core";
import {
  handleGetValueFromSelect,
  handleGetValuesMethod,
  validateForm,
} from "../../../utils/AssetsMethods/AssetRegister";
import { globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import ClonosTooltip from "../../../components/CommonComponents/ClonosTooltip/ClonosTooltip";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { v4 as uuidv4 } from 'uuid';
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";


export const UploadDocumentModal = ({ data, getData, open, closeModalMethod, getDocumentData, getChangedValues, mode }) => {
  const dispatch = useDispatch();
  const [formData, setFormData] = useState();
  const [changedData, setChangedData] = useState({});
  const [docTypes, setDocTypes] = useState([]);
  const [status, setStatus] = useState([]);
  const [errors, setErrors] = useState({});
  const fileUploaderRef = useRef(null);
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetDocument" })
  const handleChange = (e) => {
    let { name, value } = e.target;
    const specialCharacters = `!"#$%&'()*+,-./:;<=>?@[\\]^\`{|}~`;
    let charArr = value.split("");
    const newValue = charArr.filter((char) => {
      return !specialCharacters.includes(char);
    }).join("");
    setFormData((prev) => ({ ...prev, [name]: newValue }));
    setChangedData((prev) => {
      return { ...prev, [name]: newValue };
    });
  };

  const handleUploadFile = (e) => {
    let file = e.target.files[0];
    setFormData((prev) => ({ ...prev, file: file, fileName: file?.name }));
    if (formData?.isActive) {
      setChangedData((prev) => ({ ...formData, file, replaceDocument: true }));  // spreading formData because changedData need previous details with updated.
    } else {
      setChangedData((prev) => ({ ...formData, file }));    // spreading formData because changedData need previous details with updated.
    }
  };


  const handleGetValues = (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;
    if (type === "select") {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      setFormData((prev) => ({ ...prev, [uniqueKey]: { name: updatedValue?.label, id: updatedValue?.value } }));
      setChangedData((prev) => ({ ...formData, [uniqueKey]: { name: updatedValue?.label, id: updatedValue?.value } }))  // spreading formData because changedData need previous details with updated. 
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email") {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue, });
      setFormData((prev) => ({ ...prev, [uniqueKey]: updatedValue }));
      setChangedData((prev) => ({ ...formData, [uniqueKey]: updatedValue })) // spreading formData because changedData need previous details with updated.
    }
  };

  const handleSaveData = () => {
    if (globalHandleIsAllRequiredFieldAvailable({ primaryObject })) {
      let docId = uuidv4();
      if (formData?.id) getDocumentData(formData)
      if (!formData?.id) getDocumentData({ ...formData, id: docId });
     
      if (mode === "edit") {
        getChangedValues({ ...changedData, id: formData?.id ? formData?.id : docId, isActive: formData?.isActive });
        setChangedData({})
      }
      closeModalMethod();
      setFormData({});
    } else {

      handleShowErrorAndWarning({ dispatch, type: "error", message: "Please Provide all require field!", showTime: "5000" })
      // setErrors((prev) => {
      //   let temp = {
      //     ...prev,
      //     documentName: formData?.documentName
      //       ? ""
      //       : "Document Name is Required!",
      //     documentNumber: formData?.documentNumber
      //       ? ""
      //       : "Document Number is Required!",
      //   };
      //   return temp;
      // });
      // for (let key in errorhandlerObject) {
      //   if (!errorhandlerObject[key].value) {
      //     errorhandlerObject[key]?.errorActivatorMethod(true);
      //   }
      // }
    }
  };

  const handleRemoveFile = () => {
    setFormData((prev) => ({ ...prev, file: null, fileName: null }));
    if (mode === "edit") {
      setFormData((prev) => ({ ...prev, fileName: null }));
      if (formData?.isActive) {
        setChangedData((prev) => {
          return { ...formData, replaceDocument: true };
        });
      } else {
        setChangedData((prev) => {
          return { ...formData, file: null };
        });
      }
    }
  };

  useEffect(() => {
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "DocumentType", dispatch, setterFunctionForValues: setDocTypes });
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "ApprovalStatus", dispatch, setterFunctionForValues: setStatus });
  }, []);

  useEffect(() => {
    setFormData({ ...data });
  }, [data]);

  useEffect(() => {
   
  }, [primaryObject])


  return (
    <Modal isOpen={open} closeModalMethod={closeModalMethod} stopOverlayCloser={true}>
      <div className={Styles.modalContainer}>
        <div className={Styles.headerContainer}>
          <h4 className={Styles.header}>Upload Document</h4>
          <div onClick={closeModalMethod} style={{ cursor: "pointer" }}>
            <img src={CLOSEICON} />
          </div>
        </div>
        <div className={Styles.inputsContainer}>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
              <ClonosInput
                type="text"
                isLabel={true}
                isMandatory={true}
                label={"Document Name"}
                uniqueKey="documentName"
                // readOnly={!data?.isNewAdded}
                placeholder={"Document Name"}
                value={formData?.documentName}
                handleGetValues={handleGetValues}
                defaultValue={formData?.documentName}
                errorMessage={"Document Name is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div className={Styles.fieldContainer}>
              <ClonosInput
                type="text"
                isLabel={true}
                isMandatory={true}
                label={"Document Number"}
                uniqueKey="documentNumber"
                placeholder="Document Number"
                isSpecialCharacterAllow={true}
                value={formData?.documentNumber}
                handleGetValues={handleGetValues}
                errorMessage={"Document Number is Required!."}
                onlyAllowTheseSpecialCharacters={["_", "-", "."]}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
          </div>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
              <ClonosInput
                type="text"
                isLabel={true}
                label={"Revision Number"}
                uniqueKey="revisionNumber"
                placeholder="Revision Number"
                isSpecialCharacterAllow={true}
                value={formData?.revisionNumber}
                handleGetValues={handleGetValues}
                onlyAllowTheseSpecialCharacters={["_", "-", "."]}
              />
            </div>
            <div className={Styles.fieldContainer}>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={true}
                placeholder="Select"
                label={"Document Type"}
                uniqueKey="documentType"
                handleGetValues={handleGetValues}
                defaultValue={formData?.documentType?.name}
                errorMessage={"Document type is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                options={docTypes?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              />
            </div>
          </div>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                uniqueKey="status"
                isMandatory={false}
                placeholder="Select"
                label={"Document Status"}
                handleGetValues={handleGetValues}
                defaultValue={formData?.status?.name}
                options={status?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              />
            </div>
          </div>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
              <label>Upload Document</label>
              <input
                type="file"
                accept=".pdf"
                id={"document"}
                name="document"
                ref={fileUploaderRef}
                style={{ display: "none" }}
                onChange={handleUploadFile}
              />
              <div className={Styles.fileUploaderContainer}>
                <div
                  className={Styles.custom_button}
                  onClick={() => fileUploaderRef.current.click()}
                >
                  <img src={UPLOADFILEICON} />
                  <h4>Upload</h4>
                </div>
                {(formData?.file?.name || formData?.fileName) && (
                  <div className={Styles.filePreviewBox}>
                    <div className={Styles.fileNameBox}>
                      <img src={FILE} />
                      <ClonosTooltip content={formData?.file?.name || formData?.fileName} >
                        <h4 >{formData?.file?.name || formData?.fileName} </h4>
                      </ClonosTooltip>
                    </div>
                    <div
                      className={Styles.deleteFileBox}
                      onClick={handleRemoveFile}
                    >
                      <img src={DELETEICON} />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        <div className={Styles.btnController}>
          <div>
            <ClonosButton onClick={closeModalMethod}>Cancel</ClonosButton>
            <ClonosButton variant="filled" onClick={handleSaveData}>Save</ClonosButton>
          </div>
        </div>
      </div>
    </Modal>
  );
};
