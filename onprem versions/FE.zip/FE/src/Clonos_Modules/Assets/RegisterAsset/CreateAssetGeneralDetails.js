import { useDispatch } from "react-redux";
import { useEffect, useState, memo, useRef } from "react";
import SEARCHICON from "../../../assets/UIUX/icons/search (1).svg";
import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import DOWNANGLE from "../../../assets/UIUX/icons/chevron-down.svg";
import { handleCheckUniqueField, handleCreateAssetGeneralDetails } from "../../../utils/AssetsMethods/AssetRegister";
import { specialCharacters } from "../../../utils/AssetsMethods/constants";
import { getDocumentsListOfAssetCategory } from "../../../Api/Asset/assetApi";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import { handleGetUsersDropdownData } from "../../../utils/WorkOrderMethods/WorkOrderMethods";
import ClonosTextarea from "../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import { handleGetStaticDropdownValues } from "../../../utils/DropdownsMethods/DropdownsMethods";
import DynamicDropdown from "../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";
import { StepController } from "./StepController";
import { globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import useToggler from "../../../CustomHooks/TogglerHook";


const CreateAssetGeneralDetails = ({ getData, data, errorhandlerObject, steps, activeStep, setActiveStep }) => {
  const dispatch = useDispatch();
  const [assetMode, setAssetMode] = useState([]);
  const [runningMode, setRunningMode] = useState([]);
  const [formData, setFormData] = useState({ ...data });
  const [usersDropdownData, setUsersDropdownData] = useState([]);
  const [isLoading, setIsLoading] = useToggler();
  const [isCategorySelected, setIsCategorySelected] = useState(false)
  const [criticalityLevelDropdown, setCriticalityDropdown] = useState([]);
  const [functionalAreaDropdown, setFunctionalAreaDropdown] = useState([]);
  const [assetDepartmentDropdwon, setAssetDepartmentDropdown] = useState([]);
  const [assetCategoryDropdownDown, setAssetCategoryDropdown] = useState([]);
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })


  const handleMoreData = ({ isActivator }) => {
    // if (isActivator) {
    //   setAssetPaginationCurrentPage((prev) => {
    //     let updatedPageCount = prev + 1;
    //     handleGetUsersDropdownData({
    //       setUsersDropdownData,
    //       usersDropdownData,
    //       assetPaginationCurrentPage: updatedPageCount,
    //       dispatch,
    //     });
    //     return updatedPageCount;
    //   });
    // }
  };


  const updateLocalAndParentState = ({ uniqueKey, value }) => {
    setFormData((prev) => {
      let temp = { ...prev, generalDetails: { ...prev?.generalDetails, [uniqueKey]: value } }
      if (uniqueKey === "assetCategory") {
        setIsCategorySelected(true)
      }
      getData(temp)
      return temp
    })
  }

  const handleGetValues = async (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;

    if (type === "dynamicDropdown") {
      handlePrimaryObjectModifier({ uniqueKey, response: selectedOption });
      updateLocalAndParentState({ uniqueKey, value: { name: selectedOption[0]?.name, id: selectedOption[0]?.id } })

    } else if (type === "select") {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      updateLocalAndParentState({ uniqueKey, value: { name: updatedValue?.label, id: updatedValue?.value } })
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local") {
      const uniqueFields = ["name", "number", "censusNumber"];
      // if(uniqueFields.includes(uniqueKey)){
      //   const isFieldUnique = await handleCheckUniqueField({fieldName:uniqueKey,fieldValue:updatedValue});
      //   if(isFieldUnique === true){
      //     // primaryObject[uniqueKey].
      //   }
      // }
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      updateLocalAndParentState({ uniqueKey, value: updatedValue })
    }
  };

  // new changes for file uploader

  const handleGetUploadedFiles = (val) => {
    const files = val?.files;
    setFormData((prev) => {
      let temp = { ...prev, assetImages: [...files] };
      getData(temp);
      return temp;
    });
  };

  const handleBack = () => {
  }
  const handleNext = async () => {
    if (globalHandleIsAllRequiredFieldAvailable({ primaryObject })) {
      if (!handleSubmit()) return
      const res = handleCreateAssetGeneralDetails({ payload: formData, setIsLoading });

    } else {
     
      handleShowErrorAndWarning({ dispatch, type: "error", message: "Please Provide all require field!", showTime: "5000" })
    }
  }

  useEffect(() => {
    handleGetUsersDropdownData({ setUsersDropdownData, usersDropdownData, dispatch, pagination: { page: 0, limit: 100 } });
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "AssetMode", dispatch, setterFunctionForValues: setAssetMode, });
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "RunningMode", dispatch, setterFunctionForValues: setRunningMode, });
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "FunctionalArea", dispatch, setterFunctionForValues: setFunctionalAreaDropdown });
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "AssetDepartment", dispatch, setterFunctionForValues: setAssetDepartmentDropdown, });
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "CriticalityLevel", dispatch, setterFunctionForValues: setCriticalityDropdown, });
    handleGetStaticDropdownValues({ staticDropdownNameOrId: "AssetCategory", dispatch, setterFunctionForValues: setAssetCategoryDropdown, });
  }, []);

  useEffect(() => {
    if (data?.assetCategory?.id && isCategorySelected) {
      getDocumentsListOfAssetCategory(formData?.assetCategory?.id).then((res) => {
        let documents = res?.data?.result?.data || [];
        documents = documents?.map((doc, index) => {
          let tempDoc = {
            documentName: doc?.documentName,
            id: doc?._id,
            index: index + 1,
            documentType: null,
            status: null,
            documentNumber: null,
            revisionNumber: null,
            file: null,
            action: "Upload"
          }
          return tempDoc
        })
        setFormData((prev) => ({ ...prev, documents }))
        getData({ ...data, documents, })
      })
    }

    return () => {
      setIsCategorySelected(false)
    }
  }, [data?.assetCategory?.id])

  return (
    <>
      <div className={Styles.generalDetailsContainer}>
        <div>
          <div className={Styles.generalDetails_left}>
            <div>
              <ClonosInput
                type="text"
                limit="100"
                isLabel={true}
                isMandatory={true}
                label={"Asset Name"}
                uniqueKey="name"
                placeholder="Asset Name"
                value={formData?.generalDetails?.name}
                handleGetValues={handleGetValues}
                errorMessage={"Asset Name is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <ClonosInput
                type="text"
                isLabel={true}
                isMandatory={true}
                label={"Asset Number"}
                uniqueKey="number"
                placeholder="Asset Number"
                value={formData?.generalDetails?.number}
                isSpecialCharacterAllow={true}
                handleGetValues={handleGetValues}
                errorMessage={"Asset Number is Required!."}
                onlyAllowTheseSpecialCharacters={specialCharacters}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <ClonosTextarea
                rows="4"
                type="text"
                isLabel={true}
                label={"Asset Description"}
                uniqueKey="assetDescription"
                placeholder="Asset Description"
                value={formData?.generalDetails?.assetDescription}
                handleGetValues={handleGetValues}
              ></ClonosTextarea>
            </div>
            <div>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={false}
                placeholder="Select"
                label={"Asset Mode"}
                uniqueKey="assetMode"
                handleGetValues={handleGetValues}
                defaultValue={formData?.generalDetails?.assetMode?.name}
                errorMessage={"Asset Mode is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                options={assetMode?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={false}
                placeholder="Select"
                label={"Running Mode"}
                uniqueKey="runningMode"
                handleGetValues={handleGetValues}
                defaultValue={formData?.generalDetails?.runningMode?.name}
                errorMessage={"Running Mode is Required!."}
                options={runningMode?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={true}
                placeholder="Select"
                label={"Asset Department"}
                uniqueKey="assetDepartment"
                handleGetValues={handleGetValues}
                defaultValue={formData?.generalDetails?.assetDepartment?.name}
                errorMessage={"Asset Department is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                options={assetDepartmentDropdwon?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={true}
                placeholder="Select"
                label={"Asset Category"}
                uniqueKey="assetCategory"
                handleGetValues={handleGetValues}
                defaultValue={formData?.generalDetails?.assetCategory?.name}
                errorMessage={"Asset Category is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                options={assetCategoryDropdownDown?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={true}
                placeholder="Select"
                label={"Criticality Level"}
                uniqueKey="criticalityLevel"
                handleGetValues={handleGetValues}
                defaultValue={formData?.generalDetails?.criticalityLevel?.name}
                errorMessage={"Criticality Level is Required!."}
                options={criticalityLevelDropdown?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={true}
                placeholder="Select"
                label={"Functional Area"}
                uniqueKey="functionalArea"
                handleGetValues={handleGetValues}
                defaultValue={formData?.generalDetails?.functionalArea?.name}
                errorMessage={"Functional Area is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                options={functionalAreaDropdown?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              />
            </div>
            <DynamicDropdown
              isLabel={true}
              isUser={true}
              url={SEARCHICON}
              isCheckbox={false}
              isActivator={true}
              isMandatory={true}
              isSearchable={true}
              title={"Asset Owner"}
              isDynamicLoad={false}
              placeholder={"Search"}
              uniqueKey={"assetOwner"}
              data={usersDropdownData}
              labelActivator={"User Name"}
              handleMoreData={handleMoreData}
              handleGetValues={handleGetValues}
              heading={"Select from User Library"}
              errorMessage={"Asset Owner is Required!."}
              defaultValue={formData?.generalDetails?.assetOwner?.name && [formData?.generalDetails?.assetOwner]}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />
            <div>
              <ClonosInput
                type="text"
                isLabel={true}
                label={"Census Number"}
                uniqueKey="censusNumber"
                isSpecialCharacterAllow={true}
                value={formData?.generalDetails?.censusNumber}
                placeholder="Enter Census Number"
                handleGetValues={handleGetValues}
                onlyAllowTheseSpecialCharacters={specialCharacters}
              />
            </div>
          </div>
          <div className={Styles.generalDetails_right}>
            <div>
              <FileUploader
                limit={10}
                fileSizeInMB={10}
                isMandatory={false}
                title={"assetImges"}
                label={"Asset Image"}
                typeOfRecord={"images"}
                acceptableFileTypes={[".jpg", ".png", ".jpeg"]}
                handleGetSelectedData={(value) => handleGetUploadedFiles(value)}
                localPreviousPageFiles={formData?.generalDetails?.assetImages && formData?.generalDetails?.assetImages.length > 0 ? formData?.generalDetails?.assetImages : []}
              />
            </div>
          </div>
        </div>
      </div>
      <StepController
        steps={steps}
        handleBack={handleBack}
        handleNext={handleNext}
        activeStep={activeStep}
      />
    </>
  );
};

export default memo(CreateAssetGeneralDetails);
