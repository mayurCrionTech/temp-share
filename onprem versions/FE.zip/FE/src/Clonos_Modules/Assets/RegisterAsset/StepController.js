import { useState } from "react";
import Styles from "../../../ModuleStyles/Assets/stepper.module.css"
import { useSelector } from "react-redux";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
export const StepController = ({handleBack,handleNext,activeStep,steps}) => {
    const {showAssetCreationLoading,showAssetDraftLoading} = useSelector((store) => store.assetData);
    return (
        <>
            <div className={Styles.controller_btn}>
                <div>
                <ClonosButton isDisabled={activeStep === 0} loading={showAssetDraftLoading} onClick={() => handleBack()}>{activeStep === steps.length - 1 ? "Save as Draft" : "Previous"}</ClonosButton>
                </div>
                <div>
                <ClonosButton loading={showAssetCreationLoading} onClick={() => handleNext()}>{activeStep === steps.length - 1 ? 'Create' : 'Save & Next'}</ClonosButton>
                </div>
            </div>
        </>
    )   
}