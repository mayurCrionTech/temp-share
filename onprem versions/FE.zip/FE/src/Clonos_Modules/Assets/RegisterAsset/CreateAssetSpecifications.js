import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import {
  handleChangeValues,
  validateForm,
} from "../../../utils/AssetsMethods/AssetRegister";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getUser } from "../../../utils/clonosCommon";
import DOWNANGLE from "../../../assets/UIUX/icons/chevron-down.svg";
import { useEffect } from "react";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import { ClonosInputWithSelect } from "../../../components/CommonComponents/ClonosInputWithSelect/ClonosInputWithSelect";
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";
import ClonosRadioAndCheckbox from "../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox";
import { handleSpeacificationDetailsCatogories, updateLocalAndParentState } from "../Utils/specificationsMethods";



export const CreateAssetSpecifications = ({ getData, data, errorhandlerObject }) => {
  const user = getUser();
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({ ...data });
  const [errors, setErrors] = useState({});
  const isDrawerOpen = localStorage.getItem("isDrawerOpen");
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })


  // TO MANAGE ASSET TYPE VALUE
  const handleChangeRadioButtons = ({ e, label }) => {
    const { name, value, placeholder } = e.target;
    setFormData((prevData) => {
      let temp = {
        ...prevData,
        [name]: value
      }
      validateForm({ name, formData: temp, setErrors, label });
      getData({ ...temp })
      return temp
    });
  };




  // TO HANDLE CHANGED VALUES 
  const handleGetValues = (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;
    if (type === "dynamicDropdown") {
      handlePrimaryObjectModifier({ uniqueKey, response: selectedOption, });
      updateLocalAndParentState({ setFormData, formData, getData, uniqueKey, value: { name: selectedOption[0]?.name, id: selectedOption[0]?.id } })
    }
    else if (type === "select") {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue, });
      updateLocalAndParentState({ setFormData, formData, getData, uniqueKey, value: { name: updatedValue?.label, id: updatedValue?.value } })
    }

    else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email") {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      updateLocalAndParentState({ setFormData, formData, getData, uniqueKey, value: updatedValue })
    }
  };


  const handleGetUploadedfiles = (val) => {
    const files = val.files;
    setFormData((prev) => {
      let temp = { ...prev, assetTermsAndConditions: [...files] };
      getData(temp);
      return temp;
    });
  };

  const handleChangeWarrantyInclusion = () => {
    setFormData((prev) => {
      let temp = { ...prev, isWarrantyIncluded: !prev.isWarrantyIncluded };
      getData(temp);
      return temp
    })
  }

  // TO WARRANTY END DATE DYNAMICALLY BASED ON INSTALLATION DATE
  useEffect(() => {
    if (formData?.warrantyPeriodNumber && formData?.warrantyPeriodDurr && formData?.installationDate) {
      let months = 0;
      if (formData?.warrantyPeriodDurr?.name === "Years") {
        months = formData?.warrantyPeriodNumber * 12;
      } else {
        months = formData?.warrantyPeriodNumber;
      }
      let installationDate = formData?.installationDate;
      let date = new Date(installationDate);
      date.setMonth(date.getMonth() + Number(months));
      let updatedDate = date?.toISOString().slice(0, 10);
      setFormData((prev) => {
        let temp = { ...prev, warrantyEndDate: updatedDate, defaultWarrantyEndDate: updatedDate };
        validateForm(temp, setErrors);
        getData(temp);
        return temp;
      });
    }
  }, [formData?.warrantyPeriodDurr, formData?.warrantyPeriodNumber, formData?.installationDate,]);

 
  return (
    <>
      <div className={Styles.specificationsContainer}>
        <div>
          <div className={Styles.specsDetails_top}>
            <div className={Styles.manufacturingDetailsLeftContainer}>
              <h4>Manufacturing Details</h4>
              <div className={Styles.clonosInputWrapper}>
                <label className={Styles.clonosLabelStyle}>
                  Asset Type <span style={{ color: "red" }}>*</span>
                </label>
                <div className={Styles.radioContainer}>
                  <div>
                    <input
                      checked={formData?.assetType === "aty-001" ? true : false}
                      name="assetType"
                      id="standardAsset"
                      value={"aty-001"}
                      type="radio"
                      onChange={(e) => handleChangeRadioButtons({ e, label: "Asset Type" })}
                    />
                    <label>Standard Asset</label>
                  </div>
                  <div>
                    <input
                      name="assetType"
                      checked={formData?.assetType === "aty-002" ? true : false}
                      id="fabricatedAsset"
                      value={"aty-002"}
                      type="radio"
                      onChange={(e) => handleChangeRadioButtons({ e, label: "Asset Type" })}
                    />
                    <label>Fabricated Asset</label>
                  </div>
                </div>
                {errors.assetType && (
                  <span className={Styles.error}>{errors.assetType}</span>
                )}
              </div>
              <div className={Styles.inputFieldContainer}>
                <ClonosInput
                  name="assetMake"
                  isLabel={true}
                  label={"Asset Make"}
                  isMandatory={formData?.assetType === "aty-001"}
                  value={formData?.assetMake}
                  type="text"
                  placeholder="Asset Make"
                  uniqueKey="assetMake"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Asset Make is Required!."}
                />
              </div>
              <div className={Styles.inputFieldContainer}>

                <ClonosInput
                  isLabel={true}
                  label={"Asset Model"}
                  isMandatory={formData?.assetType === "aty-001"}
                  type="text"
                  value={formData?.assetModel}
                  placeholder="Asset Modal"
                  uniqueKey="assetModel"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Asset Model is Required!."}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
                <ClonosInput
                  isLabel={true}
                  label={"Serial Number"}
                  type="text"
                  value={formData?.serialNumber}
                  placeholder="Serial Number"
                  uniqueKey="serialNumber"
                  handleGetValues={handleGetValues}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
                <ClonosInput
                  isLabel={true}
                  label={"Manufacturer"}
                  isMandatory={true}
                  value={formData?.manufacturer}
                  type="text"
                  placeholder="Manufacturer"
                  uniqueKey="manufacturer"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Manufacturer is Required!."}
                />
              </div>
              <div className={Styles.inputFieldContainer}>
                <ClonosInput
                  isLabel={true}
                  label={"Installation Date"}
                  isMandatory={true}
                  value={formData?.installationDate}
                  placeholder="Installation Date"
                  uniqueKey="installationDate"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Installation Date is Required!."}
                  isMinimum={false}
                  type="date"
                />
              </div>
              <div className={Styles.inputFieldContainer}>
                <ClonosInput
                  isLabel={true}
                  label={"Service Liquid"}
                  isMandatory={true}
                  type="text"
                  value={formData?.serviceLiquid}
                  placeholder="Service Liquid"
                  uniqueKey="serviceLiquid"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  errorMessage={"Service Liquid is Required!."}
                />
              </div>
              <div className={Styles.areaDetailsContainer}>
                <h4>Hazardous Area Details</h4>
                <div>
                  <div>
                    <ClonosInput
                      isLabel={true}
                      label={"Zone Classification"}
                      isMandatory={true}
                      type="text"
                      value={formData?.hazardousAreaDetails?.zoneClassification}
                      placeholder="0"
                      uniqueKey="zoneClassification"
                      handleGetValues={handleGetValues}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      errorMessage={"Zone Classification is Required!."}
                      inputStyle={{ border: "none" }}
                    />
                  </div>
                  <div>
                    <ClonosInput
                      isLabel={true}
                      label={"Gas Group"}
                      isMandatory={true}
                      type="text"
                      value={formData?.hazardousAreaDetails?.gasGroup}
                      placeholder="G2"
                      uniqueKey="gasGroup"
                      handleGetValues={handleGetValues}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      errorMessage={"Gas Group is Required!."}
                      inputStyle={{ border: "none" }}
                    />
                  </div>
                  <div>
                    <ClonosInput
                      isLabel={true}
                      label={"Temperature Classification"}
                      isMandatory={true}
                      type="text"
                      value={formData?.hazardousAreaDetails?.temperatureClassification}
                      placeholder="T3"
                      uniqueKey="temperatureClassification"
                      handleGetValues={handleGetValues}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      errorMessage={"Temperature Classification is Required!."}
                      inputStyle={{ border: "none" }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={Styles.manufacturingDetailsRightContainer}>
              <ClonosInput
                isLabel={true}
                label={"Last Calibration Date"}
                isMandatory={true}
                value={formData?.lastCalibrationDate}
                placeholder="Last Calibration Date"
                uniqueKey="lastCalibrationDate"
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                errorMessage={"Last Calibration Date is Required!."}
                isMinimum={false}
                type="date"
              />
              <div className={Styles.inp_sel_container}>
                <label>Calibration Cycle <sup>*</sup></label>
                <div className={Styles.inp_sel_wrapper}>
                  <div className={Styles.inp_wrapper}>
                    <ClonosInput
                      isLabel={false}
                      isMandatory={true}
                      uniqueKey={"calibrationCycle_count"}
                      type={"number"}
                      placeholder={"1234"}
                      handleGetValues={handleGetValues}
                      errorMessage={"Fill this field!"}
                      // defaultValue={!selectedSpare ? formData?.cycleFrequencyCount : selectedSpare?.cycleFrequencyCount}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                  </div>
                  <div className={Styles.sel_wrapper}>
                    <ClonosSelect
                      type={"select"}
                      isMandatory={true}
                      uniqueKey={"calibrationCycle_period"}
                      handleGetValues={handleGetValues}
                      errorMessage={"Fill this field!"}
                      // defaultValue={defaultValue?.cycleFrequencyPeriod?.name}
                      placeholder={"select"}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      options={[{ label: "Cycle", isNeeded: true }]}
                    />
                  </div>
                </div>

              </div>
              <ClonosInput
                isLabel={true}
                label={"Corrosion Check Date"}
                isMandatory={true}
                value={formData?.corrosionCheckDate}
                placeholder="Corrosion Check Date"
                uniqueKey="corrosionCheckDate"
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                errorMessage={"Corrosion Check Date is Required!."}
                isMinimum={false}
                type="date"
              />
              <div className={Styles.inp_sel_container}>
                <label>Corrosion Cycle <sup>*</sup></label>
                <div className={Styles.inp_sel_wrapper}>
                  <div className={Styles.inp_wrapper}>
                    <ClonosInput
                      isLabel={false}
                      isMandatory={true}
                      uniqueKey={"corrosionCycle_count"}
                      type={"number"}
                      placeholder={"1234"}
                      handleGetValues={handleGetValues}
                      errorMessage={"Fill this field!"}
                      // defaultValue={!selectedSpare ? formData?.cycleFrequencyCount : selectedSpare?.cycleFrequencyCount}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                  </div>
                  <div className={Styles.sel_wrapper}>
                    <ClonosSelect
                      type={"select"}
                      isMandatory={true}
                      uniqueKey={"corrosionCycle_period"}
                      handleGetValues={handleGetValues}
                      errorMessage={"Fill this field!"}
                      // defaultValue={defaultValue?.cycleFrequencyPeriod?.name}
                      placeholder={"select"}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      options={[{ label: "Months", isNeeded: true }, { label: "Years", isNeeded: true }]}
                    />
                  </div>
                </div>

              </div>
              <div style={{ display: 'flex', alignItems: 'baseline', gridGap: '1rem' }}>
                <div className={Styles.inp_sel_container}>
                  <label>Design Thickness <sup>*</sup></label>
                  <div style={{ width: "100%" }} className={Styles.inp_sel_wrapper}>
                    <div className={Styles.inp_wrapper}>
                      <ClonosInput
                        isLabel={false}
                        isMandatory={true}
                        uniqueKey={"designThickness_count"}
                        type={"number"}
                        placeholder={"1234"}
                        handleGetValues={handleGetValues}
                        errorMessage={"Fill this field!"}
                        // defaultValue={!selectedSpare ? formData?.cycleFrequencyCount : selectedSpare?.cycleFrequencyCount}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      />
                    </div>
                    <div className={Styles.sel_wrapper}>
                      <ClonosSelect
                        type={"select"}
                        isMandatory={true}
                        uniqueKey={"designThickness_unit"}
                        handleGetValues={handleGetValues}
                        errorMessage={"Fill this field!"}
                        // defaultValue={defaultValue?.cycleFrequencyPeriod?.name}
                        placeholder={"select"}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        options={[{ label: "mm", isNeeded: true }]}
                      />
                    </div>
                  </div>

                </div>
                <div className={Styles.inp_sel_container}>
                  <label>Allowable Thickness <sup>*</sup></label>
                  <div style={{ width: "100%" }} className={Styles.inp_sel_wrapper}>
                    <div className={Styles.inp_wrapper}>
                      <ClonosInput
                        isLabel={false}
                        isMandatory={true}
                        uniqueKey={"allowableThickness_count"}
                        type={"number"}
                        placeholder={"1234"}
                        handleGetValues={handleGetValues}
                        errorMessage={"Fill this field!"}
                        // defaultValue={!selectedSpare ? formData?.cycleFrequencyCount : selectedSpare?.cycleFrequencyCount}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      />
                    </div>
                    <div className={Styles.sel_wrapper}>
                      <ClonosSelect
                        type={"select"}
                        isMandatory={true}
                        uniqueKey={"allowableThickness_unit"}
                        handleGetValues={handleGetValues}
                        errorMessage={"Fill this field!"}
                        // defaultValue={defaultValue?.cycleFrequencyPeriod?.name}
                        placeholder={"select"}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        options={[{ label: "mm", isNeeded: true }]}
                      />
                    </div>
                  </div>

                </div>
              </div>
              <ClonosInput
                isLabel={true}
                label={"MTTR"}
                isMandatory={true}
                value={formData?.mttr}
                placeholder="0"
                uniqueKey="mttr"
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                errorMessage={"MTTR is Required!."}
                type="number"
              />
              <ClonosInput
                isLabel={true}
                label={"MTBF"}
                isMandatory={true}
                value={formData?.mtbf}
                placeholder="0"
                uniqueKey="mtbf"
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                errorMessage={"MTBF is Required!."}
                type="number"
              />
              <ClonosInput
                isLabel={true}
                label={"Last Audit Date"}
                isMandatory={true}
                value={formData?.lastAuditDate}
                placeholder="Last Audit Date"
                uniqueKey="lastAuditDate"
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                errorMessage={"Last Audit Date is Required!."}
                isMinimum={false}
                type="date"
              />
            </div>
          </div>
          <div className={Styles.divBraker}></div>
          <div className={Styles.warrantyDetailsContainer}>
            <div className={Styles.warrantyDetailsLeftContainer}>
              <h4>Warranty Details</h4>
              <div className={Styles.warrantyInclusionBox}>
                <input
                  onChange={() => handleChangeWarrantyInclusion(formData)}
                  name="isWarrantyIncluded"
                  type="checkbox"
                  checked={formData?.isWarrantyIncluded}
                />
                <label className={Styles.clonosLabelStyle}>Warranty Included</label>
              </div>
              <div className={Styles.warrantySubContainer}>
                <div>
                  <ClonosInput
                    isLabel={true}
                    label={"Supplier Name"}
                    isMandatory={formData?.isWarrantyIncluded}
                    value={formData?.supplierName}
                    type="text"
                    placeholder="Supplier Name"
                    uniqueKey="supplierName"
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Supplier Name is Required!."}
                  />
                </div>
                <div>
                  <ClonosInput
                    isLabel={true}
                    label={"Email ID"}
                    isMandatory={formData?.isWarrantyIncluded}
                    value={formData?.supplierEmail}
                    type="email"
                    placeholder="Email ID"
                    uniqueKey="supplierEmail"
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Email ID is Required!."}
                  />
                </div>
                <div>
                  <div className={Styles.wrntTimeContainer}>
                    <div className={Styles.wrntyPeriod}>
                      <label className={Styles.clonosLabelStyle}>
                        Warranty Period{" "}
                        <span
                          style={{
                            display: formData?.isWarrantyIncluded
                              ? "inline-block"
                              : "none",
                            color: "red",
                          }}
                        >
                          *
                        </span>
                      </label>
                      <div>
                        <ClonosInput
                          isMandatory={formData?.isWarrantyIncluded}
                          value={formData?.warrantyPeriodNumber}
                          // placeholder="Warranty Period"
                          type="number"
                          uniqueKey="warrantyPeriodNumber"
                          handleGetValues={handleGetValues}
                          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                          errorMessage={"Required!"}
                          wrapperStyle={{ width: "50%", padding: "0.5rem" }}
                        />

                        <ClonosSelect
                          type="select"
                          placeholder="Select"
                          defaultValue={formData?.warrantyPeriodDurr?.name}
                          isMandatory={formData?.isWarrantyIncluded}
                          options={[
                            { label: "Months", value: "months" },
                            { label: "Years", value: "years" },
                          ]?.map((opt) => ({
                            label: opt?.label,
                            value: opt?.value,
                            isNeeded: true,
                          }))}
                          icon={DOWNANGLE}
                          uniqueKey="warrantyPeriodDurr"
                          errorMessage={"Required!"}
                          handleGetValues={handleGetValues}
                          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                      </div>
                      {errors.warrantyPeriod &&
                        formData?.isWarrantyIncluded &&
                        errors?.warrantyPeriod && (
                          <span className={Styles.error}>
                            {errors.warrantyPeriod}
                          </span>
                        )}
                    </div>
                    <div className={Styles.wrntyEndDate}>
                      <ClonosInput
                        isLabel={true}
                        label="Warranty End Date"
                        isMandatory={formData?.isWarrantyIncluded}
                        defaultValue={formData?.warrantyEndDate}
                        placeholder="Warranty End Date"
                        uniqueKey="warrantyEndDate"
                        handleGetValues={handleGetValues}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        errorMessage={"Warranty End Date is Required!."}
                        type="date"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={Styles.warrantyDetailsRightContainer}>
              <div>
                <FileUploader
                  label={"Terms & Conditions"}
                  title={"assetTermsAndConditions"}
                  typeOfRecord={"File"}
                  isMandatory={false}
                  limit={1}
                  acceptableFileTypes={[".pdf", ".doc", ".xls", ".ppt"]}
                  fileSizeInMB={10}
                  localPreviousPageFiles={
                    formData?.assetTermsAndConditions &&
                      formData?.assetTermsAndConditions.length > 0
                      ? formData?.assetTermsAndConditions
                      : []
                  }
                  handleGetSelectedData={(value) =>
                    handleGetUploadedfiles(value)
                  }
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
