import { ClonosStepper } from "./ClonosStepper";
import Styles from "../../../ModuleStyles/Assets/assets.module.css";
import { checkUserHasPermission, updateLayout } from "../../../utils/clonosCommon";
import { useDispatch, useSelector } from "react-redux";
import { getUser, loginJumpLoadingStopper } from "../../../utils/clonosCommon"
import useToggler from "../../../CustomHooks/TogglerHook"
import { useEffect } from "react"
import { Card } from "@mui/material";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_ASSETS } from "../../../Constants/Constant";

const AssetRegistatration = () => {
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS)
  const [lsLocalLoading, setIsLocalLoading] = useToggler() // Custom Hook which returns boolean value (initial value : "false")
  const logged_user = getUser();
  const dispatch = useDispatch();
  const { mainLayoutChildrenPositionsToolkitState } = useSelector(
    (store) => store.globalEntitiesStateManagement
  );

    useEffect(() => {
        updateLayout({ dispatch });
        let interval = loginJumpLoadingStopper({ setterFunction: setIsLocalLoading, timeout: 5000 })
        return () => {
            clearInterval(interval)
        }
    }, [])
	if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}))
	return <Card variant="outlined" style={{ flex: 1, margin: "1rem", margin: "1rem", overflow: 'scroll' }} bodyStyle={{ height: "100%" }}>
		<div style={{ marginTop: "1rem" }}>
			<ClonosStepper />
		</div>
	</Card>

	return <UnAuthorizedModal type="NOT_AUTHORIZED"/>
}

export default AssetRegistatration;
