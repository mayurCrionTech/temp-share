import { useState,useEffect } from "react";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import DynamicDropdown from "../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";
import Styles from "./location-and-hierarchy.module.css"
import useToggler from "../../../CustomHooks/TogglerHook";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { handleGetFilledValuesOfLocationAndHierarchyDetails, handleSaveLocationAndHierarchyDetails } from "./location-and-hierarchy-manager";
import { ImmediateParentChildAssetTree } from "../Components/ImidiateParentChildAssetTree/ImmediateParentChildAssetTree";
import { StepController } from "../Components/StepController/StepController";
import { useNavigate } from "react-router-dom";
import { handleGetAssetDropdownData } from "../managers/asset-common-managers";
import { commonPageState } from "../../../utils/clonosCommon";
import searchIcon from  '../../../assets/UIUX/icons/search (1).svg'
import { handlePrevious } from "../Specifications/specifications-managers";
import { handleIsAssetEdited } from "../managers/asset-common-managers";

export const LocationAndHierarchy = ({ setGlobalStateOfChildData, globalStateOfChildData, steps, activeStep, setActiveStep, mode }) => {
  
   
  const Navigate = useNavigate()
  const [isLoading, setIsLoading] = useToggler();
  const [changedData, setChangedData] = useState({});
  const [showHierarchyModal, setShowHierarchyModal] = useState(false);
  const [lcLocationAndHierarchyDetails, setLcLocationAndHierarchy] = useState({});
  const [assets,setAssets]=useState({})
  const [assetsPagination,setAssetsPagination] = useState(commonPageState);
  const [searchedAssets,setSeachedAssets] = useState({});
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })
  
  
  const handleSetParent = () => {

  }

  const handleNext = () => {
     const geo = lcLocationAndHierarchyDetails?.geographicalCoordinates || {};
  const hierarchy = lcLocationAndHierarchyDetails?.hierarchy || {};

  const isAssetEdited = Object.keys(geo).length > 0 || Object.keys(hierarchy).length > 0;
    if(isAssetEdited){
      handleSaveLocationAndHierarchyDetails({ checkRequiredField: handleSubmit, setActiveStep, payload: lcLocationAndHierarchyDetails, globalStateOfChildData, setGlobalStateOfChildData, setIsLoading, mode, changedData, Navigate })
    } else {
      setActiveStep(prev => prev + 1)
    }
  }

  const handlePrevious = () => {
    setGlobalStateOfChildData((prev) => {
      return { ...prev, locationAndHierarchyDetails: { ...prev?.locationAndHierarchyDetails, geographicalCoordinates: { ...prev?.locationAndHierarchyDetails?.geographicalCoordinates, ...lcLocationAndHierarchyDetails?.geographicalCoordinates } } }
    });
    setActiveStep(prev => prev - 1)
  }
  const handleHierarchy = (action) => {
    if (action === "remove" || action === "change") {
      setLcLocationAndHierarchy((prev) => ({
        ...prev,
        hierarchy: {
          ...prev?.locationAndHierarchyDetails?.hierarchy,
          parent: null,
        },

      }));
  
      if (action === "change") {
        setShowHierarchyModal(true);
      }
    }
  };
   
  const handleFetchAssetsOnScroll = () => {
        if(assets?.totalPageCount > assetsPagination?.page){
              setAssetsPagination(prev => {
                    handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:{limit:prev?.limit,page:prev?.page + 1}})
                    return {...prev,page:prev?.page+1}
              })
        }
      }


  const handleSearchAsset = ({input}) => {
    
    if(input.length){
          handleGetAssetDropdownData({setterMethod:setSeachedAssets,filterPayload:{...assetsPagination,name:input}})
    } else {
          setSeachedAssets({})
    }
  }

  useEffect(() => {
    handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:assetsPagination})
  },[assetsPagination?.page,assetsPagination?.limit])
  


  useEffect(() => {
    if (globalStateOfChildData?.locationAndHierarchyDetails) {
      const hierarchy = globalStateOfChildData.locationAndHierarchyDetails.hierarchy || {};
      const parent = hierarchy.parent;
  
      setLcLocationAndHierarchy({
        ...globalStateOfChildData.locationAndHierarchyDetails,
        assetName: globalStateOfChildData.generalDetails?.name || "",
        hierarchy: {
          ...hierarchy,
          parent: typeof parent === "object" ? parent.id : parent // always pass ID
        }
      });
    }
  }, [globalStateOfChildData]);
  
  

  return (
    <>
      <div className={Styles.locationContainer}>
        <div className={Styles.locationAndHierarchyLeftContainer}>
          <h4>Location Details</h4>
          <div className={Styles.locDetailsContainer}>
            <div>
              {/* <div className={Styles.geoLocationTitleContainer}>
                <label>
                  Geographical Co-ordinates{" "}
                  <span style={{ color: "red" }}>*</span>
                </label>
                <div className={Styles.arLocationLink}>
                  <p>Get the location from AR</p>
                </div>
              </div> */}
              <div className={Styles.geoLocation}>
                <div>
                  <ClonosInput
                    limit={8}
                    type="number"
                    isLabel={true}
                    label={"Latitude(deg)"}
                    isMandatory={false}
                    defaultValue={globalStateOfChildData?.locationAndHierarchyDetails?.geographicalCoordinates?.latitude}
                    // value={lcLocationAndHierarchyDetails?.geographicalCoordinates?.latitude ? lcLocationAndHierarchyDetails?.geographicalCoordinates?.latitude : globalStateOfChildData?.locationAndHierarchyDetails?.geographicalCoordinates?.latitude}
                    placeholder="Latitude"
                    uniqueKey="latitude"
                    handleGetValues={(props) => handleGetFilledValuesOfLocationAndHierarchyDetails({ propsVal: props,handlePrimaryObjectModifier, setFormData: setLcLocationAndHierarchy, globalStateOfChildData, primaryObject, mode, setChangedData, section: "locationAndHierarchyDetails" })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Latitude is Required!."}
                  />
                </div>
                <div>
                  <ClonosInput
                    limit={8}
                    isLabel={true}
                    label={"Longitude(deg)"}
                    isMandatory={false}
                    defaultValue={globalStateOfChildData?.locationAndHierarchyDetails?.geographicalCoordinates?.longitude}
                    // value={lcLocationAndHierarchyDetails?.geographicalCoordinates?.longitude ? lcLocationAndHierarchyDetails?.geographicalCoordinates?.longitude : globalStateOfChildData?.locationAndHierarchyDetails?.geographicalCoordinates?.longitude}
                    placeholder="Longitude"
                    uniqueKey="longitude"
                    handleGetValues={(props) => handleGetFilledValuesOfLocationAndHierarchyDetails({ propsVal: props, handlePrimaryObjectModifier, setFormData: setLcLocationAndHierarchy, globalStateOfChildData, primaryObject, mode, setChangedData, section: "locationAndHierarchyDetails" })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Longitude is Required!."}
                    type="number"
                  />
                </div>
                <div>
                  <ClonosInput
                    limit={8}
                    isLabel={true}
                    label={"Elevation(m)"}
                    isMandatory={false}
                    defaultValue={globalStateOfChildData?.locationAndHierarchyDetails?.geographicalCoordinates?.elevation}
                    placeholder="Elevation"
                    uniqueKey="elevation"
                    handleGetValues={(props) => handleGetFilledValuesOfLocationAndHierarchyDetails({ propsVal: props, handlePrimaryObjectModifier, setFormData: setLcLocationAndHierarchy, globalStateOfChildData, primaryObject, mode, setChangedData, section: "locationAndHierarchyDetails" })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    errorMessage={"Elevation is Required!."}
                    type="number"
                  />
                </div>
              </div>
            </div>
          </div>
          <h4>Hierarchy</h4>
          {
            (!globalStateOfChildData?.locationAndHierarchyDetails?.hierarchy?.parent &&
            !lcLocationAndHierarchyDetails?.hierarchy?.parent) ? (
              <ClonosButton onClick={() => setShowHierarchyModal(true)}>Set Parent</ClonosButton>
            ) : null
          }

          {
            (globalStateOfChildData?.locationAndHierarchyDetails?.hierarchy?.parent ||
            lcLocationAndHierarchyDetails?.hierarchy?.parent) ? (
              <div className={Styles.currentHierarchyTree}>
                <ImmediateParentChildAssetTree assetGeneralDetails={lcLocationAndHierarchyDetails} />
                <div className={Styles.hierarchyControlers}>
                  <span onClick={() => handleHierarchy("remove")}>Remove Hierarchy</span>
                  <span onClick={() => handleHierarchy("change")}>Change Hierarchy</span>
                </div>
              </div>
            ) : null
          }

        </div>
      </div>
      <DynamicDropdown
            uniqueKey={"parentAsset"}
            labelActivator={""}
            isOpen={showHierarchyModal}
            isOpenMethod={setShowHierarchyModal}
            heading={"Select from Asset Library"}
            placeholder={"Search"}
            isSearchable={true}
            isCheckbox={false}
            isDynamicSearch={true}
            isDynamicLoad={true}
            data={searchedAssets?.data ? searchedAssets?.data : assets?.data || []}
            isActivator={false}
            isMandatory={false}
            url={searchIcon}
            handleMoreData={handleFetchAssetsOnScroll}
            handleGetValues={(props) => handleGetFilledValuesOfLocationAndHierarchyDetails({ propsVal: props, handlePrimaryObjectModifier, setFormData: setLcLocationAndHierarchy, globalStateOfChildData, primaryObject, mode, setChangedData, section: "locationAndHierarchyDetails" })}
            handleDynamicSearch={handleSearchAsset}
          />

      <StepController
        mode={mode}
        steps={steps}
        loading={isLoading}
        handleBack={handlePrevious}
        handleNext={handleNext}
        activeStep={activeStep}
      />
    </>
  );
}