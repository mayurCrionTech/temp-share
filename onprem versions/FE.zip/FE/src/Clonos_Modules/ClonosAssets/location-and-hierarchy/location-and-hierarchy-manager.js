import { limitDecimalDigits, limitLatitude, limitLongitude } from "../../../utils/clonosCommon";
import { handleUpdateAssetDetails } from "../managers/asset-common-managers";

export const handleGetFilledValuesOfLocationAndHierarchyDetails = ({propsVal,handlePrimaryObjectModifier,setFormData,globalStateOfChildData,primaryObject,setChangedData,mode,section}) => {
    let { name, selectedOption, updatedValue, uniqueKey, type } = propsVal;
  
    if (type === "number") {
        const fourDecimalValue = limitDecimalDigits(updatedValue);
        let newValue = Number(updatedValue)
        // if(uniqueKey === "latitude") {
        //     newValue = limitLatitude(newValue);
        // } else if(uniqueKey === "longitude") {
        //     newValue = limitLongitude(newValue);
        // } 
        // newValue = Number(newValue);
        handlePrimaryObjectModifier({ uniqueKey, response: newValue});
        setFormData(prev => {
            let tempGeographicalCoordinates = {...globalStateOfChildData?.locationAndHierarchyDetails?.geographicalCoordinates,...prev?.geographicalCoordinates};
            return {...prev,geographicalCoordinates:{...tempGeographicalCoordinates,[uniqueKey]:newValue}}
        });
        
    }  else if (type === "dynamicDropdown") {
        const selected = selectedOption?.[0];
      
        handlePrimaryObjectModifier({ uniqueKey, response: selected });
      
        setFormData((prev) => ({
          ...prev,
          assetName: globalStateOfChildData?.generalDetails?.name || "",  // Set current asset name (child)
            hierarchy: {
              ...(prev.locationAndHierarchyDetails?.hierarchy || {}),
              parent: selected?.id,
            },
    
        }));
      }    
}


export const validateLocationAndHierarchy = ({data}) => {
    // const {latitude="",longitude="",elevation=""} = data?.geographicalCoordinates || {};
    // return process.env.REACT_APP_CLONOS_GLOBAL_APP_ENVIRONMENT === "PRODUCTION" ?  Boolean(latitude && longitude && elevation) : true
    return true
}


export const handleSaveLocationAndHierarchyDetails = ({checkRequiredField,setActiveStep,payload,globalStateOfChildData,setGlobalStateOfChildData,setIsLoading,mode,changedData,Navigate}) => {
    if(!checkRequiredField()) return 
    const requestPayload = {};
    const next = () => {
        setActiveStep(prev => prev + 1);
        setGlobalStateOfChildData(prev => ({...prev,locationAndHierarchyDetails:{...prev?.locationAndHierarchyDetails,...payload}}));
    }
    handleUpdateAssetDetails({id:globalStateOfChildData?.id,payload:{locationAndHierarchyDetails:payload},setIsLoading,next}) 
}