import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import AppUrl from "../../../utils/AppUrl";
import { doDeleteApiCall, doGetApiCall, doPostApiCall, doPutApiCall } from "../../../utils/ClonosApi"
import { debounce } from "../../../utils/clonosCommon";
import { handleCheckUniqueFieldsMethod } from "../../../utils/common-managers";

const handleCheckUniquenessOfDocuments = ({primaryObject,fieldValue,setFormData,handlePrimaryObjectModifier,uniqueKey}) => {
    if(fieldValue.length === 0) return
    handleCheckUniqueFieldsMethod({ module:"assetDocuments", fieldName:uniqueKey, fieldValue}).then((res) => {
        if (res === "not_unique") {
            setFormData(prev => ({...prev,isDuplicate:true}))
            primaryObject[uniqueKey] = { ...primaryObject?.[uniqueKey], value: false };
            primaryObject?.[uniqueKey]?.errorActivatorMethod(true);
            primaryObject?.[uniqueKey]?.errorSetterMethod(`Already exists, please provide different value.`)
        } else {
            setFormData(prev => ({...prev,isDuplicate:false}))
            handlePrimaryObjectModifier({uniqueKey,response:fieldValue})
            setFormData(prev => ({...prev,[uniqueKey]:fieldValue}))
        }
    })
}

export const debouncedCheckUniquenessOfDocuments = debounce(handleCheckUniquenessOfDocuments,500)

export const handleGetChangedValuesOfAssetDocument = ({mode,elementProps,assetDetails,formData,setFormData,handlePrimaryObjectModifier,primaryObject}) => {
const {e, name, selectedOption, updatedValue, uniqueKey, type } = elementProps;
    if (type === "select") {
        handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
        // setFormData((prev) => ({ ...prev, [uniqueKey]: updatedValue?.label }));
        //CR0001
          setFormData((prev) => ({ ...prev, [uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value} }));
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email") {  
        if(uniqueKey === "name" || uniqueKey === "number") {
            if((mode === "edit" && formData?.serverName !== updatedValue) || mode === "create") {
                debouncedCheckUniquenessOfDocuments({primaryObject,formData,setFormData,fieldValue:updatedValue,handlePrimaryObjectModifier,uniqueKey})
            } else {
                handlePrimaryObjectModifier({ uniqueKey, response: updatedValue, });
                setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
            }
        } else {
            handlePrimaryObjectModifier({ uniqueKey, response: updatedValue, });
            setFormData((prev) => ({ ...prev, [uniqueKey]: updatedValue }));
        }
    }
}


export const handleGetAssetDocuments = ({setterMethod,setIsLoading,assetId,pagination={}}) => {
    setIsLoading();
    doGetApiCall({url:`/assetDocuments`,params:{...pagination,assets:assetId}})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .catch((err) => console.error(err))
    .finally(setIsLoading)
}



export const handleGetAssetCategoryDetails = ({setterMethod,setIsLoading,assetDetails,setLcDocuments}) => {
    setIsLoading();
    doGetApiCall({url:`/assetCategories/${assetDetails?.category}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const documentNames = res?.data?.result?.defaultDocumentNames || [];
            setterMethod(documentNames);
            setLcDocuments && setLcDocuments(documentNames?.map((doc,index) => ({name:`${assetDetails?.number}-${doc}`,id:index+1,fromCategory:true})))
            // setterMethod(["Warranty Document","Data Sheet"])
        }
    })
    .catch((err) => console.error(err))
    .finally(setIsLoading)
}


export const handleCreateDocument =  ({payload,setIsLoading,next}) => {
    
    const requestPayload = handleManipulateRequestPayload(payload)
    
    setIsLoading();
    doPostApiCall({url:AppUrl.createDocument,payload:requestPayload})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
            next && next();
        }
    })
    .catch((err) => console.error(err))
    .finally(setIsLoading)
}


/**
 * 
 * @param {setterMethod} param0 -method to update state with response
 * @param {name} param1 - Field name to fetch enums of.
 */
export const handleGetDocumentEnums = ({setterMethod,name}) => {
    doGetApiCall({url:`/assetDocuments/enums/${name}`})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .catch((err) => console.error(err))
}


export const handleDeleteDocuments = ({payload,setIsLoading,next}) => {
    setIsLoading();
    doDeleteApiCall({url:AppUrl.deleteDocuments,payload})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
            next && next()
        }
    })
    .catch(err => console.error(err))
    .finally(setIsLoading)
}

export const handleUpdateDocument = ({payload,setIsLoading,next}) => {
    const requestPayload = handleManipulateRequestPayload(payload)
    setIsLoading();
    doPutApiCall({url:`/assetDocuments/${payload?.id}`,payload:requestPayload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
            next && next()
        }
    })
    .catch(err => console.error(err))
    .finally(setIsLoading)
}


export const handleManipulateRequestPayload = (payload) => {
    let requestPayload = {};
    const {name,number,revisionNumber,status,type,file,assetId} = payload
    if(name) requestPayload.name = name;
    if(number) requestPayload.number = number;
    if(revisionNumber) requestPayload.revisionNumber = revisionNumber;
    if(status?.name) requestPayload.status = status?.name;
    if(status?.id) requestPayload.statusId = status?.id;
    if(type?.name) requestPayload.type = type?.name;
     if(type?.id) requestPayload.typeId = type?.id;
    if(assetId) requestPayload.asset = assetId;
    if(file?.id) requestPayload.file = file?.id;
    return requestPayload
}

// This function will compare asset category documents with 
export const getCategoryDocumentsNotLinkedWithAsset = ({serverDocuments,assetCategoryDocumentNames}) => {
    if(serverDocuments?.length === 0) return assetCategoryDocumentNames;
    let categoryDocumentsLinkedWithAsset = [];
    serverDocuments?.map((doc) => {
        assetCategoryDocumentNames?.forEach((name) => {
            if(doc?.name?.includes(name)){
                categoryDocumentsLinkedWithAsset.push(name)
            }
        })
    })
 
    return assetCategoryDocumentNames?.filter((name) => !categoryDocumentsLinkedWithAsset.includes(name))
}