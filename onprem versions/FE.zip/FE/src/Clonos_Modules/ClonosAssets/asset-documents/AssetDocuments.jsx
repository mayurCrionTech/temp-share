import { useEffect, useState } from 'react';
import ClonosDataGrid from '../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import { UploadDocumentModal } from '../Components/Documents/UploadDocumentsModal';
import Styles from './asset-documents.module.css'
import { getCategoryDocumentsNotLinkedWithAsset, handleCreateDocument, handleDeleteDocuments, handleGetAssetCategoryDetails, handleGetAssetDocuments, handleUpdateDocument } from './asset-documents-manager';
import { ClonosButton } from '../../../components/CommonComponents/Button/Button';
import EditInteractiveIcon from '../../../resources/icons/interactive/EditInteractiveIcon';
import CircleMinusInteractiveIcon from '../../../resources/icons/interactive/CircleMinusInteractiveIcon';
import ClonosConfirmationBox from '../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import { handleShowErrorAndWarning } from '../../../utils/clonosCommon';
import { useDispatch } from 'react-redux';
import ClonosDocumentViewer from '../../../components/CommonComponents/document-viewer/ClonosDocumentViewer';
import { StepController } from '../Components/StepController/StepController';


export const AssetDocuments = ({assetDetails,modeOfAsset,steps,activeStep,setActiveStep}) => {
    const dispatch = useDispatch();
    const [mode,setMode] = useState(modeOfAsset)
    const [serverDocuments,setServerDocuments] = useState({});
    const [lcDocuments,setLcDocuments] = useState([]);
    const [pagination,setPagination] = useState({page:1,limit:15});
    const [selectedDocument,setSelectedDocument] = useState({})
    const [assetCategoryDocuments,setAssetCategoryDocuments] = useState([]);
    const [lcStates,setLcStates] = useState({
        showUploadDocumentModal:false,
        showDeleteConfirmation:false,
        fetchDocumentsLoader:false,
        fetchAssetCategoryDocumentsLoader:false,
        saveDocumentLoader:false,
        deleteDocumentLoader:false,
        documentToView:null,
        showDocumentViewer:false
    })
    const columns = [
        {
          field: "id",
          headerName: "SI.NO",
          width: 100,
          hideable:"false",
          renderCell: (val) => {
            return (
              <p>
                {val?.row?.index || "-"}
              </p>
            );
          },
        },
        {
          field: "number",
          headerName: "DOCUMENT NUMBER",
          flex: 1,
          renderCell: (val) => {
            return (
              <p>
                {val?.row?.number || "-"}
              </p>
            );
          },
        },
        {
          field: "name",
          headerName: "DOCUMENT NAME",
          flex: 1,
          renderCell: (val) => {
            return (
              <p>
                {val?.row?.name || "-"}
              </p>
            );
          },
        },
        {
          field: "type",
          headerName: "DOCUMENT TYPE",
          flex: 1,
          renderCell: (val) => {
            return (
              <p>
                {val?.row?.type || "-"}
              </p>
            );
          },
        },
        {
          field: "status",
          headerName: "DOCUMENT STATUS",
          flex: 1,
          renderCell: (val) => {
            return (
              <p>
                {val?.row?.status || "-"}
              </p>
            );
          },
        },
        {
          field: "revisionNumber",
          headerName: "REVISION NUMBER",
          flex: 1,
          renderCell: (val) => {
            return (
              <p>
                {val?.row?.revisionNumber || "-"}
              </p>
            );
          },
        },
        {
          field: "viewDoc",
          headerName: "VIEW DOCUMENT",
          flex: 1,
          renderCell: (val) => {
            return (
              <p
              style={{color: val?.row?.file?.name ? "#3f51b5" : "#000",textDecoration: val?.row?.fil?.name ? "underline" : "none",cursor:"pointer"}}
              onClick={() => setLcStates(prev => ({...prev,documentToView:val?.row?.file,showDocumentViewer:true}))}
              >
                {val?.row?.file?.name || "-"}
              </p>
            );
          },
        },
        {
          field: "action",
          headerName: "ACTION",
          flex: 1,
          renderCell: (param) => {
            return param?.row?.fromCategory ? <ClonosButton style={{border:"none"}} onClick={() => {
              setLcStates(prev => ({...prev,showUploadDocumentModal:true}));
              setSelectedDocument(param?.row)
              setMode("create")
            }}>Upload</ClonosButton> 
            :
            <div style={{display:"flex",gridGap:"2rem",alignItems:"center"}}>
                <EditInteractiveIcon size="24" tooltipTitle={"Edit"}
                    onClick={() => {
                        setLcStates(prev => ({...prev,showUploadDocumentModal:true}));
                        setSelectedDocument(param?.row);
                        if(param?.row?.documentNumber) { // if contains documentNumber means document is created.
                            setMode("edit")
                        }
                    }}
                />
                <CircleMinusInteractiveIcon onClick={() => {
                  setLcStates(prev => ({...prev,showDeleteConfirmation:true}));
                  setSelectedDocument(param?.row)
                }}/>
            </div>
        }
        },
      ];

     
    const handleSaveDocumentDetails = ({payload}) => {
     
      const next = () => {
        handleShowErrorAndWarning({dispatch,message:`Document ${mode === "create" ? "uploaded" : "updated"} successfully.`,type:"success",showTime:"5000"});
        setLcStates(prev => ({...prev,showUploadDocumentModal:false}))
        setSelectedDocument({})
        handleGetAssetDocuments({setterMethod:setServerDocuments,setIsLoading:() => setLcStates(prev => ({...prev,fetchDocumentsLoader:!prev.fetchDocumentsLoader})),assetId:assetDetails?.id})
      }

      if(mode === "edit") {
        let requestPayload = {};
        for(let key in payload) {
          if(payload?.[key] && payload[key] !== selectedDocument[key]){
            requestPayload[key] = payload[key]
          }
        }
        handleUpdateDocument({
          payload:{...requestPayload,id:payload?.id,assetId:assetDetails?.id},
          setIsLoading:() => setLcStates(prev => ({...prev,saveDocumentLoader:!prev.saveDocumentLoader})),
          next,
        })
      } else {
        handleCreateDocument({
          payload:{...payload,assetId:assetDetails?.id},
          setIsLoading:() => setLcStates(prev => ({...prev,saveDocumentLoader:!prev.saveDocumentLoader})),
          next
        })
      }
    }


    const handleRemoveDocument = () => {
      handleDeleteDocuments({
      payload:{ids:[selectedDocument?.id]},
      setIsLoading:() => setLcStates(prev => ({...prev,deleteDocumentLoader:!prev.deleteDocumentLoader})),
      next:() => {
        setLcStates(prev => ({...prev,showDeleteConfirmation:false}))
        handleGetAssetDocuments({setterMethod:setServerDocuments,setIsLoading:() => setLcStates(prev => ({...prev,fetchDocumentsLoader:!prev.fetchDocumentsLoader})),assetId:assetDetails?.id})
      }
      })
    }

    
    useEffect(() => {
      // modeOfAsset === "edit" && handleGetAssetDocuments({setterMethod:setServerDocuments,setIsLoading:() => setLcStates(prev => ({...prev,fetchDocumentsLoader:!prev.fetchDocumentsLoader})),assetId:assetDetails?.id})
      // assetDetails?.category && handleGetAssetCategoryDetails({
      //   setterMethod:setAssetCategoryDocuments,
      //   setIsLoading:() => setLcStates(prev => ({...prev,fetchAssetCategoryDocumentsLoader:!prev.fetchAssetCategoryDocumentsLoader})),
      //   assetDetails,
      //   setLcDocuments
      // })

        modeOfAsset === "edit" && handleGetAssetDocuments({setterMethod:setServerDocuments,setIsLoading:() => setLcStates(prev => ({...prev,fetchDocumentsLoader:!prev.fetchDocumentsLoader})),assetId:assetDetails?.id})
      // assetDetails?.category && handleGetAssetCategoryDetails({
      //   setterMethod:setAssetCategoryDocuments,
      //   setIsLoading:() => setLcStates(prev => ({...prev,fetchAssetCategoryDocumentsLoader:!prev.fetchAssetCategoryDocumentsLoader})),
      //   assetDetails,
      //   setLcDocuments
      // })
    },[])

    useEffect(() => {
      serverDocuments?.data?.length && setLcDocuments(getCategoryDocumentsNotLinkedWithAsset({serverDocuments:serverDocuments?.data,assetCategoryDocumentNames:assetCategoryDocuments})?.map((doc,index) => ({name:`${assetDetails?.number}-${doc}`,id:index+1,fromCategory:true})))
    },[serverDocuments?.data?.length])

   

    return <>
        <div className={Styles.associatedDocsContainer}>
        <div className={Styles.associatedDocsSubContainer}>
          <div className={Styles.addRowContainer}>
          <ClonosButton onClick={() => {
            setMode("create")
            setSelectedDocument({})
            setLcStates(prev => ({...prev,showUploadDocumentModal:true}))
          }}>+ Add Document</ClonosButton>
        </div>
          <div className={Styles.datagridContainer}>
              <ClonosDataGrid
                mode={mode}
                rows={[...(serverDocuments?.data || []),...lcDocuments]?.map((doc,index) => ({...doc,index:index+1}))}
                columns={columns}
                hideFooter={true}
                loading={lcStates.fetchDocumentsLoader}
                checkboxSelection={false}
                disableRowSelectionOnClick
                uniqueIdField={"id"}
              />
          </div>
        </div>
      </div>
      {lcStates.showUploadDocumentModal ? 
      <UploadDocumentModal
        mode={mode}
        setMode={setMode}
        data={selectedDocument}
        modeOfAsset={modeOfAsset}
        assetDetails={{...assetDetails,assetCategoryDocuments}}
        loading={lcStates?.saveDocumentLoader}
        open={lcStates.showUploadDocumentModal}
        getFilledDetails={(val) => handleSaveDocumentDetails({payload:val})}
        closeModalMethod={() => setLcStates(prev => ({...prev,showUploadDocumentModal:false}))}
      /> : <></>}
      {lcStates.showDeleteConfirmation 
        ? <ClonosConfirmationBox 
            loading={lcStates?.deleteDocumentLoader} 
            isOpen={lcStates?.showDeleteConfirmation} 
            headerTitle={"Delete Document"} 
            message={"Are you sure you want to Delete?"} 
            closeModalMethod={() => setLcStates(prev => ({...prev,showDeleteConfirmation:false}))} 
            confirmingMethod={handleRemoveDocument} 
          /> 
        : <></>
      }
      {lcStates.documentToView ? <ClonosDocumentViewer isDocument={true} file={lcStates?.documentToView} isOpen={lcStates.showDocumentViewer} closeMethod={() => setLcStates(prev => ({...prev,showDocumentViewer:false}))}/> : <></>}
      <StepController
        mode={mode}
        isSkippable={true}
        steps={steps}
        handleSkip={() => setActiveStep(prev => prev + 1)}
        loading={() =>{}}
        handleBack={() => setActiveStep(prev => prev - 1)}
        activeStep={activeStep}
      />
    </>
}