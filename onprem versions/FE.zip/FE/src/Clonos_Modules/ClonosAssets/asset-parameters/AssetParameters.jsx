import { useEffect, useState } from "react"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import CircleMinusInteractiveIcon from "../../../resources/icons/interactive/CircleMinusInteractiveIcon"
import EditInteractiveIcon from "../../../resources/icons/interactive/EditInteractiveIcon"
import Styles from "./asset-parameters.module.css"
import { commonPageState, handleShowErrorAndWarning } from "../../../utils/clonosCommon"
import { StepController } from "../Components/StepController/StepController"
import { ParameterModal } from "./parameter-modal/ParameterModal"
import { handleCompareEditedParameter, handleCreateParameter, handleDeleteParameters, handleEditParameter, handleGetParameters } from "./asset-parameters.managers"
import { useDispatch } from "react-redux"
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { Tooltip } from "@mui/material"
const AssetParameters = ({assetDetails,modeOfAsset,steps,activeStep,setActiveStep}) => {
  const dispatch = useDispatch()
  const [pagination,setPagination] = useState({...commonPageState})
  const [parameters,setParameters] = useState({});
  const [selectedParameter,setSelectedParameter] = useState({});
  const [mode,setMode] = useState(modeOfAsset);

  const [lcStates,setLcStates] = useState({
    saveLoading:false,
    fetchLoading:false,
    showParameterModal:false,
    parametersLoading:false,
    showConfirmationDailog:false,
    deleteLoading:false
  })

  const modifiedEditAssetParameterData ={
         name:{
          tagId: selectedParameter.tagId,
          name:selectedParameter.name,
          value:selectedParameter.value,
          unit:selectedParameter.unit
         }

  }


  const columns = [
    {
      field:"index",
      headerName:"SI.NO",
      hideable:false
    }, 
    {
        field:"name",
        headerName:"PARAMETER NAME",
        flex:1,
    },
   {
               field: "value",
               headerName: "VALUE",
              //  align: "center",
              //  headerAlign: "center",
               flex: 1,
               renderCell: (val) => {
                 const value = val?.row?.value;
   
                 return (
                   <Tooltip title={value ?? "-"}>
                     <p>
                       {value !== null && value !== undefined
                         ? Number(value).toFixed(3)
                         : "-"}
                     </p>
                   </Tooltip>
                 );
               },
             },
    {
      field:"unit",
      headerName:"UNITS",
      //  align: "center",
      //  headerAlign: "center",
      flex:1
    },
    {
      field:"action",
      headerName:"ACTION",
      width:"200",
      renderCell: (param) => {
          return <div style={{display:"flex",gridGap:"2rem",alignItems:"center"}}>
              <EditInteractiveIcon onClick={() => {
                setMode("edit");
                setLcStates(prev => ({...prev,showParameterModal:true}));
                setSelectedParameter(param?.row)
              }} size="24" tooltipTitle={"Edit"}/>
              <CircleMinusInteractiveIcon onClick={() => {
                setSelectedParameter(param?.row);
                setLcStates(prev => ({...prev,showDeleteDailog:true}))
              }} />
          </div>
      }
    }
  ]

  const handleSaveParameter = (parameter) => {
  
    const next = () => {
      setLcStates(prev => ({...prev,showParameterModal:false}))
      handleShowErrorAndWarning({dispatch,message:`Parameter ${mode === "create" ? "created" : "updated"} successfully`,type:"success",showTime:"5000"})
      handleGetParameters({assetId:assetDetails?.id,setterMethod:setParameters,setIsLoading:() => setLcStates(prev => ({...prev,parametersLoading:!prev.parametersLoading}),pagination)})
    }
    if(mode === "create") {
      handleCreateParameter({assetId:assetDetails?.id,setIsLoading:() => setLcStates(prev => ({...prev,saveLoading:!prev.saveLoading})),payload:parameter,next})
    } else {
       
        const requestPayload = handleCompareEditedParameter({lcParameter:parameter,serverParameter:selectedParameter}) || {};
        if(Object.keys(requestPayload).length === 0){
          setLcStates(prev => ({...prev,showParameterModal:false}));
        } else {
          handleEditParameter({payload:requestPayload,assetId:assetDetails?.id,parameterId:selectedParameter?.id,setIsLoading:() => setLcStates(prev => ({...prev,saveLoading:!prev.saveLoading})),next})
        }
      }
  }

  const handleRemoveParameter = () => {
    const next = () => {
      setLcStates(prev => ({...prev,showDeleteDailog:false}))
      handleShowErrorAndWarning({dispatch,message:`Parameter deleted successfully`,type:"success",showTime:"5000"})
      handleGetParameters({assetId:assetDetails?.id,setterMethod:setParameters,setIsLoading:() => setLcStates(prev => ({...prev,parametersLoading:!prev.parametersLoading}),pagination)})
    } 
    handleDeleteParameters({assetId:assetDetails?.id,payload:{parametersToDelete:[selectedParameter?.id]},setIsLoading:() => setLcStates(prev => ({...prev,deleteLoading:!prev.deleteLoading})),next})
  }

  useEffect(() => {
    mode === "edit" && handleGetParameters({assetId:assetDetails?.id,setterMethod:setParameters,setIsLoading:() => setLcStates(prev => ({...prev,parametersLoading:!prev.parametersLoading})),pagination})
  },[pagination])

  return (
    <>
      <div className={Styles.a_p_container}>
        <header className={Styles.a_p_header}>
          <h4>Parameter</h4>
        </header>
        <div className={Styles.add_param_wrapper}>
          <ClonosButton
            onClick={() => {
              setMode("create");
              setLcStates((prev) => ({ ...prev, showParameterModal: true }));
            }}
          >
            + Add Parameter
          </ClonosButton>
        </div>
        <section className={Styles.a_p_section}>
          <ClonosDataGrid
            columns={columns}
            rows={
              parameters?.data?.length
                ? parameters?.data?.map((param, index) => ({
                    ...param,
                    index: index + 1,
                  }))
                : []
            }
            loading={lcStates.parametersLoading}
            checkboxSelection={false}
            uniqueIdField={"id"}
            totalCount={parameters?.totalDataCount}
            paginationMode={"server"}
            onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
            pageLimit={pagination.limit}
          />
        </section>
      </div>
      {lcStates?.showParameterModal ? (
        <ParameterModal
          mode={mode}
          assetId={assetDetails?.id}
          parameterId={selectedParameter?.id}
          selectedParameter={selectedParameter}
          saveLoading={lcStates.saveLoading}
          modifiedEditAssetParameterData={modifiedEditAssetParameterData}
          isOpen={lcStates.showParameterModal}
          closeMethod={() =>
            setLcStates((prev) => ({
              ...prev,
              showParameterModal: !prev.showParameterModal,
            }))
          }
          getFilledValue={handleSaveParameter}
        />
      ) : (
        <></>
      )}
      {lcStates.showDeleteDailog ? (
        <ClonosConfirmationBox
          loading={lcStates.deleteLoading}
          isOpen={lcStates.showDeleteDailog}
          headerTitle={"Delete Parameter"}
          message={"Are you sure you want to Delete?"}
          closeModalMethod={() => setLcStates(prev => ({...prev,showDeleteDailog:false}))}
          rejectingMethod={() => setLcStates(prev => ({...prev,showDeleteDailog:false}))}
          confirmingMethod={handleRemoveParameter}
        />
      ) : (
        <></>
      )}

      <StepController
        mode={mode}
        steps={steps}
        // loading={isLoading}
        handleBack={() => setActiveStep(prev => prev - 1)}
        handleSkip={() => setActiveStep(prev => prev + 1)}
        isSkippable={true}
        activeStep={activeStep}
      />
    </>
  ); 
}

export default AssetParameters