import { memo } from "react";
import Styles from "./view-parameter.module.css";
import VIEW_ASSET_PARAMETER_GRAY_CHECKBOX from "../../../../resources/svgs/parameters/gray-fill-check.svg";
import VIEW_ASSET_PARAMETER_BLUE_CHECKBOX from "../../../../resources/svgs/parameters/blue-fill-check.svg";
import VIEW_ASSET_PARAMETER_OUTLINED_CHECKBOX from "../../../../resources/svgs/parameters/outlined-square.svg";
import VIEW_ASSET_PARAMETER_ALERT_CIRCLE from "../../../../resources/svgs/parameters/alert-circle.svg";
import { useState } from "react";
import { useEffect } from "react";
import { Card, Tooltip } from "@mui/material";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import { handleGetParameters } from "../asset-parameters.managers";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { setSerialNumber } from "../../../../utils/clonosCommon";

const ViewParameters = ({ assetId }) => {
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useToggler();
  const [pagination, setPagination] = useState({ page: 1, limit: 15 });
  const [parameters, setParameters] = useState({});
  const columns = [
    {
      field: "index",
      headerName: "SI.NO",
      width: "100",
    },
    {
      field: "name",
      headerName: "PARAMETERS",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.name}>
            <p>{val?.row?.name || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "description",
      headerName: "VALUE",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.description}>
            <p>{val?.row?.description || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "unit",
      headerName: "UNIT",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.unit}>
            <p>{val?.row?.unit || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "tracker",
      headerName: "ENABLE TRACKING",
      flex: 1,
      renderCell: (params) => {
        return (
          <div className={Styles.status_tracker}>
            {params?.row?.trackingStatus === "Enabled" ? (
              <div onClick={() => setShowModal(true)}>
                <img src={VIEW_ASSET_PARAMETER_BLUE_CHECKBOX} />
              </div>
            ) : params?.row?.trackingStatus === "Requested" ? (
              <div onClick={() => setShowModal(true)}>
                <img src={VIEW_ASSET_PARAMETER_GRAY_CHECKBOX} />
              </div>
            ) : (
              <div onClick={() => setShowModal(true)}>
                <img src={VIEW_ASSET_PARAMETER_OUTLINED_CHECKBOX} />
              </div>
            )}
          </div>
        );
      },
    },
    {
      field: "trackingStatus",
      headerName: "TRACKING STATUS",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip>
            <p>{"Requested"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "compare",
      headerName: "COMPARE",
      flex: 1,
      renderCell: (params) => {
        return (
          <Tooltip>
            <p>{"Compare"}</p>
          </Tooltip>
        );
      },
    },
  ];

  const handleLiveTracking = () => {};

  useEffect(() => {
    handleGetParameters({assetId,setterMethod: setParameters,setIsLoading,pagination});
  }, [pagination]);

  return (
    <>
      {/* <div className={Styles.v_a_parameters_container}> */}
      {/* <div className={Styles.v_a_parameters_sub_container}> */}
      <Card
        style={{
          flex: 1,
          height: "90%",
          margin: "1rem 1rem 0rem 1rem",
          padding: "1rem",
        }}
      >
        <ClonosDataGrid
          height={600}
          loading={isLoading}
          columns={columns}
          uniqueIdField={"id"}
          checkboxSelection={false}
          pageLimit={pagination?.limit}
          totalCount={parameters?.totalDataCount}
          onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          rows={setSerialNumber(parameters?.data || [],pagination?.page,pagination?.limit)}
        />
      </Card>
      {/* </div> */}
      {/* </div> */}
      <Modal isOpen={showModal} closeModalMethod={setShowModal}>
        <div className={Styles.modal_sub_container}>
          <div className={Styles.modal_header}>
            <div className={Styles.modal_header_content}>
              <div className={Styles.modal_header_content_left}>
                <div>
                  <img src={VIEW_ASSET_PARAMETER_ALERT_CIRCLE} />
                </div>
                <h4>Enable Tracking</h4>
              </div>
              <div className={Styles.modal_header_content_right}>
                <CloseIcon onClick={() => setShowModal(false)} />
              </div>
            </div>
          </div>
          <div className={Styles.modal_content}>
            <div>
              Do you confirm that you need live tracking for this asset ?
            </div>
            <div className={Styles.btn_controller}>
              <ClonosButton
                onClick={() => setShowModal(false)}
                isHollow={true}
                style={{ color: "#E0606A", border: "1px solid #E0606A" }}
                p={"1rem 3rem"}
              >
                Cancel
              </ClonosButton>
              <ClonosButton
                onClick={() => handleLiveTracking()}
                p={"1rem 3rem"}
              >
                Yes
              </ClonosButton>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default memo(ViewParameters);
// handleGetSelectedRowsMethod, pageLimit, isEdit, isDelete, editPermission, deletePermission, createPermission, isEditMethod, isDeleteMethod, isCreateMethod, height, uniqueIdField
