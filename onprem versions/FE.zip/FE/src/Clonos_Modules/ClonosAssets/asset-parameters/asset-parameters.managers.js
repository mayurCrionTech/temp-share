import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import { doDeleteApiCall, doGetApiCall, doPostApiCall, doPutApiCall } from "../../../utils/ClonosApi";
import { debounce } from "../../../utils/clonosCommon";
import { handleCheckUniqueFieldsMethod } from "../../../utils/common-managers";


export const handleGetFilledParameterValue = ({primaryObject,handlePrimaryObjectModifier,parameters,parameter,setLcParameters,setDuplicateParameters,setChangedParamteres,mode,...props}) => {
    const {uniqueKey,updatedValue} = props;
    if(uniqueKey.includes("name")){
        // setLcParameters((prev) => {
        //     let auxParameters = [...prev];
        //     let auxParam = auxParameters[keyIndex-1];
        //     if(isParameterUniqueLocally){
        //         console.log(updatedValue,uniqueKey,"ceck check")
        //         // setDuplicateParameters((prev) => {
        //         //     let duplicateParameters = {...prev};
        //         //     console.log(duplicateParameters,"ceck before");
        //         //     delete duplicateParameters[uniqueKey];
        //         //     console.log(duplicateParameters,"ceck after");
        //         //     return duplicateParameters
        //         // })
        //         handlePrimaryObjectModifier({ uniqueKey, response: updatedValue})
        //         auxParameters[keyIndex-1] = {...auxParam,[uniqueKey]:updatedValue};
        //         if(mode === "edit"){
                    
        //         }
        //     } else {
        //         console.log(uniqueKey,updatedValue,parameters,"one more check");
        //         // handlePrimaryObjectModifier({ uniqueKey, response: null});
        //         auxParameters[keyIndex-1] = {...auxParam,[uniqueKey]:null};
        //         // setDuplicateParameters(prev => ({...prev,[uniqueKey]:true}))
        //         primaryObject[uniqueKey].isNotUnique = true;
        //         primaryObject[uniqueKey].errorSetterMethod("Already exists!");
        //         primaryObject[uniqueKey].errorActivatorMethod(true);
        //     }
        //     console.log(auxParameters,"one more check");
        //     return auxParameters
        // })
        handlePrimaryObjectModifier({ uniqueKey, response: updatedValue})
        // setLcParameters((prev) => {
        //     let auxParameters = [...prev];
        //     const isParameterUniqueLocally = handleCheckUniqunessOfParameterNameLocally({parameterName:updatedValue,parameters:auxParameters});
        //     if(isParameterUniqueLocally){
        //         auxParameters[keyIndex - 1] = {...auxParameters[keyIndex - 1],[uniqueKey]:updatedValue};
        //     } else {
        //         auxParameters[keyIndex - 1] = {...auxParameters[keyIndex - 1],[uniqueKey]:updatedValue};
        //         primaryObject[uniqueKey]?.errorSetterMethod("Already exists!");
        //         primaryObject[uniqueKey]?.errorActivatorMethod(true);
        //     }
        //     if(mode === "edit"){
        //         setChangedParamteres((prev) => {
        //             if(prev?.[keyIndex]){
        //                 return {...prev,[keyIndex]:{...prev[keyIndex],[uniqueKey]:updatedValue}}
        //             } else {
        //                 return {...prev,[keyIndex]:{...auxParameters[keyIndex -1],[uniqueKey]:updatedValue}}
        //             }
        //         })
        //     }
        //     return auxParameters
        // })
        setLcParameters((prev) => {
            return prev?.map((param) => {
                if(param?.localId && param?.localId === parameter?.localId || (param?.id && param?.id === parameter?.id)){
                    return {...param,[uniqueKey.split("_")[0]]:updatedValue}
                } else {
                    return param
                }
            })
        })
    } else {
        handlePrimaryObjectModifier({ uniqueKey, response: updatedValue})
        setLcParameters((prev) => {
            return prev?.map((param) => {
                if(param?.localId && param?.localId === parameter?.localId){
                    return {...param,[uniqueKey.split("_")[0]]:updatedValue}
                } else {
                    return param
                }
            })
        })
    }
    if(mode === "edit"){
        let idToCheck = parameter?.localId || parameter?.id;
        setChangedParamteres((prev) => {
            if(prev?.[idToCheck]){
                return {...prev,[idToCheck]:{...prev?.[idToCheck],[uniqueKey?.split("_")[0]]:updatedValue}}
            } else {
                return {...prev,[idToCheck]:{...parameter,[uniqueKey?.split("_")[0]]:updatedValue}}
            }
        })
    }
}

export const handleCreateParameters = ({assetId,payload,next,setIsLoading}) => {
    const url = `/assets/${assetId}/parameters/bulkCreate`;
    const requestPayload = ModifyParameterPayload({payload})
    setIsLoading();
    doPostApiCall({url,payload:{parameters:requestPayload}})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
            next && next()
        }
    })
    .catch((err) => console.error(err))
    .finally(() => setIsLoading())
}

const ModifyParameterPayload = ({payload}) => {
    let requestPayload = payload?.map((parameter) => {
        const {name,value,unit} = parameter;
        return {name,value,unit}
    });
    return requestPayload
}


export const handleCheckUniqunessOfParameterNameLocally = ({parameterName,parameters}) => {
    let isParameterUnique = true;
    parameters?.forEach((param) => {
        if(param?.[`name_${param?.keyIndex}`] === parameterName){
            isParameterUnique = false;
            return 
        }
    })
    return isParameterUnique
}


export const handleGetParameters = ({assetId,setterMethod,setIsLoading,pagination}) => {
    const url = `assets/${assetId}/parameters`;
    setIsLoading && setIsLoading();
    
    doGetApiCall({url,params:pagination})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .catch((err) => console.error(err))
    .finally(() => setIsLoading && setIsLoading())
}


export const handleEditParameters = async ({payload,assetId,setIsLoading}) => {
    try {
        const url = `/assets/${assetId}/parameters`;
        setIsLoading();
        const response = await doPutApiCall({url,payload});
        if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
            return true
        } else {
            throw new Error("Failed to edit parameters!")
        }
    } catch (error) {
        console.console.error(error);
    } finally {
        setIsLoading();
    }
}



export const handleModifyEditableParameteres = ({payload}) => {
    let parametersToEdit = [];
    let parametersToCreate = [];
    let parametersToDelete = payload?.parametersToDelete || [];
    for(let key in payload){
        if(key !== "parametersToDelete"){
            let name = payload?.[key]?.name;
            let value = payload?.[key]?.value;
            let unit = payload?.[key]?.unit; 
            if(payload[key].id){
                parametersToEdit.push({name,value,unit,id:payload[key]?.id});
            } else {
                parametersToCreate.push({name,value,unit});
            }
        }
    }
    return {parametersToCreate,parametersToEdit,parametersToDelete}
}

export const handleRemoveParameter = ({parameter,setLcParameters,mode,setChangedParamteres}) => {
    setLcParameters((prev) => {
        let temp = prev?.filter((param) => (param?.localId && param?.localId !== parameter?.localId || (param?.id && param?.id !== parameter?.id)));
        return temp
    });
    if(mode === "edit" && parameter?.id) {
        setChangedParamteres((prev) => {
            let tempParametersToDelete = prev?.parametersToDelete ? [...prev?.parametersToDelete]:[];
            return {...prev,parametersToDelete:[...tempParametersToDelete,parameter?.id]}
        })
    }
}   



export const parametersEditHelper = async ({changedData,assetId,setIsLoading}) => {
    const  {parametersToCreate,parametersToEdit,parametersToDelete} = handleModifyEditableParameteres({payload:changedData});
      if(parametersToEdit?.length) {
        const isParametersEdited = await handleEditParameters({assetId,payload:{parametersToEdit},setIsLoading});
      }
      if(parametersToDelete?.length) {
        const isParametersDeleted = await handleDeleteParameters({assetId,payload:{parametersToDelete},setIsLoading})
      }
      if(parametersToCreate?.length) {
        handleCreateParameters({assetId,payload:parametersToCreate,setIsLoading});
      }
}

// export const handleDeleteParameters = async ({payload,assetId,setIsLoading}) => {
//     try {
//         const url = `/assets/${assetId}/parameters`
//         setIsLoading();
//         const response = await doPutApiCall({url,payload});
//         if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
//             return true
//         } else {
//             throw new Error("Failed to edit parameters!")
//         }
//     } catch (error) {
//         console.console.error(error);
//     } finally {
//         setIsLoading();
//     }
// }


export const handleCheckUniquenessOfParameter = ({primaryObject,fieldValue,setterMethod,handlePrimaryObjectModifier,uniqueKey,assetId}) => {
    handleCheckUniqueFieldsMethod({ module:`assets/${assetId}/parameters`, fieldName:"name", fieldValue}).then((res) => {
        if (res === "not_unique") {
            setterMethod(prev => ({...prev,isDuplicate:true}))
            primaryObject.name = { ...primaryObject?.name, value: false };
            primaryObject?.name?.errorActivatorMethod(true);
            primaryObject?.name?.errorSetterMethod(`Already exists, please provide different name!`)
        } else {
            setterMethod(prev => ({...prev,isDuplicate:false}))
            handlePrimaryObjectModifier({uniqueKey,response:fieldValue})
            setterMethod(prev => ({...prev,name:fieldValue}))
        }
    })
}

export const debouncedCheckUniquenessOfParameter = debounce(handleCheckUniquenessOfParameter,500)


export const handleGetFilledValuesOfParameter = ({fieldProps,primaryObject,handlePrimaryObjectModifier,setterMethod,assetId,formData,mode}) => {
    const {type,uniqueKey,updatedValue} = fieldProps;
    if(uniqueKey === "name") {
        if((mode === "edit" && formData?.name !== updatedValue) || mode === "create") {
            debouncedCheckUniquenessOfParameter({primaryObject,fieldValue:updatedValue,setterMethod,handlePrimaryObjectModifier,uniqueKey,assetId})
        } else {
            handlePrimaryObjectModifier({uniqueKey,response: updatedValue})
            setterMethod(prev => ({...prev,[uniqueKey]:updatedValue}))
        }
    } else {
        handlePrimaryObjectModifier({uniqueKey,response: updatedValue})
        setterMethod(prev => ({...prev,[uniqueKey]:updatedValue}))
    }
}


export const handleCreateParameter = ({assetId,setIsLoading,payload,next}) => {
     
    // const requestPayload = handleManipulateParameterPayload({payload});
  
    setIsLoading()
    doPostApiCall({url:`/assets/${assetId}/parameters/`,payload:payload.name})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
            next && next()
        }
    })
    .finally(() => setIsLoading())
}

export const handleGetSingleParameter = ({setterMethod,setIsLoading,assetId,parameterId}) => {
    setIsLoading();
    doGetApiCall({url:`/assets/${assetId}/parameters/${parameterId}`})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

const handleManipulateParameterPayload = ({payload}) => {
    let requestPayload = {};

    // if(payload?.name) requestPayload.name = payload.name;
    // if(payload?.value) requestPayload.value = payload.value;
    // if(payload?.unit) requestPayload.unit = payload.unit;
    // return requestPayload
}


export const handleDeleteParameters = ({assetId,payload,setIsLoading,next}) => {
    const url = `/assets/${assetId}/parameters`;
    setIsLoading();
    doDeleteApiCall({url,payload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
            next && next()
        } else{
            throw new Error("Failed to delete parameters!")
        }
    }).finally(setIsLoading) 
   
}

export const handleCompareEditedParameter = ({lcParameter,serverParameter}) => {
  
    let requestPayload = {};
    const fields = ["name","value","unit"];
    fields.forEach(field => {
        if(lcParameter[field] !== serverParameter[field]) requestPayload[field] = lcParameter[field]
    })
    return requestPayload
}

export const handleEditParameter = ({payload,assetId,parameterId,setIsLoading,next}) => {
      payload = {
         tagId : payload?.name?.tagId
      }
    const url = `/assets/${assetId}/parameters/${parameterId}`;
    setIsLoading();
    doPutApiCall({url,payload:payload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
            next && next();
        } 
    })
    .finally(setIsLoading) 
    
}