import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import Styles from "./single-parametere.module.css";
import CircleMinusIcon from "../../../../resources/icons/static/CircleMinusIcon";
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";
import { useState } from "react";

const SingleParameter = ({ parameter, parameters, getFilledParameterValue, mode, handleRemoveParameter, index }) => {
  const [lcParameter, setLcParameter] = useState({});
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: `parameter_${parameter?.keyIndex}` })

  const handleGetValues = (props) => {
    const { uniqueKey, updatedValue } = props;
    getFilledParameterValue({ uniqueKey, updatedValue });
  };

  return <div className={Styles.container} key={parameter?.localId || parameter?.id}>
    <div className={Styles.input_name_wrapper}>
      <ClonosInput
        limit={50}
        type="text"
        isMandatory={true}
        errorMessage={"Fill this field."}
        uniqueKey={`name_${index}`}
        placeholder={`Parameter ${index}`}
        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
        handleGetValues={(val) => handleGetValues({ ...val, index: index })}
        defaultValue={parameter?.name}
      />
    </div>
    <div className={Styles.input_value_wrapper}>
      <ClonosInput
        limit={10}
        type="text"
        isMandatory={true}
        placeholder={"Value"}
        defaultValue={parameter?.value}
        uniqueKey={`value_${index}`}
        errorMessage={"Fill this field."}
        handleGetValues={(val) => handleGetValues({ ...val, index: index })}
        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      />
    </div>
    <div className={Styles.input_unit_wrapper}>
      <ClonosInput
        limit={10}
        type="text"
        isMandatory={true}
        placeholder={"Unit"}
        defaultValue={parameter?.unit}
        uniqueKey={`unit_${index}`}
        errorMessage={"Fill this field."}
        handleGetValues={(val) => handleGetValues({ ...val, index: index })}
        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      />
    </div>
    <div onClick={() => handleRemoveParameter(parameter)} className="c-pointer" ><CircleMinusIcon /></div>
  </div>

};

export default SingleParameter
