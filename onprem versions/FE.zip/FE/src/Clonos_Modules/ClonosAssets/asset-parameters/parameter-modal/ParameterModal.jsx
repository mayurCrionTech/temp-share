// import React, { useState, useEffect, useCallback ,useRef} from "react";
// import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
// import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
// import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
// import Modal from "../../../../components/CommonComponents/Modal/Modal"
// import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
// import Styles from "./parameter-modal.module.css"
// import { handleGetFilledValuesOfParameter, handleGetSingleParameter } from "../asset-parameters.managers"
// import useToggler from "../../../../CustomHooks/TogglerHook"
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner"
// import ClonosSearchableDropdown from "../../../../components/CommonComponents/ClonosSearchableDropdown/ClonosSearchableDropdown"
// import { doGetApiCall } from "../../../../utils/ClonosApi"
// import { useLocation } from "react-router-dom";
// export const ParameterModal = ({isOpen,parameterId,assetId,modifiedEditAssetParameterData,saveLoading,closeMethod,mode,getFilledValue}) => {
//     const [formData,setFormData] = useState({}); 
//     const [isLoading,setIsLoading] = useToggler()
//     const {primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit } = useFieldsChecker({ isIndexKey: false, })
   
//    const [data, setData] = useState([]);
//   const [page, setPage] = useState(1);
//   const [loading, setLoading] = useState(false);
//   const [hasMore, setHasMore] = useState(false);
//   const [hasEdited,setHasEdited]=useState(false)
//   const currentQuery = useRef("");


// const fetchLiveDataTags = async (query, pageNum = 1) => {
//   if (!query) return;
//   setLoading(true);
//   try {
//     const res = await doGetApiCall({
//       url: `assets/${assetId}/parameters/liveData?tag=${query}&page=${pageNum}`,
//     });

//     console.log(res?.data, "parameterResult");

//     const apiData = res?.data;

//     if (apiData && Array.isArray(apiData.result)) {
//       const results = apiData.result.map((item) => ({
//         tagId: item._id,
//         name: item.tagName,
//         value: item.latestValue,
//         unit: item.unit,
//         updatedAt: item.lastUpdated,
//       }));

//       setData((prev) => (pageNum === 1 ? results : [...prev, ...results]));
//       setHasMore(apiData.result.length > 0);
//     } else {
//       setData([]);
//       setHasMore(false);
//     }
//   } catch (error) {
//     console.error("Error fetching parameters:", error);
//     setData([]);
//     setHasMore(false);
//   } finally {
//     setLoading(false);
//   }
// };


// const handleSearch = (query) => {
//   if (!query) {
//     // ✅ Clear old results when user clears input
//     setData([]);
//     setHasMore(false);
//     return;
//   }

//   // normal API call
//   currentQuery.current = query;
//   setPage(1);
//   fetchLiveDataTags(query, 1);
// };


//   const handleLoadMore = () => {
//     const nextPage = page + 1;
//     setPage(nextPage);
//     fetchLiveDataTags(currentQuery.current, nextPage);
//   };

//     const handleGetValues = (props) => {
//     console.log(primaryObject,'pppp2131')
//         handleGetFilledValuesOfParameter({fieldProps:props,primaryObject,handlePrimaryObjectModifier,setterMethod:setFormData,assetId,formData,mode})
//     }

//     const handleSave = () => {
//         if(formData?.isDuplicate){
//             primaryObject.name = { ...primaryObject?.name, value: false };
//             primaryObject?.name?.errorActivatorMethod(true);
//             primaryObject?.name?.errorSetterMethod(`Already exists, please provide different name!`)
//         }
//         if(!handleSubmit()) return
//         getFilledValue(formData)
//     }

//     useEffect(() => {
//         if(mode === "edit") {
//             // handleGetSingleParameter({setterMethod:setFormData,setIsLoading,parameterId,assetId})
//             setFormData(modifiedEditAssetParameterData)
//         }
//     },[])




//     return (
//       <Modal
//         isOpen={isOpen}
//         closeModalMethod={closeMethod}
//         stopOverlayCloser={true}
//       >
//         <div className={Styles.container}>
//           {isLoading ? (
//             <div style={{height:"318px"}} className="center_wrapper">
//               <ClonosSpinner />
//             </div>
//           ) : (
//             <>
//               <div className={Styles.header}>
//                 <h4>
//                   {mode === "edit" ? "Parameter Edit" : "Parameter Upload"}
//                 </h4>
//                 <CloseIcon onClick={closeMethod} />
//               </div>
//               <div className={Styles.fiels_container}>
//                 <div className={Styles.name_wrapper}>
//                   {/* <ClonosInput
//                     limit={50}
//                     type="text"
//                     isLabel={true}
//                     uniqueKey={"name"}
//                     isMandatory={true}
//                     defaultValue={formData?.name}
//                     label="Parameter Name"
//                     placeholder="Parameter Name"
//                     errorMessage={"Parameter Name is required!"}
//                     handleGetValues={handleGetValues}
//                     handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                   /> */}
   
//                 <ClonosSearchableDropdown
//                   label="Parameter Name"
//                   data={data}
//                   onSearch={handleSearch}
//                   onLoadMore={handleLoadMore}
//                   hasMore={hasMore}
//                   loading={loading}
//                   isMandatory={true}
//                   debounceDelay={500}
//                   uniqueKey={"name"}
//                    placeholder="parameter name - (Ex: FT,TANK)"
//                   defaultValue={mode === "edit" ? modifiedEditAssetParameterData.name : null}
//                   errorMessage="Parameter Name is required!"
//                   handleGetValues={handleGetValues}
//                   handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                   hasEdited={hasEdited}
//                   setHasEdited={setHasEdited}
//                 />

//                 </div>
//                 <div className={Styles.value_unit}>
//                   <label>
//                     Value and Unit <sup style={{ color: "red" }}>*</sup>
//                   </label>
//                   <div>
//                     <ClonosInput
//                       limit={50}
//                       type="text"
//                       isLabel={false}
//                       isMandatory={true}
//                       uniqueKey={"value"}
//                       placeholder="1234"
//                       defaultValue={ formData?.name?.value ?? " "}
//                       disabled={true}
//                       errorMessage={"Value is required!"}
//                       handleGetValues={handleGetValues}
//                       handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />
//                     <ClonosInput
//                       limit={10}
//                       type="text"
//                       isLabel={false}
//                       isMandatory={true}
//                       placeholder={"Unit"}
//                       defaultValue={formData?.name?.unit ?? " "}
//                       uniqueKey={"unit"}
//                       disabled={true}
//                       errorMessage={"Unit is required!"}
//                       handleGetValues={handleGetValues}
//                       handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />
//                   </div>
//                 </div>
//               </div>
//               <div className={Styles.footer}>
//                 <div>
//                   <ClonosButton onClick={closeMethod}>Cancel</ClonosButton>
//                   <ClonosButton
//                     loading={saveLoading}
//                     onClick={handleSave}
//                     variant="filled"
//                   >
//                     Save
//                   </ClonosButton>
//                 </div>
//               </div>
//             </>
//           )}
//         </div>
//       </Modal>
//     );
// }



import React, { useState, useEffect, useCallback ,useRef} from "react";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
import Styles from "./parameter-modal.module.css"
import { handleGetFilledValuesOfParameter, handleGetSingleParameter } from "../asset-parameters.managers"
import useToggler from "../../../../CustomHooks/TogglerHook"
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner"
import ClonosSearchableDropdown from "../../../../components/CommonComponents/ClonosSearchableDropdown/ClonosSearchableDropdown"
import { doGetApiCall } from "../../../../utils/ClonosApi"
import { useLocation } from "react-router-dom";
export const ParameterModal = ({isOpen,parameterId,assetId,modifiedEditAssetParameterData,saveLoading,closeMethod,mode,getFilledValue}) => {
    const [formData,setFormData] = useState({}); 
    const [isLoading,setIsLoading] = useToggler()
    const {primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit } = useFieldsChecker({ isIndexKey: false, })
   
   const [data, setData] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [hasEdited,setHasEdited]=useState(false)
  const currentQuery = useRef("");


const fetchLiveDataTags = async (query, pageNum = 1) => {
  if (!query) return;
  setLoading(true);
  try {
    // const res = await doGetApiCall({
    //   url: `assets/${assetId}/parameters/liveData?tag=${query}&page=${pageNum}`,
    // });
      const res = await doGetApiCall({
      url: `/plcTags?tag=${query}&page=${pageNum}`,
    });

  

    const apiData = res?.data;

    if (apiData && Array.isArray(apiData.data)) {
      const results = apiData.data.map((item) => ({
        tagId: item._id,
        name: item.name,
        value: item.value,
        unit: item.unit,
        // updatedAt: item.lastUpdated,
      }));

      setData((prev) => (pageNum === 1 ? results : [...prev, ...results]));
       setHasMore(pageNum < apiData.totalPages);
      // setHasMore(apiData.result.length > 0);
    } else {
      setData([]);
      setHasMore(false);
    }
  } catch (error) {
    console.error("Error fetching parameters:", error);
    setData([]);
    setHasMore(false);
  } finally {
    setLoading(false);
  }
};


const handleSearch = (query) => {
  if (!query) {
    // ✅ Clear old results when user clears input
    setData([]);
    setHasMore(false);
    return;
  }

  // normal API call
  currentQuery.current = query;
  setPage(1);
  fetchLiveDataTags(query, 1);
};


  const handleLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchLiveDataTags(currentQuery.current, nextPage);
  };

    const handleGetValues = (props) => {

        handleGetFilledValuesOfParameter({fieldProps:props,primaryObject,handlePrimaryObjectModifier,setterMethod:setFormData,assetId,formData,mode})
    }

    const handleSave = () => {
        if(formData?.isDuplicate){
            primaryObject.name = { ...primaryObject?.name, value: false };
            primaryObject?.name?.errorActivatorMethod(true);
            primaryObject?.name?.errorSetterMethod(`Already exists, please provide different name!`)
        }
        if(!handleSubmit()) return
        getFilledValue(formData)
    }

    useEffect(() => {
        if(mode === "edit") {
            // handleGetSingleParameter({setterMethod:setFormData,setIsLoading,parameterId,assetId})
            setFormData(modifiedEditAssetParameterData)
        }
    },[])




    return (
      <Modal
        isOpen={isOpen}
        closeModalMethod={closeMethod}
        stopOverlayCloser={true}
      >
        <div className={Styles.container}>
          {isLoading ? (
            <div style={{height:"318px"}} className="center_wrapper">
              <ClonosSpinner />
            </div>
          ) : (
            <>
              <div className={Styles.header}>
                <h4>
                  {mode === "edit" ? "Parameter Edit" : "Parameter Upload"}
                </h4>
                <CloseIcon onClick={closeMethod} />
              </div>
              <div className={Styles.fiels_container}>
                <div className={Styles.name_wrapper}>
                  {/* <ClonosInput
                    limit={50}
                    type="text"
                    isLabel={true}
                    uniqueKey={"name"}
                    isMandatory={true}
                    defaultValue={formData?.name}
                    label="Parameter Name"
                    placeholder="Parameter Name"
                    errorMessage={"Parameter Name is required!"}
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  /> */}
   
                <ClonosSearchableDropdown
                  label="Parameter Name"
                  data={data}
                  onSearch={handleSearch}
                  onLoadMore={handleLoadMore}
                  hasMore={hasMore}
                  loading={loading}
                  isMandatory={true}
                  debounceDelay={500}
                  uniqueKey={"name"}
                   placeholder="parameter name - (Ex: FT,TANK)"
                  defaultValue={mode === "edit" ? modifiedEditAssetParameterData.name : null}
                  errorMessage="Parameter Name is required!"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  hasEdited={hasEdited}
                  setHasEdited={setHasEdited}
                />

                </div>
                <div className={Styles.value_unit}>
                  <label>
                    Value and Unit <sup style={{ color: "red" }}>*</sup>
                  </label>
                  <div>
                    <ClonosInput
                      limit={50}
                      type="text"
                      isLabel={false}
                      isMandatory={true}
                      uniqueKey={"value"}
                      placeholder="1234"
                      defaultValue={ formData?.name?.value ?? " "}
                      disabled={true}
                      errorMessage={"Value is required!"}
                      handleGetValues={handleGetValues}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                    <ClonosInput
                      limit={10}
                      type="text"
                      isLabel={false}
                      isMandatory={true}
                      placeholder={"Unit"}
                      defaultValue={formData?.name?.unit ?? " "}
                      uniqueKey={"unit"}
                      disabled={true}
                      errorMessage={"Unit is required!"}
                      handleGetValues={handleGetValues}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                  </div>
                </div>
              </div>
              <div className={Styles.footer}>
                <div>
                  <ClonosButton onClick={closeMethod}>Cancel</ClonosButton>
                  <ClonosButton
                    loading={saveLoading}
                    onClick={handleSave}
                    variant="filled"
                  >
                    Save
                  </ClonosButton>
                </div>
              </div>
            </>
          )}
        </div>
      </Modal>
    );
}