import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';

const useStyles = makeStyles((theme) => ({
  searchContainer: {
    width: '100%',
    margin: '0 auto',
    padding: theme.spacing(1, 0),
  },
  search: {
    position: 'relative',
    backgroundColor: '#fff',
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    padding: '4px 12px',
    border: '1px solid #06337E',
    borderRadius: '8px',
  },
  searchIcon: {
    marginRight: theme.spacing(1),
    color: '#888',
  },
  inputRoot: {
    color: '#000',
    flex: 1,
  },
  inputInput: {
    padding: theme.spacing(1, 0),
  },
}));

const AssetSearchBar = ({ setSearchQuery }) => {
  const classes = useStyles();
  const [localQuery, setLocalQuery] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(localQuery);
    }, 500);

    return () => clearTimeout(timer);
  }, [localQuery]);

  return (
    <div className={classes.searchContainer}>
      <div className={classes.search}>
        <SearchIcon className={classes.searchIcon} />
        <InputBase
          placeholder="Search Asset…"
          value={localQuery}
          onChange={(e) => setLocalQuery(e.target.value)}
          classes={{
            root: classes.inputRoot,
            input: classes.inputInput,
          }}
        />
      </div>
    </div>
  );
};


export default AssetSearchBar;