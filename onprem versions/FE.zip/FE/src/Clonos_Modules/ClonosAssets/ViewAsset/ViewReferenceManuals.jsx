import { memo, useEffect } from "react"
import Styles from "../../../ModuleStyles/Assets/assetReferenceManual.module.css";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Accordion, AccordionDetails, AccordionSummary, Tooltip } from "@mui/material";
import { useState } from "react";
import REFERENCE_MANUAL_FILE_TEXT from "../../../assets/UIUX/icons/file-text.svg";
import REFERENCE_MANUAL_MP3 from "../../../assets/UIUX/icons/music.svg";
import REFERENCE_MANUAL_MP4 from "../../../assets/UIUX/icons/movie.svg";
import REFERENCE_MANUAL_DOWNLOAD, { DownloadIcon } from "../../../assets/AssetsSVGComponents/DownloadIcon"
import { getReferenceManualForAsset } from "../../../Api/Asset/assetApi";
import { referenceManualsOptionalParams } from "../../../SharedEnums/ReferencemanualsEnums";
import { handleLoginExpiry, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import { useDispatch } from "react-redux";
import { doGetApiCall } from "../../../utils/ClonosApi";


const ViewReferenceManuals = ({data}) => {
    const [instructionsDocument,setInstructionsDocuments] = useState([]);
    const dispatch = useDispatch()
    // const [instructionsDocument,setInstructionsDocuments] = useState([
    //     {
    //         id:1,
    //         instructionDocumentName:"instructionDocumentName",
    //         instructions : [ {instructionId:11,instructionTitle:"instructionTitle",instructionFile:{name:"videofile.mp4",type:"video"}},{instructionId:12,instructionTitle:"instructionTitle",instructionFile:{name:"videofile.mp4",type:"video"}}]
    //     }
    // ])

    const downloadInstructionFile = async ({assetId,referenceManualId,instructionId,fileName}) =>  {
      try{
        const url = `assets/${assetId}/referenceManuals/${referenceManualId}/instructions/${instructionId}/download`;
        const response = await doGetApiCall(url);
        if(response?.data?.status === 200) {
          const link = document.createElement("a");
          link.href = response?.data?.downloadUrl;
          link.download = fileName;
          link.addEventListener("click", () => {
            document.body.removeChild(link);
          });
          link.click();
        } else {
          throw new Error("Encountered server Error!")
        }
      } catch (err) {
        handleLoginExpiry(err,dispatch);
        if(err?.response?.data?.status !== 401){
          handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.message,showTime:"5000"})
        }
      }     
    }

    useEffect(() => {
      getReferenceManualForAsset(data?._id,referenceManualsOptionalParams).then((res) => {
        setInstructionsDocuments(res?.data?.result?.data[0])
      }).catch((err) => {
        handleLoginExpiry(err,dispatch)
      })
    },[data?._id])
    return <div style={{width:"80%",margin:"auto",padding:"80px"}}>
        {
            // instructionsDocument?.map((doc) => {
                <div key={instructionsDocument?.id} className={Styles.ast_rfml_singledoc}>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <div className={Styles.ast_rfml_doc_header}>
                      <div className={Styles.ast_rfml_doc_header_left}>
                        <div>
                          <img src={REFERENCE_MANUAL_FILE_TEXT} />
                        </div>
                        <p>{instructionsDocument?.name}</p>
                      </div>
                      {/* <div className={Styles.ast_rfml_doc_header_right}>
                        <div>
                          <div onClick={() => handleRemoveDocument(instructionsDocument?.id)}>
                            <img src={REFERENCE_MANUAL_RED_TRASH} />
                          </div>
                        </div>
                      </div> */}
                    </div>
                  </AccordionSummary>
                  <AccordionDetails>
                    <div className={Styles.ast_rfml_instruction_list}>
                      {instructionsDocument?.instructions?.map((instruction, index) => {
                        return (
                          <div key={instruction?.instructionId} className={Styles.ast_rfml_single_instruction}>
                            <div
                              className={Styles.ast_rfml_instruction_text_taker}
                            >
                              <input readOnly value={instruction?.instruction} style={{border:"none"}} />
                            </div>
                            {/* <div className={Styles.ast_rfml_instruction_remover} ><img src={REFERENCE_MANUAL_CREATION_REMOVEROW}/></div> */}
                            {
                              instruction?.originalName ? <div className={Styles.ast_rfml_file_preview}>
                                <div>
                                  <img src={instruction?.extension?.includes("mp4") ? REFERENCE_MANUAL_MP4 : instruction?.extension?.includes("mp3") ? REFERENCE_MANUAL_MP3 : ""} />
                                </div>
                                <Tooltip title={instruction?.originalName}>
                                <p className={Styles.ast_rfml_filename_preview}>
                                {instruction?.originalName}
                                </p>
                                </Tooltip>
                                <div  className={Styles.ast_rfml_instructionfile_remover} onClick={() => downloadInstructionFile({assetId:data?._id,referenceManualId:instructionsDocument?.id,instructionId:instruction?._id,fileName:instruction?.originalName})}>
                                  {/* <img src={REFERENCE_MANUAL_RED_TRASH}/> */}
                                  <DownloadIcon/>
                                </div>
                              </div> : <div className={Styles.ast_rfml_instructionfile_taker_container}>
                              {/* <label
                                htmlFor={`instruction-${index + 1}`}
                                name={`instruction-${index + 1}`}
                              >
                                <div
                                  className={
                                    Styles.ast_rfml_instructionfile_taker
                                  }
                                >
                                  <div>
                                    <img src={REFERENCE_MANUAL_PAPER_CLIP} />
                                  </div>
                                  <p className={Styles.ast_rfml_filename_preview}>Attach File</p>
                                  <input
                                    type="file"
                                    accept="audio/*, video/*"
                                    name={`instruction-${index + 1}`}
                                    id={`instruction-${index + 1}`}
                                  />
                                </div>
                              </label> */}
                            </div>
                            }
                          </div>
                        );
                      })}
                    </div>
                    {/* <div className={Styles.ast_rfml_instruction_controller}>
                      <div  className={Styles.ast_rfml_instruction_controller_btn}>
                        <span>+</span>
                        <span onClick={() => handleAddInstructions({docId:doc?.id})}>
                          Add Instruction
                        </span>
                      </div>
                    </div> */}
                  </AccordionDetails>
                </Accordion>
              </div>
            // })
        }
    </div>
}

export default memo(ViewReferenceManuals)