import { useEffect, useState } from "react"
import { UnderDevelopmentPage } from "../../../components/CommonComponents/UnderDevelopmentPage/UnderDevelopmentPage"
import { getAllScheduledMaintenanceOfAsset } from "../../../Api/ScheduleMaintenance/ScheduleMaintenance"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { commonPageState, getFormatedDate, getYYYYMMDD_Format, setSerialNumber } from "../../../utils/clonosCommon"
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog"
import { Card, Tooltip } from "@mui/material"
import { doGetApiCall } from "../../../utils/ClonosApi"
import useToggler from "../../../CustomHooks/TogglerHook"
import { handleGetMaintenancePlans } from "../../maintenance-plan/maintenance-plan-manager"
import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData"
import { useNavigate } from "react-router-dom"

const ViewMaintenancePlansOfAsset = ({asset}) => {
    const navigate = useNavigate();
    const [maintenancePlansList,setMaintenancePlansList] = useState({});
    const [showConfirmationDailog,setShowConfirmationDailog] = useState(false);
    const [pagination, setPagination] = useState(commonPageState);
    const [isLoading, setIsLoading] = useToggler();
    const columns = [
      {
          field: "index",
          headerName: "SI.NO",
          width: 50,
          hideable: false
      },
      {
          field: "number",
          headerName: "PLAN NUMBER",
          flex:1,
          renderCell: param => <p className='c-pointer' onClick={() => navigate(`/view-maintenance-plan/${param?.row?.name}`, { state: { id: param?.row?.id,name:param?.row?.name,status:param?.row?.status,updatedAt:param?.row?.updatedAt } })} style={{ textDecoration: "underline", color: "#0A5FFF" }}>{param?.row?.number}</p>
      },
      {
          field: "name",
          headerName: "PLAN NAME",
          flex:1,
      },
      {
          field: "assignees",
          headerName: "ASSIGNED USER",
          flex:1,
          renderCell: param => <p>{param?.row?.assignees?.[0]?.name || "-"}</p>
      },
      {
          field: "existingTeams",
          headerName: "TEAM",
          flex:1,
          renderCell: (param) => <p>{param?.row?.existingTeams?.length ? param?.row?.existingTeams?.map(team => team?.name).join(" ,") : "-"}</p>
      },
      {
          field: "departments",
          headerName: "DEPARTMENT",
          flex:1,
          renderCell: (param) => <p>{param?.row?.departments?.[0]?.name || "-"}</p>
      },
      {
          field: 'status',
          headerName: "STATUS",
          flex:1,
          align: 'center',
          headerAlign: 'center',
          renderCell: (param) => {
              return <div style={{background:statusStyleStaticData[param?.row?.status]?.backgroundColor ,color:statusStyleStaticData[param?.row?.status]?.color,padding:"0.4rem 1rem",borderRadius:"6px",fontWeight:"500"}}>{statusStaticData[param?.row?.status]}</div>
          }
      },
      {
          field: "createdAt",
          headerName: "CREATED ON",
          flex:1,
          renderCell: param => <p>{param?.row?.createdAt ? getFormatedDate(param.row.createdAt) : ''}</p>
      },
      {
          field: "updatedAt",
          headerName: "LAST UPDATED ON",
          flex:1,
          renderCell: param => <p>{param?.row?.updatedAt ? getFormatedDate(param.row.updatedAt) : ''}</p>
      }
  ]



    useEffect(() => {
      handleGetMaintenancePlans({setterMethod:setMaintenancePlansList,setIsLoading,filterPayload:{...pagination,asset}})
    },[asset])

    return <> 
        <Card style={{
          flex: 1,
          height:"90%",
          margin:"1rem 1rem 0rem 1rem",
          padding: "1rem",
        }}>
            <div style={{padding:"2rem 4rem",height:"100%"}}>
              <ClonosDataGrid
                    rows={setSerialNumber(maintenancePlansList?.data || [],pagination?.page,pagination?.limit)}
                    columns={columns}
                    pageLimit={pagination.limit}
                    totalCount={maintenancePlansList?.totalDataCount}
                    uniqueIdField={"id"}
                    isEditMethod={false}
                    isDeleteMethod={false}
                    checkboxSelection={false}
                    onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                    isLoading={isLoading}
                />
            </div>
        </Card>
        {/* <ClonosConfirmationDialog open={showConfirmationDailog} CloseDialog={() => setShowConfirmationDailog(false)} Title="Delete Maintenance Task" Content={'Are you sure you want to delete?'} ProceedDialog={() => {}} /> */}
        {/* <UnderDevelopmentPage/> */}
    </>
}

export default ViewMaintenancePlansOfAsset