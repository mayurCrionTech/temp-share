// import {
// 	checkUserHasPermission,
// 	commonPageState,
// 	getFormatedDate,
// 	getUser,
// 	handleClientDateInConfiguredTimeZone,
// 	handleLoggedInUser,
// 	handleLoginExpiry,
// 	handleSegregateURL,
// 	handleShowErrorAndWarning,
// 	modifyString,
// 	setSerialNumber,
// } from "../../../utils/clonosCommon";
// import {
// 	getAllAssetsDataMethod,
// } from "../../../utils/AssetsMethods/AssetsList";
// import { useNavigate } from "react-router-dom";
// import { useDispatch } from "react-redux";
// import React, {useCallback, useEffect, useState } from "react";
// import useToggler from "../../../CustomHooks/TogglerHook";
// import NOIMAGE from "../../../assets/images/noImg.jpg"
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
// import { Card } from "@material-ui/core";
// import { doDeleteApiCall, doGetApiCall, doPutApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";
// import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog";
// import { handleDeleteAsset } from "../../../utils/AssetsMethods/AssetRegister";
// import { commonActions } from "../../../Store/Reducers/CommonReducer";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { AssetsUnderMaintenanceIcon } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
// import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
// import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
// import { assetListSkeletonColumns, assetStatusWithColors } from "../../../utils/AssetsMethods/constants";
// import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
// import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_ASSETS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS } from "../../../Constants/Constant";
// import { AlertRedFilledCircleIcon } from "../../../assets/AssetsSVGComponents/AlertRedFilledCircleIcon";
// import { CompleteAssetAlert } from "../Components/CompleteAssetAlert/CompleteAssetAlert";
// import { statusStyleStaticData } from "../../../Constants/StaticData";
// import { handleGetAssets, handleGetAssetsCounts } from "../Utils/AssetsListMethods";
// import { message } from "antd";
// import MaintenancePlansList from "../../maintenance-plan/MaintenancePlansList";
// import { MaintenancePlansListModal } from "./asset-maintenance-plan/MaintenancePlansListModal";
// import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
// import { useSelector } from "react-redux";
// import AssetSearchBar from "./AssetSearchBar";

// const ClonosGridNav = React.lazy(() => import("../../../utils/ClonosGridNav"))


// const convertMuiFilterModelToApiParams = (filterModel) => {
//   if (!filterModel?.items?.length) return {};

//   const params = {};

//   filterModel.items.forEach(({ field, operator, value }) => {
//     if (value === undefined || value === null || value === "") return;

//     switch (field) {
//       case "number":
//         params.number = value;
//         break;

//       case "name":
//         params.name = value;
//         break;

//       case "assetDepartment":
//         params.department = value;
//         break;

//       case "criticalityLevel":
//         params.criticalityLevel = value;
//         break;

//       case "assetStatus":
//         params.status = Array.isArray(value) ? value.join(",") : value;
//         break;

//     //   case "owner":
//     //     params.owner = value;
//     //     break;
// 	case "owner":
// 	params.owner = value?.id || value;
// 	break;

//     //   case "createdAt":
//     //     params.createdAt = value;
//     //     break;
// 	case "createdAt":
//         const date = new Date(value).toISOString().split("T")[0];
//         params.createdAt = `${date},${date}`;
//         break;

//       default:
//         params[field] = value;
//     }
//   });

//   return params;
// };


// const AssetsList = () => {
// 	const dispatch = useDispatch();
// 	const navigate = useNavigate();
// 	const URL = handleSegregateURL();
//     const [lcStates,setLcStates] = useState({
//         fetchAssetsLoading : false,
//         fetchAssetCountsLoading: false,
//         showMaintenanceModal:false,
//         showIncompleteAsseRegistrationtDetailsModal:false,
//         fetchIncompleteAssetDetailsLoading:false,
//     })
//     const [assetsData,setAssetsData] = useState({});
//     const [assetCounts,setAssetCounts] = useState({});
// 	const [isLoading, setIsLoading] = useToggler();
// 	const [totalCount, setTotalCount] = useState(0);
// 	const [refreshApi, setRefreshApi] = useToggler();
// 	const [selectedRows, setSelectedRows] = useState([]);
// 	const [selectedAsset, setSelectedAsset] = useState({})
// 	const [showDeleteDailog, setShowDeleteDailog] = useToggler();
// 	const [pagination, setPagination] = useState({page:1,limit:15});
// 	const [showFillAssetAlert, setShowFillAssetAlert] = useState(false);
// 	const [selelctedRowAssetId, setSelectedRowAssetId] = useState(null)
// 	const [showMaintenanceModal, setShowMaintenanceModal] = useToggler();
// 	const [showAssetCountsLoading, setShowAssetCountsLoading] = useToggler();
// 	const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS);
// 	 const [searchQuery, setSearchQuery] = useState('');
// 	 // ── NEW: holds the converted filter params from MUI filterModel ──
// 		 const [filterParams, setFilterParams] = useState({});

// 	const [counts, setCounts] = useState({
// 		totalAssets: 0,
// 		activeAssets: 0,
// 		underMaintainanceAssets: 0
// 	});

//     let user = handleLoggedInUser()
//     const userDeparmentId = user?.department?.id
	

// 	const selectedAutoFillAsset=useSelector(
// 		   (store) => store.assetData.selectedAutoFillAsset
// 		)
	
// 	const columns = [
// 		{
// 			field: "index",
// 			headerName: "SI.NO",
// 			width: "50",
// 			disableColumnFilter: true,
//             filterable: false, 
// 			hideable: false
// 		},
// 		{
// 			field: "preview",
// 			headerName: "",
// 			width: "100",
// 			disableColumnFilter: true,
//             filterable: false, 
// 			headerClassName: "ast_column_header",
// 			filterPanelClassName: "ast_column_filterPanel",
// 			renderCell: (params) => {
// 				return <img height={30} width={30} src={params?.row?.assetImages?.length > 0 ? params?.row?.assetImages[0]?.imageUrl : NOIMAGE} />
// 			}
// 		},
// 		{
// 			field: "number",
// 			headerName: "ASSET NUMBER",
// 			flex: 1,
// 			// disableColumnFilter: true,
// 			headerClassName: "ast_column_header",
// 			filterPanelClassName: "ast_column_filterPanel",
// 		renderCell: (params) =>
// 			checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ }) ? (
// 				<div
// 				style={{ cursor: "pointer", color: "#0A5FFF" }}
// 				onClick={() => {
// 					if (userDeparmentId !== params?.row?.generalDetails?.department?.id) {
// 					return handleShowErrorAndWarning({
// 						dispatch,
// 						message: `Access denied: You cannot view assets from ${params?.row?.generalDetails?.department?.name} department.`,
// 						type: "Error",
// 						showTime: "5000",
// 					});
// 					}

// 					navigate(`/view-asset/${params?.row?.generalDetails?.name}`, {
// 					state: {
// 						id: params?.row?.id,
// 						parentId: "",
// 						// activePage,
// 						// limit,
// 					},
// 					});
// 				}}
// 				>
// 				{params?.row?.generalDetails?.number || "-"}
// 				</div>
// 			) : (
// 				<div>{params?.row?.generalDetails?.number || "-"}</div>
// 			)
// 		},
// 		{
// 			field: "incompleteAssetDetails",
// 			headerName: "",
// 			width: "50",
// 			headerClassName: "ast_column_header",
// 			renderCell: (param) => {
// 				return !param?.row?.isRegistrationCompleted ? <div style={{ position: "relative", cursor: "pointer" }} onClick={() => {
// 					setLcStates((prev) => ({...prev,showIncompleteAsseRegistrationtDetailsModal:true}))
// 					setSelectedAsset(param?.row)
// 				}}>
// 					<AlertRedFilledCircleIcon />
// 				</div> : <></>
// 			}
// 		},
// 		{
// 			field: "name",
// 			headerName: "ASSET NAME",
// 			flex: 1,
// 			renderCell:(param) => {
// 				return <p>{param?.row?.generalDetails?.name || "-"}</p>
// 			}
// 		},
// 		{
// 			field: "assetDepartment",
// 			headerName: "DEPARTMENT",
// 			flex: 1,
// 			valueGetter: (params) => params?.row?.generalDetails?.department?.name || "-",
// 		},
// 		{
// 			field: "criticalityLevel",
// 			headerName: "CRITICALITY LEVEL",
// 			 type: 'singleSelect',
//             valueOptions: ['Emergency', 'Critical','Normal'],
// 			flex: 1,
// 			valueGetter: (params) => params?.row?.generalDetails?.criticalityLevel || "-",
// 		},
// 		{
// 			field: "assetStatus",
// 			headerName: "STATUS",
// 			flex: 1,
// 			align: 'center',
// 			headerAlign: 'center',
// 			 type: 'singleSelect',
//             valueOptions: ['Standby', 'Breakdown', 'Under Maintenance','Active'],
// 			renderCell: (param) => {
// 				const status = modifyString(param?.row?.status, "camelcase");
				
// 				return <div style={{ background: statusStyleStaticData[status]?.backgroundColor, color: statusStyleStaticData[status]?.color, padding: "0.4rem 1rem", borderRadius: "6px" }}>{param?.row?.status}</div>
// 			}
// 		},
// 		// {
// 		// 	field: "owner",
// 		// 	headerName: "OWNER",
// 		// 	flex: 1,
// 		// 	valueGetter: (params) => params?.row?.generalDetails?.owner?.name || "-",
// 		// },
// 		{
// 		field: "owner",
// 		headerName: "OWNER",
// 		flex: 1,
// 		valueGetter: (params) => params?.row?.generalDetails?.owner?.name || "-",
// 		valueFormatter: (params) => params?.row?.generalDetails?.owner?.id
// 		},
// 		{
// 			field: "maintenancePlan",
// 			headerName: "MAINTENANCE PLAN",
// 			flex: 1,
// 			 disableColumnFilter: true,
//             filterable: false, 
// 			renderCell: (val) => {
// 				return <>
// 					<div className="c-pointer" style={{ textDecoration: "underline", color: "#0A5FFF",visibility:val?.row?.isMaintenancePresent ? "none":"hidden"  }} onClick={() => {
// 						setLcStates(prev => ({...prev,showMaintenanceModal:true}))
// 						setSelectedRowAssetId(val?.row?.id)
// 					}}>View Maintenance Plan</div>
// 				</>
// 			}
// 		},
// 		{
// 			field: "createdAt",
// 			headerName: "CREATED DATE",
// 			flex: 1,
// 			type: "date",
//             valueGetter: (params) => params?.value ? new Date(params.value) : null,
// 			renderCell: (params) => getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params.row?.createdAt,parseType:"string"})),
// 		},
// 	];

// 	// useEffect(() => {
// 	// 	setIsLoading();
// 	// 	// setAllAssets([]);
// 	// 	doGetApiCall(AppUrl.getAssets, { ...params, ...pagination })
// 	// 		.then(res => {
// 	// 			// setAllAssets(setSerialNumber(res?.data?.result?.data || [], pagination.page, pagination.limit));
// 	// 			setTotalCount(res?.data?.result?.totalDataCount || res?.data?.result?.data?.length || 0);
// 	// 		})
// 	// 		.finally(setIsLoading)
// 	// }, [pagination, refreshApi]);

// 	const doDelete = () => {
// 		setShowDeleteDailog()
// 		const user = getUser();
// 		// setIsLoading();
// 		const payload = { assets: selectedRows};
// 		doDeleteApiCall({url:AppUrl.deleteAssets, payload})
// 			.then((res) => {
// 				if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
// 					handleShowErrorAndWarning({dispatch,message:"Assets deleted successfully.",type:"success",showTime:"5000"})
// 					handleGetAssets({setterMethod:setAssetsData,setIsLoading:() => () => setLcStates((prev) => ({...prev,fetchAssetsLoading:!prev.fetchAssetsLoading})),pagination})
// 				}
// 			})
// 			// .finally(() => setIsLoading())
// 	}

//    // ── NEW: called by ClonosDataGrid whenever the user changes a filter ──
//     const handleFilterModelChange = useCallback((muiFilterModel) => {
//         const converted = convertMuiFilterModelToApiParams(muiFilterModel);
//         setFilterParams(converted);
//         // Reset to page 1 when filters change
//         setPagination((prev) => ({ ...prev, page: 1 }));
//     }, []);

// 	useEffect(() => {
// 	  dispatch(assetActions.resetAssetState());
// 	}, []);


// 	// useEffect(() => {
// 	// 	handleGetAssetsCounts({setterMethod:setAssetCounts,setIsLoading:() => setLcStates((prev) => ({...prev,fetchAssetCountsLoading:!prev.fetchAssetCountsLoading}))});
//     //     handleGetAssets({setterMethod:setAssetsData,setIsLoading:() => () => setLcStates((prev) => ({...prev,fetchAssetsLoading:!prev.fetchAssetsLoading})),pagination})
// 	// }, [pagination]);

// 	useEffect(() => {
// 		handleGetAssetsCounts({setterMethod: setAssetCounts,setIsLoading: () =>setLcStates(prev => ({...prev,fetchAssetCountsLoading: !prev.fetchAssetCountsLoading}))});

// 		const params = {
// 			page: pagination.page,
// 			limit: pagination.limit,
// 			...filterParams
// 		};

// 		// attach search query to pagination
// 		if (searchQuery?.trim()) {
// 			params.name = searchQuery;
// 		}

//   handleGetAssets({ setterMethod: setAssetsData,setIsLoading: () => () => setLcStates(prev => ({ ...prev,fetchAssetsLoading: !prev.fetchAssetsLoading})), pagination: params,});

// }, [pagination, searchQuery]);

// useEffect(() => {
//   if (searchQuery) {
//     setPagination(prev => ({ ...prev, page: 1 }));
//   }
// }, [searchQuery]);




// 	if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
// 		return <>
// 			{
// 				(!URL?.unity && !URL?.AR && !URL?.VR) &&

// 				<ClonosGridNav isLoading={showAssetCountsLoading} items={[
// 					{
// 						icon: TotalAssetsIcon,
// 						iconBg: '#E7EFFF',
// 						title: 'Total Assets',
// 						count: assetCounts?.totalAssets || 0,
// 					},
// 					{
// 						icon: ActiveAssetsIcon,
// 						iconBg: '#EBFAEC',
// 						title: 'Active Assets',
// 						count: assetCounts?.activeAssets || 0
// 					},
// 					{
// 						icon: AssetsUnderMaintenanceIcon,
// 						iconBg: '#F7E9BF',
// 						title: 'Assets under Maintenance',
// 						count: assetCounts?.underMaintainanceAssets || 0
// 					}
// 				]}>
					 
// 					<div className="d-fl-al-cen">
// 						{/* {checkUserHasPermission({ moduleName: 'maintenancePlan', action: CLONOS_GLOBAL_ACTION_CREATE }) ? lcStates.fetchAssetCountsLoading ? <ClonosSkeletonLoading variant="rounded" width="50%" height="40px" animation="wave" /> : <ClonosButton onClick={() => navigate("/create-maintenance-plan")} variant={"outlined"}>Schedule Maintenance Plan</ClonosButton> : <></>} */}
// 						{checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? lcStates.fetchAssetCountsLoading ? <ClonosSkeletonLoading variant="rounded" width="40%" height="40px" animation="wave" /> : <ClonosButton className="ml-half" onClick={() => navigate("/create-asset")} variant={"filled"}>Create New Asset</ClonosButton> : <></>}
// 					</div>
// 				</ClonosGridNav>
// 			}
// 			<Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", padding: "1rem", overflowY: "scroll" }}>
				
// 				 <AssetSearchBar setSearchQuery={setSearchQuery} />


// 				<ClonosDataGrid
// 					rows= {setSerialNumber(assetsData?.data ?? [] ,pagination?.page,pagination?.limit)}
// 					columns={columns}
//                     loading={lcStates?.fetchAssetsLoading}
// 					uniqueIdField={"id"}
// 					pageLimit={pagination.limit}
// 					totalCount={assetsData?.totalDataCount}
// 					handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
// 					isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowDeleteDailog : false}
// 					onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
// 					isEditMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => navigate("/edit-asset", {
// 						state: {
// 							id: selectedRows[0],
// 						}
// 					}) : false}
// 					checkboxSelection={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? true : false}
// 					  // ── NEW: wire up server-side filter ──
//                     filterMode="server"
//                     handleFilterModelChange={handleFilterModelChange}
//                     toolbar={true}   // shows the GridToolbar so users can open the filter panel
// 				/>
// 			</Card>
// 			<ClonosConfirmationBox isOpen={showDeleteDailog} headerTitle={"Delete Asset"} message={"Are you sure you want to Delete?"} closeModalMethod={setShowDeleteDailog} confirmingMethod={doDelete} />
// 			{lcStates.showMaintenanceModal ? <MaintenancePlansListModal asset={selelctedRowAssetId} open={lcStates.showMaintenanceModal} closeModalMethod={() => setLcStates((prev) => ({...prev,showMaintenanceModal:!prev.showMaintenanceModal}))}  /> : <></>}
// 			{lcStates.showIncompleteAsseRegistrationtDetailsModal ? <CompleteAssetAlert isOpen={lcStates.showIncompleteAsseRegistrationtDetailsModal} closeMethod={() => setLcStates(prev => ({...prev,showIncompleteAsseRegistrationtDetailsModal:false}))} asset={selectedAsset} /> : <></>}
// 		</>
// 	}
// 	return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
// }

// export default AssetsList;

/*
date            qid / cr#         comments
16-mar-2026     CR0002            Enable single column filter on the fields visible on these screens

*/

/*
date            qid / cr#         comments
19-mar-2026     CR0008           ASSET import by xlsx

*/
import {
	checkUserHasPermission,
	commonPageState,
	getFormatedDate,
	getUser,
	handleClientDateInConfiguredTimeZone,
	handleLoggedInUser,
	handleLoginExpiry,
	handleSegregateURL,
	handleShowErrorAndWarning,
	modifyString,
	setSerialNumber,
} from "../../../utils/clonosCommon";
import {
	getAllAssetsDataMethod,
} from "../../../utils/AssetsMethods/AssetsList";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import React, {useCallback, useEffect, useState } from "react";
import useToggler from "../../../CustomHooks/TogglerHook";
import NOIMAGE from "../../../assets/images/noImg.jpg"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { Card } from "@material-ui/core";
import { doDeleteApiCall, doGetApiCall, doPutApiCall } from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog";
import { handleDeleteAsset } from "../../../utils/AssetsMethods/AssetRegister";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
import { AssetsUnderMaintenanceIcon } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { assetListSkeletonColumns, assetStatusWithColors } from "../../../utils/AssetsMethods/constants";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_ASSETS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS } from "../../../Constants/Constant";
import { AlertRedFilledCircleIcon } from "../../../assets/AssetsSVGComponents/AlertRedFilledCircleIcon";
import { CompleteAssetAlert } from "../Components/CompleteAssetAlert/CompleteAssetAlert";
import { statusStyleStaticData } from "../../../Constants/StaticData";
import { handleGetAssets, handleGetAssetsCounts } from "../Utils/AssetsListMethods";
import { message } from "antd";
import MaintenancePlansList from "../../maintenance-plan/MaintenancePlansList";
import { MaintenancePlansListModal } from "./asset-maintenance-plan/MaintenancePlansListModal";
import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
import { useSelector } from "react-redux";
import AssetSearchBar from "./AssetSearchBar";

//START
//CR0008
//XLSX
import { IoCloudUploadOutline ,IoDownloadOutline } from "react-icons/io5";//for import asset by xlsx file
import { useRef } from "react";//for import asset by xlsx file
import { doPostApiCall } from "../../../utils/ClonosApi";//for import asset by xlsx file
import Styles from "./view-asset.module.css"//for import asset by xlsx file
import AssetImportTemplate from "../../../Templates/Asset_template.xlsx";//for import asset by xlsx file
//END

const ClonosGridNav = React.lazy(() => import("../../../utils/ClonosGridNav"))


const convertMuiFilterModelToApiParams = (filterModel) => {
  if (!filterModel?.items?.length) return {};

  const params = {};

  filterModel.items.forEach(({ field, operator, value }) => {
    if (value === undefined || value === null || value === "") return;

    switch (field) {
      case "number":
        params.number = value;
        break;

      case "name":
        params.name = value;
        break;

      case "assetDepartment":
        params.department = value;
        break;

      case "criticalityLevel":
        params.criticalityLevel = value;
        break;

      case "assetStatus":
        params.status = Array.isArray(value) ? value.join(",") : value;
        break;

    //   case "owner":
    //     params.owner = value;
    //     break;
	case "owner":
	params.owner = value?.id || value;
	break;

    //   case "createdAt":
    //     params.createdAt = value;
    //     break;
	case "createdAt":
        const date = new Date(value).toISOString().split("T")[0];
        params.createdAt = `${date},${date}`;
        break;

      default:
        params[field] = value;
    }
  });

  return params;
};


const AssetsList = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();
	const URL = handleSegregateURL();
    const [lcStates,setLcStates] = useState({
        fetchAssetsLoading : false,
        fetchAssetCountsLoading: false,
        showMaintenanceModal:false,
        showIncompleteAsseRegistrationtDetailsModal:false,
        fetchIncompleteAssetDetailsLoading:false,
    })
    const [assetsData,setAssetsData] = useState({});
    const [assetCounts,setAssetCounts] = useState({});
	const [isLoading, setIsLoading] = useToggler();
	const [totalCount, setTotalCount] = useState(0);
	const [refreshApi, setRefreshApi] = useToggler();
	const [selectedRows, setSelectedRows] = useState([]);
	const [selectedAsset, setSelectedAsset] = useState({})
	const [showDeleteDailog, setShowDeleteDailog] = useToggler();
	const [pagination, setPagination] = useState({page:1,limit:15});
	const [showFillAssetAlert, setShowFillAssetAlert] = useState(false);
	const [selelctedRowAssetId, setSelectedRowAssetId] = useState(null)
	const [showMaintenanceModal, setShowMaintenanceModal] = useToggler();
	const [showAssetCountsLoading, setShowAssetCountsLoading] = useToggler();
	const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS);
	 const [searchQuery, setSearchQuery] = useState('');
	 // ── NEW: holds the converted filter params from MUI filterModel ──
		 const [filterParams, setFilterParams] = useState({});
 //START
 //CR0008
 //XLSX
	const [importLoading, setImportLoading] = useState(false);//for import asset by xlsx file
	const importInputRef = useRef(null);	 //for import asset by xlsx file
	const [dropdownOpen, setDropdownOpen] = useState(false);//xlsx file
	const dropdownRef = useRef(null);//xlsx file
 //END
	const [counts, setCounts] = useState({
		totalAssets: 0,
		activeAssets: 0,
		underMaintainanceAssets: 0
	});

    let user = handleLoggedInUser()
    const userDeparmentId = user?.department?.id
	

	const selectedAutoFillAsset=useSelector(
		   (store) => store.assetData.selectedAutoFillAsset
		)
	
	const columns = [
		{
			field: "index",
			headerName: "SI.NO",
			width: "50",
			disableColumnFilter: true,
            filterable: false, 
			hideable: false
		},
		{
			field: "preview",
			headerName: "",
			width: "100",
			disableColumnFilter: true,
            filterable: false, 
			headerClassName: "ast_column_header",
			filterPanelClassName: "ast_column_filterPanel",
			renderCell: (params) => {
				return <img height={30} width={30} src={params?.row?.assetImages?.length > 0 ? params?.row?.assetImages[0]?.imageUrl : NOIMAGE} />
			}
		},
		{
			field: "number",
			headerName: "ASSET NUMBER",
			flex: 1,
			// disableColumnFilter: true,
			headerClassName: "ast_column_header",
			filterPanelClassName: "ast_column_filterPanel",
		renderCell: (params) =>
			checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ }) ? (
				<div
				style={{ cursor: "pointer", color: "#0A5FFF" }}
				onClick={() => {
					if (userDeparmentId !== params?.row?.generalDetails?.department?.id) {
					return handleShowErrorAndWarning({
						dispatch,
						message: `Access denied: You cannot view assets from ${params?.row?.generalDetails?.department?.name} department.`,
						type: "Error",
						showTime: "5000",
					});
					}

					navigate(`/view-asset/${params?.row?.generalDetails?.name}`, {
					state: {
						id: params?.row?.id,
						parentId: "",
						// activePage,
						// limit,
					},
					});
				}}
				>
				{params?.row?.generalDetails?.number || "-"}
				</div>
			) : (
				<div>{params?.row?.generalDetails?.number || "-"}</div>
			)
		},
		{
			field: "incompleteAssetDetails",
			headerName: "",
			width: "50",
			headerClassName: "ast_column_header",
			renderCell: (param) => {
				return !param?.row?.isRegistrationCompleted ? <div style={{ position: "relative", cursor: "pointer" }} onClick={() => {
					setLcStates((prev) => ({...prev,showIncompleteAsseRegistrationtDetailsModal:true}))
					setSelectedAsset(param?.row)
				}}>
					<AlertRedFilledCircleIcon />
				</div> : <></>
			}
		},
		{
			field: "name",
			headerName: "ASSET NAME",
			flex: 1,
			renderCell:(param) => {
				return <p>{param?.row?.generalDetails?.name || "-"}</p>
			}
		},
		{
			field: "assetDepartment",
			headerName: "DEPARTMENT",
			flex: 1,
			valueGetter: (params) => params?.row?.generalDetails?.department?.name || "-",
		},
		{
			field: "criticalityLevel",
			headerName: "CRITICALITY LEVEL",
			 type: 'singleSelect',
            valueOptions: ['Emergency', 'Critical','Normal'],
			flex: 1,
			valueGetter: (params) => params?.row?.generalDetails?.criticalityLevel || "-",
		},
		{
			field: "assetStatus",
			headerName: "STATUS",
			flex: 1,
			align: 'center',
			headerAlign: 'center',
			 type: 'singleSelect',
            valueOptions: ['Standby', 'Breakdown', 'Under Maintenance','Active'],
			renderCell: (param) => {
				const status = modifyString(param?.row?.status, "camelcase");
				
				return <div style={{ background: statusStyleStaticData[status]?.backgroundColor, color: statusStyleStaticData[status]?.color, padding: "0.4rem 1rem", borderRadius: "6px" }}>{param?.row?.status}</div>
			}
		},
		// {
		// 	field: "owner",
		// 	headerName: "OWNER",
		// 	flex: 1,
		// 	valueGetter: (params) => params?.row?.generalDetails?.owner?.name || "-",
		// },
		{
		field: "owner",
		headerName: "OWNER",
		flex: 1,
		valueGetter: (params) => params?.row?.generalDetails?.owner?.name || "-",
		valueFormatter: (params) => params?.row?.generalDetails?.owner?.id
		},
		{
			field: "maintenancePlan",
			headerName: "MAINTENANCE PLAN",
			flex: 1,
			 disableColumnFilter: true,
            filterable: false, 
			renderCell: (val) => {
				return <>
					<div className="c-pointer" style={{ textDecoration: "underline", color: "#0A5FFF",visibility:val?.row?.isMaintenancePresent ? "none":"hidden"  }} onClick={() => {
						setLcStates(prev => ({...prev,showMaintenanceModal:true}))
						setSelectedRowAssetId(val?.row?.id)
					}}>View Maintenance Plan</div>
				</>
			}
		},
		{
			field: "createdAt",
			headerName: "CREATED DATE",
			flex: 1,
			type: "date",
            valueGetter: (params) => params?.value ? new Date(params.value) : null,
			renderCell: (params) => getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params.row?.createdAt,parseType:"string"})),
		},
	];

	// useEffect(() => {
	// 	setIsLoading();
	// 	// setAllAssets([]);
	// 	doGetApiCall(AppUrl.getAssets, { ...params, ...pagination })
	// 		.then(res => {
	// 			// setAllAssets(setSerialNumber(res?.data?.result?.data || [], pagination.page, pagination.limit));
	// 			setTotalCount(res?.data?.result?.totalDataCount || res?.data?.result?.data?.length || 0);
	// 		})
	// 		.finally(setIsLoading)
	// }, [pagination, refreshApi]);

	const doDelete = () => {
		setShowDeleteDailog()
		const user = getUser();
		// setIsLoading();
		const payload = { assets: selectedRows};
		doDeleteApiCall({url:AppUrl.deleteAssets, payload})
			.then((res) => {
				if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
					handleShowErrorAndWarning({dispatch,message:"Assets deleted successfully.",type:"success",showTime:"5000"})
					handleGetAssets({setterMethod:setAssetsData,setIsLoading:() => () => setLcStates((prev) => ({...prev,fetchAssetsLoading:!prev.fetchAssetsLoading})),pagination})
				}
			})
			// .finally(() => setIsLoading())
	}

   // ── NEW: called by ClonosDataGrid whenever the user changes a filter ──
    const handleFilterModelChange = useCallback((muiFilterModel) => {
        const converted = convertMuiFilterModelToApiParams(muiFilterModel);
        setFilterParams(converted);
        // Reset to page 1 when filters change
        setPagination((prev) => ({ ...prev, page: 1 }));
    }, []);

	useEffect(() => {
	  dispatch(assetActions.resetAssetState());
	}, []);

		//for import asset by xlsx file
			//start
			//CR0008
			
		useEffect(() => {
			const handleClickOutside = (e) => {
				if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
					setDropdownOpen(false);
				}
			};
			document.addEventListener("mousedown", handleClickOutside);
			return () => document.removeEventListener("mousedown", handleClickOutside);
		}, []);

		const handleDownloadTemplate = () => {
			const a = document.createElement("a");
			a.href = AssetImportTemplate;
			a.download = "Asset_template.xlsx";
			document.body.appendChild(a);
			a.click();
			a.remove();
		};
		const handleImportXlsx = async (e) => {
			const file = e.target.files[0];
			if (!file) return;
			const formData = new FormData();
			formData.append("file", file);
			setImportLoading(true);
			try {
			const res = await doPostApiCall({
				url: "assets/import",
				payload: formData,
				contentType: "multipart/form-data",
			});

			if (res?.data?.result) {
				handleShowErrorAndWarning({
					dispatch,
					message: `Import done: ${res.data.result.insertedCount} inserted, ${res.data.result.failedCount} failed.`,
					type: "success",
					showTime: 6000,
				});
				handleGetAssets({
					setterMethod: setAssetsData,
					setIsLoading: () => () => setLcStates(prev => ({ ...prev, fetchAssetsLoading: !prev.fetchAssetsLoading })),
					pagination,
				});
			} else {
				handleShowErrorAndWarning({ dispatch, message: res?.data?.message || "Import failed", type: "Error", showTime: 5000 });
			}
			
			} catch (err) {
				handleShowErrorAndWarning({ dispatch, message: "Import failed: " + err.message, type: "Error", showTime: 5000 });
			} finally {
				setImportLoading(false);
				e.target.value = "";
			}
		};

		//end
		//for import asset by xlsx file
	// useEffect(() => {
	// 	handleGetAssetsCounts({setterMethod:setAssetCounts,setIsLoading:() => setLcStates((prev) => ({...prev,fetchAssetCountsLoading:!prev.fetchAssetCountsLoading}))});
    //     handleGetAssets({setterMethod:setAssetsData,setIsLoading:() => () => setLcStates((prev) => ({...prev,fetchAssetsLoading:!prev.fetchAssetsLoading})),pagination})
	// }, [pagination]);

	useEffect(() => {
		handleGetAssetsCounts({setterMethod: setAssetCounts,setIsLoading: () =>setLcStates(prev => ({...prev,fetchAssetCountsLoading: !prev.fetchAssetCountsLoading}))});

		const params = {
			page: pagination.page,
			limit: pagination.limit,
			...filterParams
		};

		// attach search query to pagination
		if (searchQuery?.trim()) {
			params.name = searchQuery;
		}

  handleGetAssets({ setterMethod: setAssetsData,setIsLoading: () => () => setLcStates(prev => ({ ...prev,fetchAssetsLoading: !prev.fetchAssetsLoading})), pagination: params,});

}, [pagination, searchQuery]);

useEffect(() => {
  if (searchQuery) {
    setPagination(prev => ({ ...prev, page: 1 }));
  }
}, [searchQuery]);




	if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
		return <>
			{
				(!URL?.unity && !URL?.AR && !URL?.VR) &&

				<ClonosGridNav isLoading={showAssetCountsLoading} items={[
					{
						icon: TotalAssetsIcon,
						iconBg: '#E7EFFF',
						title: 'Total Assets',
						count: assetCounts?.totalAssets || 0,
					},
					{
						icon: ActiveAssetsIcon,
						iconBg: '#EBFAEC',
						title: 'Active Assets',
						count: assetCounts?.activeAssets || 0
					},
					{
						icon: AssetsUnderMaintenanceIcon,
						iconBg: '#F7E9BF',
						title: 'Assets under Maintenance',
						count: assetCounts?.underMaintainanceAssets || 0
					}
				]}>
					 
				{/* //start
				//for import asset by xlsx file */}
				{/* CR0008 */}

				<div className="d-fl-al-cen" style={{ gap: "8px" }}>

					{/* Hidden file input */}
					<input
						ref={importInputRef}
						type="file"
						accept=".xlsx,.xls"
						style={{ display: "none" }}
						onChange={handleImportXlsx}
					/>

					{/* Import loading overlay */}
					{importLoading && (
						<div className={Styles.import_overlay}>
							<div className={Styles.import_overlay_box}>
								<div className={Styles.import_spinner} />
								<p style={{ fontSize: "16px", fontWeight: 600, color: "#333", margin: 0 }}>
									Importing Assets...
								</p>
								<p style={{ fontSize: "13px", color: "#888", margin: 0, textAlign: "center" }}>
									Please wait while your file is being processed.
									<br />Do not close or refresh this page.
								</p>
							</div>
						</div>
					)}

					{/* Create Asset + dropdown */}
					{checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ?
						lcStates.fetchAssetCountsLoading ?
							<ClonosSkeletonLoading variant="rounded" width="40%" height="40px" animation="wave" /> :
							<div
								ref={dropdownRef}
								className={`${Styles.asset_btn_group} ${dropdownOpen ? Styles.dropdown_open : ""}`}
							>
								{/* Dropdown menu — sits below button, button slides up to reveal it */}
								{dropdownOpen && (
									<div className={Styles.asset_dropdown_menu}>
										<div
											className={Styles.asset_dropdown_item}
											onClick={() => { setDropdownOpen(false); importInputRef.current.click(); }}
										>
											<IoCloudUploadOutline size={16} />
											Import Assets
										</div>
										<div
											className={Styles.asset_dropdown_item}
											onClick={() => { setDropdownOpen(false); handleDownloadTemplate(); }}
										>
											<IoDownloadOutline size={16} />
											Download Template
										</div>
									</div>
								)}

								{/* Button row */}
								<div className={Styles.asset_btn_row}>
									<ClonosButton
										variant={"filled"}
										className={Styles.asset_btn_main}
										onClick={() => navigate("/create-asset")}
									>
										Create New Asset
									</ClonosButton>
									<div
										className={`${Styles.asset_btn_arrow} ${dropdownOpen ? Styles.open : ""}`}
										onClick={() => setDropdownOpen(prev => !prev)}
									>
										▾
									</div>
								</div>

							</div>
					: <></>}

				</div>
				{/* END */}
				</ClonosGridNav>
			}
			<Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", padding: "1rem", overflowY: "scroll" }}>
				
				 <AssetSearchBar setSearchQuery={setSearchQuery} />


				<ClonosDataGrid
					rows= {setSerialNumber(assetsData?.data ?? [] ,pagination?.page,pagination?.limit)}
					columns={columns}
                    loading={lcStates?.fetchAssetsLoading}
					uniqueIdField={"id"}
					pageLimit={pagination.limit}
					totalCount={assetsData?.totalDataCount}
					handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
					isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowDeleteDailog : false}
					onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
					isEditMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => navigate("/edit-asset", {
						state: {
							id: selectedRows[0],
						}
					}) : false}
					checkboxSelection={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? true : false}
					  // ── NEW: wire up server-side filter ──
                    filterMode="server"
                    handleFilterModelChange={handleFilterModelChange}
                    toolbar={true}   // shows the GridToolbar so users can open the filter panel
				/>
			</Card>
			<ClonosConfirmationBox isOpen={showDeleteDailog} headerTitle={"Delete Asset"} message={"Are you sure you want to Delete?"} closeModalMethod={setShowDeleteDailog} confirmingMethod={doDelete} />
			{lcStates.showMaintenanceModal ? <MaintenancePlansListModal asset={selelctedRowAssetId} open={lcStates.showMaintenanceModal} closeModalMethod={() => setLcStates((prev) => ({...prev,showMaintenanceModal:!prev.showMaintenanceModal}))}  /> : <></>}
			{lcStates.showIncompleteAsseRegistrationtDetailsModal ? <CompleteAssetAlert isOpen={lcStates.showIncompleteAsseRegistrationtDetailsModal} closeMethod={() => setLcStates(prev => ({...prev,showIncompleteAsseRegistrationtDetailsModal:false}))} asset={selectedAsset} /> : <></>}
		</>
	}
	return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default AssetsList;