import { useEffect, useState } from "react";
import Styles from "../../../ModuleStyles/Assets/viewAsset.module.css";
import { doGetApiCall } from "../../../utils/ClonosApi";
import useToggler from "../../../CustomHooks/TogglerHook";
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
export const ViewHistory = ({assetId}) => {
  const arr = new Array(10).fill(1);
  const [isLoading,setIsLoading] = useToggler();
  const [assetHistory,setAssetHistory] = useState({})

  useEffect(() => {
    setIsLoading()
    doGetApiCall({url:`/assets/${assetId}/history`})
    .then((res) => {
      if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
        setAssetHistory(res?.data?.result)
      }
    })
    .catch((err) => console.error(err))
    .finally(setIsLoading)
  },[])
  
  return (
    <div className={Styles.astHistoryContainer}>
      <div className={Styles.stteper_container}>
        {
          arr?.map((step,index) => {
            return <div className={Styles.step_wrapper}>
            <div className={Styles.left}>12 September 2021</div>
            <div className={Styles.center}>
              <div className={Styles.circle}>{index+1}</div>
              {index < arr.length - 1 && (
                <div className={Styles.line}>
                  <p></p>
                </div>
              )}
            </div>
            <div className={Styles.right}>
              <h5>Purchased On</h5>
              <p>Step Description</p>
            </div>
          </div>
          })
        }
      </div>
    </div>
  );
};
