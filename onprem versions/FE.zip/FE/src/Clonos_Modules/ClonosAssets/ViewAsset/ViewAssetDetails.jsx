import { useEffect, useState } from "react"
import Styles from './view-asset.module.css'
import Subbar from "../../../components/CommonComponents/ClonosSubbar/Subbar"
import QRCodeStaticIcon from "../../../resources/icons/static/QRCodeStaticIcon"
import { handleChangeAssetStatus, handleDeleteAsset, handleGetSingleAssetDetails , handleGetHierarchyDetails } from "../managers/asset-common-managers";
import useToggler from "../../../CustomHooks/TogglerHook";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { useLocation, useNavigate } from "react-router-dom";
import { Card } from "@mui/material";
import { AssetStatusDropdown } from "../Components/asset-status-dropdown/AssetStatusDropdown";
import CommonNavigator from "../../../components/CommonComponents/Navigator/Navigator";
import { VIEW_ASSET_COMMON_NAVIGATORS_VALUES } from "../AssetConstants";
import { ViewCoreDetails } from "../view-asset/view-core-details/ViewCoreDetail";
import { checkUserHasPermission, getFormatedDate, handleLoginExpiry, handleMakeCamelCase, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import { useDispatch } from "react-redux";
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE } from "../../../Constants/Constant";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { QRCodeModal } from "../../../components/CommonComponents/QRCodeModal/QRCodeModal";
import { doGetApiCall } from "../../../utils/ClonosApi";
import { ViewAssetSpares } from "../asset-spares/view-asset-spares/ViewAssetSpares";
import { ViewAssetHistory } from "../view-asset/view-asset-history/ViewAssetHistory";
import { AssetApprovalModal } from "../asset-approval-modal/AssetApprovalModal";
import { ViewAssetDocuments } from "../view-asset/view-asset-documents/ViewAssetDocuments";
import ViewAssetParameter from "../view-asset/view-asset-parameters/ViewAssetParameter";
import ViewMaintenancePlanOfAsset from "./ViewMaintenancePlan";
 // #160 
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";

/*
    date            qid / cr#         comments
    07-Apr-2026     #160             Broken Access Control - Permission Restriction FrontEnd
    */
const ViewAssetDetails = () => {
    const dispatch = useDispatch();
    const Location = useLocation();
    const Navigate = useNavigate();
    const [assetDetails, setAssetDetails] = useState({});
    const [hierarchyDetails,setHierarchyDetails]=useState({})
    const [showDeleteDailog,setShowDeleteDailog] = useToggler();
    const [showQRCodeModal, setShowQRCodeModal] = useState(false);
    const [qrCodeDetails, setQrCodeDetails] = useState(null)
    const [lcModifiedData, setLcModifiedData] = useState({});
    const [activeTab, setActiveTab] = useState("Details");
    const [statusChangeLoader,setStatusChangeLoader] = useToggler();
    const [fetchDetailsLoading, setFetchDetailsLoading] = useToggler();
    const [showApprovalModal,setShowApprovalModal] = useState(false);
    const [lcLocationAndHierarchyDetails, setLcLocationAndHierarchy] = useState({});
    const [navigatorValues, setNavigatorValues] = useState(VIEW_ASSET_COMMON_NAVIGATORS_VALUES);
     // #160 
    const [isUnauthorized, setIsUnauthorized] = useState(false);
    
    
    
    useEffect(()=>{
        if(assetDetails?.locationAndHierarchyDetails){
          const hierarchy = assetDetails.locationAndHierarchyDetails.hierarchy || {};
          const parent = hierarchy.parent;
  
          setLcLocationAndHierarchy({
            ...assetDetails.locationAndHierarchyDetails,
            assetName: assetDetails.generalDetails?.name || "",
            hierarchy: {
              ...hierarchy,
              parent: typeof parent === "object" ? parent.id : "" // always pass ID
            }
          });
        }
    },[assetDetails])


    const changeStatusHelper = async ({value}) => {
        const isStatusChanged = await handleChangeAssetStatus({statusToChange:value,id:Location?.state?.id,setIsLoading:setStatusChangeLoader});
        if(isStatusChanged) {
            handleGetSingleAssetDetails({ assetId: Location?.state?.id, setterMethod: setAssetDetails, setIsLoading: setFetchDetailsLoading, setLcModifiedData })           
        }
    }

    // const handleQRCodeView = async () => {
    //     if (qrCodeDetails === null) {
    //         setShowQRCodeModal(true);
    //       const url = `assets/${assetDetails?.id}/qrcode`;
    //       try {
    //         const response = await doGetApiCall({url});
    //         // const dataUrl = `data:image/png;base64,${Buffer.from(response.data).toString('base64')}`;
    //         setQrCodeDetails(response?.data?.result.url)
    //       } catch (err) {
    //         handleLoginExpiry(err, dispatch);
    //         if (err?.response?.data.status !== 401) {
    //           handleShowErrorAndWarning(({ dispatch, type: "error", message: "Failed to fetch QR Code Details!", showTime: "5000" }))
    //         }
    //       }
    //     }
    //   }

    const handleQRCodeView = async () => {
  setShowQRCodeModal(true); // always open modal

  if (!qrCodeDetails) { // fetch only if not already fetched
    const url = `assets/${assetDetails?.id}/qrcode`;
    try {
      const response = await doGetApiCall({ url });
      setQrCodeDetails(response?.data?.result?.url);
    } catch (err) {
      handleLoginExpiry(err, dispatch);
      if (err?.response?.data?.status !== 401) {
        handleShowErrorAndWarning({
          dispatch,
          type: "error",
          message: "Failed to fetch QR Code Details!",
          showTime: 5000,
        });
      }
    }
  }
};


    useEffect(() => {
       // #160 
           if (!Location?.state) {
        setIsUnauthorized(true);
        return;
     }
        handleGetSingleAssetDetails({ assetId: Location?.state?.id, setterMethod: setAssetDetails, setIsLoading: setFetchDetailsLoading, setLcModifiedData })
    }, [Location?.state?.id])


    useEffect(()=>{
        handleGetHierarchyDetails({assetId: Location?.state?.id, setterMethod:setHierarchyDetails, setIsLoading: setFetchDetailsLoading})
    },[])
    // #160 
    if (isUnauthorized) {
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
    }

    return <>
        {
            (fetchDetailsLoading || statusChangeLoader) ?
                <div style={{ width: "100%", height: "80px", background: "#FFF", padding: '1rem 2rem', display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <ClonosSkeletonLoading variant="rounded" width="20%" height="40px" animation="wave" />
                    <ClonosSkeletonLoading variant="rounded" width="15%" height="40px" animation="wave" />
                </div>
                :
                <Subbar
                    isStatus={true}
                    isEditMethod={checkUserHasPermission({ moduleName: "assets", action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => Navigate("/edit-asset", { state: { id: assetDetails?.id } }) : false}
                    isDeleteMethod={checkUserHasPermission({ moduleName: "assets", action: CLONOS_GLOBAL_ACTION_DELETE }) ? () =>  setShowDeleteDailog() : false}
                    subbarData={{ status: assetDetails?.status }}
                    htmlElements={[<div onClick={() => handleQRCodeView()}><QRCodeStaticIcon /></div>,<div style={{width:"200px"}}><AssetStatusDropdown currentStatus={assetDetails?.status} getSelectedValue={(val) => changeStatusHelper({value:val?.value})} label={"Asset Status"}/></div>]}
                    staticElements={[{ key: "Created On :", value: assetDetails?.createdAt ? getFormatedDate(assetDetails?.createdAt) : "" }, { key: "Last Updated On :", value: assetDetails?.updatedAt ? getFormatedDate(assetDetails?.updatedAt) : "" }]}
                />
        }
        <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem",overflowY:"scroll" }}>
            <div style={{ height: "10%" }}>
                {/* <CommonNavigator
                    web={true}
                    values={VIEW_ASSET_COMMON_NAVIGATORS_VALUES}
                    getSelectedValue={(val) => setActiveTab(val)}
                /> */}
               <CommonNavigator
                web={true}
                values={navigatorValues}
                getSelectedValue={(val) => setActiveTab(val)}
              />

            </div>
            {activeTab === "Details" && <ViewCoreDetails assetDetails={assetDetails} hierarchyDetails={hierarchyDetails} locationAndHierarchyDetails={lcLocationAndHierarchyDetails} />}
            {activeTab === "Parameters" && <ViewAssetParameter assetId={assetDetails?.id} />}
            {activeTab === "Spares" && <ViewAssetSpares assetId={assetDetails?.id} />}
            {activeTab === "History" && <ViewAssetHistory assetId={assetDetails?.id} setNavigatorValues={setNavigatorValues} setActiveTab={setActiveTab}/>}
            {activeTab === "Documents" && <ViewAssetDocuments assetId={assetDetails?.id}/>}
            {activeTab === "Maintenance Plan" && <ViewMaintenancePlanOfAsset asset={assetDetails?.id}/>}
        </Card>
        <QRCodeModal Open={showQRCodeModal} CloseDialog={() => setShowQRCodeModal(false)} assetId={assetDetails?.id} qrCodeDetails={qrCodeDetails} />
        <ClonosConfirmationBox isOpen={showDeleteDailog} headerTitle={"Delete Asset"} message={"Are you sure you want to Delete?"} closeModalMethod={setShowDeleteDailog} confirmingMethod={() => handleDeleteAsset({ payload: [assetDetails?.id], next: () => Navigate("/assets"), dispatch })} />
        <AssetApprovalModal isOpen={showApprovalModal} closeMethod={() => setShowApprovalModal(false)} heading={"Delete Asset"}/>
    </>
}

export default ViewAssetDetails