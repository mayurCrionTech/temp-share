import Styles from './MaintenancePlansListModal.module.css'
import searchIcon from "../../../../assets/UIUX/icons/WO/search-1.svg"
import closeIcon from "../../../../assets/UIUX/icons/WO/circle-x-filled.svg"
import ClonosSpinner from "../../../../assets/Clonos Common Indicators/Clonos_Spinner.svg"
import { useEffect, useState } from 'react';
import Modal from '../../../../components/CommonComponents/Modal/Modal';
import { getFormatedDate, globalOnScrollEnd, handleLoginExpiry, handleShowErrorAndWarning, showErrorMessage } from '../../../../utils/clonosCommon';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import useDebounce from '../../../../CustomHooks/DebounceHook';
import { handleGetMaintenancePlans } from '../../../maintenance-plan/maintenance-plan-manager';
import { statusStaticData } from '../../../../Constants/StaticData';
export const MaintenancePlansListModal = ({ open, asset, closeModalMethod }) => {
    const [maintenancePlans, setMaintenancePlans] = useState({})
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const Navigate = useNavigate()
    const dispatch = useDispatch();
    const debouncedValue = useDebounce(inputValue, 500);


    const handleInputChange = (e) => {
        const { value } = e.target;
        setInputValue(value)
    };

    const handleNavigate = (task) => {
        Navigate(`/view-maintenance-plan/${task?.name}`, { state: { id:task?.id,status:task?.status,updatedAt:task?.updatedAt } })
    }

    const handleDataOnScroll = () => {
        // handleGetMaintenancePlans({setterMethod:setMaintenancePlans,setIsLoading,filterPayload:{name:debouncedValue}})
    }

    // useEffect(() => {
    //     if (open) {
    //         handleGetMaintenancePlans({setterMethod:setMaintenancePlans,setIsLoading,filterPayload:{name:debouncedValue}})
    //     }
    // }, [open]);

    useEffect(() => {
         
            handleGetMaintenancePlans({setterMethod:setMaintenancePlans,setIsLoading,filterPayload:{name:debouncedValue,asset}})
    }, [debouncedValue])

    return (
        <Modal isOpen={open} closeModalMethod={() => closeModalMethod(false)}>
            <div className={Styles.dd_body}>
                <header className={Styles.ddb_header}> {/* ddb: dynamic dropdown body */}
                    <span>Select From Maintenance Plan</span>
                    <div><img onClick={() => closeModalMethod(false)} src={closeIcon} alt='Close Button' /></div>
                </header>

                <section>
                    <div>
                        <div className={Styles.ddb_search} >
                            <img src={searchIcon} alt="Search" />
                            <input
                                placeholder={"Search"}
                                value={inputValue}
                                onChange={handleInputChange}
                            />
                        </div>
                    </div>
                    <div id="mt_scroller_area" className={Styles.ddb_content} onScroll={() => globalOnScrollEnd({ callback: handleDataOnScroll, idName: "mt_scroller_area" })}>
                        {
                            maintenancePlans?.data?.length > 0 && maintenancePlans?.data?.map((task) => {
                                return <div className={Styles.ddb_content_item} onClick={() => handleNavigate(task)}>
                                    <div>
                                        <p className={Styles.ddb_content_item_label}>{task?.name}</p>
                                    </div>
                                    <div>
                                        <p className={Styles.ddb_content_item_label}>{`Scheduled On : ${getFormatedDate(task?.startAt)}`}</p>
                                        <p className={Styles.ddb_content_item_label}>{`Status : ${statusStaticData[task?.status]}`}</p>
                                    </div>
                                </div>
                            })
                        }
                        {
                            isLoading && <img src={ClonosSpinner} />
                        }
                        {
                            !maintenancePlans?.data?.length && <section><span>No results Found!</span></section>
                        }
                    </div>
                </section>
                <footer className={Styles.ddb_footer}>
                    <div className={Styles.ddbf_controller}> {/* ddbf: dynamic dropdown body footer */}
                        <span onClick={() => closeModalMethod(false)}>Cancel</span>
                        <span onClick={() => closeModalMethod(false)}>Ok</span>
                    </div>
                </footer>
            </div >
        </Modal >
    )
}