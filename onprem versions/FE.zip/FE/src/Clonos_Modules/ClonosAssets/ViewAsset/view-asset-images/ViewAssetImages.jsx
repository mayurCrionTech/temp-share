import { useState } from "react";
import Styles from './view-asset-images.module.css';
import NO_IMAGE_PRESENT from '../../../../resources/images/no-image.png'
import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { Tooltip } from "@mui/material";
import { ImagePreviewModal } from "../../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal";

export const ViewAssetImages = ({images}) => {
    const [loading,setLoading] = useState(false)
    const [activeImage,setActiveImage] = useState(0);
    const [showImagePreviewModal,setShowImagePreviewModal] = useState(false);

    const handleImagePreview = (imageIndex) => {
      setShowImagePreviewModal(true);
      setActiveImage(imageIndex)
    }
 
    return <>
    <div className={Styles.astImageContainer}>
      {
        loading 
        ? <ClonosSkeletonLoading variant="rounded" animation="wave" /> 
        : <h4 className={Styles.detail_header}>Asset Image</h4>
      }
      <div onClick={() =>  images?.length && handleImagePreview(0)} className={Styles.thumbnailHolder}>
        {
          loading 
          ? <div><ClonosSkeletonLoading variant="rounded" width="100%"  height="350px" animation="wave" /></div>
          :  <img loading="lazy" src={images?.length > 0 ? images[0]?.url : NO_IMAGE_PRESENT}/>
        }
      </div>
      <div className={Styles.imgListContainer}>
        {images?.length > 1 && (
          <div  className={Styles.imgItemBox}>
            <div onClick={() => handleImagePreview(1)}className={Styles.imgHolder}>
              {
              loading 
              ? <div>
                  <ClonosSkeletonLoading variant="rounded" width="120px"  height="120px" animation="wave" />
                </div>  
              : <img loading="lazy" src={images?.length > 1 ? images[1]?.url : NO_IMAGE_PRESENT}/>
              }
            </div>
            <Tooltip
              title={`${images[1]?.name}.${images[1]?.imageType}`}
            >
              {loading 
              ? <div><ClonosSkeletonLoading variant="rounded" width="120px"  height="20px" animation="wave" /></div> 
              : <p>
                {images[1]?.name}.
                {images[1]?.extension}
              </p>}
              
            </Tooltip>
          </div>
        )}
        {images?.length > 2 && (
          <div className={Styles.imgItemBox}>
            <div onClick={() => handleImagePreview(2)} className={Styles.imgHolder}>
              {
                loading 
                ? <div><ClonosSkeletonLoading variant="rounded" width="120px"  height="120px" animation="wave" /></div> 
                : <img loading="lazy" src={images?.length > 2 ? images[2]?.url : NO_IMAGE_PRESENT}/>
              }
            </div>
            <Tooltip
              title={`${images[2]?.name}.${images[2]?.imageType}`}
            >
              {loading 
              ? <div><ClonosSkeletonLoading variant="rounded" width="120px"  height="20px" animation="wave" /></div> 
              : <p>
                {images[2]?.name}.
                {images[2]?.imageType}
              </p>
              }
            </Tooltip>
          </div>
        )}
        {images?.length > 3 && (
          <div className={Styles.imgItemBox}>
            <div
              style={{
                height: "120px",
                display: "flex",
                alignItems: "center",
              }}
            >
              <p onClick={() => handleImagePreview(0)}
                className={Styles.linkText}
              >
                View All
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
    <ImagePreviewModal
        activeImageIndex={activeImage}
        open={showImagePreviewModal}
        closeModalMethod={setShowImagePreviewModal}
        images={images}
        // deleteMethod={handleDeleteAssetImage}
      />
    </>
}