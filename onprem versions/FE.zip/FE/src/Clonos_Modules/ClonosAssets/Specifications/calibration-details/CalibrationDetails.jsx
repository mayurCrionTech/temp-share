import { useEffect, useState } from "react";
import Styles from "./calibration-details.module.css";
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import { handleGetFilledValuesOfSpecifications } from "../specifications-managers";
import { handleGetAssetEnums } from "../../managers/asset-common-managers";
import { getFormatedDate, getYYYYMMDD_Format } from "../../../../utils/clonosCommon";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { doGetApiCall } from "../../../../utils/ClonosApi";

/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/
export const CalibrationDetails = ({ updateParentLcState, globalStateOfChildData, specificationsLcState, setChangedSpecifications, mode }) => {
  const [dropdownsData, setDropdownsData] = useState({
    calibrationCycles: [],
    corrosionCycles: [],
    designThicknessUnits: [],
    allowableThicknessUnits: []

  })
  const [minimumOfCalibrationDate, setMinimumOfCalibrationDate] = useState(specificationsLcState?.manufacturingDetails?.installationDate)
  const [lcCalibrationDetails, setLcCalibrationDetails] = useState({});
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "calibrationDetails", isChildren: true });
  //  const [loadingDropdowns, setLoadingDropdowns] = useState({});
  //  const [staticDropdownData,setStaticDropdownData]=useState({})
    
   const selectedAutoFillAsset = useSelector(
      (store) => store.assetData.selectedAutoFillAsset
    );

//  const fetchStaticDropdownByCode = async (code) => {
//   if (staticDropdownData[code] || loadingDropdowns[code]) return;

//   setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

//   try {
//     const res = await doGetApiCall({url:`dropdowns/${code}`});
       
//     setStaticDropdownData(prev => ({
//       ...prev,
//       [code]: res?.data?.result?.options
//     }));
//   } finally {
//     setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
//   }
// };

  useEffect(() => {
    const tempCalibrationDetails = globalStateOfChildData?.calibrationDetails ? { ...globalStateOfChildData?.calibrationDetails } : {...selectedAutoFillAsset?.specifications?.calibrationDetails};
    updateParentLcState(prev => ({ ...prev, calibrationDetails: { ...tempCalibrationDetails, ...lcCalibrationDetails } }));
    if (mode === "edit") {
      setChangedSpecifications((prev) => ({ ...prev, calibrationDetails: lcCalibrationDetails }))
    }
  }, [lcCalibrationDetails]);

  useEffect(() => {
    setMinimumOfCalibrationDate(specificationsLcState?.manufacturingDetails?.installationDate)
  }, [specificationsLcState?.manufacturingDetails?.installationDate])

  useEffect(() => {
    handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, calibrationCycles: val })), moduleName: "specifications", enumTypeEndPoint: "calibrationDetails/calibrationCycle/type" });
    handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, corrosionCycles: val })), moduleName: "specifications", enumTypeEndPoint: "calibrationDetails/corrosionCycle/type" });
    handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, designThicknessUnits: val })), moduleName: "specifications", enumTypeEndPoint: "calibrationDetails/designThickness/type" });
    handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, allowableThicknessUnits: val })), moduleName: "specifications", enumTypeEndPoint: "calibrationDetails/allowableThickness/type" });
  }, [])



  return <div className={Styles.container}>
    <ClonosInput
      type="date"
      isLabel={true}
      isMinimum={false}
      isMandatory={false}
      disabled={mode === "edit" && globalStateOfChildData?.specifications?.calibrationDetails?.lastCalibrationDate}
      label={"Last Calibration Date"}
      uniqueKey="lastCalibrationDate"
      placeholder="Last Calibration Date"
      errorMessage={"Last Calibration Date is Required!."}
      // min={minimumOfCalibrationDate ? `${minimumOfCalibrationDate}` : ""}
      max={new Date().toISOString().split("T")[0]} // ✅ prevent future dates
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={
      specificationsLcState?.calibrationDetails?.lastCalibrationDate
        ? getYYYYMMDD_Format(
            specificationsLcState.calibrationDetails.lastCalibrationDate
          )
        : globalStateOfChildData?.specifications?.calibrationDetails?.lastCalibrationDate
        ? getYYYYMMDD_Format(
            globalStateOfChildData.specifications.calibrationDetails.lastCalibrationDate
          )
        : null
    }

      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
    />
    <div className={Styles.inp_sel_container}>
      <label>Calibration Cycle</label>
      <div className={Styles.inp_sel_wrapper}>
        <div className={Styles.inp_wrapper}>
          <ClonosInput
            limit={3}
            isLabel={false}
            type={"text"}
            isMandatory={false}
            placeholder={"1234"}
            errorMessage={"Fill this field!"}
            uniqueKey={"calibrationCycle_value"}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            defaultValue={specificationsLcState?.calibrationDetails?.calibrationCycle?.value  ?? globalStateOfChildData?.specifications?.calibrationDetails?.calibrationCycle?.value}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
          />
        </div>
        <div className={Styles.sel_wrapper}>
          <ClonosSelect
            type={"select"}
            isMandatory={false}
            placeholder={"select"}
            errorMessage={"Select this field!"}
            uniqueKey={"calibrationCycle_type"}
            options={dropdownsData?.calibrationCycles?.map((value) => ({ label: value, isNeeded: true }))}
            // options={staticDropdownData?.calibrationCycle?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            defaultValue={specificationsLcState?.calibrationDetails?.calibrationCycle?.type  ??globalStateOfChildData?.specifications?.calibrationDetails?.calibrationCycle?.type}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
            // onOpen={() => fetchStaticDropdownByCode("calibrationCycle")}
         />
        </div>
      </div>

    </div>
    <ClonosInput
      type="date"
      isLabel={true}
      isMinimum={false}
      isMandatory={false}
      disabled={mode === "edit" && globalStateOfChildData?.specifications?.calibrationDetails?.corrosionCheckDate}
      uniqueKey="corrosionCheckDate"
      label={"Corrosion Check Date"}
      placeholder="Corrosion Check Date"
      errorMessage={"Corrosion Check Date is Required!."}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={
      specificationsLcState?.calibrationDetails?.corrosionCheckDate
        ? getYYYYMMDD_Format(
            specificationsLcState.calibrationDetails.corrosionCheckDate
          )
        : globalStateOfChildData?.specifications?.calibrationDetails?.corrosionCheckDate
        ? getYYYYMMDD_Format(
            globalStateOfChildData.specifications.calibrationDetails.corrosionCheckDate
          )
        : null
    }
      //defaultValue={globalStateOfChildData?.specifications?.calibrationDetails?.corrosionCheckDate ? getYYYYMMDD_Format(globalStateOfChildData?.specifications?.calibrationDetails?.corrosionCheckDate) : null}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
    />
    <div className={Styles.inp_sel_container}>
      <label>Corrosion Cycle</label>
      <div className={Styles.inp_sel_wrapper}>
        <div className={Styles.inp_wrapper}>
          <ClonosInput
            limit={3}
            isLabel={false}
            type={"text"}
            isMandatory={false}
            placeholder={"1234"}
            uniqueKey={"corrosionCycle_value"}
            errorMessage={"Fill this field!"}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            defaultValue={specificationsLcState?.calibrationDetails?.corrosionCycle?.value  ??globalStateOfChildData?.specifications?.calibrationDetails?.corrosionCycle?.value}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
          />
        </div>
        <div className={Styles.sel_wrapper}>
          <ClonosSelect
            type={"select"}
            isMandatory={false}
            placeholder={"select"}
            errorMessage={"Select this field!"}
            uniqueKey={"corrosionCycle_type"}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            options={dropdownsData?.corrosionCycles?.map((value) => ({ label: value, isNeeded: true }))}
            //options={staticDropdownData?.corrosionCycle?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
            defaultValue={specificationsLcState?.calibrationDetails?.corrosionCycle?.type ?? globalStateOfChildData?.specifications?.calibrationDetails?.corrosionCycle?.type}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
            // onOpen={() => fetchStaticDropdownByCode("corrosionCycle")}
          />
        </div>
      </div>

    </div>
    <div style={{ display: 'flex', alignItems: 'baseline', gridGap: '1rem' }}>
      <div className={Styles.inp_sel_container}>
        <label>Design Thickness</label>
        <div style={{ width: "100%" }} className={Styles.inp_sel_wrapper}>
          <div className={Styles.inp_wrapper}>
            <ClonosInput
              limit={3}
              isLabel={false}
              type={"text"}
              isMandatory={false}
              placeholder={"1234"}
              errorMessage={"Fill this field!"}
              uniqueKey={"designThickness_value"}
              defaultValue={specificationsLcState?.calibrationDetails?.designThickness?.value ?? globalStateOfChildData?.specifications?.calibrationDetails?.designThickness?.value}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
            />
          </div>
          <div className={Styles.sel_wrapper}>
            <ClonosSelect
              type={"select"}
              isMandatory={false}
              placeholder={"select"}
              errorMessage={"Select this field!"}
              uniqueKey={"designThickness_type"}
              options={dropdownsData?.designThicknessUnits?.map((value) => ({ label: value, isNeeded: true }))}
              //options={staticDropdownData?.designThickness?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
              defaultValue={specificationsLcState?.calibrationDetails?.designThickness?.type ?? globalStateOfChildData?.specifications?.calibrationDetails?.designThickness?.type}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
              // onOpen={() => fetchStaticDropdownByCode("designThickness")}
            />
          </div>
        </div>

      </div>
      <div className={Styles.inp_sel_container}>
        <label>Allowable Thickness</label>
        <div style={{ width: "100%" }} className={Styles.inp_sel_wrapper}>
          <div className={Styles.inp_wrapper}>
            <ClonosInput
              limit={3}
              type={"number"}
              isLabel={false}
              isMandatory={false}
              placeholder={"1234"}
              errorMessage={"Fill this field!"}
              uniqueKey={"allowableThickness_value"}
              defaultValue={specificationsLcState?.calibrationDetails?.allowableThickness?.value ?? globalStateOfChildData?.specifications?.calibrationDetails?.allowableThickness?.value}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
            />
          </div>
          <div className={Styles.sel_wrapper}>
            <ClonosSelect
              type={"select"}
              isMandatory={false}
              placeholder={"select"}
              errorMessage={"Select this field!"}
              uniqueKey={"allowableThickness_type"}
              options={dropdownsData?.allowableThicknessUnits?.map((value) => ({ label: value, isNeeded: true }))}
              //options={staticDropdownData?.allowableThickness?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              defaultValue={specificationsLcState?.calibrationDetails?.allowableThickness?.type ?? globalStateOfChildData?.specifications?.calibrationDetails?.allowableThickness?.type}
              handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
              // onOpen={() => fetchStaticDropdownByCode("allowableThickness")}
            />
          </div>
        </div>

      </div>
    </div>
    <ClonosInput
      limit={3}
      type="number"
      placeholder="0"
      isLabel={true}
      label={"MTTR"}
      uniqueKey="meanTimeToRepair"
      isMandatory={false}
      defaultValue={specificationsLcState?.calibrationDetails?.meanTimeToRepair  ?? globalStateOfChildData?.specifications?.calibrationDetails?.meanTimeToRepair}
      errorMessage={"MTTR is Required!."}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
    />
    <ClonosInput
      limit={3}
      type="number"
      isLabel={true}
      label={"MTBF"}
      placeholder="0"
      uniqueKey="meanTimeBetweenFailures"
      isMandatory={false}
      defaultValue={specificationsLcState?.calibrationDetails?.meanTimeBetweenFailures  ??  globalStateOfChildData?.specifications?.calibrationDetails?.meanTimeBetweenFailures}
      errorMessage={"MTBF is Required!."}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
    />
    <ClonosInput
      type="date"
      isLabel={true}
      isMinimum={false}
      isMandatory={false}
      uniqueKey="lastAuditDate"
      label={"Last Audit Date"}
      placeholder="Last Audit Date"
      defaultValue={
      specificationsLcState?.calibrationDetails?.lastAuditDate
        ? getYYYYMMDD_Format(
            specificationsLcState.calibrationDetails.lastAuditDate
          )
        : globalStateOfChildData?.specifications?.calibrationDetails?.lastAuditDate
        ? getYYYYMMDD_Format(
            globalStateOfChildData.specifications.calibrationDetails.lastAuditDate
          )
        : null
    }
      //defaultValue={globalStateOfChildData?.specifications?.calibrationDetails?.lastAuditDate ? getYYYYMMDD_Format(globalStateOfChildData?.specifications?.calibrationDetails?.lastAuditDate) : null}
      errorMessage={"Last Audit Date is Required!."}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcCalibrationDetails, specificationsLcState, section: "calibrationDetails", globalStateOfChildData })}
    />
  </div>
}