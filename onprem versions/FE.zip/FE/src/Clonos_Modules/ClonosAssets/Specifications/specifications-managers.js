import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS } from "../../../Constants/Constant";
import AppUrl from "../../../utils/AppUrl";
import { doPostApiCall, doPutApiCall } from "../../../utils/ClonosApi";
import { handleServerDateInConfiguredTimeZone, handleShowErrorAndWarning, modifyString } from "../../../utils/clonosCommon";
import { debouncedSaveFildsToLocalStorage } from "../../../utils/common-managers";
import { manipulateGeneralDetailsPayload } from "../general-details/general-details-managers";
import {handleIsAssetEdited } from "../managers/asset-common-managers";
import { ManufacturingDetails } from "./manufacturing-details/ManufacturingDetails";


// TO HANDLE CHANGED VALUES 
export const handleGetFilledValuesOfSpecifications = ({
  componentProps,
  primaryObject,
  handlePrimaryObjectModifier,
  setFormData,
  specificationsLcState,
  globalStateOfChildData,
  section,
}) => {
  let { name, selectedOption, updatedValue, uniqueKey, type,files } = componentProps;
  const [key1, key2] = uniqueKey?.split("_"); // to handle the nested objects fields

  if (type === "dynamicDropdown") {
    handlePrimaryObjectModifier({ uniqueKey, response: selectedOption });
    setFormData((prev) => ({
      ...prev,
      [uniqueKey]: { name: selectedOption[0]?.name, id: selectedOption[0]?.id },
    }));
  } else if (type === "searchableDropdown") {
  const selected = updatedValue;  // because dropdown sends only this

  handlePrimaryObjectModifier({ uniqueKey, response: selected });

  setFormData(prev => ({
    ...prev,
    [uniqueKey]: { 
      name: selected?.[uniqueKey],    // field name = "make", not "name"
      id: selected?.id
    }
  }));

  return;
} else if (type === "select") {
    handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });

    if (key2 === "type") {
      setFormData((prev) => {
        if(!prev[key1]?.value){
          primaryObject[`${key1}_value`].value = false;
          primaryObject[`${key1}_value`]?.errorActivatorMethod(true);
          primaryObject[`${key1}_value`]?.errorSetterMethod("Fill this field!")
        }
        let auxObj = {
          ...prev,
          [key1]: {
            ...globalStateOfChildData?.specifications?.[section]?.key1,
            ...prev?.[key1],
            //  id: updatedValue?.value,
            [key2]: updatedValue?.label,
          },
        }
        return auxObj
      });
    } else {
      setFormData((prev) => ({
        ...prev,
        [uniqueKey]: {
          name: updatedValue[0]?.label,
          id: updatedValue[0]?.value,
        },
      }));
    }
  } else if ( type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email" ) {
    if (type === "number") updatedValue = Number(updatedValue);
    if (uniqueKey === "lastCalibrationDate") {
      handleCalibrationDate({primaryObject,handlePrimaryObjectModifier,uniqueKey,setFormData,updatedValue,specificationsLcState });
    }
    if (key1 === "hazardousAreaDetails") {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      setFormData((prev) => {
        let prevHazardousAreaDetails = {
          ...globalStateOfChildData?.specifications?.hazardousAreaDetails,
          ...prev?.hazardousAreaDetails,
        };
        return {
          ...prev,
          hazardousAreaDetails: {
            ...prevHazardousAreaDetails,
            [key2]: updatedValue,
          },
        };
      });
    } else if (key2 === "value") {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      setFormData((prev) => {
        if(updatedValue && (!prev[key1] || !prev[key1].type)){
            primaryObject[`${key1}_type`].value = false;
            primaryObject[`${key1}_type`]?.errorActivatorMethod(true);
            primaryObject[`${key1}_type`]?.errorSetterMethod("Select this field!")
        } else if(!updatedValue && prev[key1].type){
            primaryObject[`${key1}_value`].value = false;
            primaryObject[`${key1}_value`]?.errorActivatorMethod(true);
            primaryObject[`${key1}_value`]?.errorSetterMethod("Fill this field!")
        } else if(!updatedValue && (!prev[key1] || !prev[key1].type)) {
          primaryObject[`${key1}_type`].value = true;
          primaryObject[`${key1}_type`]?.errorActivatorMethod(false);
          primaryObject[`${key1}_type`]?.errorSetterMethod("")
        }

        let auxObj = {
          ...prev,
          [key1]: {
            ...globalStateOfChildData?.specifications?.[section]?.[key1],
            ...prev?.[key1],
            [key2]: updatedValue,
          },
        }
        return auxObj
      });
    } else {
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      setFormData((prev) => {
        let auxObj = { ...prev, [uniqueKey]: updatedValue };
        debouncedSaveFildsToLocalStorage({key: section,data: { ...prev, [uniqueKey]: updatedValue }});
        return auxObj;
      });
    }
  } else if (type === "radio") {
    setFormData((prev) => ({
      ...prev,
      [name]: modifyString(uniqueKey, "spacecase"),
    }));
  } else if (type === "checkbox") {
    setFormData((prev) => ({ ...prev, [uniqueKey]: updatedValue }));
  } else if (type === "file") {
    setFormData((prev) => {
      let auxObj = {...prev,[uniqueKey]:files[0]};
      // debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:files[0]}}})
      return auxObj
    })
  } else if(type === "isEditable") {
    setFormData(prev => {
      let auxObj = {...prev,[`${uniqueKey}NeedToDelete`]:[...(prev?.[`${uniqueKey}NeedToDelete`] || []),...selectedOption]};
      // debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:files[0]}}})
      return auxObj
    }) 
  }
};


const handleCalibrationDate = ({primaryObject,handlePrimaryObjectModifier,setFormData,uniqueKey,updatedValue,specificationsLcState}) => {
  const installationDate = new Date(specificationsLcState?.manufacturingDetails?.installationDate);
  const lastCalibrationDate = new Date(updatedValue);
  if(lastCalibrationDate >= installationDate){
    handlePrimaryObjectModifier({ uniqueKey, response: updatedValue});
    setFormData(prev => ({...prev,[uniqueKey]:updatedValue}));
  } else {
    // primaryObject[uniqueKey].value = false;
    primaryObject?.[uniqueKey]?.errorActivatorMethod(true);
    primaryObject?.[uniqueKey]?.errorSetterMethod(`Last calibration date should be greater than installation date!`);
  }
}


export const validateSpecifications = ({specifications={}}) => {
  const {manufacturingDetails = {},calibrationDetails={},warrantyDetails={},hazardousAreaDetails={}} = specifications;
  let temp = validateManufacturingDetails({manufacturingDetails}) 
  return (process.env.REACT_APP_BUILDTYPE === "PRODUCTION" || process.env.REACT_APP_BUILDTYPE === "TESTING") ? temp : true;
}

function validateManufacturingDetails ({manufacturingDetails={}}){
  const {type="",make="",model="",serialNumber="",manufacturer="",installationDate="",serviceLiquid=""} = manufacturingDetails;
  return Boolean(installationDate)

}

function validateCalibrationDetails ({calibrationDetails={}}) {
  const {lastCalibrationDate="",calibrationCycle={},corrosionCheckDate="",corrosionCycle={},designThickness={},allowableThickness={},meanTimeToRepair="",meanTimeBetweenFailures="",lastAuditDate=""} = calibrationDetails;
  return Boolean(lastCalibrationDate && corrosionCheckDate && meanTimeBetweenFailures && meanTimeToRepair && lastAuditDate && corrosionCycle?.value && corrosionCycle?.type &&  calibrationCycle?.value && calibrationCycle?.type && designThickness?.type && designThickness?.value && allowableThickness?.type && allowableThickness?.value )
}

function validateWarrantyDetails ({warrantyDetails={}}) {
  const {isWarrantyIncluded=false,supplierEmail="",supplierName="",warrantyPeriod={},warrantyEndDate=""} = warrantyDetails;
  return !isWarrantyIncluded || Boolean(isWarrantyIncluded && supplierEmail && supplierName && warrantyPeriod?.value && warrantyPeriod?.type && warrantyEndDate)
  // return true
}

function validateHazardousAreaDetails ({hazardousAreaDetails={}}) {
  const {zoneClassification="",gasGroup="",temperatureClassification=""} = hazardousAreaDetails;
  return Boolean(zoneClassification && gasGroup && temperatureClassification)
}

export const handlePrevious = ({formData,setGlobalStateOfChildData,setActiveStep}) => {
  const {manufacturingDetails,calibrationDetails,warrantyDetails} = formData;
  const {hazardousAreaDetails,...restManufacturingDetails} = manufacturingDetails;
  Object.keys(formData)?.length && setGlobalStateOfChildData(prev => (
    {...prev,
    specifications:{
      ...prev?.specifications,
      warrantyDetails:{...prev?.specifications?.warrantyDetails,...warrantyDetails},
      calibrationDetails:{...prev?.specifications?.calibrationDetails,...calibrationDetails},
      hazardousAreaDetails:{...prev?.specifications?.hazardousAreaDetails,...hazardousAreaDetails},
      manufacturingDetails:{...prev?.specifications?.manufacturingDetails,...restManufacturingDetails},
    }}));
  setActiveStep(prev => prev -1)
}


export const manipulateSpecificationsPayload = ({payload,setIsLoading}) => {
  const {manufacturingDetails={},calibrationDetails={},warrantyDetails={}} = payload;
  let requestPayload = {};
  const {hazardousAreaDetails={},...restManufacturingDetails} = manufacturingDetails; 
  if(Object?.keys(restManufacturingDetails)?.length) {
    requestPayload.manufacturingDetails = restManufacturingDetails?.installationDate ? {...restManufacturingDetails,installationDate: handleServerDateInConfiguredTimeZone({dateString:restManufacturingDetails?.installationDate})} : {...restManufacturingDetails};
  }
  if(Object?.keys(calibrationDetails)?.length) {
    requestPayload.calibrationDetails = calibrationDetails;
    if(calibrationDetails?.lastCalibrationDate){
      requestPayload.calibrationDetails.lastCalibrationDate = handleServerDateInConfiguredTimeZone({dateString:calibrationDetails?.lastCalibrationDate})
    }
    if(calibrationDetails?.corrosionCheckDate) {
      requestPayload.calibrationDetails.corrosionCheckDate = handleServerDateInConfiguredTimeZone({dateString:calibrationDetails?.corrosionCheckDate})
    }
    if(calibrationDetails?.lastAuditDate) {
      requestPayload.calibrationDetails.lastAuditDate = handleServerDateInConfiguredTimeZone({dateString:calibrationDetails?.lastAuditDate})
    }
  }
  if(Object?.keys(hazardousAreaDetails)?.length) requestPayload.hazardousAreaDetails = hazardousAreaDetails;
  if(Object?.keys(warrantyDetails)?.length) {
    requestPayload.warrantyDetails = warrantyDetails
    if(warrantyDetails?.warrantyEndDate) {
      requestPayload.warrantyDetails.warrantyEndDate = handleServerDateInConfiguredTimeZone({dateString:warrantyDetails?.warrantyEndDate})
    };
    if(warrantyDetails?.termsAndConditions?.id) {
      requestPayload.warrantyDetails.termsAndConditions = warrantyDetails?.termsAndConditions?.id
    }
  }
  return requestPayload
} 


const manipulateWarrantyDetails = ({payload}) => {

  const data = {};
  if(payload?.supplierName) data.supplierName = payload?.supplierName;
  if(payload?.supplierEmail) data.supplierName = payload?.supplierEmail;
  if(payload?.warrantyPeriod?.value && payload?.warrantyPeriod?.value) data.warrantyPeriod = payload?.warrantyPeriod;
  if(payload?.warrantyEndDate) data.warrantyEndDate = payload?.warrantyEndDate;
  if(payload?.isWarrantyIncluded) data.isWarrantyIncluded = payload?.isWarrantyIncluded;
  if(payload?.termsAndConditionsNeedToDelete?.length) {
    data.termsAndConditions = null;
  } else {
    if(payload?.termsAndConditions) data.termsAndConditions = payload?.termsAndConditions?.id;
  }
  return data
}


export const handleSaveSpecifications = ({dispatch,formData,setIsLoading,next}) => {
 
  const url = `/assets/${formData?.id}`;
  const auxData = {...formData};

  // Convert warrantyPeriod.value to a number if it exists
  if (auxData?.manufacturingDetails?.make) {
    auxData.manufacturingDetails.make = auxData?.manufacturingDetails?.make?.name
  }
  if (auxData?.manufacturingDetails?.model) {
    auxData.manufacturingDetails.model = auxData?.manufacturingDetails?.model?.name
  }
  if (auxData?.warrantyDetails?.warrantyPeriod?.value) {
    auxData.warrantyDetails.warrantyPeriod.value = Number(auxData.warrantyDetails.warrantyPeriod.value);
  }

  delete auxData?.id;
    setIsLoading(true)
    doPutApiCall({url,payload:{specifications:auxData}})
    .then((res) => {
      if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
        next && next()
      }
    })
    .catch((err) => console.error(err))
    .finally(() => setIsLoading(false))
}


export const handleUpdateSpecifications = ({id,setActiveStep,changedData,setIsLoading}) => {
  const requestPayload = manipulateSpecificationsPayload({payload:changedData});
  setIsLoading()
  const url = `${AppUrl.editAsset}/${id}`
  doPutApiCall({url,payload:{specifications:requestPayload}})
  .then((res) => {
    if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
      setActiveStep(prev => prev + 1)
    }
  })
  .catch(err => console.error(err))
  .finally(() => setIsLoading()) 
}


