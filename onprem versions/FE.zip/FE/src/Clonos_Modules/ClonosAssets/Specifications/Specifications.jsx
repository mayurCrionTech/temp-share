import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import Styles from "./specifications.module.css";
import useToggler from "../../../CustomHooks/TogglerHook";
import { WarrantyDetails } from "./warranty-details/WarrantyDetails";
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";
import { handleIsAssetEdited } from "../managers/asset-common-managers";
import { StepController } from "../Components/StepController/StepController";
import { CalibrationDetails } from "./calibration-details/CalibrationDetails";
import { getUser, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import { ManufacturingDetails } from "./manufacturing-details/ManufacturingDetails";
import { handlePrevious, handleSaveSpecifications, manipulateSpecificationsPayload } from "./specifications-managers";
import { useSelector } from "react-redux";



export const Specifications = ({ setGlobalStateOfChildData, globalStateOfChildData, steps, activeStep, setActiveStep, mode, serverResponse, setServerResponse }) => {
  const user = getUser();
  const dispatch = useDispatch();
    const selectedAutoFillAsset = useSelector(
    (store) => store.assetData.selectedAutoFillAsset
  );
  const Navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({});
  const [isLoading, setIsLoading] = useToggler();
  const [changedSpecifications, setChangedSpecifications] = useState({});
  const { handleSubmit} = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "specifications" })

  const handleSaveAndNext = () => {
    if (!handleSubmit()) {
      handleShowErrorAndWarning({ dispatch, type: "error", message: "Please provide all required fiels!", showTime: "5000" });
      return
    };  
    const requestPayload = manipulateSpecificationsPayload({ payload: structuredClone(formData) });
    const isAssetEdited = handleIsAssetEdited({ serverResponse: serverResponse?.specifications, changedData: requestPayload, assetModule: "specifications" });
    if (!isAssetEdited) {
      setActiveStep(prev => prev + 1);
      return
    } else {
      const next = () => {
        setGlobalStateOfChildData(prev => {
          const manufacturingDetails = structuredClone(formData?.manufacturingDetails || {});
          delete manufacturingDetails.hazardousAreaDetails;
          const auxData = {
            ...prev,
            specifications:{
              manufacturingDetails:{...prev?.specifications?.manufacturingDetails,...manufacturingDetails},
              hazardousAreaDetails:{...prev?.specifications?.hazardousAreaDetails,...formData?.manufacturingDetails?.hazardousAreaDetails},
              calibrationDetails:{...prev?.specifications?.calibrationDetails,...formData?.calibrationDetails},
              warrantyDetails: {...(prev?.specifications?.warrantyDetails || {}),
                ...(formData?.warrantyDetails || {}),
                termsAndConditions: formData?.warrantyDetails?.termsAndConditions?.id ? formData?.warrantyDetails?.termsAndConditions : formData?.warrantyDetails?.termsAndConditionsNeedToDelete?.length ? null : prev?.specifications?.warrantyDetails?.termsAndConditions
              }
            }}
          setServerResponse(auxData)  
          return auxData 
        });
        setActiveStep(prev => prev + 1)
      }
      handleSaveSpecifications({ dispatch,formData: { ...requestPayload, id: globalStateOfChildData?.id },setIsLoading, next })
    }
  }


  // TO REMOVE TERMSANDCONDITIONS FILE ON REMOVE
  useEffect(() => {
    if(formData?.warrantyDetails?.termsAndConditionsNeedToDelete?.length) {
      setGlobalStateOfChildData((prev) => {
        let tempWarrantyDetails = {...prev?.specifications?.warrantyDetails,};
        delete tempWarrantyDetails.termsAndConditions;
        return {...prev,specifications:{...(prev?.specifications || {}),warrantyDetails:tempWarrantyDetails}}
      })
    }
  },[formData?.warrantyDetails?.termsAndConditionsNeedToDelete?.length])

   useEffect(()=>{
      if(selectedAutoFillAsset){
          setFormData(selectedAutoFillAsset?.specifications)
      }
  },[selectedAutoFillAsset])

  
  return (
    <>
      <div className={Styles.specificationsContainer}>
        <div className={Styles.specsDetails_top}>
          <div className={Styles.manufacturingDetailsLeftContainer}>
            <h4>Manufacturing Details</h4>
            <ManufacturingDetails globalStateOfChildData={globalStateOfChildData} updateParentLcState={setFormData} specificationsLcState={formData} setChangedSpecifications={setChangedSpecifications} mode={mode} />
          </div>
          <div className={Styles.manufacturingDetailsRightContainer}>
            <CalibrationDetails updateParentLcState={setFormData} globalStateOfChildData={globalStateOfChildData} specificationsLcState={formData} setChangedSpecifications={setChangedSpecifications} mode={mode} />
          </div>
        </div>
        <div className={Styles.divBraker}></div>
        <div className={Styles.warrantyDetailsContainer}>
          <WarrantyDetails updateParentLcState={setFormData} globalStateOfChildData={globalStateOfChildData} specificationsLcState={formData} setChangedSpecifications={setChangedSpecifications} mode={mode} />
        </div>
      </div>
      <StepController
        loading={isLoading}
        steps={steps}
        handleBack={() => handlePrevious({ formData, setGlobalStateOfChildData, setActiveStep })}
        handleNext={handleSaveAndNext}
        activeStep={activeStep}
      />
    </>
  );
};
