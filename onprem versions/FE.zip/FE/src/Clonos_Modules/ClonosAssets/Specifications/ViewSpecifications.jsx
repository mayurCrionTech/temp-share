
import React, { useState, useRef, useEffect } from "react";
import ClonosHierarchyModal from "../../../components/CommonComponents/ClonosHierarchyModal/ClonosHierarchyModal"

import ClonosDocumentViewer from "../../../components/CommonComponents/document-viewer/ClonosDocumentViewer"
import { getFormatedDate, getYYYYMMDD_Format } from "../../../utils/clonosCommon"
import Styles from "../ViewAsset/view-asset.module.css"
import { doGetApiCall } from "../../../utils/ClonosApi";
import { useLocation } from "react-router-dom";
import { ImmediateParentChildAssetTree } from "../Components/ImidiateParentChildAssetTree/ImmediateParentChildAssetTree";
export const ViewSpecifications = ({specifications}) => {

    return <div className={Styles.spec_details_container}>
        <h4 className={Styles.v_a_header}>Specifications</h4>
        <div className={Styles.fields_container}>
            {specifications?.make && (
                <div className={Styles.field_wrapper}>
                    <h4>Asset Make</h4>
                    <p>{specifications.make}</p>
                </div>
            )}
            {specifications?.model && (
                <div className={Styles.field_wrapper}>
                    <h4>Asset Model</h4>
                    <p>{specifications.model}</p>
                </div>
            )}
            {specifications?.serialNumber && (
                <div className={Styles.field_wrapper}>
                    <h4>Serial Number</h4>
                    <p>{specifications.serialNumber}</p>
                </div>
            )}
            {specifications?.manufacturer && (
                <div className={Styles.field_wrapper}>
                    <h4>Manufacturer</h4>
                    <p>{specifications.manufacturer}</p>
                </div>
            )}
            {specifications?.installationDate && (
                <div className={Styles.field_wrapper}>
                    <h4>Installation Date</h4>
                    <p>{getFormatedDate(specifications.installationDate)}</p>
                </div>
            )}
            {specifications?.serviceLiquid && (
                <div className={Styles.field_wrapper}>
                    <h4>Service Liquid</h4>
                    <p>{specifications.serviceLiquid}</p>
                </div>
            )}
        </div>

    </div>
}


export const ViewHazardousAreaDetails = ({hazardousAreaDetails}) => {
    return <div className={Styles.hazar_details_container}>
        <h4 className={Styles.v_a_header}>Hazardous Area Details</h4>
        <div className={Styles.fields_container}>
            {hazardousAreaDetails?.zoneClassification && (
                <div className={Styles.field_wrapper}>
                    <h4>Zone</h4>
                    <p>{hazardousAreaDetails.zoneClassification}</p>
                </div>
            )}
            {hazardousAreaDetails?.gasGroup && (
                <div className={Styles.field_wrapper}>
                    <h4>Gas</h4>
                    <p>{hazardousAreaDetails.gasGroup}</p>
                </div>
            )}
            {hazardousAreaDetails?.temperatureClassification && (
                <div className={Styles.field_wrapper}>
                    <h4>Temperature</h4>
                    <p>{hazardousAreaDetails.temperatureClassification}</p>
                </div>
            )}
        </div>

    </div>
}


export const ViewCalibrationDetails = ({calibrationDetails}) => {
    return <div className={Styles.calib_details_container}>
        <h4 className={Styles.v_a_header}>Other Details</h4>
        <div className={Styles.fields_container}>
            {calibrationDetails?.lastCalibrationDate && (
                <div className={Styles.field_wrapper}>
                    <h4>Last Calibration Date</h4>
                    <p>{getFormatedDate(calibrationDetails.lastCalibrationDate)}</p>
                </div>
            )}
            {calibrationDetails?.calibrationCycle?.value && calibrationDetails?.calibrationCycle?.type && (
                <div className={Styles.field_wrapper}>
                    <h4>Calibration Cycle</h4>
                    <p>{`${calibrationDetails.calibrationCycle.value} ${calibrationDetails.calibrationCycle.type}`}</p>
                </div>
            )}
            {calibrationDetails?.corrosionCheckDate && (
                <div className={Styles.field_wrapper}>
                    <h4>Corrosion Check Date</h4>
                    <p>{getFormatedDate(calibrationDetails.corrosionCheckDate)}</p>
                </div>
            )}
            {calibrationDetails?.corrosionCycle?.value && calibrationDetails?.corrosionCycle?.type && (
                <div className={Styles.field_wrapper}>
                    <h4>Corrosion Cycle</h4>
                    <p>{`${calibrationDetails.corrosionCycle.value} ${calibrationDetails.corrosionCycle.type}`}</p>
                </div>
            )}
            {calibrationDetails?.designThickness?.value && calibrationDetails?.designThickness?.type && (
                <div className={Styles.field_wrapper}>
                    <h4>Design Thickness</h4>
                    <p>{`${calibrationDetails.designThickness.value} ${calibrationDetails.designThickness.type}`}</p>
                </div>
            )}
            {calibrationDetails?.allowableThickness?.value && calibrationDetails?.allowableThickness?.type && (
                <div className={Styles.field_wrapper}>
                    <h4>Allowable Thickness</h4>
                    <p>{`${calibrationDetails.allowableThickness.value} ${calibrationDetails.allowableThickness.type}`}</p>
                </div>
            )}
            {calibrationDetails?.meanTimeToRepair && (
                <div className={Styles.field_wrapper}>
                    <h4>MTTR</h4>
                    <p>{calibrationDetails.meanTimeToRepair}</p>
                </div>
            )}
            {calibrationDetails?.meanTimeBetweenFailures && (
                <div className={Styles.field_wrapper}>
                    <h4>MTBF</h4>
                    <p>{calibrationDetails.meanTimeBetweenFailures}</p>
                </div>
            )}
            {calibrationDetails?.lastAuditDate && (
                <div className={Styles.field_wrapper}>
                    <h4>Last Audit Date</h4>
                    <p>{getFormatedDate(calibrationDetails.lastAuditDate)}</p>
                </div>
            )}
        </div>

    </div>
}


export const ViewWarrantyDetails = ({warrantyDetails}) => {
    const [showDocument,setShowDocument] = useState(false);
    return <>
        <div className={Styles.warranty_details_container}>
            <h4 className={Styles.v_a_header}>Warranty Details</h4>
            <div className={Styles.fields_container}>
                {warrantyDetails?.supplierName && (
                    <div className={Styles.field_wrapper}>
                        <h4>Supplier Name</h4>
                        <p>{warrantyDetails.supplierName}</p>
                    </div>
                )}
                {warrantyDetails?.supplierEmail && (
                    <div className={Styles.field_wrapper}>
                        <h4>Email ID</h4>
                        <p>{warrantyDetails.supplierEmail}</p>
                    </div>
                )}
                {warrantyDetails?.warrantyPeriod?.value && warrantyDetails?.warrantyPeriod?.type && (
                    <div className={Styles.field_wrapper}>
                        <h4>Warranty Period</h4>
                        <p>{`${warrantyDetails.warrantyPeriod.value} ${warrantyDetails.warrantyPeriod.type}`}</p>
                    </div>
                )}
                {warrantyDetails?.warrantyEndDate && (
                    <div className={Styles.field_wrapper}>
                        <h4>Warranty End Date</h4>
                        <p>{getFormatedDate(warrantyDetails.warrantyEndDate)}</p>
                    </div>
                )}
                {warrantyDetails?.termsAndConditions && (
                    <div className={Styles.field_wrapper}>
                        <h4>Terms And Conditions</h4>
                        <p onClick={() => setShowDocument(true)} className={Styles.link}>{warrantyDetails.termsAndConditions?.name}</p>
                    </div>
                )}
            </div>
            {showDocument && <ClonosDocumentViewer isOpen={showDocument} isDocument={true} closeMethod={() => setShowDocument(false)} file={warrantyDetails?.termsAndConditions}/>}
        </div>
    </>
    
}


export const ViewLocationDetails  = ({locationDetails}) => {
    return <div className={Styles.location_details_container}>
    {Object.keys(locationDetails || {})?.length > 0  && <h4 className={Styles.v_a_header}>Location Details</h4>}
    <div className={Styles.fields_container}>
        {locationDetails?.geographicalCoordinates && (
            <>
                <h4 className={Styles.v_a_header}>Geographical Coordinates</h4>
                {locationDetails.geographicalCoordinates.latitude && (
                    <div className={Styles.field_wrapper}>
                        <h4>Latitude</h4>
                        <p>{locationDetails.geographicalCoordinates.latitude}</p>
                    </div>
                )}
                {locationDetails.geographicalCoordinates.longitude && (
                    <div className={Styles.field_wrapper}>
                        <h4>Longitude</h4>
                        <p>{locationDetails.geographicalCoordinates.longitude}</p>
                    </div>
                )}
                {locationDetails.geographicalCoordinates.elevation && (
                    <div className={Styles.field_wrapper}>
                        <h4>Elevation</h4>
                        <p>{locationDetails.geographicalCoordinates.elevation}</p>
                    </div>
                )}
            </>
        )}
    </div>

</div>
}

const buildTreeForReactFlow = (assets) => {
  if (!Array.isArray(assets)) {
    console.error("Invalid data format for hierarchyDetails:", assets);
    return { nodes: [], edges: [] };
  }

  const nodes = [];
  const edges = [];

  assets.forEach((asset) => {
    nodes.push({
      id: asset.id.toString(),
      data: { label: asset.generalDetails?.name || "Unnamed Asset" },
      position: { x: Math.random() * 500, y: Math.random() * 500 }, // Auto layout
    });

    if (asset.parentAsset?.id) {
      edges.push({
        id: `edge-${asset.parentAsset.id}-${asset.id}`,
        source: asset.parentAsset.id.toString(),
        target: asset.id.toString(),
      });
    }
  });

  return { nodes, edges };
};

export const ViewHierarchyPage = ({ hierarchyDetails , locationAndHierarchyDetails }) => {

  const location = useLocation();
  const selectedAssetId = location?.state?.id;
 
  const [isModalOpen, setModalOpen] = useState(false);
  const { nodes, edges } = Array.isArray(hierarchyDetails) 
    ? buildTreeForReactFlow(hierarchyDetails) 
    : { nodes: [], edges: [] };

  return (
    <div>
      <h2 className={Styles.v_a_header}>Asset Hierarchy</h2>
      <div className={Styles.fields_container}>
         <div style={{display:"flex"}}>
                 <div >
                    { Object.keys(locationAndHierarchyDetails || {}).length > 0 && (
                            <ImmediateParentChildAssetTree assetGeneralDetails={locationAndHierarchyDetails}/>
                        )
                        
                    }
                 </div>
                
                <div style={{display:"flex", flexDirection:"column", justifyContent:"end"}}>
                    <a onClick={() => setModalOpen(true)}
                     style={{
                      textDecoration:"underline",
                      cursor: "pointer",
                     
                    }}
                >
                    View Full Hierarchy
                </a>
                    </div>
                </div>
         
          
      </div>
     
      {isModalOpen && nodes.length > 0 && (
        <ClonosHierarchyModal
          isOpen={isModalOpen}
          closeModalMethod={() => setModalOpen(false)}
          nodes={nodes}
          edges={edges}
          selectedAssetId={selectedAssetId}
        />
      )}
    </div>
  );
};




