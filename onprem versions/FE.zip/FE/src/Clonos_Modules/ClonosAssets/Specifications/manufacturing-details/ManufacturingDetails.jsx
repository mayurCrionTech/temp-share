import { useEffect, useRef, useState } from "react";
import Styles from "./manufacturing-details.module.css";
import ClonosRadioAndCheckbox from "../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox";
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";
import { handleGetFilledValuesOfSpecifications } from "../specifications-managers";
import { getYYYYMMDD_Format, handleClientDateInConfiguredTimeZone, handleServerDateInConfiguredTimeZone } from "../../../../utils/clonosCommon";
import ClonosSearchableDropdown from "../../../../components/CommonComponents/ClonosSearchableDropdown/ClonosSearchableDropdown";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import { Chip, Paper } from "@mui/material";
import AutoFixHighIcon from "@mui/icons-material/AutoFixHigh";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { assetActions } from "../../../../Store/Reducers/ClonosAssetReducer";


export const ManufacturingDetails = ({ updateParentLcState, globalStateOfChildData, specificationsLcState, mode, setChangedSpecifications }) => {
  
  const dispatch =useDispatch()
   const selectedAutoFillAsset = useSelector(
    (store) => store.assetData.selectedAutoFillAsset
  );

  const generalDetailsAutoFillChanged= useSelector(
     (store) => store.assetData.generalDetailsAutoFillChanged
  )
 
  const [lcManufacturingDetails, setLcManufacturingDetails] = useState({});
  const [serverManufacturingDetail, setServerManufacturingDetails] = useState({})
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, handleGetUpdatedPrimaryObject } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "manufacturingDetails", isChildren: true })
  const [assetMakeData,setAssetMakeData]=useState([])
  const [assetModelData,setAssetModelData]=useState([])
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const [hasMore, setHasMore] = useState(false);
    const [showAutoFillMake, setShowAutoFillMake] = useState(null);
    const [showAutoFillModel, setShowAutoFillModel] = useState(null);
    const [hasEdited,setHasEdited]=useState(false)
     const currentQuery = useRef("");



  useEffect(() => {
    const tempManufacturingDetails = globalStateOfChildData?.manufacturingDetails ? { ...globalStateOfChildData?.manufacturingDetails } : {...selectedAutoFillAsset?.specifications?.manufacturingDetails};
    const hazardousAreaDetails = tempManufacturingDetails?.hazardousAreaDetails || {};
    updateParentLcState(prev => ({ ...prev, manufacturingDetails: { ...tempManufacturingDetails, ...lcManufacturingDetails } }));
    // const updatedPrimaryObject = handleGetUpdatedPrimaryObject();
    if (mode === "edit") {
      setChangedSpecifications((prev) => ({ ...prev, manufacturingDetails: lcManufacturingDetails }))
    }
  }, [lcManufacturingDetails])

    useEffect(()=>{
      if(selectedAutoFillAsset){
          updateParentLcState({...selectedAutoFillAsset?.specifications })
      }
     },[selectedAutoFillAsset])

const fetchAssetMake = async (query, pageNum = 1) => {
  if (!query) return;

  setLoading(true);

  try {
    const res = await doGetApiCall({
      url: `assets/assetMaster?assetMake=${query}&page=${pageNum}`,
    });

    const apiData = res?.data?.result;
   

    if (apiData && Array.isArray(apiData.data)) {
      const results = apiData.data.map((item) => {
        const details = item.templateData?.generalDetails || {};
        const specifications = item.templateData?.specifications || {};

        return {
          id: item._id,
          familyKey: item.familyKey,

          // GENERAL DETAILS
          generalDetails: {
            name: details.name || "",
            number: details.number || "",
            description: details.description || "",
            runningMode: details.runningMode || "",
            businessUnit: details.businessUnit || "",
            category: details.category || "",
            criticalityLevel: details.criticalityLevel || "",
            department: details.department || "",
            functionalArea: details.functionalArea || "",
            owner: details.owner || "",
          },

          // FULL NESTED SPECIFICATIONS (NO LOSS)
          specifications: {
            ...specifications
          }
        };
      });

      setAssetMakeData((prev) =>
        pageNum === 1 ? results : [...prev, ...results]
      );

      setHasMore(apiData.page < apiData.totalPages);
    } else {
      setAssetMakeData([]);
      setHasMore(false);
    }
  } catch (error) {
    console.error("Error fetching parameters:", error);
    setAssetMakeData([]);
    setHasMore(false);
  } finally {
    setLoading(false);
  }
};



  const handleLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchAssetMake(currentQuery.current, nextPage);
  };


  const handleSearch = (query) => {
  if (!query) {
    // ✅ Clear old results when user clears input
    setAssetMakeData([]);
    setHasMore(false);
    return;
  }

  // normal API call
  currentQuery.current = query;
  setPage(1);
  fetchAssetMake(query, 1);
  
  const existingAsset = assetMakeData.find((asset) => asset.id === specificationsLcState?.manufacturingDetails?.make?.id);

  if (existingAsset) {
    setShowAutoFillMake(existingAsset);
    
  } else {
    setShowAutoFillMake(null);
  }
};

const fetchAssetModel = async (query, pageNum = 1) => {
  if (!query) return;

  setLoading(true);

  try {
    const res = await doGetApiCall({
      url: `assets/assetMaster?assetModel=${query}&page=${pageNum}`,
    });

    const apiData = res?.data?.result;
   

    if (apiData && Array.isArray(apiData.data)) {
      const results = apiData.data.map((item) => {
        const details = item.templateData?.generalDetails || {};
        const specifications = item.templateData?.specifications || {};

        return {
          id: item._id,
          familyKey: item.familyKey,

          // GENERAL DETAILS
          generalDetails: {
            name: details.name || "",
            number: details.number || "",
            description: details.description || "",
            runningMode: details.runningMode || "",
            businessUnit: details.businessUnit || "",
            category: details.category || "",
            criticalityLevel: details.criticalityLevel || "",
            department: details.department || "",
            functionalArea: details.functionalArea || "",
            owner: details.owner || "",
          },

          // FULL NESTED SPECIFICATIONS (NO LOSS)
          specifications: {
            ...specifications
          }
        };
      });

      setAssetModelData((prev) =>
        pageNum === 1 ? results : [...prev, ...results]
      );

      setHasMore(apiData.page < apiData.totalPages);
    } else {
      setAssetModelData([]);
      setHasMore(false);
    }
  } catch (error) {
    console.error("Error fetching parameters:", error);
    setAssetModelData([]);
    setHasMore(false);
  } finally {
    setLoading(false);
  }
};



  const handleAssetModalLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchAssetModel(currentQuery.current, nextPage);
  };


  const handleAssetModalSearch = (query) => {
  if (!query) {
    // ✅ Clear old results when user clears input
    setAssetModelData([]);
    setHasMore(false);
    return;
  }

  // normal API call
  currentQuery.current = query;
  setPage(1);
  fetchAssetModel(query, 1);
  
  const existingAsset = assetModelData.find((asset) => asset.id === specificationsLcState?.manufacturingDetails?.model?.id);


  if (existingAsset) {
    setShowAutoFillModel(existingAsset);
    
  } else {
    setShowAutoFillModel(null);
  }

};



useEffect(() => {
  const handleKeyDown = (e) => {
    if (e.key === "Tab") {

      // Autofill for Asset Name
      if (showAutoFillMake) {
         const newGeneral = showAutoFillMake.generalDetails || {};
          const oldGeneral = selectedAutoFillAsset?.specifications?.generalDetails || {};

          const isDifferent = JSON.stringify(newGeneral) !== JSON.stringify(oldGeneral);
        
          if (isDifferent) {
            dispatch(assetActions.setGeneralDetailsAutoFillChanged(true));
          } else {
            dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
          }
        dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillMake));
        //  setAssetNameEdited(false)
          setHasEdited(false)
        setShowAutoFillMake(null);
        return; // stop here so it doesn't check number too
      }

      // Autofill for Asset Number
      if (showAutoFillModel) {
          const newGeneral = showAutoFillModel.generalDetails || {};
          const oldGeneral = selectedAutoFillAsset?.specifications?.generalDetails || {};

        const isDifferent = JSON.stringify(newGeneral) !== JSON.stringify(oldGeneral);
      
        if (isDifferent) {
          dispatch(assetActions.setGeneralDetailsAutoFillChanged(true));
        } else {
          dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
        }
        dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillModel));
        //  setAssetNumberEdited(false)
          setHasEdited(false)
        setShowAutoFillModel(null);
        return;
      }
    }
  };

  window.addEventListener("keydown", handleKeyDown);

  return () => {
    window.removeEventListener("keydown", handleKeyDown);
  };
}, [showAutoFillMake, showAutoFillModel]);


  return <div className={Styles.container}>
    <div className={Styles.asset_type_wrapper}>
      <label className={Styles.clonosLabelStyle}>
        Asset Type
      </label>
      <div className={Styles.radioContainer}>
        <ClonosRadioAndCheckbox
          type="radio"
          name="type"
          label="Standard Asset"
          isLabel={true}
          isChecked={specificationsLcState?.manufacturingDetails?.type === "Standard Asset" || lcManufacturingDetails?.type === "Standard Asset" || globalStateOfChildData?.specifications?.manufacturingDetails?.type === "Standard Asset"}
          uniqueKey={"standardAsset"}
          handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
        />
        <ClonosRadioAndCheckbox
          type="radio"
          isLabel={true}
          name="type"
          uniqueKey={"fabricatedAsset"}
          isChecked={specificationsLcState?.manufacturingDetails?.type==="Fabricated Asset" || lcManufacturingDetails?.type === "Fabricated Asset" || globalStateOfChildData?.specifications?.manufacturingDetails?.type === "Fabricated Asset"}
          label="Fabricated Asset"
          handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
        />
      </div>
      {/* {errors.assetType && (
                  <span className={Styles.error}>{errors.assetType}</span>
                )} */}
    </div>
    {/* <ClonosInput
      limit={50}
      type="text"
      isLabel={true}
      name="assetMake"
      uniqueKey="make"
      label={"Asset Make"}
      placeholder="Asset Make"
      errorMessage={"Asset Make is Required!."}
      isMandatory={false}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={specificationsLcState?.manufacturingDetails?.make ?? globalStateOfChildData?.specifications?.manufacturingDetails?.make}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
    /> */}




             <ClonosSearchableDropdown
                      label="Asset Make"
                      data={assetMakeData.map(a => ({
                        id: a.id,
                        make: a.specifications?.manufacturingDetails?.make

                      }))}
                      //  tabIndex={1}
                      onSearch={handleSearch}
                      onLoadMore={handleLoadMore}
                      hasMore={hasMore}
                      loading={loading}
                      isMandatory={false}
                      debounceDelay={500}
                      uniqueKey={"make"}
                       placeholder="Asset Make"
                     defaultValue={specificationsLcState?.manufacturingDetails?.make ?? globalStateOfChildData?.specifications?.manufacturingDetails?.make}
                      errorMessage="Asset Make is required!"
                      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      allowCustomInput={true} 
                        hasEdited={hasEdited}
                      setHasEdited={setHasEdited}
                     
                    />
                {showAutoFillMake && (
                  <Paper
                    elevation={1}
                    sx={{
                      display: "inline-flex",
                      alignItems: "start",
                      padding: "6px 10px",
                      borderRadius: 4,
                      cursor: "pointer",
                      backgroundColor: "#f1f3f4",
                      width: "fit-content",
                      margin:"-15px 0px 0px -5px",
                      "&:hover": {
                        backgroundColor: "#e0e0e0",
                      },
                    }}
                    onClick={() =>{
                       
                     const newGeneral = showAutoFillMake.generalDetails || {};
                      const oldGeneral = selectedAutoFillAsset?.specifications?.generalDetails || {};

                    const isDifferent = JSON.stringify(newGeneral) !== JSON.stringify(oldGeneral);
                 
                    if (isDifferent) {
                      dispatch(assetActions.setGeneralDetailsAutoFillChanged(true));
                    } else {
                      dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
                    }
                     
                    dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillMake));
                    
                    //  setAssetNameEdited(false)
                    setHasEdited(false)
                    setShowAutoFillMake(null)
                    }
                    }
                  >
                    <AutoFixHighIcon sx={{ fontSize: 18, mr: 1 }} />
                        Auto-fill with "{showAutoFillMake.specifications.manufacturingDetails.make}"
                  </Paper>
                )}



                <ClonosSearchableDropdown
                      label="Asset Model"
                      data={assetModelData.map(a => ({
                        id: a.id,
                        model: a.specifications?.manufacturingDetails?.model

                      }))}
                      //  tabIndex={2}
                      onSearch={handleAssetModalSearch}
                      onLoadMore={handleAssetModalLoadMore}
                      hasMore={hasMore}
                      loading={loading}
                      isMandatory={false}
                      debounceDelay={500}
                      uniqueKey={"model"}
                       placeholder="Asset Model"
                     defaultValue={specificationsLcState?.manufacturingDetails?.model ?? globalStateOfChildData?.specifications?.manufacturingDetails?.model}
                      errorMessage="Asset Model is required!"
                      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                      allowCustomInput={true} 
                      hasEdited={hasEdited}
                      setHasEdited={setHasEdited}
                     
                    />
              {showAutoFillModel && (
                <Paper
                  elevation={1}
                  sx={{
                    display: "inline-flex",
                    alignItems: "start",
                    padding: "6px 10px",
                    borderRadius: 4,
                    cursor: "pointer",
                    backgroundColor: "#f1f3f4",
                    width: "fit-content",
                    margin:"-15px 0px 0px -5px",
                    "&:hover": {
                      backgroundColor: "#e0e0e0",
                    },
                  }}
                  onClick={() =>{

                    const newGeneral = showAutoFillModel.generalDetails || {};
                    const oldGeneral = selectedAutoFillAsset?.specifications?.generalDetails || {};

                    const isDifferent = JSON.stringify(newGeneral) !== JSON.stringify(oldGeneral);
                
                    if (isDifferent) {
                      dispatch(assetActions.setGeneralDetailsAutoFillChanged(true));
                    } else {
                      dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
                    }

                  dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillModel));
                  //  setAssetNameEdited(false)
                  setHasEdited(false)
                  setShowAutoFillModel(null)
                  }
                  }
                >
                  <AutoFixHighIcon sx={{ fontSize: 18, mr: 1 }} />
                      Auto-fill with "{showAutoFillModel.specifications.manufacturingDetails.model}"
                </Paper>
              )}



    {/* <ClonosInput
      limit={50}
      type="text"
      isLabel={true}
      uniqueKey="model"
      label={"Asset Model"}
      placeholder="Asset Modal"
      errorMessage={"Asset Model is Required!."}
      isMandatory={false}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={specificationsLcState?.manufacturingDetails?.model ?? globalStateOfChildData?.specifications?.manufacturingDetails?.model}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
    /> */}
    <ClonosInput
      limit={15}
      type="text"
      isLabel={true}
      isMandatory={false}
      label={"Serial Number"}
      uniqueKey="serialNumber"
      placeholder="Serial Number"
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={specificationsLcState?.manufacturingDetails?.serialNumber ?? globalStateOfChildData?.specifications?.manufacturingDetails?.serialNumber}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
    />
    <ClonosInput
      limit={50}
      type="text"
      isLabel={true}
      isMandatory={false}
      label={"Manufacturer"}
      uniqueKey="manufacturer"
      placeholder="Manufacturer"
      errorMessage={"Manufacturer is Required!."}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={specificationsLcState?.manufacturingDetails?.manufacturer ?? globalStateOfChildData?.specifications?.manufacturingDetails?.manufacturer}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
    />
    <ClonosInput
      type="date"
      isLabel={true}
      isMinimum={false}
      isMandatory={false}
      disabled={mode === "edit" && globalStateOfChildData?.specifications?.manufacturingDetails?.installationDate}
      label={"Installation Date"}
      uniqueKey="installationDate"
      placeholder="Installation Date"
      errorMessage={"Installation Date is Required!."}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={
        specificationsLcState?.manufacturingDetails?.installationDate
          ? getYYYYMMDD_Format(
              specificationsLcState.manufacturingDetails.installationDate
            )
          : globalStateOfChildData?.specifications?.manufacturingDetails?.installationDate
          ? getYYYYMMDD_Format(
              globalStateOfChildData.specifications.manufacturingDetails.installationDate
            )
          : null
      }

      handleGetValues={(props) => {
        handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })
      }}
    />
    <ClonosInput
      limit={50}
      type="text"
      isLabel={true}
      isMandatory={false}
      label={"Service Liquid"}
      uniqueKey="serviceLiquid"
      placeholder="Service Liquid"
      errorMessage={"Service Liquid is Required!."}
      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
      defaultValue={specificationsLcState?.manufacturingDetails?.serviceLiquid ?? globalStateOfChildData?.specifications?.manufacturingDetails?.serviceLiquid}
      handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
    />
    <div className={Styles.areaDetailsContainer}>
      <h4>Hazardous Area Details</h4>
      <div>
        <div>
          <ClonosInput
            limit={3}
            type="text"
            isLabel={true}
            placeholder="0"
            isMandatory={false}
            inputStyle={{ border: "none" }}
            label={"Zone Classification"}
            errorMessage={"Zone Classification is Required!."}
            uniqueKey="hazardousAreaDetails_zoneClassification"
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            defaultValue={specificationsLcState?.hazardousAreaDetails?.zoneClassification ?? globalStateOfChildData?.specifications?.hazardousAreaDetails?.zoneClassification}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, globalStateOfChildData, section: "manufacturingDetails" })}
          />
        </div>
        <div>
          <ClonosInput
            limit={3}
            type="text"
            isLabel={true}
            placeholder="G2"
            isMandatory={false}
            label={"Gas Group"}
            inputStyle={{ border: "none" }}
            errorMessage={"Gas Group is Required!."}
            uniqueKey="hazardousAreaDetails_gasGroup"
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            defaultValue={specificationsLcState?.hazardousAreaDetails?.gasGroup   ??globalStateOfChildData?.specifications?.hazardousAreaDetails?.gasGroup}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
          />
        </div>
        <div>
          <ClonosInput
            limit={3}
            type="text"
            isLabel={true}
            placeholder="T3"
            isMandatory={false}
            inputStyle={{ border: "none" }}
            label={"Temperature Classification"}
            errorMessage={"Temperature Classification is Required!."}
            uniqueKey="hazardousAreaDetails_temperatureClassification"
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            defaultValue={specificationsLcState?.hazardousAreaDetails?.temperatureClassification ?? globalStateOfChildData?.specifications?.hazardousAreaDetails?.temperatureClassification}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, handlePrimaryObjectModifier, setFormData: setLcManufacturingDetails, specificationsLcState, section: "manufacturingDetails" })}
          />
        </div>
      </div>
    </div>
  </div>
}