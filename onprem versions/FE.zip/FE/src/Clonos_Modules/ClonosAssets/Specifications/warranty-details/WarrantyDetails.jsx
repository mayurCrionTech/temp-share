import { useEffect, useState } from "react"
import { handleGetFilledValuesOfSpecifications } from "../specifications-managers"
import Styles from "./warranty-details.module.css"
import ClonosRadioAndCheckbox from "../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect"
import FileUploader from "../../../../components/CommonComponents/FileUploader/FileUploader"
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
import { handleGetAssetEnums } from "../../managers/asset-common-managers"
import { getFormatedDate, getYYYYMMDD_Format } from "../../../../utils/clonosCommon"
import { useSelector } from "react-redux"
import { doGetApiCall } from "../../../../utils/ClonosApi"

/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/
export const WarrantyDetails = ({ updateParentLcState, globalStateOfChildData, specificationsLcState, setChangedSpecifications, mode }) => {
  const [dropdownsData, setDropdownsData] = useState({ warrantyPeriods: [] });
  const [lcWarrantyDetails, setLcWarrantyDetails] = useState({});
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "calibrationDetails", isChildren: true });
      // const [loadingDropdowns, setLoadingDropdowns] = useState({});
      // const [staticDropdownData,setStaticDropdownData]=useState({})
  const selectedAutoFillAsset = useSelector(
      (store) => store.assetData.selectedAutoFillAsset
    );

  useEffect(() => {
    const tempWarrantyDetails = globalStateOfChildData?.specifications?.warrantyDetails ? { ...globalStateOfChildData?.specifications?.warrantyDetails } : {...selectedAutoFillAsset?.specifications?.warrantyDetails};
    updateParentLcState(prev => ({ ...prev, warrantyDetails: lcWarrantyDetails }));
    if (mode === "edit") {
      setChangedSpecifications((prev) => ({ ...prev, warrantyDetails: lcWarrantyDetails }))
    }
  }, [lcWarrantyDetails]);

//  const fetchStaticDropdownByCode = async (code) => {
//   if (staticDropdownData[code] || loadingDropdowns[code]) return;

//   setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

//   try {
//     const res = await doGetApiCall({url:`dropdowns/${code}`});
       
//     setStaticDropdownData(prev => ({
//       ...prev,
//       [code]: res?.data?.result?.options
//     }));
//   } finally {
//     setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
//   }
// };
  useEffect(() => {
    handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, warrantyPeriods: val })), moduleName: "specifications", enumTypeEndPoint: "warrantyDetails/warrantyPeriod/type" });
  }, [])

  // TO CHANGE WARRANTY END DATE DYNAMICALLY BASED ON INSTALLATION DATE
  useEffect(() => {
    if (lcWarrantyDetails?.warrantyPeriod?.value && lcWarrantyDetails?.warrantyPeriod?.type && (specificationsLcState?.manufacturingDetails?.installationDate || globalStateOfChildData?.specifications?.manufacturingDetails?.installationDate)) {
      let months = 0;
      if (lcWarrantyDetails?.warrantyPeriod?.type === "Years") {
        months = lcWarrantyDetails?.warrantyPeriod?.value * 12;
      } else {
        months = lcWarrantyDetails?.warrantyPeriod?.value;
      }
      let installationDate = specificationsLcState?.manufacturingDetails?.installationDate || globalStateOfChildData?.specifications?.manufacturingDetails?.installationDate;
      let date = new Date(installationDate);
      date.setMonth(date.getMonth() + Number(months));
      let updatedDate = date?.toISOString().slice(0, 10);
      setLcWarrantyDetails((prev) => {
        let temp = { ...prev, warrantyEndDate: updatedDate, defaultWarrantyEndDate: updatedDate };
        // getData(temp);
        return temp;
      });
    }
  }, [lcWarrantyDetails?.warrantyPeriod?.type, lcWarrantyDetails?.warrantyPeriod?.value, specificationsLcState?.manufacturingDetails?.installationDate,]);

  
  return <div className={Styles.container}>
    <div className={Styles.warrantyDetailsLeftContainer}>
      <h4>Warranty Details</h4>
      <ClonosRadioAndCheckbox
        isLabel={true}
        type="checkbox"
        name="warrantyInclusion"
        label="Warranty Included"
        areaLabel="Warranty Included"
        uniqueKey="isWarrantyIncluded"
        isChecked={specificationsLcState?.warrantyDetails?.isWarrantyIncluded  ||  globalStateOfChildData?.specifications?.warrantyDetails?.isWarrantyIncluded || lcWarrantyDetails?.isWarrantyIncluded}
        handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcWarrantyDetails, specificationsLcState, section: "warrantyDetails", globalStateOfChildData })}
      
      />
      <div className={Styles.warrantySubContainer}>
        <div>
          <ClonosInput
            limit={50}
            type="text"
            isLabel={true}
            label={"Supplier Name"}
            uniqueKey="supplierName"
            placeholder="Supplier Name"
            // isMandatory={lcWarrantyDetails?.isWarrantyIncluded || globalStateOfChildData?.specifications?.warrantyDetails?.isWarrantyIncluded}
            errorMessage={"Supplier Name is Required!."}
            defaultValue={specificationsLcState?.warrantyDetails?.supplierName ??  globalStateOfChildData?.specifications?.warrantyDetails?.supplierName}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcWarrantyDetails, specificationsLcState, section: "warrantyDetails", globalStateOfChildData })}
          />
        </div>
        <div>
          <ClonosInput
            limit={50}
            type="email"
            isLabel={true}
            label={"Email ID"}
            placeholder="Email ID"
            uniqueKey="supplierEmail"
            errorMessage={"Email ID is Required!."}
            // isMandatory={lcWarrantyDetails?.isWarrantyIncluded || globalStateOfChildData?.specifications?.warrantyDetails?.isWarrantyIncluded}
            defaultValue={specificationsLcState?.warrantyDetails?.supplierEmail ?? globalStateOfChildData?.specifications?.warrantyDetails?.supplierEmail}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcWarrantyDetails, specificationsLcState, section: "warrantyDetails", globalStateOfChildData })}
          />
        </div>
        <div>
          <div className={Styles.wrntTimeContainer}>
            <div className={Styles.inp_sel_container}>
              <div className={Styles.inp_sel_label_wrapper}>
                <label>Warranty Period </label>
                {lcWarrantyDetails?.isWarrantyIncluded || globalStateOfChildData?.specifications?.warrantyDetails?.isWarrantyIncluded ? <sup>*</sup> : <></>}
              </div>
              <div className={Styles.inp_sel_wrapper}>
                <div className={Styles.inp_wrapper}>
                  <ClonosInput
                    limit={3}
                    isLabel={false}
                    type={"number"}
                    isMandatory={false}
                    placeholder={"1234"}
                    uniqueKey={"warrantyPeriod_value"}
                    errorMessage={"Fill this field!"}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    defaultValue={Number(specificationsLcState?.warrantyDetails?.warrantyPeriod?.value)   ?? globalStateOfChildData?.specifications?.warrantyDetails?.warrantyPeriod?.value}
                    // isMandatory={lcWarrantyDetails?.isWarrantyIncluded || globalStateOfChildData?.specifications?.warrantyDetails?.isWarrantyIncluded}
                    handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props,primaryObject, handlePrimaryObjectModifier, setFormData: setLcWarrantyDetails, specificationsLcState, section: "warrantyDetails", globalStateOfChildData })}
                  />
                </div>
                <div className={Styles.sel_wrapper}>
                  <ClonosSelect
                    type={"select"}
                    isMandatory={false}
                    placeholder={"select"}
                    errorMessage={"Fill this field!"}
                    uniqueKey={"warrantyPeriod_type"}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    options={dropdownsData?.warrantyPeriods?.map((value) => ({ label: value, isNeeded: true }))}
                    //options={staticDropdownData?.warrantyPeriod?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
                    defaultValue={specificationsLcState?.warrantyDetails?.warrantyPeriod?.type   ?? globalStateOfChildData?.specifications?.warrantyDetails?.warrantyPeriod?.type}
                    // isMandatory={lcWarrantyDetails?.isWarrantyIncluded || globalStateOfChildData?.specifications?.warrantyDetails?.isWarrantyIncluded}
                    handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props,primaryObject, handlePrimaryObjectModifier, setFormData: setLcWarrantyDetails, specificationsLcState, section: "warrantyDetails", globalStateOfChildData })}
                      // onOpen={() => fetchStaticDropdownByCode("warrantyPeriod")}
                  />
                </div>
              </div>
            </div>
            <div className={Styles.wrntyEndDate}>
              <ClonosInput
                type="date"
                isLabel={true}
                label="Warranty End Date"
                uniqueKey="warrantyEndDate"
                placeholder="Warranty End Date"
                errorMessage={"Warranty End Date is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                value={lcWarrantyDetails?.warrantyEndDate}
                defaultValue={
                  specificationsLcState?.warrantyDetails?.warrantyEndDate
                    ? getYYYYMMDD_Format(
                        specificationsLcState.warrantyDetails.warrantyEndDate
                      )
                    : globalStateOfChildData?.specifications?.warrantyDetails?.warrantyEndDate
                    ? getYYYYMMDD_Format(
                        globalStateOfChildData.specifications.warrantyDetails.warrantyEndDate
                      )
                    : null
                }
                //defaultValue={globalStateOfChildData?.specifications?.warrantyDetails?.warrantyEndDate ? getYYYYMMDD_Format(globalStateOfChildData?.specifications?.warrantyDetails?.warrantyEndDate) : null}
                // isMandatory={lcWarrantyDetails?.isWarrantyIncluded || globalStateOfChildData?.specifications?.warrantyDetails?.isWarrantyIncluded}
                handleGetValues={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcWarrantyDetails, specificationsLcState, section: "warrantyDetails", globalStateOfChildData })}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className={Styles.warrantyDetailsRightContainer}>
      <div>
        <FileUploader
          label={"Terms & Conditions"}
          title={"termsAndConditions"}
          uniqueKey="termsAndConditions"
          typeOfRecord={"File"}
          isMandatory={false}
          limit={1}
          acceptableFileTypes={[".pdf", ".doc", ".xls", ".ppt"]}
          fileSizeInMB={10}
          defaultValue={
            globalStateOfChildData?.specifications?.warrantyDetails?.termsAndConditions &&
              [globalStateOfChildData?.specifications?.warrantyDetails?.termsAndConditions]
          }
          handleGetSelectedData={(props) => handleGetFilledValuesOfSpecifications({ componentProps: props, primaryObject, handlePrimaryObjectModifier, setFormData: setLcWarrantyDetails, specificationsLcState, section: "warrantyDetails", globalStateOfChildData })}
        />
      </div>
    </div>
  </div>
}