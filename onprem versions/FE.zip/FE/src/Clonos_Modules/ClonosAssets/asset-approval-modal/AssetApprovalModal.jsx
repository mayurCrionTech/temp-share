import { useRef, useState } from "react"
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import ClonosTextarea from "../../../components/CommonComponents/ClonosTextarea/ClonosTextarea"
import Modal from "../../../components/CommonComponents/Modal/Modal"
import Styles from "./asset-approval-modal.module.css"
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook"
import { PapperClipStaticIcon } from "../../../resources/icons/static/PapperClipStaticIcon"
import { handleValidateFiles } from "../../../utils/common-managers"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import DeleteIcon from "../../../assets/Clonos Common Indicators/Icon_Components/DeleteIcon"
import { FileStaticIcon } from "../../../resources/icons/static/FileStaticIcon"


/**
 * 
 * @param {String} requestFor -  Action name, for which approval requested e.g. "Delete", "Decommission", 
 * @returns 
 */
export const AssetApprovalModal = ({heading,isOpen,closeMethod,requestFor,SubmitBtnText}) => {
    const [lcFiles,setLcFiles] = useState([]);
    const [lcComment,setLcComment] = useState("");
    const inputRef = useRef();
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false})
    const handleGetValues = (props) => {
        const {uniqueKey,updatedValue,type} = props;
        handlePrimaryObjectModifier({uniqueKey,response:updatedValue});
        setLcComment(updatedValue)
    }

    const handleGetFiles = (e) => {
        const files = e.target.files;
        // handleValidateFiles({})
    
        setLcFiles(prev => ([...prev,...files]))
    }

    return <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
        <div className={Styles.container}>
            <div className={Styles.header}>
                <h4>{heading}</h4>
                <CloseIcon/>
            </div>
            <div className={Styles.section}>
                <ClonosTextarea 
                    type="text"
                    isLabel={true}
                    label={"Reason"}
                    placeholder={"Reason"}
                    uniqueKey={"comment"}
                    isMandatory={true}
                    handleGetValues={handleGetValues}
                    errorMessage={"Please add a reason."}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                >
                </ClonosTextarea>
                <div className={Styles.media_wrapper}>
                    <label>Attach Documents</label>
                    <input multiple accept={[".png",".jpg",".jpeg",".pdf"]} ref={inputRef} type="file" onChange={handleGetFiles} style={{display:"none"}} />
                    <div>
                        <div onClick={() => inputRef?.current?.click()} className={Styles.attach_btn}>
                            <PapperClipStaticIcon/>
                            <h4>Attach</h4>
                        </div>
                    </div>
                    <div className={Styles.f_p_wrapper}>
                        {
                            lcFiles?.map(file => {
                                return <div className={Styles.f_p_item}>
                                    {file?.type?.includes("pdf") ? <FileStaticIcon/> : <img src={URL.createObjectURL(file)}  />}
                                    <p>File Name</p>
                                    <DeleteIcon size="24px" strokeColor={"#D24B5A"}/>
                                </div>
                            })
                        }
                    </div>
                </div>
            </div>
            <div className={Styles.footer}>
                <div className={Styles.btn_wrapper}>
                    <ClonosButton>Cancel</ClonosButton>
                    <ClonosButton variant="filled">Approve</ClonosButton>
                </div>
            </div>
        </div>
    </Modal>
}