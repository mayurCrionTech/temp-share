import Styles from "../../Style/uploadDocumentModal.module.css";
import CLOSEICON from "../../../../assets/UIUX/icons/x-circle-fill.svg";
import DOWNANGLE from "../../../../assets/UIUX/icons/chevron-down.svg";
import { useState } from "react";
import { useRef } from "react";
import { useEffect } from "react";
import { handleGetStaticDropdownValues } from "../../../../utils/DropdownsMethods/DropdownsMethods";
import { useDispatch } from "react-redux";
import UPLOADFILEICON from "../../../../assets/UIUX/icons/fileuploadIcon.svg";
import FILE from "../../../../assets/UIUX/icons/file.svg";
import DELETEICON from "../../../../assets/UIUX/icons/redTrash.svg";
import { debounce, globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../../utils/clonosCommon";
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import ClonosTooltip from "../../../../components/CommonComponents/ClonosTooltip/ClonosTooltip";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import { v4 as uuidv4 } from 'uuid';
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";
import { handleCreateDocument, handleGetChangedValuesOfAssetDocument, handleGetDocumentEnums } from "../../asset-documents/asset-documents-manager";
import { handleCheckUniqueFieldsMethod, handleUploadSingleFileAndGetId, handleValidateFiles } from "../../../../utils/common-managers";
import useToggler from "../../../../CustomHooks/TogglerHook";
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { CLONOS_GLOBAL_COLOUR_RED, CLONOS_GLOBAL_ERROR_HANDLING_SIZE, CLONOS_GLOBAL_FILE_SIZE_PDF } from "../../../../Constants/Constant";
import { ErrorSVGCom } from "../../../../assets/svg/ErrorHandling";
import { doGetApiCall } from "../../../../utils/ClonosApi";


/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/

export const UploadDocumentModal = ({ data,modeOfAsset,setMode, loading, open,assetDetails, closeModalMethod, mode ,getFilledDetails}) => {
  const dispatch = useDispatch();
  const [formData, setFormData] = useState();
  const [docTypes, setDocTypes] = useState([]);
  const [status, setStatus] = useState([]);
  const [showFileError,setShowFileError] = useState(false)
  const [fieldError,setFieldError] = useState({
    showFileError:false,
    showDocumentNameError:false,
    errorMessage:"Document Name is required!"
  })
  const fileUploaderRef = useRef(null);
  const [uploadFileLoader,setUploadFileLoader] = useToggler();
  const {primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetDocument" })
  //CR0001 
  const [loadingDropdowns, setLoadingDropdowns] = useState({});
   const [staticDropdownData,setStaticDropdownData]=useState({})

  const handleGetValues = (props) => {
    handleGetChangedValuesOfAssetDocument({mode,elementProps:props,assetDetails,formData,setFormData,handlePrimaryObjectModifier,primaryObject})
  }


  const handleChangeDocumentName = (e) => {
    const value = e.target.value;
    if(!value?.length) {
      setFieldError(prev => ({...prev,showDocumentNameError:true,errorMessage:"Document Name is required!"}));
      return
    }
    if(value !== data?.name){
      handleCheckUniqueFieldsMethod({ module:"assetDocuments", fieldName:"name", fieldValue:`${assetDetails?.number?.name ?? assetDetails?.number ?? ""}-${value}`}).then((res) => {
        if (res === "not_unique") {
            setFieldError(prev => ({...prev,showDocumentNameError:true,errorMessage:"Already exists, please provide different name!"}))
        } else {
            setFormData(prev => ({...prev,name:`${assetDetails?.number?.name ?? assetDetails?.number ?? ""}-${value}`}))
            setFieldError(prev => ({...prev,showDocumentNameError:false,errorMessage:""}))
        }
      })
    } else {
      setFormData(prev => ({...prev,name:`${assetDetails?.number?.name ?? assetDetails?.number ?? ""}-${value}`}))
      setFieldError(prev => ({...prev,showDocumentNameError:false,errorMessage:""}))
    }
  }

  const handleDebounceDocumentName = debounce(handleChangeDocumentName,500)


  const handleBlurDocumentName = (e) => {
    const value = e.target.value;
    if(value?.length === 0) {
      setFieldError(prev => ({...prev,showDocumentNameError:true}))
    } else {
      setFieldError(prev => ({...prev,showDocumentNameError:false}))
    }
  }


  const handleUploadFile = (e) => {
    let files = Array.from(e.target.files);
    // Reset input so the same file can be selected again
     e.target.value = "";
    //const validatedFiles = handleValidateFiles({dispatch,limit:1,fileSizeInMB:CLONOS_GLOBAL_FILE_SIZE_PDF,acceptableFileTypes:[".pdf"],files});
    const validatedFiles = handleValidateFiles({dispatch,limit:1,fileSizeInMB:10,acceptableFileTypes:[".pdf"],files});
    if(!validatedFiles.length) return
    handleUploadSingleFileAndGetId({file:validatedFiles[0],setIsLoading:setUploadFileLoader}).then((res) => {
      if(res) {
        setFormData(prev => ({...prev,file:res}));
        setFieldError(prev => ({...prev,showFileError:false}))
      }
    })
  };


  const handleSave =() => {
  
    if(!formData?.name) setFieldError(prev => ({...prev,showDocumentNameError:true,errorMessage:"Document Name is required!"}));
    if(!handleSubmit()) return 
    if(!formData?.file) {
      setFieldError(prev => ({...prev,showFileError:true}))
      return
    }
     getFilledDetails(formData)
  }


  const handleRemoveFile = () => {
    setFormData(prev => ({...prev,file:null}))
  };

  //CR0001 
 const fetchStaticDropdownByCode = async (code) => {
  if (staticDropdownData[code] || loadingDropdowns[code]) return;

  setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

  try {
    const res = await doGetApiCall({url:`dropdowns/${code}`});
       
    setStaticDropdownData(prev => ({
      ...prev,
      [code]: res?.data?.result?.options
    }));
  } finally {
    setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
  }
};

  // useEffect(() => {
  //  // handleGetDocumentEnums({setterMethod:setDocTypes,name:"types"})
  //  // handleGetDocumentEnums({setterMethod:setStatus,name:"status"})

  //   return () => {
  //     setFormData({});
  //     setMode(modeOfAsset)
  //   }
  // }, []);

  useEffect(() => {
    setFormData({ ...data });
  }, [data]);



  return (
    <Modal isOpen={open} closeModalMethod={closeModalMethod} stopOverlayCloser={true}>
      <div className={Styles.modalContainer}>
        <div className={Styles.headerContainer}>
          <h4 className={Styles.header}>Upload Document</h4>
          <div onClick={closeModalMethod} style={{ cursor: "pointer" }}>
            <img src={CLOSEICON} />
          </div>
        </div>
        <div className={Styles.inputsContainer}>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
            <label>Document Name <sup style={{color:"red"}}>*</sup></label>  
            <div className={Styles.prefix_input} style={{border:fieldError.showDocumentNameError ? "1px solid #d55866":"1px solid #8CA1C4" }}>
              {/* <p>{`${assetDetails?.number}-`}</p> */}
              <p>{`${assetDetails?.number?.name ?? assetDetails?.number ?? ""}-`}</p>

              <input 
              readOnly={formData?.fromCategory || assetDetails?.assetCategoryDocuments?.includes(formData?.name?.substring(assetDetails?.number?.length+1,formData?.name?.length))}
              defaultValue={formData?.name?.substring(assetDetails?.number?.length+1,formData?.name?.length)} onBlur={handleBlurDocumentName} onChange={handleDebounceDocumentName} placeholder="Name"/>
            </div>
            {fieldError.showDocumentNameError ? <span style={{ color: CLONOS_GLOBAL_COLOUR_RED }} className={Styles.clonos_input_error}><ErrorSVGCom size={CLONOS_GLOBAL_ERROR_HANDLING_SIZE} color={CLONOS_GLOBAL_COLOUR_RED} /> {fieldError.errorMessage}</span> : <></>}

            </div>
            <div className={Styles.fieldContainer}>
              <ClonosInput
                limit={15}
                type="text"
                isLabel={true}
                isMandatory={true}
                label={"Document Number"}
                uniqueKey="number"
                placeholder="Document Number"
                defaultValue={formData?.number}
                handleGetValues={handleGetValues}
                errorMessage={"Document Number is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
          </div>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
              <ClonosInput
                limit={15}
                type="text"
                isLabel={true}
                label={"Revision Number"}
                uniqueKey="revisionNumber"
                placeholder="Revision Number"
                isSpecialCharacterAllow={true}
                value={formData?.revisionNumber}
                handleGetValues={handleGetValues}
                onlyAllowTheseSpecialCharacters={["_", "-", "."]}
              />
            </div>
            <div className={Styles.fieldContainer}>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={true}
                placeholder="Select"
                label={"Document Type"}
                uniqueKey="type"
                handleGetValues={handleGetValues}
                defaultValue={ formData?.type?.name ?? formData?.type }
                errorMessage={"Document type is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                // options={docTypes?.map((opt) => ({ label: opt, value: opt, isNeeded: true }))}
                options={staticDropdownData?.documentType?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
                onOpen={() => fetchStaticDropdownByCode("documentType")}
              />
            </div>
          </div>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
              <ClonosSelect
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                uniqueKey="status"
                isMandatory={false}
                placeholder="Select"
                label={"Document Status"}
                handleGetValues={handleGetValues}
                defaultValue={formData?.status?.name ?? formData?.status }
                // options={status?.map((opt) => ({ label: opt, value: opt, isNeeded: true }))}
                  options={staticDropdownData?.documentStatus?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
                onOpen={() => fetchStaticDropdownByCode("documentStatus")}
              />
            </div>
          </div>
          <div className={Styles.flexBox}>
            <div className={Styles.fieldContainer}>
              <label>Upload Document</label>
              <input
                type="file"
                accept=".pdf"
                id={"document"}
                name="document"
                ref={fileUploaderRef}
                style={{ display: "none" }}
                onChange={handleUploadFile}
              />
              <div className={Styles.fileUploaderContainer}>
                <div
                  className={Styles.custom_button}
                  onClick={() => !uploadFileLoader && fileUploaderRef.current.click()}
                >
                  {uploadFileLoader ? <ClonosSpinner width={"21px"}/> : <img src={UPLOADFILEICON} />}
                  <h4>Upload</h4>
                </div>
                {(formData?.file?.name || formData?.fileName) && (
                  <div className={Styles.filePreviewBox}>
                    <div className={Styles.fileNameBox}>
                      <img src={FILE} />
                      <ClonosTooltip content={formData?.file?.name || formData?.fileName} >
                        <h4 >{formData?.file?.name || formData?.fileName} </h4>
                      </ClonosTooltip>
                    </div>
                    <div
                      className={Styles.deleteFileBox}
                      onClick={handleRemoveFile}
                    >
                      <img src={DELETEICON} />
                    </div>
                  </div>
                )}
              </div>
              {fieldError.showFileError ? <span style={{ color: CLONOS_GLOBAL_COLOUR_RED }} className={Styles.clonos_input_error}><ErrorSVGCom size={CLONOS_GLOBAL_ERROR_HANDLING_SIZE} color={CLONOS_GLOBAL_COLOUR_RED} />Document is required!</span> : <></>}
            </div>
          </div>
        </div>
        <div className={Styles.btnController}>
          <div>
            <ClonosButton onClick={closeModalMethod}>Cancel</ClonosButton>
            <ClonosButton loading={loading} variant="filled" onClick={handleSave}>{mode === "edit" ? "Update" : "Save"}</ClonosButton>
          </div>
        </div>
      </div>
    </Modal>
  );
};
