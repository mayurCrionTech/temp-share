import { Tooltip } from "@material-ui/core";
import Styles from "./ImmediateParentChildAssetTree.module.css";
import { useEffect, useState } from "react";
import REDDOTCIRCLE from "../../../../assets/UIUX/icons/red-dot-filled.svg";
import { handleLoginExpiry } from "../../../../utils/clonosCommon";
import { getSingleAsset } from "../../../../Api/Asset/assetApi";

export const ImmediateParentChildAssetTree = ({
  assetGeneralDetails,
  dispatch,
}) => {
  const [parentAsset, setParentAsset] = useState("");
  useEffect(() => {
    if (assetGeneralDetails?.hierarchy?.parent ) {
      getSingleAsset(assetGeneralDetails?.hierarchy?.parent )
        .then((res) => {
          setParentAsset(res?.data?.result?.generalDetails?.name)
        })
        .catch((err) => {
          handleLoginExpiry(err, dispatch);
        });
    }
  }, [assetGeneralDetails]);

  return (
    <div>
      <div className={Styles.astParentAndChild}>
        {assetGeneralDetails?.hierarchy?.parent && parentAsset ? (
          <>
            <div className={Styles.astParent}>
              {/* <div className={Styles.astDot}></div> */}
              <img src={REDDOTCIRCLE} />
              <Tooltip title={parentAsset}>
                <h4 className={Styles.hrchyParentAsset}>{parentAsset} (Parent Asset)</h4>
              </Tooltip>
            </div>
            <div className={Styles.dotConnector}></div>
          </>
        ) : (
          <></>
        )}
        <div className={Styles.astChild}>
          {/* <div className={Styles.astDot}></div> */}
          <img src={REDDOTCIRCLE} />
          <Tooltip title={assetGeneralDetails?.assetName}>
            <h4 className={Styles.hrchyCurrentAsset}>
              {assetGeneralDetails?.assetName}
            </h4>
          </Tooltip>
        </div>
      </div>
    </div>
  );
};
