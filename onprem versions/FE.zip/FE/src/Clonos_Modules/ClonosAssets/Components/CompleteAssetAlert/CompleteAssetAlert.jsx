import { useEffect, useState } from "react"
import { AlertRedFilledCircleIcon } from "../../../../assets/AssetsSVGComponents/AlertRedFilledCircleIcon"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { WarningIcon } from "../../../../assets/Clonos Common Indicators/Icon_Components/WarningIcon"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "./CompleteAssetAlert.module.css"
import useToggler from "../../../../CustomHooks/TogglerHook"
import { handleGetIncompleteAssetRegistrationDetails } from "../../Utils/AssetsListMethods"
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner"
import { useNavigate } from "react-router-dom"
import { checkUserHasPermission } from "../../../../utils/clonosCommon"
import { CLONOS_GLOBAL_ACTION_UPDATE } from "../../../../Constants/Constant"
import AlertRedFilledCircleStaticIcon from "../../../../resources/icons/static/AlertRedFilledCircleStaticIcon"
export const CompleteAssetAlert = ({isOpen,closeMethod,asset}) => {
    const [assetDetails,setAssetDetails] = useState({});
    const [incompleteAssetRegistrationDetails,setIncompleteAssetRegistrationDetails] = useState({});
    const assetRegistrationModules = [""];
    const Navigate = useNavigate()
    const [isLoading,setIsLoading] = useToggler();
    const subModulesToCheck = [
        { keyToCheck: "isGeneralDetailsPresent", keyToShow: "General Details" },
        { keyToCheck: "isSpecificationsPresent", keyToShow: "Specifications" },
        { keyToCheck: "isLocationAndHierarchyDetailsPresent", keyToShow: "Location Details" },
        // { keyToCheck: "isPlant3DPresent", keyToShow: "Plant 3D" },
        { keyToCheck: "isParametersPresent", keyToShow: "Parameters" },
        // { keyToCheck: "isReferenceManualsPresent", keyToShow: "Reference Manuals" },
        { keyToCheck: "isDocumentsPresent", keyToShow: "Documents" },
        { keyToCheck: "isSparesPresent", keyToShow: "Spares" }
    ]
    
    
    useEffect(() => {
        handleGetIncompleteAssetRegistrationDetails({assetId:asset?.id,setterMethod:setIncompleteAssetRegistrationDetails,setIsLoading})
        return () => {
            setIncompleteAssetRegistrationDetails({})
        }
    },[asset]);


    
    return <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
            <div className={Styles.alert_container}>
                    <div className={Styles.alert_header}>
                            <WarningIcon/>
                        <h4>Complete Asset Registration</h4>
                    </div>
                    <div className={Styles.alert_section}>
                        {
                            isLoading ? <div className="center_wrapper"><ClonosSpinner/></div> : <>
                                <div className={Styles.alert_module_wrapper}>
                            {
                                subModulesToCheck?.map((module) => {
                                    return !incompleteAssetRegistrationDetails?.[module?.keyToCheck] ? <div >
                                        <div className={Styles.alert_icon_wrapper}>
                                            <AlertRedFilledCircleStaticIcon size={32}/>
                                        </div>
                                        <h4>{`Add ${module?.keyToShow}`}</h4>
                                    </div> : <></>
                                })
                            }
                        </div>
                        <div className={Styles.btn_wrapper}>
                            <ClonosButton onClick={() => closeMethod(false)} style={{border:"1px solid #E0606A",color:"#E0606A",padding:"0.5rem 2rem"}}>Cancel</ClonosButton>
                            <ClonosButton isDisabled={!checkUserHasPermission({moduleName:"users",action:CLONOS_GLOBAL_ACTION_UPDATE})} onClick={() => Navigate("/edit-asset",{state:{id:asset?.id}})} style={{padding:"0.5rem 2rem"}} variant="filled">Edit Asset</ClonosButton>
                        </div>
                            </>
                        }
                    </div>
                    <div className={Styles.alert_close}>
                        <CloseIcon onClick={() => closeMethod(false)}/>
                    </div>
            </div>
    </Modal>
}
