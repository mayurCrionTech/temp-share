import { useEffect, useRef, useState } from "react";
import useToggler from "../../../../CustomHooks/TogglerHook";
import DownTriangleStaticIcon from "../../../../resources/icons/static/DownTriangleStaticIcon"
import Styles from "./asset-status-dropdown.module.css"
import { statusStaticData } from "../../../../Constants/StaticData";
import { CLONOS_GLOBAL_STATUS_ACTIVE, CLONOS_GLOBAL_STATUS_BREAKDOWN, CLONOS_GLOBAL_STATUS_STANDBY, CLONOS_GLOBAL_STATUS_UNDER_MAINTENANCE } from "../../../../Constants/Constant";
export const AssetStatusDropdown = ({label,currentStatus,options,getSelectedValue}) => {
    const tempOptions = [statusStaticData[CLONOS_GLOBAL_STATUS_ACTIVE],statusStaticData[CLONOS_GLOBAL_STATUS_STANDBY],statusStaticData[CLONOS_GLOBAL_STATUS_UNDER_MAINTENANCE], statusStaticData[CLONOS_GLOBAL_STATUS_BREAKDOWN]];
    const [showOptions,setShowOptions] = useState(false);
    const dropdownRef = useRef(null);

    const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
            setShowOptions(false);
        }
    };

    const handleSelectOption = (option) => {
        getSelectedValue && getSelectedValue({value:option});
        setShowOptions(false)
    }

    useEffect(() => {
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    
    return <div ref={dropdownRef} className={Styles.container}>
        <div onClick={() => setShowOptions(true)} className={Styles.label_wrapper}>
            <p>{label}</p>
            <DownTriangleStaticIcon/>
        </div>
        {showOptions ? <div className={Styles.options_wrapper}>
            {
                tempOptions?.map((option,index) => {
                    return statusStaticData[currentStatus] !== option && <p key={index} onClick={() => handleSelectOption(option)} className={Styles.option}>{option}</p>
                })
            }
        </div> : <></>}
    </div>
}