import { StepConnector, makeStyles, withStyles } from "@material-ui/core";
import { clsx } from "clsx";
import PropTypes from "prop-types";
import FiberManualRecordIcon from "@material-ui/icons/FiberManualRecord";
import CheckIcon from "@material-ui/icons/Check";
import { useDispatch } from "react-redux";
import { validateGeneralDetails } from "../../general-details/general-details-managers";
import { validateSpecifications } from "../../Specifications/specifications-managers";
import { validateLocationAndHierarchy } from "../../location-and-hierarchy/location-and-hierarchy-manager";
import { handleStepperActiveStep } from "./stepper-managers";
import { useSelector } from "react-redux";
export const StepConnectorHandler = withStyles({
  alternativeLabel: {
    top: 22,
  },
  active: {
    "& $line": {
      border: "1px solid #06337E",
    },
  },
  completed: {
    "& $line": {
      border: "1px solid #06337E",
    },
  },
  line: {
    height: 3,
    border: 0,
    backgroundColor: "#eaeaf0",
    borderRadius: 1,
  },
})(StepConnector);

const useStepIconStyles = makeStyles({
  root: {
    backgroundColor: "#ccc",
    zIndex: 1,
    color: "#fff",
    width: 30,
    height: 30,
    display: "flex",
    borderRadius: "50%",
    justifyContent: "center",
    alignItems: "center",
  },
  active: {
    border: "1px solid #06337E",
    color: "#06337E",
  },
  completed: {
    border: "1px solid #06337E",
    color: "#06337E",
  },
  warning: {
  backgroundColor: "#FFC107",
  color: "#000",
},

});

export const StepIcon = (props) => {
  const classes = useStepIconStyles();
  const dispatch = useDispatch();
   const generalDetailsAutoFillChanged = useSelector(
    (store) => store.assetData.generalDetailsAutoFillChanged
  );
  const {
    active,
    completed,
    handleSetActiveStep,
    activeStep,
    formData,
    index,
  } = props;
  
  const assetDataFromLocalStorage = JSON.parse(localStorage.getItem("asset_details")) || {};
  const renderIcon = (condition) => condition ? <CheckIcon fontSize="small" /> : <FiberManualRecordIcon fontSize="small" />;
    const icons = {
      // 1: renderIcon(validateGeneralDetails({generalDetails:formData?.generalDetails})),
       1: renderIcon(activeStep > index || validateGeneralDetails({generalDetails:formData?.generalDetails})),
      2: renderIcon(activeStep > index || Object.keys({...(formData?.specifications || {})})?.length > 0),
      3: renderIcon(activeStep > index || Object.keys({...(formData?.locationAndHierarchyDetails?.geographicalCoordinates || {})})?.length > 0),
      4: renderIcon(activeStep > index),
      5: renderIcon(activeStep > index),
      6: renderIcon(activeStep > index),
    };

    const shouldBeYellow =
  generalDetailsAutoFillChanged && String(props.icon) === "1";

  return (
    <div
      className={clsx(classes.root, {
        [classes.active]: active,
        [classes.completed]: completed,
          [classes.warning]: shouldBeYellow,
      })}
      onClick={() => {
        handleStepperActiveStep({ index, activeStep, dispatch, formData, proceedNext: handleSetActiveStep })
      }}
    >
      {icons[String(props.icon)]}
    </div>
  );
};

StepIcon.propTypes = {
  /**
   * Whether this step is active.
   */
  active: PropTypes.bool,
  /**
   * Mark the step as completed. Is passed to child components.
   */
  completed: PropTypes.bool,
  /**
   * The label displayed in the step icon.
   */
  icon: PropTypes.node,
};
