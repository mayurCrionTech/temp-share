import { handleShowErrorAndWarning } from "../../../../utils/clonosCommon";
import { validateGeneralDetails } from "../../general-details/general-details-managers";
import { validateLocationAndHierarchy } from "../../location-and-hierarchy/location-and-hierarchy-manager";
import { validateSpecifications } from "../../Specifications/specifications-managers";

const requiredFieldsError = (dispatch) => {
    handleShowErrorAndWarning({dispatch,type:"error",message:"Please fill all the required fields ",showTime:"5000"})
  }
//   export const handleStepperActiveStep = ({index,activeStep,dispatch,formData,proceedNext}) => {
//       if (activeStep < index) {
//         if (index === 1) {
//           if (validateGeneralDetails({generalDetails:formData?.generalDetails})) {
//             proceedNext();
//           } else {
//             requiredFieldsError(dispatch)
//           }
//         } else if (index === 2 || index === 3 || index === 4 || index === 5) {
//           if (
//             validateGeneralDetails({generalDetails:formData?.generalDetails}) 
//           ) {
//             proceedNext();
//           } else {
//             requiredFieldsError(dispatch)
//           }
//         }
//         else if (index === 6) {
//           if(validGeneralDetails(formData) && validSpecificationsDetails(formData) && validLocationDetails(formData) ) {
//             if(formData?.assetParameters?.length && !validateAssetParametersValue(formData)){
//               handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide all details for added parameters.",showTime:"10000"})
//             } else if(formData?.assetParameters?.length && validateAssetParametersValue(formData) && !validateParameterNameUniqueness(formData?.assetParameters)){
//               handleShowErrorAndWarning({dispatch,type:"error",message:"Parameter's Name should be unique! ",showTime:"10000"})
//             } else if (validateAssetParametersValue(formData) && validateParameterNameUniqueness(formData?.assetParameters)){
//               proceedNext();
//             }
//           } else {
//             requiredFieldsError(dispatch)
//           }
//         } else if(index === 7){
//           if(validGeneralDetails(formData) && validSpecificationsDetails(formData) && validLocationDetails(formData) ){
//             proceedNext();
//           }
//         }
//       } else {
//         proceedNext();
//       }


     
//   }


    export const handleStepperActiveStep = ({index,activeStep,dispatch,formData,proceedNext}) => {
      // if (activeStep < index) {
      //   if (index === 1) {
      //     if (validateGeneralDetails({generalDetails:formData?.generalDetails})) {
      //       proceedNext();
      //     } else {
      //       requiredFieldsError(dispatch)
      //     }
      //   } else if (index === 2 || index === 3 || index === 4 || index === 5) {
      //     if (
      //       validateGeneralDetails({generalDetails:formData?.generalDetails}) 
      //     ) {
      //       proceedNext();
      //     } else {
      //       requiredFieldsError(dispatch)
      //     }
      //   }
      //   else if (index === 6) {
      //     if(validGeneralDetails(formData) && validSpecificationsDetails(formData) && validLocationDetails(formData) ) {
      //       if(formData?.assetParameters?.length && !validateAssetParametersValue(formData)){
      //         handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide all details for added parameters.",showTime:"10000"})
      //       } else if(formData?.assetParameters?.length && validateAssetParametersValue(formData) && !validateParameterNameUniqueness(formData?.assetParameters)){
      //         handleShowErrorAndWarning({dispatch,type:"error",message:"Parameter's Name should be unique! ",showTime:"10000"})
      //       } else if (validateAssetParametersValue(formData) && validateParameterNameUniqueness(formData?.assetParameters)){
      //         proceedNext();
      //       }
      //     } else {
      //       requiredFieldsError(dispatch)
      //     }
      //   } else if(index === 7){
      //     if(validGeneralDetails(formData) && validSpecificationsDetails(formData) && validLocationDetails(formData) ){
      //       proceedNext();
      //     }
      //   }
      // } else {
      //   proceedNext();
      // }


      proceedNext();
  }