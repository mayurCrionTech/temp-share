import { Step, StepConnector, StepLabel, Stepper } from "@material-ui/core"
import Styles from "./assetHorizontalStepper.module.css"
import { StepIcon } from "./StepConnectorHandler"


export const AssetHorizontalStepper = ({activeStep,steps,setActiveStep,globalStateOfChildData}) => {

    return <div className={Styles.StepperWrapper}>
    <Stepper
      alternativeLabel
      activeStep={activeStep}
      connector={<StepConnector />}
      style={{ background: "none" }}
    >
      {steps.map((label, index) => (
        <Step key={label}>
          <StepLabel
            StepIconComponent={(props) => {
              return <StepIcon
                {...props}
                handleSetActiveStep={() => setActiveStep(index)}
                activeStep={activeStep}
                formData={globalStateOfChildData}
                index={index}
              />
            }}
          >
            {label}
          </StepLabel>
        </Step>
      ))}
    </Stepper>
  </div>
}


  