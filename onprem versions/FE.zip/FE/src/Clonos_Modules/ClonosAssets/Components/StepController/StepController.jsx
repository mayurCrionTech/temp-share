import { useState } from "react";
import Styles from "../../Style/stepController.module.css"
import { useSelector } from "react-redux";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
export const StepController = ({handleBack,isSkippable,handleNext,handleSkip,activeStep,steps,loading}) => {
    return (
        <>
            <div className={Styles.controller_btn}>
                <div>
                <ClonosButton tabIndex={12} isDisabled={activeStep === 0} onClick={() => handleBack()}>{"Previous"}</ClonosButton>
                </div>
                <div>
                {
                    isSkippable ? <ClonosButton onClick={handleSkip}>Continue</ClonosButton> : <ClonosButton tabIndex={13} loading={loading} onClick={() => handleNext()}>{activeStep === steps.length - 1 ? 'View Assets' : 'Save & Next'}</ClonosButton>
                }
                
                </div>
            </div>
        </>
    )   
}