import { useNavigate } from "react-router-dom";
import {
  createAsset,
  createReferenceManualForAsset,
  deleteAsset,
  editAsset,
  editReferenceManualForAsset,
  getAllAssets,
  getAllAssetsWithoutLimit,
  getAssetModeDropdown,
  getAssetTypes,
  getFilteredAssets,
  getRunningModeDropdown,
  getexportableData,
} from "../../../Api/Asset/assetApi";
import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import {
  binaryDataToFile,
  getFormatedDate,
  handleGetENVVariables,
  handleLoginExpiry,
  handleShowErrorAndWarning,
  removeUserSession,
} from "../../../utils/clonosCommon";
import * as xlsx from "xlsx";
import Papa from "papaparse";
import { editAssociateDocs, uploadAssociateDocs } from "../../../Api/Documents/DocumentApi";
import { getAllAssetsDataMethod } from "../../../utils/AssetsMethods/AssetsList";
import { doPutApiCall ,doPostApiCall} from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS } from "../../../Constants/Constant";
// FOR HANDLING REQUIRED FIELD ERRORS :

export const validateForm = ({
  value,
  name,
  formData,
  setErrors,
  pageName,
  label,
}) => {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const newErrors = {};
  if (name) {
    if (name === "warrantyPeriod") {
      if (
        !formData?.warrantyPeriodNumber ||
        !formData?.warrantyPeriodDurr?.name
      ) {
        setErrors((prev) => ({
          ...prev,
          warrantyPeriod: "Warranty Period is required!",
        }));
      }
      if (
        formData?.warrantyPeriodNumber &&
        formData?.warrantyPeriodDurr?.name
      ) {
        setErrors((prev) => ({ ...prev, warrantyPeriod: "" }));
      }
    } else if (name === "supplierEmail") {
      if (!formData[name]) {
        setErrors((prev) => {
          let temp = {
            ...prev,
            [name]: "Supplier Email is required!.",
          };
          return temp;
        });
      } else {
        setErrors((prev) => {
          return {
            ...prev,
            [name]: emailRegex.test(formData.supplierEmail)
              ? ""
              : "Please provide valid Email.",
          };
        });
      }
    } else if (
      name === "zoneClassification" ||
      name === "gasGroup" ||
      name === "temperatureClassification"
    ) {
      if (!formData?.hazardousAreaDetails[name]) {
        setErrors((prev) => {
          let temp = {
            ...prev,
            [name]: `${label} is required!`,
          };
          return temp;
        });
      } else {
        setErrors((prev) => {
          return {
            ...prev,
            [name]: ``,
          };
        });
      }
    } else if (
      name === "latitude" ||
      name === "longitude" ||
      name === "elevation"
    ) {
      if (!formData?.geoLocation[name]) {
        setErrors((prev) => {
          let temp = {
            ...prev,
            [name]: `${label} is required!`,
          };
          return temp;
        });
      } else {
        setErrors((prev) => {
          return {
            ...prev,
            [name]: ``,
          };
        });
      }
    } else {
      if (!formData[name]) {
        setErrors((prev) => {
          let temp = {
            ...prev,
            [name]: `${label} is Required!.`,
          };
          return temp;
        });
      } else {
        setErrors((prev) => {
          let temp = {
            ...prev,
            [name]: ``,
          };
          return temp;
        });
      }
    }
  } else {
    if (pageName === "general details") {
      let tempErrors = {};
      let requiredFields = [
        { key: "assetName", label: "Asset Name" },
        { key: "assetNumber", label: "Asset Number" },
        { key: "assetDepartment", label: "Asset Department" },
        { key: "assetCategory", label: "Asset Category" },
        { key: "criticalityLevel", label: "Criticality Level" },
        { key: "functionalArea", label: "Functional Area" },
        { key: "assetOwner", label: "Asset Owner" },
      ];
      requiredFields.map((field) => {
        if (!formData[field.key]) {
          tempErrors[field.key] = `${field.label} is required!`;
        } else {
          tempErrors[field.key] = `${field.label} is required!`;
        }
      });
      setErrors(tempErrors);
    } else if (pageName === "specification") {
      let tempErrors = {};
      let requiredFields = [
        { key: "assetType", label: "Asset Type" },
        { key: "assetMake", label: "Asset Make" },
        { key: "assetModel", label: "Asset Model" },
        { key: "manufacturer", label: "Manufacturer" },
        { key: "installationDate", label: "Installation Date" },
        { key: "serviceLiquid", label: "Service Liquid" },
        { key: "zoneClassification", label: "Zone Classification" },
        { key: "gasGroup", label: "Gas Group" },
        {
          key: "temperatureClassification",
          label: "Temperature Classification",
        },
        { key: "supplierName", label: "Supplier Name" },
        { key: "supplierEmail", label: "Supplier Email" },
        { key: "warrantyEndDate", label: "WarrantyEnd Date" },
        { key: "warrantyPeriod", label: "Warranty Period" },
      ];
      requiredFields.map((field) => {
        if (
          field.key === "zoneClassification" ||
          field.key === "temperatureClassification" ||
          field.key === "gasGroup"
        ) {
          if (
            !formData?.hazardousAreaDetails ||
            !formData?.hazardousAreaDetails[field.key]
          ) {
            tempErrors[field.key] = `${field.label} is required!`;
          } else {
            tempErrors[field.key] = ``;
          }
        }
        if (!formData[field.key]) {
          tempErrors[field.key] = `${field.label} is required!`;
        } else {
          tempErrors[field.key] = ``;
        }
      });
      setErrors(tempErrors);
    }
  }
  return Object.keys(newErrors).length === 0; // Returns true if no errors
};

// TO VALIDATE MULTISTEP FORM DATA WHILE CREATING OR EDITING ASSET
export const validGeneralDetails = (formData) => {
  // const { assetName, assetNumber, assetDepartment, criticalityLevel, functionalArea, assetOwner, assetCategory } = formData;
  // return (assetName && assetNumber && assetDepartment?.name && criticalityLevel?.name && functionalArea?.name && assetOwner?.name && assetCategory?.name) ? true : false;
  return true;
};

export const validSpecificationsDetails = (formData) => {
  // if (
  //   formData?.assetType &&
  //   formData?.manufacturer &&
  //   formData?.installationDate &&
  //   formData?.serviceLiquid &&
  //   formData?.hazardousAreaDetails?.zoneClassification &&
  //   formData?.hazardousAreaDetails?.gasGroup &&
  //   formData?.hazardousAreaDetails?.temperatureClassification && (formData.assetType === "aty-001" ? (formData?.assetMake && formData?.assetModel) : true)
  // ) {
  //   if (formData?.isWarrantyIncluded) {
  //     const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  //     if (
  //       emailRegex.test(formData?.supplierEmail) &&
  //       formData?.supplierName &&
  //       formData?.warrantyPeriodNumber &&
  //       formData?.warrantyPeriodDurr?.id &&
  //       formData?.warrantyEndDate
  //     ) {
  //       return true;
  //     } else {
  //       return false;
  //     }
  //   } else {
  //     return true;
  //   }
  // } else {
  //   return false;
  // }
  return true;
};

export const validLocationDetails = (formData) => {
  // if (
  //   formData?.location?.name &&
  //   formData?.geoLocation?.elevation &&
  //   formData?.geoLocation?.longitude &&
  //   formData?.geoLocation?.latitude
  // ) {
  //   return true;
  // } else {
  //   return false;
  // }
  return true;
};
export const validate3DDetails = (formData, changedData) => {
  // if (
  //   !isNaN(formData?.asset3DmodelPosition?.x) ||
  //   !isNaN(formData?.asset3DmodelPosition?.y) ||
  //   !isNaN(formData?.asset3DmodelPosition?.z) ||
  //   !isNaN(formData?.asset3DmodelRotation?.x) ||
  //   !isNaN(formData?.asset3DmodelRotation?.y) ||
  //   !isNaN(formData?.asset3DmodelRotation?.z) ||
  //   (formData?.asset3DModel || changedData?.asset3DModel) ||
  //   (formData?.assetLayoutImage || changedData?.assetLayoutImage)
  // ) {
  //   return true
  // } else {
  //   return false
  // }
  return true;
};
export const validateAssetParametersValue = (formData) => {
  let allSet = true;
  if (!formData?.assetParameters?.length) return true;
  formData?.assetParameters?.map((param) => {
    if (!param?.name || !param?.description || !param?.unit) {
      allSet = false;
      return allSet;
    }
  });
  return allSet;
};


export const validateParameterNameUniqueness = (parameters) => {
  if (!parameters?.length) return true;
  const parametersNamesObj = {};
  parameters?.map((param) => {
    if (!parametersNamesObj[param.name]) {
      parametersNamesObj[param.name] = 1
    } else {
      parametersNamesObj[param.name] = parametersNamesObj[param.name] + 1
    }
  })
  if (Object.keys(parametersNamesObj)?.length !== parameters?.length) {
    return false;
  } else {
    return true;
  }

}

export const validateReferenceManualsValue = (formData) => {
  let allSet = false;
  const instructionsDocuments = formData?.instructionsDocuments || formData?.referenceManuals && [formData?.referenceManuals] || []    // handled for both create & edit response;
  if (!instructionsDocuments?.length) return true;
  instructionsDocuments?.forEach((ref) => {
    if (!ref?.instructions?.length) {
      allSet = false;
      return allSet;
    }
    ref?.instructions?.forEach((instruction) => {
      if ((instruction?.instructionTitle || instruction?.instructionFile) || (instruction?.instruction || instruction?.documentName)) {
        allSet = true;
        return;
      }
    });
  });
  return allSet;
};

const validateAssetParameters = (parameters) => {
  let validParameters = parameters?.filter((param) => {
    return param?.name || param?.description || param?.unit;
  });
  return validParameters;
};


export const validateAssetDocuments = (documents) => {
  let isDocumentsUploaded = false;
  documents?.length && documents?.forEach((doc) => {
    if ((doc?.documentNumber && doc?.documentType)) {
      isDocumentsUploaded = true;
      return isDocumentsUploaded
    }
  })
  return isDocumentsUploaded
}


// TO GET VALUES FROM CLONOS CUSTOM COMPONENTS LIKE SELECT, INPUT AND DYNAMIC DROPDOWN
export const handleGetValuesMethod = ({
  val,
  setFormData,
  getData,
  getChangedValues,
  changedData,
}) => {
  let { type } = val;
  if (type === "select") {
    let { uniqueKey, updatedValue } = val;
    setFormData((prev) => {
      let temp = {
        ...prev,
        [uniqueKey]: { name: updatedValue?.label, id: updatedValue?.value },
      };
      if (getChangedValues) {
        let changeIn = {
          ...changedData,
          [uniqueKey]: { name: updatedValue?.label, id: updatedValue?.value },
        };
        getChangedValues(changeIn);
      }
      if (getData) getData(temp);
      return temp;
    });
  } else if (type === "dynamicDropdown") {
    let { name, selectedOption } = val;
    if (name === "assetowner") name = "assetOwner";
    if (name === "parentasset") name = "parentAsset";
    setFormData((prev) => {
      let temp = {
        ...prev,
        [name]: selectedOption?.length ? { name: selectedOption[0]?.name, id: selectedOption[0]?.id } : null,
      };
      if (getChangedValues) {
        let changeIn = {
          ...changedData,
          [name]: selectedOption?.length ? { name: selectedOption[0]?.name, id: selectedOption[0]?.id } : null
        };
        getChangedValues(changeIn);
      }
      if (getData) getData(temp);
      return temp;
    });
  } else if (
    type === "text" ||
    type === "number" ||
    type === "textarea" ||
    type === "date"
  ) {
    let { uniqueKey, updatedValue } = val;
    setFormData((prev) => {
      let temp = {
        ...prev,
        [uniqueKey]: updatedValue,
      };
      if (getChangedValues) {
        let changeIn = { ...changedData, [uniqueKey]: updatedValue };
        getChangedValues(changeIn);
      }
      if (getData) getData(temp);
      return temp;
    });
  }
};

function isAsset3DDetailsPresent(formData){
  return (formData?.asset3DModel && formData?.assetLayoutImage && formData?.interactability?.id) ? true : false;
}

function isAssetDocumentsPresent(formData) {
  return formData?.documents?.length ? true : false
}

function isAssetParametersPresent(formData){
  const parameters = validateAssetParameters(formData?.assetParameters);
  return parameters?.length ? true : false
}

function isAssetReferenceManualsPresent(formData){
  return formData?.referenceManuals?.length ? true : false;
}


// TO CREATE A NEW ASSET
export const createNewAsset = async ({
  formData,
  dispatch,
  getUpdatedStatusOFAssetCreation,
  operationType,
  getCreatedAssetDetails,
}) => {
  const { assetName, assetNumber, assetDescription, assetMode, runningMode, assetDepartment, assetCategory, criticalityLevel, functionalArea, assetOwner, censusNumber, assetType, assetMake, assetModel, serialNumber, manufacturer, installationDate, serviceLiquid, hazardousAreaDetails, location, geoLocation, parentAsset, isWarrantyIncluded, warrantyPeriodNumber, warrantyPeriodDurr, warrantyPeriod, supplierName, supplierEmail, warrantyEndDate, asset3DmodelRotation, asset3DmodelPosition, asset3DModel, assetLayoutImage, assetImagesToDelete, assetImages, assetTermsAndConditions } = formData
  if (installationDate) formData["installationDate"] = new Date(installationDate).toISOString();
  if (warrantyEndDate) formData["warrantyEndDate"] = new Date(warrantyEndDate).toISOString();
  const parameters = validateAssetParameters(formData?.assetParameters);
  const form_data = new FormData();
  const assetStatus = operationType === "created" ? "Active" : operationType === "drafted" ? "Draft" : "";
  form_data.append(`assetStatus`, assetStatus);
  assetName && form_data.append(`assetName`, assetName);
  assetNumber && form_data.append(`assetNumber`, assetNumber);
  assetDescription && form_data.append(`assetDescription`, assetDescription);
  assetMode && form_data.append(`assetMode`, assetMode?.id);
  runningMode && form_data.append(`runningMode`, runningMode?.id);
  assetDepartment && form_data.append(`assetDepartment`, assetDepartment?.id);
  assetCategory && form_data.append(`assetCategory`, assetCategory?.id);
  criticalityLevel && form_data.append(`criticalityLevel`, criticalityLevel?.id);
  functionalArea && form_data.append(`functionalArea`, functionalArea?.id);
  assetOwner && form_data.append(`assetOwner`, assetOwner?.id);
  censusNumber && form_data.append(`censusNumber`, censusNumber);
  assetType && form_data.append(`assetType`, assetType);
  assetMake && form_data.append(`assetMake`, assetMake);
  assetModel && form_data.append(`assetModel`, assetModel);
  serialNumber && form_data.append(`serialNumber`, serialNumber);
  manufacturer && form_data.append(`manufacturer`, manufacturer);
  installationDate && form_data.append(`installationDate`, installationDate);
  serviceLiquid && form_data.append(`serviceLiquid`, serviceLiquid);
  hazardousAreaDetails && form_data.append(`hazardousAreaDetails`, JSON.stringify(hazardousAreaDetails));
  location && form_data.append(`location`, location?.id);
  geoLocation && form_data.append(`geoLocation`, JSON.stringify(geoLocation));
  parentAsset?.id && form_data.append(`parentAsset`, parentAsset?.id);
  form_data.append(`isWarrantyIncluded`, isWarrantyIncluded ? isWarrantyIncluded : false);
  supplierName && form_data.append(`supplierName`, supplierName);
  supplierEmail && form_data.append(`supplierEmail`, supplierEmail);
  isWarrantyIncluded && form_data.append(`warrantyPeriodNumber`, warrantyPeriodNumber);
  isWarrantyIncluded && form_data.append(`warrantyPeriodDurr`, warrantyPeriodDurr?.id);
  isWarrantyIncluded && form_data.append(`warrantyPeriod`, warrantyPeriodNumber + " " + warrantyPeriodDurr?.id);
  warrantyEndDate && form_data.append(`warrantyEndDate`, warrantyEndDate);
  const { x, y, z } = asset3DmodelRotation || {};
  let tempPositions = { x: asset3DmodelPosition?.x || "0", y: asset3DmodelPosition?.y || "0", z: asset3DmodelPosition?.z || "0" };
  let tempRotations = { x: asset3DmodelRotation?.x || "0", y: asset3DmodelRotation?.y || "0", z: asset3DmodelRotation?.z || "0" }
  asset3DmodelRotation && form_data.append(`asset3DmodelRotation`, JSON.stringify(tempRotations));
  asset3DmodelPosition && form_data.append(`asset3DmodelPosition`, JSON.stringify(tempPositions));
  asset3DModel && form_data.append(`asset3DModel`, asset3DModel);
  assetLayoutImage && form_data.append(`assetLayoutImage`, assetLayoutImage);
  assetImages?.length >= 0 && assetImages.forEach((file, index) => { form_data.append(`assetImage${index}`, file); });
  assetTermsAndConditions?.length >= 0 && assetTermsAndConditions.forEach((file, index) => { form_data.append(`assetTermsAndConditions${index}`, file); });
  parameters?.length > 0 && form_data.append(`assetParameters`, JSON.stringify(parameters));
  if (operationType === "created") dispatch(assetActions.setAssetCreationLoading(true))
  if (operationType === "drafted") dispatch(assetActions.setAssetDraftLoading(true));
  if(isAsset3DDetailsPresent) form_data.append(`isAsset3DDetailsPresent`,true)
  if(isAssetDocumentsPresent) form_data.append(`isAssetDocumentsPresent`,true)
  if(isAssetParametersPresent) form_data.append(`isAssetParametersPresent`,true)
  if(isAssetReferenceManualsPresent) form_data.append(`isAssetReferenceManualsPresent`,true)
  let assetCreated = false;
  let referenceCreated = false;
  let documentsCreated = false;
  let sparesCreated = false;
  try {

    // ASSET CREATION PHASE
    const assetCreationRes = await doPostApiCall(AppUrl.createAsset, form_data, "multipart/form-data");
    const assetId = assetCreationRes?.data?.result?._id;
    if (assetCreationRes?.data?.status !== CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
      throw new Error("Something went wrong during asset creation");
    }
    assetCreated = true;

    // REFERENCE MANUAL CREATION PHASE
    if (formData?.instructionsDocuments?.length > 0) {
      const payload = constructReferenceManualsPayload(formData);
      const url = "assets/" + assetId + "/referenceManuals";
      const referenceCreationAsset = await createReferenceManuals(url, payload);

      if (referenceCreationAsset?.data?.status !== CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
        throw new Error("Something went wrong during asset reference creation");
      }
    }
    referenceCreated = true;

    // DOCUMENTS CREATION PHASE
    if (formData?.documents?.length > 0) {
      const arrayOfDocsPayload = createAssetDocuments({ assetId, assetDetails: formData }).filter(a => a)
      let successDocs = 0;
      await (async () => {
        for (let i = 0; i < arrayOfDocsPayload?.length; i++) {
          try {
            let res = await documentApi(arrayOfDocsPayload[i]);
            if (res?.data?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
              successDocs++;
            } else {
              throw new Error();
            }
          } catch (err) {
            handleLoginExpiry(err, dispatch)
          }
        }
      })()
      if (successDocs !== arrayOfDocsPayload?.length)
        throw new Error("Something went wrong during asset document creation");
    }
    documentsCreated = true;

    // SPARES CREATION PHASE

    if(formData?.spares?.length){
      const sparesResponse = await handleCreateMultipleSpares({formData});
      if(sparesResponse?.status !== CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
        throw new Error("Something went wrong during spares creation");
      }
    }
    sparesCreated = true;
    
    dispatch(assetActions.setAssetCreationLoading(false));
    dispatch(assetActions.setAssetDraftLoading(false));
    getUpdatedStatusOFAssetCreation(true);
    getCreatedAssetDetails({isSuccess: true, assetId: assetId, operationType, message: `Asset ${operationType} successfully.`, });
  } catch (e) {
    const error = e?.response?.data;
    dispatch(assetActions.setAssetCreationLoading(false));
    dispatch(assetActions.setAssetDraftLoading(false));
    getUpdatedStatusOFAssetCreation(true);
    let message = '';
    if (!assetCreated && !referenceCreated )
      message = `Something went wrong while saving Assets.`
    else if (assetCreated && !referenceCreated)
      message = `Something went wrong while saving Assets Reference.`
    else if (assetCreated && referenceCreated && !documentsCreated)
      message = `Something went wrong while saving Assets Documents.`
    else if(assetCreated && !sparesCreated)
      message = `Something went wrong while saving Spares`
    if (handleGetENVVariables().REACT_APP_BUILDTYPE === "TESTING") {
      message = message + " " + error?.message ? error?.message : "Encountered server error!"
    }
    getCreatedAssetDetails({ isSuccess: false, assetId: '', operationType, message});
  }
};



// TO CREATE ASSOCIATED DOCUMENTS WITH ASSET
const createAssetDocuments = ({ assetId, assetDetails }) => {

  let documentsCount = 0;
  let document_checks = {};
  const { documents } = assetDetails;
  return documents.map((document, index) => {
    const form_data1 = new FormData();
    const { documentName, documentNumber, documentType, revisionNumber, status, file } = document;
    form_data1.append("assetId", assetId);
    if (file) {
      documentsCount++;
      file && form_data1.append(`file1`, file);
      documentName && form_data1.append(`documentName`, documentName);
      documentNumber && form_data1.append(`documentNumber`, documentNumber);
      documentType && form_data1.append(`documentType`, documentType?.id);
      revisionNumber && form_data1.append(`revisionNumber`, revisionNumber);
      status?.id && form_data1.append(`status`, status?.id);
      form_data1.append("noOfFiles", 1);
      document_checks[`${file.id}`] = true;
      return form_data1;
    }
  });
};

// TO  CREATE REFERENCE MANUALS OF ASSET
const constructReferenceManualsPayload = (formData) => {
  const form_data1 = new FormData();
  const { instructionsDocuments } = formData;
  const instructionsDoc = instructionsDocuments[0];
  instructionsDoc?.instructionDocumentName && form_data1.append("name", instructionsDoc?.instructionDocumentName);
  const files = instructionsDoc?.instructions;
  const instructionTitles = [];
  let fileCount = 0;
  files?.map((file, index) => {
    if (file?.instructionTitle) {
      instructionTitles.push(file?.instructionTitle)
    } else {
      instructionTitles.push("")
    }
    if (file?.instructionFile) {
      fileCount += 1;
      file?.instructionFile && form_data1.append(`file${index}`, file?.instructionFile);
    }
  });
  form_data1.append("noOfFiles", fileCount);
  form_data1.append("isArEnabled", false);
  instructionTitles?.length && form_data1.append("instructions", JSON.stringify(instructionTitles));
  return form_data1;
}

const createReferenceManuals = (url, payload) => doPostApiCall(url, payload, "multipart/form-data")

const documentApi = payload => doPostApiCall(AppUrl.createAssetDocument, payload, "multipart/form-data")

// TO DELETE ASSETS
export const handleDeleteAsset = ({
  payload,
  activePage,
  limit,
  dispatch,
  setShowDeleteDailog,
  setSelectedRows,
  setActivePage,
  setTotalPage,
  Navigate,
  setAllAssets,
}) => {
  deleteAsset(payload).then((res) => {
    dispatch(
      commonActions.handleSnackbar({
        show: true,
        message: `Successfully Deleted`,
        type: "success",
      })
    );
    setShowDeleteDailog(false);
    if (setSelectedRows) setSelectedRows([]);
    getFilteredAssets({
      page: 1,
      limit,
      optionalParams: { assetDepartment: 1, criticalityLevel: 1 },
    }).then((res) => {
      dispatch(assetActions.getAllAssets(res?.data?.result?.assets));
      dispatch(commonActions.showApiLoader(false));
      getAllAssetsDataMethod({ setAllAssets });
      Navigate("/assets");
      // setTotalPage(res?.data?.result?.totalPages);
      // if (res?.data?.result?.assets.length % limit === 0 && activePage !== 1) {
      //   setActivePage((prev) => prev - 1);
      // }
    });
  });
};

// TO EDIT ASSET
export const handleEditAsset = async ({assetId,formData,loggedUser, dispatch,Navigate,page, limit,getUpdatedAssetDetails, getUpdatedStatusOFAssetEdit,}) => {
  const { assetName, assetNumber, assetDescription, assetMode, runningMode, assetDepartment, criticalityLevel, functionalArea, assetOwner, censusNumber, assetType, assetMake, assetModel, serialNumber, manufacturer, installationDate, serviceLiquid, hazardousAreaDetails, location, geoLocation, parentAsset, isWarrantyIncluded, warrantyPeriodNumber, warrantyPeriodDurr, warrantyPeriod, supplierName, supplierEmail, warrantyEndDate, asset3DmodelRotation, asset3DmodelPosition, asset3DModel, assetLayoutImage, assetImagesToDelete, assetImages, assetTermsAndConditions, assetParameters, assetParametersToDelete, referenceManualId, documents, instructions, instructionsToDelete, referenceManualsToCreate, referenceManualToDelete } = formData
  if (installationDate) formData["installationDate"] = new Date(installationDate).toISOString();
  if (warrantyEndDate) formData["warrantyEndDate"] = new Date(warrantyEndDate).toISOString();
  const form_data = new FormData();
  const parameters = validateAssetParameters(assetParameters);
  let assetParametersToEdit = [];
  let assetParametersToCreate = [];
  parameters?.filter((param) => {
    if (param?.isActive) {
      assetParametersToEdit.push(param);
    } else {
      assetParametersToCreate.push(param);
    }
  });
  if (formData?.assetStatus) {
    if (formData?.assetStatus === 'Decommissioned') {
      form_data.append(`assetStatus`, formData?.assetStatus);
      form_data.append(`decommissionedDate`, formData?.decommissionedDate)
    }
  }

  let documentsToCreate = [];
  let documentsToEdit = [];

  for (let key in documents) {
    let document = documents[key];
    if (document.isActive) {
      documentsToEdit.push(documents[key])
    } else {
      documentsToCreate.push(documents[key])
    }
  }

  assetId && form_data.append("assetId", assetId);
  assetName && form_data.append(`assetName`, assetName);
  assetNumber && form_data.append(`assetNumber`, assetNumber);
  assetDescription && form_data.append(`assetDescription`, assetDescription);
  assetMode?.id && form_data.append(`assetMode`, assetMode?.id);
  runningMode?.id && form_data.append(`runningMode`, runningMode?.id);
  assetDepartment?.id && form_data.append(`assetDepartment`, assetDepartment?.id);
  criticalityLevel?.id && form_data.append(`criticalityLevel`, criticalityLevel?.id);
  functionalArea?.id && form_data.append(`functionalArea`, functionalArea?.id);
  assetOwner?.id && form_data.append(`assetOwner`, assetOwner?.id);
  censusNumber && form_data.append(`censusNumber`, censusNumber);
  assetType && form_data.append(`assetType`, assetType);
  assetMake && form_data.append(`assetMake`, assetMake);
  assetModel && form_data.append(`assetModel`, assetModel);
  serialNumber && form_data.append(`serialNumber`, serialNumber);
  manufacturer && form_data.append(`manufacturer`, manufacturer);
  installationDate && form_data.append(`installationDate`, installationDate);
  serviceLiquid && form_data.append(`serviceLiquid`, serviceLiquid);
  hazardousAreaDetails && form_data.append(`hazardousAreaDetails`, JSON.stringify(hazardousAreaDetails));
  location?.id && form_data.append(`location`, location?.id);
  geoLocation && form_data.append(`geoLocation`, JSON.stringify(geoLocation));
  parentAsset && form_data.append(`parentAsset`, parentAsset?.id);
  isWarrantyIncluded && form_data.append(`isWarrantyIncluded`, isWarrantyIncluded);
  warrantyPeriodNumber && form_data.append(`warrantyPeriodNumber`, warrantyPeriodNumber);
  warrantyPeriodDurr?.id && form_data.append(`warrantyPeriodDurr`, warrantyPeriodDurr?.id);
  warrantyPeriod && form_data.append(`warrantyPeriod`, warrantyPeriod);
  supplierName && form_data.append(`supplierName`, supplierName);
  supplierEmail && form_data.append(`supplierEmail`, supplierEmail);
  warrantyEndDate && form_data.append(`warrantyEndDate`, warrantyEndDate);
  asset3DmodelRotation && form_data.append(`asset3DmodelRotation`, JSON.stringify(asset3DmodelRotation));
  asset3DmodelPosition && form_data.append(`asset3DmodelPosition`, JSON.stringify(asset3DmodelPosition));
  asset3DModel?.length && form_data.append(`asset3DModel`, asset3DModel[0]);
  assetLayoutImage?.length && form_data.append(`assetLayoutImage`, assetLayoutImage[0]);
  assetImagesToDelete?.length && form_data.append(`assetImagesToDelete`, JSON.stringify(assetImagesToDelete));
  assetImages?.length >= 0 && assetImages.forEach((file, index) => { form_data.append(`assetImage${index}`, file); });
  assetTermsAndConditions?.length > 0 && assetTermsAndConditions.forEach((file, index) => { form_data.append(`assetTermsAndConditions${index}`, file); });
  assetParametersToDelete?.length > 0 && form_data.append("assetParametersToDelete", JSON.stringify(assetParametersToDelete))
  assetParametersToCreate?.length > 0 && form_data.append("createAssetParameters", JSON.stringify(assetParametersToCreate));
  assetParametersToEdit?.length > 0 && form_data.append("assetParameters", JSON.stringify(assetParametersToEdit));

  dispatch(assetActions.setAssetEditLoading(true));

  let assetCreated = false;
  let referenceCreated = false;
  let documentsCreated = false;
  try {
    const assetCreationRes = await editAsset(form_data);
    if (assetCreationRes?.data?.status !== 201 && assetCreationRes?.data?.status !== 200) {
      throw new Error("Something went wrong during asset updation");
    }
    assetCreated = true;

    let referenceEditStatus = {};
    let referenceCreateStatus = {};
    let referenceDeleteStatus = {};

    if (referenceManualsToCreate || referenceManualToDelete) {
      if (referenceManualsToCreate) {
        const customPayload = { instructionsDocuments: [{ instructionDocumentName: referenceManualsToCreate?.name, instructions: referenceManualsToCreate?.instructions?.map((ins) => ({ ...ins, instructionTitle: ins?.instruction })) }] }
        const payload = constructReferenceManualsPayload(customPayload);
        const url = "assets/" + assetId + "/referenceManuals";
        referenceCreateStatus = await createReferenceManuals(url, payload);
      }
      if (referenceManualToDelete) {
        const payload = { referenceManualIds: [referenceManualToDelete] };
        const url = `assets/${assetId}/referenceManuals/delete`;
        referenceDeleteStatus = await doPutApiCall(url, payload);
      }
    } else if (referenceManualId) {
      const payload = handleEditReferenceManuals({ assetId, formData })
      referenceEditStatus = await editReferenceManualForAsset({ assetId, referenceManualId, payload })
    }


    if (
      (Object.keys(referenceCreateStatus).length > 0 && referenceCreateStatus?.data?.status !== 201 && referenceCreateStatus?.data?.status !== 200) ||
      (Object.keys(referenceEditStatus).length > 0 && referenceEditStatus?.data?.status !== 201 && referenceEditStatus?.data?.status !== 200) ||
      (Object.keys(referenceDeleteStatus).length > 0 && referenceDeleteStatus?.data?.status !== 201 && referenceDeleteStatus?.data?.status !== 200)
    ) {
      throw new Error("Something went wrong during reference manuals update");
    }
    referenceCreated = true;

    let successDocs = 0;
    let arrayOfDocsPayload = [];
    if (documentsToEdit?.length) {
      arrayOfDocsPayload = handleEditAssetDocuments({ documents: documentsToEdit, assetId });
      await (async () => {
        for (let i = 0; i < arrayOfDocsPayload?.length; i++) {
          try {
            let res = await editAssociateDocs(arrayOfDocsPayload[i]);;
            if (res?.data?.status === 200 || res?.data?.status === 201) {
              successDocs++;
            } else {
              throw new Error();
            }
          } catch (err) {
            handleLoginExpiry(err, dispatch)
          }
        }
      })()
    }
    if (successDocs !== arrayOfDocsPayload?.length)
      throw new Error("Something went wrong during asset document creation");

    let successDocs1 = 0;
    let arrayOfDocsPayload1 = [];
    if (documentsToCreate?.length) {
      arrayOfDocsPayload1 = createAssetDocuments({ assetId, assetDetails: { documents: documentsToCreate } });
      await (async () => {
        for (let i = 0; i < arrayOfDocsPayload1?.length; i++) {
          try {
            let res = await documentApi(arrayOfDocsPayload1[i]);
            if (res?.data?.status === 200 || res?.data?.status === 201) {
              successDocs1++;
            } else {
              throw new Error();
            }
          } catch (err) {
            handleLoginExpiry(err, dispatch)
          }
        }
      })()
    }

    if (successDocs1 !== arrayOfDocsPayload1?.length) throw new Error("Something went wrong while updating Assets Documents.");
    documentsCreated = true;

    dispatch(assetActions.setAssetEditLoading(false));

    getUpdatedStatusOFAssetEdit(true);
    getUpdatedAssetDetails({
      assetId,
      operationType: "edit",
      message: `Asset updated successfully.`,
      isSuccess: true
    });
  } catch (e) {
    const error = e?.response?.data;
    dispatch(assetActions.setAssetEditLoading(false));
    // getUpdatedStatusOFAssetCreation(true);
    let message = '';
    if (!assetCreated && !referenceCreated && !documentsCreated)
      message = `Something went wrong while updating Assets.`
    else if (assetCreated && !referenceCreated && !documentsCreated)
      message = `Something went wrong while updating Assets Reference.`
    else if (assetCreated && referenceCreated && !documentsCreated)
      message = `Something went wrong while updating Assets Documents.`

    if (handleGetENVVariables().REACT_APP_BUILDTYPE === "TESTING") {
      const test_message = error?.message ? error?.message : " Encountered server error!"
      message += test_message
    }

    getUpdatedStatusOFAssetEdit(true);
    getUpdatedAssetDetails({
      assetId,
      operationType: "edit",
      message,
      isSuccess: false
    });
  }
};

//  TO EDIT ASSET DOCUMENTS
export const handleEditAssetDocuments = ({ documents, assetId }) => {
  return documents?.map((doc) => {
    const form_data = new FormData();
    const { file, id, replaceDocument, documentName, documentNumber, revisionNumber, documentType, status } = doc;
    file && form_data.append("file0", file)
    assetId && form_data.append("assetId", assetId)
    id && form_data.append("docId", id);
    documentName && form_data.append("documentName", documentName)
    documentNumber && form_data.append("documentNumber", documentNumber)
    documentType?.id && form_data.append("documentType", documentType?.id)
    status?.id && form_data.append("status", status?.id)
    replaceDocument && form_data.append("replaceDocument", replaceDocument)
    revisionNumber && form_data.append("revisionNumber", revisionNumber);
    file && form_data.append("noOfFiles", 1)
    return form_data;
  })
}

// TO EDIT REFERENCE MANUALS
export const handleEditReferenceManuals = ({ assetId, formData }) => {
  if (formData?.referenceManualToDelete || formData?.referenceManualsToCreate) {
    if (formData?.referenceManualToDelete) {

    }
    if (formData?.referenceManualsToCreate) {

    }
  } else {
    const form_data = new FormData();
    const { name, instructions, instructionsToDelete, referenceManualId, documents, referenceManualToDelete, referenceManualsToCreate } = formData
    if (name) form_data.append("name", name);
    if (instructionsToDelete?.length) form_data.append("instructionsToDelete", JSON.stringify(instructionsToDelete))
    let instructionsToCreate = [];
    let instructionsToEdit = [];
    let filesToCreate = [];
    let filesToUpdate = [];
    for (let key in instructions) {
      if (key.slice(0, 3) === "rfi") {
        if (instructions[key]?.isFileToBeDeleted) {
          instructionsToEdit.push({ id: key, isFileToBeDeleted: true })
        }
        if (instructions[key]?.isTitleChanged) {
          let isInsPresent = false;
          instructionsToEdit = instructionsToEdit?.map((ins) => {
            if (ins?.id === key) {
              isInsPresent = true;
              return { ...ins, instruction: instructions[key].instruction }
            } else {
              return ins
            }
          })
          if (!isInsPresent) {
            instructionsToEdit.push({ id: key, instruction: instructions[key].instruction });
          }
        }
        if (instructions[key].isFileChanged) {
          let isInsPresent = false;
          instructionsToEdit = instructionsToEdit?.map((ins) => {
            if (ins?.id === key) {
              isInsPresent = true;
              return { ...ins, instruction: instructions[key].instruction }
            } else {
              return ins
            }
          })
          if (!isInsPresent) {
            instructionsToEdit.push({ id: key });
          }
          filesToUpdate.push({ id: key, file: instructions[key]?.instructionFile })
        }
      } else {
        instructionsToCreate.push({ id: key, instruction: instructions[key].instruction, index: instructionsToCreate?.length });
        filesToCreate.push(instructions[key]?.instructionFile)
      }
    }
    if (referenceManualToDelete) form_data.append("referenceManualToDelete", referenceManualToDelete);
    if (referenceManualsToCreate) form_data.append("referenceManualsToCreate", JSON.stringify(referenceManualsToCreate))
    instructionsToCreate?.length > 0 && form_data.append("instructionsToCreate", JSON.stringify(instructionsToCreate))
    instructionsToEdit?.length > 0 && form_data.append("instructionsToEdit", JSON.stringify(instructionsToEdit))
    filesToCreate?.map((file, index) => { form_data.append(`file${index}`, file) })
    filesToUpdate?.map((file, index) => { form_data.append(`updateFile_${file?.id}`, file?.file) })
    form_data.append("isArEnabled", false);
    return form_data;
  }
};


// TO CREATE MULTIPLE SPARES OF ASSET
export const handleCreateMultipleSpares = async ({formData,setIsLoading}) => {
  try{
    const {spares} = formData;
    const payload = {};
    const response = await doPostApiCall(AppUrl.createMultipleSpares,payload);
    const data = response?.data;
    return data
  } catch (err) {
    throw err
  } 
}



// TO DOWNLOAD EXCEL DATA
export const downloadExcel = (filters) => {
  const optionalParams = {
    assetDepartment: 1,
    criticalityLevel: 1,
    functionalArea: 1,
    location: 1,
  };
  getexportableData(filters, optionalParams).then((res) => {
    let filteredArray = res?.data?.result?.map((asset) => {
      return {
        assetName: asset?.assetName,
        assetNumber: asset?.assetNumber,
        tagId: asset?.tagId,
        description: asset?.description,
        department: asset?.assetDepartment,
        criticalityLevel: asset?.criticalityLevel,
        functionalArea: asset?.functionalArea,
        assetMake: asset?.assetMake,
        assetModel: asset?.assetModel,
        serialNumber: asset?.serialNumber,
        manufacturer: asset?.manufacturer,
        installationDate: getFormatedDate(asset?.installationDate),
        supplierName: asset?.supplierName,
        supplierEmail: asset?.supplierEmail,
        location: asset?.location,
        assetLevel: asset?.assetLevel,
        decommissionedDate: getFormatedDate(asset?.decommissionedDate),
      };
    });
    const worksheet = xlsx.utils.json_to_sheet(filteredArray);
    const workbook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    xlsx.writeFile(workbook, "AssetsData.xlsx");
  });
};

// TO DOWNLOAD 3D EXCEL DATA

export const download3DExcel = (filters) => {
  getexportableData(filters).then((res) => {
    let filteredArray = res?.data?.result?.assets?.map((asset) => {
      return {
        uuid: asset?.assetId,
        assetName: asset?.assetName,
        assetNumber: asset?.assetNumber,
        tagId: asset?.tagId,
        description: asset?.description,
        department: asset?.assetDepartment,
        criticalityLevel: asset?.criticalityLevel,
        functionalArea: asset?.functionalArea,
        assetMake: asset?.assetMake,
        assetModel: asset?.assetModel,
        serialNumber: asset?.serialNumber,
        manufacturer: asset?.manufacturer,
        installationDate: getFormatedDate(asset?.installationDate),
        supplierName: asset?.supplierName,
        supplierEmail: asset?.supplierEmail,
        location: asset?.location,
        assetLevel: asset?.assetLevel,
        decommissionedDate: getFormatedDate(asset?.decommissionedDate),
      };
    });
    const worksheet = xlsx.utils.json_to_sheet(filteredArray);
    const workbook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    xlsx.writeFile(workbook, "AssetsData-3d-system.xlsx");
  });
};

// TO DOWNLOAD CSV DATA

export const downloadCSV = (filters) => {
  getexportableData(filters).then((res) => {
    let filteredArray = res?.data?.result?.assets?.map((asset) => {
      return {
        assetName: asset?.assetName,
        assetNumber: asset?.assetNumber,
        tagId: asset?.tagId,
        description: asset?.description,
        department: asset?.assetDepartment,
        criticalityLevel: asset?.criticalityLevel,
        functionalArea: asset?.functionalArea,
        assetMake: asset?.assetMake,
        assetModel: asset?.assetModel,
        serialNumber: asset?.serialNumber,
        manufacturer: asset?.manufacturer,
        installationDate: getFormatedDate(asset?.installationDate),
        supplierName: asset?.supplierName,
        supplierEmail: asset?.supplierEmail,
        location: asset?.location,
        assetLevel: asset?.assetLevel,
        decommissionedDate: getFormatedDate(asset?.decommissionedDate),
      };
    });

    //
    const csv = Papa.unparse(filteredArray);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "assetsData.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });
};

// To validate files and images while uploading

export const validatedFiles = (
  dispatch,
  selectedFiles,
  presentFiles,
  allowedExtensions
) => {
  let files = [];
  let allFiles = presentFiles?.length
    ? [...presentFiles, ...selectedFiles]
    : [...selectedFiles];
  if (allFiles.length > 10) {
    dispatch(
      commonActions.handleSnackbar({
        show: true,
        message: "You can not upload more than 10 files.",
        type: "error",
      })
    );
  }
  files = allFiles?.filter((file, index) => index < 10);
  let presentFileNames = presentFiles?.map((img) => {
    return img?.name;
  });
  if (presentFileNames?.length) {
    files = allFiles?.filter((file) => {
      return !presentFileNames.includes(file?.name);
    });
  }
  // Filter the files to only include those with allowed extensions
  let wrongExtensionFiles = files?.filter((file) => {
    const extension = file?.name?.split(".").pop()?.toLowerCase();
    return !allowedExtensions.includes("." + extension);
  });

  let wrongFileNames = "";
  wrongExtensionFiles?.forEach((file) => {
    wrongFileNames += file?.name + ",";
  });
  if (wrongExtensionFiles?.length) {
    dispatch(
      commonActions.handleSnackbar({
        show: true,
        message:
          wrongExtensionFiles?.length > 1
            ? `The following files are not supported : ${wrongFileNames} `
            : `The following file is not supported : ${wrongFileNames} `,
        type: "error",
        closeIn: 10000,
      })
    );
  }
  // Filter the files to only include those with size <= 10MB

  let overSizeFiles = files?.filter((file) => {
    return file?.size > 10 * 1024 * 1024; // 10MB in bytes
  });
  let overSizeFileNames = "";
  overSizeFiles?.forEach((file) => {
    overSizeFileNames += file?.name + ",";
  });
  if (overSizeFiles?.length) {
    dispatch(
      commonActions.handleSnackbar({
        show: true,
        message: `The following files are exceeds the size limit of 10MB. ${overSizeFileNames} `,
        type: "error",
        closeIn: 10000,
      })
    );
  }
  files = files?.filter((file) => {
    const extension = file?.name?.split(".").pop()?.toLowerCase();
    return allowedExtensions.includes("." + extension);
  });

  files = files?.filter((file) => {
    return file?.size <= 10 * 1024 * 1024; // 10MB in bytes
  });
  return files;
};

// TO GET ASSET MODE DROPDOWN VALUES

export const getAssetModeDropdownData = async (setAssetMode, dispatch) => {
  try {
    const response = await getAssetModeDropdown();
    setAssetMode(response?.data?.result);
    // dispatch(userActions.getAllUsers(response?.data?.result))
  } catch (error) {
    handleLoginExpiry(error, dispatch);
  }
};

// TO GET RUNNING MODE DROPDOWN VALUES

export const getRunningModeDropdownData = async (setRunningMode, dispatch) => {
  try {
    const response = await getRunningModeDropdown();
    setRunningMode(response?.data?.result);
    // dispatch(userActions.getAllUsers(response?.data?.result))
  } catch (error) {
    handleLoginExpiry(error, dispatch);
  }
};

export const handleGetValueFromSelect = ({
  field,
  type,
  formData,
  setFormData,
  getData,
  getChangedValues,
  changedData,
  setErrors,
}) => {
  if (field === "deselected") {
    delete formData[type];
    if (type === "warrantyPeriodDurr") {
      delete formData?.warrantyPeriod;
      delete formData?.warrantyEndDate;
      validateForm({
        name: "warrantyPeriod",
        formData,
        setErrors,
        label: "Warranty Period",
      });
    }
    validateForm({ name: "", formData, setErrors, label: "" });
    setFormData({ ...formData });
    getData({ ...formData });
    if (changedData && getChangedValues) {
      delete changedData[type];
      if (type === "warrantyPeriodDurr") {
        delete changedData?.warrantyPeriod;
        delete changedData?.warrantyEndDate;
      }
      getChangedValues({ ...changedData });
    }
  } else {
    let temp = {};
    setFormData((prev) => {
      if (type === "warrantyPeriodDurr") {
        temp = {
          ...prev,
          [type]: { id: field?.value, name: field?.label },
          warrantyPeriod: formData?.warrantyPeriodNumber
            ? `${formData?.warrantyPeriodNumber} ${field?.value}`
            : `0 ${field?.value}`,
        };
        validateForm({
          name: "warrantyPeriod",
          formData: temp,
          setErrors,
          label: "Warranty Period",
        });
      } else {
        temp = {
          ...prev,
          [type]: { id: field?.value, name: field?.label },
        };
      }
      // validateForm({formData:temp,setErrors})
      getData(temp);
      if (changedData && getChangedValues) {
        let changeIn = {
          ...changedData,
          [type]: { id: field?.value, name: field?.label },
        };
        getChangedValues(changeIn);
      }
      return temp;
    });
  }
};


// NEW METHODS

export const handleCheckUniqueField = async ({fieldName,fieldValue}) => {
  try {
    const response = await doPostApiCall({[fieldName]:fieldValue});
    // return true/false
  } catch (error) {
    console.error(error?.response?.data?.message)
  }
}

export const handleCreateAssetGeneralDetails = async ({payload,setIsLoading}) => {
  try {
    const requestPayload = {};
    const {generalDetails} = payload;
    const {name,number,description,runningMode,department,category,criticalityLevel,functionalArea,assetOwner,censusNumber} = generalDetails;
    if(name) requestPayload.name = name;
    if(number) requestPayload.number = number;
    if(description) requestPayload.description = description;
    if(runningMode) requestPayload.runningMode = runningMode;
    if(department) requestPayload.department = department;
    if(category) requestPayload.category = category;
    if(criticalityLevel) requestPayload.criticalityLevel = criticalityLevel;
    if(functionalArea) requestPayload.functionalArea = functionalArea;
    if(assetOwner) requestPayload.assetOwner = assetOwner;
    if(censusNumber) requestPayload.censusNumber = censusNumber;
    setIsLoading();
    const response = await doPostApiCall({url:AppUrl.createAsset,payload:requestPayload});
    if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
      return response?.data?.result
    }
  } catch (error) {
    console.log(error)
  } finally {
    setIsLoading()
  }
  
}