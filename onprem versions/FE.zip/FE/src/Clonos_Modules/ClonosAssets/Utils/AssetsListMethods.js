import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant"
import AppUrl from "../../../utils/AppUrl"
import { doGetApiCall } from "../../../utils/ClonosApi"

// TO GET THE COUTS OF ASSETS ACCORDING TO THEIR STATUS
export const handleGetAssetsCounts = ({setterMethod,setIsLoading}) => {
    setIsLoading()
    doGetApiCall({url:AppUrl.getAssetCounts}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        } else {
            throw new Error("Failed to fetch assets counts!")
        }   
    }).catch((err) => {
        console.error(err)   
    }).finally(() => {
        setIsLoading()
    }) 
}


// TO FETCH ASSETS 
export const handleGetAssets = ({setterMethod,setIsLoading,pagination}) => {
   
    setIsLoading && setIsLoading()
    doGetApiCall({url:AppUrl.getAssets,params:pagination}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        } else {
            throw new Error("Failed to fetch assets!")
        }   
    }).catch((err) => {
        console.error(err)   
    }).finally(() => {
        setIsLoading && setIsLoading()
    }) 
}


// TO GET THE INCOMPLETE MODULES OF ASSET.
export const handleGetIncompleteModuleDetailsOfAsset = ({setterMethod,setIsLoading}) => {
    setIsLoading()
    doGetApiCall({url:AppUrl.getAssets}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        } else {
            throw new Error("Failed to fetch icomplete modules of asset!")
        }   
    }).catch((err) => {
        console.error(err)   
    }).finally(() => {
        setIsLoading()
    }) 
}


export const handleGetIncompleteAssetRegistrationDetails = ({assetId,setterMethod,setIsLoading}) => {
    setIsLoading(true);
    const url = `/assets/${assetId}/incompleteRegisterationDetails`
    doGetApiCall({url}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result);
        }
    }).catch((err) => console.error(err))
    .finally(() => {
        setIsLoading(false)
    })
}