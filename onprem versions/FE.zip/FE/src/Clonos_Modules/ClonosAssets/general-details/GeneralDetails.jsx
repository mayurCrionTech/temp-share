import { useDispatch } from "react-redux";
import Styles from "./general-details.module.css"
import { useEffect, useState, memo, useRef } from "react";
import { specialCharacters } from "../AssetConstants";
import useToggler from "../../../CustomHooks/TogglerHook";
import SEARCHICON from "../../../assets/UIUX/icons/search (1).svg";
import DOWNANGLE from "../../../assets/UIUX/icons/chevron-down.svg";
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";
import { StepController } from "../Components/StepController/StepController";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosTextarea from "../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import { handleGetStaticDropdownValues } from "../../../utils/DropdownsMethods/DropdownsMethods";
import DynamicDropdown from "../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import { getBusinessUnitDropdownData, getDepartmentDropdownData, getUsersDropdownData, getUsersList } from "../../../utils/UsersMethods/usersMethods";
import { handleGetAssetCategories, handleGetFilledValuesOfGeneralDetails, handleSaveGeneralDetail, handleUpdateGeneralDetails } from "./general-details-managers";
import { handleGetAssetEnums, handleGetNewAssetDropDown, handleGetSingleAssetDetails, handleIsAssetEdited } from "../managers/asset-common-managers";
import { handleGetWorkOrderPriorities } from "../../work-orders/work-order-manager";
import ClonosSearchableDropdown from "../../../components/CommonComponents/ClonosSearchableDropdown/ClonosSearchableDropdown";
import { useSelector } from "react-redux";
import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
import { Chip, Paper } from "@mui/material";
import AutoFixHighIcon from "@mui/icons-material/AutoFixHigh";
import { Dialog, DialogActions, DialogTitle, Button } from "@mui/material";
import { doGetApiCall } from "../../../utils/ClonosApi";
import { Margin } from "@mui/icons-material";

/*
date            qid / cr#         comments
20-mar-2026     CR0001            Apply filter on drop down

*/
const GeneralDetails = ({ setGlobalStateOfChildData, globalStateOfChildData, steps, activeStep, setActiveStep, mode, serverResponse, setServerResponse }) => {
  const dispatch = useDispatch();
  const selectedAutoFillAsset = useSelector(
  (store) => store.assetData.selectedAutoFillAsset
);
 const generalDetailsAutoFillChanged = useSelector(
    (store) => store.assetData.generalDetailsAutoFillChanged
  );

  const [dropdownsData, setDropdownsData] = useState({
    users: {
      data: []
    },
    departments: [],
    runningMode: [],
    businessUnits: [],
    functionalArea: [],
    criticalityLevel: [],
    assetCategory:[],
    searchedUsers : {
      data : []
    }
  })


  const [formData, setFormData] = useState({});
  const [changedData, setChangedData] = useState({});
  const [isLoading, setIsLoading] = useToggler();
  const [assetOwners,setAssetOwners] = useState({});
  const [serverImages,setServerImages] = useState({
    images:[],
    loading:false
  });
 
  const [searchedAssetOwners,setSearchedAssetOwners] = useState({});
  const [pagination, setPagination] = useState({ page: 1, limit: 15 })
  const [assetCategoryDropdownDown, setAssetCategoryDropdown] = useState([]);
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })
    const [assetData, setAssetData] = useState([]);
    const [assetNumData, setAssetNumData] = useState([]);
    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(false);
    const [hasMore, setHasMore] = useState(false);
    const currentQuery = useRef("");
    const [showAutoFillName, setShowAutoFillName] = useState(null);
    const [showAutoFillNumber, setShowAutoFillNumber] = useState(null);
    const [hasEdited,setHasEdited]=useState(false)
    const [loadingDropdowns, setLoadingDropdowns] = useState({});
    const [staticDropdownData,setStaticDropdownData]=useState({})


  const handleGetValues = (props) => {
    handleGetFilledValuesOfGeneralDetails({ propsVal: props, handlePrimaryObjectModifier, setFormData, globalStateOfChildData, primaryObject, mode, setChangedData, section: "generalDetails" })
  };

  const fetchMoreUsersOnScroll = () => {
    if (assetOwners?.totalPageCount > pagination?.page) {
      setPagination((prev) => {
        let temp = { ...prev, page: prev?.page + 1 }
        getUsersDropdownData({setterMethod:setAssetOwners,filterPayload:{pagination: temp,selectFields: "name,employeeId", populateFields: "department"}})
        return temp
      })
    }
  }


const fetchAssetNumbers = async (query, pageNum = 1) => {
  if (!query) return;

  setLoading(true);

  try {
    const res = await doGetApiCall({
      url: `assets/assetMaster?assetNumber=${query}&page=${pageNum}`,
    });

    const apiData = res?.data?.result;
   
    if (apiData && Array.isArray(apiData.data)) {
         const results = apiData.data.map((item) => {
         const details = item.templateData?.generalDetails || {};
         const specifications = item.templateData?.specifications || {};

        return {
          id: item._id,
          familyKey: item.familyKey,

          // GENERAL DETAILS
          generalDetails: {
            name: details.name || "",
            number: details.number || "",
            description: details.description || "",
            runningMode: details.runningMode || "",
            businessUnit: details.businessUnit || "",
            category: details.category || "",
            criticalityLevel: details.criticalityLevel || "",
            department: details.department || "",
            functionalArea: details.functionalArea || "",
            owner: details.owner || "",
          },

          // FULL NESTED SPECIFICATIONS (NO LOSS)
          specifications: {
            ...specifications
          }
        };
      });

      setAssetNumData((prev) =>
        pageNum === 1 ? results : [...prev, ...results]
      );

      setHasMore(apiData.page < apiData.totalPages);
    } else {
      setAssetNumData([]);
      setHasMore(false);
    }
  } catch (error) {
    console.error("Error fetching parameters:", error);
    setAssetNumData([]);
    setHasMore(false);
  } finally {
    setLoading(false);
  }
};

const fetchAssets = async (query, pageNum = 1) => {
  if (!query) return;

  setLoading(true);

  try {
    const res = await doGetApiCall({
      url: `assets/assetMaster?assetKey=${query}&page=${pageNum}`,
    });

    const apiData = res?.data?.result;
 
    if (apiData && Array.isArray(apiData.data)) {
        const results = apiData.data.map((item) => {
        const details = item.templateData?.generalDetails || {};
        const specifications = item.templateData?.specifications || {};

        return {
          id: item._id,
          familyKey: item.familyKey,

          // GENERAL DETAILS
          generalDetails: {
            name: details.name || "",
            number: details.number || "",
            description: details.description || "",
            runningMode: details.runningMode || "",
            businessUnit: details.businessUnit || "",
            category: details.category || "",
            criticalityLevel: details.criticalityLevel || "",
            department: details.department || "",
            functionalArea: details.functionalArea || "",
            owner: details.owner || "",
          },

          // FULL NESTED SPECIFICATIONS (NO LOSS)
          specifications: {
            ...specifications
          }
        };
      });

      setAssetData((prev) =>
        pageNum === 1 ? results : [...prev, ...results]
      );

      setHasMore(apiData.page < apiData.totalPages);
    } else {
      setAssetData([]);
      setHasMore(false);
    }
  } catch (error) {
    console.error("Error fetching parameters:", error);
    setAssetData([]);
    setHasMore(false);
  } finally {
    setLoading(false);
  }
};

// For Asset Name Dropdown helper function
  const handleSearch = (query) => {
    if (!query) {
      // ✅ Clear old results when user clears input
      setAssetData([]);
      setHasMore(false);
      return;
    }

    // normal API call
    currentQuery.current = query;
    setPage(1);
    fetchAssets(query, 1);
    
    const existingAsset = assetData.find((asset) => asset?.id === formData.name?.id);
 
    if (existingAsset) {
      setShowAutoFillName(existingAsset);
      
    } else {
      setShowAutoFillName(null);
    }
  };


  const handleLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchAssets(currentQuery.current, nextPage);
  };

  // For Asset Number Dropdown helper function

    const handleAssetNumberSearch =(query)=>{
      if (!query) {
        // ✅ Clear old results when user clears input
        setAssetNumData([]);
        setHasMore(false);
        return;
      }

      // normal API call
      currentQuery.current = query;
      setPage(1);
      fetchAssetNumbers(query,1)
    const existingAsset = assetNumData.find((asset) => asset?.id === formData.number?.id);
  
      if (existingAsset) {
        setShowAutoFillNumber(existingAsset);
      } else {
        setShowAutoFillNumber(null);
      }
    }

    const handleAssetNumberLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchAssetNumbers(currentQuery.current, nextPage);
  };

  const handleSearchAssetOwner = (props) => {
    const {uniqueKey,input} = props;
    if(input?.length) {
      getUsersDropdownData({setterMethod:setSearchedAssetOwners,filterPayload:{name:input,selectFields: "name,employeeId", populateFields: "department"}})
    } else {
      setSearchedAssetOwners({});
    }
  }


  const handleSaveAndNext = () => {
    const isAssetEdited = globalStateOfChildData?.generalDetails ? handleIsAssetEdited({ serverResponse: globalStateOfChildData?.generalDetails, changedData: formData, assetModule: "generalDetails" }) : true
    if (!isAssetEdited) {
      setActiveStep(prev => prev + 1);
      return
    } else {
      if (mode === "edit") {
        handleUpdateGeneralDetails({ id: globalStateOfChildData?.id, checkRequiredField: handleSubmit,globalStateOfChildData, setGlobalStateOfChildData, setActiveStep, changedData: formData, serverResponse, setIsLoading })
      } else {
        if (!globalStateOfChildData?.id) {
          handleSaveGeneralDetail({ dispatch, checkRequiredField: handleSubmit, formData, globalStateOfChildData, setGlobalStateOfChildData, setActiveStep, setIsLoading })
        } else {
          handleUpdateGeneralDetails({ id: globalStateOfChildData?.id, checkRequiredField: handleSubmit,globalStateOfChildData, setGlobalStateOfChildData, setActiveStep, changedData: formData, serverResponse, setIsLoading })
        }
      }
    }
  }

 const fetchStaticDropdownByCode = async (code) => {
  if (staticDropdownData[code] || loadingDropdowns[code]) return;

  setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

  try {
    const res = await doGetApiCall({url:`dropdowns/${code}`});
       
    setStaticDropdownData(prev => ({
      ...prev,
      [code]: res?.data?.result?.options
    }));
  } finally {
    setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
  }
};


  useEffect(() => {
    getBusinessUnitDropdownData({ setterMethod: (val) => setDropdownsData(prev => ({ ...prev, businessUnits: val })), dispatch });
    //handleGetAssetCategories({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, assetCategory: val }))})
    getUsersDropdownData({ pagination, setterMethod: setAssetOwners, selectFields: "name,employeeId", populateFields: "department" })
    // handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, runningMode: val })), moduleName: "generalDetails", enumTypeEndPoint: "runningMode" });
    //handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, criticalityLevel: val })), moduleName: "generalDetails", enumTypeEndPoint: "criticalityLevel" });
    //handleGetAssetEnums({ setterMethod: (val) => setDropdownsData((prev) => ({ ...prev, functionalArea: val })), moduleName: "generalDetails", enumTypeEndPoint: "functionalArea" });
    if(globalStateOfChildData?.id){
      handleGetSingleAssetDetails({assetId:globalStateOfChildData?.id,setterMethod:(val) => setGlobalStateOfChildData(prev => ({...prev,images:val?.images})),setIsLoading:() => {}})
    }
    handleGetWorkOrderPriorities({setterMethod:setAssetCategoryDropdown})

  }, []);

  useEffect(() => {
    formData?.businessUnit?.id && getDepartmentDropdownData({ setterMethod: (val) => setDropdownsData(prev => ({ ...prev, departments: val })), dispatch, selectedBusinessUnit: formData?.businessUnit?.id });
  }, [formData?.businessUnit?.id])


  useEffect(()=>{
      if(selectedAutoFillAsset){
          setFormData(selectedAutoFillAsset?.generalDetails)
      }
  },[selectedAutoFillAsset])
  

    useEffect(() => {
      const handleKeyDown = (e) => {
        if (e.key === "Tab") {

          // Autofill for Asset Name
          if (showAutoFillName) {
            dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillName));
            //  setAssetNameEdited(false)
            setHasEdited(false)
            setShowAutoFillName(null);
             dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
            return; // stop here so it doesn't check number too
          }

          // Autofill for Asset Number
          if (showAutoFillNumber) {
            dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillNumber));
            //  setAssetNumberEdited(false)
              setHasEdited(false)
            setShowAutoFillNumber(null);
            dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
            return;
          }
        }
      };

      window.addEventListener("keydown", handleKeyDown);

      return () => {
        window.removeEventListener("keydown", handleKeyDown);
      };
    }, [showAutoFillName, showAutoFillNumber]);

 
  return (
    <>
      <div className={Styles.generalDetailsContainer}>
        <div>
          <div className={Styles.generalDetails_left}>


            {/* <ClonosInput
              type="text"
              limit={50}
              tabIndex={1}
              isLabel={true}
              uniqueKey="name"
              isMandatory={true}
              label={"Asset Name"}
              placeholder="Asset Name"
              handleGetValues={handleGetValues}
              defaultValue={globalStateOfChildData?.generalDetails?.name}
              errorMessage={"Asset Name is Required!."}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            /> */}
               <ClonosSearchableDropdown
                  label="Asset Name"
                  data={assetData.map(a => ({
                    id: a.id,
                    name: a.generalDetails?.name
                  }))}
                   tabIndex={1}
                  onSearch={handleSearch}
                  onLoadMore={handleLoadMore}
                  hasMore={hasMore}
                  loading={loading}
                  isMandatory={true}
                  debounceDelay={500}
                  uniqueKey={"name"}
                  placeholder="Asset name"
                  defaultValue={selectedAutoFillAsset?.generalDetails?.name ?? formData?.name ?? globalStateOfChildData?.generalDetails?.name }
                  errorMessage="Asset Name is required!"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  allowCustomInput={true} 
                  hasEdited={hasEdited}
                  setHasEdited={setHasEdited}
                />
            {showAutoFillName && (
              <Paper
                elevation={1}
                sx={{
                  display: "inline-flex",
                  alignItems: "start",
                  padding: "6px 10px",
                  borderRadius: 4,
                  cursor: "pointer",
                  backgroundColor: "#f1f3f4",
                  width: "fit-content",
                  margin:"-15px 0px 0px -5px",
                  "&:hover": {
                    backgroundColor: "#e0e0e0",
                  },
                }}
                onClick={() =>{
                dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillName));
                setHasEdited(false)
                setShowAutoFillName(null)
                dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
                }
                }
              >
                <AutoFixHighIcon sx={{ fontSize: 18, mr: 1 }} />
                    Auto-fill with "{showAutoFillName.generalDetails.name}"
              </Paper>
            )}




            {/* <ClonosInput
              limit={15}
              type="text"
              tabIndex={2}
              isLabel={true}
              isMandatory={true}
              uniqueKey="number"
              label={"Asset Number"}
              placeholder="Asset Number"
              disabled={mode === "edit"}
              handleGetValues={handleGetValues}
              // defaultValue={globalStateOfChildData?.generalDetails?.number}
             defaultValue={
  formData?.number 
  ?? globalStateOfChildData?.generalDetails?.number 
  ?? ""
}

              errorMessage={"Asset Number is Required!."}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            /> */}



            <ClonosSearchableDropdown
                  label="Asset Number"
                  data={assetNumData.map(a => ({
                    id: a.id,
                    number: a.generalDetails?.number
                  }))}
                  onSearch={handleAssetNumberSearch}
                  onLoadMore={handleAssetNumberLoadMore}
                  hasMore={hasMore}
                  loading={loading}
                  isMandatory={true}
                  debounceDelay={500}
                  uniqueKey={"number"}
                  placeholder="Asset Number"
                  defaultValue={ formData?.number ?? globalStateOfChildData?.generalDetails?.number} 
                  errorMessage="Asset Number is required!"
                  handleGetValues={handleGetValues}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  allowCustomInput={true} 
                   tabIndex={2}
                   hasEdited={hasEdited}
                  setHasEdited={setHasEdited}
                />
            {showAutoFillNumber && (
              <Paper
                elevation={1}
                sx={{
                  display: "inline-flex",
                  alignItems: "start",
                  padding: "6px 10px",
                  borderRadius: 4,
                  cursor: "pointer",
                  backgroundColor: "#f1f3f4",
                  width: "fit-content",
                  margin:"-15px 0px 0px -5px",
                  "&:hover": {
                    backgroundColor: "#e0e0e0",
                  },
                }}
                onClick={() =>{
                dispatch(assetActions.setSelectedAutoFillAsset(showAutoFillNumber));
                  setHasEdited(false)
                //  setAssetNumberEdited(false)
                setShowAutoFillNumber(null)
                dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
                }
                }
              >
                <AutoFixHighIcon sx={{ fontSize: 18, mr: 1 }} />
                    Auto-fill with "{showAutoFillNumber.generalDetails.number}"
              </Paper>
            )}

            <ClonosTextarea
              rows="4"
              type="text"
              limit={1000}
              tabIndex={3}
              isLabel={true}
              uniqueKey="description"
              label={"Asset Description"}
              placeholder="Asset Description"
              handleGetValues={handleGetValues}
              defaultValue={formData?.description ?? globalStateOfChildData?.generalDetails?.description?? ""}
            ></ClonosTextarea>

            <ClonosSelect
              type="select"
              tabIndex={4}
              isLabel={true}
              isMandatory={false}
              placeholder="Select"
              label="Business Unit"
              uniqueKey="businessUnit"
              areaLabel="Business unit"
              handleGetValues={handleGetValues}
              errorMessage={"Please provide business unit."}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              defaultValue={formData?.businessUnit?.name??globalStateOfChildData?.generalDetails?.businessUnit?.name?? ''}
              options={dropdownsData?.businessUnits?.map((unit) => ({ label: unit?.name, value: unit?.id, isNeeded: true, isChecked: false })) || []}
            />
            <ClonosSelect
              tabIndex={4}
              type="select"
              isLabel={true}
              icon={DOWNANGLE}
              isMandatory={false}
              placeholder="Select"
              label={"Running Mode"}
              uniqueKey="runningMode"
              handleGetValues={handleGetValues}
              errorMessage={"Running Mode is Required!."}
              // options={dropdownsData?.runningMode?.map((opt) => ({ label: opt, value: opt, isNeeded: true }))}
              options={staticDropdownData?.runningMode?.map((opt)=>({label:opt?.value,value:opt?._id,isNeeded: true })) ||[]}
              defaultValue={formData?.runningMode??globalStateOfChildData?.generalDetails?.runningMode?.name ?? globalStateOfChildData?.generalDetails?.runningMode}
              onOpen={() => fetchStaticDropdownByCode("runningMode")}
           />
            <ClonosSelect
              tabIndex={5}
              type="select"
              isLabel={true}
              icon={DOWNANGLE}
              isMandatory={true}
              placeholder="Select"
              label={"Asset Department"}
              uniqueKey="department"
              handleGetValues={handleGetValues}
              errorMessage={"Asset Department is Required!."}
              defaultValue={formData?.department?.name?? globalStateOfChildData?.generalDetails?.department?.name}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              options={dropdownsData?.departments?.map((opt) => ({ label: opt?.name, value: opt?.id, isNeeded: true }))}
              disabled={mode === "edit" || (formData?.businessUnit?.id || globalStateOfChildData?.generalDetails?.department?.name ? false : true)}
            />
            <ClonosSelect
                tabIndex={6}
                type="select"
                isLabel={true}
                icon={DOWNANGLE}
                isMandatory={false}
                placeholder="Select"
                disabled={mode === "edit"}
                label={"Asset Category"}
                uniqueKey="category"
                handleGetValues={handleGetValues}
                // defaultValue={formData?.category?.name?? globalStateOfChildData?.generalDetails?.category?.name}
                defaultValue={formData?.category?.name?? globalStateOfChildData?.generalDetails?.category?.value}
                errorMessage={"Asset Category is Required!."}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                options={staticDropdownData?.assetCategory?.map((opt)=>({label:opt?.value,value:opt?._id,isNeeded: true })) ||[]}
                  //options={dropdownsData?.assetCategory?.map((opt) => ({label: opt?.name,value: opt?.id,isNeeded: true}))}
                onOpen={() => fetchStaticDropdownByCode("assetCategory")}
              />
            <ClonosSelect
              tabIndex={7}
              type="select"
              isLabel={true}
              icon={DOWNANGLE}
              isMandatory={false}
              placeholder="Select"
              label={"Criticality Level"}
              uniqueKey="criticalityLevel"
              handleGetValues={handleGetValues}
              errorMessage={"Criticality Level is Required!."}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
             // options={dropdownsData?.criticalityLevel?.map((opt) => ({ label: opt, value: opt, isNeeded: true }))}
               options={staticDropdownData?.criticalityLevel?.map((opt) => ({ label: opt?.value, value: opt?._id, isNeeded: true })) || []}
              defaultValue={formData?.criticalityLevel ?? globalStateOfChildData?.generalDetails?.criticalityLevel?.name ?? globalStateOfChildData?.generalDetails?.criticalityLevel}
               onOpen={() => fetchStaticDropdownByCode("criticalityLevel")}
            />
            <ClonosSelect
              tabIndex={8}
              type="select"
              isLabel={true}
              icon={DOWNANGLE}
              isMandatory={false}
              placeholder="Select"
              label={"Functional Area"}
              uniqueKey="functionalArea"
              handleGetValues={handleGetValues}
              errorMessage={"Functional Area is Required!."}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
               //options={dropdownsData?.functionalArea?.map((opt) => ({ label: opt, value: opt, isNeeded: true }))}
               options={staticDropdownData?.functionalArea?.map((opt)=>({label:opt?.value,value:opt?._id,isNeeded: true })) ||[]}
              defaultValue={formData?.functionalArea ?? globalStateOfChildData?.generalDetails?.functionalArea?.name ?? globalStateOfChildData?.generalDetails?.functionalArea}
              onOpen={() => fetchStaticDropdownByCode("functionalArea")}
           />
            <DynamicDropdown
              tabIndex={9}
              isUser={true}
              isLabel={true}
              url={SEARCHICON}
              isCheckbox={false}
              isActivator={true}
              isMandatory={true}
              isSearchable={true}
              uniqueKey={"owner"}
              label={"Asset Owner"}
              title={"Asset Owner"}
              placeholder={"Search"}
              disabled={mode === "edit"}
              labelActivator={"User Name"}
              populatedFields={["employeeId"]}
              handleGetValues={handleGetValues}
              heading={"Select from User Library"}
              handleMoreData={fetchMoreUsersOnScroll}
              errorMessage={"Asset Owner is Required!."}
              handleDynamicSearch={handleSearchAssetOwner}
              isDynamicLoad={assetOwners?.totalPageCount > pagination?.page}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              data={searchedAssetOwners?.currentPage ? searchedAssetOwners?.data || [] : assetOwners?.data || []}
             defaultValue={ formData?.owner ? [formData.owner] : globalStateOfChildData?.generalDetails?.owner ? [globalStateOfChildData.generalDetails.owner] : null }


/>
            {/* <ClonosInput
              limit={15}
              type="text"
              tabIndex={10}
              isLabel={true}
              label={"Census Number"}
              uniqueKey="censusNumber"
              placeholder="Enter Census Number"
              handleGetValues={handleGetValues}
              defaultValue={globalStateOfChildData?.generalDetails?.censusNumber}
            /> */}
          </div>
          <div className={Styles.generalDetails_right}>
              <FileUploader
                limit={6}
                tabIndex={11}
                fileSizeInMB={5}
                isMandatory={false}
                title={"images"}
                uniqueKey={"images"}
                label={"Asset Image"}
                typeOfRecord={"images"}
                acceptableFileTypes={[".jpg", ".png", ".jpeg"]}
                handleGetSelectedData={handleGetValues}
                defaultValue={globalStateOfChildData?.images?.length ? globalStateOfChildData?.images : []}
              />
          </div>
        </div>
      </div>
      <StepController
        mode={mode}
        steps={steps}
        loading={isLoading}
        handleBack={() => { }}
        handleNext={handleSaveAndNext}
        activeStep={activeStep}
      />

    </>
  );
};

export default memo(GeneralDetails);
