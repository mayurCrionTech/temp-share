import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall, doPostApiCall, doPutApiCall } from "../../../utils/ClonosApi";
import { debounce, handleCheckUniqueFieldsMethod, handleShowErrorAndWarning, modifyString } from "../../../utils/clonosCommon";
import { autoSaveFieldsToLocalStorage, debouncedSaveFildsToLocalStorage } from "../../../utils/common-managers";
import { debouncedCheckUniquenessOfAssetFields, handleIsAssetEdited } from "../managers/asset-common-managers";

// TO UPDATE LOCAL STATE WITH FILLED VALUES
export const handleGetFilledValuesOfGeneralDetails = ({propsVal,handlePrimaryObjectModifier,setFormData,globalStateOfChildData,primaryObject,setChangedData,mode,section}) => {
    const { name, selectedOption, updatedValue, uniqueKey, type,files } = propsVal;
    
    if (type === "dynamicDropdown") {
      if (!updatedValue) {
          setFormData(prev => {
            const updated = {
              ...prev,
              [uniqueKey]: null    // or "" or {} — whichever you prefer
            };

            debouncedSaveFildsToLocalStorage({
              key: "generalDetails",
              data: { generalDetails: updated }
            });

            return updated;
          });

        return;
       }

      handlePrimaryObjectModifier({ uniqueKey, response: selectedOption });
      setFormData((prev) => {
        let auxObj = {...prev,[uniqueKey]:{name:selectedOption[0]?.name,id:selectedOption[0]?.id}};
        debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:selectedOption?.length > 1 ? selectedOption : {name:selectedOption[0]?.name,id:selectedOption[0]?.id}}}})
        return auxObj
      });
      mode === "edit" && setChangedData((prev) => ({...prev,[uniqueKey]:{name:selectedOption[0]?.name,id:selectedOption[0]?.id}}))
    } else if (type === "searchableDropdown") {
       if (!updatedValue) {
          setFormData(prev => {
            const updated = {
              ...prev,
              [uniqueKey]: null    // or "" or {} — whichever you prefer
            };

            debouncedSaveFildsToLocalStorage({
              key: "generalDetails",
              data: { generalDetails: updated }
            });

            return updated;
          });

        return;
       }


      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
    
      setFormData((prev) => {
  const valueToSet = {
    name: updatedValue[uniqueKey] || updatedValue.name,
    id: updatedValue?.id || null
  };

  const auxObj = { ...prev, [uniqueKey]: valueToSet };

  debouncedSaveFildsToLocalStorage({
    key: "generalDetails",
    data: { generalDetails: auxObj },
  });

  return auxObj;
});


      // setFormData((prev) => {
      //   let auxObj = {...prev,[uniqueKey]:{name:updatedValue.name,id:updatedValue?.id}};
      //   debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]: {name:updatedValue.name,id:updatedValue?.id}}}})
      //   return auxObj
      // });
      //mode === "edit" && setChangedData((prev) => ({...prev,[uniqueKey]:{name:selectedOption[0]?.name,id:selectedOption[0]?.id}}))
    } else if (type === "select") {
       if (updatedValue === null) {
        // CLEAR VALUE
        setFormData(prev => {
          const updated = { ...prev, [uniqueKey]: null };

          debouncedSaveFildsToLocalStorage({
            key: "generalDetails",
            data: { generalDetails: updated }
          });

          return updated;
        });

        return;
      }

      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      setFormData((prev) => {
        let auxObj = {...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}};
        debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}}}})
        return auxObj
      });
      mode === "edit" && setChangedData(prev => ({...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}}))
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local") {
      const uniqueFields = ["name","number","censusNumber"];
      if(uniqueFields.includes(uniqueKey)){
        if(mode !== "edit"){
          // debouncedCheckUniquenessOfAssetFields({module:"assets",fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData})
        } else {
          updatedValue !== globalStateOfChildData?.generalDetails[`${uniqueKey}FromServer`] && debouncedCheckUniquenessOfAssetFields({module:"assets",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData,setChangedData})
        }
      }
      handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
      setFormData((prev) => {
        let auxObj = {...prev,[uniqueKey]:updatedValue};
        debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:updatedValue}}})
        return auxObj
      });
      mode === "edit" && setChangedData(prev => ({...prev,[uniqueKey]:updatedValue}))
    } else if(type === "file") {
      setFormData((prev) => {
        let auxObj = {...prev,[uniqueKey]:files};
        debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:files}}})
        return auxObj
      })
      
    } else if(type === "isEditable") {
      setFormData(prev => {
        let auxObj = {...prev,[`${uniqueKey}NeedToDelete`]:selectedOption};
        // debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:files[0]}}})
        return auxObj
      }) 
    }
}


export const validateGeneralDetails = ({ generalDetails = {} }) => {
  const {
    name = '',  // Default to an empty string if undefined
    number = '',
    description = '',
    businessUnit = {},
    runningMode = '',
    department = {},
    criticalityLevel = '',
    functionalArea = '',
    owner = {},
    censusNumber = ''
} = generalDetails;
return (process.env.REACT_APP_BUILDTYPE === "PRODUCTION" || process.env.REACT_APP_BUILDTYPE === "TESTING") ? Boolean(name && number && department?.id && owner?.id) : true
}




export const handleSaveGeneralDetail = ({ dispatch, checkRequiredField, formData, globalStateOfChildData, setActiveStep, setGlobalStateOfChildData, setIsLoading }) => {
  if (globalStateOfChildData?.id) {
    setActiveStep((prev) => prev + 1);
    return
  }
  // if (!checkRequiredField()) {
  //   handleShowErrorAndWarning({ dispatch, type: "error", message: "Please provide all required fiels!", showTime: "5000" });
  //   return
  // };
  const requestPayload = manipulateGeneralDetailsPayload({ payload: formData })
  setIsLoading(true);
  doPostApiCall({ url: AppUrl.createAsset, payload: requestPayload })
    .then((res) => {
      if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
        setActiveStep((prev) => prev + 1)
        setGlobalStateOfChildData((prev) => ({ ...prev, generalDetails: formData, id: res?.data?.result?.id }));
      }
    })
    .catch(err => console.error(err))
    .finally(() => setIsLoading(false))
}


export const handleUpdateGeneralDetails = ({ id, globalStateOfChildData, checkRequiredField, setActiveStep, setGlobalStateOfChildData, changedData, setIsLoading }) => {
  if (!checkRequiredField()) return;
  const remainingServerImages = changedData?.imagesNeedToDelete?.length ? globalStateOfChildData?.images?.filter((image) => !changedData?.imagesNeedToDelete?.includes(image?.id)) : globalStateOfChildData?.images;
  const imagesToSave = [...(remainingServerImages || []), ...(changedData?.images || [])];
  const requestPayload = manipulateGeneralDetailsPayload({ payload: { ...changedData, images: imagesToSave } });
  setIsLoading()
  const url = `${AppUrl.editAsset}/${id}`;
  doPutApiCall({ url, payload: requestPayload })
    .then((res) => {
      if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
        setGlobalStateOfChildData(prev => {
          return { ...prev, generalDetails: { ...prev?.generalDetails, ...changedData }, images: imagesToSave }
        })
        setActiveStep(prev => prev + 1)
      }
    })
    .catch(err => console.error(err))
    .finally(() => setIsLoading())
}

/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/
export const manipulateGeneralDetailsPayload = ({payload}) => {
  const {name,number,description,businessUnit,runningMode,department,category,criticalityLevel,functionalArea,owner,censusNumber,images} = payload;
    
  let generalDetails = {};

  if(name) generalDetails.name = name?.name || name;
  if(number) generalDetails.number = number?.name ||number;
  if(description) generalDetails.description = description;
  if(businessUnit?.id) generalDetails.businessUnit = businessUnit?.id;
  if(runningMode?.name) generalDetails.runningMode = runningMode?.name;
  if(runningMode?.id) generalDetails.runningModeId = runningMode?.id;
  if(department?.id) generalDetails.department = department?.id;
   if(category?.id) generalDetails.category = category?.id;
  //  if(category) generalDetails.categoryName = category?.name;
  if(criticalityLevel?.name) generalDetails.criticalityLevel = criticalityLevel?.name;
  if(criticalityLevel?.id) generalDetails.criticalityLevelId = criticalityLevel?.id;
   if(functionalArea?.name) generalDetails.functionalArea = functionalArea?.name;
  if(functionalArea?.id) generalDetails.functionalAreaId = functionalArea?.id;
  if(owner?.id) generalDetails.owner = owner?.id;
  if(censusNumber) generalDetails.censusNumber = censusNumber;
  if(Object.keys(generalDetails)?.length && images?.length) return { generalDetails,images: images?.map(image => image?.id)};
  if(Object.keys(generalDetails)?.length && !images?.length) return { generalDetails};
  if(!Object.keys(generalDetails)?.length && images?.length) return {images:images?.map(image => image?.id)}
  return {}
}

export const handleGetAssetCategories = ({setterMethod}) => {
  doGetApiCall({url:AppUrl.getAssetCategories})
  .then((res) => {
    if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
      setterMethod(res?.data?.result?.data)
    }

  })
  .catch(err => console.error(err)) 
}