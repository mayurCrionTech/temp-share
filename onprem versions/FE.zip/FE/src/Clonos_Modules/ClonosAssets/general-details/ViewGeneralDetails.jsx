import { useState } from "react"
import Styles from "../../ClonosAssets/ViewAsset/view-asset.module.css"
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading"
export const ViewGeneralDetails = ({generalDetails}) => {

    return <div className={Styles.gen_details_container}>
        <h4 className={Styles.v_a_header}>General Details</h4>
        <div className={Styles.fields_container}>
            {generalDetails?.name ? <div className={Styles.field_wrapper}>
                <h4>Asset Name</h4>
                <p>{generalDetails?.name || "-"}</p>
            </div>: <></>}
            {generalDetails?.number ?<div className={Styles.field_wrapper}>
                <h4>Asset Number</h4>
                <p>{generalDetails?.number || "-"}</p>
            </div> : <></>}
            {generalDetails?.description ? <div className={Styles.field_wrapper}>
                <h4>Asset Description</h4>
                <p>{generalDetails?.description || "-"}</p>
            </div> : <></>}
            {generalDetails?.runningMode ? <div className={Styles.field_wrapper}>
                <h4>Running Mode</h4>
                <p>{generalDetails?.runningMode || "-"}</p>
            </div> : <></>}
            {generalDetails?.department?.name ? <div className={Styles.field_wrapper}>
                <h4>Department</h4>
                <p>{generalDetails?.department?.name || "-"}</p>
            </div> : <></>}
            {generalDetails?.category?.name ? <div className={Styles.field_wrapper}>
                <h4>Asset Category</h4>
                <p>{generalDetails?.category?.name || "-"}</p>
            </div> : <></>}
            {generalDetails?.criticalityLevel ? <div className={Styles.field_wrapper}>
                <h4>Criticality Level</h4>
                <p>{generalDetails?.criticalityLevel || "-"}</p>
            </div> : <></>}
            {generalDetails?.functionalArea ? <div className={Styles.field_wrapper}>
                <h4>Functional Area</h4>
                <p>{generalDetails?.functionalArea || "-"}</p>
            </div> : <></>}
            {generalDetails?.owner?.name ? <div className={Styles.field_wrapper}>
                <h4>Asset Owner</h4>
                <p>{generalDetails?.owner?.name || "-"}</p>
            </div> : <></>}
            {/* <div className={Styles.field_wrapper}>
                <h4>Census Number</h4>
                <p>{generalDetails?.censusNumber || "-"}</p>
            </div> */}
        </div>
    </div>
}



export const ViewAssetImages = ({images,}) => {
    
}