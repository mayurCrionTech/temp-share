import { useEffect, useRef, useState } from "react";
import Styles from "./view-asset-history.module.css";
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { commonPageState, getFormatedDate, modifyString } from "../../../../utils/clonosCommon";
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { Navigate, useNavigate } from "react-router-dom";
import { ViewCoreDetails } from "../view-core-details/ViewCoreDetail";
import { VIEW_ASSET_COMMON_NAVIGATORS_VALUES } from "../../AssetConstants";


const formatHistoryName = (name) => {
  // Split the string at capital letters and join with spaces
  const words = name.split(/(?=[A-Z])/).map(word => 
    word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
  );
  return words.join(' ');
};
export const ViewAssetHistory = ({assetId,setNavigatorValues,setActiveTab}) => {
  const containerRef = useRef(null);
  const [isLoading,setIsLoading] = useToggler();
  const [assetHistory,setAssetHistory] = useState({})
  const [pagination,setPagination] = useState(commonPageState)
   const navigate= useNavigate()
  const eventDescriptions = {
    installationDate: {message:"Installed On",description:""},
    warrantyEndDate: {message:"Warranty End"},
    lastCalibrationDate:{message:"Calibration Date"},
    corrosionCheckDate:{message:"Corrosion Check"},
    lastAuditDate:{message:"Audit Date"},
    assetBreakdownDate:{message:"Asset Breakdown"},
    assetMaintenanceComletionDate:{message:"Asset Maintenance"}
  }

  const statusBaseBG = {
    planned:"#FFD700",
    executed:"green",
    missed:"red"
  }
  const getTextColor = (bgColor) => {
    switch(bgColor) {
      case "#FFD700": // yellow
        return "#000000"; // black text for yellow background
      default:
        return "#FFFFFF"; // white text for other backgrounds
    }
  };


const handleNavigatePage = (props) => {
  if (props.moduleName === "workOrders") {
    navigate(`/view-work-order/${props.workOrderName}`, {
      state: { workOrderId: props?.moduleId }
    });
  } else {
    // Update active tab
    setActiveTab("Details");

    // Update status so underline moves
    const updated = VIEW_ASSET_COMMON_NAVIGATORS_VALUES.map(item =>
      item.value === "Details"
        ? { ...item, status: true }
        : { ...item, status: false }
    );

    setNavigatorValues(updated);
  }
};


  const handleScroll = () => {
    const container = containerRef.current;
    if (
      container && 
      assetHistory?.totalPageCount > pagination.page &&
      container.scrollTop + container.clientHeight >= container.scrollHeight - 10 &&
      !isLoading
    ) {
      setPagination((prev) => ({...prev,page:prev.page+1}));
    }
  };

  useEffect(() => {
    setIsLoading()
    doGetApiCall({url:`/assets/${assetId}/history`,params:pagination})
    .then((res) => {
      if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
        const newHistory = res?.data?.result?.data || [];
        setAssetHistory((prev) => {
          let prevData = prev?.data || [];
          const uniqueData = newHistory.filter(
            (newItem) => !prevData.some((existingItem) => existingItem.id === newItem.id)
          );
          return {...res?.data?.result,data:[...prevData, ...uniqueData]};
        });
      }
    })
    .catch((err) => console.error(err))
    .finally(setIsLoading)
  },[pagination?.page])
  
  return (
    <div className={Styles.astHistoryContainer}>
      {
        isLoading ? <div className="center_wrapper"><ClonosSpinner/></div> : !isLoading && !assetHistory?.data?.length ? <div className="center_wrapper"><h4>No Details present</h4></div> 
        : 
        <div ref={containerRef}
          onScroll={handleScroll}
          style={{ overflowY: "auto", maxHeight: "100%" }}
          className={Styles.stteper_container}>
         {assetHistory?.data?.map((step, index) => {
          const displayMessage = eventDescriptions[step.name]?.message || formatHistoryName(step.name);
          const bgColor = statusBaseBG[step.status];
          const circleClass = bgColor === "red" ? "red" : bgColor === "#FFD700" ? "yellow" : "green";

            // Determine next step color
            const nextStep = assetHistory?.data?.[index + 1];
            const nextStepClass = nextStep ? statusBaseBG[nextStep.status] : null;

            // Set line class based on next step
            let lineClass = "";
            if (nextStepClass === "red") {
              lineClass = "red";
            } else if (nextStepClass === "#FFD700") {
              lineClass = "yellow"; // Dashed yellow line before yellow circle
            } else if (nextStepClass === "green") {
              lineClass = "green";
            }

            return (
              <div className={Styles.step_wrapper} key={step.id} onClick={()=>handleNavigatePage(step)}>
                <div className={Styles.left}>
                  {step?.eventDate ? getFormatedDate(step?.eventDate) : ""}
                </div>
                <div className={Styles.center}>
                  <div className={`${Styles.circle} ${Styles[circleClass]}`}>
                    {index + 1}
                  </div>
                  {index < assetHistory?.data?.length - 1 && (
                    <div className={`${Styles.line} ${Styles[lineClass]}`}>
                      <p></p>
                    </div>
                  )}
                </div>
                <div className={Styles.right} >
                  <h5>{displayMessage}</h5>
                  {step.moduleName === "workOrders" && step.description && (
                    <p className={Styles.description}>{step.description}</p>
                  )}
                </div>
              </div>
            );
          })}

      </div>
      }
    </div>
  );
};


// const displayMessage = eventDescriptions[step.name]?.message || formatHistoryName(step.name);