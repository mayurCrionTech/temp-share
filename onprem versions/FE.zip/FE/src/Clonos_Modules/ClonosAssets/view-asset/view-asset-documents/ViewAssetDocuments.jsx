import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Card, Tooltip } from "@mui/material";
import { commonPageState, getToken, setSerialNumber } from "../../../../utils/clonosCommon";
import useToggler from "../../../../CustomHooks/TogglerHook";
import configs from "../../../../config";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import ClonosConfirmationDialog from "../../../../components/Dialogs/ClonosConfirmationDialog";
import { handleGetAssetDocuments } from "../../asset-documents/asset-documents-manager";
import ClonosDocumentViewer from "../../../../components/CommonComponents/document-viewer/ClonosDocumentViewer";

export const ViewAssetDocuments = ({ assetId }) => {
  const [documents, setDocuments] = useState({});
  const dispatch = useDispatch();
  const [pagination, setPagination] = useState(commonPageState);
  const [documentToView,setDocumentToView] = useState({});
  const [showDocumentViewer,setShowDocumentViewer] = useState(false)
  const [isLoading, setIsLoading] = useToggler();
  const columns = [
    {
      field: "index",
      headerName: "SI.NO",
      width: 100,
      renderCell: (val) => {
        return <p>{val?.row?.index || "-"}</p>;
      },
    },
    {
      field: "number",
      headerName: "DOCUMENT NUMBER",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.number}>
            <p>{val?.row?.number || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "name",
      headerName: "DOCUMENT NAME",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.name}>
            <p>{val?.row?.name || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "type",
      headerName: "DOCUMENT TYPE",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.type}>
            <p>{val?.row?.type || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "status",
      headerName: "DOCUMENT STATUS",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.status}>
            <p>{val?.row?.status || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "revisionNumber",
      headerName: "REVISION NUMBER",
      flex: 1,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.revisionNumber}>
            <p>{val?.row?.revisionNumber || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "viewDoc",
      headerName: "VIEW DOCUMENT",
      width: 300,
      renderCell: (val) => {
        return (
          <Tooltip title={val?.row?.name}>
            <p
              onClick={() => {
                setDocumentToView(val?.row?.file);
                setShowDocumentViewer(true)
              }}
              style={{ color: "#0a5fff", textDecoration: "underline" }}
            >
              {val?.row?.file?.name || "-"}
            </p>
          </Tooltip>
        );
      },
    },
  ];

  const handleViewDocument = (docId) => {
    const token = getToken();
    window.open(`${configs.url}/?astDocId=${docId}&token=${token}`);
  };


  useEffect(() => {
    handleGetAssetDocuments({setterMethod:setDocuments,setIsLoading,pagination,assetId,pagination})
  },[pagination?.page,pagination?.limit])

  return (
    <>
      <div
        style={{
          height:"90%",
          padding: "2rem 5rem",
        }}
      >
        <ClonosDataGrid
          isLoading={isLoading}
          onPageChange={(e) =>
            setPagination({ page: e.page + 1, limit: e.pageSize })
          }
          checkboxSelection={false}
          rows={setSerialNumber(documents?.data,pagination?.page,pagination?.limit)}
          columns={columns}
          uniqueIdField={"id"}
          pageLimit={pagination?.limit}
          isEdit={false}
          isDelete={false}  
          totalDataCount={documents?.totalDataCount}
        />
      </div>
      {documentToView?.url ? <ClonosDocumentViewer isDocument={true} file={documentToView} isOpen={showDocumentViewer} closeMethod={() => setShowDocumentViewer(false)}/> : <></>}

    </>
  );
};
