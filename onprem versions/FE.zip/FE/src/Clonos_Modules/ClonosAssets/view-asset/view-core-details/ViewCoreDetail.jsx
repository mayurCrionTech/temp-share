import {ViewGeneralDetails } from "../../general-details/ViewGeneralDetails";
import { ViewCalibrationDetails, ViewHazardousAreaDetails, ViewHierarchyPage, ViewLocationDetails, ViewSpecifications, ViewWarrantyDetails } from "../../Specifications/ViewSpecifications";
import { ViewAssetImages } from "../../ViewAsset/view-asset-images/ViewAssetImages";
import Styles from "./view-core-details.module.css"
import { doGetApiCall } from "../../../../utils/ClonosApi";
import { useEffect,useState } from "react";


export const ViewCoreDetails = ({assetDetails, hierarchyDetails, locationAndHierarchyDetails}) => { 
 
  return (
    <div className={Styles.content_container}>
      <div className={Styles.left_side_content}>
        <ViewGeneralDetails generalDetails={assetDetails?.generalDetails} />
        {Object?.keys(assetDetails?.specifications?.manufacturingDetails || {})?.length > 0 && <ViewSpecifications
          specifications={assetDetails?.specifications?.manufacturingDetails}
        />}
        {Object?.keys(assetDetails?.specifications?.hazardousAreaDetails || {})?.length > 0 && <ViewHazardousAreaDetails
          hazardousAreaDetails={
            assetDetails?.specifications?.hazardousAreaDetails
          }
        />}
        {Object?.keys(assetDetails?.specifications?.calibrationDetails || {})?.length > 0 && <ViewCalibrationDetails
          calibrationDetails={assetDetails?.specifications?.calibrationDetails}
        />}
      </div>
      <div className={Styles.right_side_content}>
        <ViewAssetImages images={assetDetails?.images}/>
        {Object?.keys(assetDetails?.locationAndHierarchyDetails || {})?.length > 0  && <ViewLocationDetails locationDetails={assetDetails?.locationAndHierarchyDetails}/>}
        {Object?.keys(assetDetails?.specifications?.warrantyDetails || {})?.length > 0 && <ViewWarrantyDetails warrantyDetails={assetDetails?.specifications?.warrantyDetails} />}
        {hierarchyDetails.length ? <ViewHierarchyPage hierarchyDetails={hierarchyDetails}  locationAndHierarchyDetails={locationAndHierarchyDetails}/> :<></>}
         
      </div>
    </div>
  );
};
