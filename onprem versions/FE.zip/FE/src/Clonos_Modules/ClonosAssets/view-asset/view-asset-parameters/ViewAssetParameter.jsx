import { memo } from "react"
import Styles from "./view-asset-parameters.module.css"
import { DataGrid } from "@mui/x-data-grid";
import { useState } from "react";
import { useEffect } from "react";
import { Card, Tooltip } from "@mui/material";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import VIEW_ASSET_PARAMETER_BLUE_CHECKBOX from "../../../../assets/UIUX/icons/blue-fill-check.svg"
import VIEW_ASSET_PARAMETER_GRAY_CHECKBOX from "../../../../assets/UIUX/icons/gray-fill-check.svg";
import VIEW_ASSET_PARAMETER_OUTLINED_CHECKBOX from "../../../../assets/UIUX/icons/outlined-square.svg"
import VIEW_ASSET_PARAMETER_ALERT_CIRCLE from "../../../../assets/UIUX/icons/alert-circle.svg"
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import { handleGetParameters } from "../../asset-parameters/asset-parameters.managers";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { handleClientDateInConfiguredTimeZone, handleShowErrorAndWarning, setSerialNumber } from "../../../../utils/clonosCommon";
import ClonosLiveStatusButton from "../../../../components/CommonComponents/ClonosLiveStatusButton/ClonosLiveStatusButton";
import { doGetApiCall, doPutApiCall } from "../../../../utils/ClonosApi";
import { useDispatch } from "react-redux";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";

const ViewAssetParameters = ({assetId}) => {
    const [showModal,setShowModal] = useState(false);
    const [parameters,setParameters] = useState({});
    const [isLoding,setIsLoading] = useToggler();
    const [pagination,setPagination] = useState({page:1,limit:15})
    const [selectedAsset, setSelectedAsset] = useState(null);
    const [actionType, setActionType] = useState(""); 
    const dispatch = useDispatch()
    const [refreshApi,setRefreshApi]=useToggler()


    const columns = [
        {

            field:"index",
            headerName:"SI.NO",
            width:"100"
        },
        {

            field:"name",
            headerName:"PARAMETERS",
            flex:1,
            renderCell:(val) => {
                return <Tooltip title={val?.row?.name}>
                    <p>{val?.row?.name || "-"}</p>
                </Tooltip>
            }
        },
        {
            field: "value",
            headerName: "VALUE",
            align: "center",
            headerAlign: "center",
            flex: 1,
            renderCell: (val) => {
              const value = val?.row?.value;

              return (
                <Tooltip title={value ?? "-"}>
                  <p>
                    {value !== null && value !== undefined
                      ? Number(value).toFixed(3)
                      : "-"}
                  </p>
                </Tooltip>
              );
            },
          },
        {

            field:"unit",
            headerName:"UNIT",
             align: "center",
            headerAlign: "center",
            flex:1,
            renderCell:(val) => {
                return <Tooltip title={val?.row?.unit}>
                    <p>{val?.row?.unit || "-"}</p>
                </Tooltip>
            }
        },
        // {
        //     field:"tracker",
        //     headerName:"ENABLE TRACKING",
        //     align:"center",
        //     headerAlign:"center",
        //     flex:1,
        //     renderCell:(params) => {
        //       console.log(params,"params")
        //         return <div className={Styles.status_tracker}>
        //             {
        //                 params?.row?.trackingStatus === "Enabled" ?  <div onClick={() => setShowModal(true)}><img src={VIEW_ASSET_PARAMETER_BLUE_CHECKBOX}/></div> : params?.row?.trackingStatus === "Requested" ? <div  onClick={() => setShowModal(true)}><img src={VIEW_ASSET_PARAMETER_GRAY_CHECKBOX}/></div> : <div  onClick={() => setShowModal(true)}><img src={VIEW_ASSET_PARAMETER_OUTLINED_CHECKBOX}/></div>
        //             }

                    
        //         </div>
        //     }
        // },
        {
    field: "tracker",
    headerName: "ENABLE TRACKING",
    align: "center",
    headerAlign: "center",
    flex: 1,
    renderCell: (params) => {
      const isActive = params?.row?.trackingStatus === "Active";

      return (
        <div className={Styles.status_tracker}>
        {isActive ? (
            <CheckBoxIcon
              onClick={() => {
                setSelectedAsset(params.row);
                setActionType("Unlinked");
                setShowModal(true);
              }}
              style={{
                color: "#06337E", // <-- easily changeable color
                cursor: "pointer",
                width: "22px",
                height: "22px"
              }}
            />
          ) : (
            <CheckBoxOutlineBlankIcon
              onClick={() => {
                setSelectedAsset(params.row);
                setActionType("Active");
                setShowModal(true);
              }}
              style={{
                color: "gray",
                cursor: "pointer",
                width: "22px",
                height: "22px"
              }}
            />
          )}
                </div>
              );
            },
          },

        {

            field:"trackingStatus",
            headerName:"TRACKING STATUS",
            align:"center",
            headerAlign:"center",
            flex:1,
            renderCell:(params) => {
           

                return params?.row?.trackingStatus ==="Active" ?  <ClonosLiveStatusButton status="online" type="minimal" /> : <ClonosLiveStatusButton status="offline" type="minimal" />

            }
        },
         {

            field:"createdAt",
            headerName:"CREATED AT",
             align:"center",
            headerAlign:"center",
            flex:1,
            valueGetter: (params) => params?.row?.createdAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "object" })?.clientView : "-"
        },
           {

            field:"updatedAt",
            headerName:"UPDATED AT",
             align:"center",
            headerAlign:"center",
            flex:1,
            valueGetter: (params) => params?.row?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.updatedAt, parseType: "object" })?.clientView : "-"
        },
        // {

        //     field:"compare",
        //     headerName:"COMPARE",
        //     flex:1,
        //     renderCell:(params) => {
        //         return <Tooltip >
        //         <p>{"Compare"}</p>
        //     </Tooltip>
        //     }
        // },
        
    ]
const handleLiveTracking = async () => {
  if (!selectedAsset) return;

  try {
    const status = actionType === "Active" ? "Active" : "UnLinked";
    const assetId=selectedAsset?.asset
    const parameterId= selectedAsset?.id
    const url = `/assets/${assetId}/parameters/${parameterId}`
    const payload ={
        trackingStatus: status
    }
        doPutApiCall({url,payload})
        .then((res)=>{
        
           setRefreshApi()
           handleShowErrorAndWarning({ type: "success", dispatch, message: `Asset ${status=="Active"? "Activated": "Unlinked"} sucessfully`, showTime: 5000 })
       })
      
   
    // const response = await fetch(`/api/assets/${selectedAsset.id}/tracking`, {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify({ trackingStatus: newStatus }),
    // });

    // const data = await response.json();

    
  } catch (error) {
    console.error("Error updating tracking:", error);
   
  } finally {
    setShowModal(false);
  }
};


    useEffect(() => {
        handleGetParameters({assetId,setterMethod:setParameters,setIsLoading,pagination})
    },[pagination?.page,pagination?.limit,refreshApi])

    return (
      <>
        {/* <div className={Styles.v_a_parameters_container}> */}
        {/* <div className={Styles.v_a_parameters_sub_container}> */}
        <Card
          style={{
            flex: 1,
            height: "90%",
            margin: "1rem 1rem 0rem 1rem",
            padding: "1rem",
          }}
        >
          <ClonosDataGrid
            loading={isLoding}
            checkboxSelection={false}
            rows={setSerialNumber(parameters?.data,pagination?.page,pagination?.limit)}
            columns={columns}
            uniqueIdField={"id"}
            totalCount={parameters?.totalDataCount}
            pageLimit={pagination?.limit}
            height={600}
            onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          />
        </Card>
        {/* </div> */}
        {/* </div> */}
        {/* <Modal isOpen={showModal} closeModalMethod={setShowModal}>
          <div className={Styles.modal_sub_container}>
            <div className={Styles.modal_header}>
              <div className={Styles.modal_header_content}>
                <div className={Styles.modal_header_content_left}>
                  <div>
                    <img src={VIEW_ASSET_PARAMETER_ALERT_CIRCLE} />
                  </div>
                  <h4>Enable Tracking</h4>
                </div>
                <div className={Styles.modal_header_content_right}>
                  <CloseIcon onClick={() => setShowModal(false)} />
                </div>
              </div>
            </div>
            <div className={Styles.modal_content}>
              <div>
                Do you confirm that you need live tracking for this asset ?
              </div>
              <div className={Styles.btn_controller}>
                <ClonosButton
                  onClick={() => setShowModal(false)}
                  isHollow={true}
                  style={{ color: "#E0606A", border: "1px solid #E0606A" }}
                  p={"1rem 3rem"}
                >
                  Cancel
                </ClonosButton>
                <ClonosButton
                  onClick={() => handleLiveTracking()}
                  p={"1rem 3rem"}
                >
                  Yes
                </ClonosButton>
              </div>
            </div>
          </div>
        </Modal> */}

        <Modal isOpen={showModal} closeModalMethod={setShowModal}>
  <div className={Styles.modal_sub_container}>
    <div className={Styles.modal_header}>
      <div className={Styles.modal_header_content}>
        <div className={Styles.modal_header_content_left}>
          <div>
            <img src={VIEW_ASSET_PARAMETER_ALERT_CIRCLE} alt="alert" />
          </div>
          <h4>{actionType === "Active" ? "Active Asset" : "Unlink Asset"}</h4>
        </div>
        <div className={Styles.modal_header_content_right}>
          <CloseIcon onClick={() => setShowModal(false)} />
        </div>
      </div>
    </div>

    <div className={Styles.modal_content}>
      <div style={{textAlign:"center",fontSize:"0.9rem",fontFamily:"sans-serif"}}>
        {actionType === "Active"
        ? "Are you sure you want to activate this asset for live tracking?"
        : "Are you sure you want to unlink this asset from live tracking?"}

      </div>

      <div className={Styles.btn_controller}>
        <ClonosButton
          onClick={() => setShowModal(false)}
          isHollow={true}
          style={{ color: "#E0606A", border: "1px solid #E0606A" }}
          p={"1rem 3rem"}
        >
          Cancel
        </ClonosButton>
        <ClonosButton onClick={handleLiveTracking} p={"1rem 3rem"}>
          Yes
        </ClonosButton>
      </div>
    </div>
  </div>
</Modal>

      </>
    );
}

export default memo(ViewAssetParameters)
// handleGetSelectedRowsMethod, pageLimit, isEdit, isDelete, editPermission, deletePermission, createPermission, isEditMethod, isDeleteMethod, isCreateMethod, height, uniqueIdField