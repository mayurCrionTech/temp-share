import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant"
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall, doPostApiCall, doPutApiCall } from "../../../utils/ClonosApi"
import { handleShowErrorAndWarning } from "../../../utils/clonosCommon";

// export const handleGetSparesOfAsset = ({dispatch,assetId,setterMethod,pagination,setIsLoading,setLcSetterMethod}) => {
//     setIsLoading();
//     doGetApiCall({url:AppUrl.getAllSpares,params:{...pagination,asset:assetId,selectFields:"name,quantity,cycleFrequency,replacementFrequency,minimumRequirement"}})
//     .then((res) => {
//         if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
//             setterMethod(res?.data?.result)
//             setLcSetterMethod && setLcSetterMethod(res?.data?.result)
//         }
//     })
//     .catch((err) => {
//         handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
//     })
//     .finally(() => setIsLoading())
// }

export const handleGetSparesOfAsset = ({dispatch,assetId,setterMethod,pagination,setIsLoading,setLcSetterMethod}) => {
    setIsLoading();
    //doGetApiCall({url:AppUrl.getAllAssetSpares,params:{...pagination,asset:assetId,selectFields:"name,quantity,cycleFrequency,replacementFrequency,minimumRequirement"}})
    doGetApiCall({url:`assets/${assetId}/spares`,params:pagination})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
            setLcSetterMethod && setLcSetterMethod(res?.data?.result)
        }
    })
    .catch((err) => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
    .finally(() => setIsLoading())
}

const handleManipulateSparesPayload = ({payload,assetId}) => {
    return payload?.map((spare) => {
        let auxSpare = {...spare};
        if(spare.isLocal) delete auxSpare.id;
        delete auxSpare.isEdited;
        delete auxSpare.isLocal;
        return {...auxSpare,assetId}
    })
}

export const handleCreateMultipleSpares = ({dispatch,payload,assetId,setIsLoading,next}) => {
    const requestPayload = handleManipulateSparesPayload({payload,assetId})
     setIsLoading();
    doPostApiCall({url:AppUrl.createSpare,payload:{spares:requestPayload}})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
            next && next()
        }
    })
    .catch((err) => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
    .finally(() => setIsLoading())
}


export const handleChangeSparesDetailsHelper = ({updatedValue,setLcSpares,setServerSpares,closeModalMethod}) => {
    let isChangedSpareIsFromLocal = false;
    let isChangedSpareIsFromServer = false;
    setLcSpares(prev => {
        return prev?.map((spare) => {
            if(spare?.id === updatedValue?.id){
                isChangedSpareIsFromLocal = true;
                return {...updatedValue,isLocal:true}
            } else {
                return spare
            }
        })
    })
    if(!isChangedSpareIsFromLocal) {
        setServerSpares(prev => {
            let tempPrev = {...prev};
            const auxSpares = prev?.data?.length ?  prev?.data?.map((spare) => {
                if(spare?.id === updatedValue?.id) {
                    tempPrev.isEdited = true;
                    return {...updatedValue,isEdited:true};
                }
                return spare
            }) : [];
            return {...tempPrev,data:auxSpares}
        })
    }
    closeModalMethod();
}

export const handleRemoveAssetSpare = ({spareToRemove,setLcSpares,setServerSpares,setSparesToDelete}) => {
    if(spareToRemove?.isLocal){
        setLcSpares(prev => {
            return prev?.filter((spare) => spare?.id !== spareToRemove?.id)
        })
    } else {
        setSparesToDelete(prev => ([...(prev?.length ? prev : []),spareToRemove?.id]))
        setServerSpares(prev => {
            const spares = prev?.data?.length ? prev?.data : [];
            const remainingSpares = spares?.filter((spare) => spare?.id !== spareToRemove?.id); 
            return {...prev,data:remainingSpares}
        })
    }

}


export const  handleEditMultipleAssetSpares = ({dispatch,payload,assetId,setIsLoading,next}) => {
    const requestPayload = handleManipulateSparesPayload({payload,assetId})
    setIsLoading();
    doPutApiCall({url:AppUrl.editSpare,payload:{spares:requestPayload}})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
            next && next()
        }
    })
    .catch((err) => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
    .finally(() => setIsLoading())
}


export const handleEditSpareHelperMethod = ({assetId,lcSpares,serverSpares,sparesToDelete,setIsLoading,next}) => {
    const sparesToAdd = handleManipulateSparesPayload({payload:lcSpares,assetId});
    const auxServerSpares = serverSpares?.data?.filter((spare) => spare.isEdited);

    if(auxServerSpares?.length && sparesToAdd?.length) {
        setIsLoading();
        handleEditMultipleAssetSpares({payload:auxServerSpares,assetId,setIsLoading})
        handleCreateMultipleSpares({payload:sparesToAdd,setIsLoading:setIsLoading,assetId,next})
        // .then((res) => {
        //     if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
        //         handleCreateMultipleSpares({payload:sparesToAdd,setIsLoading:setIsLoading,assetId,next})
        //         .then((response) => {
        //             if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
        //                 next && next();
        //             }
        //         })
        //         .finally(() => setIsLoading())
        //     } else {
        //         handleShowErrorAndWarning({dispatch,type:"error",message:"Failed to update spares!",showTime:"5000"});
        //         setIsLoading();
        //     }
        // })
    } else if(serverSpares?.data?.length) {
        setIsLoading();
        handleEditMultipleAssetSpares({payload:serverSpares?.data,assetId,setIsLoading})
        // .then((res) => {
        //     if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
        //         next  && next();
        //     } 
        // })
        // .finally(() => setIsLoading())
    } else if(sparesToAdd?.length) {
        setIsLoading();
        handleCreateMultipleSpares({payload:sparesToAdd,setIsLoading,assetId,next})
        // .then((response) => {
        //     if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
        //         next && next();
        //     }
        // })
        // .finally(() => setIsLoading())
    }
}   