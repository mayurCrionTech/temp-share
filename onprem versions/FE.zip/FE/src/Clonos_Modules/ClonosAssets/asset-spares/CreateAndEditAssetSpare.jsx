// import { useEffect, useState } from "react"
// import Styles from "../../../ModuleStyles/Assets/assetSparesCreation.module.css"
// import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
// import { handleShowErrorAndWarning, setSerialNumber } from "../../../utils/clonosCommon"
// import { UploadSpareModal } from "../../spares/components/upload-spare-modal/UploadSpareModal"
// import CircleMinusIcon from "../../../resources/icons/static/CircleMinusIcon"
// import EditInteractiveIcon from "../../../resources/icons/interactive/EditInteractiveIcon"
// import { StepController } from "../Components/StepController/StepController"
// import useToggler from "../../../CustomHooks/TogglerHook"
// import CircleMinusInteractiveIcon from "../../../resources/icons/interactive/CircleMinusInteractiveIcon"
// import { handleCreateMultipleSpares, handleGetSparesOfAsset } from "./asset-spares-manager"
// import { handleCreateSingleSpareMethod, handleCreateSpareHelper, handleDeleteSpareMethod, handleEditSpareMethod, handleGetChangedFielsOfSpare } from "../../spares/managers/spares-manager"
// import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
// import { useDispatch } from "react-redux"
// import { useNavigate } from "react-router-dom"


// export const CreateAndEditAssetSpare = ({setGlobalStateOfChildData, globalStateOfChildData, steps, activeStep, setActiveStep,modeOfAsset}) => {
//     const dispatch = useDispatch();
//     const Navigate = useNavigate();
//     const [showSpareModal,setShowSpareModal] = useState(false);
//     const [selectedSpare,setSelectedSpare] = useState({});
//     const [mode,setMode] = useState(modeOfAsset)
//     const [sparesData,setSparesData] = useState({});
//     const [serverSpare,setServerSpare] = useState({});
//     const [isLoading,setIsLoading] = useToggler();
//     const [showDeleteDailog,setShowDeleteDailog] = useState(false);
//     const [showDeleteLoader,setShowDeleteLoader] = useToggler();
//     const [saveLoader,setSaveLoader] = useToggler();
//     const [pagination,setPagination] = useState({page:1,limit:15})
//     const sparesColumns = [
//         {
//             field:"index",
//             headerName:"SI.NO",
//             hideable:false
//         }, 
//         {
//             field:"name",
//             headerName:"SPARE NAME",
//             flex:1,
//         },
//         {
//             field:"quantity",
//             headerName:"QUANTITY",
//             flex:1,
//             renderCell: (param) => {
//                 return <p>{param?.row?.quantity?.value}{" "}{param?.row?.quantity?.type}</p>
//             }
//         },
//         {
//             field:"replacementFrequency",
//             headerName:"REPLACEMENT FREQUENCY",
//             flex:1,
//             renderCell: (param) => {
//                 return <p>{param?.row?.replacementFrequency?.value}{" "}{param?.row?.replacementFrequency?.type}</p>
//             }
//         },
//         {
//             field:"cycleFrequency",
//             headerName:"CYCLE FREQUENCY",
//             flex:1,
//             renderCell: (param) => {
//                 return <p>{param?.row?.cycleFrequency?.value}{" "}{param?.row?.cycleFrequency?.type}</p>
//             }
//         },
//         {
//           field:"minimumRequirement",
//           headerName:"MINIMUM REQUIREMENT",
//           flex:1,
//       },
//         {
//             field:"action",
//             headerName:"ACTIONS",
//             width:"200",
//             renderCell: (param) => {
//                 return <div style={{display:"flex",gridGap:"2rem",alignItems:"center"}}>
//                     <EditInteractiveIcon size="24" tooltipTitle={"Edit"}
//                         onClick={() => {
//                             setShowSpareModal(true);
//                             setSelectedSpare(param?.row);
//                             setMode("edit");
//                         }}
//                     />
//                     <CircleMinusInteractiveIcon onClick={() => {
//                       setShowDeleteDailog(true);
//                       setSelectedSpare(param?.row?.id)
//                     }}/>
//                 </div>
//             }
//         }
//     ]

//     const handleSaveSpareDetails = (spareDetails) => {
//        if(mode === "edit") {
//         const requestPayload = handleGetChangedFielsOfSpare({lcSpare:spareDetails,serverSpare:selectedSpare});
//         if(Object.keys(requestPayload)?.length === 0) {
//           setShowSpareModal(false);
//           return
//         }

//         globalStateOfChildData?.id && handleEditSpareMethod({dispatch,assetId:globalStateOfChildData?.id,payload:{...requestPayload,id:spareDetails?.id},setIsLoading,next:() => {
//           setShowSpareModal(false);
//           handleGetSparesOfAsset({dispatch,assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination,});
//           handleShowErrorAndWarning({dispatch,message:"Spare updated successfully.",type:"success",showTime:"5000"})
//         }})
        
//        } else {
//         globalStateOfChildData?.id && handleCreateSingleSpareMethod({payload:{...spareDetails,assetId:globalStateOfChildData?.id},setIsLoading:setSaveLoader,next:() => {
//           setShowSpareModal(false);
//           handleGetSparesOfAsset({dispatch,assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination,});
//           handleShowErrorAndWarning({dispatch,message:"Spare create successfully.",type:"success",showTime:"5000"})
//         }})
//        }
//     }
    

//     const handleRemoveSpare = () => {
//       handleDeleteSpareMethod({dispatch,payload:{spares:[selectedSpare]},setIsLoading:setShowDeleteLoader,next:() => {
//       setShowDeleteDailog(false)  
//       globalStateOfChildData?.id && handleGetSparesOfAsset({assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination,});
//       handleShowErrorAndWarning({dispatch,message:"Spare deleted successfully.",type:"success",showTime:"5000"})
//       }})
//     }
    
//     const handlePrevious = () => {
//         setGlobalStateOfChildData(prev => ({...prev,spares:sparesData}));
//         setActiveStep(prev => prev - 1)
//     }

//     useEffect(() => {
//       if(globalStateOfChildData?.id && modeOfAsset === "edit") {
//         handleGetSparesOfAsset({dispatch,assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination});
//       }
//     },[])

//     return (
//       <>
//         <div className={Styles.a_c_spares_container}>
//           <div className={Styles.a_c_spares_header}>
//             <h4>Spares </h4>
//           </div>
//           <div className={Styles.a_c_spares_add_btn}>
//             <ClonosButton onClick={() => {
//               setShowSpareModal(true);
//               setMode("create")
//             }}>+ Add Spare</ClonosButton>
//           </div>
//           <div className={Styles.a_c_spares_datagrid_wrapper}>
//             <ClonosDataGrid
//               columns={sparesColumns}
//               rows={ sparesData?.data?.length ? sparesData?.data?.map((spare,index) => ({...spare,index:index+1})) : []}
//               checkboxSelection={false}
//               uniqueIdField={"id"}
//               totalCount={sparesData?.totalDataCount}
//               paginationMode={"server"}
//               onPageChange={(e) =>setPagination({ page: e.page + 1, limit: 15 }) }
//               pageLimit={pagination.limit}
//             />
//           </div>
//         </div>
//         {showSpareModal ? (
//           <UploadSpareModal mode={mode} spareId={selectedSpare?.id} isOpen={showSpareModal} closeMethod={setShowSpareModal} getFilledValue={handleSaveSpareDetails} saveLoader={saveLoader}/>
//         ) : (
//           <></>
//         )}
//         <StepController
//             mode={mode}
//             steps={steps}
//             // loading={isLoading}
//             handleBack={handlePrevious}
//             handleNext={() => Navigate("/assets")}
//             activeStep={activeStep}
//         />
//         {showDeleteDailog ? <ClonosConfirmationBox loading={showDeleteLoader} isOpen={showDeleteDailog} headerTitle={"Delete Spare"} message={"Are you sure you want to Delete?"} closeModalMethod={setShowDeleteDailog} confirmingMethod={handleRemoveSpare} /> : <></>}
//       </>
//     );
// }


import { useEffect, useState } from "react"
import Styles from "../../../ModuleStyles/Assets/assetSparesCreation.module.css"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { commonPageState, handleShowErrorAndWarning, setSerialNumber } from "../../../utils/clonosCommon"
import { UploadSpareModal } from "../../spares/components/upload-spare-modal/UploadSpareModal"
import CircleMinusIcon from "../../../resources/icons/static/CircleMinusIcon"
import EditInteractiveIcon from "../../../resources/icons/interactive/EditInteractiveIcon"
import { StepController } from "../Components/StepController/StepController"
import useToggler from "../../../CustomHooks/TogglerHook"
import CircleMinusInteractiveIcon from "../../../resources/icons/interactive/CircleMinusInteractiveIcon"
import { handleCreateMultipleSpares, handleGetSparesOfAsset } from "./asset-spares-manager"
import { getAllSparesList,handleGetSparesList, handleCreateSingleSpareMethod, handleCreateSpareHelper, handleDeleteSpareMethod, handleEditSpareMethod, handleGetChangedFielsOfSpare } from "../../spares/managers/spares-manager"
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { useDispatch } from "react-redux"
import { useLocation, useNavigate } from "react-router-dom"


export const CreateAndEditAssetSpare = ({setGlobalStateOfChildData, globalStateOfChildData, steps, activeStep, setActiveStep,modeOfAsset}) => {
    const dispatch = useDispatch();
    const Navigate = useNavigate();
    const [showSpareModal,setShowSpareModal] = useState(false);
    const [selectedSpare,setSelectedSpare] = useState({});
    const [mode,setMode] = useState(modeOfAsset)
    const [sparesData,setSparesData] = useState({});
    const [serverSpare,setServerSpare] = useState({});
    const [spareList,setSpareList]=useState({});
    const [isLoading,setIsLoading] = useToggler();
    const [showDeleteDailog,setShowDeleteDailog] = useState(false);
    const [showDeleteLoader,setShowDeleteLoader] = useToggler();
    const [saveLoader,setSaveLoader] = useToggler();
    const [pagination,setPagination] = useState(commonPageState)
    const LOCATION = useLocation();
    const [refreshapi,setRefreshApi]=useToggler()
    
    // const sparesColumns = [
    //     {
    //         field:"index",
    //         headerName:"SI.NO",
    //         hideable:false
    //     }, 
    //     {
    //         field:"name",
    //         headerName:"SPARE NAME",
    //         flex:1,
    //     },
    //     {
    //         field:"minimumSpareQuantity",
    //         headerName:"MINIMUM SPARE QUANTITY",
    //         flex:1,
    //         renderCell: (param) => {
    //             return <p>{param?.row?.quantity?.value}{" "}{param?.row?.quantity?.type}</p>
    //         }
    //     },
    //     {
    //         field:"cycleFrequency",
    //         headerName:"CYCLE FREQUENCY",
    //         flex:1,
    //         renderCell: (param) => {
    //             return <p>{param?.row?.cycleFrequency?.value}{" "}{param?.row?.cycleFrequency?.type}</p>
    //         }
    //     },
    //     {
    //         field:"replacementFrequency",
    //         headerName:"REPLACEMENT FREQUENCY",
    //         flex:1,
    //         renderCell: (param) => {
    //             return <p>{param?.row?.replacementFrequency?.value}{" "}{param?.row?.replacementFrequency?.type}</p>
    //         }
    //     },
    //     {
    //         field:"action",
    //         headerName:"ACTIONS",
    //         width:"200",
    //         renderCell: (param) => {
    //             return <div style={{display:"flex",gridGap:"2rem",alignItems:"center"}}>
    //                 <EditInteractiveIcon size="24" tooltipTitle={"Edit"}
    //                     onClick={() => {
    //                         setShowSpareModal(true);
    //                         setSelectedSpare(param?.row);
    //                         setMode("edit");
    //                     }}
    //                 />
    //                 <CircleMinusInteractiveIcon onClick={() => {
    //                   setShowDeleteDailog(true);
    //                   setSelectedSpare(param?.row?.id)
    //                 }}/>
    //             </div>
    //         }
    //     }
    // ]

     const sparesColumns = [
        {
          field: "index",
          headerName: "SI. NO",
          width: 80,
          headerAlign: "center",
          align: "center",
          hideable: false,
        },
        {
          field: "spare",
          headerName: "SPARE NAME",
          flex: 1,
          minWidth: 150,
          headerAlign: "left",
          align: "left",
          renderCell: ({ row }) => (
            
            <span>{row?.spare?.name} </span>
          ),
        },
        {
          field: "minimumRequiredQuantity",
          headerName: "MINIMUM REQUIRED QUANTITY",
          flex: 1,
          minWidth: 180,
          headerAlign: "center",
          align: "center",
          renderCell: ({ row }) => (
            
            <span>{row?.minimumRequiredQuantity} {row?.unit}</span>
          ),
        },
        {
          field: "cycleFrequency",
          headerName: "CYCLE FREQUENCY",
          flex: 1,
          minWidth: 160,
          headerAlign: "center",
          align: "center",
          
          renderCell: ({ row }) => (
            <span>
              {row?.cycleFrequency?.value || "-"}{" "}
              {row?.cycleFrequency?.type || ""}
            </span>
          ),
        },
        {
            field:"replacementFrequency",
            headerName:"REPLACEMENT FREQUENCY",
            flex:1,
            renderCell: ({row}) => {
                return <p>{row?.replacementFrequency?.value || '-'}{" "}{row?.replacementFrequency?.type ||''}</p>
            }
        },
        // {
        //   field: "status",
        //   headerName: "STATUS",
        //   flex: 1,
        //   minWidth: 190,
        //   headerAlign: "center",
        //   align: "center",
        //   // renderCell: ({ row }) => (
        //   //   <span>
        //   //     {row?.replacementFrequency || "-"}{" "}
        //   //     {row?.replacementFrequencyType || ""}
        //   //   </span>
        //   // ),
        // },
        {
          field: "action",
          headerName: "ACTIONS",
          width: 160,
          headerAlign: "center",
          align: "center",
          sortable: false,
          filterable: false,
          renderCell: ({ row }) => (
            <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
              <EditInteractiveIcon
                size="24"
                tooltipTitle="Edit"
                onClick={() => {
                  setShowSpareModal(true);
                  setSelectedSpare(row);
                  setMode("edit");
                }}
              />
              <CircleMinusInteractiveIcon
                tooltipTitle="Delete"
                onClick={() => {
                  setShowDeleteDailog(true);
                  setSelectedSpare(row?.id);
                }}
              />
            </div>
          ),
        },
      ];


     const handleSaveSpareDetails = (spareDetails) => {
     
       if(mode === "edit") {
         
        const requestPayload = handleGetChangedFielsOfSpare({lcSpare:spareDetails,serverSpare:selectedSpare});
       
        if(Object.keys(requestPayload)?.length === 0) {
          setShowSpareModal(false);
          return
        }

        globalStateOfChildData?.id && handleEditSpareMethod({dispatch,assetId:globalStateOfChildData?.id,spareId:spareDetails?.id  ,payload:{...requestPayload},setIsLoading,next:() => {
          setShowSpareModal(false);
          setRefreshApi()
          handleGetSparesOfAsset({dispatch,assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination,});
          handleShowErrorAndWarning({dispatch,message:"Spare updated successfully.",type:"success",showTime:"5000"})
        }})
        
       } else {
        globalStateOfChildData?.id && handleCreateSingleSpareMethod({payload:{...spareDetails,assetId:globalStateOfChildData?.id},setIsLoading:setSaveLoader,next:() => {
          setShowSpareModal(false);
          setRefreshApi()
          handleGetSparesOfAsset({dispatch,assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination,});
          handleShowErrorAndWarning({dispatch,message:"Spare create successfully.",type:"success",showTime:"5000"})
        }})
       }
    }

    const handleRemoveSpare = () => {
      handleDeleteSpareMethod({dispatch,payload:{assetSpareIds:[selectedSpare]} ,assetId:globalStateOfChildData?.id,setIsLoading:setShowDeleteLoader,next:() => {
      setShowDeleteDailog(false)  
      setRefreshApi()
      globalStateOfChildData?.id && handleGetSparesOfAsset({assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination,});
      handleShowErrorAndWarning({dispatch,message:"Spare deleted successfully.",type:"success",showTime:"5000"})
      }})
    }
    
    const handlePrevious = () => {
        setGlobalStateOfChildData(prev => ({...prev,spares:sparesData}));
        setActiveStep(prev => prev - 1)
    }

    useEffect(()=>{
       handleGetSparesList({dispatch,assetId:globalStateOfChildData?.id,setterMethod:setSpareList,setIsLoading,pagination})
    },[refreshapi,pagination?.page, pagination?.limit])

    // useEffect(() => {
    //   if(globalStateOfChildData?.id && modeOfAsset === "edit") {
    //     handleGetSparesOfAsset({dispatch,assetId:globalStateOfChildData?.id,setterMethod:setSparesData,setIsLoading,pagination});
    //   }
    // },[])

    return (
      <>
        <div className={Styles.a_c_spares_container}>
          <div className={Styles.a_c_spares_header}>
            <h4>Spares </h4>
          </div>
          <div className={Styles.a_c_spares_add_btn}>
            <ClonosButton onClick={() => {
              setShowSpareModal(true);
              setMode("create")
            }}>+ Link Spare</ClonosButton>
          </div>
          <div className={Styles.a_c_spares_datagrid_wrapper}>
            {/* <ClonosDataGrid
              columns={sparesColumns}
              rows={ sparesData?.data?.length ? sparesData?.data?.map((spare,index) => ({...spare,index:index+1})) : []}
              checkboxSelection={false}
              uniqueIdField={"id"}
              totalCount={sparesData?.totalDataCount}
              paginationMode={"server"}
              onPageChange={(e) =>setPagination({ page: e.page + 1, limit: 15 }) }
              pageLimit={pagination.limit}
            /> */}
            <ClonosDataGrid
              columns={sparesColumns}
              rows={ spareList?.data ? spareList?.data?.map((spare,index) => ({...spare,index:index+1})) : []}
              checkboxSelection={false}
              uniqueIdField={"id"}
              totalCount={spareList?.totalDataCount}
              paginationMode={"server"}
              onPageChange={(e) =>setPagination({ page: e.page + 1, limit: 15 }) }
              pageLimit={pagination.limit}
            />
          </div>
        </div>
        {showSpareModal ? (
          <UploadSpareModal mode={mode} selectedSpare={selectedSpare} assetId={LOCATION?.state?.id}  spareId={selectedSpare?.spare?.id} isOpen={showSpareModal} closeMethod={setShowSpareModal} getFilledValue={handleSaveSpareDetails} saveLoader={saveLoader}/>
        ) : (
          <></>
        )}
        <StepController
            mode={mode}
            steps={steps}
            // loading={isLoading}
            handleBack={handlePrevious}
            handleNext={() => Navigate("/assets")}
            activeStep={activeStep}
        />
        {showDeleteDailog ? <ClonosConfirmationBox loading={showDeleteLoader} isOpen={showDeleteDailog} headerTitle={"Delete Spare"} message={"Are you sure you want to Delete?"} closeModalMethod={setShowDeleteDailog} confirmingMethod={handleRemoveSpare} /> : <></>}
      </>
    );
}