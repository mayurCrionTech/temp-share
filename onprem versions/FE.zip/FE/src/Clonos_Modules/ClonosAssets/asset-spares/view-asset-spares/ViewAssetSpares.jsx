import { useEffect, useState } from "react"
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import useToggler from "../../../../CustomHooks/TogglerHook";
import { handleGetSparesOfAsset } from "../asset-spares-manager";
import { useNavigate } from "react-router-dom";

export const ViewAssetSpares = ({assetId}) => {
    const [spares,setSpares] = useState({});
    const [isLoading,setIsLoading] = useToggler();
    const [pagination,setPagination] = useState({page:1,limit:15});
    const navigate= useNavigate()

    const sparesColumns = [
        {
            field:"index",
            headerName:"SI.NO",
            hideable:false
        }, 
        {
        field: "name",
        headerName: "SPARE NAME",
        flex: 1,
        renderCell: (param) => {
        const name = param?.row?.spare?.name || "-";
        return (
            <p
            onClick={() => handleGotoSpareView(param?.row?.spare?.id, name, name)}
            style={{
                textDecoration: "none",
                color: "#3f51b5",
                cursor: "pointer",
                margin: 0,
                whiteSpace: "nowrap",
            }}
            >
            {name}
            </p>
        );
        },
        // renderCell: (param) => {
        //     const spareName = param?.row?.spare?.name;
        //     console.log(spareName,"spareName")
        //     return spareName ? (
        //     <div
        //         style={{ cursor: "pointer", color: "#0A5FFF" }}
        //         onClick={() =>
        //         navigate(`/view-spare/${spareName}`, {
        //             state: {
        //             id: param?.row?.id,
        //             parentId: "",
        //             // activePage,
        //             // limit,
        //             },
        //         })
        //         }
        //     >
        //         {spareName}
        //     </div>
        //     ) : (
        //     <div>-</div>
        //     );
        // },
        },

        // {
        //     field:"quantity",
        //     headerName:"QUANTITY",
        //     flex:1,
        //     renderCell: (param) => {
        //         return <p>{param?.row?.quantity?.value}{" "}{param?.row?.quantity?.type}</p>
        //     }
        // },
        {
            field:"minimumRequirement",
            headerName:"MINIMUM REQUIREMENT QTY",
            flex:1,
             headerAlign:"center",
            align:"center",
             renderCell: (param) => {
                return <p>{param?.row?.minimumRequiredQuantity || '-'}{" "} {param?.row?.unit}</p>
            }
        },
        {
            field:"replacementFrequency",
            headerName:"REPLACEMENT FREQUENCY",
            flex:1,
            headerAlign:"center",
            align:"center",
            renderCell: (param) => {
                return <p>{param?.row?.replacementFrequency?.value || '-'}{" "}{param?.row?.replacementFrequency?.type}</p>
            }
        },
        {
            field:"cycleFrequency",
            headerName:"CYCLE FREQUENCY",
            flex:1,
             headerAlign:"center",
            align:"center",
            renderCell: (param) => {
                return <p>{param?.row?.cycleFrequency?.value || '-' }{" "}{param?.row?.cycleFrequency?.type}</p>
            }
        },
        
    ]


     const handleGotoSpareView = (spareId, spareName, spareNameOrId) => {
        navigate(`/view-spare/${spareNameOrId}`, { state: { spareId, spareName } })
    }

    useEffect(() => {
        handleGetSparesOfAsset({assetId,setterMethod:setSpares,setIsLoading,pagination});
    },[pagination?.page])

    return <div style={{padding:"2rem 5rem",height:"90%"}}>
        <ClonosDataGrid
            loading={isLoading}
            columns={sparesColumns}
            rows={ spares?.data?.length ? spares?.data?.map((spare,index) => ({...spare,index:index+1})) : []}
            checkboxSelection={false}
            uniqueIdField={"id"}
            totalCount={spares?.totalDataCount}
            paginationMode={"server"}
            onPageChange={(e) =>setPagination({ page: e.page + 1, limit: 15 }) }
            pageLimit={pagination.limit}
          />
    </div>
}