
export const ASSET_STATIC_DATA = {
    runningMode : ["Rotating","Static"],
    criticalityLevel: ["Emergency","Critical","Normal"]
}

