import { checkUserHasPermission, handleShowErrorAndWarning, updateLayout } from "../../../utils/clonosCommon";
import { useDispatch, useSelector } from "react-redux";
import { getUser, loginJumpLoadingStopper } from "../../../utils/clonosCommon"
import useToggler from "../../../CustomHooks/TogglerHook"
import { useEffect, useState } from "react"
import { Card } from "@mui/material";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_ASSETS } from "../../../Constants/Constant";
import { AssetHorizontalStepper } from "../Components/Stepper/AssetHorizontalStepper";
import { ASSET_STEPPER_STEPS } from "../AssetConstants";
import { RenderAssetSteps } from "../RenderAssetSteps";
import { assetActions } from "../../../Store/Reducers/ClonosAssetReducer";
import { handleGetSingleAssetDetails } from "../managers/asset-common-managers";

const CreateAsset = () => {
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS)
  const [lsLocalLoading, setIsLocalLoading] = useToggler() 
  const logged_user = getUser();
  const dispatch = useDispatch();
  const { mainLayoutChildrenPositionsToolkitState } = useSelector((store) => store.globalEntitiesStateManagement);
  const [activeStep,setActiveStep] = useState(0);
  const [globalStateOfChildData,setGlobalStateOfChildData] = useState({}); 
  const [serverResponse,setServerResponse] = useState({});

  
  const generalDetailsAutoFillChanged= useSelector(
       (store) => store.assetData.generalDetailsAutoFillChanged
    )

// const selectedAutoFillAsset=useSelector(
//        (store) => store.assetData.selectedAutoFillAsset
//     )

//     console.log(selectedAutoFillAsset,"selectedAutoFillAsset")

 useEffect(() => {
  if (generalDetailsAutoFillChanged) {
    handleShowErrorAndWarning({
      dispatch,
      message: "General Details Changed",
      type: "warning",
      showTime: 5000
    });

    // ✅ RESET the flag so next changes can trigger the popup again
    // dispatch(assetActions.setGeneralDetailsAutoFillChanged(false));
  }
}, [generalDetailsAutoFillChanged]);

// useEffect(() => {
//   dispatch(assetActions.resetAssetState());
// }, []);


	if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}))
	return <Card variant="outlined" style={{ flex: 1, margin: "1rem", margin: "1rem", overflow: 'scroll' }} bodyStyle={{ height: "100%" }}>
		<div style={{ marginTop: "1rem" }}>
			<AssetHorizontalStepper steps={ASSET_STEPPER_STEPS} activeStep={activeStep} setActiveStep={setActiveStep} globalStateOfChildData={globalStateOfChildData} />
            <RenderAssetSteps
                changeIN={{}}
                mode={"create"}
                defaultData={{}}
                step={activeStep}
                steps={ASSET_STEPPER_STEPS}
                getChangedValues={() => {}}
                serverResponse={serverResponse}
                setServerResponse={setServerResponse}
                setActiveStep={setActiveStep}
                globalStateOfChildData={globalStateOfChildData}
                setGlobalStateOfChildData={setGlobalStateOfChildData}
            />
		</div>
	</Card>

	return <UnAuthorizedModal type="NOT_AUTHORIZED"/>
}

export default CreateAsset;
