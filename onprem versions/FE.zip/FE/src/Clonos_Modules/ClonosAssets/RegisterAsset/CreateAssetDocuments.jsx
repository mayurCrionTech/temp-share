import { DataGrid } from "@mui/x-data-grid";
import Styles from "../../../ModuleStyles/Assets/associatedDocs.module.css";
import { Box, Tooltip } from "@mui/material";
import { Delete } from "@material-ui/icons";
import REDTRASH from "../../../assets/UIUX/icons/redTrash.svg";
import { useState } from "react";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import { UploadDocumentModal } from "../Components/Documents/UploadDocumentsModal";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";

export const CreateAssetDocuments = ({ getData, data,errorhandlerObject }) => {
  const dispatch = useDispatch();
  const [showUploadModal, setShowUploadModal] = useState(false);
  const defaultColumns = [
    {
      field: "id",
      headerName: "SI.NO",
      width: 100,
      hideable:"false",
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => {
        return (
          <p>
            {val?.row?.index || "-"}
          </p>
        );
      },
    },
    {
      field: "documentNumber",
      headerName: "DOCUMENT NUMBER",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => {
        return (
          <p>
            {val?.row?.documentNumber || "-"}
          </p>
        );
      },
    },
    {
      field: "documentName",
      headerName: "DOCUMENT NAME",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => {
        return (
          <p>
            {val?.row?.documentName || "-"}
          </p>
        );
      },
    },
    {
      field: "documentType",
      headerName: "DOCUMENT TYPE",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => {
        return (
          <p>
            {val?.row?.documentType?.name || "-"}
          </p>
        );
      },
    },
    {
      field: "status",
      headerName: "DOCUMENT STATUS",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => {
        return (
          <p>
            {val?.row?.status?.name || "-"}
          </p>
        );
      },
    },
    {
      field: "revisionNumber",
      headerName: "REVISION NUMBER",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => {
        return (
          <p>
            {val?.row?.revisionNumber || "-"}
          </p>
        );
      },
    },
    {
      field: "viewDoc",
      headerName: "VIEW DOCUMENT",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => {
        return (
          <p
          style={{color: val?.row?.file?.name ? "#3f51b5" : "#000",textDecoration: val?.row?.fil?.name ? "underline" : "none",cursor:"pointer"}}
          onClick={() => {val?.row?.file?.name && window.open(URL.createObjectURL(val?.row?.file), '_blank')}}
          >
            {val?.row?.file?.name || "-"}
          </p>
        );
      },
    },
    {
      field: "action",
      headerName: "ACTION",
      flex: 1,
      headerClassName: "asso_doc_text_content",
      renderCell: (val) => (
        <p
          onClick={() => {
            getSelectedRow({ ...val.row }, setSelectedRow);
            setShowUploadModal(true);
          }}
          style={{color: val?.row?.file?.name ? "#3f51b5" : "#000",textDecoration: val?.row?.file?.name ? "underline" : "none",cursor:"pointer"}}
        >
          {val?.row?.file ? "EDIT" : "UPLOAD"}
        </p>
      ),
    },
  ];
  const [rows, setRows] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [pagination,setPagination] = useState({page:1,limit:5})
  const getSelectedRow = (val, setSelectedRow) => {
    setSelectedRow({ ...val });
  };

  const getDocumentData = (val) => {
   
    let documents = [];
    if(val?.isNewAdded){
      let isDocumentPresent = false;
      documents = rows?.length ? rows?.map((doc) => {
        if(doc?.id === val?.id){
          isDocumentPresent = true;
          return val
        } else {
          return doc
        }
      }) : [val]
      if(!isDocumentPresent && rows?.length) documents.push(val)
    } else {
      documents = rows?.map((doc) => {
        if (doc.id === val.id) {
          return val;
        } else {
          return doc;
        }
      });
    }
    setRows([...documents]);
    getData({ ...data, documents });
  };

  const handleCloseModal = () => {
    setShowUploadModal(false);
    setSelectedRow(null);
  };
  useEffect(() => {
    setRows(data?.documents);
  }, []);
  return (
    <>
      <div className={Styles.associatedDocsContainer}>
        <div className={Styles.associatedDocsSubContainer}>
          <div className={Styles.addRowContainer}>
          <ClonosButton onClick={() => setShowUploadModal(true)}>+ Add Document</ClonosButton>
        </div>
          <div className={Styles.datagridContainer}>
              <Box sx={{height:"100%",width: "100%" }}>
              <ClonosDataGrid
                rows={rows?.map((a,i) => ({...a,index:i+1})) || []}
                columns={defaultColumns}
                autoPageSize={true}
                checkboxSelection={false}
                disableRowSelectionOnClick
                uniqueIdField={"id"}
              />
            </Box>
          </div>
        </div>
      </div>
      <UploadDocumentModal
        open={showUploadModal}
        data={selectedRow === null ? {isNewAdded:true} : selectedRow}
        closeModalMethod={handleCloseModal}
        getDocumentData={getDocumentData}
        getData={getData}
        errorhandlerObject={errorhandlerObject}
      />
    </>
  );
};
