import { useEffect, useState } from "react";
import Styles from "../Style/generalDetails.module.css";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import useToggler from "../../../CustomHooks/TogglerHook";
import { Plant3DLibraryModal } from "../../Plant3D/Plant3DLibraryModal/Plant3DLibraryModal";
import { LinkIcon } from "../../../assets/Clonos Common Indicators/Icon_Components/LinkIcon";
import { ClonosDropdownButton } from "../../../components/CommonComponents/ClonosDropdownButton/ClonosDropdownButton";
import { AddFrom3DLibraryModal } from "../../Plant3D/components/AddFrom3DLibrary/AddFrom3DLibraryModal";
import { getStandard3DOjectsMethod, getUserUploaded3DOjectsMethod } from "../../../utils/Plant3DMethods/Plant3DMethods";
import { useDispatch } from "react-redux";

export const Create3DDetails = ({ getData, data }) => {
  const dispatch = useDispatch();
  const [pagination,setPagination] = useState({limit:15,page:1})
  const [formData, setFormData] = useState({ ...data });
  const [showPlant3DLibrary,setShowPlant3DLibrary] = useToggler();
  const [showUserUploadedLibraryModal,setShowUserUploadedLibraryModal] = useState(false);
  const [showStandardLibraryModal,setShowStandardLibraryModal] = useState(false);
  const [all3DObjects,setAll3DObjects] = useState({userUploaded:[],standard:[]})
  const AddFrom3DLibraryDropdownList = [
    {id:1,title:"User Uploaded",onClickMethod:() => setShowUserUploadedLibraryModal(true)},
    {id:2,title:"Standard",onClickMethod:() => setShowStandardLibraryModal(true)}
  ]

  const handleGetValues = (props) => {
    const { name, selectedOption, updatedValue, uniqueKey, type } = props;
    if(type === "text" || type === "number"){
      setFormData((prev) => {
        let asset3DmodelPosition = prev?.asset3DmodelPosition || {};
        let asset3DmodelRotation = prev?.asset3DmodelRotation || {}
        if(uniqueKey === "asset3DmodelPositionX"){
          asset3DmodelPosition.x = updatedValue;
          let temp = {...prev,asset3DmodelPosition }
          getData(temp)
          return temp
        } else if (uniqueKey === "asset3DmodelPositionY"){
          asset3DmodelPosition.y = updatedValue;
          let temp = {...prev,asset3DmodelPosition }
          getData(temp)
          return temp
        } else if(uniqueKey === "asset3DmodelPositionZ") {
          asset3DmodelPosition.z = updatedValue;
          let temp = {...prev,asset3DmodelPosition }
          getData(temp)
          return temp
        } else if(uniqueKey === "asset3DmodelRotationX") {
          asset3DmodelRotation.x = updatedValue;
          let temp = {...prev,asset3DmodelRotation }
          getData(temp)
          return temp
        } else  if (uniqueKey === "asset3DmodelRotationY") {
          asset3DmodelRotation.y = updatedValue;
          let temp = {...prev,asset3DmodelRotation }
          getData(temp)
          return temp
        } else if (uniqueKey === "asset3DmodelRotationZ") {
          asset3DmodelRotation.z = updatedValue;
          let temp = {...prev,asset3DmodelRotation }
          getData(temp)
          return temp
        }
        
      })
    }
  };

  const getFileFrom3DLibrary = (val) => {
    setFormData((prev) => {
      let temp = {...prev,asset3DModel:val?.model?.model3d,assetLayoutImage:val?.model?.model2d}
      getData(temp)
      return temp
    })
    if(val?.name === "User Uploaded") setShowUserUploadedLibraryModal(false) 
    if(val?.name === "Standard") setShowStandardLibraryModal(false)
  }


  const handleGetUploadedfile = (val) => {
    const {uniqueKey,files,type} = val
    if (uniqueKey === "asset3DModal") {
      if (val?.files?.length > 0) {
        setFormData((prev) => {
          let temp = {
            ...prev,
            asset3DModel: val.files[0]
          }
          getData(temp);
          return temp
        })
      } else {
        delete formData.asset3DModel
        setFormData({ ...formData })
        getData({ ...formData })
      }
    }
    if (uniqueKey === "assetLayoutImage") {
      if (val?.files?.length > 0) {
        setFormData((prev) => {
          let temp = {
            ...prev,
            assetLayoutImage: val.files[0]
          }
          getData(temp);
          return temp
        })
      } else {
        delete formData.assetLayoutImage
        setFormData({ ...formData })
        getData({ ...formData })
      }
    }
  }

  const getFileFromPlant3DLibrary = (val) => {
    setFormData((prev) => {
      let temp = {...prev,asset3DmodelRotation:val?.rotation,asset3DmodelPosition:val?.position,intractability:val?.intractability?.id,asset3DModel:val?.model?.model3d,assetLayoutImage:val?.model?.model2d}
      getData(temp)
      return temp
    })
  }


  useEffect(() => {
    const fetchData = async () => {
        const userUploadedRes = await getUserUploaded3DOjectsMethod({dispatch, pagination});
        if (userUploadedRes?.data?.length) {
            setAll3DObjects(prev => ({...prev, userUploaded: userUploadedRes?.data}));
        }

        const standardRes = await getStandard3DOjectsMethod({dispatch, pagination});
        if (standardRes?.data?.length) {
            setAll3DObjects(prev => ({...prev, standard: standardRes?.data}));
        }
    };

    fetchData();
},[]);


  return (
    <>
    <div className={Styles.asset3DDetailsContainer}>
          <div className={Styles.asset3DDetailsLeftContainer}>
            <div className={Styles.btn_wrapper1}>
              <div onClick={() => setShowPlant3DLibrary()}> <span><LinkIcon/></span> Link data from Plant 3D</div>
            </div>
            <div className={Styles.locDetailsContainer}>
                <ClonosSelect
                  isLabel={true}
                  label="Intractability"
                  isMandatory={true}
                  placeholder="Select"
                />
                <div>
                  <label className={Styles.clonosLabelStyle}>Position</label>
                  <div className={Styles.geoLocation}>
                    <ClonosInput
                      type="number"
                      isLabel={true}
                      label={"X"}
                      value={formData?.asset3DmodelPosition?.x}
                      placeholder="x"
                      uniqueKey="asset3DmodelPositionX"
                      handleGetValues={handleGetValues}
                    />
                    <ClonosInput
                      type="number"
                      isLabel={true}
                      label={"Y"}
                      value={formData?.asset3DmodelPosition?.y}
                      uniqueKey="asset3DmodelPositionY"
                      placeholder="y"
                      handleGetValues={handleGetValues}
                    />
                    <ClonosInput
                      type="number"
                      isLabel={true}
                      label={"Z"}
                      value={formData?.asset3DmodelPosition?.z}
                      uniqueKey="asset3DmodelPositionZ"
                      placeholder="z"
                      handleGetValues={handleGetValues}
                    />
                  </div>
                </div>
                <div>
                  <label className={Styles.clonosLabelStyle}>Rotation (Degree)</label>
                  <div className={Styles.geoLocation}>
                    <ClonosInput
                      type="number"
                      isLabel={true}
                      label={"X"}
                      value={formData?.asset3DmodelRotation?.x}
                      placeholder="x"
                      uniqueKey="asset3DmodelRotationX"
                      handleGetValues={handleGetValues}
                    />
                    <ClonosInput
                      type="number"
                      isLabel={true}
                      label={"Y"}
                      value={formData?.asset3DmodelRotation?.y}
                      uniqueKey="asset3DmodelRotationY"
                      placeholder="y"
                      handleGetValues={handleGetValues}
                    />
                      <ClonosInput
                      type="number"
                      isLabel={true}
                      label={"Z"}
                      value={formData?.asset3DmodelRotation?.z}
                      uniqueKey="asset3DmodelRotationZ"
                      placeholder="z"
                      handleGetValues={handleGetValues}
                    />
                  </div>
                </div>
            </div>
          </div>
          <div className={Styles.asset3DDetailsRightContainer}>
            <div className={Styles.btn_wrapper2}>
              <ClonosDropdownButton buttonTitle={"+ Add From Library"} dropdownItems={AddFrom3DLibraryDropdownList}/>
            </div>
            <div className={Styles.asset3DFilesWrapper}>
            <div className={Styles.file_uploader_wrapper}>
              <FileUploader label={"3D Model"} uniqueKey={"asset3DModal"} typeOfRecord={"Image"} isMandatory={false} limit={1} acceptableFileTypes={[".fbx"]} fileSizeInMB={10} localPreviousPageFiles={formData?.asset3DModel ? [formData?.asset3DModel] : []} handleGetSelectedData={(value) => handleGetUploadedfile(value)} />
            </div>
            <div>
              <FileUploader label={"Layout Image"} uniqueKey={"assetLayoutImage"} typeOfRecord={"Image"} isMandatory={false} limit={1} acceptableFileTypes={[".png", ".jpg", ".jpeg"]} fileSizeInMB={10} localPreviousPageFiles={formData?.assetLayoutImage ? [formData?.assetLayoutImage] : []} handleGetSelectedData={(value) => handleGetUploadedfile(value)} />
            </div>
            </div>
          </div>
    </div>
        <Plant3DLibraryModal isOpen={showPlant3DLibrary} closeMethod={setShowPlant3DLibrary} getSelectedValue={getFileFromPlant3DLibrary} />
        <AddFrom3DLibraryModal isOpen={showUserUploadedLibraryModal} closeMethod={setShowUserUploadedLibraryModal} getUploadedValue={getFileFrom3DLibrary} data={all3DObjects?.userUploaded} type={'User Uploaded'}/>
        <AddFrom3DLibraryModal isOpen={showStandardLibraryModal} closeMethod={setShowStandardLibraryModal} getUploadedValue={getFileFrom3DLibrary} data={all3DObjects?.standard} type={'Standard'}/>
    </>)
};