import { Card } from "@mui/material";
import { AssetHorizontalStepper } from "../Components/Stepper/AssetHorizontalStepper";
import { useDispatch } from "react-redux";
import { checkUserHasPermission, getUser } from "../../../utils/clonosCommon";
import { handleGetSingleAssetDetails } from "../managers/asset-common-managers";
import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import useToggler from "../../../CustomHooks/TogglerHook";
import { RenderAssetSteps } from "../RenderAssetSteps";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { ASSET_STEPPER_STEPS } from "../AssetConstants";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_ASSETS } from "../../../Constants/Constant";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";


const EditAsset = () => {
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_ASSETS)
  const logged_user = getUser();
  const Location = useLocation();
  const dispatch = useDispatch();
  const [activeStep,setActiveStep] = useState(0);
  const [isLoading,setIsLoading] = useToggler();
  const [changedData,setChangedData] = useState({});
  const [globalStateOfChildData,setGlobalStateOfChildData] = useState({}); 
  const [serverResponse,setServerResponse] = useState({});
    useEffect(() => {
        handleGetSingleAssetDetails({assetId:Location?.state?.id,setterMethod:setGlobalStateOfChildData,setIsLoading,setServerResponse})
    }, []);


	if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}))
	return <Card variant="outlined" style={{ flex: 1, margin: "1rem", margin: "1rem", overflow: 'scroll' }} bodyStyle={{ height: "100%" }}>
		<div style={{ marginTop: "1rem",height:"100%" }}>
			{
                isLoading ? <div className="center_wrapper"><ClonosSpinner/></div> : <>
                    <AssetHorizontalStepper steps={ASSET_STEPPER_STEPS} activeStep={activeStep} setActiveStep={setActiveStep} globalStateOfChildData={globalStateOfChildData} />
                    <RenderAssetSteps
                        mode={"edit"}
                        changedData={{}}
                        defaultData={{}}
                        step={activeStep}
                        steps={ASSET_STEPPER_STEPS}
                        setActiveStep={setActiveStep}
                        setChangedData={setChangedData}
                        serverResponse={serverResponse}
                        setServerResponse={setServerResponse}
                        globalStateOfChildData={globalStateOfChildData}
                        setGlobalStateOfChildData={setGlobalStateOfChildData}
                    />
                </>
            }
		</div>
	</Card>

	return <UnAuthorizedModal type="NOT_AUTHORIZED"/>
}

export default EditAsset;
