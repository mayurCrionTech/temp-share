import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import AppUrl from "../../../utils/AppUrl";
import { doDeleteApiCall, doGetApiCall, doPatchApiCall, doPutApiCall } from "../../../utils/ClonosApi";
import { debounce, handleClientDateInConfiguredTimeZone, handleShowErrorAndWarning, modifyString } from "../../../utils/clonosCommon";
import { handleCheckUniqueFieldsMethod } from "../../../utils/common-managers";
import { handleShouldWarningModalOpen } from "../../../utils/UsersMethods/usersMethods";
import { CalibrationDetails } from "../Specifications/calibration-details/CalibrationDetails";
import { WarrantyDetails } from "../Specifications/warranty-details/WarrantyDetails";

export const updateLocalAndParentState = ({ uniqueKey, value, setFormData, }) => {
    // setFormData((prev) => {
    //   let temp = {...prev, generalDetails:{...prev?.generalDetails,[uniqueKey]:value}}
    //   if(uniqueKey === "assetCategory"){
    //     // setIsCategorySelected(true)
    //   }
    //   getData(temp)
    //   return temp
    // })
}


// TO GET DROPDOWN ENUMS 
export const handleGetAssetEnums = ({ setterMethod, moduleName, enumTypeEndPoint }) => {
    const url = `/assets/enums/${moduleName}/${enumTypeEndPoint}`
    doGetApiCall({ url }).then((res) => {
        if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result);
        }
    }).catch((err) => console.error(err))
}

//  TO CHECK THE UNIQUNESS OF FIELD
const uniqueFieldHandler = ({ module, mode, fieldName, fieldValue, primaryObject, handlePrimaryObjectModifier, setFormData, setChangedData }) => {
    handleCheckUniqueFieldsMethod({ module, fieldName, fieldValue }).then((res) => {
        if (res === "unique") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
            setFormData((prev) => {
                return { ...prev, [fieldName]: fieldValue }
            })
            if (mode === "edit") setChangedData((prev) => ({ ...prev, [fieldName]: fieldValue }))
        } else if (res === "not_unique") {
            primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
            primaryObject?.[fieldName]?.errorActivatorMethod(true);
            primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${modifyString(fieldName, "spacecase")}.`)
        }
    })
}


export const debouncedCheckUniquenessOfAssetFields = debounce(uniqueFieldHandler, 500);


export const handleGetSingleAssetDetails = ({ assetId, setterMethod, setIsLoading,setServerResponse }) => {
    setIsLoading(false)
    doGetApiCall({ url: `/assets/${assetId}` })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                const data = res?.data?.result;
                const tempData = { 
                    ...data, 
                    status: modifyString(data?.status, "camelcase"),
                    generalDetails: { 
                        ...data?.generalDetails,
                        nameFromServer: data?.generalDetails?.name,
                        numberFromServer: data?.generalDetails?.number,
                        censusNumberFromServer: data?.generalDetails?.censusNumber
                    },
                    specifications: {
                        ...data?.specifications,
                        manufacturingDetails:{
                            ...data?.specifications?.manufacturingDetails,
                            installationDate:handleClientDateInConfiguredTimeZone({dateString:data?.specifications?.manufacturingDetails.installationDate,parseType:"string"})
                        },
                        calibrationDetails:{
                            ...data?.specifications?.calibrationDetails,
                            lastCalibrationDate:handleClientDateInConfiguredTimeZone({dateString:data?.specifications?.calibrationDetails?.lastCalibrationDate,parseType:"string"}),
                            corrosionCheckDate:handleClientDateInConfiguredTimeZone({dateString:data?.specifications?.calibrationDetails?.corrosionCheckDate,parseType:"string"}),
                            lastAuditDate:handleClientDateInConfiguredTimeZone({dateString:data?.specifications?.calibrationDetails?.lastAuditDate,parseType:"string"})
                        },
                        warrantyDetails:{
                            ...data?.specifications?.warrantyDetails,
                            warrantyEndDate:handleClientDateInConfiguredTimeZone({dateString:data?.specifications?.warrantyDetails?.warrantyEndDate,parseType:"string"})
                        }
                    },
                    createdAt:handleClientDateInConfiguredTimeZone({dateString:data?.createdAt,parseType:"string"}),
                    updatedAt:handleClientDateInConfiguredTimeZone({dateString:data?.updatedAt,parseType:"string"})
                }
                setterMethod(tempData);
                setServerResponse && setServerResponse(tempData);
            }
        })
        .catch((err) => console.error(err))
        .finally(() => setIsLoading(false))
}

 export const handleGetHierarchyDetails =({assetId, setterMethod, setIsLoading,setServerResponse})=>{
    setIsLoading(false)
    doGetApiCall({url:`/assets/${assetId}/hierarchy`}).then((res)=>{
        if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
           
            const result = res?.data?.result
            setterMethod(result)
            // setServerResponse(result)
        }

    })
    .catch((err) => console.error(err))
    .finally(() => setIsLoading(false))
 }
export const handleUpdateAssetDetails = ({ id, payload, setIsLoading, next }) => {

    const url = `/assets/${id}`;
    setIsLoading();
    doPutApiCall({ url, payload })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
                if (next) next()
            }
        })
        .catch((err) => console.error(err))
        .finally(() => setIsLoading())
}


// export const modifyAssetResponse = ({data}) => {
//     const geneneralDetails = data?.geneneralDetails || {};
//     const specifications = data?.specifications || {};
//     const manufacturingDetails = specifications?.manufacturingDetails || {};
//     const hazardousAreaDetails = specifications?.hazardousAreaDetails || {};
//     const calibrationDetails = specifications?.calibrationDetails || {};
//     const warrantyDetails = specifications?.warrantyDetails || {};
//     return {...geneneralDetails,}
// }

export const handleDeleteAsset = ({ payload, setIsLoading, next, dispatch }) => {
    doDeleteApiCall({ url: AppUrl.deleteAssets, payload: {assets:payload} })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
                handleShowErrorAndWarning({ dispatch, message: "Asset deleted successfully.", type: 'success', showTime: '5000' });
                next && next()
            }
        })
}   


export const handleIsAssetEdited = ({serverResponse,changedData,assetModule}) => {
    if(!Object?.keys?.(changedData)?.length) return false;
    let isAssetEdited = false;
    if(assetModule === 'generalDetails') {
        const fieldsToCompare = ["name","description","businessUnit","department","runningMode","criticalityLevel","functionalArea"];
        fieldsToCompare.forEach((field,index) => {
            if((changedData?.[field] || changedData?.[field]?.name) && changedData?.[field] !== serverResponse?.[field] || changedData?.[field]?.name !== serverResponse?.[field]?.name){
                isAssetEdited = true;
                // return;
            }
        })
    } else if(assetModule === "specifications"){
        for(let key in changedData){
            if(key === "manufacturingDetails") {
                const fieldsToCompare = ["type","make","make","model","serialNumber","manufacturer","installationDate","serviceLiquid"];
                fieldsToCompare.forEach((field) => {
                    if(field === "hazardousAreaDetails") {
                    } else {
                        if(changedData?.[key]?.[field] && changedData?.[key]?.[field] !== serverResponse?.[field]){
                            isAssetEdited = true;
                        }
                    }
                })
            } else if(key === "calibrationDetails") {
                
                const fieldsToCompare = ["lastCalibrationDate","calibrationCycle","corrosionCheckDate","corrosionCycle","designThickness","allowableThickness","meanTimeToRepair","lastAuditDate","meanTimeBetweenFailures"];
                fieldsToCompare.forEach((field) => {
                    if(typeof changedData?.[key]?.[field] === "object"){
                        if(changedData?.[key]?.[field]?.type && (changedData?.[key]?.[field]?.type !== serverResponse?.[key]?.[field]?.type)){
                            isAssetEdited = true;
                        }
                        if(changedData?.[key]?.[field]?.value && (changedData?.[key]?.[field]?.value !== serverResponse?.[key]?.[field]?.value)){
                            isAssetEdited = true;
                        }
                    } else {
                        if(changedData?.[key]?.[field] && (changedData?.[key]?.[field] !== serverResponse?.[key]?.[field])){
                            isAssetEdited = true;
                        }
                    }
                })
            } else if(key === "warrantyDetails") {
                const fieldsToCompare = ["isWarrantyIncluded","supplierName","supplierEmail","warrantyEndDate","warrantyPeriod","termsAndConditions"];
                fieldsToCompare.forEach((field) => {
                    if(typeof changedData[field] === "object"){
                        if(changedData?.[key]?.[field]?.type && (changedData?.[key]?.[field]?.type !== serverResponse?.[key]?.[field]?.type)){
                            isAssetEdited = true;
                        }
                        if(changedData?.[key]?.[field]?.value && (changedData?.[key]?.[field]?.value !== serverResponse?.[key]?.[field]?.value)){
                            isAssetEdited = true;
                        } 
                       
                        if(field === "termsAndConditions" && changedData?.[key]?.[field]?.id) {
                          
                            if(changedData?.[key]?.[field]?.id !== serverResponse?.[key]?.[field]?.id) isAssetEdited = true;
                        }
                    } else {
                        if(field === "isWarrantyIncluded") {
                            if(changedData?.[key]?.[field] !== serverResponse?.[key]?.[field]) {
                                isAssetEdited = true;
                            }
                        } else {
                            if(changedData?.[key]?.[field] && (changedData?.[key]?.[field] !== serverResponse?.[key]?.[field])){
                                isAssetEdited = true;
                            }
                        }
                    }
                })
            } else if(key === "hazardousAreaDetails") {
                const fieldsToCompare = ["gasGroup","temperatureClassification","zoneClassification"];
                fieldsToCompare.forEach((field) => {
                    if(changedData?.[key]?.[field] && (changedData?.[key]?.[field] !== serverResponse?.[key]?.[field])){
                        isAssetEdited = true;
                    }
                })
            }
        } 
    }
    // for (let key in changedData) {
    //     // Check if the value is an object, and recursively check
    //     if (typeof changedData[key] === 'object' && changedData[key] !== null) {
    //       if (handleIsAssetEdited(changedData[key], serverResponse[key])) {
    //         return true;
    //       }
    //     } else {
    //       // Check if the value is different from serverResponse
    //       if (changedData[key] !== serverResponse[key]) {
    //         return true;
    //       }
    //     }
    //   }
    //   return false;
    return isAssetEdited
}


export const handleChangeAssetStatus = async ({statusToChange,id,setIsLoading}) => {
    try {
        const url = `assets/${id}/updateStatus`;
        setIsLoading();
        const response = await doPatchApiCall({url,payload:{status:statusToChange}});
        if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            return true
        }
    } catch (error) {
        console.error(error)
    } finally {
        setIsLoading()
    }
}

export const handleGetAssetDropdownData = ({setterMethod,setIsLoading,filterPayload}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:AppUrl.getAssets,params:{...(filterPayload || {})}})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const data = {...(res?.data?.result || {}),data:res?.data?.result?.data?.map(asset => ({id:asset?.id,name:asset?.generalDetails?.name,number:asset?.generalDetails?.number}))}
            setterMethod((prev) => {
                if(filterPayload?.name) {
                    return data
                } else {
                    const prevData = prev?.data?.length ? [...prev?.data] : [];
                    if (prevData?.length) {
                        const uniqueEntitiesObject = prevData.reduce((acc, entity) => {
                            if (!acc[entity?.name]) {
                                acc[entity?.name] = entity;
                            }
                            return acc;
                        }, {});

                        const newEntities = data?.data?.filter(entity => !uniqueEntitiesObject[entity?.name]);

                        return {
                            ...data,
                            data: [...prevData, ...newEntities]
                        };
                    } else {
                        return data;
                    }
                }
            })
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading()
    })
}

/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/
// export const handleGetNewAssetDropDown = ({ setterMethod, moduleName, enumTypeEndPoint }) => {
//     // const url = `/assets/enums/${moduleName}/${enumTypeEndPoint}`
//     doGetApiCall({ url:'/dropdowns' }).then((res) => {
//         if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
//             console.log(res,"newassetdrops")
//             setterMethod(res?.data?.result);
//         }
//     }).catch((err) => console.error(err))
// }