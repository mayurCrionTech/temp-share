import ClonosSkeletonLoading from "../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

export const optionalParamsForSingleAsset = {
  assetMode: 1,
  runningMode: 1,
  assetImages: 1,
  // assetType : 1,
  assetDepartment: 1,
  assetCategory: 1,
  criticalityLevel: 1,
  functionalArea: 1,
  location: 1,
  geoLocation: 1,
  assetOwner: 1,
  assetLayoutImage: 1,
  asset3DModel: 1,
  parentAsset: 1,
  assetTermsAndConditions: 1,
  hazardousAreaDetails: 1,
  assetParameters: 1,
};

export const specialCharacters = [""]


export const assetStatusWithColors = {
  active:{background:"#EBFAEC",fontColor:"#60D468"},
  standBy:{background:"#FCF8EA",fontColor:"#E5B82F"},
  underMaintenance:{background:"#FBEDEF",fontColor:"#D24B5A"},
  breakDown:{background:"#FBEDEF",fontColor:"#D24B5A"},
  decommissioned:{background:"#FBEDEF",fontColor:"#D24B5A"},
}

export  const ASSET_STEPPER_STEPS = ["General Details","Specifications","Location & Hierarchy","Documents","Parameters","Spares"]

export const VIEW_ASSET_COMMON_NAVIGATORS_VALUES = [
  { value: "Details", status: true,visibility:true },
  // { value: "Reference Manuals", status: false,visibility:false },
  // { value: "3D", status: false,visibility:false },
  { value: "History", status: false,visibility:true },
  // { value: "Performance Data", status: false,visibility:false },
  { value: "Spares", status: false,visibility:true },
  { value: "Documents", status: false,visibility:true},
  { value: "Parameters", status: false,visibility:true},
  { value: "Maintenance Plan", status: false,visibility:true },
]