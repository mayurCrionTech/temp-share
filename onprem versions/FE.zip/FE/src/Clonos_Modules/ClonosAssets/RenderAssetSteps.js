import React from "react";
import { EditAssetLocationAndHierarchy } from "../Assets/EditAsset/EditAssetLocationAndHierarchy";
import { Edit3DDetails } from "./EditAsset/Edit3DDetails";
import EditParameters from "./EditAsset/EditParameters";
import EditReferenceManuals from "./EditAsset/EditReferenceManuals";
import { Create3DDetails } from "./RegisterAsset/Create3DDetails";
import CreateParameters from "./RegisterAsset/CreateParameters";
import CreateReferenceManuals from "./RegisterAsset/CreateReferenceManuals";
import GeneralDetails from "./general-details/GeneralDetails";
import { Specifications } from "./Specifications/Specifications";
import { LocationAndHierarchy } from "./location-and-hierarchy/LocationAndHierarchy";
import AssetParameters from "./asset-parameters/AssetParameters";
import { CreateAndEditAssetSpare } from "./asset-spares/CreateAndEditAssetSpare";
import { AssetDocuments } from "./asset-documents/AssetDocuments";



/** 
  @param {Object} props - The properties object.
 * @param {number} props.step - The current step in the asset editing/registration process. Determines which component to render.
 * @param {number} props.steps - All steps
 * @param {Object} props.formData - global state to hanlde data of all steps.
 * @param {function} props.getChildData - Callback function to retrieve data from the child component.
 * @param {function} props.changeIN - global state to handle store changes values while editing process.
 * @param {Object} props.defaultData - The default data for the form inputs. Used to initialize the form with pre-existing data or default values.
 * @param {function} props.getChangedValues - Function to get the changed values in the form. Tracks which values have been modified from their original state.
 * @param {Object} props.errorhandlerObject - Object containing error handling logic and messages. Manages and displays form validation errors.
 * 
 * @returns {React.Element} The rendered component corresponding to the current step, with the appropriate props.
*/


export const RenderAssetSteps = ({ mode,step,steps, globalStateOfChildData,setActiveStep, setGlobalStateOfChildData, changeIN, defaultData, getChangedValues,serverResponse,setServerResponse }) => {
    const editAssetcomponents = [
      <GeneralDetails mode={mode} />,
      <Specifications mode={mode} />,
      <LocationAndHierarchy mode={mode}/>,
      <AssetDocuments modeOfAsset={"edit"} assetDetails={{id:globalStateOfChildData?.id,category:globalStateOfChildData?.generalDetails?.category?.id,number:globalStateOfChildData?.generalDetails?.number}}/>,
      // <Edit3DDetails />,
      // <EditAssetDocuments />,
      <AssetParameters modeOfAsset={"edit"} assetDetails={{id:globalStateOfChildData?.id}}/>,
      <CreateAndEditAssetSpare modeOfAsset={"edit"} />
    ];
    const createAssetComponents = [
      <GeneralDetails/>,
      <Specifications/>,
      <LocationAndHierarchy/>,
      // <Create3DDetails/>,
      <AssetDocuments modeOfAsset={"create"} assetDetails={{id:globalStateOfChildData?.id,category:globalStateOfChildData?.generalDetails?.category?.id,number:globalStateOfChildData?.generalDetails?.number}}/>,
      <AssetParameters modeOfAsset={"create"} assetDetails={{id:globalStateOfChildData?.id}}/>,
      <CreateAndEditAssetSpare modeOfAsset={"create"}/>
    ]  

    const components = mode === "create" ? createAssetComponents : mode === "edit" ? editAssetcomponents : [];
  
    return components[step] && React.cloneElement(components[step], {
      steps:steps,
      activeStep:step,
      changedData: changeIN,
      defaultData: defaultData,
      setActiveStep:setActiveStep,
      getChangedValues: getChangedValues,
      serverResponse:serverResponse,
      setServerResponse:setServerResponse,
      globalStateOfChildData: globalStateOfChildData,
      setGlobalStateOfChildData: setGlobalStateOfChildData,
    });
  };