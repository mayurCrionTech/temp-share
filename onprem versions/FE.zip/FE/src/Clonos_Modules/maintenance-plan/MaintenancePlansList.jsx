// import { Card } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
// import React, { useEffect, useState } from 'react'
// import AppUrl from '../../utils/AppUrl';
// import { useDispatch } from "react-redux";
// import { checkUserHasPermission, commonPageState, getYYYYMMDD_Format, handleShowErrorAndWarning, hasPermission, setSerialNumber } from '../../utils/clonosCommon';
// import { doGetApiCall } from '../../utils/ClonosApi';
// import ClonosDataGrid from '../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
// import ClonosGridNav from '../../utils/ClonosGridNav';
// import useToggler from '../../CustomHooks/TogglerHook';
// import { AllChecklists, Checks, PendingForApproval } from '../../assets/UIUX/icons/Checklist/Checklist';
// import { ClonosButton } from '../../components/CommonComponents/Button/Button';
// import CommonNavigator from '../../components/CommonComponents/Navigator/Navigator';
// import ClonosConfirmationBox from '../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
// import { getMaintenanceTasksListMethod, handleDeleteMaintenanceTask } from '../../utils/ScheduleMaintenanceMethods/ScheduleMaintenanceMethods';
// import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_MAINTENANCE_PLANS } from '../../Constants/Constant';
// import { UnAuthorizedModal } from '../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal';
// import useModuleNameProvider from '../../CustomHooks/ModuleNameProviderHook';
// import { statusStaticData, statusStyleStaticData } from '../../Constants/StaticData';
// import { handleDeleteMaintenancePlan, handleGetMaintenancePlanCounts, handleGetMaintenancePlans } from './maintenance-plan-manager';


// const MaintenancePlansList = () => {
//     // Local States
//     const navigate = useNavigate();
//     const dispatch = useDispatch();
//     const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_MAINTENANCE_PLANS)
//     const [pagination, setPagination] = useState(commonPageState);
//     const [totalCount, setTotalCount] = useState(0);
//     const [plansCounts,setPlansCounts] = useState({})
//     const [isFetchLoader, setIsFetchLoader] = useToggler();
//     const [fetchCountLoader,setFetchCountLoader] = useToggler();
//     const [isDeleteLoader,setIsDeleteLoader] = useToggler()
//     const [refreshApi, setRefreshApi] = useToggler();
//     const [maintenancePlans, setMaintenancePlans] = useState({});
//     const [activeTab, setActiveTab] = useState("Scheduled Maintenance");
//     const [counts, setCounts] = useState({
//         allAsset: 0,
//         scheduledMaintenanceTasks: 0,
//         completedMaintenanceTasks: 0
//     })
//     const [selectedRows, setSelectedRows] = useState([]);
//     const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
//     const columns = [
//         {
//             field: "index",
//             headerName: "SI.NO",
//             width: 50,
//             hideable: false
//         },
//         {
//             field: "number",
//             headerName: "PLAN NUMBER",
//             flex:1,
//             renderCell: param => <p className='c-pointer' onClick={() => navigate(`/view-maintenance-plan/${param?.row?.name}`, { state: { id: param?.row?.id,name:param?.row?.name,status:param?.row?.status,updatedAt:param?.row?.updatedAt } })} style={{ textDecoration: "underline", color: "#0A5FFF" }}>{param?.row?.number}</p>
//         },
//         {
//             field: "name",
//             headerName: "PLAN NAME",
//             flex:1,
//         },
//         {
//             field: "assignees",
//             headerName: "ASSIGNED USER",
//             flex:1,
//             renderCell: param => <p>{param?.row?.assignees?.[0]?.name || "-"}</p>
//         },
//         {
//             field: "existingTeams",
//             headerName: "TEAM",
//             flex:1,
//             renderCell: (param) => <p>{param?.row?.existingTeams?.length ? param?.row?.existingTeams?.map(team => team?.name).join(" ,") : "-"}</p>
//         },
//         {
//             field: "departments",
//             headerName: "DEPARTMENT",
//             flex:1,
//             renderCell: (param) => <p>{param?.row?.departments?.[0]?.name || "-"}</p>
//         },
//         {
//             field: 'status',
//             headerName: "STATUS",
//             flex:1,
//             align: 'center',
// 			headerAlign: 'center',
//             renderCell: (param) => {
//                 return <div style={{background:statusStyleStaticData[param?.row?.status]?.backgroundColor ,color:statusStyleStaticData[param?.row?.status]?.color,padding:"0.4rem 1rem",borderRadius:"6px",fontWeight:"500"}}>{statusStaticData[param?.row?.status]}</div>
//             }
//         },
//         {
//             field: "createdAt",
//             headerName: "CREATED ON",
//             flex: 1,
//             valueGetter: (params) => params?.value ? new Date(params.value) : null,
//             renderCell: param => (
//                 <p>{param?.row?.createdAt ? getYYYYMMDD_Format(param.row.createdAt) : ''}</p>
//             )
//         },
//         {
//             field: "updatedAt",
//             headerName: "LAST UPDATED ON",
//             flex: 1,
//             valueGetter: (params) => params?.value ? new Date(params.value) : null,
//             renderCell: param => (
//                 <p>{param?.row?.updatedAt ? getYYYYMMDD_Format(param.row.updatedAt) : ''}</p>
//             )
//         }
//     ]
//     let [navigatorValues,setNavigatorValues] = useState([
//         {value: "Scheduled Maintenance", status: true,visibility:true},
//         {value: "Predictive Maintenance",status:false,visibility:true},
//         {value: "Preventive Maintenance",status:false,visibility:true},
//     ]);
//     const handleactiveTab = name => {
//         setNavigatorValues(prev => {
//             return prev?.map(tab => {
//                 if(tab?.value === name){
//                     return {...tab,status:true}
//                 } else {
//                     return {...tab,status:false}
//                 }
//             })
//         })
//         setActiveTab(name)
//     };

//     useEffect(() => {
//         handleGetMaintenancePlans({setterMethod:setMaintenancePlans,setIsLoading:setIsFetchLoader,filterPayload:{...pagination,...filterParams}});
//         handleGetMaintenancePlanCounts({setterMethod:setPlansCounts,setIsLoading:setFetchCountLoader})
//     }, [pagination, refreshApi])
//     if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_READ}))
//     return (
//         <>
//             <ClonosGridNav items={[
//                 {
//                     icon: AllChecklists,
//                     iconBg: '#E7EFFF',
//                     title: 'Total Maintenance Plans',
//                     count: plansCounts?.totalMaintenancePlans || 0
//                 },
//                 {
//                     icon: Checks,
//                     iconBg: '#E7EFFF',
//                     title: 'Maintenance Completed Assets',
//                     count: plansCounts?.completedMaintenanceTasks || 0
//                 },
//                 {
//                     icon: PendingForApproval,
//                     iconBg: '#E7EFFF',
//                     title: 'Draft Maintenance Plans',
//                     count: plansCounts?.draftMaintenancePlans || 0
//                 },

//             ]}
//             isLoading={fetchCountLoader}
//             >
//                 <div className="d-fl-al-cen">
//                     {checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}) ? <ClonosButton onClick={() => navigate("/create-maintenance-plan")} variant={"filled"}>Create Maintenance Plan</ClonosButton> : <></>}
//                 </div>
//             </ClonosGridNav >

//             <Card variant="outlined" style={{ flex: 1, marginRight: "1rem", marginLeft: "1rem", display: 'flex', flexDirection: 'column' ,overflowY:"scroll"}}>
//                 <CommonNavigator values={navigatorValues} getSelectedValue={handleactiveTab} />
//                 <div style={{padding:"2rem 4rem",height:"100%"}}>
//                     {activeTab === "Scheduled Maintenance" && <ClonosDataGrid
//                         rows={setSerialNumber(maintenancePlans?.data || [],pagination?.page,pagination?.limit)}
//                         columns={columns}
//                         pageLimit={pagination.limit}
//                         totalCount={maintenancePlans?.totalDataCount}
//                         uniqueIdField={"id"}
//                         handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
//                         isEditMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE}) ? () => navigate("/edit-maintenance-plan", { state: { id: selectedRows[0] } }) : false}
//                         isDeleteMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE}) ? () => setShowConfirmationDailog(true) : false}
//                         onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
//                         isLoading={isFetchLoader}
                        
//                     />}
//                 </div>
//             </Card>
//            { 
//             <ClonosConfirmationBox 
//                 isOpen={showConfirmationDailog} 
//                 headerTitle={"Delete Maintenance Task"} 
//                 message={"Are you sure you want to Delete?"} 
//                 closeModalMethod={setShowConfirmationDailog} 
//                 confirmingMethod={() => handleDeleteMaintenancePlan({
//                                             payload:{"maintenancePlans":selectedRows},
//                                             setIsLoading:setIsDeleteLoader,
//                                             next:() => {
//                                                 setShowConfirmationDailog()
//                                                 handleShowErrorAndWarning({dispatch,message:"Maintenance plans deleted successfully.",type:"success",showTime:"5000"});
//                                                 setRefreshApi();
//                                             }
//                                         })} 
//             />
//             }
//         </>
//     )
//     return <UnAuthorizedModal type="NOT_AUTHORIZED"/>
// }

// export default React.memo(MaintenancePlansList)

/*
date            qid / cr#         comments
12-mar-2026     CR0002            Enable single column filter on the fields visible on these screens

*/

import { Card } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import React, { useCallback, useEffect, useState } from 'react'
import AppUrl from '../../utils/AppUrl';
import { useDispatch } from "react-redux";
import { checkUserHasPermission, commonPageState, getYYYYMMDD_Format, handleShowErrorAndWarning, hasPermission, setSerialNumber } from '../../utils/clonosCommon';
import { doGetApiCall } from '../../utils/ClonosApi';
import ClonosDataGrid from '../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import ClonosGridNav from '../../utils/ClonosGridNav';
import useToggler from '../../CustomHooks/TogglerHook';
import { AllChecklists, Checks, PendingForApproval } from '../../assets/UIUX/icons/Checklist/Checklist';
import { ClonosButton } from '../../components/CommonComponents/Button/Button';
import CommonNavigator from '../../components/CommonComponents/Navigator/Navigator';
import ClonosConfirmationBox from '../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import { getMaintenanceTasksListMethod, handleDeleteMaintenanceTask } from '../../utils/ScheduleMaintenanceMethods/ScheduleMaintenanceMethods';
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_MAINTENANCE_PLANS } from '../../Constants/Constant';
import { UnAuthorizedModal } from '../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal';
import useModuleNameProvider from '../../CustomHooks/ModuleNameProviderHook';
import { statusStaticData, statusStyleStaticData } from '../../Constants/StaticData';
import { handleDeleteMaintenancePlan, handleGetMaintenancePlanCounts, handleGetMaintenancePlans } from './maintenance-plan-manager';


const convertMuiFilterModelToApiParams = (filterModel) => {
 
    if (!filterModel?.items?.length) return {};

    const params = {};
    filterModel.items.forEach(({ field, operator, value }) => {
        // Skip empty values
        if (value === undefined || value === null || value === '') return;

        switch (field) {
            case 'name':
                params.name = value;
                break;

            case 'number':
                params.number = value;
                break;

            case 'assignees':
                params.assignees = value;
                break;

            case 'existingTeams':
                params.existingTeams = value;
                break;

            case 'departments':
                params.departments = value;
                break;

            case 'status':
                // MUI might send a single value; backend expects comma-separated
                params.status = Array.isArray(value) ? value.join(',') : value;
                break;

            case 'createdAt':
                params.createdAt = value;
                break;

            case 'updatedAt':
                params.updatedAt = value;
                break;

            default:
                // For any unmapped field, pass it as-is
                params[field] = value;
        }
    });

    return params;
};

const MaintenancePlansList = () => {
    // Local States
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_MAINTENANCE_PLANS)
    const [pagination, setPagination] = useState(commonPageState);
    const [totalCount, setTotalCount] = useState(0);
    const [plansCounts,setPlansCounts] = useState({})
    const [isFetchLoader, setIsFetchLoader] = useToggler();
    const [fetchCountLoader,setFetchCountLoader] = useToggler();
    const [isDeleteLoader,setIsDeleteLoader] = useToggler()
    const [refreshApi, setRefreshApi] = useToggler();
    const [maintenancePlans, setMaintenancePlans] = useState({});
    const [activeTab, setActiveTab] = useState("Scheduled Maintenance");
    // ── NEW: holds the converted filter params from MUI filterModel ──
                const [filterParams, setFilterParams] = useState({});
    const [counts, setCounts] = useState({
        allAsset: 0,
        scheduledMaintenanceTasks: 0,
        completedMaintenanceTasks: 0
    })
    const [selectedRows, setSelectedRows] = useState([]);
    const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            width: 50,
            disableColumnFilter: true,
            filterable: false, 
            hideable: false
        },
        {
            field: "number",
            headerName: "PLAN NUMBER",
            flex:1,
            renderCell: param => <p className='c-pointer' onClick={() => navigate(`/view-maintenance-plan/${param?.row?.name}`, { state: { id: param?.row?.id,name:param?.row?.name,status:param?.row?.status,updatedAt:param?.row?.updatedAt } })} style={{ textDecoration: "underline", color: "#0A5FFF" }}>{param?.row?.number}</p>
        },
        {
            field: "name",
            headerName: "PLAN NAME",
            flex:1,
        },
        {
            field: "assignees",
            headerName: "ASSIGNED USER",
            flex:1,
            renderCell: param => <p>{param?.row?.assignees?.[0]?.name || "-"}</p>
        },
        {
            field: "existingTeams",
            headerName: "TEAM",
            flex:1,
            renderCell: (param) => <p>{param?.row?.existingTeams?.length ? param?.row?.existingTeams?.map(team => team?.name).join(" ,") : "-"}</p>
        },
        {
            field: "departments",
            headerName: "DEPARTMENT",
            flex:1,
            renderCell: (param) => <p>{param?.row?.departments?.[0]?.name || "-"}</p>
        },
        {
            field: 'status',
            headerName: "STATUS",
            flex:1,
            align: 'center',
			headerAlign: 'center',
             type: 'singleSelect',
             valueOptions: ['Draft','Scheduled' ,'Expired', 'completed'],  // adjust to match your backend enum
            renderCell: (param) => {
                return <div style={{background:statusStyleStaticData[param?.row?.status]?.backgroundColor ,color:statusStyleStaticData[param?.row?.status]?.color,padding:"0.4rem 1rem",borderRadius:"6px",fontWeight:"500"}}>{statusStaticData[param?.row?.status]}</div>
            }
        },
       {
            field: "createdAt",
            headerName: "CREATED ON",
            flex: 1,
            type: "date",
            valueGetter: (params) => params?.value ? new Date(params.value) : null,
            renderCell: param => (
                <p>{param?.row?.createdAt ? getYYYYMMDD_Format(param.row.createdAt) : ''}</p>
            )
        },
        {
            field: "updatedAt",
            headerName: "LAST UPDATED ON",
            flex: 1,
            type: "date",
            valueGetter: (params) => params?.value ? new Date(params.value) : null,
            renderCell: param => (
                <p>{param?.row?.updatedAt ? getYYYYMMDD_Format(param.row.updatedAt) : ''}</p>
            )
        }
    ]
    let [navigatorValues,setNavigatorValues] = useState([
        {value: "Scheduled Maintenance", status: true,visibility:true},
        {value: "Predictive Maintenance",status:false,visibility:true},
        {value: "Preventive Maintenance",status:false,visibility:true},
    ]);
    const handleactiveTab = name => {
        setNavigatorValues(prev => {
            return prev?.map(tab => {
                if(tab?.value === name){
                    return {...tab,status:true}
                } else {
                    return {...tab,status:false}
                }
            })
        })
        setActiveTab(name)
    };


        // ── NEW: called by ClonosDataGrid whenever the user changes a filter ──
        const handleFilterModelChange = useCallback((muiFilterModel) => {
            const converted = convertMuiFilterModelToApiParams(muiFilterModel);
            setFilterParams(converted);
            // Reset to page 1 when filters change
            setPagination((prev) => ({ ...prev, page: 1 }));
        }, []);

    useEffect(() => {
        handleGetMaintenancePlans({setterMethod:setMaintenancePlans,setIsLoading:setIsFetchLoader,filterPayload:{...pagination,...filterParams}});
        handleGetMaintenancePlanCounts({setterMethod:setPlansCounts,setIsLoading:setFetchCountLoader})
    }, [pagination, refreshApi])
    if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_READ}))
    return (
        <>
            <ClonosGridNav items={[
                {
                    icon: AllChecklists,
                    iconBg: '#E7EFFF',
                    title: 'Total Maintenance Plans',
                    count: plansCounts?.totalMaintenancePlans || 0
                },
                {
                    icon: Checks,
                    iconBg: '#E7EFFF',
                    title: 'Maintenance Completed Assets',
                    count: plansCounts?.completedMaintenanceTasks || 0
                },
                {
                    icon: PendingForApproval,
                    iconBg: '#E7EFFF',
                    title: 'Draft Maintenance Plans',
                    count: plansCounts?.draftMaintenancePlans || 0
                },

            ]}
            isLoading={fetchCountLoader}
            >
                <div className="d-fl-al-cen">
                    {checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}) ? <ClonosButton onClick={() => navigate("/create-maintenance-plan")} variant={"filled"}>Create Maintenance Plan</ClonosButton> : <></>}
                </div>
            </ClonosGridNav >

            <Card variant="outlined" style={{ flex: 1, marginRight: "1rem", marginLeft: "1rem", display: 'flex', flexDirection: 'column' ,overflowY:"scroll"}}>
                <CommonNavigator values={navigatorValues} getSelectedValue={handleactiveTab} />
                <div style={{padding:"2rem 4rem",height:"100%"}}>
                    {activeTab === "Scheduled Maintenance" && <ClonosDataGrid
                        rows={setSerialNumber(maintenancePlans?.data || [],pagination?.page,pagination?.limit)}
                        columns={columns}
                        pageLimit={pagination.limit}
                        totalCount={maintenancePlans?.totalDataCount}
                        uniqueIdField={"id"}
                        handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                        isEditMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE}) ? () => navigate("/edit-maintenance-plan", { state: { id: selectedRows[0] } }) : false}
                        isDeleteMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE}) ? () => setShowConfirmationDailog(true) : false}
                        onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                        isLoading={isFetchLoader}
                         // ── NEW: wire up server-side filter ──
                    filterMode="server"
                    handleFilterModelChange={handleFilterModelChange}
                    toolbar={true}   // shows the GridToolbar so users can open the filter panel
                    />}
                </div>
            </Card>
           { 
            <ClonosConfirmationBox 
                isOpen={showConfirmationDailog} 
                headerTitle={"Delete Maintenance Task"} 
                message={"Are you sure you want to Delete?"} 
                closeModalMethod={setShowConfirmationDailog} 
                confirmingMethod={() => handleDeleteMaintenancePlan({
                                            payload:{"maintenancePlans":selectedRows},
                                            setIsLoading:setIsDeleteLoader,
                                            next:() => {
                                                setShowConfirmationDailog()
                                                handleShowErrorAndWarning({dispatch,message:"Maintenance plans deleted successfully.",type:"success",showTime:"5000"});
                                                setRefreshApi();
                                            }
                                        })} 
            />
            }
        </>
    )
    return <UnAuthorizedModal type="NOT_AUTHORIZED"/>
}

export default React.memo(MaintenancePlansList)

