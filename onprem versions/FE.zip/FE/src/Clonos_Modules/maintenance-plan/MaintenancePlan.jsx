import { Card } from "@material-ui/core";
import Styles from "./maintenance-plan.module.css"
import ClonosInput from "../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosTextarea from "../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import DynamicDropdown from "../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import ClonosSelect from "../../components/CommonComponents/ClonosSelect/ClonosSelect";
import { ClonosButton } from "../../components/CommonComponents/Button/Button";
import { ClonosToggleButton } from "../../components/CommonComponents/ClonosToggleButton/ClonosToggleButton";
import { useEffect, useState } from "react";
import useFieldsChecker from "../../CustomHooks/FieldsValidatorHook";
import ClonosRadioAndCheckbox from "../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox";
import { getTeamDropdownData, getUsersDropdownData, getDepartmentDropdownData } from "../../utils/UsersMethods/usersMethods";
import { handleGetAssetDropdownData } from "../ClonosAssets/managers/asset-common-managers";
import { handleGetSingleWorkOrder, handleGetWorkOrderPriorities } from "../work-orders/work-order-manager";
import { checkUserHasPermission, commonPageState, handleShowErrorAndWarning } from "../../utils/clonosCommon";
import { useDispatch } from "react-redux";
import { handleCreateMaintenancePlan, handleGetFilledValuesOfMaintenancePlan, handleGetSingleMaintenancePlan, handleUpdateMaintenancePlan } from "./maintenance-plan-manager";
import { useLocation, useNavigate } from "react-router-dom";
import { CustmizedTeamDropdown } from "../work-orders/components/custmized-team-dropdown/CustmizedTeamDropdown";
import { IoIosClose } from "react-icons/io";
import RecurrenceCustomization from "../LogAndReports/Components/FrequencyBasedRecurrenceCustomization/RecurrenceCustomization";
import { WorkOrderTasks } from "../work-orders/components/work-order-taks/WorkOrderTasks";
import { UnAuthorizedModal } from "../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_MAINTENANCE_PLANS } from "../../Constants/Constant";
import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";


const MaintenancePlan = ({mode}) => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const Location = useLocation();
    const [formData,setFormData] = useState({});
    const [serverData,setServerData] = useState({})
    const [assets,setAssets] = useState({});
    const [assetsPagination,setAssetsPagination] = useState(commonPageState)
    const [assigneesPagination,setAssigneesPagination] = useState(commonPageState)
    const [users,setUsers] = useState({});
    const [teams,setTeams] = useState({});
    const [searchedAssets,setSearchedAssets] = useState({});
    const [searchedUsers,setSearchedUsers] = useState({})
    const [departments,setDepartments] = useState([]);
    const [priorities,setPriorities] = useState([]); 
    const [lcLoadersAndFlags,setLcLoadersAndFlags] = useState({
        fetchMPLoading:false,
        draftMainteneanceLoading:false,
        showDraftMaintenanceAlert:false,
    })
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit,handleRemoveField} = useFieldsChecker({ isIndexKey: false})
    const handleGetValues = (props) => handleGetFilledValuesOfMaintenancePlan({mode,fieldProps:props,setFormData,primaryObject,serverResponse:serverData,handlePrimaryObjectModifier,})
    const handleDynamicSearch = () => {}
    const handleMoreData = () => {}
  //   const handleSave = (action) => {
  //       const next = () => {
  //           navigate("/maintenance-plans")
  //           handleShowErrorAndWarning({dispatch,message:`Maintenance plan ${mode === "edit" ? "updated" :"created"} successfully.`,type:"success",showTime:"5000"})
  //       }
  //       if(action !== "draft" && !handleSubmit()) return
  //       if(mode === "edit"){
  //           handleUpdateMaintenancePlan({payload:formData,setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,saveLoader:!prev.saveLoader})),planId:Location?.state?.id,next})
  //       } else {
  //         // Only add status:"draft" if saving as draft
  //         // const payload = action === "draft" ? {...formData, status: "draft"} : formData;
  //         handleCreateMaintenancePlan({
  //             action,
  //             payload:formData,
  //             setIsLoading: () => setLcLoadersAndFlags(prev => ({...prev, saveLoader: !prev.saveLoader})),
  //             next
  //         })
  //     }
  // }

  const handleSave = (action) => {
    
      
      const emptyTask = formData?.tasks?.findIndex(t => !t.description?.trim());
      if (emptyTask !== -1) {
      handleShowErrorAndWarning({
      dispatch,
      message: `Please fill the description for Task: ${emptyTask + 1}.`,
      type: "error",
      showTime: "5000"
      });
      return;
      }
      
        const next = () => {
          navigate("/maintenance-plans");
          handleShowErrorAndWarning({
            dispatch,
            message: `Maintenance plan ${
              mode === "edit" ? "updated" : "created"
            } successfully.`,
            type: "success",
            showTime: "5000"
          });
        };

        // Only validate for submit/update, not drafts
        if ((action === "submit" || action === "update") && !handleSubmit()) return;

        if (mode === "create") {
          // Create Mode
          // const payload = action === "draft" ? { ...formData, isDraft: true } : formData;
          const isDraft = action === "draft";   
          handleCreateMaintenancePlan({
            isDraft,
            payload:formData,
            setIsLoading: () => setLcLoadersAndFlags(prev => ({
              ...prev, saveLoader: !prev.saveLoader
            })),
            next
          });
        }
     
        if (mode === "edit") {
          let isDraft = false;

        if (mode === "edit" && serverData?.status === "draft") {
          // Editing a draft
          isDraft = action === "draft"; // true only if button is "Save as Draft"
        }
        // Always trigger update in edit mode
        handleUpdateMaintenancePlan({
          payload: formData,
          isDraft,
          setIsLoading: () =>
            setLcLoadersAndFlags(prev => ({
              ...prev,
              saveLoader: !prev.saveLoader,
            })),
          planId: Location?.state?.id,
          next,
        });
}
  };

    const handleFetchAssetsOnScroll = () => {
          if(assets?.totalPageCount > assetsPagination?.page){
              setAssetsPagination(prev => {
                      handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:{limit:prev?.limit,page:prev?.page + 1}})
                      return {...prev,page:prev?.page+1}
              })
          }
    }

    const handleFetchUsersOnScroll = () => {
    if(users?.totalPageCount > assigneesPagination?.page){
            setAssigneesPagination(prev => {
                getUsersDropdownData({setterMethod: setUsers, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType",...assigneesPagination} })
                return {...prev,page:prev?.page+1}
            })
    }
    }

    const handleSearchAsset = ({input}) => {
    
    if(input.length){
            handleGetAssetDropdownData({setterMethod:setSearchedAssets,filterPayload:{...assetsPagination,name:input}})
    } else {
            setSearchedAssets({})
    }
    }

    const handleSeachUsers = ({input}) => {
  
    if(input.length){
            getUsersDropdownData({setterMethod: setSearchedUsers, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType",name:input,...assigneesPagination} })
    } else {
        setSearchedUsers({})
    }
    }

    useEffect(() => {
        if(formData?.department?.id || serverData?.department?.id){
            getTeamDropdownData({setterMethod: setTeams, dispatch, selectedDepartment: formData?.department?.id || serverData?.department?.id })
        }
    },[formData?.department?.id,serverData?.department?.id])

    useEffect(() => {
      handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:assetsPagination})
    },[assetsPagination?.page,assetsPagination?.limit])
    
    useState(() => {
        getUsersDropdownData({ pagination:assigneesPagination?.pagination, setterMethod: setUsers, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType"} })
    },[assigneesPagination?.page,assigneesPagination?.limit])


    useEffect(() => {
      if(mode === "edit") {
            
            handleGetSingleMaintenancePlan({setterMethod:setServerData,setIsLoading: () => setLcLoadersAndFlags(prev => ({...prev,fetchMPLoading:!prev.fetchMPLoading})),planId:Location?.state?.id})
      }
      handleGetWorkOrderPriorities({setterMethod:setPriorities})
      getDepartmentDropdownData({setterMethod:setDepartments,dispatch});
    },[])

  
  if (checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_MAINTENANCE_PLANS, action: CLONOS_GLOBAL_ACTION_CREATE })){
     return <Card variant="outlined" className={Styles.s_m_container}>
    <div className={Styles.s_m_sub_container}>
      <div className={Styles.s_m_content_wrapper}>
        <div className={Styles.s_m_content_wrapper_left}>
          <ClonosInput
            tabIndex={1}
            type={"text"}
            isLabel={true}
            isMandatory={true}
            style={{ width: "100%" }}
            placeholder={"Plan Name"}
            label="Maintenance Plan Name"
            uniqueKey={"name"}
            limit='100'
            errorMessage={"Maintenance plan name is Required!"}
            handleGetValues={handleGetValues}
            defaultValue={mode === "edit" && serverData?.name}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
          />
          <ClonosTextarea
           tabIndex={2}
            type={"text"}
            isLabel={true}
            isMandatory={false}
            label="Description"
            limit='1000'
            style={{ width: "100%" }}
            placeholder={"Description"}
            uniqueKey={"description"}
            handleGetValues={handleGetValues}
            defaultValue={mode === "edit" ? serverData?.description : ""}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
          />
          <DynamicDropdown
            tabIndex={3}
            label="Asset"
            isUser={false}
            isLabel={true}
            disabled={mode === "edit" && serverData?.status !== "draft"}
            uniqueKey="asset"
            heading={"Asset"}
            isCheckbox={false}
            isActivator={true}
            isMandatory={true}
            isSearchable={true}
            // isDynamicLoad={true}
            isDynamicLoad={assets?.totalPageCount > assetsPagination?.page}
            placeholder={"Search"}
            labelActivator={"Select Asset"}
            data={searchedAssets?.data ? searchedAssets?.data : assets?.data || []}
            errorMessage={"Asset is Required!"}
            handleDynamicSearch={handleSearchAsset}
            handleGetValues={handleGetValues}
            handleMoreData={handleFetchAssetsOnScroll}
            defaultValue={serverData?.asset?.name && [serverData?.asset]}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
          />
          <ClonosSelect
            tabIndex={4} 
            isLabel={true}
            type={"select"}
            label="Priority"
            isMandatory={true}
            placeholder="Select"
            uniqueKey="priority"
            defaultValue={serverData?.priority}
            errorMessage={"Priority ir required!."}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            options={priorities?.map((priority) => ({ label: priority, value: priority, isNeeded: true, }))}
            handleGetValues={(value) => handleGetValues({ ...value, updatedValue: { id: value.updatedValue.value, name: value.updatedValue.label, } })}
          />

          <ClonosSelect
            tabIndex={5}
            isLabel={true}
            type={"select"}
            isMandatory={true}
            label="Department"
            placeholder="Select"
            uniqueKey="department"
            errorMessage={"Department is required!."}
            defaultValue={serverData?.department?.name}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            options={departments?.map((dept) => ({ label: dept?.name, value: dept?.id, isNeeded: true, }))}
            //handleGetValues={(value) => handleGetValues({ ...value, updatedValue: { id: value.updatedValue.value, name: value.updatedValue.label, } })}
            disabled={mode === "edit" ? (serverData?.status !== "draft"): false}
            handleGetValues={(props) => {handleGetValues({ ...props, updatedValue: {id: props.updatedValue.value,name: props.updatedValue.label, }, });

            

            // Call API when a department is selected
            if (props?.updatedValue?.value) {
              getUsersDropdownData({
                pagination: assigneesPagination?.pagination, // optional
                setterMethod: setUsers,
                dispatch,
                filterPayload: { selectFields: "name,employeeId" },
                departments: props.updatedValue.value,
              });
            }
          }}
          />
          <div>
          <DynamicDropdown
            tabIndex={6}
            label="Team"
            isUser={false}
            isLabel={true}
            uniqueKey="existingTeams"
            // disabled={mode === "edit" ? true : formData?.department?.id ? false : true} 
             disabled={mode === "edit" ? (serverData?.status !== "draft") || !formData?.department?.id  : !formData?.department?.id }
            isCheckbox={true}
            isActivator={true}
            isMandatory={false}
            isSearchable={true}
            isDynamicLoad={false}
            placeholder={"Search"}
            data={teams?.data || []}
            defaultValue={serverData?.existingTeams?.length ? serverData?.existingTeams : []}
            labelActivator={"Select Team"}
            errorMessage={"Please select teams and members required!"}
            heading={"Select from team library"}
            stopOverlayCloser={true}
            handleNext={() => {
                setLcLoadersAndFlags(prev => ({...prev,showCustmizedTeamDropdown:true}))
            }}
            // handleDynamicSearch={handleDynamicSearch}
            handleGetValues={handleGetValues}
            handleMoreData={() => handleMoreData({ uniqueKey: "team" })}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
          />
          <div className={Styles.local_team_preview}>
              {
              //     !formData?.localTeams?.length ? serverResponse?.localTeams?.map(team => {
              //       return <div className={Styles.preview_tab}>
              //             <p>{`Local Team-${team?.name} - ${team.noOfMembersRequired}`}</p>
              //             <IoIosClose fontSize={"23px"} onClick={() => setServerResponse(prev => ({...prev,localTeams:prev?.localTeams?.filter(el => el?.key !== team?.key)}))}/>
              //       </div>
              //     })  :
                    formData?.localTeams?.map(team => {
                    return <div className={Styles.preview_tab}>
                    <p>{`Local Team-${team?.name} - ${team.noOfMembersRequired}`}</p>
                    <IoIosClose fontSize={"23px"} onClick={() => setFormData(prev => ({...prev,localTeams:prev?.localTeams?.filter(el => el?.key !== team?.key)}))}/>
              </div>
                  })
              }
          </div>
          </div>
          <DynamicDropdown
            tabIndex={7}
            isLabel={true}
            // url={SEARCHICON}
            label="Assignee"
            isMandatory={true}
            isActivator={true}
            isSearchable={true}
            uniqueKey="assignee"
            placeholder={"Search"}
            data={searchedUsers?.data ? searchedUsers?.data : users?.data || []}
            defaultValue={serverData?.assignee}
            labelActivator={"Select assignee"}
            heading={"Select from user library"}
            handleDynamicSearch={handleSeachUsers}
            // isUser={true}
            // isDynamicLoad={true}
            errorMessage={"Assignee is Required!"}
            handleGetValues={handleGetValues}
            handleMoreData={handleFetchUsersOnScroll}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
          />


        <ClonosToggleButton
            tabIndex={8}
            label="Add To Asset History"
            labelPosition="left"
            type="toggle"
            uniqueKey="addToAssetHistory"
            disabled={mode === "edit" ? true : false}
            // disabled={true}
            checked={serverData.addToAssetHistory}
            handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData })}
            />

          <div className={Styles.s_m_dates_wrapper}>
            <div className={Styles.s_m_dates_wrapper_left}>
              <ClonosInput
                tabIndex={9}
                isLabel={true}
                isMandatory={true}
                label="Start Date"
                type={"datetime-local"}
                uniqueKey={"startAt"}
                placeholder="DD/MM/YYYY"
                style={{ width: "100%" }}
                disabled={mode === "edit" && serverData?.status !== "draft" ? true : false}
                errorMessage="Start date is required!"
                handleGetValues={handleGetValues}
                defaultValue={mode === "edit" && serverData?.startAt}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div className={Styles.s_m_dates_wrapper_right}>
              <ClonosInput
                tabIndex={10}
                isLabel={true}
                label="End Date"
                isMandatory={true}
                uniqueKey="endAt"
                type={"datetime-local"}
                style={{ width: "100%" }}
                placeholder="DD/MM/YYYY"
                disabled={!formData?.startAt}
                errorMessage="End date is required!"
                defaultValue={mode === "edit" && serverData?.endAt}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
          </div>

          <div className={Styles.s_m_estimate_wrapper}>
            <div className={Styles.s_m_estimate_wrapper_left}>
              <ClonosInput
              tabIndex={11}
                isLabel={true}
                type={"number"}
                isMandatory={true}
                label="Estimated Days"
                placeholder="Enter Days"
                style={{ width: "100%" }}
                uniqueKey={"estimatedDays"}
                errorMessage="Estimation Days is required!"
                handleGetValues={handleGetValues}
                defaultValue={mode === "edit" && serverData?.estimatedDays}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
            <div className={Styles.s_m_estimate_wrapper_right}>
              <ClonosInput
              tabIndex={12}
                label="Hours"
                isLabel={true}
                type={"number"}
                uniqueKey="estimatedHours"
                isMandatory={true}
                placeholder="Enter Hours"
                style={{ width: "100%" }}
                errorMessage="Hours is required!"
                defaultValue={mode === "edit" && serverData?.estimatedHours}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </div>
          </div>
          <ClonosRadioAndCheckbox
              tabIndex={13}
              name="generationMode"
              uniqueKey="isRecurrence"
              isLabel={true}
              label="Recurrence"
              type="checkbox"
              isChecked={serverData?.isRecurrence}
              disabled={(mode === "edit" && serverData?.status !== "draft") ? true : false}
              handleGetValues={(props) => {
              
                if (!props?.updatedValue) {
                  handleRemoveField(["timePeriod", "recurOn", "inEach"]);
                }
                handleGetValues(props)
              }}
            />

              {
                formData?.isRecurrence ? <div
                aria-label="Frequency selection container"
                className={`${Styles.split_common}`}
              >
                <ClonosInput
                  tabIndex={14}
                  label="Every"
                  isLabel={true}
                  placeholder="1"
                  isMandatory={true}
                  type="number"
                  limit='2'
                  uniqueKey="inEach"
                  defaultValue={mode === "edit" && serverData?.recurrenceDetails?.frequency}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={handleGetValues}
                />
                <ClonosSelect
                  tabIndex={15}
                  type="select"
                  label="Frequency"
                  isMandatory={true}
                  isLabel={true}
                  uniqueKey="timePeriod"
                  placeholder="Select"
                  options={["Hour","Day","Week","Month"]?.map((type) => ({
                    label: `${type}${Number(formData?.inEach) > 1 ? "s" : ""}`,
                    value: type,
                    isNeeded: true,
                    isChecked: false
                  }))}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={(value) => handleGetValues({ ...value, updatedValue: value.updatedValue?.value })}
                />
              </div> : <></>
              }
              {
                formData?.isRecurrence && <RecurrenceCustomization
                  formData={formData}
                  timePeriod={formData?.timePeriod}
                  type="basedOnTimePeriodRecurrence"
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={handleGetValues}
                />
              }

        </div>
        <div className={Styles.s_m_content_wrapper_right}>
          {/* <div className={Styles.s_m_tasks_container}>
            <div className={Styles.s_m_tasks_container_header}>
              <p> Add step-by-step procedures, safety precautions, required tools or equipment, and any additional documentation or references </p>
              <div>
                <h4 className="c-pointer" onClick={() => setIsAddTaskFromTaskLibraryModal(true)} > Add from Task Library </h4>
                <h4 className="c-pointer" onClick={handleAddSingleTask}>{`+ Add Task`}</h4>
              </div>
            </div>
            <div className={Styles.tasks_wrapper}>
              {formData?.tasks?.length > 0 ? (
                formData?.tasks?.map((task, index) => {
                  return (
                    <div className={Styles.single_task_wrapper}>
                      <div key={index} className={Styles.task_input_wrapper}>
                        <p>{`Task-${index + 1}`}</p>
                        <input value={task?.name} placeholder="Enter Task..." maxLength={"100"} onChange={(e) => handleChangeTask(e, task?._id)} />
                      </div>
                      <div>
                        <img src={DELETE_TASK_ICON} alt="Delete TASK" onClick={() => handleRemoveTask(task)} />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div></div>
              )}
            </div>
          </div> */}
          <WorkOrderTasks setFormData={setFormData} formData={formData} serverResponse={serverData}/>
        </div>
      </div>
    <div className={Styles.s_m_btn_controllers}>
        {/* <div> */}
          {/* {mode === "edit" ? (
            <ClonosButton variant="outlined"
              onClick={() => navigate("/maintenance-plans")}
            >Cancel</ClonosButton>
          ) 
          : (
            <ClonosButton variant="outlined"
            onClick={() => navigate("/maintenance-plans")}
          >Cancel</ClonosButton>
            // <ClonosButton
            //     variant="outlined"
            //     onClick={() => handleSave("draft")}
            //     loading={lcLoadersAndFlags.saveLoader}
            // >
            // Save As Draft
            // </ClonosButton>
          )
          } */}
          {/* <ClonosButton variant="outlined"
            onClick={() => navigate("/maintenance-plans")}
          >Cancel</ClonosButton>
             <ClonosButton
                variant="outlined"
                onClick={() => setLcLoadersAndFlags(prev => ({ ...prev, showDraftMaintenanceAlert: true})) } 
            >
            Save As Draft
          </ClonosButton>
          <ClonosButton
              variant="filled"
              loading={lcLoadersAndFlags.saveLoader}
              onClick={() => handleSave("submit")}
          >
          {mode === "edit" ? "Update" : "Submit"}
          </ClonosButton> */}
        {/* </div> */}
        <div>
  {/* Cancel button always */}
  <ClonosButton
    variant="outlined"
    onClick={() => navigate("/maintenance-plans")}
  >
    Cancel
  </ClonosButton>

  {mode === "create" && (
    <>
      <ClonosButton
        variant="outlined"
        onClick={() => handleSave("draft")}
      >
        Save As Draft
      </ClonosButton>
      <ClonosButton
        variant="filled"
        loading={lcLoadersAndFlags.saveLoader}
        onClick={() => handleSave("submit")}
      >
        Submit
      </ClonosButton>
    </>
  )}

  {mode === "edit" && (
    <>
      {serverData?.status=="draft" ? (
        <>
          <ClonosButton
            variant="outlined"
            onClick={() => handleSave("draft")}
          >
            Save As Draft
          </ClonosButton>
          <ClonosButton
            variant="filled"
            loading={lcLoadersAndFlags.saveLoader}
            onClick={() => handleSave("submit")}
          >
            Submit
          </ClonosButton>
        </>
      ) : (
        <ClonosButton
          variant="filled"
          loading={lcLoadersAndFlags.saveLoader}
          onClick={() => handleSave("update")}
        >
          Update
        </ClonosButton>
      )}
    </>
  )}
</div>

      </div>
    </div>
   
    {/* <Modal
      isOpen={isAddTaskFromTaskLibraryModal}
      closeModalMethod={setIsAddTaskFromTaskLibraryModal}
    >
      <TaskLibraryDropdown
        data={taskLibraryData}
        closeModalMethod={setIsAddTaskFromTaskLibraryModal}
        uniqueKey={"predefineTasks"}
        handleGetValues={handleGetValues}
        type={"taskLibrary"}
      />
    </Modal> */}
    <CustmizedTeamDropdown isOpen={lcLoadersAndFlags.showCustmizedTeamDropdown} localTeamsFromServer={serverData?.localTeams || []} existingTeams={mode === "create" ? formData?.existingTeams : !formData?.existingTeams?.length ? serverData?.existingTeams : formData?.existingTeams} formData={formData} setFormData={setFormData} closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,showCustmizedTeamDropdown:false}))}/>
    
    {/* // Confirmation modal */}
      <ClonosConfirmationBox
        isOpen={lcLoadersAndFlags.showDraftMaintenanceAlert}
        headerTitle="Save as Draft"
        message="Are you sure you want to save this Maintenance Plan as a draft?"
        confirmingMethod={() => {
          // Call the API
          handleCreateMaintenancePlan({isDraft: "true",payload: formData,
            setIsLoading: () =>setLcLoadersAndFlags(prev => ({...prev,draftMainteneanceLoading: !prev.draftMainteneanceLoading })),
             next: () => {
              // close modal after success
              setLcLoadersAndFlags(prev => ({
                ...prev,
                showDraftMaintenanceAlert: false
              }));
              navigate("/maintenance-plans")
            }
          });
        }}
        closeModalMethod={() =>
          setLcLoadersAndFlags(prev => ({
            ...prev,
            showDraftMaintenanceAlert: false
          }))
          
        }
      />
  </Card>


    


     }
 
  return <UnAuthorizedModal type={"NOT_AUTHORIZED"} /> 
}

export default MaintenancePlan