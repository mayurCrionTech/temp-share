import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall } from "../../../utils/ClonosApi";
import { generateUniqueId, handleClientDateInConfiguredTimeZone } from "../../../utils/clonosCommon";

export const handleGetRecurredMaitenancePlans = ({planId,setterMethod,setIsLoading,pagination}) => {
    setIsLoading();
    doGetApiCall({url:"workOrders",params:{...pagination,maintenanceId:planId}})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

export const handleGetVersionsOfMaitenancePlan = ({planId,setterMethod,setIsLoading,pagination}) => {
    setIsLoading();
    doGetApiCall({url:`/maintenancePlans/${planId}/versions`,params:pagination})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

export const handleGetMaintenancePlanVersionDetails = ({planId,setterMethod,setIsLoading,versionId}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:`/maintenancePlans/${planId}/versions/${versionId}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            let data = res?.data?.result;
            data.department = data?.departments?.[0];
            data.asset = {name:data?.asset?.generalDetails?.name,id:data?.asset?.id}
            data.assignee = data?.assignees;
            data.startAt = handleClientDateInConfiguredTimeZone({dateString:data?.startAt,parseType:"string"})
            data.endAt = handleClientDateInConfiguredTimeZone({dateString:data?.endAt,parseType:"string"})
            if(data?.tasks?.length > 0) {
                data.tasks = data?.tasks?.map(task => ({...task,isFromServer:true,key:generateUniqueId(3)}))
            }
            if(data?.localTeams?.length > 0){
                data.localTeams = data?.localTeams?.map(team => ({...team,key:generateUniqueId(3)}))
            }
            setterMethod(data)
        }
    })
    .finally(setIsLoading && setIsLoading)
}