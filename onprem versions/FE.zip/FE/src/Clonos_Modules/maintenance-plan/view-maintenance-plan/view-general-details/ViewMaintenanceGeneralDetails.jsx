import { memo, version } from "react";
import Styles from "./view-maintenance-general-details.module.css";
import { useEffect } from "react";
import {
  getFormatedDate,
  getFormatAMPM,
  handleLoginExpiry,
  handleClientDateInConfiguredTimeZone,
} from "../../../../utils/clonosCommon";
import VIEW_MAINTENANCE_TASK_TODO_STATUS from "../../../../assets/UIUX/icons/alert-circle.svg";
import VIEW_MAINTENANCE_TASK_DONE_STATUS from "../../../../assets/UIUX/icons/ScheduleMaintenance/success-check.svg";
import VIEW_MAINTENANCE_TASK_PENDING_STATUS from "../../../../assets/UIUX/icons/ScheduleMaintenance/hourglass-empty.svg";
import { useState } from "react";
import { useLocation } from "react-router";
import { Card } from "@mui/material";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import { useDispatch } from "react-redux";
import useToggler from "../../../../CustomHooks/TogglerHook";
import ClonosLoader from "../../../../components/CommonComponents/ClonosLoader/ClonosLoader";
import AppUrl from "../../../../utils/AppUrl";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import { handleGetSingleMaintenancePlan } from "../../maintenance-plan-manager";
import { handleGetSingleWorkOrder } from "../../../work-orders/work-order-manager";
import { handleGetMaintenancePlanVersionDetails, handleGetVersionsOfMaitenancePlan } from "../view-maintenance-plan-manager";

const ViewMaintenanceGeneralDetails = ({isVersion,versionId,planId,isOpen,closeModalMethod}) => {
  const Location = useLocation();
  const dispatch = useDispatch();
  const [maintenancePlanDetails, setMaintenancePlanDetails] = useState({});
  const [isLoading, setIsLoading] = useToggler(); 
  useEffect(() => {
    if(isVersion){
        versionId && handleGetMaintenancePlanVersionDetails({planId,versionId,setterMethod:setMaintenancePlanDetails,setIsLoading})
    } else {
        planId && handleGetSingleMaintenancePlan({planId,setterMethod:setMaintenancePlanDetails,setIsLoading})
    }
  }, [versionId,planId]);
 
  if(isVersion) return (
    <Modal isOpen={isOpen} closeModalMethod={closeModalMethod}>
        <div className={Styles.version_container}>
            <GeneralDetails isLoading={isLoading} maintenancePlanDetails={maintenancePlanDetails} isVersion={isVersion} closeModalMethod={closeModalMethod}/>
        </div>
    </Modal>
  );

  return <GeneralDetails isLoading={isLoading} maintenancePlanDetails={maintenancePlanDetails}/>
};

export default memo(ViewMaintenanceGeneralDetails);


const GeneralDetails = ({maintenancePlanDetails,isLoading,isVersion,closeModalMethod}) => {
    return <div className={Styles.view_s_m_main_container}>
    {isLoading ? (
      <ClonosLoader />
    ) : (
      <>
        {Object.keys(maintenancePlanDetails ? maintenancePlanDetails : {})?.length > 0 ? (
           <> 
        
            <div className={Styles.view_s_m_sub_container}>
                {isVersion && <div className={Styles.header}>
                    <h4>Maintenance Plan Details</h4>
                    <CloseIcon onClick={closeModalMethod}/>
                </div>}
                <div className={Styles.view_s_m_details_container}>
                <div className={Styles.view_s_m_details_left}>
                      <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                       Maintenance Plan Name
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.name ||
                        "-"}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Maintenance Plan Number
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.number ||
                        "-"}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Description
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.description || "-"}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Assigned User
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.assignee
                        ?.map((user) => user.name)
                        .join(",")}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>Existing Teams</h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.existingTeams
                        ?.map((team) => `${team.name} [${team.noOfMembersRequired}]`)
                        .join(",")}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>Local Teams</h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.localTeams
                        ?.map((team) => `${team.name} [${team.noOfMembersRequired}]`)
                        .join(",")}
                    </p>
                    </div>
                    {/* {
                    Location?.state?.workOrderName && Location?.state?.workOrderNumber && <>
                        <div className={Styles.view_s_field_wrapper}>
                        <h4 className={Styles.view_s_field_name_wrapper}>Work Order Number</h4>
                        <p className={Styles.view_s_field_value_wrapper}>{Location?.state?.workOrderNumber}</p>
                        </div>
                        <div className={Styles.view_s_field_wrapper}>
                        <h4 className={Styles.view_s_field_name_wrapper}>Work Order Name</h4>
                        <p className={Styles.view_s_field_value_wrapper}>{Location?.state?.workOrderName}</p>
                        </div>
                    </>
                    } */}
                </div>
                <div className={Styles.view_s_m_details_right}>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Frequency
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.recurrenceDetails?.frequency
                        ? `${maintenancePlanDetails?.recurrenceDetails?.frequency} ${maintenancePlanDetails?.recurrenceDetails?.timePeriod}`
                        : "-"}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Asset
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {maintenancePlanDetails?.asset?.name || "-"}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Scheduled time
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                       { handleClientDateInConfiguredTimeZone({ dateString: maintenancePlanDetails?.startAt, parseType: "object" })?.clientView}
                         {/* {getFormatedDate(maintenancePlanDetails?.startAt) +
                        " " +
                        getFormatAMPM(maintenancePlanDetails?.startAt) ||
                        "-"} */}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Created On
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {getFormatedDate(maintenancePlanDetails?.createdAt) ||
                        "-"}
                    </p>
                    </div>
                    <div className={Styles.view_s_field_wrapper}>
                    <h4 className={Styles.view_s_field_name_wrapper}>
                        Last Updated On
                    </h4>
                    <p className={Styles.view_s_field_value_wrapper}>
                        {getFormatedDate(maintenancePlanDetails?.updatedAt) ||
                        "-"}
                    </p>
                    </div>
                </div>
                </div>
                <div className={Styles.tasks_wrapper}>
                <div className={Styles.view_s_m_tasks_container}>
                    {maintenancePlanDetails?.tasks?.map(
                    (task, index) => {
                        return (
                        <div
                            key={task?.taskId}
                            className={Styles.view_s_m_task_row}
                            style={{border:"1px solid #8CA1C4"}}
                        >
                            <div className={Styles.view_s_m_task_row_left}>
                            <h5>{`Task ${index + 1} - `}</h5>
                            <p>{task?.description}</p>
                            </div>
                        </div>
                        );
                    }
                    )}
                </div>
                </div>
            </div>
          </>
        ) : (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100%",
            }}
          >
            <h2 style={{ color: "rgb(6, 51, 126)" }}>No Data Found!</h2>
          </div>
        )}
      </>
    )}
  </div>
}