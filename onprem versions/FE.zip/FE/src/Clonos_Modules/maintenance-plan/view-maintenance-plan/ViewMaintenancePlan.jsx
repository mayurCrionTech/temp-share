import { useLocation, useNavigate } from "react-router-dom"
import Subbar from "../../../components/CommonComponents/ClonosSubbar/Subbar";
import React, { useEffect, useState } from "react";
import { CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_ACTION_DELETE } from "../../../Constants/Constant";
import { checkUserHasPermission, commonPageState, getFormatedDate, getYYYYMMDD_Format, handleShowErrorAndWarning, setSerialNumber } from "../../../utils/clonosCommon";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import { Card } from "@material-ui/core";
import CommonNavigator from "../../../components/CommonComponents/Navigator/Navigator";
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { handleGetRecurredMaitenancePlans, handleGetVersionsOfMaitenancePlan } from "./view-maintenance-plan-manager";
import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { handleDeleteMaintenancePlan } from "../maintenance-plan-manager";
import ViewMaintenanceGeneralDetails from "./view-general-details/ViewMaintenanceGeneralDetails";
import { useDispatch } from "react-redux";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
/*
    date            qid / cr#         comments
    07-Apr-2026     -#160             Broken Access Control - Permission Restriction FrontEnd
    */
const ViewMaintenancePlan = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate();
    const [navigatorValues,setNavigatorValues] = useState([
        { value: "Scheduled Maintenance", status: true,visibility:true},
        { value: "Versions", status: false,visibility:true},
        {value:"General Details",status:false,visibility:true}
    ])
    const [lcLoadersAndFlags,setLcLoadersAndFlags] = useState({
        fetchLoader:false,
        showConfirmationDailog:false,
        showGeneralDetailsModal:false,
        maintenancePlanId:null
    })
    const Location = useLocation();
    const moduleName = useModuleNameProvider()
    const [versions,setVersions] = useState({});
    const [planDetails,setPlanDetails] = useState({});
    const [maintenancePlans,setMaintenancePlans] = useState({});
    const [activeTab,setActiveTab] = useState("Scheduled Maintenance")
    const [plansPagination,setPlansPagination] = useState(commonPageState) 
    const [versionsPagination,setVersionsPagination] = useState(commonPageState) 
    //#160 
    const [isUnauthorized, setIsUnauthorized] = useState(false);
    
    const plansColumns = [
        {
            field: "index",
            headerName: "SI.NO",
            width: 50,
            hideable: false
        },
        {
            field: "workOrderNumber",
            headerName: "WORK ORDER ID",
            flex:1,
            hideable: false,
            renderCell: param => <p onClick={() => navigate(`/view-work-order/${param?.row?.name}`,{state:{workOrderId:param?.row?.id}})} className="clonos_datagrid_link">{param?.row?.number ? param?.row?.number : '-'}</p>
        },
        {
            field: "createdAt",
            headerName: "DATE",
            hideable: false,
            flex:1,
            renderCell: param => <p>{param?.row?.createdAt ? getFormatedDate(param.row.createdAt) : '-'}</p>
        },
        {
            field: "status",
            headerName: "STATUS",
            hideable: false,
            flex:1,
            align: 'center',
			headerAlign: 'center',
            renderCell: (param) => {
                return <div style={{background:statusStyleStaticData[param?.row?.status]?.backgroundColor ,color:statusStyleStaticData[param?.row?.status]?.color,padding:"0.4rem 1rem",borderRadius:"6px",fontWeight:"500"}}>{statusStaticData[param?.row?.status]}</div>
            }
        },
    ]

    const versionsColumns = [
        {
            field: "index",
            headerName: "SI.NO",
            width: 100,
            hideable: false
        },
        {
            field: "number",
            headerName: "VERSION NUMBER",
            flex:1,
            hideable: false,
            className:"clonos_datagrid_link",
            renderCell:(param) => {
                return <p onClick={() => setLcLoadersAndFlags(prev => ({...prev,versionId:param?.row?.id,showGeneralDetailsModal:true}))} className="clonos_datagrid_link">{param?.row?.version ? param?.row?.version: "-"}</p>
            }
        },
        {
            field: "updatedAt",
            headerName: "DATE",
            hideable: false,
            flex:1,
            renderCell: param => <p>{param?.row?.updatedAt ? getFormatedDate(param.row.updatedAt) : '-'}</p>
        },
    ]
    const handleactiveTab = name => {
        setNavigatorValues(prev => {
            return prev?.map(tab => {
                if(tab?.value === name){
                    return {...tab,status:true}
                } else {
                    return {...tab,status:false}
                }
            })
        })
        setActiveTab(name)
    };

    useEffect(() => {
        //#160 
     if (!Location?.state) {
        setIsUnauthorized(true);
        return;
     }
        if(activeTab === "Scheduled Maintenance"){
            handleGetRecurredMaitenancePlans({planId:Location?.state?.id,setterMethod:setMaintenancePlans,setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,fetchLoader:!prev.fetchLoader})),pagination:plansPagination})
        } else if(activeTab === "Versions"){
            handleGetVersionsOfMaitenancePlan({planId:Location?.state?.id,setterMethod:setVersions,setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,fetchLoader:!prev.fetchLoader})),pagination:versionsPagination})
        }
    },[Location?.state?.id,plansPagination,versionsPagination,activeTab])
    //#160 
       if (isUnauthorized) {
         return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
         }
    return <>
        <Subbar
            isStatus={true}
            subbarData={Location?.state}
            isEditMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => navigate("/edit-maintenance-plan",{state:{id:Location?.state?.id}})  : false}
            isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setLcLoadersAndFlags(prev => ({...prev,showConfirmationDailog:true})) : false}
            staticElements={[{key:"Last Updated On :",value:getFormatedDate(Location?.state?.updatedAt)}]}
        />
        <Card variant="outlined" style={{ flex: 1, margin: "1rem", display: 'flex', flexDirection: 'column' }}>
            <CommonNavigator
                values={navigatorValues}
                getSelectedValue={handleactiveTab}
            />
            {
                activeTab === "Scheduled Maintenance" ? <div style={{width:"50%",margin:"auto",height:"90%",padding:"2rem"}}>
                    <ClonosDataGrid
                        columns={plansColumns}
                        uniqueId="id"
                        rows={setSerialNumber(maintenancePlans?.data,plansPagination?.page,plansPagination?.limit)}
                        pageLimit={plansPagination.limit}
                        totalCount={maintenancePlans?.totalDataCount}
                        uniqueIdField={"id"}
                        checkboxSelection={false}
                        onPageChange={e => setPlansPagination({ page: e.page + 1, limit: e.pageSize })}
                        isLoading={lcLoadersAndFlags.fetchLoader}
                    />
                </div> : activeTab === "Versions" ? <div style={{width:"40%",margin:"auto",height:"90%",padding:"2rem"}}>
                    <ClonosDataGrid
                        columns={versionsColumns}
                        uniqueId="id"
                        rows={setSerialNumber(versions?.data,versionsPagination?.page,versionsPagination?.limit)}
                        pageLimit={versionsPagination.limit}
                        totalCount={versions?.totalDataCount}
                        uniqueIdField={"id"}
                        checkboxSelection={false}
                        onPageChange={e => setVersionsPagination({ page: e.page + 1, limit: e.pageSize })}
                        isLoading={lcLoadersAndFlags.fetchLoader}
                    />
                </div> : <div style={{overflowY:"scroll",height:"100%"}}>
                <ViewMaintenanceGeneralDetails planId={Location?.state?.id} versionId={lcLoadersAndFlags.versionId} isOpen={lcLoadersAndFlags.showGeneralDetailsModal} closeModalMethod={() => setLcLoadersAndFlags(prev =>({...prev,showGeneralDetailsModal:false}))}/>
                </div>
            }
            <ClonosConfirmationBox 
            isOpen={lcLoadersAndFlags.showConfirmationDailog} 
            headerTitle={"Delete Maintenance Plan"} 
            message={"Are you sure you want to Delete?"} 
            closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,showConfirmationDailog:false}))} 
            confirmingMethod={() => handleDeleteMaintenancePlan({payload: { maintenancePlans: [Location?.state?.id] },setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,deleteLoader:!prev.deleteLoader})),next:() => {
                setLcLoadersAndFlags(prev => ({...prev,showConfirmationDailog:false}))
                handleShowErrorAndWarning({dispatch,message:"Maintenance plans deleted successfully.",type:"success",showTime:"5000"})
                navigate("/maintenance-plans");
            }})} />
        </Card>
        {lcLoadersAndFlags?.versionId && <ViewMaintenanceGeneralDetails isVersion={true} planId={Location?.state?.id} versionId={lcLoadersAndFlags.versionId} isOpen={lcLoadersAndFlags.showGeneralDetailsModal} closeModalMethod={() => setLcLoadersAndFlags(prev =>({...prev,showGeneralDetailsModal:false}))}/>}
    </>
}

export default ViewMaintenancePlan
