import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../Constants/Constant"
import AppUrl from "../../utils/AppUrl"
import { doDeleteApiCall, doGetApiCall, doPatchApiCall, doPostApiCall, doPutApiCall } from "../../utils/ClonosApi"
import { debounce, generateUniqueId, handleClientDateInConfiguredTimeZone, handleServerDateInConfiguredTimeZone } from "../../utils/clonosCommon"
import { handleCheckUniqueFieldsMethod } from "../../utils/common-managers"

//  TO CHECK THE UNIQUNESS OF FIELD
const uniqueFieldHandler = ({ module, mode, fieldName, fieldValue, primaryObject, handlePrimaryObjectModifier, setFormData }) => {
    handleCheckUniqueFieldsMethod({ module, fieldName, fieldValue }).then((res) => {
        if (res === "unique") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
            setFormData((prev) => {
                return { ...prev, [fieldName]: fieldValue }
            })
            // if (mode === "edit") setChangedData((prev) => ({ ...prev, [fieldName]: fieldValue }))
        } else if (res === "not_unique") {
            primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
            primaryObject?.[fieldName]?.errorActivatorMethod(true);
            primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${fieldName}.`)
        }
    })
}


const debouncedCheckUniquenessOfFields = debounce(uniqueFieldHandler, 500);

export const handleGetFilledValuesOfMaintenancePlan = ({mode,fieldProps,setFormData,primaryObject,handlePrimaryObjectModifier,serverResponse}) => {
    const {type,uniqueKey,updatedValue,selectedOption,files} = fieldProps;

    if (type === "dynamicDropdown") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
        setFormData((prev) => ({ ...prev, [uniqueKey]: selectedOption?.map(opt => ({name:opt?.name,id:opt?.id}))}))
    } else if (type === "select") {
            if(uniqueKey === "timePeriod"){
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData(prev => {
                    let temp = {...(prev || {})};
                    if(updatedValue === "Week"){
                        delete temp.recurOn
                    } else if(["Day","Hour","Month"].includes(updatedValue)){
                        delete temp.occursOnSpecificWeekDay
                        delete temp.isOccurOnTheseWeekDays
                        if(updatedValue === "Month"){
                            let day = new Date();
                            temp.recurOn =`monthlyOnDay${day.getDate()}`
                        }
                    }
                    return {...temp,[uniqueKey]:updatedValue}
                })
            } else if(uniqueKey === "recurOn"){
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => ({...prev,[uniqueKey]:updatedValue?.value}))
            } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => ({...prev,[uniqueKey]:updatedValue}))
            }
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
            if(uniqueKey === "name") {
                if(mode !== "edit") {
                    debouncedCheckUniquenessOfFields({module:"maintenancePlans",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData})
                } else {
                    updatedValue !== serverResponse?.name && debouncedCheckUniquenessOfFields({module:"maintenancePlans",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData})
                }
            } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => ({...prev,[uniqueKey]:updatedValue}))
            }
    } else if (type === "file") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
        setFormData((prev) => ({ ...prev, [uniqueKey] : files }))
    } else if (type === "checkbox"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    } else if(type === "taskLibrary"){
        setFormData(prev => ({...prev,[uniqueKey]:selectedOption}))
    } else if(type === "customDay"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue?.map((day) => day.uniqueKey)}))
    } else if(type === "toggle"){
        setFormData(prev => ({...prev , [uniqueKey]:updatedValue}))
    }
}

export const handleGetMaintenancePlans = ({setterMethod,setIsLoading,filterPayload,}) => {
    setIsLoading();
    doGetApiCall({url:AppUrl.getMaintenancePlan,params:filterPayload})
    .then(res =>{
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}


export const handleGetMaintenancePlanCounts = ({setterMethod,setIsLoading}) => {
    setIsLoading();
    doGetApiCall({url:AppUrl.getMaintenancePlanCounts})
    .then(res =>{
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

export const handleCreateMaintenancePlan = ({isDraft,payload,setIsLoading,next}) => {
   
    const requestPayload = handleModifyRequestPayload(payload,"create",isDraft);
   
    setIsLoading();
    doPostApiCall({url:AppUrl.createMaintenancePlan,payload:requestPayload,queryParams:{isDraft}})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
            next && next()
        }
    })
    .finally(setIsLoading)
}

export const handleUpdateMaintenancePlan = ({isDraft,payload,planId,setIsLoading,next}) => {
 
    const requestPayload = handleModifyRequestPayload(payload,"edit",isDraft)
    setIsLoading();
    doPatchApiCall({url:`${AppUrl.editMaintenancePlan}/${planId}`,payload:requestPayload,queryParams:{isDraft}})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            next && next()
        }
    })
    .finally(setIsLoading)
}

const handleModifyRequestPayload = (payload,mode,isDraft) => {
    const requestPayload = {};
 
    
    if ((mode !== "edit") || (mode === "edit" && isDraft)) {
 
       if (payload?.name) requestPayload.name = payload.name;
    } 
    
    if (mode === "edit" && !isDraft) {

       requestPayload.status = "scheduled";
    }

    // if(payload?.status) requestPayload.status = payload.status;
    if(payload?.description) requestPayload.description = payload.description;
    if(payload?.department?.id) requestPayload.departments = [payload?.department?.id];
    if(payload?.asset?.length ? payload?.asset[0]?.id : payload?.asset?.id) requestPayload.asset = payload?.asset?.length ? payload?.asset[0]?.id : payload?.asset?.id;
    if(payload?.priority?.id || payload?.priority?.length) requestPayload.priority = payload?.priority?.id ? payload?.priority?.id : payload?.priority;
    if ((mode !== "edit") || (mode === "edit" && isDraft)){
        if (payload?.startAt) 
            requestPayload.startAt = handleServerDateInConfiguredTimeZone({ dateString: payload.startAt });
    }
    
    //if(payload?.startAt) requestPayload.startAt = handleServerDateInConfiguredTimeZone({dateString:payload?.startAt});
    if(payload?.endAt) requestPayload.endAt = handleServerDateInConfiguredTimeZone({dateString:payload?.endAt});
    if(payload?.estimatedDays >= 0 || payload?.estimatedDays?.length ) requestPayload.estimatedDays = Number(payload?.estimatedDays);
    if(payload?.estimatedHours >= 0 || payload?.estimatedHours?.length) requestPayload.estimatedHours = Number(payload?.estimatedHours);
    if(payload?.assignee?.length && payload?.assignee[0]?.id) requestPayload.assignees = [payload?.assignee[0]?.id];
    if(payload?.addToAssetHistory) requestPayload.addToAssetHistory = payload?.addToAssetHistory
    else requestPayload.addToAssetHistory=false
    if(payload?.existingTeams?.length > 0) requestPayload.existingTeams = payload?.existingTeams?.map(team => ({id:team?.id,noOfMembersRequired:Number(team?.noOfMembersRequired || 0)}));
    if(payload?.localTeams?.length > 0) requestPayload.localTeams = payload?.localTeams?.map(team => ({name:team?.name,noOfMembersRequired:Number(team?.noOfMembersRequired || 0)}));
    requestPayload.isRecurrence = payload.isRecurrence ? true : false;
    let recurrenceDetails = {};
    if(payload?.timePeriod) {
        recurrenceDetails.timePeriod = payload.timePeriod?.toLowerCase();
        if(payload?.inEach) recurrenceDetails.frequency = Number(payload?.inEach) || 0;
        if(payload.timePeriod === "Week"){
            recurrenceDetails.recurrOn = "custom";
            recurrenceDetails.isOccurOnTheseWeekDays = payload.isOccurOnTheseWeekDays;
            recurrenceDetails.occursOnSpecificWeekDay = payload?.occursOnSpecificWeekDay || []
        } else if(payload.timePeriod =="Month"){
            recurrenceDetails.recurrOn = "custom";
        }
        else {
            recurrenceDetails.recurrOn = payload.recurOn;
        }
    }
    if(requestPayload.isRecurrence){
        requestPayload.recurrenceDetails = recurrenceDetails
    }
    let tasksToCreate = [];
    let tasksToEdit = [];
    if(mode === "edit"){
        if(payload?.tasks?.length){
            payload?.tasks?.map((task,index) => {
                if(task.isFromServer){
                    tasksToEdit.push({id:task?.id,description:task?.description,isCompleted:task?.isCompleted,order:task?.order ? task?.order : index+1})
                } else {
                    task?.description && tasksToCreate.push({description:task?.description,order:index+1})
                }
            })
            if(tasksToCreate?.length) requestPayload.tasksToBeAdded = tasksToCreate
            if(tasksToEdit?.length) requestPayload.tasksToBeEdited = tasksToEdit
        }
        if(payload?.tasksToDelete?.length) requestPayload.tasksDeleted = payload?.tasksToDelete
    } else {
        let tempTasks = [];
        if(payload?.tasks?.length){
            payload?.tasks?.map(task => {
                task?.description && tempTasks.push(({description:task?.description,order:task?.order}))
            })
            if(tempTasks?.length) requestPayload.tasks = tempTasks
        }
    }
    return requestPayload
}


export const handleGetSingleMaintenancePlan = ({setterMethod,setIsLoading,planId}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:`${AppUrl.getMaintenancePlan}/${planId}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            let data = res?.data?.result;
            data.department = data?.departments?.[0];
            data.asset = {name:data?.asset?.generalDetails?.name,id:data?.asset?.id}
            data.assignee = data?.assignees;
            data.startAt = handleClientDateInConfiguredTimeZone({dateString:data?.startAt,parseType:"string"})
            data.endAt = handleClientDateInConfiguredTimeZone({dateString:data?.endAt,parseType:"string"})
            if(data?.tasks?.length > 0) {
                data.tasks = data?.tasks?.map(task => ({...task,isFromServer:true,key:generateUniqueId(3)}))
            }
            if(data?.localTeams?.length > 0){
                data.localTeams = data?.localTeams?.map(team => ({...team,key:generateUniqueId(3)}))
            }
            setterMethod(data)
        }
    })
    .finally(setIsLoading && setIsLoading)
}

export const handleDeleteMaintenancePlan = ({payload,next,setIsLoading}) => {
    setIsLoading();
    doDeleteApiCall({url:AppUrl.deleteMaintenancePlan,payload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
            next && next()
        }
    })
    .finally(setIsLoading)
}


