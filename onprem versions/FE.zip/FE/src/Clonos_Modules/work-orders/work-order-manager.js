import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../Constants/Constant"
import AppUrl from "../../utils/AppUrl"
import { doDeleteApiCall, doGetApiCall, doPatchApiCall, doPostApiCall } from "../../utils/ClonosApi"
import { debounce, generateUniqueId, getFormatedDate, getYYYYMMDD_Format, handleClientDateInConfiguredTimeZone, handleServerDateInConfiguredTimeZone, handleShowErrorAndWarning } from "../../utils/clonosCommon"
import { handleCheckUniqueFieldsMethod } from "../../utils/common-managers"

export const handleGetWorkOrderPriorities = ({setterMethod}) => {
    doGetApiCall({url:AppUrl.getWorkOrderConstants})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            const data = res?.data?.result;
            setterMethod(data?.priority)
        }
    })
}

//  TO CHECK THE UNIQUNESS OF FIELD
const uniqueFieldHandler = ({ module, mode, fieldName, fieldValue, primaryObject, handlePrimaryObjectModifier, setFormData, setChangedData }) => {
    handleCheckUniqueFieldsMethod({ module, fieldName, fieldValue }).then((res) => {
        if (res === "unique") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
            setFormData((prev) => {
                return { ...prev, [fieldName]: fieldValue }
            })
            if (mode === "edit") setChangedData((prev) => ({ ...prev, [fieldName]: fieldValue }))
        } else if (res === "not_unique") {
            primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
            primaryObject?.[fieldName]?.errorActivatorMethod(true);
            primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${fieldName}.`)
        }
    })
}


const debouncedCheckUniquenessOfFields = debounce(uniqueFieldHandler, 500);

export const handleGetFilledValuesOfWorkOrder = ({fieldProps,primaryObject,setFormData,handlePrimaryObjectModifier,mode,setChangedData,serverResponse,}) => {
    const {type,uniqueKey,updatedValue,selectedOption,files} = fieldProps;
     
    if (type === "dynamicDropdown") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
      
        setFormData((prev) => ({ ...prev, [uniqueKey]: selectedOption?.map(opt => ({name:opt?.name,id:opt?.id,spareId:opt?.spareId,quantity:opt?.quantity}))}))
    } else if (type === "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => ({...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}}))
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
            if(uniqueKey === "name") {
                if(mode !== "edit") {
                    debouncedCheckUniquenessOfFields({module:"workOrders",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData,setChangedData})
                } else {
                    updatedValue !== serverResponse?.name && debouncedCheckUniquenessOfFields({module:"workOrders",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData,setChangedData})
                }
            } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => ({...prev,[uniqueKey]:updatedValue}))
            }
            
    } else if (type === "file") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
       
        setFormData((prev) => ({ ...prev, [uniqueKey] : files }))
    } else if (type === "checkbox"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    } else if(type === "taskLibrary"){
        setFormData(prev => ({...prev,[uniqueKey]:selectedOption}))
    } else if(type === "toggle"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    }else if(type === "isEditable") {
      setFormData(prev => {
        let auxObj = {...prev,[`${uniqueKey}NeedToDelete`]:selectedOption};
        // debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:files[0]}}})
        return auxObj
      }) 
    }
}


/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/

const handleModifyRequestPayload = (payload,mode,isDraftExisting) => {
  
    const requestPayload = {};
    if(payload?.isWorkPermitRequired !== undefined) requestPayload.isWorkPermitRequired = payload.isWorkPermitRequired
    if(mode !== "edit"){
       if(payload?.name) requestPayload.name = payload.name;
       if(payload?.startAt) requestPayload.startAt = handleServerDateInConfiguredTimeZone({dateString:payload?.startAt});
    }
    
    if (mode === "edit" && isDraftExisting) {
        if(payload?.name) requestPayload.name = payload.name;
         if(payload?.startAt) requestPayload.startAt = handleServerDateInConfiguredTimeZone({dateString:payload?.startAt});
        requestPayload.status = "scheduled";
    }
    if(payload?.description) requestPayload.description = payload.description;
    if(payload?.department?.id) requestPayload.departments = [payload?.department?.id];
    if(payload?.asset?.length ? payload?.asset[0]?.id : payload?.asset?.id) requestPayload.asset = payload?.asset?.length ? payload?.asset[0]?.id : payload?.asset?.id;
     if(payload?.priority?.id || payload?.priority?.length) requestPayload.priority = payload?.priority?.id ? payload?.priority?.id : payload?.priority;
    // if(payload?.priority?.name) requestPayload.priority = payload?.priority?.name
    // if(payload?.priority?.id) requestPayload.priorityId = payload?.priority?.id
    if(payload?.endAt) requestPayload.endAt = handleServerDateInConfiguredTimeZone({dateString:payload?.endAt});
    if(payload?.estimatedDays >= 0 || payload?.estimatedDays?.length ) requestPayload.estimatedDays = Number(payload?.estimatedDays);
    if(payload?.estimatedHours >= 0 || payload?.estimatedHours?.length) requestPayload.estimatedHours = Number(payload?.estimatedHours);
    if(payload?.assignees?.length && payload?.assignees[0]?.id) requestPayload.assignees = [payload?.assignees[0]?.id];
    if(payload?.existingTeams?.length > 0) requestPayload.existingTeams = payload?.existingTeams?.map(team => ({id:team?.id,noOfMembersRequired:Number(team?.noOfMembersRequired || 0)}));
    if(payload?.addToAssetHistory) requestPayload.addToAssetHistory=payload?.addToAssetHistory
    else requestPayload.addToAssetHistory=false
    if(payload?.localTeams?.length > 0) requestPayload.localTeams = payload?.localTeams?.map(team => ({name:team?.name,noOfMembersRequired:Number(team?.noOfMembersRequired || 0)}));
    if(payload?.documents?.length) requestPayload.documents = payload?.documents?.map(doc => doc.id);
    if(payload?.images?.length) requestPayload.images = payload?.images?.map(image => image?.id)
    let tasksToCreate = [];
    let tasksToEdit = [];
    if(mode === "edit"){
        if(payload?.tasks?.length){
            payload?.tasks?.map((task,index) => {
                if(task.isFromServer){
                    tasksToEdit.push({id:task?.id,description:task?.description,isCompleted:task?.isCompleted,order:task?.order ? task?.order : index+1})
                } else {
                    task?.description && tasksToCreate.push({description:task?.description,order:index+1})
                }
            })
            if(tasksToCreate?.length) requestPayload.tasksToBeAdded = tasksToCreate
            if(tasksToEdit?.length) requestPayload.tasksToBeEdited = tasksToEdit
        }
        if(payload?.tasksToDelete?.length) requestPayload.tasksDeleted = payload?.tasksToDelete
    } else {
        let tempTasks = [];
        if(payload?.tasks?.length){
            payload?.tasks?.map(task => {
                task?.description && tempTasks.push(({description:task?.description,order:task?.order}))
            })
            if(tempTasks?.length) requestPayload.tasks = tempTasks
        }
    }
    return requestPayload
}



export const handleCreateWorkOrder = ({payload,setIsLoading,next}) => {
    setIsLoading();
    const requestPayload = handleModifyRequestPayload(payload,"create");
    doPostApiCall({url:AppUrl.createWorkOrder,payload:requestPayload})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
            next && next(res?.data?.result?.id);
        }
    })
    .finally(() => setIsLoading())
}

// export const handleGetAllWorkOrders = ({setterMethod,setIsLoading,pagination}) => {
//     setIsLoading()
//     doGetApiCall({url:AppUrl.getWorkOrders,params:pagination})
//     .then(res => {
//         if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
//             setterMethod(res?.data?.result)
//         }
//     })
//     .finally(setIsLoading)
// }

export const handleGetAllWorkOrders = ({ setterMethod, setIsLoading, pagination, filterParams = {} }) => {
    setIsLoading();

    // Merge pagination + filter params into a single query object
    const params = {
        ...pagination,
        ...filterParams,
    };

    doGetApiCall({ url: AppUrl.getWorkOrders, params })
        .then(res => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                setterMethod(res?.data?.result);
            }
        })
        .finally(setIsLoading);
};



export const handleGetWorkOrdersCounts = ({setterMethod,setIsLoading}) => {
    setIsLoading()
    doGetApiCall({url:AppUrl.getWorkOrderStatuses})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}


// export const handleDraftWorkOrder = ({dispatch,payload,setIsLoading,next}) => {
//     const requestPayload = handleModifyRequestPayload(payload,"create")
//     setIsLoading && setIsLoading();
//     doPostApiCall({url:AppUrl.createWorkOrder,payload:requestPayload,queryParams:{isDraft:true}})
//     .then((res) => {
//         next && next()
//         handleShowErrorAndWarning({dispatch,type:"success",message:"Work order drafted successfully",showTime:"5000"})
//     })
//     .finally(() => {
//         setIsLoading && setIsLoading();
//     })
// }

export const handleDraftWorkOrder = ({ dispatch, payload, setIsLoading, next, workOrderId, isDraftExisting = false }) => {
  const requestPayload = handleModifyRequestPayload(payload, "create");
  setIsLoading && setIsLoading(); // Turn ON loading

  const apiCall = (isDraftExisting && workOrderId)
    ? doPatchApiCall({
        url: `/workOrders/${workOrderId}`,
        payload: requestPayload,
        queryParams: { isDraft: true },
      })
    : doPostApiCall({
        url: AppUrl.createWorkOrder,
        payload: requestPayload,
        queryParams: { isDraft: true },
      });

  // ✅ Always return to ensure proper chaining
  return apiCall
    .then((res) => {
      next && next();
      handleShowErrorAndWarning({
        dispatch,
        type: "success",
        message: "Work order drafted successfully",
        showTime: "5000",
      });
    })
    .catch((err) => {
      console.error("Error drafting work order:", err);
      handleShowErrorAndWarning({
        dispatch,
        type: "error",
        message: "Failed to draft work order",
        showTime: "5000",
      });
    })
    .finally(() => {
      setIsLoading && setIsLoading(); // Turn OFF loading
    });
};

// export const handleGetSingleWorkOrder = ({setterMethod,workOrderId,setIsLoading,mode,setFormData}) => {
    
export const handleGetSingleWorkOrder = ({setterMethod,workOrderId,setIsLoading,mode}) => {
    setIsLoading && setIsLoading();
    const apiUrl = mode === "duplicate" 
        ? `/workOrders/${workOrderId}/copy` 
        : `/workOrders/${workOrderId}`;

    doGetApiCall({url:apiUrl})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const data = res?.data?.result;
            data.department = data?.departments?.length ? data?.departments[0]:null
            // data.assignee = data?.assignees?.length ? data?.assignees[0]:null
            data.nameFromServer= data?.name
            if(data?.startAt?.length > 0){
                data.startAt = getYYYYMMDD_Format(handleClientDateInConfiguredTimeZone({dateString:data?.startAt,parseType:"string"}))
            }
            if(data?.endAt?.length > 0){
                data.endAt = getYYYYMMDD_Format(handleClientDateInConfiguredTimeZone({dateString:data?.endAt,parseType:"string"}))
            }
            if(data?.createdAt?.length > 0){
                data.createdAt = getYYYYMMDD_Format(handleClientDateInConfiguredTimeZone({dateString:data?.createdAt,parseType:"string"}))
            }
            if(data?.updatedAt?.length > 0){
                data.updatedAt = getYYYYMMDD_Format(handleClientDateInConfiguredTimeZone({dateString:data?.updatedAt,parseType:"string"}))
            }

            if(data?.tasks?.length > 0) {
                data.tasks = data?.tasks?.map(task => ({...task,isFromServer:true,key:generateUniqueId(3)}))
            }
            if(data?.localTeams?.length > 0){
                data.localTeams = data?.localTeams?.map(team => ({...team,key:generateUniqueId(3)}))
            }
            // if(mode === "duplicate"){
            //     delete data.images
            //     delete data.documents
            // }

            setterMethod(data)
            // setFormData(data)
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading()
    })
}

export const handleUpdateWorkOrder = ({setIsLoading,workOrderId,payload,next,isDraftExisting = false}) => {
    const requestPayload = handleModifyRequestPayload(payload,"edit",isDraftExisting);
    setIsLoading();
    doPatchApiCall({url:`/workOrders/${workOrderId}`,payload:requestPayload})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
            next && next();
        }
    })
    .finally(() => setIsLoading())
}

export const handleGetTasksDropdownData = ({setterMethod,setIsLoading,filterPayload}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:AppUrl.getTaskList,params:filterPayload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const data = res?.data?.result
            setterMethod(prev => {
                if(filterPayload?.name) {
                    return data
                } else {
                    const prevData = prev?.data?.length ? [...prev?.data] : [];
                    if (prevData?.length) {
                        const uniqueEntitiesObject = prevData.reduce((acc, entity) => {
                            if (!acc[entity?.name]) {
                                acc[entity?.name] = entity;
                            }
                            return acc;
                        }, {});

                        const newEntities = data?.data?.filter(entity => !uniqueEntitiesObject[entity?.name]);

                        return {
                            ...data,
                            data: [...prevData, ...newEntities]
                        };
                    } else {
                        return data;
                    }
                }
            })
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading()
    })
}

export const handleGetSubTasksOfTask = ({setterMethod,setIsLoading,filterPayload,taskId}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:`/tasks/${taskId}`,params:filterPayload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const data = res?.data?.result?.tasks
            // setterMethod(prev => {
            //     if(filterPayload?.name) {
            //         return data
            //     } else {
            //         const prevData = prev?.data?.length ? [...prev?.data] : [];
            //         if (prevData?.length) {
            //             const uniqueEntitiesObject = prevData.reduce((acc, entity) => {
            //                 if (!acc[entity?.name]) {
            //                     acc[entity?.name] = entity;
            //                 }
            //                 return acc;
            //             }, {});

            //             const newEntities = data?.data?.filter(entity => !uniqueEntitiesObject[entity?.name]);

            //             return {
            //                 ...data,
            //                 data: [...prevData, ...newEntities]
            //             };
            //         } else {
            //             return data;
            //         }
            //     }
            // })
            setterMethod(data || [])
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading()
    })
}


export const handleChangeWOStatus = ({status,workOrderId,next,setIsLoading}) => {
    setIsLoading && setIsLoading();
    doPostApiCall({url:`/workOrders/${workOrderId}/${status}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            next && next()
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading();
    })
}

export const handleDeleteWorkOrders = ({payload,setIsLoading,next}) => {
    setIsLoading()
    doDeleteApiCall({url:AppUrl.deleteWorkOrders,payload:{workOrders:payload}})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
            next && next()
        }
    })
    .finally(setIsLoading)
}