// import React, { useEffect } from 'react'
// import { useState } from 'react'
// import "../../overrideStyle.css"
// import { useDispatch } from 'react-redux'
// import { checkUserHasPermission, commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone, handleSegregateURL, handleShowErrorAndWarning, setSerialNumber } from '../../utils/clonosCommon'
// import { useNavigate } from 'react-router-dom'
// import useToggler from '../../CustomHooks/TogglerHook'
// import { Card } from '@material-ui/core'
// import ClonosGridNav from '../../utils/ClonosGridNav'
// import { UnAuthorizedModal } from '../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
// import { ClonosButton } from '../../components/CommonComponents/Button/Button'
// import ClonosDataGrid from '../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
// import ClonosConfirmationBox from '../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
// import { doGetApiCall } from '../../utils/ClonosApi'
// import AppUrl from '../../utils/AppUrl'
// import { Checks, PendingForApproval, AllChecklists } from "../../assets/UIUX/icons/Checklist/Checklist"
// import useModuleNameProvider from '../../CustomHooks/ModuleNameProviderHook'
// import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE } from '../../Constants/Constant'
// import { statusStaticData, statusStyleStaticData, priorityStyleStaticData } from '../../Constants/StaticData'
// import { handleDeleteWorkOrders, handleGetAllWorkOrders, handleGetWorkOrdersCounts } from './work-order-manager'


// const WorkOrderList = () => {
//     const dispatch = useDispatch();
//     const navigate = useNavigate();
//     const [isLoading, setIsLoading] = useToggler(); 
//     const [navLoading,setNavLoading] = useToggler();
//     const [deleteLoading, setDeleteLoading] = useToggler();
//     const [workOrders,setWorkOrders] = useState({});
//     const [pagination, setPagination] = useState(commonPageState);
//     const [totalWorkOrder, setTotalWorkOrder] = useState(0);
//     const [selectedRows, setSelectedRows] = useState([]);
//     const [refreshApi, setRefreshApi] = useToggler();
//     const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
//     const [workOrderStatuses, setWorkOrderStatuses] = useState({});
//     const [refreshStatusCount, setRefreshStatusCount] = useToggler();
//     const moduleName = useModuleNameProvider();
//     console.log('moduleName:', moduleName)



//     const columns = [
//         {
//             field: "index",
//             headerName: "SI.No",
//             // flex: 1,
//             width: "50",
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//         },
//         {
//             field: "number",
//             headerName: "WORK ORDER NUMBER",
//             // width: "200",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             filterPanelClassName: "ast_column_filterPanel",
//             valueGetter: (params) => params?.row?.number || "-"
//         },
//         {
//             field: "name",
//             headerName: "WORK ORDER TITLE",
//             // width: "200",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             renderCell: (params) => {
//                 return <p onClick={() => handleGotoWOV(params?.row?.id, params?.row?.name, (params?.row?.name || params?.row?.id))} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>
//             }
//         },
//         {
//             field: "endAt",
//             headerName: "END DATE",
//             // width: "200",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             valueGetter: (params) => params?.row?.endAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params?.row?.endAt,parseType:"string"})) : "-"
//         },
//         {
//             field: "priority",
//             headerName: "PRIORITY",
//             // width: "100",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             // valueGetter: (params) => params?.row?.priority?.priorityName || "-"
//             renderCell: (params) => {
//                 const row = params.row;
//                 return <p style={{ ...priorityStyleStaticData[row?.priority === "High-P1" ? "high" : row?.priority === "Medium-P2" ? "medium" : "low"], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{row?.priority|| "-"}</p>
//             }
//         },
//         {
//             field: "asset",
//             headerName: "ASSET",
//             // width: "200",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             valueGetter: (params) => params?.row?.asset && params?.row?.asset?.generalDetails?.name || "-"
//         },
//         {
//             field: "assignee",
//             headerName: "ASSIGNED USER  ",
//             // width: "200",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             valueGetter: (params) => params?.row?.assignees && params?.row?.assignees[0]?.name || "-"
//         },
//         {
//             field: "status",
//             headerName: "STATUS",
//             // width: "100",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             // valueGetter: (params) => params?.row?.status || "-"
//             renderCell: (params) => {
//                 return <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{params?.row?.status ? statusStaticData[params?.row?.status] : "-"}</p>
//             }
//         },
//         {
//             field: "createdAt",
//             headerName: "CREATED ON",
//             // width: "200",
//             flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "ast_column_header",
//             valueGetter: (params) => params?.row?.createdAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params?.row?.createdAt,parseType:"string"})) : "-"
//         },
//     ]

//     const handleGotoWOV = (workOrderId, workOrderNumber, workOrderNameOrId) => {
//         navigate(`/view-work-order/${workOrderNameOrId}`, { state: { workOrderId, workOrderNumber } })
//     }

//     const handleDeleteMultipleWorkOrders = () => {
//         handleDeleteWorkOrders({payload:selectedRows,setIsLoading:setDeleteLoading,next:() => {
//             handleShowErrorAndWarning({dispatch,message:"Work orders deleted successfully.",type:"success",showTime:"5000"})
//             handleGetAllWorkOrders({setterMethod:setWorkOrders,setIsLoading,pagination});
//             handleGetWorkOrdersCounts({setterMethod:setWorkOrderStatuses,setIsLoading:setNavLoading})
//             setSelectedRows([]);
//             setDeleteWorkOrderAlert(false)
//         }})
//     }

//     const handleEditWorkOrder = () => {
//         navigate("/edit-work-order", { state: { workOrderId: selectedRows[0] } })
//     }


//     useEffect(() => {
//         handleGetAllWorkOrders({setterMethod:setWorkOrders,setIsLoading,pagination})
//     },[pagination?.page,pagination?.limit])


//     useEffect(() => {
//         handleGetWorkOrdersCounts({setterMethod:setWorkOrderStatuses,setIsLoading:setNavLoading})
//     }, []);

//     console.log(workOrderStatuses,"workOrderStatuses")

//     if (checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
//         const URL = handleSegregateURL();

//         return <>
//             {(!URL?.unity && !URL?.AR && !URL?.VR) && <ClonosGridNav isLoading={navLoading} items={[
//                 {
//                     icon: AllChecklists,
//                     iconBg: '#E7EFFF',
//                     title: 'Total Work Orders',
//                     count: workOrderStatuses?.totalWorkOrders || 0
//                 },
//                 {
//                     icon: Checks,
//                     iconBg: '#EBFAEC',
//                     title: 'Completed Work Orders',
//                     count: workOrderStatuses?.completedWorkOrders || 0
//                 },
//                 {
//                     icon: PendingForApproval,
//                     iconBg: '#F7E9BF',
//                     title: 'Drafted Work Orders',
//                     count: workOrderStatuses?.draftWorkOrders || 0
//                 },
//             ]}>
//                 <div className="d-fl-al-cen">
//                     {checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ?
//                         <ClonosButton onClick={() => navigate("/create-work-order")} variant={"filled"}>Create Work Order</ClonosButton> : <></>}
//                 </div>
//             </ClonosGridNav>}

//             <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", padding: "2.5rem 2rem", borderRadius: "0rem 0rem 1rem 1rem", height: "100vh" }}>
//                 <ClonosDataGrid
//                     rows={setSerialNumber(workOrders?.data,pagination?.page,pagination?.limit)}
//                     columns={columns}
//                     isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
//                     isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
//                     uniqueIdField="id"
//                     onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
//                     isLoading={isLoading}
//                     totalCount={workOrders?.totalDataCount}
//                     pageLimit={pagination.limit}
//                     checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
//                     handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
//                 />
//             </Card>
//             <ClonosConfirmationBox
//                 isOpen={deleteWorkOrderAlert}
//                 loading={deleteLoading}
//                 confirmingMethod={() => {
//                     handleDeleteMultipleWorkOrders()
//                 }}
//                 closeModalMethod={setDeleteWorkOrderAlert}
//                 headerTitle="Delete Work Order"
//                 message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this work order" : "these work orders"}?`}
//             />
//         </>
//     }

//     return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
// }

// export default WorkOrderList


//last workintcode
// import React, { useEffect, useCallback } from 'react'
// import { useState } from 'react'
// import "../../overrideStyle.css"
// import { useDispatch } from 'react-redux'
// import { checkUserHasPermission, commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone, handleSegregateURL, handleShowErrorAndWarning, setSerialNumber } from '../../utils/clonosCommon'
// import { useNavigate } from 'react-router-dom'
// import useToggler from '../../CustomHooks/TogglerHook'
// import { Card } from '@material-ui/core'
// import ClonosGridNav from '../../utils/ClonosGridNav'
// import { UnAuthorizedModal } from '../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
// import { ClonosButton } from '../../components/CommonComponents/Button/Button'
// import ClonosDataGrid from '../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
// import ClonosConfirmationBox from '../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
// import useModuleNameProvider from '../../CustomHooks/ModuleNameProviderHook'
// import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE } from '../../Constants/Constant'
// import { statusStaticData, statusStyleStaticData, priorityStyleStaticData } from '../../Constants/StaticData'
// import { Checks, PendingForApproval, AllChecklists } from "../../assets/UIUX/icons/Checklist/Checklist"
// import { handleDeleteWorkOrders, handleGetAllWorkOrders, handleGetWorkOrdersCounts } from './work-order-manager'


// /**
//  * Converts MUI DataGrid filterModel → query params your backend queryBuilder understands.
//  *
//  * MUI filterModel shape:
//  * {
//  *   items: [
//  *     { field: 'name', operator: 'contains', value: 'pump' },
//  *     { field: 'status', operator: 'equals', value: 'open' },
//  *     ...
//  *   ]
//  * }
//  *
//  * Supported field → backend param mappings:
//  *   name        → name       (string, regex on backend)
//  *   number      → number     (string, regex on backend)
//  *   status      → status     (comma-separated string for $in on backend)
//  *   priority    → priority   (string, regex on backend)
//  *   asset       → asset      (ObjectId string)
//  */
// const convertMuiFilterModelToApiParams = (filterModel) => {
//     if (!filterModel?.items?.length) return {};

//     const params = {};

//     filterModel.items.forEach(({ field, operator, value }) => {
//         // Skip empty values
//         if (value === undefined || value === null || value === '') return;

//         switch (field) {
//             case 'name':
//                 params.name = value;
//                 break;

//             case 'number':
//                 params.number = value;
//                 break;

//             case 'status':
//                 // MUI might send a single value; backend expects comma-separated for $in
//                 params.status = Array.isArray(value) ? value.join(',') : value;
//                 break;

//             case 'priority':
//                 params.priority = value;
//                 break;

//             case 'asset':
//                 // The asset column valueGetter shows the name, but for filtering
//                 // you'd ideally pass the asset ID. Adjust if your UI stores the ID separately.
//                 params.asset = value;
//                 break;
                

//             default:
//                 // For any unmapped field, pass it as-is
//                 params[field] = value;
//         }
//     });

//     return params;
// };


// const WorkOrderList = () => {
//     const dispatch = useDispatch();
//     const navigate = useNavigate();
//     const [isLoading, setIsLoading] = useToggler();
//     const [navLoading, setNavLoading] = useToggler();
//     const [deleteLoading, setDeleteLoading] = useToggler();
//     const [workOrders, setWorkOrders] = useState({});
//     const [pagination, setPagination] = useState(commonPageState);
//     const [selectedRows, setSelectedRows] = useState([]);
//     const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
//     const [workOrderStatuses, setWorkOrderStatuses] = useState({});

//     // ── NEW: holds the converted filter params from MUI filterModel ──
//     const [filterParams, setFilterParams] = useState({});

//     const moduleName = useModuleNameProvider();
   



//     const columns = [
//         {
//             field: "index",
//             headerName: "SI.No",
//             width: "50",
//             disableColumnFilter: true,
//             filterable: false,   
//             headerClassName: "ast_column_header",
//         },
//         {
//             field: "number",
//             headerName: "WORK ORDER NUMBER",
//             flex: 1,
//             // filterable: true (default) — operator options: contains, equals, startsWith, endsWith
//             headerClassName: "ast_column_header",
//             filterPanelClassName: "ast_column_filterPanel",
//             valueGetter: (params) => params?.row?.number || "-"
//         },
//         {
//             field: "name",
//             headerName: "WORK ORDER TITLE",
//             flex: 1,
//             headerClassName: "ast_column_header",
//             renderCell: (params) => (
//                 <p
//                     onClick={() => handleGotoWOV(params?.row?.id, params?.row?.name, (params?.row?.name || params?.row?.id))}
//                     style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}
//                 >
//                     {params?.row?.name || "-"}
//                 </p>
//             )
//         },
//         {
//             field: "endAt",
//             headerName: "END DATE",
//             flex: 1,
//             disableColumnFilter: true,   // dates are tricky — keep disabled unless you add a date picker filter
//             headerClassName: "ast_column_header",
//             type: "date",
//             valueGetter: (params) => params?.value ? new Date(params.value) : null,
//             renderCell: (params) => params?.row?.endAt
//                 ? getFormatedDate(handleClientDateInConfiguredTimeZone({ dateString: params?.row?.endAt, parseType: "string" }))
//                 : "-"
//         },
//         {
//             field: "priority",
//             headerName: "PRIORITY",
//             flex: 1,
//             // type: 'singleSelect' lets MUI render a dropdown in the filter panel
//             type: 'singleSelect',
//             valueOptions: ['High-P1', 'Medium-P2', 'Low-P3'],
//             headerClassName: "ast_column_header",
//             renderCell: (params) => {
//                 const row = params.row;
//                 const key = row?.priority === "High-P1" ? "high" : row?.priority === "Medium-P2" ? "medium" : "low";
//                 return (
//                     <p style={{ ...priorityStyleStaticData[key], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
//                         {row?.priority || "-"}
//                     </p>
//                 );
//             }
//         },
//         {
//             field: "asset",
//             headerName: "ASSET",
//             flex: 1,
//              // asset filter needs ObjectId — disable text filter or build custom
//             headerClassName: "ast_column_header",
//             valueGetter: (params) => params?.row?.asset?.generalDetails?.name || "-"
//         },
//         {
//             field: "assignee",
//             headerName: "ASSIGNED USER",
//             flex: 1,
           
//             headerClassName: "ast_column_header",
//             valueGetter: (params) => params?.row?.assignees?.[0]?.name || "-"
//         },
//         {
//             field: "status",
//             headerName: "STATUS",
//             flex: 1,
//             // type: 'singleSelect' gives a dropdown in the filter panel
//             type: 'singleSelect',
//             valueOptions: ['open', 'inProgress', 'completed', 'draft', 'onHold','expired'],  // adjust to match your backend enum
//             headerClassName: "ast_column_header",
//             renderCell: (params) => (
//                 <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
//                     {params?.row?.status ? statusStaticData[params?.row?.status] : "-"}
//                 </p>
//             )
//         },
//         {
//             field: "createdAt",
//             headerName: "CREATED ON",
//             flex: 1,
           
//             headerClassName: "ast_column_header",
//             type: "date",
//             valueGetter: (params) => params?.value ? new Date(params.value) : null,
//             renderCell: (params) => params?.row?.createdAt
//                 ? getFormatedDate(handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "string" }))
//                 : "-"
//         },
//     ];


//     const handleGotoWOV = (workOrderId, workOrderNumber, workOrderNameOrId) => {
//         navigate(`/view-work-order/${workOrderNameOrId}`, { state: { workOrderId, workOrderNumber } });
//     };

//     const handleDeleteMultipleWorkOrders = () => {
//         handleDeleteWorkOrders({
//             payload: selectedRows,
//             setIsLoading: setDeleteLoading,
//             next: () => {
//                 handleShowErrorAndWarning({ dispatch, message: "Work orders deleted successfully.", type: "success", showTime: "5000" });
//                 handleGetAllWorkOrders({ setterMethod: setWorkOrders, setIsLoading, pagination, filterParams });
//                 handleGetWorkOrdersCounts({ setterMethod: setWorkOrderStatuses, setIsLoading: setNavLoading });
//                 setSelectedRows([]);
//                 setDeleteWorkOrderAlert(false);
//             }
//         });
//     };

//     const handleEditWorkOrder = () => {
//         navigate("/edit-work-order", { state: { workOrderId: selectedRows[0] } });
//     };

//     // ── NEW: called by ClonosDataGrid whenever the user changes a filter ──
//     const handleFilterModelChange = useCallback((muiFilterModel) => {
//         const converted = convertMuiFilterModelToApiParams(muiFilterModel);
//         setFilterParams(converted);
//         // Reset to page 1 when filters change
//         setPagination((prev) => ({ ...prev, page: 1 }));
//     }, []);


//     // Re-fetch when page/limit OR filterParams change
//     useEffect(() => {
//         handleGetAllWorkOrders({
//             setterMethod: setWorkOrders,
//             setIsLoading,
//             pagination,
//             filterParams,          // ← pass filters to the manager
//         });
//     }, [pagination?.page, pagination?.limit, filterParams]);


//     useEffect(() => {
//         handleGetWorkOrdersCounts({ setterMethod: setWorkOrderStatuses, setIsLoading: setNavLoading });
//     }, []);

 

//     if (checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
//         const URL = handleSegregateURL();

//         return <>
//             {(!URL?.unity && !URL?.AR && !URL?.VR) && (
//                 <ClonosGridNav isLoading={navLoading} items={[
//                     { icon: AllChecklists, iconBg: '#E7EFFF', title: 'Total Work Orders',     count: workOrderStatuses?.totalWorkOrders     || 0 },
//                     { icon: Checks,        iconBg: '#EBFAEC', title: 'Completed Work Orders', count: workOrderStatuses?.completedWorkOrders || 0 },
//                     { icon: PendingForApproval, iconBg: '#F7E9BF', title: 'Drafted Work Orders', count: workOrderStatuses?.draftWorkOrders  || 0 },
//                 ]}>
//                     <div className="d-fl-al-cen">
//                         {checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) && (
//                             <ClonosButton onClick={() => navigate("/create-work-order")} variant={"filled"}>
//                                 Create Work Order
//                             </ClonosButton>
//                         )}
//                     </div>
//                 </ClonosGridNav>
//             )}

//             <Card
//                 variant="outlined"
//                 style={{
//                     flex: 1,
//                     margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem" : "0rem 1rem 1rem 1rem",
//                     padding: "2.5rem 2rem",
//                     borderRadius: "0rem 0rem 1rem 1rem",
//                     height: "100vh"
//                 }}
//             >
//                 <ClonosDataGrid
//                     rows={setSerialNumber(workOrders?.data, pagination?.page, pagination?.limit)}
//                     columns={columns}
//                     isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
//                     isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
//                     uniqueIdField="id"
//                     onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
//                     isLoading={isLoading}
//                     totalCount={workOrders?.totalDataCount}
//                     pageLimit={pagination.limit}
//                     checkboxSelection={
//                         checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) &&
//                         checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })
//                     }
//                     handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
//                     // ── NEW: wire up server-side filter ──
//                     filterMode="server"
//                     handleFilterModelChange={handleFilterModelChange}
//                     toolbar={true}   // shows the GridToolbar so users can open the filter panel
//                 />
//             </Card>

//             <ClonosConfirmationBox
//                 isOpen={deleteWorkOrderAlert}
//                 loading={deleteLoading}
//                 confirmingMethod={handleDeleteMultipleWorkOrders}
//                 closeModalMethod={setDeleteWorkOrderAlert}
//                 headerTitle="Delete Work Order"
//                 message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this work order" : "these work orders"}?`}
//             />
//         </>;
//     }

//     return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
// };

// export default WorkOrderList;

/*
date            qid / cr#         comments
9-mar-2026     CR0002            Enable single column filter on the fields visible on these screens

*/

import React, { useEffect, useCallback } from 'react'
import { useState } from 'react'
import "../../overrideStyle.css"
import { useDispatch } from 'react-redux'
import { checkUserHasPermission, commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone, handleSegregateURL, handleShowErrorAndWarning, setSerialNumber } from '../../utils/clonosCommon'
import { useNavigate } from 'react-router-dom'
import useToggler from '../../CustomHooks/TogglerHook'
import { Card } from '@material-ui/core'
import ClonosGridNav from '../../utils/ClonosGridNav'
import { UnAuthorizedModal } from '../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
import { ClonosButton } from '../../components/CommonComponents/Button/Button'
import ClonosDataGrid from '../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import ClonosConfirmationBox from '../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import useModuleNameProvider from '../../CustomHooks/ModuleNameProviderHook'
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE } from '../../Constants/Constant'
import { statusStaticData, statusStyleStaticData, priorityStyleStaticData } from '../../Constants/StaticData'
import { Checks, PendingForApproval, AllChecklists } from "../../assets/UIUX/icons/Checklist/Checklist"
import { handleDeleteWorkOrders, handleGetAllWorkOrders, handleGetWorkOrdersCounts } from './work-order-manager'


/**
 * Converts MUI DataGrid filterModel → query params the backend queryBuilder understands.
 *
 * Field → backend param mapping:
 *   name        → name                       (string regex)
 *   number      → number                     (string regex)
 *   status      → status                     (comma-separated for $in)
 *   priority    → priority                   (string regex)
 *   asset       → assetName                  (string regex — backend pre-lookup)
 *   assignee    → assigneeName               (string regex — backend pre-lookup)
 *   createdAt   → createdAtFrom/createdAtTo  (ISO date strings)
 *   endAt       → endAtFrom/endAtTo          (ISO date strings)
 */
const convertMuiFilterModelToApiParams = (filterModel) => {
    if (!filterModel?.items?.length) return {};

    const params = {};

    filterModel.items.forEach(({ field, operator, value }) => {
        if (value === undefined || value === null || value === '') return;

        switch (field) {

            // ── String / regex fields ────────────────────────────────────────
            case 'name':
                params.name = value;
                break;

            case 'number':
                params.number = value;
                break;

            case 'priority':
                params.priority = value;
                break;

            // ── Asset name → backend does regex find on assets collection ────
            case 'asset':
                params.assetName = value;
                break;

            // ── Assignee name → backend does regex find on users collection ──
            case 'assignee':
                params.assigneeName = value;
                break;

            // ── Status single-select dropdown ────────────────────────────────
            case 'status':
                params.status = Array.isArray(value) ? value.join(',') : value;
                break;

            // ── Date range fields ────────────────────────────────────────────
            case 'createdAt':
            case 'endAt': {
                const raw = value instanceof Date ? value : new Date(value);
                if (isNaN(raw.getTime())) break;

                const startOfDay = new Date(raw); startOfDay.setHours(0, 0, 0, 0);
                const endOfDay   = new Date(raw); endOfDay.setHours(23, 59, 59, 999);

                switch (operator) {
                    case 'is':
                        params[`${field}From`] = startOfDay.toISOString();
                        params[`${field}To`]   = endOfDay.toISOString();
                        break;
                    case 'after':
                        params[`${field}From`] = endOfDay.toISOString();
                        break;
                    case 'onOrAfter':
                        params[`${field}From`] = startOfDay.toISOString();
                        break;
                    case 'before':
                        params[`${field}To`] = startOfDay.toISOString();
                        break;
                    case 'onOrBefore':
                        params[`${field}To`] = endOfDay.toISOString();
                        break;
                    default:
                        params[`${field}From`] = startOfDay.toISOString();
                        params[`${field}To`]   = endOfDay.toISOString();
                }
                break;
            }

            default:
                break;
        }
    });

    return params;
};


const WorkOrderList = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useToggler();
    const [navLoading, setNavLoading] = useToggler();
    const [deleteLoading, setDeleteLoading] = useToggler();
    const [workOrders, setWorkOrders] = useState({});
    const [pagination, setPagination] = useState(commonPageState);
    const [selectedRows, setSelectedRows] = useState([]);
    const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
    const [workOrderStatuses, setWorkOrderStatuses] = useState({});
    const [filterParams, setFilterParams] = useState({});

    const moduleName = useModuleNameProvider();


    const columns = [
        {
            field: "index",
            headerName: "SI.No",
            width: 60,
            disableColumnFilter: true,
            filterable:false,
            headerClassName: "ast_column_header",
        },
        {
            field: "number",
            headerName: "WORK ORDER NUMBER",
            flex: 1,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.number || "-"
        },
        {
            field: "name",
            headerName: "WORK ORDER TITLE",
            flex: 1,
            headerClassName: "ast_column_header",
            renderCell: (params) => (
                <p
                    onClick={() => handleGotoWOV(params?.row?.id, params?.row?.name, (params?.row?.name || params?.row?.id))}
                    style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}
                >
                    {params?.row?.name || "-"}
                </p>
            )
        },
        {
            field: "endAt",
            headerName: "END DATE",
            flex: 1,
            // type:'date' → MUI renders a DatePicker in the filter panel
            // valueGetter MUST return a JS Date (not a string) for date columns
            type: 'date',
            headerClassName: "ast_column_header",
            valueGetter: (params) => {
                if (!params?.row?.endAt) return null;
                const parsed = handleClientDateInConfiguredTimeZone({ dateString: params.row.endAt, parseType: "string" });
                return parsed ? new Date(parsed) : null;
            },
            renderCell: (params) => {
                if (!params?.row?.endAt) return "-";
                return getFormatedDate(handleClientDateInConfiguredTimeZone({ dateString: params.row.endAt, parseType: "string" }));
            }
        },
        {
            field: "priority",
            headerName: "PRIORITY",
            flex: 1,
            type: 'singleSelect',
            valueOptions: ['High-P1', 'Medium-P2', 'Low-P3'],
            headerClassName: "ast_column_header",
            renderCell: (params) => {
                const row = params.row;
                const key = row?.priority === "High-P1" ? "high"
                    : row?.priority === "Medium-P2" ? "medium"
                    : "low";
                return (
                    <p style={{ ...priorityStyleStaticData[key], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                        {row?.priority || "-"}
                    </p>
                );
            }
        },
        {
            field: "asset",
            headerName: "ASSET",
            flex: 1,
            // Text filter → sends 'assetName' to backend
            // Backend resolves name → ObjectId(s) via regex find on assets collection
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.asset?.generalDetails?.name || "-"
        },
        {
            field: "assignee",
            headerName: "ASSIGNED USER",
            flex: 1,
            // Text filter → sends 'assigneeName' to backend
            // Backend resolves name → ObjectId(s) via regex find on users collection
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.assignees?.[0]?.name || "-"
        },
        {
            field: "status",
            headerName: "STATUS",
            flex: 1,
            type: 'singleSelect',
            valueOptions: [ 'completed', 'draft', 'onHold', 'expired', 'scheduled', 'accepted'],
            headerClassName: "ast_column_header",
            renderCell: (params) => (
                <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                    {params?.row?.status ? statusStaticData[params?.row?.status] : "-"}
                </p>
            )
        },
        {
            field: "createdAt",
            headerName: "CREATED ON",
            flex: 1,
            // type:'date' → MUI renders a DatePicker in the filter panel
            type: 'date',
            headerClassName: "ast_column_header",
            valueGetter: (params) => {
                if (!params?.row?.createdAt) return null;
                const parsed = handleClientDateInConfiguredTimeZone({ dateString: params.row.createdAt, parseType: "string" });
                return parsed ? new Date(parsed) : null;
            },
            renderCell: (params) => {
                if (!params?.row?.createdAt) return "-";
                return getFormatedDate(handleClientDateInConfiguredTimeZone({ dateString: params.row.createdAt, parseType: "string" }));
            }
        },
    ];


    const handleGotoWOV = (workOrderId, workOrderNumber, workOrderNameOrId) => {
        navigate(`/view-work-order/${workOrderNameOrId}`, { state: { workOrderId, workOrderNumber } });
    };

    const handleDeleteMultipleWorkOrders = () => {
        handleDeleteWorkOrders({
            payload: selectedRows,
            setIsLoading: setDeleteLoading,
            next: () => {
                handleShowErrorAndWarning({ dispatch, message: "Work orders deleted successfully.", type: "success", showTime: "5000" });
                handleGetAllWorkOrders({ setterMethod: setWorkOrders, setIsLoading, pagination, filterParams });
                handleGetWorkOrdersCounts({ setterMethod: setWorkOrderStatuses, setIsLoading: setNavLoading });
                setSelectedRows([]);
                setDeleteWorkOrderAlert(false);
            }
        });
    };

    const handleEditWorkOrder = () => {
        navigate("/edit-work-order", { state: { workOrderId: selectedRows[0] } });
    };

    const handleFilterModelChange = useCallback((muiFilterModel) => {
        const converted = convertMuiFilterModelToApiParams(muiFilterModel);
        setFilterParams(converted);
        setPagination((prev) => ({ ...prev, page: 1 }));
    }, []);


    useEffect(() => {
        handleGetAllWorkOrders({
            setterMethod: setWorkOrders,
            setIsLoading,
            pagination,
            filterParams,
        });
    }, [pagination?.page, pagination?.limit, filterParams]);


    useEffect(() => {
        handleGetWorkOrdersCounts({ setterMethod: setWorkOrderStatuses, setIsLoading: setNavLoading });
    }, []);


    if (checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
        const URL = handleSegregateURL();

        return <>
            {(!URL?.unity && !URL?.AR && !URL?.VR) && (
                <ClonosGridNav isLoading={navLoading} items={[
                    { icon: AllChecklists,      iconBg: '#E7EFFF', title: 'Total Work Orders',     count: workOrderStatuses?.totalWorkOrders     || 0 },
                    { icon: Checks,             iconBg: '#EBFAEC', title: 'Completed Work Orders', count: workOrderStatuses?.completedWorkOrders || 0 },
                    { icon: PendingForApproval, iconBg: '#F7E9BF', title: 'Drafted Work Orders',   count: workOrderStatuses?.draftWorkOrders     || 0 },
                ]}>
                    <div className="d-fl-al-cen">
                        {checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) && (
                            <ClonosButton onClick={() => navigate("/create-work-order")} variant={"filled"}>
                                Create Work Order
                            </ClonosButton>
                        )}
                    </div>
                </ClonosGridNav>
            )}

            <Card
                variant="outlined"
                style={{
                    flex: 1,
                    margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem" : "0rem 1rem 1rem 1rem",
                    padding: "2.5rem 2rem",
                    borderRadius: "0rem 0rem 1rem 1rem",
                    height: "100vh"
                }}
            >
                <ClonosDataGrid
                    rows={setSerialNumber(workOrders?.data, pagination?.page, pagination?.limit)}
                    columns={columns}
                    isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
                    isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
                    uniqueIdField="id"
                    onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                    isLoading={isLoading}
                    totalCount={workOrders?.totalDataCount}
                    pageLimit={pagination.limit}
                    checkboxSelection={
                        checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) &&
                        checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })
                    }
                    handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                    filterMode="server"
                    handleFilterModelChange={handleFilterModelChange}
                    toolbar={true}
                />
            </Card>

            <ClonosConfirmationBox
                isOpen={deleteWorkOrderAlert}
                loading={deleteLoading}
                confirmingMethod={handleDeleteMultipleWorkOrders}
                closeModalMethod={setDeleteWorkOrderAlert}
                headerTitle="Delete Work Order"
                message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this work order" : "these work orders"}?`}
            />
        </>;
    }

    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
};

export default WorkOrderList;