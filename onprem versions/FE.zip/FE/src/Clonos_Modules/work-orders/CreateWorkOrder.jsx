import { Card } from "@material-ui/core"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS } from "../../Constants/Constant"
import { checkUserHasPermission, commonPageState, generateUniqueId, getCurrentDate, globalHandleIsAllRequiredFieldAvailable, handleGetHeightOrWidthBasedOnId, handleShowErrorAndWarning, setSerialNumber } from "../../utils/clonosCommon"
import ClonosInput from "../../components/CommonComponents/ClonosInput/ClonosInput"
import ClonosTextarea from "../../components/CommonComponents/ClonosTextarea/ClonosTextarea"
import ClonosSelect from "../../components/CommonComponents/ClonosSelect/ClonosSelect"
import DynamicDropdown from "../../components/CommonComponents/DynamicDropdown/DynamicDropdown"
import { ClonosButton} from "../../components/CommonComponents/Button/Button"
import { ClonosToggleButton } from "../../components/CommonComponents/ClonosToggleButton/ClonosToggleButton"
import Modal from "../../components/CommonComponents/Modal/Modal"
import Styles from "./work-order.module.css"
import useFieldsChecker from "../../CustomHooks/FieldsValidatorHook"
import { UnAuthorizedModal } from "../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"
import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { useEffect, useState } from "react"
import { useDispatch } from "react-redux"
import { useLocation, useNavigate } from "react-router-dom"
import { FaGreaterThan } from "react-icons/fa"
import searchIcon from "../../resources/svgs/searchIcon.svg"
import ClonosRadioAndCheckbox from "../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox"
import FileUploader from "../../components/CommonComponents/FileUploader/FileUploader"
import { handleCreateWorkOrder, handleDraftWorkOrder, handleGetFilledValuesOfWorkOrder, handleGetSingleWorkOrder, handleGetTasksDropdownData, handleGetWorkOrderPriorities, handleUpdateWorkOrder } from "./work-order-manager"
import { getDepartmentDropdownData, getTeamDropdownData, getUsersDropdownData } from "../../utils/UsersMethods/usersMethods"
import { handleGetAssets } from "../ClonosAssets/Utils/AssetsListMethods"
import { WorkOrderTasks } from "./components/work-order-taks/WorkOrderTasks"
import { CustmizedTeamDropdown } from "./components/custmized-team-dropdown/CustmizedTeamDropdown"
import { handleGetAssetDropdownData } from "../ClonosAssets/managers/asset-common-managers"
import TaskLibraryDropdown from "../TaskLibrary/Components/TaskLibraryDropdown/TaskLibraryDropdown"
import { MediaBlackStaticIcon } from "../../resources/icons/static/MediaBlackStaticICon"
import ClonosDocumentViewer from "../../components/CommonComponents/document-viewer/ClonosDocumentViewer"
import { ImagePreviewModal } from "../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal"
import { MediaBlueStaticIcon } from "../../resources/icons/static/MediaBlueStaticIcon"
import { handleUploadSingleFileAndGetId } from "../../utils/common-managers"
import { doGetApiCall, doPostApiCall } from "../../utils/ClonosApi"
import { IoIosClose } from "react-icons/io"
import { statusStyleStaticData } from "../../Constants/StaticData"


/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/
const CreateWorkOrder = ({mode}) => {
    const Location = useLocation();  
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [formData,setFormData] = useState({});
    const [searchedAssets,setSeachedAssets] = useState({});
    const [searchedUsers,setSeachedUsers] = useState({});
    const [serverResponse,setServerResponse] = useState({});
    const [departments,setDepartments] = useState([]);
    const [priorities,setPriorities] = useState([]);
    const [assets,setAssets] = useState({});
    const [teams,setTeams] = useState({});
    const [taskLibraryData,setTaskLibraryData] = useState({})
    const [teamsPagination,setTeamsPagination] = useState(commonPageState);
    const [assetsPagination,setAssetsPagination] = useState(commonPageState);
    const [assignees,setAssignees] = useState({});
    const [assigneesPagination,setAssigneesPagination] = useState(commonPageState);
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false,hookUniqueKey:"work-order"})
    const [cancelWorkOrderAlert,setCancelWorkOrderAlert] = useState(false);
    const [loadersAndFlags,setLoadersAndFlags] = useState({
        fetchTasksLoading:false,
        saveWorkOrderLoading:false,
        draftWorkOrderLoading:false,
        showImagePreviewModal:false,
        showRemarksPreviewModal:false,
        showDraftWorkOrderAlert:false,
        showCancelWorkOrderAlert:false,
        showCustmizedTeamDropdown:false,
        showAddFromTaskLibraryModal:false
    })
//     const [loadingDropdowns, setLoadingDropdowns] = useState({});
//    const [staticDropdownData,setStaticDropdownData]=useState({})

    const handleGetValues = (props) => {
        handleGetFilledValuesOfWorkOrder({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier})
    }

    const handleSubmitWorkOrder = () => {
        if(!handleSubmit()) return

      const emptyTask = formData?.tasks?.findIndex(t => !t.description?.trim());
      if (emptyTask !== -1) {
      handleShowErrorAndWarning({
      dispatch,
      message: `Please fill the description for Task: ${emptyTask + 1}.`,
      type: "error",
      showTime: "5000"
      });
      return;
      }

         
          // ✅ merge logic for documents
            const remainingServerDocs = formData?.documentsNeedToDelete?.length
            ? serverResponse?.documents?.filter(
                  (doc) => !formData?.documentsNeedToDelete?.includes(doc?.id)
                  )
            : serverResponse?.documents;

            const documentsToSave = [
            ...(remainingServerDocs || []),
            ...(formData?.documents || [])
            ];

            // ✅ final payload
            const finalPayload = {
            ...formData,
            documents: documentsToSave,
            };
        const next = () => {
            navigate("/work-orders");
            handleShowErrorAndWarning({dispatch,message:`Work Order ${mode === "created"? "created" : "updated"} successfully.`,type:"success",showTime:"5000"})
        }
        if(mode === "edit") {
            handleUpdateWorkOrder({payload:finalPayload,isDraftExisting: serverResponse?.status === "draft",setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveWorkOrderLoading:!prev.saveWorkOrderLoading})),next,workOrderId:Location?.state?.workOrderId})
        } else {
              handleCreateWorkOrder({payload:formData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveWorkOrderLoading:!prev.saveWorkOrderLoading})),next})
        }
    }

    const handleFetchAssetsOnScroll = () => {
            if(assets?.totalPageCount > assetsPagination?.page){
                  setAssetsPagination(prev => {
                        handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:{limit:prev?.limit,page:prev?.page + 1}})
                        return {...prev,page:prev?.page+1}
                  })
            }
    }

    const handleFetchUsersOnScroll = () => {
      if(assignees?.totalPageCount > assigneesPagination?.page){
            setAssigneesPagination(prev => {
                  getUsersDropdownData({setterMethod: setAssignees, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType",...assigneesPagination} })
                  return {...prev,page:prev?.page+1}
            })
      }
}

    const handleSearchAsset = ({input}) => {
      
      if(input.length){
            handleGetAssetDropdownData({setterMethod:setSeachedAssets,filterPayload:{...assetsPagination,name:input}})
      } else {
            setSeachedAssets({})
      }
    }

    const handleSeachUsers = ({input}) => {
     
      if(input.length){
            getUsersDropdownData({setterMethod: setSeachedUsers, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType",name:input,...assigneesPagination} })
      } else {
            setSeachedUsers({})
      }
    }

//   const fetchStaticDropdownByCode = async (code) => {
//   if (staticDropdownData[code] || loadingDropdowns[code]) return;

//   setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

//   try {
//     const res = await doGetApiCall({url:`dropdowns/${code}`});
       
//     setStaticDropdownData(prev => ({
//       ...prev,
//       [code]: res?.data?.result?.options
//     }));
//   } finally {
//     setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
//   }
// };

    useEffect(() => {
        if(formData?.department?.id || serverResponse?.department?.id){
            getTeamDropdownData({setterMethod: setTeams, dispatch, selectedDepartment: formData?.department?.id || serverResponse?.department?.id })
        }
    },[formData?.department?.id,serverResponse?.department?.id])

    useEffect(() => {
      handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:assetsPagination})
    },[assetsPagination?.page,assetsPagination?.limit])
    
    useState(() => {
        getUsersDropdownData({ pagination:assigneesPagination?.pagination, setterMethod: setAssignees, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType"} })
    },[assigneesPagination?.page,assigneesPagination?.limit])
   
    console.log(formData,"formData")

    useEffect(() => {
      if(mode === "edit") {
            handleGetSingleWorkOrder({setterMethod:setServerResponse,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,fetchWOLoading:!prev.fetchWOLoading})),workOrderId:Location?.state?.workOrderId,setFormData})
      }
      
      handleGetWorkOrderPriorities({setterMethod:setPriorities})
      getDepartmentDropdownData({setterMethod:setDepartments,dispatch});
    },[])
 
    if (checkUserHasPermission({ moduleName: "workOrders", action: CLONOS_GLOBAL_ACTION_CREATE }))
        return (
              <>
                    <nav className={Styles.work_order_nav} /** c = customize */ >
                          <div className={Styles.work_order_nav_first_child}>
                                <b>Status:</b>
                                {
                                      ["Draft", "Scheduled", "Accepted", "Completed"].map((element, index) => {
                                            if (index > 0) return <div> <FaGreaterThan /> <span style={{color:mode === "edit" && serverResponse?.status === element.toLocaleLowerCase() ? statusStyleStaticData?.[element?.toLocaleLowerCase()]?.color : ""}}>{element}</span></div>
                                            return <span style={{color:serverResponse?.status === element.toLocaleLowerCase() ? statusStyleStaticData?.[element?.toLocaleLowerCase()]?.color : ""}}>{element}</span>

                                      })
                                }
                          </div>
                          {/* <div className={Styles.work_order_nav_second_child}>
                                <div className={Styles.work_order_nav_second_child_current_date}><b>Created On :</b> <span>{getCurrentDate()}</span></div>
                          </div> */}
                    </nav>
                    <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                          <section className={Styles.work_order_content_body}>
                                <div id='work_order_first_child_container' className={Styles.work_order_first_child_container}>
                                      <ClonosInput
                                            tabIndex={1}
                                            label="Work Order Title"
                                            isLabel={true}
                                            placeholder="Work Order Title"
                                            isMandatory={true}
                                            type="text"
                                            limit='100'
                                            uniqueKey="name"
                                            defaultValue={serverResponse?.name}
                                            handleGetValues={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                      />
                                      <ClonosRadioAndCheckbox
                                        isLabel={true}
                                        uniqueKey="isWorkPermitRequired"
                                        label="Require work permit"
                                        defaultValue={serverResponse?.isWorkPermitRequired}
                                        isChecked={serverResponse?.isWorkPermitRequired}
                                        handleGetValues={handleGetValues}
                                      />
                                      <ClonosTextarea
                                            tabIndex={2}
                                            label="Description"
                                            isLabel={true}
                                            placeholder="Description"
                                            type="text"
                                            limit='1000'
                                            defaultValue={serverResponse?.description}
                                            uniqueKey="description"
                                            handleGetValues={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                      />
                                      <ClonosSelect
                                            tabIndex={3}
                                            type="select"
                                            label="Department"
                                            isMandatory={true}
                                            isLabel={true}
                                          //   disabled={mode === "edit"}
                                            disabled={mode === "edit" && serverResponse?.status !== "draft"}
                                            uniqueKey="department"
                                            placeholder="Select"
                                            defaultValue={serverResponse?.department?.name}
                                            options={departments?.map(department => ({label:department?.name,value:department?.id,isNeeded:true}))}
                                          //   handleGetValues={handleGetValues}
                                           handleGetValues={(props) => {
                                                handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData });
                                              
                                                
                                               props?.updatedValue?.value && 
                                                getUsersDropdownData({
                                                pagination: assigneesPagination?.pagination,  // optional
                                                setterMethod: setAssignees,
                                                dispatch,
                                                filterPayload: { selectFields: "name,employeeId" },
                                                departments: props?.updatedValue?.value
                                                })


                                                }}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}

                                      />
                                       
                                      <ClonosSelect
                                            tabIndex={4}
                                            type="select"
                                            label="Priority"
                                            isMandatory={true}
                                            isLabel={true}
                                            uniqueKey="priority"
                                            placeholder="Select"
                                            defaultValue={serverResponse?.priority}
                                            options={priorities?.map(priority => ({label:priority,value:priority,isNeeded:true}))}
                                          //   options={staticDropdownData?.priority?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true })) ||[]}
                                          //   onOpen={() => fetchStaticDropdownByCode("priority")} 
                                            handleGetValues={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                      />

                                      <DynamicDropdown
                                            label="Asset"
                                            tabIndex={5}
                                            isAsset={true}
                                            isLabel={true}
                                            title={"Asset"}
                                            url={searchIcon}
                                            uniqueKey="asset"
                                            isCheckbox={false}
                                            isActivator={true}
                                            isMandatory={true}
                                            isSearchable={true}
                                          //   isDynamicLoad={true}
                                            isDynamicLoad={assets?.totalPageCount > assetsPagination?.page}
                                            
                                            type="dynamicDropdown"
                                            placeholder={"Search"}
                                          //   disabled={mode === "edit"}
                                            disabled={mode === "edit" && serverResponse?.status !== "draft"}
                                            populatedFields={["number"]}
                                            labelActivator={"Asset Name"}
                                            handleGetValues={handleGetValues}
                                            handleDynamicSearch={handleSearchAsset}
                                            handleMoreData={handleFetchAssetsOnScroll}
                                            defaultValue={mode === "edit" ? [{name:serverResponse?.asset?.generalDetails?.name,id:serverResponse?.asset?.id}] : null}
                                            heading={"Select from Asset Library"}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            data={searchedAssets?.data ? searchedAssets?.data : assets?.data || []}
                                      />

                                      <div className={Styles.work_order_fc_date_and_time}>
                                            <ClonosInput
                                                  tabIndex={6}
                                                  label="Start Date"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="date"
                                                  isMinimum={true}
                                                  uniqueKey="startAt"
                                                  min={true}
                                                //   disabled={mode === "edit"}
                                                  disabled={mode === "edit" && serverResponse?.status !== "draft"}
                                                  defaultValue={serverResponse?.startAt}
                                                  handleGetValues={handleGetValues}
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />
                                            <ClonosInput
                                                  tabIndex={7}
                                                  label="End Date"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="date"
                                                  isMinimum={true}
                                                  uniqueKey="endAt"
                                                  disabled={(mode === "edit" || formData?.startAt?.length > 0)  ? false : true}
                                                  min={mode === "edit" ? serverResponse?.startAt : formData?.startAt}
                                                  defaultValue={serverResponse?.endAt}
                                                  handleGetValues={handleGetValues}
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />
                                      </div>
                                      <div className={Styles.work_order_fc_date_and_time}>
                                            <ClonosInput
                                                  tabIndex={8}
                                                  label="Estimation Days"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="number"
                                                  uniqueKey="estimatedDays"
                                                  placeholder="Estimation Days"
                                                  handleGetValues={handleGetValues}
                                                  defaultValue={serverResponse?.estimatedDays }
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />

                                            <ClonosInput
                                                  tabIndex={9}
                                                  label="Hours"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="number"
                                                  uniqueKey="estimatedHours"
                                                  placeholder="Hours"
                                                  range={[0, 23]}
                                                  defaultValue={mode === "edit" ? (serverResponse?.estimatedHours ?? "") : ""}
                                                  handleGetValues={handleGetValues}
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />
                                      </div>
                                      <ClonosToggleButton
                                          label="Add To Asset History"
                                          labelPosition="left"
                                          type="toggle"
                                          uniqueKey="addToAssetHistory"
                                          // disabled={mode === "edit" ? true : false}
                                          disabled={mode === "edit" && serverResponse?.status !== "draft"}
                                          // disabled={true}
                                          checked={serverResponse.addToAssetHistory}
                                          // defaultValue={mode === "edit" && (serverResponse?.addToAssetHistory)}
                                          handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData })}
                                          />

                                      <DynamicDropdown
                                            tabIndex={10}
                                            isUser={true}
                                            isLabel={true}
                                            label="Assignee"
                                            url={searchIcon}
                                            isCheckbox={false}
                                            isActivator={true}
                                            isMandatory={true}
                                            title={"Assignee"}
                                            isSearchable={true}
                                            uniqueKey="assignees"
                                          //   isDynamicLoad={true}
                                            isDynamicLoad={assignees?.totalPageCount > assigneesPagination?.page}
                                            placeholder={"Search"}
                                            type="dynamicDropdown"
                                            labelActivator={"User Name"}
                                            populatedFields={["userType"]}
                                            handleGetValues={handleGetValues}
                                            handleMoreData={handleFetchUsersOnScroll}
                                            handleDynamicSearch={handleSeachUsers}
                                            defaultValue={serverResponse?.assignees || ""}
                                            heading={"Select from Users Library"}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            data={searchedUsers?.data ? searchedUsers?.data.map(user => ({id:user?.id,name:user?.name,userType:user?.userType?.name})) : assignees?.data?.map(user => ({id:user?.id,name:user?.name,userType:user?.userType?.name}))}
                                      />
                                    <div>
                                      <DynamicDropdown
                                            isLabel={true}
                                            label="Team"
                                            tabIndex={11}
                                            title={"Team"}
                                            uniqueKey="existingTeams"
                                            labelActivator={"Team Name"}
                                            heading={"Select from Team Library"}
                                            placeholder={"Search"}
                                            isSearchable={true}
                                            isCheckbox={true}
                                          //   disabled={!Boolean(formData?.department?.id || serverResponse?.department?.id)}
                                          disabled={!(serverResponse?.status === "draft" || formData?.department?.id || serverResponse?.department?.id)}

                                            isDynamicLoad={false}
                                            type="dynamicDropdown"
                                            data={setSerialNumber(teams?.data,teamsPagination?.pagination?.page,teamsPagination?.limit)}
                                            isActivator={true}
                                            isMandatory={false}
                                            url={searchIcon}
                                            stopOverlayCloser={true}
                                            // handleMoreData={handleMoreData}
                                            handleNext={() => {
                                                setLoadersAndFlags(prev => ({...prev,showCustmizedTeamDropdown:true}))
                                            }}
                                            defaultValue={serverResponse?.existingTeams?.length ? serverResponse?.existingTeams : []}
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please select teams and members required!"}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}

                                      />
                                      <div className={Styles.local_team_preview}>
                                          {
                                          //     !formData?.localTeams?.length ? serverResponse?.localTeams?.map(team => {
                                          //       return <div className={Styles.preview_tab}>
                                          //             <p>{`Local Team-${team?.name} - ${team.noOfMembersRequired}`}</p>
                                          //             <IoIosClose fontSize={"23px"} onClick={() => setServerResponse(prev => ({...prev,localTeams:prev?.localTeams?.filter(el => el?.key !== team?.key)}))}/>
                                          //       </div>
                                          //     })  :
                                               formData?.localTeams?.map(team => {
                                                return <div className={Styles.preview_tab}>
                                                <p>{`Local Team-${team?.name} - ${team.noOfMembersRequired}`}</p>
                                                <IoIosClose fontSize={"23px"} onClick={() => setFormData(prev => ({...prev,localTeams:prev?.localTeams?.filter(el => el?.key !== team?.key)}))}/>
                                          </div>
                                              })
                                          }
                                      </div>
                                    </div>  
                                </div>

                                <div className={Styles.work_order_second_child_container}>
                                      <div>
                                          <div className={Styles.media_wrapper}>
                                                <div onClick={() => setLoadersAndFlags(prev => ({...prev,showImagePreviewModal:true}))}>
                                                      {(formData?.images?.length || serverResponse?.images?.length) ? <MediaBlueStaticIcon/> : <MediaBlackStaticIcon/>}
                                                      <span style={{color:(formData?.images?.length || serverResponse?.images?.length) ? "#0A5FFF" : "#000"}}>{(formData?.images?.length || serverResponse?.images?.length) ? "View Images" :"Add Images"}</span>
                                                </div>
                                                {/* <div onClick={() => setLoadersAndFlags(prev => ({...prev,showRemarksPreviewModal:true}))}>
                                                      {formData?.images?.length ? <MediaBlueStaticIcon/> : <MediaBlackStaticIcon/>}
                                                      <span style={{color:formData?.remarks?.length ? "#0A5FFF" : "#000"}}>{formData?.remarks?.length ? "View Remark":"Add Remarks"}</span>
                                                </div> */}
                                          </div>
                                          <WorkOrderTasks setFormData={setFormData} formData={formData} serverResponse={serverResponse}/>
                                          <FileUploader
                                                tabIndex={12}
                                                label="Documents"
                                                uniqueKey="documents"
                                                typeOfRecord={"Files"}
                                                title="Documents"
                                                isMandatory={false}
                                                limit={10}
                                                fileSizeInMB={10}
                                                acceptableFileTypes={[".jpg", ".jpeg", ".pdf", ".docs"]}
                                                handleGetSelectedData={handleGetValues}
                                                defaultValue={serverResponse?.documents}
                                          />
                                      </div>
                                      <div className={Styles.work_order_second_child_submit}>
                                            <div>
                                                  <ClonosButton
                                                        variant="outlined"
                                                        onClick={() => setLoadersAndFlags(prev => ({...prev,showCancelWorkOrderAlert:true}))}>Cancel</ClonosButton>
                                                  
                                                  {(mode === "create" || serverResponse?.status === "draft") && <ClonosButton  variant="outlined" onClick={() => setLoadersAndFlags(prev => ({...prev,showDraftWorkOrderAlert:true}))}>Save as Draft</ClonosButton>}       
                                                  <ClonosButton
                                                        loading={loadersAndFlags?.saveWorkOrderLoading}
                                                        variant="filled"
                                                        onClick={handleSubmitWorkOrder}
                                                    > 
                                                    {/* {mode === "edit" ? "Update" : "Submit"} */}
                                                    {mode === "edit" ? "Update" : "Submit"}
                                                    </ClonosButton>
                                            </div>
                                      </div>
                                </div>
                          </section >
                    </Card> 
                     <ClonosConfirmationBox
                          isOpen={loadersAndFlags?.showDraftWorkOrderAlert}
                          confirmingMethod={() => {  
                              const next = () => {
                                    setLoadersAndFlags(prev => ({...prev,showDraftWorkOrderAlert:false}));
                                    navigate('/work-orders')
                              };
                              handleDraftWorkOrder({dispatch,payload:formData,workOrderId: Location?.state?.workOrderId,isDraftExisting: serverResponse?.status === "draft" ,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,draftWorkOrderLoading:!prev.draftWorkOrderLoading})),next})
                          }}
                          
                          loading={loadersAndFlags?.draftWorkOrderLoading}
                          closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showDraftWorkOrderAlert:false}))}
                          headerTitle="Draft Work Order"
                          message="Are you sure, You want to draft this work order ?"
                    />
                    <ClonosConfirmationBox
                          isOpen={loadersAndFlags?.showCancelWorkOrderAlert}
                          confirmingMethod={() => {
                                setLoadersAndFlags(prev => ({...prev,cancelWorkOrderAlert:false}));
                                navigate('/work-orders')
                          }}
                          closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showCancelWorkOrderAlert:false}))}
                          headerTitle="Work Order Creation."
                          message="Do you confirm that you are want to cancel the work order creation?"
                    />
                    <CustmizedTeamDropdown isOpen={loadersAndFlags.showCustmizedTeamDropdown} localTeamsFromServer={serverResponse?.localTeams || []} existingTeams={mode === "create" ? formData?.existingTeams : !formData?.existingTeams?.length ? serverResponse?.existingTeams : formData?.existingTeams} formData={formData} setFormData={setFormData} closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showCustmizedTeamDropdown:false}))}/>
                    <ImagePreviewModal images={[...(serverResponse?.images || []),...(formData?.images || [])]} open={loadersAndFlags.showImagePreviewModal} closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showImagePreviewModal:!prev.showImagePreviewModal}))} uploadOption={true} getUploadedDetails={(val) => setFormData(prev => ({...prev,images:val?.files}))}/> 
              </>

        )

  return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default CreateWorkOrder