// import React from 'react'
// import Styles from "./view-work-order.module.css"
// import Modal from '../../../components/CommonComponents/Modal/Modal'
// import useToggler from '../../../CustomHooks/TogglerHook'
// import CloseIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'

// const PartsAndToolsCreateComp = ({ data, workOrderDetails }) => {
//   const [isOpen, setIsOpen] = useToggler();
//   console.log(workOrderDetails,"workorderdetailskey")
//   // Function to render the appropriate table rows based on data structure
//   const renderTableRows = (key) => {
//     // Special handling for partReplaced which has a different structure
//     if (key === 'partsReplaced' && workOrderDetails['partReplaced']) {
//       return workOrderDetails['partReplaced'].map((part, index) => {
//         return (
//           <tr key={part.id || index}>
//             <td className={Styles.table_cell}>{part.spare?.name || 'N/A'}</td>
//             <td className={Styles.table_cell_quantity}>{part.quantity || 0}</td>
//           </tr>
//         );
//       });
//     }

//     // Regular handling for other fields
//     if (workOrderDetails[key]) {
//       return workOrderDetails[key].map((part, index) => {
//         return (
//           <tr key={part.id || index}>
//             <td className={Styles.table_cell}>{part.name || 'N/A'}</td>
//             <td className={Styles.table_cell_quantity}>{part.quantity || 0}</td>
//           </tr>
//         );
//       });
//     }
//     return null;
//   };

//   // Function to check if data exists to display
//   const hasData = (key) => {
//     if (key === 'partsReplaced') {
//       return workOrderDetails['partReplaced'] && workOrderDetails['partReplaced'].length > 0;
//     }
//     return workOrderDetails[key] && workOrderDetails[key].length > 0;
//   };

//   return (
//     <>
//       <div key={data?.id} className={Styles.wov_bs_c3_repeatedItem}>
//         <header><span>{data?.heading}</span></header>
//         <div className={Styles.wov_bs_c3_repeatedItem_body}>
//           {/* <span className={Styles.item_title}>{data.title}</span> */}
//           {hasData(data?.key) ? (
//             <div className={Styles.wov_bs_c3_repeatedItem_table_wrapper}>
//               <table className={Styles.parts_table}>
//                 <thead>
//                   <tr className={Styles.table_row}>
//                     <th className={Styles.table_header}>Name</th>
//                     <th className={Styles.table_header_quantity}>Quantity</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {renderTableRows(data?.key)}
//                 </tbody>
//               </table>
//             </div>
//           ) : (
//             <p className={Styles.no_parts_message}>No Parts Added</p>
//           )}
//         </div>
//       </div>
//     </>
//   )
// }

// export default PartsAndToolsCreateComp

import React, { useState,useEffect } from 'react'
import Styles from "./view-work-order.module.css"
import Modal from '../../../components/CommonComponents/Modal/Modal'
import useToggler from '../../../CustomHooks/TogglerHook'
import ClonosInput from '../../../components/CommonComponents/ClonosInput/ClonosInput'
import CloseIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import WO_Plus_Icon from "../../../assets/UIUX/icons/WO/WO_Plus.svg"
import { CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant'
import { handleLoggedInUser } from '../../../utils/clonosCommon'
import DynamicDropdown from '../../../components/CommonComponents/DynamicDropdown/DynamicDropdown'
import useFieldsChecker from '../../../CustomHooks/FieldsValidatorHook'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import ClonosSelect from '../../../components/CommonComponents/ClonosSelect/ClonosSelect'
import { handleGetSpares,handlePartRequested,handlePartReplaced, handleGetWorkorderPartsRequested ,handleGetApprovedPartsRequestSpare,handleGetWorkorderPartsReplaced, handleToolsRequested, handleConsumablesRequested} from './view-work-order-manager'
import { commonPageState ,setSerialNumber} from '../../../utils/clonosCommon'
import { handleGetFilledValuesOfWorkOrder } from '../work-order-manager'
import FileUploader from '../../../components/CommonComponents/FileUploader/FileUploader'
import { handleShowErrorAndWarning } from '../../../utils/clonosCommon'
import { useDispatch } from 'react-redux'
import ClonosDataGrid from '../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { statusStaticData,statusStyleStaticData } from '../../../Constants/StaticData'
import { MediaBlueStaticIcon } from '../../../resources/icons/static/MediaBlueStaticIcon'
import { ImagePreviewModal } from '../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal'
import { useLocation } from 'react-router-dom'
import ClonosAlertBox from '../../../components/CommonComponents/ClonosAlertBox/ClonosAlertBox'

const PartsAndToolsCreateComp = ({ data,workOrderDetails,onChildRefresh}) => {
    const dispatch =useDispatch()
    const location=useLocation()
    const [isOpen, setIsOpen] = useToggler();
    const [isLoading, setIsLoading] = useToggler(); 
    const [sparesDetails,setSparesDetails]=useState([])
    const [refreshApi,setRefreshApi]=useToggler()
    const [searchedSpare,setSearchedSpare]=useState({})
    const [pagination, setPagination] = useState(commonPageState);
    const [selectedRows, setSelectedRows] = useState([]);
    const [selectedPartImages,setSelectedPartImages]=useState([])
    const [formData,setFormData]=useState({})
    const [partsRequired,setPartsRequired]=useState([])
    const [partsReplaced,setPartsReplaced]=useState({})
    const [approvedPartsRequestDropdownData,setApprovedPartsRequestDropdownData] =useState({})
    const [requestedQuantity, setRequestedQuantity] = useState('');
    const [utilizedCount,setUtilizedCount]=useState('')

 
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false,hookUniqueKey:"work-order"})
    const [loadersAndFlags,setLoadersAndFlags] = useState({
            saveSpareRequestLoading:false,
            saveSpareReplacedLoading:false,
            getPartsRequiredLoading:false,
            getApprovedPartsRequiredLoading:false,
            getPartsReplacedLoading:false,
            showPartsReplacedImagePreview:false,
            saveToolsRequestLoading:false,
            saveconsumablesRequestLoading:false,
            showRemarkModal:false,
            currentRemark: ""
        })


    const availableQuantity= requestedQuantity - utilizedCount 
    const selectedSpare = formData?.name?.[0]; // already has {id, name, quantity}
    const availableQty = Number(selectedSpare?.quantity ?? 0);
    const requestedQty = Number(formData?.requestedQuantity ?? 0);
       
     const spareData = searchedSpare?.data? searchedSpare.data : sparesDetails?.data || [];
      const formattedSpareDropdownData = spareData.map(spare => ({
        name: spare?.name,
        quantity:spare?.quantity,
        id: spare?.id,
        isNeeded: true
      }));
    
     const approvePartsRequestedSpareData = searchedSpare?.data? searchedSpare.data : approvedPartsRequestDropdownData?.data || [];

     const formattedApprovedSpareDropdownData = approvePartsRequestedSpareData?.map(item =>({
        id:item.id,
        spareId:item?.spareId,
        name:item?.name,
        utilizedCount:item?.utilizedCount,
        isNeeded:true
    }));
 
    const handleGetValues = (props) => {
  
    handleGetFilledValuesOfWorkOrder({fieldProps: props,primaryObject,setFormData,handlePrimaryObjectModifier});

        // Get selected spare name
        const selectedSpareRequestId = props?.updatedValue?.[0]?.id;
         
        if(props?.updatedValue === null){
            setRequestedQuantity(prev => ({
            ...prev,
            requestedQuantity: '',
            }));
          return; // Exit early to avoid further execution
        }
    
    

        if (selectedSpareRequestId) {
            const matchedPart = approvedPartsRequestDropdownData?.data?.find(
            (spare) => spare?.id === selectedSpareRequestId
            );
         
            setFormData(prev => ({
            ...prev,
            requestedQuantity: matchedPart?.id,
            requestedQuantityValue: matchedPart?.requestedQuantity
            }));
            
            setRequestedQuantity(matchedPart?.requestedQuantity?? '');
            setUtilizedCount(matchedPart?.utilizedCount)
        } 

          

        
        };

   function getSuccessMessage(modal) {
      switch (modal) {
        case "spareRequested":
          return "Spare Requested successfully.";
        case "spareReplaced":
          return "Spare Replaced successfully.";
        case "toolsRequested":
          return "Tool Requested successfully.";
        case "consumablesRequested":
          return "Consumable Requested successfully.";
        default:
          return "Action completed successfully.";
      }
    }

    const handleSave=(modal)=>{
         if(!handleSubmit()) return
         
         if(Number(formData?.replacedQuantity) > Number(formData?.requestedQuantityValue) ){
            return handleShowErrorAndWarning({dispatch,message:"Replaced Spares quantity should be less than requested quantity" ,type:"error",showTime:"5000"})
         }

            const next = (res,err) => {
             
                setIsOpen()
                setRefreshApi()
                if(res.status==201){
                      handleShowErrorAndWarning({dispatch,message: getSuccessMessage(modal),type:"success",showTime:"5000"})
                      onChildRefresh()
                    }else{
                    handleShowErrorAndWarning({dispatch,message:err?.response?.data?.message ,type:"success",showTime:"5000"})
                }
                
            }
          if(modal =="spareRequested") {
            handlePartRequested({payload:formData,workOrderId:workOrderDetails?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveSpareRequestLoading:!prev.saveSpareRequestLoading})),next})
          }else if(modal =="spareReplaced"){ 
            handlePartReplaced({ payload:formData,workOrderId:workOrderDetails?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveSpareReplacedLoading:!prev.saveSpareReplacedLoading})),next})
          }
          else if(modal =="toolsRequested"){ 
            handleToolsRequested({ payload:formData,workOrderId:workOrderDetails?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveToolsRequestLoading:!prev.saveToolsRequestLoading})),next})
          }
           else if(modal =="consumablesRequested"){ 
            handleConsumablesRequested({ payload:formData,workOrderId:workOrderDetails?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveconsumablesRequestLoading:!prev.saveconsumablesRequestLoading})),next})
          }


        }

    useEffect(()=>{
      
        handleGetSpares({setterMethod:setSparesDetails,filterPayload:{...pagination, status: "approved"}});
        // handleGetWorkorderPartsRequested({setterMethod:setPartsRequired,workOrderId:workOrderDetails?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,getPartsRequiredLoading:!prev.getPartsRequiredLoading}))})
         handleGetApprovedPartsRequestSpare({setterMethod:setApprovedPartsRequestDropdownData,workOrderId:location?.state?.workOrderId,filterPayload:{status: "approved"},setIsLoading:() => setLoadersAndFlags(prev => ({...prev,getApprovedPartsRequiredLoading:!prev.getApprovedPartsRequiredLoading})) } )
        //handleGetWorkorderPartsReplaced({setterMethod:setPartsReplaced,workOrderId:workOrderDetails?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,getPartsReplacedLoading:!prev.getPartsReplacedLoading}))})
    
    },[pagination?.page,pagination?.limit,refreshApi])
     
    const handleMoreSpareData = () => {
        if(sparesDetails?.totalPageCount > pagination?.page){
            setPagination(prev =>{
                handleGetSpares({setterMethod:setSparesDetails,filterPayload:{limit:prev?.limit,page:prev?.page + 1}})
                return {...prev,page:prev?.page+1}
            })
        }
    }  

   const handleMoreApprovedSpareData =()=>{
        if(approvedPartsRequestDropdownData?.totalPageCount > pagination?.page){
            setPagination(prev =>{
                handleGetApprovedPartsRequestSpare({setterMethod:setApprovedPartsRequestDropdownData,filterPayload:{limit:prev?.limit,page:prev?.page + 1}})
                return {...prev,page:prev?.page+1}
            })
        }
   } 
   const handleSearchSpareName = (props) => {
        const {uniqueKey,input} = props;
       
 
         if(input.length){
             handleGetSpares({setterMethod:setSearchedSpare, filterPayload: {
                limit: pagination.limit || 15,
                page: 1, // Reset page to 1 for search
                name: input,
                status: "approved"
            }
        })
         }else {
            setSearchedSpare({})
      }
    }	


  const handleSearchPartsRequested = (props) => {
        const {uniqueKey,input} = props;
       
        
         if(input.length){
             handleGetApprovedPartsRequestSpare({setterMethod:setSearchedSpare,workOrderId:workOrderDetails?.id, 
                setIsLoading:() => setLoadersAndFlags(prev => ({...prev,getApprovedPartsRequiredLoading:!prev.getApprovedPartsRequiredLoading})),
                filterPayload: {
                limit: pagination.limit || 15,
                page: 1, // Reset page to 1 for search
                name: input,
                status: "approved"
            }
        })
         }else {
            setSearchedSpare({})
      }
    }	
    
    


     const headingToButton = {
      "Spare Requested": "Add Spare",
      "Spare Replaced":"Add Spare",
      "Tools Required": "Add Tools",
      "Consumables": "Add Consumables",
    };
    const isOperator = handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR;
    const isActiveWO = workOrderDetails?.status !== "expired" && workOrderDetails?.status !== "scheduled" && workOrderDetails?.status !== "completed";;
    const btnText = headingToButton[data?.heading];
    return (
        <>
            <div key={data?.id} className={Styles.wov_bs_c3_repeatedItem}>
                <header className={Styles.wov_header}>
                  <span className={Styles.wov_header_title}>{data?.heading}</span>
                  {/* {handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR && workOrderDetails?.status !== 'expired'&& workOrderDetails?.status !== 'scheduled' && data?.heading !="Tools Required" && data?.heading !="Consumables" &&(
                    <button className={Styles.wov_plain_button} onClick={() => setIsOpen(prev => !prev)}>
                      <img src={WO_Plus_Icon} alt={data?.heading} />
                      Add Spare
                    </button>
                  )} */}
                  {isOperator && isActiveWO && btnText && (
                    <button className={Styles.wov_plain_button} onClick={() => setIsOpen(prev => !prev)}>
                      <img src={WO_Plus_Icon} alt={data?.heading} />
                      {btnText}
                    </button>
                  )}
                  
                 </header>

                <div className={Styles.wov_bs_c3_repeatedItem_body}>
                    
                    


{ data?.heading === "Spare Requested" ? (
  Array.isArray(workOrderDetails?.spareRequested) && workOrderDetails?.spareRequested?.length > 0 ? (
    <div className={Styles.table_wrapper}>
      <table className={Styles.custom_table}>
        <thead>
          <tr>
            <th>SI.No</th>
            <th>SPARE NAME</th>
            <th>QTY</th>
            <th>REMARKS</th>
            <th>STATUS</th>
          </tr>
        </thead>
        <tbody>
          {workOrderDetails?.spareRequested?.map((row, index) => (
            <tr key={row.id}>
              <td>{index + 1}</td>
              <td>{row?.spare?.name || "-"}</td>
              <td>
                {row?.requestedQuantity
                  ? `${row.requestedQuantity} ${row?.spare?.units || ""}`
                  : "-"}
              </td>
              {/* <td>{row?.remarks || "-"}</td> */}
              <td
                onClick={() =>
                  setLoadersAndFlags({
                    ...loadersAndFlags,
                    showRemarkModal: true,
                    currentRemark: row?.remarks || "No remarks available.",
                  })
                }
              >
               <span className={Styles.view_remarks_btn}>View Remarks</span>
              </td>
              <td>
                <p
                  style={{
                    ...statusStyleStaticData[row?.status],
                    padding: "0.25rem 0.5rem",
                    borderRadius: "0.25rem",
                    cursor: "default",
                  }}
                >
                  {row?.status ? statusStaticData[row?.status] : "-"}
                </p>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ) : (
    <p>No Spare Added</p>
  )
) : null}



                    {data?.heading === "Spare Replaced" ? (
                      Array.isArray(workOrderDetails?.spareReplaced) && workOrderDetails?.spareReplaced?.length > 0 ? (
                        <div className={Styles.table_wrapper}>
                          <table className={Styles.custom_table}>
                            <thead>
                              <tr>
                                <th>SI.No</th>
                                <th>SPARE NAME</th>
                                <th>REQUESTED QTY</th>
                                <th>REPLACED QTY</th>
                                <th>REMARKS</th>
                                <th>IMAGES</th>
                              </tr>
                            </thead>
                            <tbody>
                              {workOrderDetails?.spareReplaced?.map((row, index) => (
                                <tr key={row.id}>
                                  <td>{index + 1}</td>
                                  <td>
                                    {`${row?.spare?.name || ""} ${row?.spare?.specification || ""}`}
                                  </td>
                                  <td>
                                    {row?.spareRequested?.requestedQuantity
                                      ? `${row.spareRequested.requestedQuantity} ${row?.spare?.units || ""}`
                                      : "-"}
                                  </td>
                                  <td>
                                    {row?.replacedQuantity
                                      ? `${row.replacedQuantity} ${row?.spare?.units || ""}`
                                      : "-"}
                                  </td>
                                  {/* <td>{row?.remarks || "-"}</td> */}
                                 <td
                                    onClick={() =>
                                      setLoadersAndFlags({
                                        ...loadersAndFlags,
                                        showRemarkModal: true,
                                        currentRemark: row?.remarks || "No remarks available.", // 👈 save remark
                                      })
                                    }
                                    style={{ color: "blue", textDecoration: "underline", cursor: "pointer" }}
                                  >
                                      <span className={Styles.view_remarks_btn}>View Remarks</span>
                                  </td>
                                  <td>
                                    {row?.images?.length ? (
                                      <p
                                        className={Styles.view_images_btn} // 👈 same approach as STATUS in Spare Requested
                                        onClick={() => {
                                          setSelectedPartImages(row?.images || []);
                                          setLoadersAndFlags((prev) => ({
                                            ...prev,
                                            showPartsReplacedImagePreview:
                                              !prev.showPartsReplacedImagePreview,
                                          }));
                                        }}
                                      >
                                        <MediaBlueStaticIcon />
                                        View Images
                                      </p>
                                    ) : (
                                      "-"
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p>No Spare Added</p>
                      )
                    ) : null}


                    {data?.heading === "Tools Required" ? (
                      Array.isArray(workOrderDetails?.toolsRequired) && workOrderDetails?.toolsRequired.length > 0 ? (
                        <div className={Styles.table_wrapper}>
                          <table className={Styles.custom_table}>
                            <thead>
                              <tr>
                                <th>SI.No</th>
                                <th>Tool NAME</th>
                                <th>Quantity</th>
                              </tr>
                            </thead>
                            <tbody>
                              {workOrderDetails?.toolsRequired?.map((row, index) => (
                                <tr key={row.id || index}>
                                  <td>{index + 1}</td>
                                  <td>{row?.name || "-"}</td>
                                  <td>{row?.quantity || "-"}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p>No Tools Added</p>
                      )
                    ) : null}

                    {data?.heading === "Consumables" ? (
                      Array.isArray(workOrderDetails?.consumables) && workOrderDetails?.consumables.length > 0 ? (
                        <div className={Styles.table_wrapper}>
                          <table className={Styles.custom_table}>
                            <thead>
                              <tr>
                                <th>SI.No</th>
                                <th>Tool NAME</th>
                                <th>Quantity</th>
                              </tr>
                            </thead>
                            <tbody>
                              {workOrderDetails?.consumables?.map((row, index) => (
                                <tr key={row.id || index}>
                                  <td>{index + 1}</td>
                                  <td>{row?.name || "-"}</td>
                                  <td>{row?.quantity || "-"}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p>No Consumables Added</p>
                      )
                    ) : null}

                    

                    {/* <span>{data.title}</span> */}
                    {/* {
                        partsRequired?.data?.length ? 
                        <div className={Styles.wov_bs_c3_repeatedItem_table_wrapper}>
                            <table>
                                <thead>
                                    <th>
                                        <td>SI.No</td>
                                        <td>Spare Name</td>
                                        <td>Quantity</td>
                                        <td>Remarks</td>
                                        <td>Status</td>
                                    </th>
                                </thead>
                                <tbody>
                                    {
                                        partsRequired.data?.map((part) => {
                                            return <tr>
                                                <td>{part?.spare?.name}</td>
                                                <td>{part?.spare?.quantity}</td>
                                            </tr>
                                        })
                                    }
                                </tbody>
                            </table>
                        </div> 
                        : <p style={{width:"100%",textAlign:"center",color:"#666666"}}>No Parts Added</p>
                    } */}
                </div>
            </div>
           
           {
            data?.heading === "Spare Requested" && (
                <Modal isOpen={isOpen} closeModalMethod={setIsOpen}>
                <div className={Styles.wov_modal_container}>
                    {/* Header */}
                    <header className={Styles.wov_modal_header}>
                    <span className={Styles.wov_modal_heading}>
                        {"Spare Request" || "Not Mentioned"}
                    </span>
                    <CloseIcon onClick={() => setIsOpen(false)} />
                    </header>
                    <div className={Styles.wov_modal_avlqty}>
                      <span> 
                           Present Quantity:&nbsp; {formData?.name?.[0]?.name ? availableQty : '-'}
                      </span> 
                    </div>
                    
                    {/* Modal Body Section */}
                    <div className={Styles.wov_modal_section}>
                    {/* Row 1: Spare Name + Quantity & Unit */}
                    <div className={Styles.wov_modal_flex_box}>
                        {/* Spare Name */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                            Spare Name <sup>*</sup>
                            </label>
                            <DynamicDropdown
                            isLabel={false}
                            label="Spare Name"
                            uniqueKey="name"
                            areaLabel="SpareName"
                            isCheckbox={false}
                            isActivator={true}
                            isMandatory={true}
                            isSearchable={true}
                            placeholder="search"
                            populatedFields={["number"]}
                            heading="Select from Spares Library"
                            isDynamicLoad={true}
                            handleMoreData={handleMoreSpareData}
                            handleGetValues={handleGetValues}
                            handleDynamicSearch={handleSearchSpareName}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            data={formattedSpareDropdownData || []}
                            />
                        </div>
                        </div>

                        {/* Quantity + Unit */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_inp_sel_wrapper}>
                            <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                                Request Quantity <sup>*</sup>
                            </label>
                            <ClonosInput
                                limit={8}
                                tabIndex={1}
                                type="number"
                                isLabel={false}
                                 placeholder="1234"
                                isMandatory={true}
                                areaLabel="Quantity"
                                uniqueKey="requestedQuantity"
                                isSpare={true}
                                errorMessage ={
                                !formData?.requestedQuantity
                                  ? "Please fill the Requested Quantity field!"
                                  : requestedQty > availableQty
                                    ? `Only ${availableQty} spare${availableQty > 1 ? 's' : ''} are available`
                                    : null
                                  }
                                // errorMessage="Please Fill the Requested Quantity field!."
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={ handleGetErrorActivatorInformation}
                            />
                            </div>
                            {/* <div className={Styles.wov_modal_select_wrapper}>
                            <label className={Styles.wov_modal_label}>Unit</label>
                            <ClonosSelect
                                type="select"
                                isMandatory={false}
                                placeholder="Unit"
                                errorMessage="Fill this field!"
                                uniqueKey="unit_type"
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                options={[
                                { label: "mm", isNeeded: true },
                                { label: "Litres", isNeeded: true },
                                { label: "No's", isNeeded: true },
                                ]}
                            />
                            </div> */}
                        </div>
                        </div>
                    </div>

                    {/* Row 2: Replaced Spares + Remarks */}
                    <div className={Styles.wov_modal_flex_box}>
                        {/* Remarks */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                            Remarks <sup>*</sup>
                            </label>
                            <ClonosInput
                            limit={50}
                            tabIndex={1}
                            type="text"
                            isLabel={false}
                            placeholder="remarks"
                            isMandatory={true}
                            areaLabel="Remarks"
                            uniqueKey="remarks"
                            errorMessage="Please Fill the Remarks field!."
                            handleGetValues={handleGetValues}
                            handleGetErrorActivatorInformation={ handleGetErrorActivatorInformation }
                            />
                        </div>
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className={Styles.wov_modal_btns_wrapper}>
                        <ClonosButton style={{ padding: "0.8rem 3rem" }} onClick={() => setIsOpen(false)}>
                        Cancel
                        </ClonosButton>
                        <ClonosButton
                        variant="filled"
                        style={{ padding: "0.8rem 3rem" }}
                        onClick={()=>handleSave('spareRequested')}
                        >
                        Request
                        </ClonosButton>
                    </div>
                    </div>
                </div>
                </Modal>
            )
            }
              {
            data?.heading === "Spare Replaced" && (
                <Modal isOpen={isOpen} closeModalMethod={setIsOpen}>
                <div className={Styles.wov_modal_container}>
                    {/* Header */}
                    <header className={Styles.wov_modal_header}>
                    <span className={Styles.wov_modal_heading}>
                        {"Spare Replacement"|| "Not Mentioned"}
                    </span>
                    <CloseIcon onClick={() => {
                      setIsOpen(false)
                      setRequestedQuantity('')
                    } }/>
                    </header>

                    <div className={Styles.wov_modal_avlqty}>
                      <span> 
                           Utilizing Spare Count:&nbsp; {formData?.name?.[0]?.name ? utilizedCount : '-'}
                      </span> 
                    </div>

                    {/* Modal Body Section */}
                    <div className={Styles.wov_modal_section}>
                    {/* Row 1: Spare Name + Quantity & Unit */}
                    <div className={Styles.wov_modal_flex_box}>
                        {/* Spare Name */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                            Spare Name <sup>*</sup>
                            </label>
                            <DynamicDropdown
                            isLabel={false}
                            label="Spare Name"
                            uniqueKey="name"
                            areaLabel="SpareName"
                            isCheckbox={false}
                            isActivator={true}
                            isMandatory={true}
                            isSearchable={true}
                            placeholder="search"
                            populatedFields={["number"]}
                            heading="Select from Spares Library"
                            handleGetValues={handleGetValues}
                            isDynamicLoad={true}
                            handleMoreData={handleMoreApprovedSpareData}
                            handleDynamicSearch={handleSearchPartsRequested}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            data={formattedApprovedSpareDropdownData || []}
                            />
                        </div>
                        </div>

                        {/* Quantity + Unit */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_inp_sel_wrapper}>
                            <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                               Requested Quantity <sup>*</sup>
                            </label>
                            <ClonosInput
                                limit={8}
                                type="number"
                                isLabel={false}
                                placeholder="1234"
                                isMandatory={true}
                                areaLabel="Quantity"
                                uniqueKey="requestedQuantity"
                                errorMessage="Please Fill the Requested Quantity field!."
                                handleGetErrorActivatorInformation={ handleGetErrorActivatorInformation }
                                handleGetValues={handleGetValues}
                                defaultValue={requestedQuantity? requestedQuantity : ""}
                                disabled={true}
                            />
                            </div>
                            {/* <div className={Styles.wov_modal_select_wrapper}>
                            <label className={Styles.wov_modal_label}>Unit</label>
                            <ClonosSelect
                                type="select"
                                isMandatory={false}
                                placeholder="Unit"
                                errorMessage="Fill this field!"
                                uniqueKey="unit_type"
                                handleGetErrorActivatorInformation={
                                handleGetErrorActivatorInformation
                                }
                                options={[
                                { label: "mm", isNeeded: true },
                                { label: "Litres", isNeeded: true },
                                { label: "No's", isNeeded: true },
                                ]}
                            />
                            </div> */}
                        </div>
                        </div>
                       
                    </div>

                    {/* Row 2: Replaced Spares + Remarks */}
                    <div className={Styles.wov_modal_flex_box}>
                        {/* Replaced Spares */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                            Replaced Spares <sup>*</sup>
                            </label>
                            <ClonosInput
                            limit={8}
                            type="number"
                            isLabel={false}
                            placeholder="1234"
                            isMandatory={true}
                            areaLabel="Replaced Spares"
                            uniqueKey="replacedQuantity"
                            // errorMessage="Please Fill the Replaced Spares field!."
                          errorMessage={
                            !formData?.replacedQuantity
                              ? "Please Fill the Replaced Spares field!."
                              : Number(formData?.replacedQuantity) > availableQuantity
                                ? `Only ${availableQuantity} spare is available`
                                : null
                          }
                            isSpare={true}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                             handleGetValues={handleGetValues}
                            />
                        </div>
                        </div>

                        {/* Remarks */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                            Remarks <sup>*</sup>
                            </label>
                            <ClonosInput
                            limit={50}
                            type="text"
                            isLabel={false}
                            placeholder="remarks"
                            isMandatory={true}
                            areaLabel="Remarks"
                            uniqueKey="remarks"
                            errorMessage="Please Fill the Remarks field!."
                            handleGetErrorActivatorInformation={
                                handleGetErrorActivatorInformation
                            }
                             handleGetValues={handleGetValues}
                            />
                        </div>
                        </div>
                    </div>
                      <div className={Styles.wov_modal_flex_box}>
                      <div className={Styles.wov_modal_field_block}>
                          <div className={Styles.wov_modal_input_wrapper}>
                            <FileUploader
                                limit={5}
                                fileSizeInMB={5}
                                isMandatory={true}
                                title={"images"}
                                uniqueKey={"images"}
                                label={"Spare Images"}
                                typeOfRecord={"images"}
                                acceptableFileTypes={[".jpg", ".png", ".jpeg"]}
                                handleGetSelectedData={handleGetValues}
                                errorMessage="Please Fill the Image field!."
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            //    defaultValue={globalStateOfChildData?.images?.length ? globalStateOfChildData?.images : []}
                                />
                    
                         </div>
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className={Styles.wov_modal_btns_wrapper}>
                        <ClonosButton style={{ padding: "0.8rem 3rem" }} onClick={() => setIsOpen(false)}>
                        Cancel
                        </ClonosButton>
                        <ClonosButton
                        variant="filled"
                        style={{ padding: "0.8rem 3rem" }}
                        onClick={()=>handleSave('spareReplaced')}
                        >
                        Replace
                        </ClonosButton>
                    </div>
                    </div>
                </div>
                </Modal>
            )
            }



            {
            data?.heading === "Tools Required" && (
                <Modal isOpen={isOpen} closeModalMethod={setIsOpen}>
                <div className={Styles.wov_modal_container}>
                    {/* Header */}
                    <header className={Styles.wov_modal_header}>
                    <span className={Styles.wov_modal_heading}>
                        {"Tools Required" || "Not Mentioned"}
                    </span>
                    <CloseIcon onClick={() => setIsOpen(false)} />
                    </header>
                    
                    
                    {/* Modal Body Section */}
                    <div className={Styles.wov_modal_section}>
                    {/* Row 1: Spare Name + Quantity & Unit */}
                    <div className={Styles.wov_modal_flex_box}>
                        {/* Spare Name */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                              Name <sup>*</sup>
                            </label>
                             <ClonosInput
                                limit={50}
                                tabIndex={1}
                                type="text"
                                isLabel={false}
                                placeholder="name"
                                isMandatory={true}
                                areaLabel="name"
                                uniqueKey="toolName"
                                errorMessage="Please Fill the Name field!."
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={ handleGetErrorActivatorInformation}
                            />
                        </div>
                        </div>

                        {/* Quantity + Unit */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_inp_sel_wrapper}>
                            <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                                 Quantity <sup>*</sup>
                            </label>
                            <ClonosInput
                                limit={8}
                                tabIndex={1}
                                type="number"
                                isLabel={false}
                                 placeholder="1234"
                                isMandatory={true}
                                areaLabel="Quantity"
                                uniqueKey="quantity"
                                errorMessage="Please Fill the Quantity field!."
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={ handleGetErrorActivatorInformation}
                            />
                            </div>
                           
                        </div>
                        </div>
                    </div>


                    {/* Action Buttons */}
                    <div className={Styles.wov_modal_btns_wrapper}>
                        <ClonosButton style={{ padding: "0.8rem 3rem" }} onClick={() => setIsOpen(false)}>
                        Cancel
                        </ClonosButton>
                        <ClonosButton
                        variant="filled"
                        style={{ padding: "0.8rem 3rem" }}
                        onClick={()=>handleSave('toolsRequested')}
                        >
                        Request
                        </ClonosButton>
                    </div>
                    </div>
                </div>
                </Modal>
            )
            }

              {
            data?.heading === "Consumables" && (
                <Modal isOpen={isOpen} closeModalMethod={setIsOpen}>
                <div className={Styles.wov_modal_container}>
                    {/* Header */}
                    <header className={Styles.wov_modal_header}>
                    <span className={Styles.wov_modal_heading}>
                        {"Tools Required" || "Not Mentioned"}
                    </span>
                    <CloseIcon onClick={() => setIsOpen(false)} />
                    </header>
                    
                    
                    {/* Modal Body Section */}
                    <div className={Styles.wov_modal_section}>
                    {/* Row 1: Spare Name + Quantity & Unit */}
                    <div className={Styles.wov_modal_flex_box}>
                        {/* Spare Name */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                              Name <sup>*</sup>
                            </label>
                             <ClonosInput
                                limit={50}
                                tabIndex={1}
                                type="text"
                                isLabel={false}
                                placeholder="name"
                                isMandatory={true}
                                areaLabel="name"
                                uniqueKey="consumablesName"
                                errorMessage="Please Fill the Name field!."
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={ handleGetErrorActivatorInformation}
                            />
                        </div>
                        </div>

                        {/* Quantity + Unit */}
                        <div className={Styles.wov_modal_field_block}>
                        <div className={Styles.wov_modal_inp_sel_wrapper}>
                            <div className={Styles.wov_modal_input_wrapper}>
                            <label className={Styles.wov_modal_label}>
                                 Quantity <sup>*</sup>
                            </label>
                            <ClonosInput
                                limit={8}
                                tabIndex={1}
                                type="number"
                                isLabel={false}
                                 placeholder="1234"
                                isMandatory={true}
                                areaLabel="Quantity"
                                uniqueKey="quantity"
                                errorMessage="Please Fill the Quantity field!."
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={ handleGetErrorActivatorInformation}
                            />
                            </div>
                           
                        </div>
                        </div>
                    </div>


                    {/* Action Buttons */}
                    <div className={Styles.wov_modal_btns_wrapper}>
                        <ClonosButton style={{ padding: "0.8rem 3rem" }} onClick={() => setIsOpen(false)}>
                        Cancel
                        </ClonosButton>
                        <ClonosButton
                        variant="filled"
                        style={{ padding: "0.8rem 3rem" }}
                        onClick={()=>handleSave('consumablesRequested')}
                        >
                        Request
                        </ClonosButton>
                    </div>
                    </div>
                </div>
                </Modal>
            )
            }

           



            <ImagePreviewModal 
                images={selectedPartImages}
                open={loadersAndFlags.showPartsReplacedImagePreview} 
                closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showPartsReplacedImagePreview:!prev.showPartsReplacedImagePreview}))} 
                // uploadOption={task.isCompleted === "true" ? false : true}  // Disable upload if checked
                // getUploadedDetails={(val) => setFormData(prev => ({
                //     ...prev, 
                //     images: { ...prev.images, [task.id]: val?.files }
                // }))}
            />
          
            {/* Modal rendered outside the table */}
            <ClonosAlertBox
              isOpen={loadersAndFlags.showRemarkModal}
              closeModalMethod={() =>
                setLoadersAndFlags({
                  ...loadersAndFlags,
                  showRemarkModal: false,
                  currentRemark: "",
                })
              }
              headerTitle="Remarks"
              message={loadersAndFlags.currentRemark}
            />
        </>
    )
}

export default PartsAndToolsCreateComp



