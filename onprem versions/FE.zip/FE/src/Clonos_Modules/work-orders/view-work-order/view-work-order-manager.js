import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import { doGetApiCall, doPatchApiCall, doPostApiCall } from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";

export const handleChangeTaskStatus = ({setRefreshAPI,workOrderId,taskId,taskImages}) => {
    let imagesId= taskImages.map((image)=>image.id)
      
    const payload={
          
         images: imagesId
    }

    doPatchApiCall({url:`/workOrders/${workOrderId}/tasks/${taskId}`,payload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            setRefreshAPI(prev => !prev)
        }
    })
}


export const handleGetSpares = ({ setterMethod, setIsLoading, filterPayload }) => {
    setIsLoading && setIsLoading(true);

    doGetApiCall({ url: AppUrl?.getAllSparesList, params: { ...(filterPayload || {}) } })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                const data = {
                    ...(res?.data?.result || {}),
                    data: res?.data?.result?.data?.map(spare => ({
                        id: spare?.id,
                        // name: `${spare?.name?.trim() ?? ''}${spare?.specification?.trim() ?? ''}`.trim()
                        name: `${spare?.name?.trim() ?? ''}`.trim(),
                        quantity: spare?.quantity
                    }))
                };

                setterMethod((prev) => {
                    // If it's a search, replace the data
                    if (filterPayload?.name) {
                        return data;
                    } else {
                        const prevData = prev?.data?.length ? [...prev?.data] : [];

                        if (prevData?.length) {
                            const uniqueSpareMap = prevData.reduce((acc, spare) => {
                                if (!acc[spare?.name]) {
                                    acc[spare?.name] = spare;
                                }
                                return acc;
                            }, {});

                            const newSpares = data?.data?.filter(spare => !uniqueSpareMap[spare?.name]);

                            return {
                                ...data,
                                data: [...prevData, ...newSpares]
                            };
                        } else {
                            return data;
                        }
                    }
                });
            }
        })
        .finally(() => {
            setIsLoading && setIsLoading(false);
        });
};



export const handleGetApprovedPartsRequestSpare = ({ setterMethod, workOrderId,setIsLoading, filterPayload }) => {
    setIsLoading && setIsLoading(true);

    doGetApiCall({url:`workOrders/${workOrderId}/spareRequested`, params: { ...(filterPayload || {}) } })
        .then((res) => {
            
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                const data = {
                    ...(res?.data?.result || {}),
                    data: res?.data?.result?.map(spare => ({
                        id: spare?.id,
                        // name: `${spare?.spare?.name?.trim() ?? ''}${spare?.spare?.specification?.trim() ?? ''}`.trim(),
                        name: `${spare?.spare?.name?.trim() ?? ''}`.trim() ,
                        spareId:spare?.spare?.id,
                        requestedQuantity:spare?.requestedQuantity,
                        utilizedCount:spare?.utilisedCount
                    }))
                };

                setterMethod((prev) => {
                    // If it's a search, replace the data
                    if (filterPayload?.name) {
                        return data;
                    } else {
                        const prevData = prev?.data?.length ? [...prev?.data] : [];

                        if (prevData?.length) {
                            const uniqueSpareMap = prevData.reduce((acc, spare) => {
                                if (!acc[spare?.name]) {
                                    acc[spare?.name] = spare;
                                }
                                return acc;
                            }, {});

                            const newSpares = data?.data?.filter(spare => !uniqueSpareMap[spare?.name]);

                            return {
                                ...data,
                                data: [...prevData, ...newSpares]
                            };
                        } else {
                            return data;
                        }
                    }
                });
            }
        })
        .finally(() => {
            setIsLoading && setIsLoading(false);
        });
};




export const handleGetWorkorderPartsReplaced =({setterMethod,workOrderId,setIsLoading})=>{
    setIsLoading()
    doGetApiCall({url:`workOrders/${workOrderId}/spareReplaced`})
    .then((res)=>{
        
         if(res.status=CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
         }
    })
    .catch((err)=>{
        console.log(err)
    })
   .finally(() => {
        setIsLoading && setIsLoading()
    })
}


export const handlePartRequested=({payload,workOrderId,setIsLoading,next})=>{
    setIsLoading()
    
    const requestPayload={}
    requestPayload.spareId=payload?.name?.[0].id
    requestPayload.requestedQuantity = Number(payload.requestedQuantity)
    requestPayload.remarks = payload.remarks
    
    doPostApiCall({url:`workOrders/${workOrderId}/spareRequested`, payload:requestPayload})
    .then((res)=>{
       
        if(res.status ==CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
             next && next(res)
        }
    })
    .catch((err)=>{
        if(err.status==400){
            next && next(err)
        }
        
    })
   .finally(() => {
        setIsLoading && setIsLoading()
    })
}

// export const handlePartReplaced=({payload,workOrderId,setIsLoading,next})=>{
    
//     setIsLoading()
//    console.log(payload,"replacedsparepayload")
//     const requestPayload={}
//     requestPayload.spareId=payload?.name?.[0].spareId
//     requestPayload.spareRequestedId = payload.requestedQuantity
//     requestPayload.replacedQuantity = Number(payload.replacedQuantity)
//     requestPayload.remarks = payload.remarks
//    requestPayload.images = payload?.images?.map(img => img?.id).filter(Boolean) || [];
//  console.log(payload,"payloadfrompartsreplaced111")
//     console.log(requestPayload,"requestpartpayload")
//     doPostApiCall({url:`workOrders/${workOrderId}/spareReplaced`, payload:requestPayload})
//     .then((res)=>{
//         if(res.status === 201){
//            next && next(res)
//         }
        
//     })
//     .catch((err)=>{
//         if(err.status==400){
//             next && next(err)
//         }
//         // handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.message,showTime:"5000"})
//         console.log(err,"err")
//     })
//    .finally(() => {
//         setIsLoading && setIsLoading()
//     })

// }


export const handlePartReplaced = ({ payload, workOrderId, setIsLoading, next }) => {
  setIsLoading();

  // Create FormData
  const formData = new FormData();
  formData.append("spareId", payload?.name?.[0]?.spareId || "");
  formData.append("spareRequestedId", payload.requestedQuantity || "");
  formData.append("replacedQuantity", Number(payload.replacedQuantity) || 0);
  formData.append("remarks", payload.remarks || "");

  // Collect only ids
  const imageIds = payload?.images?.filter((img) => img?.id)?.map((img) => img.id) || [];

    // Append as JSON string
    formData.append("images", JSON.stringify(imageIds));




  doPostApiCall({
    url: `workOrders/${workOrderId}/spareReplaced`,
    payload: formData,
    headers: { "Content-Type": "multipart/form-data" } // important for FormData
  })
    .then((res) => {
      if (res.status === 201) {
        next && next(res);
      }
    })
    .catch((err) => {
      if (err.status === 400) {
        next && next(err);
      }
     
    })
    .finally(() => {
      setIsLoading && setIsLoading();
    });
};


export const handleGetWorkorderPartsRequested =({setterMethod,workOrderId,setIsLoading})=>{
    setIsLoading()  
    
    doGetApiCall({url:`workOrders/${workOrderId}/spareRequested`})
    .then((res)=>{
       
        setterMethod(res?.data?.result)
    })
    .catch((err)=>{
        console.log(err)
    })
    .finally(() => {
        setIsLoading && setIsLoading()
    })
}

export const handleToolsRequested =({payload,workOrderId,setIsLoading,next})=>{
  setIsLoading()
    
    const requestPayload = {
        toolsRequired: [
        {
            name: payload.toolName,
            quantity: Number(payload.quantity)
        }
        ]
    };
 
    doPostApiCall({url:`workOrders/${workOrderId}/toolsRequired`, payload:requestPayload})
    .then((res)=>{
       
        if(res.status ==CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
             next && next(res)
        }
    })
    .catch((err)=>{
        if(err.status==400){
            next && next(err)
        }
        console.log(err)
    })
   .finally(() => {
        setIsLoading && setIsLoading()
    })
}

export const handleConsumablesRequested =({payload,workOrderId,setIsLoading,next})=>{
  setIsLoading()
    
    const requestPayload = {
        consumables: [
        {
            name: payload.consumablesName,
            quantity: Number(payload.quantity)
        }
        ]
    };

    doPostApiCall({url:`workOrders/${workOrderId}/consumables`, payload:requestPayload})
    .then((res)=>{
       
        if(res.status ==CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
             next && next(res)
        }
    })
    .catch((err)=>{
        if(err.status==400){
            next && next(err)
        }
        console.log(err)
    })
   .finally(() => {
        setIsLoading && setIsLoading()
    })
}