import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import Styles from "./view-work-order.module.css"
import { downloadCSV, downloadXLSX, getDateAndTime, handleCreateRemark, handleDeleteWorkOrder, handleExtendingDueDate, handleGetAllDueDateRequests, handleGetDocumentImage, handleGetRemark, handleGetStatusDropdown, handleRequestToExtendDueDate, handleUpdateTheWorkOrderStatus, lcHandleDummyEncryption } from "../../../utils/WorkOrderMethods/WorkOrderMethods"
import { workOrderStateManagementActions } from "../../../Store/Reducers/ClonosWorkOrderReducer"
import CircularProgress from '@material-ui/core/CircularProgress';
import { useDispatch, useSelector } from 'react-redux'
import { checkUserHasPermission, getDayMonthYear, getFormatedDate, getToken, globalhandlerOutsideRequest, handleAllowDirectAccessPage, handleLoggedInUser, handleSegregateURL, handleShowErrorAndWarning, hasPermission, isDate1GreaterThanDate2 } from '../../../utils/clonosCommon'
import configs from '../../../config'
import { commonActions } from "../../../Store/Reducers/CommonReducer";
import useToggler from '../../../CustomHooks/TogglerHook'
import { useRef } from 'react'
import { Card, Tooltip,makeStyles  } from '@material-ui/core'
import WO_Plus_Icon from "../../../assets/UIUX/icons/WO/WO_Plus.svg"
import PartsAndToolsComp from './PartsAndToolsComp'
import PartsAndToolsCreateComp from './PartsAndToolsCreateComp'
import CloseIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import RemarkMessage from './RemarkMessage'
import Modal from '../../../components/CommonComponents/Modal/Modal'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import { UnAuthorizedModal } from '../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
import ClonosConfirmationDialog from '../../../components/Dialogs/ClonosConfirmationDialog'
import ClonosInput from '../../../components/CommonComponents/ClonosInput/ClonosInput'
import Subbar from '../../../components/CommonComponents/ClonosSubbar/Subbar'
import ClonosConfirmationBox from '../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import ClonosExportOptions from '../../../components/CommonComponents/ClonosExportOptions/ClonosExportOptions'
import { CLONOS_GLOBAL_ACTION_COPY, CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_DOWNLOAD, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_USER_TYPE_ENGINEER, CLONOS_GLOBAL_USER_TYPE_MANAGER, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant'
import useModuleNameProvider from '../../../CustomHooks/ModuleNameProviderHook'
import { handleChangeWOStatus, handleDeleteWorkOrders, handleGetSingleWorkOrder } from '../work-order-manager'
import ClonosDocumentViewer from '../../../components/CommonComponents/document-viewer/ClonosDocumentViewer'
import { DueDateExtension } from '../components/due-date-extension/DueDateExtension'
import { handleGetDueDateExtensionRequest } from '../components/due-date-extension/due-date.extension-manager'
import ClonosRadioAndCheckbox from '../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox'
import { handleChangeTaskStatus } from './view-work-order-manager'
import { ImagePreviewModal } from '../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal'
import { AddRemarks } from '../components/remarks/AddRemarks'
import { ViewRemarks } from '../components/remarks/ViewRemarks'
import { setRandomFallback } from 'bcryptjs'
import { MediaBlueStaticIcon } from '../../../resources/icons/static/MediaBlueStaticIcon'
import { MediaBlackStaticIcon } from '../../../resources/icons/static/MediaBlackStaticICon'
import useFieldsChecker from '../../../CustomHooks/FieldsValidatorHook'
import { handleGetFilledValuesOfWorkOrder } from '../work-order-manager'

/*
    date            qid / cr#         comments
    07-Apr-2026     -#160             Broken Access Control - Permission Restriction FrontEnd
    */
const ViewWorkOrder = () => {
    // Global States 
    const store = useSelector(store => store)
    const { singleWorkOrderToolkitState, workOrderStatusDropdownToolkitState } = useSelector(store => store.workOrderStateManagement)
    const { workOrderDocuments, workOrderTasks } = singleWorkOrderToolkitState

    // Local States
    const LOCATION = useLocation();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [refreshAPI,setRefreshAPI] = useState(false)
    const [documentToView,setDocumentToView] = useState({})
    const [workOrderDetails,setWorkOrderDetails] = useState({});
    const [dueDateRequest,setDueDateRequest] = useState([]);
    const [lcLoaderAndFlags,setLcLoadersAndFlags] = useState({
        deleteLoading:false,
        fetchWOLoading:false,
        showAddRemarksModal:false,
        changeStatusLoading:false,
        showViewRemarksModal:false,
        deleteWorkOrderAlert:false,
        showImagePreviewModal:false,
        downloadWorkOrderAlert:false,
        showDueDateExtensionModal:false,
        
    })
    const [loadersAndFlags,setLoadersAndFlags] = useState({
        fetchTasksLoading:false,
        saveWorkOrderLoading:false,
        draftWorkOrderLoading:false,
        showImagePreviewModal:false,
        showRemarksPreviewModal:false,
        showDraftWorkOrderAlert:false,
        showCancelWorkOrderAlert:false,
        showCustmizedTeamDropdown:false,
        showAddFromTaskLibraryModal:false
    })
       
    
    const [formData,setFormData] = useState({});
    const [serverResponse,setServerResponse] = useState({});
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false,hookUniqueKey:"work-order"})
    const isOperatorLoggedIn = handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR ? true : false;
    const [isOpen, setIsOpen] = useState(false);
    const [imageUrl, setImageUrl] = useState("");
    const [statusAlert, setStatusAlert] = useToggler();
    const [statusChangeDialogBoxText, setStatusChangeDialogBoxText] = useState("");
    const statusRef = useRef(null);
    const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
    const [lcIntervals, setLcIntevals] = useState({});
    const [isExtendWorkOrderLimitModalOpen, setIsExtendWorkOrderLimitModalOpen] = useState(false);
    const [isAddRemarkModalOpen, setIsAddRemarkModalOpen] = useState(false);
    const [isExtendDueDateModalOpen, setIsExtendDueDateModalOpen] = useState(false);
    const workOrderRemarkRef = useRef(null);
    const workOrderExtendDateReasonRef = useRef(null);
    const [lcValues, setLcValues] = useState({ deleteWorkOrder: false, requestsForDueDateExtension: [], remarksResponse: null });
    const { requestsForDueDateExtension, remarksResponse } = lcValues;
    const [needToExportFileDetails, setNeedToExportFileDetails] = useState({});
    const [isDownloadModal, setIsDownloadModal] = useState(false);
    // To store the task details waiting for confirmation
    const [pendingTaskConfirmation, setPendingTaskConfirmation] = useState(null);

    // To control whether confirmation box is open
    const [isTaskConfirmationOpen, setIsTaskConfirmationOpen] = useState(false);
    //#160 
      const [isUnauthorized, setIsUnauthorized] = useState(false);
    const URL = handleSegregateURL();
    const moduleName = useModuleNameProvider();
   
    const repeatedElements = [{
        id: Math.random(),
        heading: "Spare Requested",
        title: "Spare requested by the Assigned User",
        key:"spareRequested",
        icon: WO_Plus_Icon,
        isVisible: true // hasPermission('/view-parts-required')
    },
    {
        id: Math.random(),
        heading: "Spare Replaced",
        title: "Spare requested by the Assigned User",
        key:"spareReplaced",
        icon: WO_Plus_Icon,
        isVisible: true //hasPermission('/view-parts-requested')
    },
    {
        id: Math.random(),
        heading: "Tools Required",
        title: "Spare replaced by the Assigned User",
        key:"toolsRequired",
        icon: WO_Plus_Icon,
        isVisible: true //hasPermission('/view-tool-required')
    },
    {
        id: Math.random(),
        heading: "Consumables",
        title: "Spare replaced by the Assigned User",
        key:"consumables",
        icon: WO_Plus_Icon,
        isVisible: true //hasPermission('/view-consumables')
    },
    ]

    const EngineerRepeatedElements = [
        {
            heading: "Parts Required",
            isVisible: true //hasPermission('/view-parts-required')
        },
        {
            heading: "Parts Requested",
            isVisible: true //hasPermission('/view-parts-requested')

        },
        {
            heading: "Tools Required",
            isVisible: true //hasPermission('/view-tool-required')
        },
        {
            heading: "Consumables",
            isVisible: true //hasPermission('/view-consumables')
        }
    ]

    const request = [{
        partName: "string",
        partNumber: "number",
        quantity: "number"
    }]

    /**
     * WOE  = Work Order Edit
     * This function is getting use to jump to the edit page.
     */
    const handleGotoWOE = (mode) => {
        navigate(mode === "duplicate" ? "/duplicate-work-order" : "/edit-work-order", { state: { workOrderId: workOrderDetails?.id } })
    }

    const handleGetValues = (props) => {
        handleGetFilledValuesOfWorkOrder({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier})
    }

    const handleGotoViewMaintenanceTask = () => {
        navigate(`/view-maintenance-plan/${workOrderDetails?.maintenanceId}`, { state: { maintenanceId: workOrderDetails?.maintenanceId, workOrderName: workOrderDetails?.title, workOrderNumber: workOrderDetails?.woNumber } })
    }

    /**
     * This handler is getting use to see the images and pdf.
     * @param {string} documentId 
     * @param {string} type 
     */
    const handleViewDocuments = (documentId, type) => {
        const token = getToken();
        if (type === "png" || type === "jpg" || type === "jpeg") {
            setIsOpen(true)
            handleGetDocumentImage({ documentId, setImageUrl })
        }
        else {
            window.open(`${configs.url}?woDocId=${documentId}&token=${token}`);
        }
    }

    /**
     * donwload the work order detail in the CSV format.
     * @param {*} e => Synthetic Event 
     */
    const handleDownloadView = (e) => {
        if (e?.target?.value === "csv") {
            downloadCSV({ data: workOrderDetails })
        } else {
            return downloadXLSX({ data: workOrderDetails, needToExportFileDetails })
        }
    }


    /**
     * This function will use to extent the end date of the work order.
     */
    const handleExtendDueDate = () => {
        setIsExtendDueDateModalOpen(true)
    }

    const lcHandleStatusChange = (e) => {
        const target = e?.target?.value
        if (workOrderDetails.status === target) {
            handleShowErrorAndWarning({ dispatch, type: "error", message: "Select different status!", showTime: 5000 })
            return
        }
        if (e.target.value === "putOnHold") {
            setLcLoadersAndFlags(prev => ({...prev,showAddRemarksModal:true}))
        }
        else {
            const next = () => {
                setRefreshAPI(prev => !prev);
                handleShowErrorAndWarning({dispatch,message:"Status updated successfully.",type:"success",showTime:"5000"})
            }
            handleChangeWOStatus({status:target,workOrderId:workOrderDetails?.id,setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,changeStatusLoading:!prev.changeStatusLoading})),next})
        }
    }

    const handlePutWorkOrderOnHold = () => {
        handleChangeWOStatus({status:"putOnHold",workOrderId:workOrderDetails?.id,setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,changeStatusLoading:!prev.changeStatusLoading})),next:() => {
            setRefreshAPI(prev => !prev);
            handleShowErrorAndWarning({dispatch,message:"Status updated successfully.",type:"success",showTime:"5000"})
        }})
    }

    const lcHandleAddRemark = () => {

        if (workOrderDetails.status === lcValues?.latestStatus) return
        handleCreateRemark({
            dispatch, payload: {
                workOrderId: workOrderDetails?.workOrderId,
                remarks: lcValues?.workOrderRemark,
                "createdBy": handleLoggedInUser()?.userId
            },
            locallyResponseSetterMethod: setLcValues
        });
        handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR && handleUpdateTheWorkOrderStatus({ dispatch, workOrderId: workOrderDetails.workOrderId, status: lcValues?.latestStatus });
        setIsAddRemarkModalOpen(false);
    }

    

    const lcHandleExtendDueDate = () => {
        if ((lcValues?.extendDueDate && lcValues?.extendDueDateReason) || handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_ENGINEER) {
            if (handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR) {
                handleRequestToExtendDueDate(
                    {
                        workOrderId: workOrderDetails?.id,
                        dispatch,
                        payload: {
                            "remarks": lcValues?.extendDueDateReason,
                            "createdBy": handleLoggedInUser().userId,
                            "requestedDate": lcValues?.extendDueDate,
                            "isFromRequest": true
                        },
                        locallyResponseSetterMethod: setLcValues
                    })
            } else {
                handleExtendingDueDate(
                    {
                        workOrderId: workOrderDetails?.id,
                        dispatch,
                        payload: {
                            "remarks": lcValues?.extendDueDateReason ? lcValues?.extendDueDateReason : "Due Date Extended.",
                            "createdBy": handleLoggedInUser().userId,
                            "dueDate": lcValues?.extendDueDate ? lcValues?.extendDueDate : lcValues?.requestsForDueDateExtension[0]?.requestedDate,
                            "woDueDateId": lcValues?.requestsForDueDateExtension[0]?.woDueDateId,
                            "isFromRequest": true
                        },
                        locallyResponseSetterMethod: setLcValues
                    })
            }
        }
        else {
            handleShowErrorAndWarning({ dispatch, type: "error", message: `Please select both fields!`, showTime: 5000 })
        }
        setIsExtendDueDateModalOpen(false)
    }


    const handleGetDetails = (props) => {
        setNeedToExportFileDetails(props)
    }

    const handleExportFile = () => {
        handleDownloadView("xlxs");
        setIsDownloadModal(false);
    }

   useEffect(() => {
       //#160
       if (!LOCATION?.state) {
        setIsUnauthorized(true);
        return;
     }
       handleGetSingleWorkOrder({workOrderId:LOCATION?.state?.workOrderId,setterMethod:setWorkOrderDetails,setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,fetchWOLoading:!prev.fetchWOLoading}))})
       //handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_ENGINEER && handleGetDueDateExtensionRequest({workOrderId:LOCATION?.state?.workOrderId,setterMethod:setDueDateRequest}) 
       const userType = handleLoggedInUser()?.userType?.name;
        if (
            userType === CLONOS_GLOBAL_USER_TYPE_ENGINEER ||
            userType === CLONOS_GLOBAL_USER_TYPE_MANAGER
        ) {
            handleGetDueDateExtensionRequest({
            workOrderId: LOCATION?.state?.workOrderId,
            setterMethod: setDueDateRequest
            });
        }
    },[refreshAPI,LOCATION?.state?.workOrderId])
    
    
    
 const allTasksCompleted = workOrderDetails?.tasks?.every(t => t.isCompleted === "true");
     const useStyles = makeStyles((theme) => ({
        customWidth: {
           maxWidth:"400px",
           fontSize:'12px',
           textAlign:"justify"
        },
        
        }));

     const classes = useStyles();
    
      //#160 
     if (isUnauthorized) {
         return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
         }
     
         
    if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ }))

        return (
            <>
                {!globalhandlerOutsideRequest() && <Subbar
                    // isCopy={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_COPY })}
                    // isEdit={false}
                    // isDelete={}
                    // isDownload={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DOWNLOAD })}
                    isHollow={false}
                    isPriority={true}
                    isStatus={true}
                    isCreatedOn={workOrderDetails?.status !== "expired" ? workOrderDetails?.createdAt : false}
                    isExpiredOn={workOrderDetails?.status === "expired" ? workOrderDetails?.endAt : false}
                    subbarData={workOrderDetails}
                    isRemarksMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? () => setLcLoadersAndFlags(prev => ({...prev,showViewRemarksModal:true})) : false}
                    isCopyMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? () => handleGotoWOE("duplicate") : false}
                    isEditMethod={workOrderDetails?.status !== "onHold" && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => handleGotoWOE("edit") : false}
                    isDownloadMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DOWNLOAD }) ? () => setLcLoadersAndFlags(prev => ({...prev,downloadWorkOrderAlert:!prev.downloadWorkOrderAlert})) : false}
                    isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setLcLoadersAndFlags(prev => ({...prev,deleteWorkOrderAlert:!prev.deleteWorkOrderAlert})) : false}
                    buttons={
                        [
                            {
                                buttonMethod: "",
                                isHollow: false,
                                buttonText: "Change Status",
                                isActive: handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR,
                                isActive: false,
                                isDisabled: false
                            },
                            {
                                buttonMethod: () => setLcLoadersAndFlags(prev => ({...prev,showDueDateExtensionModal:true})),
                                isHollow: true,
                                buttonText: "Extend Due Date",
                                // isActive: dueDateRequest?.length > 0 && handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_ENGINEER,
                                isActive:
                                dueDateRequest?.length > 0 &&
                                (
                                    handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_ENGINEER ||
                                    handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_MANAGER
                                ),
                                isDisabled: false
                            },
                            {
                                buttonMethod: () => setLcLoadersAndFlags(prev => ({...prev,showDueDateExtensionModal:true})),
                                isHollow: true,
                                buttonText: "Request Extension",
                                isActive: workOrderDetails?.status === "expired" && isOperatorLoggedIn,
                                isDisabled: false
                            },
                            {
                                type: "select",
                                buttonMethod: lcHandleStatusChange,
                                isHollow: true,
                                buttonText: "Change Status",
                                isActive: isOperatorLoggedIn &&  (workOrderDetails?.status !== "expired" && workOrderDetails?.status !== "completed"),
                                isDisabled: isDate1GreaterThanDate2(new Date().toISOString(), workOrderDetails?.endDate) || workOrderDetails?.status === "Completed",
                                options:[
                                    {label:"Accept",value:"accept",isDisabled:false,isNeeded:workOrderDetails?.status === "scheduled"},
                                    {label:"On Hold",value:"putOnHold",isDisabled:false,isNeeded:workOrderDetails?.status === "accepted"},
                                    {label:"Complete",value:"complete",isDisabled:!allTasksCompleted,isNeeded:workOrderDetails?.status === "accepted"},
                                    {label:"Resume",value:"accept",isDisabled:false,isNeeded:workOrderDetails?.status === "onHold"},
                                ]
                            }
                        ]
                    }
                />}
                <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                    <section className={Styles.wov_body}>
                        {/* <header className={Styles.wov_header}>
                            <div>
                                <span className={Styles.wov_header_title}>{workOrderDetails?.title}</span>
                                {
                                    workOrderDetails?.isAutoCreated === 1 && <span onClick={handleGotoViewMaintenanceTask} className={Styles.wov_view_maintenance_plan}>View Maintenance Plan</span>
                                }
                            </div>
                        </header> */}
                        <section className={Styles.wov_body_split}>
                            <div>
                                <div className={Styles.wov_bs_c1}>
                                    <table>
                                    <tr>
                                            <td>Work Order Name:</td>
                                            <td>
                                                {workOrderDetails?.name || "-"}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Work Order Number:</td>
                                            <td>
                                                {workOrderDetails?.number || "-"}
                                            </td>
                                        </tr>
                                        {/* <tr>
                                            <td>Description:</td>
                                            <Tooltip title={workOrderDetails?.description}>
                                                <td>
                                                    <p>
                                                        {workOrderDetails?.description || "-"}
                                                    </p>
                                                </td>
                                            </Tooltip>
                                        </tr> */}
                                        <tr>
                                            <td>Description:</td>
                                            <td>
                                                <Tooltip title={workOrderDetails?.description || "-"} placement="right"  classes={{ tooltip: classes.customWidth }}>
                                                <p className={Styles.description}>
                                                    {workOrderDetails?.description || "-"}
                                                </p>
                                                </Tooltip>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>Department:</td>
                                            <td>{workOrderDetails?.departments?.length ? workOrderDetails?.departments[0]?.name : "-"}</td>
                                        </tr>
                                        <tr>
                                            <td>Asset Name:</td>
                                            <td>{workOrderDetails?.asset ? workOrderDetails?.asset?.generalDetails?.name : "-"}</td>
                                        </tr>
                                        <tr>
                                            <td>Start Date:</td>
                                            <td>{workOrderDetails?.startAt ? getFormatedDate(workOrderDetails?.startAt) : "-"}</td>
                                        </tr>
                                        <tr>
                                            <td>End Date:</td>
                                            <td>{workOrderDetails?.endAt ? getFormatedDate(workOrderDetails?.endAt) : "-"}</td>
                                        </tr>
                                        <tr>
                                            <td>Estimation Days:</td>
                                            <td>{workOrderDetails?.estimatedDays ? `${workOrderDetails?.estimatedDays} Days` : "-"}</td>
                                        </tr>
                                        <tr>
                                            <td>Estimation Hours:</td>
                                            <td>{workOrderDetails?.estimatedHours ? `${workOrderDetails?.estimatedHours} Hrs` : "0 Hrs"}</td>
                                        </tr>
                                        <tr>
                                            <td>Assignee:</td>
                                            <td>{workOrderDetails?.assignees?.length ? workOrderDetails?.assignees[0]?.name : "-"}</td>
                                        </tr>
                                        <tr>
                                            <td>Existing Teams & Members:</td>
                                            <td>{workOrderDetails?.existingTeams?.length  ? workOrderDetails?.existingTeams?.map(ele => `${ele.name}[${ele.noOfMembersRequired}]`).join(" ") : "-"}</td>
                                        </tr>
                                        <tr>
                                            <td>Local Teams & Members:</td>
                                            <td>{workOrderDetails?.localTeams?.length  ? workOrderDetails?.localTeams?.map(ele => `${ele.name}[${ele.noOfMembersRequired}]`).join(" ") : "-"}</td>
                                        </tr>
                                    </table>
                                </div>
                                 <div className={Styles.wov_bs_c2}>
                                <header><span>Tasks Details</span></header>

                                <div className={`${Styles.wov_bs_c2_tasks} ${!isOperatorLoggedIn ? Styles.no_checkbox : ""}`}>
                                    {workOrderDetails?.tasks?.length ? workOrderDetails?.tasks?.map((task, index) => (
                                    <div className={Styles.task_row} key={task?.id}>
                                        {/* Column 1: Checkbox */}
                                        {isOperatorLoggedIn && (
                                            <div className={Styles.task_checkbox}>
                                                {workOrderDetails?.status === "accepted" && (
                                                    <ClonosRadioAndCheckbox
                                                        handleGetValues={() => {
                                                            setPendingTaskConfirmation({
                                                                workOrderId: workOrderDetails?.id,
                                                                taskId: task?.id,
                                                                taskImages: [
                                                                    ...(formData?.images?.[task.id] || []),
                                                                    ...(task?.images || []),
                                                                ],
                                                            });
                                                            setIsTaskConfirmationOpen(true);
                                                        }}
                                                        isChecked={task.isCompleted === "true"}
                                                    />
                                                )}
                                            </div>
                                        )}

                                        {/* Column 2: Task no + dash + description */}
                                        <div className={Styles.task_content}>
                                        <div className={Styles.task_left}>
                                            {task?.isCompleted === "true" ? (
                                            <s>Task {index + 1}</s>
                                            ) : (
                                            <span>Task {index + 1}</span>
                                            )}
                                            <div>-</div>
                                        </div>

                                        <div className={Styles.task_right}>
                                            {task?.isCompleted === "true" ? (
                                            <s>{task?.description}</s>
                                            ) : (
                                            <span>{task?.description}</span>
                                            )}
                                        </div>
                                        </div>

                                        {/* Column 3: Add/View Images */}
                                        <div
                                        className={Styles.task_images_col}
                                        onClick={() =>
                                            setLoadersAndFlags((prev) => ({
                                            ...prev,
                                            showImagePreviewModal: { ...prev.showImagePreviewModal, [task.id]: true },
                                            }))
                                        }
                                        >
                                        {(formData?.images?.[task.id]?.length || task?.images?.length) 
                                            ? <MediaBlueStaticIcon/> 
                                            : <MediaBlackStaticIcon/>
                                        }
                                        <span style={{
                                            color: (formData?.images?.[task.id]?.length || task?.images?.length) 
                                            ? "#0A5FFF" 
                                            : "#000"
                                        }}>
                                            {isOperatorLoggedIn
                                            ? (formData?.images?.[task.id]?.length || task?.images?.length) 
                                                ? "View Images" 
                                                : "Add Images"
                                            : (formData?.images?.[task.id]?.length || task?.images?.length) 
                                                ? "View Images"
                                                : "View Images"}
                                        </span>
                                        </div>

                                        {/* Modal */}
                                        <ImagePreviewModal
                                        images={[...(task?.images || []), ...(formData?.images?.[task.id] || [])]}
                                        open={loadersAndFlags.showImagePreviewModal?.[task.id] || false}
                                        closeModalMethod={() =>
                                            setLoadersAndFlags((prev) => ({
                                            ...prev,
                                            showImagePreviewModal: { ...prev.showImagePreviewModal, [task.id]: false },
                                            }))
                                        }
                                        uploadOption={isOperatorLoggedIn && task.isCompleted !== "true" && workOrderDetails?.status !== "scheduled" && workOrderDetails?.status !== "expired"}
                                        getUploadedDetails={(val) =>
                                            setFormData((prev) => ({
                                            ...prev,
                                            images: { ...prev.images, [task.id]: val?.files },
                                            }))
                                        }
                                        />
                                    </div>
                                    )) : <span>No Tasks Available!</span>}
                                </div>
                                </div>


                                {/* {
                                    handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_ENGINEER ?
                                        <div className={Styles.wov_bs_c3}>
                                            {
                                                EngineerRepeatedElements?.map((element) => {
                                                    return element.isVisible && <PartsAndToolsComp title={element?.heading} data={[]} />
                                                })
                                            }
                                        </div>
                                        :
                                } */}
                                        <div className={Styles.wov_bs_c3}>
                                            {
                                                repeatedElements?.map((element) => {
                                                    return element.isVisible && <PartsAndToolsCreateComp data={element}  workOrderDetails={workOrderDetails}  onChildRefresh={() => setRefreshAPI(prev => !prev)} />
                                                })
                                            }
                                        </div>

                            </div>
                            <div>
                                <div className={Styles.wov_bs_rc0}>
                                    <div>
                                        <span onClick={() => setLcLoadersAndFlags(prev => ({...prev,showImagePreviewModal:true}))}>View Images</span>
                                        {/* <span>View Maintenance Plan</span> */}
                                    </div>
                                </div>
                                <div className={Styles.wov_bs_rc1}>
                                    <header><span>Documents</span></header>
                                    <div className={Styles.wov_bs_rc1_documents}>
                                        {
                                            workOrderDetails?.documents?.length ? workOrderDetails?.documents?.map((ele, index) => {
                                                return <div key={ele.id} onClick={() => setDocumentToView(ele)}><span>{ele.name}</span></div>
                                            }) : <span>No Documents Available!</span>
                                        }
                                    </div>
                                </div>
                            </div>
                        </section>
                    </section>
                </Card>
                <Modal isOpen={isOpen} closeModalMethod={setIsOpen}>
                    <div className={Styles.wov_modal}>
                        {
                            imageUrl === "" ? <CircularProgress /> : <img src={imageUrl} />
                        }
                    </div>
                </Modal>

                {/* <Modal isOpen={isExtendWorkOrderLimitModalOpen} closeModalMethod={setIsExtendWorkOrderLimitModalOpen}>
                    <div className={Styles.wov_extent_wo_limit_modal_container}>
                        <section className={Styles.wov_ewolmc_heading}>
                            <p>Extend Due Date</p>
                            <CloseIcon tooltipTitle="Close" onClick={() => setIsExtendWorkOrderLimitModalOpen(false)} />
                        </section>
                        <section className={Styles.wov_ewolmc_content}>
                            <ClonosInput
                                label="Extend Till"
                                isMandatory={true}
                                type="date"

                            />
                            <div>
                                <ClonosButton>Cancel</ClonosButton>
                                <ClonosButton>Extend</ClonosButton>
                            </div>
                        </section>
                    </div>
                </Modal> */}

                {lcLoaderAndFlags.showDueDateExtensionModal && <DueDateExtension 
                    setRefreshAPI={setRefreshAPI}
                    dueDateRequest={dueDateRequest}
                    workOrderId={workOrderDetails?.id} 
                    isOpen={lcLoaderAndFlags.showDueDateExtensionModal} 
                    closeMethod={() => setLcLoadersAndFlags(prev => ({...prev,showDueDateExtensionModal:!prev.showDueDateExtensionModal}))}
                />}
                {lcLoaderAndFlags.showViewRemarksModal && <ViewRemarks isOpen={lcLoaderAndFlags.showViewRemarksModal} closeMethod={() => setLcLoadersAndFlags(prev => ({...prev,showViewRemarksModal:false}))} workOrderId={LOCATION?.state?.workOrderId}/>}

                <Modal isOpen={lcLoaderAndFlags.downloadWorkOrderAlert} closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,downloadWorkOrderAlert:!prev.downloadWorkOrderAlert}))}>
                    <ClonosExportOptions handleGetDetails={handleGetDetails} handleExportFile={handleExportFile} formats={["xlsx"]} fileName={workOrderDetails?.name} />
                </Modal>

                <ClonosConfirmationDialog
                    Open={statusAlert}
                    Title="Status Work Order"
                    Content={statusChangeDialogBoxText}
                    CloseDialog={() => setStatusAlert(false)}
                    ProceedDialog={() => {
                        if (statusRef.current.value === "completed" && workOrderDetails?.team && workOrderDetails?.users && workOrderDetails?.asset && workOrderDetails?.priority) {
                            handleUpdateTheWorkOrderStatus({ dispatch, commonActions, workOrderId: workOrderDetails?.workOrderId, status: { status: statusRef?.current?.value }, workOrderStateManagementActions })
                        }
                        setStatusAlert(false)
                    }}
                    warning={true}
                />
                <ClonosConfirmationBox
                    isOpen={lcLoaderAndFlags.deleteWorkOrderAlert}
                    confirmingMethod={() => {
                        handleDeleteWorkOrders({payload:[workOrderDetails?.id],setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,deleteLoading:!prev.deleteLoading})),next:() => {
                            handleShowErrorAndWarning({dispatch,message:"Work Order deleted successfully!",type:"success",showTime:"5000"})
                            navigate("/work-orders")
                        } })
                        setDeleteWorkOrderAlert(false)
                    }}
                    loading={lcLoaderAndFlags?.deleteLoading}
                    closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,deleteWorkOrderAlert:!prev.deleteWorkOrderAlert}))}
                    headerTitle="Delete Work Order"
                    message="Are you sure, You want to delete this work order?"
                />
                <ClonosConfirmationBox
                    isOpen={isTaskConfirmationOpen}
                    confirmingMethod={() => {
                        if (pendingTaskConfirmation) {
                            handleChangeTaskStatus({
                                ...pendingTaskConfirmation,
                                setRefreshAPI
                            });
                        }
                        setIsTaskConfirmationOpen(false);
                        setPendingTaskConfirmation(null);
                    }}
                    closeModalMethod={() => {
                        setIsTaskConfirmationOpen(false);
                        setPendingTaskConfirmation(null);
                    }}
                    headerTitle="Confirm Task Completion"
                    message="Are you sure you want to mark this task as completed?"
                />

                {documentToView?.url ? <ClonosDocumentViewer
                    isDocument={documentToView?.extension =="pdf" ? true : false}
                    file={documentToView}
                    isOpen={documentToView?.url ? true : false}
                    closeMethod={() => setDocumentToView({})}
                /> : <></>}
                {
                    lcLoaderAndFlags.showImagePreviewModal ? 
                    <ImagePreviewModal
                        images={workOrderDetails?.images}
                        open={lcLoaderAndFlags.showImagePreviewModal}
                        closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,showImagePreviewModal:false}))}
                    /> : <></>
                }
                {
                    lcLoaderAndFlags.showAddRemarksModal && <AddRemarks workOrderId={workOrderDetails?.id} isOpen={lcLoaderAndFlags.showAddRemarksModal} closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,showAddRemarksModal:false}))} next={handlePutWorkOrderOnHold}/>
                }
            </>
        )
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default ViewWorkOrder

               {/* <div className={Styles.wov_bs_c2_tasks}>
                                        {
                                            workOrderDetails?.tasks?.length ? workOrderDetails?.tasks?.map((task, index) => {
                                                return <div key={task?.id}>
                                                    {workOrderDetails?.status === "accepted" && isOperatorLoggedIn && <ClonosRadioAndCheckbox handleGetValues={(val) => handleChangeTaskStatus({workOrderId:workOrderDetails?.id,taskId:task?.id,setRefreshAPI})} isChecked={task.isCompleted === "true" ? true : false}/>}
                                                    {task?.isCompleted === "true" ? <s>Task {index + 1} - </s> : <span>Task {index + 1} - </span>}
                                                    <Tooltip title={task?.description}>
                                                        {
                                                            task?.isCompleted === "true" ? <s>{task?.description}</s> : <span>{task?.description}</span>
                                                        }
                                                        
                                                    </Tooltip>
                                                    <div className={Styles.media_wrapper}>
                                                
                                                        <div onClick={() => setLoadersAndFlags(prev => ({...prev,showImagePreviewModal:true}))}>
                                                            {(formData?.images?.length || serverResponse?.images?.length) ? <MediaBlueStaticIcon/> : <MediaBlackStaticIcon/>}
                                                            <span style={{color:(formData?.images?.length || serverResponse?.images?.length) ? "#0A5FFF" : "#000"}}>{(formData?.images?.length || serverResponse?.images?.length) ? "View Images" :"Add Images"}</span>
                                                        </div>
                                                        <FileUploader
                                                            label="Documents"
                                                            uniqueKey="documents"
                                                            typeOfRecord={"Files"}
                                                            title="Documents"
                                                            isMandatory={false}
                                                            limit={10}
                                                            fileSizeInMB={10}
                                                            acceptableFileTypes={[".jpg", ".jpeg", ".pdf", ".docs"]}
                                                            handleGetSelectedData={handleGetValues}
                                                            defaultValue={serverResponse?.documents}
                                                        />

                                                     </div>
                                                </div>
                                            }) : <span>No Tasks Available!</span>
                                        }
                                    </div> */}