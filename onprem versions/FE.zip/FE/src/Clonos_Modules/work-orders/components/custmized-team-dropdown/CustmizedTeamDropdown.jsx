import { useEffect, useState } from "react"
import BackIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/BackIcon"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import { CLONOS_GLOBAL_MATE_BLACK } from "../../../../Constants/Constant"
import Styles from "./custmized-team-dropdown.module.css"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import { generateUniqueId } from "../../../../utils/clonosCommon"
export const CustmizedTeamDropdown = ({isOpen,closeModalMethod,existingTeams,formData,localTeamsFromServer,setFormData}) => {
    const [lcTeams,setLcTeams] = useState([]);
    const [lcExistingTeams,setLcExistingTeams] = useState([])
    const handleAddLocalTeam = () => {
        setLcTeams(prev => {
            return [...prev,{name:"",noOfMembersRequired:0,key:generateUniqueId(3)}]
        })
    }

    const handleChangeLcTeam = ({value,index,key}) => {
        const modifiedTeams = lcTeams?.map((team,i) => {
            if(index === team.key){
                return {...team,[key]:value}
            } else {
                return team
            }
        })
        setLcTeams(modifiedTeams)
    }

    const handleChangeExistingTeam = ({value,index}) => {
        const modifiedTeams = existingTeams?.map((team,i) => {
            if(index === i){
                return {...team,"noOfMembersRequired":value}
            } else {
                return team
            }
        })
        setLcExistingTeams(modifiedTeams)
    }

    useEffect(() => {
        setLcTeams(formData?.localTeams)
    },[formData?.localTeams?.length])

    useEffect(() => {
        setLcTeams(localTeamsFromServer);
        setFormData(prev => ({...prev,localTeams:localTeamsFromServer}))
    },[localTeamsFromServer?.length])


    return <Modal isOpen={isOpen} closeModalMethod={closeModalMethod} stopOverlayCloser={true}>
        <div className={Styles.container}>
            <div className={Styles.container_body}>
            <header className={Styles.header}>
                <div>
                    < BackIcon
                        strokeColor={CLONOS_GLOBAL_MATE_BLACK}
                        tooltipTitle="Back"
                        // onClick={() => {
                        //     setFormData(prev => ({...prev,existingTeams:lcExistingTeams,localTeams:lcTeams}));
                        //     closeModalMethod()
                        // }} 
                    />
                    <h4>Members Required</h4>
                </div>
                <CloseIcon onClick={closeModalMethod}/>
            </header>
            <section className={Styles.section}>
                <div className={Styles.section_c1}>
                    <h5>Team Name</h5>
                    <h5>No of Members required</h5>
                </div>
                <div className={Styles.rows_wrapper}>
                {
                    existingTeams?.map((team,index) => {
                        return <div key={team.key} className={`${Styles.row_item}`}>
                            <p>{team?.name}</p>
                            <div className={Styles.inp_wrapper}>
                                <ClonosInput
                                    limit={8}
                                    type={"number"}
                                    isLabel={false}
                                    uniqueKey={"members"}
                                    errorMessage="Maximum 8 digits allowed."
                                    defaultValue={team?.noOfMembersRequired}
                                    handleGetValues={(val) => handleChangeExistingTeam({value:val?.updatedValue,index})}   
                                />
                            </div>
                        </div>
                    }) 
                }
                {
                    lcTeams?.map((team,index) => {
                        return <div key={team.key} className={`${Styles.row_item}`}>
                            <div>
                            <div className={Styles.t_n_input_wrapper}>
                                <ClonosInput
                                    
                                    isLabel={false}
                                    uniqueKey={"name"} 
                                    defaultValue={team?.name}
                                    handleGetValues={(val) => handleChangeLcTeam({value:val?.updatedValue,index:team.key,key:"name"})}   
                                />
                            </div>
                            </div>
                            <div className={Styles.inp_wrapper}>
                                <ClonosInput
                                    limit={8}
                                    type={"number"}
                                    isLabel={false}
                                    uniqueKey={"members"}
                                    errorMessage="Maximum 8 digits allowed."
                                    defaultValue={team?.noOfMembersRequired}
                                    handleGetValues={(val) => handleChangeLcTeam({value:val?.updatedValue,index:team.key,key:"noOfMembersRequired"})}
                                />
                            </div>
                        </div>
                    }) 
                }
                </div>
                <span className={Styles.a_t_btn} onClick={handleAddLocalTeam}>+ Add Local Team</span>
            </section>
            <footer className={Styles.footer}>
                <div className={Styles.f_controller}>
                <span onClick={closeModalMethod}>Cancel</span>
                <span onClick={() => {
                    setFormData(prev => ({...prev,existingTeams:lcExistingTeams,localTeams:lcTeams}))
                    closeModalMethod()
                }}>Ok</span>
                </div>
            </footer>
            </div>
        </div>
    </Modal>
}