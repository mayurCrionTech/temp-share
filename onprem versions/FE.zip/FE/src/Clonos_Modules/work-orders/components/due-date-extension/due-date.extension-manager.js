import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant";
import { doGetApiCall, doPatchApiCall, doPostApiCall } from "../../../../utils/ClonosApi";
import { handleClientDateInConfiguredTimeZone, handleServerDateInConfiguredTimeZone } from "../../../../utils/clonosCommon";

export const handleRequestDueDateExtension = ({workOrderId,setIsLoading,next,payload}) => {
    const requestPayload = {};
    if(payload?.reason?.length) requestPayload.reason = payload.reason;
    if(payload?.requestedDate?.length) requestPayload.requestedDate = handleClientDateInConfiguredTimeZone({dateString:payload?.requestedDate,parseType:"string"})
    setIsLoading && setIsLoading();
    doPostApiCall({url:`/workOrders/${workOrderId}/requestExtension`,payload:requestPayload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
            next && next()
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading();
    })
}

export const handleGetDueDateExtensionRequest = ({workOrderId,setterMethod,setIsLoading}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:`/workOrders/${workOrderId}/requestExtension`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result?.data)
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading();
    })
}


export const handleApproveDueDateExtension = ({workOrderId,requestInformation,setIsLoading,next,payload}) => {
    const requestPayload = {};
    if(requestInformation?.id) requestPayload.dueDateRequest = requestInformation?.id;
    if(requestInformation?.reason) requestPayload.reason = requestInformation?.reason;
   // if(requestInformation?.dateToExtend?.length) requestPayload.requestedDate = handleServerDateInConfiguredTimeZone({dateString:requestInformation?.dateToExtend.split("T")[0]})
   if (requestInformation?.dateToExtend?.length) {
    const datePart = requestInformation.dateToExtend.split("T")[0];
    requestPayload.requestedDate = new Date(`${datePart}T23:59:59Z`).toISOString();
    }

   setIsLoading && setIsLoading();
    doPatchApiCall({url:`/workOrders/${workOrderId}/approveExtension`,payload:requestPayload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            next && next();
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading();
    })
}