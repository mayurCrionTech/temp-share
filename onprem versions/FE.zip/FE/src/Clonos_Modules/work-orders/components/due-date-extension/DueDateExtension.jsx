import { useEffect, useState } from "react"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "./due-date-extension.module.css"
import { getFormatedDate, getYYYYMMDD_Format, handleClientDateInConfiguredTimeZone, handleLoggedInUser, handleServerDateInConfiguredTimeZone, handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import { CLONOS_GLOBAL_USER_TYPE_OPERATOR } from "../../../../Constants/Constant"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import { handleApproveDueDateExtension, handleRequestDueDateExtension } from "./due-date.extension-manager"
import useToggler from "../../../../CustomHooks/TogglerHook"
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
import ClonosTextarea from "../../../../components/CommonComponents/ClonosTextarea/ClonosTextarea"
import { Height } from "@material-ui/icons"
import { useDispatch } from "react-redux"
export const DueDateExtension = ({isOpen,closeMethod,workOrderId,setRefreshAPI,dueDateRequest}) => {
    const dispatch = useDispatch();
    const [formData,setFormData] = useState({});
    const [request,setRequest] = useState({});
    const [isLoading,setIsLoading] = useToggler();
    const isOperatorLoggedIn = handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR ? true : false;
    const lcHandleGetValues = (props) => {
        const { uniqueKey, updatedValue } = props;
        handlePrimaryObjectModifier({uniqueKey, response: updatedValue})
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    }

    const {isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({isIndexKey: false,hookUniqueKey:"Due Date"});
    
    const handleSave = (actionType) => {
        if(!handleSubmit()) return
        const next = () => {
            closeMethod();
            setRefreshAPI(prev => !prev);
            handleShowErrorAndWarning({dispatch,message:`Extension ${actionType === "request" ? "requested" : "approved"} successfully.`,type:"success",showTime:"5000"});
        }
        if(actionType === "request"){
            handleRequestDueDateExtension({workOrderId,setIsLoading,next:next,payload:formData})
        } else {
          if(formData.requestedDate || request?.requestedDate){
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            let dateToExtend = formData.requestedDate || request?.requestedDate;
            if(dateToExtend && new Date(dateToExtend) < today){
              handleShowErrorAndWarning({dispatch,message:"Requested date should be future date.",type:"error",showTime:"5000"})
            } else {
              handleApproveDueDateExtension({workOrderId,requestInformation:{...(request || {}),dateToExtend},setIsLoading,next})
            }
          }
        }
    }

    useEffect(() => {
      setRequest(dueDateRequest?.length ? dueDateRequest[0] : {}) 
    },[dueDateRequest?.length])


  
    return (
      <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
        <div
          aria-label="Extend Due Date"
          className={Styles.wov_extend_due_date_container}
        >
          <header className={Styles.wov_extend_due_date_header}>
            <span className={Styles.wov_extend_due_date_heading}>
              {isOperatorLoggedIn ? "Request Extension" : "Extend Due Date"}
            </span>
            <CloseIcon tooltipTitle="Close" onClick={closeMethod} />
          </header>
          <section className={Styles.wov_extend_due_date_body}>
            {isOperatorLoggedIn ? (
                <ClonosTextarea
                isLabel={true}
                label={"Reason"}
                uniqueKey="reason"
                isMandatory={true}
                inputStyle={{height:"7rem"}}
                placeholder="Reason for delay"
                errorMessage="Fill the Reason!"
                handleGetValues={lcHandleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              ></ClonosTextarea>
            ) : (
              <div className={Styles.wov_extend_due_date_engineer_container}>
                <div className={Styles.wov_extend_due_date_engineer_reason}>
                  <label>Reason : </label>
                  <span>{request?.reason || "-"}</span>
                </div>
                <div
                  className={Styles.wov_extend_due_date_engineer_requestedDate}
                >
                  <label>Requested Date : </label>
                    <span>{request?.createdAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:request?.createdAt,parseType:"string"})) : "-"}</span>
                  <div>
                    {/* <span>{lcValues?.requestsForDueDateExtension && getDayMonthYear(lcValues?.requestsForDueDateExtension[0]?.requestedDate).day}</span>
                                <span>{lcValues?.requestsForDueDateExtension && getDayMonthYear(lcValues?.requestsForDueDateExtension[0]?.requestedDate).monthString}</span>
                                <span>{lcValues?.requestsForDueDateExtension && getDayMonthYear(lcValues?.requestsForDueDateExtension[0]?.requestedDate).year}</span> */}
                  </div>
                </div>
              </div>
            )}
            <ClonosInput
              type="date"
              isLabel={true}
              isMandatory={true}
              label="Extension Date"
              placeholder="12/30/9999"
              uniqueKey="requestedDate"
              errorMessage="Fill the Date!"
              defaultValue={request?.requestedDate && getYYYYMMDD_Format(handleClientDateInConfiguredTimeZone({dateString:request?.requestedDate,parseType:"string"}))}
              handleGetValues={lcHandleGetValues}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />
            {/* {
                handleLoggedInUser()?.userType?.name === CLONOS_GLOBAL_USER_TYPE_ENGINEER && <div className={Styles.wov_extend_due_date_textarea}>
                    <label>Add Remark</label>
                    <textarea ref={workOrderExtendDateReasonRef} placeholder='Add Remark If Needed.' onChange={(e) => lcHandleGetValues({ uniqueKey: "extendDueDateReason", updatedValue: e.target.value })}></textarea>
                </div>
            } */}
          </section>
          <footer className={Styles.wov_extend_due_date_footer}>
            <ClonosButton
              loading={isLoading}
              onClick={() =>
                handleSave(
                  handleLoggedInUser()?.userType?.name ===
                    CLONOS_GLOBAL_USER_TYPE_OPERATOR
                    ? "request"
                    : "approve"
                )
              }
            >
              {handleLoggedInUser()?.userType?.name ===
              CLONOS_GLOBAL_USER_TYPE_OPERATOR
                ? "Send Request"
                : "Approve"}
            </ClonosButton>
          </footer>
        </div>
      </Modal>
    );
}