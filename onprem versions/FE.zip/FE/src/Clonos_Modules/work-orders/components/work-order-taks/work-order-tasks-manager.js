export const handleChangeLcTask = ({e,setLcTasks,formData,key,setFormData}) => {
    const {value} = e.target;
    const updatedTasks = formData?.tasks?.map((task,i) => {
        if(key === task.key){
            return {...task,description:value}
        } else {
            return task
        }
    })
    setFormData(prev => ({...prev,tasks:updatedTasks}))
}