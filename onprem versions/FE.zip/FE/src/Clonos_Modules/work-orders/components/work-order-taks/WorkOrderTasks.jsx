import { useEffect, useState } from "react"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import Styles from "./work-order-tasks.module.css"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import { handleChangeLcTask } from "./work-order-tasks-manager";
import CircleMinusInteractiveIcon from "../../../../resources/icons/interactive/CircleMinusInteractiveIcon";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import TaskLibraryDropdown from "../../../TaskLibrary/Components/TaskLibraryDropdown/TaskLibraryDropdown";
import { generateUniqueId } from "../../../../utils/clonosCommon";


export const WorkOrderTasks = ({setFormData,formData,serverResponse}) => {
    const [lcIntervals,setLcIntervals] = useState({});
    const [showLibraryModal,setShowLibraryModal] = useState(false);

    const  handleAddLcTask = () => {
        setFormData(prev => ({...prev,tasks:[...(prev?.tasks || []),{description:"",key:generateUniqueId(3)}]}))
    }

    const handleRemoveLcTask = ({taskToDelete}) => {
        const remainingTask = formData?.tasks?.filter((task,i) => task?.key !== taskToDelete?.key );
        let tasksToDelete = formData?.tasksToDelete || [];
        if(taskToDelete?.isFromServer){
            tasksToDelete.push(taskToDelete.id)
        }
        setFormData(prev => ({...prev,tasks:remainingTask,tasksToDelete}));
    }

    const handleMakeFocusOnTastInputTag = ({ elementIdName }) => {
        let lcElement = document.querySelectorAll(`#${elementIdName}`)
        lcElement[lcElement.length - 1].focus()
    }

  const handleGetValues = (props) => {
    const {selectedOption} = props;
    if(formData?.tasks?.length === 1 && !formData?.tasks[0]?.description){
        setFormData(prev => ({...prev,tasks:selectedOption?.map(task => ({description:task?.description,key:generateUniqueId(3)}))}))
    } else {
        setFormData(prev => ({...prev,tasks:[...(prev?.tasks || []),...(selectedOption?.map(task => ({description:task?.description,key:generateUniqueId(3)})) || [])]})) 
    }
  }

  useEffect(() => {
    if(serverResponse?.tasks?.length > 0) {
        setFormData(prev => ({...prev,tasks:serverResponse?.tasks}))
    } else if(!formData?.tasks?.length){
        setFormData(prev => ({...prev,tasks:[{description:"",key:generateUniqueId(3)}]}))
    }
  },[serverResponse?.tasks])
  

    return <>
        <div className={Styles.work_order_add_task}>
            <header className={Styles.wo_ad_header}>
                <p>Add step-by-step procedures, safety precautions, required tools or equipment, and any additional documentation or references</p>
            </header>
            <section className={Styles.wo_ad_content}>
                <div className={Styles.wo_adc_controllers}>
                        <span onClick={() => setShowLibraryModal(true)}>Add from Task Library</span>
                        <span onClick={handleAddLcTask}>+ Add Tasks</span>
                </div>
                <div className={Styles.wo_adc_body}>
                        {/* {
                            formValues?.predefineTasks?.map((task, index) => {
                                    return <div key={generateUniqueId(2)}
                                        // className={Styles.work_order_tasks_input}
                                        className={Styles.work_order_predefine_task}
                                    >
                                        <p>Task {index + 1} -</p>
                                        <span>{task?.description}</span>
                                        <img src={WO_Task_Delete_Icon} alt='Delete WO' onClick={() => handleDeletePredefineTaskOfTaskLibrary({ lcValuesMethod: setFormValues, "id": task._id })} />
                                    </div>
                            })
                        } */}
                        {formData?.tasks?.map((task, i) => {
                            return (
                                    <div
                                        className={Styles.work_order_tasks}
                                        key={task?.key}
                                        display="flex"
                                        justifyContent="space-between"
                                        margin="10px"
                                    >
                                        <div className={Styles.work_order_tasks_input}>
                                                <p>Task {i + 1} -</p>
                                                <input
                                                    tabIndex={13}
                                                    id="subtasks"
                                                    className="subtasks"
                                                    defaultValue={task?.description}
                                                    w="80%"
                                                    onChange={(e) => handleChangeLcTask({e, key:task?.key, formData,setFormData})}
                                                    // onKeyDown={(e) => {
                                                    //         if (e.keyCode === 13) {
                                                    //             setFormData(prev => ({...prev,tasks:[...prev?.tasks,{description:"",key:generateUniqueId(3)}]}))
                                                    //             let interval = setTimeout(() => {
                                                    //                     handleMakeFocusOnTastInputTag({ elementIdName: "subtasks" })
                                                    //             }, 100)
                                                    //             setLcIntervals({ ...lcIntervals, ["subtasksInterval"]: interval })
                                                    //         }
                                                    // }}

                                                    onKeyDown={(e) => {
                                                    const isLast = i === formData?.tasks?.length - 1;
                                                    if (e.keyCode === 13) {
                                                        if (isLast) {
                                                        // Add a new task if on the last one
                                                        setFormData(prev => ({
                                                            ...prev,
                                                            tasks: [...prev.tasks, { description: "", key: generateUniqueId(3) }]
                                                        }));

                                                        const interval = setTimeout(() => {
                                                            handleMakeFocusOnTastInputTag({ elementIdName: "subtasks" });
                                                        }, 100);
                                                        setLcIntervals(prev => ({ ...prev, subtasksInterval: interval }));
                                                        } else {
                                                        // Move focus to the next task input
                                                        const allInputs = document.querySelectorAll(`.subtasks`);
                                                        if (allInputs[i + 1]) allInputs[i + 1].focus();
                                                        }
                                                    }
                                                    }}
                                                    required
                                                    placeholder="Enter Your Task..."

                                                />
                                        </div>
                                        <CircleMinusInteractiveIcon onClick={() => handleRemoveLcTask({taskToDelete:task})}/>
                                    </div>
                            );
                        })}

                </div>

            </section>
        </div>
        {showLibraryModal && <Modal isOpen={showLibraryModal} closeModalMethod={setShowLibraryModal}>
                <TaskLibraryDropdown data={[]} closeModalMethod={setShowLibraryModal} uniqueKey={"predefineTasks"} handleGetValues={handleGetValues} type={"taskLibrary"} />
        </Modal>}
    </>
}