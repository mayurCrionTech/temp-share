import { useState } from "react"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import ClonosTextarea from "../../../../components/CommonComponents/ClonosTextarea/ClonosTextarea"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
import Styles from "./remarks.module.css"
import { doPostApiCall } from "../../../../utils/ClonosApi"
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS } from "../../../../Constants/Constant"
import { handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import useToggler from "../../../../CustomHooks/TogglerHook"
import { useDispatch } from "react-redux"
export const AddRemarks = ({isOpen,closeModalMethod,workOrderId,setRefreshAPI,next}) => {
    const dispatch = useDispatch()
    const {handleSubmit,handleGetErrorActivatorInformation,handlePrimaryObjectModifier} = useFieldsChecker()
    const [remark,setRemark] = useState("");
    const [isLoading,setIsLoading] = useToggler();

    const handleAddRemark = () => {
        if(!handleSubmit()) return;
        setIsLoading();
        doPostApiCall({url:`/workOrders/${workOrderId}/remarks`,payload:{remark}})
        .then(res => {
            if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
                !next && handleShowErrorAndWarning({dispatch,type:"success",message:"Remark added successfully.",showTime:"5000"});
                closeModalMethod();
                !next && setRefreshAPI();
                next && next();
            }
        })
        .finally(setIsLoading)
    }


    return <Modal isOpen={isOpen} closeModalMethod={closeModalMethod} stopOverlayCloser={true}>
    <div className={Styles.wov_remark_container}>
        <header className={Styles.wov_remark_heading_container}>
            <span className={Styles.wov_remark_heading}>Add Remark</span>
            <CloseIcon tooltipTitle="Close" onClick={closeModalMethod} />
        </header>
        <section className={Styles.wov_remark_body}>
            <div className={Styles.wov_remark_textarea}>
                <ClonosTextarea
                    isLabel={true}
                    label="Remark"
                    isMandatory={true}
                    uniquekey={"remark"}
                    inputStyle={{height:"7rem"}}
                    placeHolder="Add Remark"
                    handleGetValues={(val) => {
                        handlePrimaryObjectModifier({uniquekey:"remark",response:val?.updatedValue})
                        setRemark(val?.updatedValue)
                    }}
                    errorMessage="Fill the remark!"
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                />
            </div>
        </section>
        <footer className={Styles.wov_remark_footer_container}>
            <div>
                <ClonosButton onClick={closeModalMethod}>Cancel</ClonosButton>
                <ClonosButton loading={isLoading} variant="filled" onClick={handleAddRemark}>Add Remark</ClonosButton>
            </div>
        </footer>
    </div>
</Modal>
}