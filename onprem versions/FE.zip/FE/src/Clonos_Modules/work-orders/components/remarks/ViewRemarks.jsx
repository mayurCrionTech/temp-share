import { useEffect, useState } from "react";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import Styles from './remarks.module.css'
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import { getFormatAMPM } from "../../../../utils/clonosCommon";
import useToggler from "../../../../CustomHooks/TogglerHook";
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { AddRemarks } from "./AddRemarks";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant";
export const ViewRemarks = ({isOpen,closeMethod,workOrderId}) => {
    const [remarks,setRemarks] = useState([]);
    const [isLoading,setIsLoading] = useToggler();
    const [refreshAPI,setRefreshAPI] = useToggler()
    const [showAddRemarksModal,setShowAddRemarksModal] = useState(false);
    const handleScroll = () => {}
    useEffect(() => {
        setIsLoading();
        doGetApiCall({url:`/workOrders/${workOrderId}/remarks`,params:{page:1,limit:100}})
        .then(res => {
            if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
                setRemarks(res?.data?.result?.data)
            }
        })
        .finally(setIsLoading)
    },[refreshAPI])


    return (
        <>
            {
                showAddRemarksModal  
                ? <AddRemarks isOpen={showAddRemarksModal} closeModalMethod={() => setShowAddRemarksModal(false)} workOrderId={workOrderId} setRefreshAPI={setRefreshAPI}/>
                : <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
                <div className={Styles.container}>
                    <div className={Styles.header}>
                      <h4 onClick={() => setShowAddRemarksModal(true)}>Remarks</h4>
                      <div className={Styles.h_right}>
                        <span onClick={() => setShowAddRemarksModal(true)}>+ Add Remark</span>
                        <CloseIcon onClick={() => closeMethod()} />
                      </div>
                    </div>
                    <div onScroll={handleScroll} className={Styles.section}>
                      {remarks?.length === 0 ? (
                        <div className="center_wrapper">
                          <h4>No Remarks</h4>
                        </div>
                      ) : isLoading ? (
                        <div className="center_wrapper"><ClonosSpinner /></div>
                      ) : (
                        <div className={Styles.remarks_wrapper}>
                          {remarks?.map((remark) => {
                            const time = remark?.createdAt ? getFormatAMPM(remark?.createdAt) : "";
                            const [firstName, lastName] = remark?.createdBy?.name ? remark?.createdBy?.name?.split(" ") : [];
                            const nameInitials = firstName[0] + (lastName ? lastName[0] : "");
                         
                            return (
                              <div className={Styles.remark_wrapper}>
                                <div className={Styles.user_warpper}>
                                  <div className={Styles.profile_wrapper}>
                                    {remark?.profilePhoto ? (
                                      <img src={remark?.profilePhoto} />
                                    ) : (
                                      <h4>{nameInitials}</h4>
                                    )}
                                  </div>
                                  <div className={Styles.name_wrapper}>
                                    <h4>{remark?.createdBy?.name}</h4>
                                    <p>{time}</p>
                                  </div>
                                </div>
                                <div className={Styles.remark_text}>
                                  <p>{remark?.remark}</p>
                                </div>
                                <div className={Styles.remark_breaker}></div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
            </Modal>
            }
        </>
    )
    
}