import { Card } from "@material-ui/core"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS } from "../../Constants/Constant"
import { checkUserHasPermission, commonPageState, getCurrentDate, globalHandleIsAllRequiredFieldAvailable, handleGetHeightOrWidthBasedOnId, handleShowErrorAndWarning, setSerialNumber } from "../../utils/clonosCommon"
import ClonosInput from "../../components/CommonComponents/ClonosInput/ClonosInput"
import ClonosTextarea from "../../components/CommonComponents/ClonosTextarea/ClonosTextarea"
import ClonosSelect from "../../components/CommonComponents/ClonosSelect/ClonosSelect"
import DynamicDropdown from "../../components/CommonComponents/DynamicDropdown/DynamicDropdown"
import { ClonosButton } from "../../components/CommonComponents/Button/Button"
import Modal from "../../components/CommonComponents/Modal/Modal"
import Styles from "./work-order.module.css"
import useFieldsChecker from "../../CustomHooks/FieldsValidatorHook"
import { UnAuthorizedModal } from "../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"
import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { useEffect, useState } from "react"
import { useDispatch } from "react-redux"
import { useLocation, useNavigate } from "react-router-dom"
import { FaGreaterThan } from "react-icons/fa"
import searchIcon from "../../resources/svgs/searchIcon.svg"
import ClonosRadioAndCheckbox from "../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox"
import FileUploader from "../../components/CommonComponents/FileUploader/FileUploader"
import { handleCreateWorkOrder, handleDraftWorkOrder, handleGetFilledValuesOfWorkOrder, handleGetSingleWorkOrder, handleGetTasksDropdownData, handleGetWorkOrderPriorities, handleUpdateWorkOrder } from "./work-order-manager"
import { getDepartmentDropdownData, getTeamDropdownData, getUsersDropdownData } from "../../utils/UsersMethods/usersMethods"
import { handleGetAssets } from "../ClonosAssets/Utils/AssetsListMethods"
import { WorkOrderTasks } from "./components/work-order-taks/WorkOrderTasks"
import { CustmizedTeamDropdown } from "./components/custmized-team-dropdown/CustmizedTeamDropdown"
import { handleGetAssetDropdownData } from "../ClonosAssets/managers/asset-common-managers"
import TaskLibraryDropdown from "../TaskLibrary/Components/TaskLibraryDropdown/TaskLibraryDropdown"
import { MediaBlackStaticIcon } from "../../resources/icons/static/MediaBlackStaticICon"
import ClonosDocumentViewer from "../../components/CommonComponents/document-viewer/ClonosDocumentViewer"
import { ImagePreviewModal } from "../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal"
import { MediaBlueStaticIcon } from "../../resources/icons/static/MediaBlueStaticIcon"
import { handleUploadSingleFileAndGetId } from "../../utils/common-managers"
import { doPostApiCall } from "../../utils/ClonosApi"


const DuplicateWorkOrder = ({mode}) => {
    const Location = useLocation();  
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [formData,setFormData] = useState({});
    const [searchedAssets,setSeachedAssets] = useState({});
    const [searchedUsers,setSeachedUsers] = useState({});
    const [departments,setDepartments] = useState([]);
    const [priorities,setPriorities] = useState([]);
    const [assets,setAssets] = useState({});
    const [teams,setTeams] = useState({});
    const [taskLibraryData,setTaskLibraryData] = useState({})
    const [teamsPagination,setTeamsPagination] = useState(commonPageState);
    const [assetsPagination,setAssetsPagination] = useState(commonPageState);
    const [assignees,setAssignees] = useState({});
    const [assigneesPagination,setAssigneesPagination] = useState(commonPageState);
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false,hookUniqueKey:"work-order"})
    const [cancelWorkOrderAlert,setCancelWorkOrderAlert] = useState(false);
    const [loadersAndFlags,setLoadersAndFlags] = useState({
        fetchTasksLoading:false,
        saveWorkOrderLoading:false,
        draftWorkOrderLoading:false,
        showImagePreviewModal:false,
        showRemarksPreviewModal:false,
        showDraftWorkOrderAlert:false,
        showCancelWorkOrderAlert:false,
        showCustmizedTeamDropdown:false,
        showAddFromTaskLibraryModal:false
    })
    const handleGetValues = (props) => {
        handleGetFilledValuesOfWorkOrder({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier})
    }
    
    const handleSubmitWorkOrder = () => {
        if(!handleSubmit()) return
        if(formData?.name === formData?.nameFromServer) {
            if(primaryObject?.name?.value){
                  primaryObject.name.value = false;
                  primaryObject.name.errorActivatorMethod(true);
                  primaryObject.name.errorSetterMethod("Already exists, please provide different name!");
                  handleSubmit()
                  return
            } else {
                  handleShowErrorAndWarning({dispatch,type:"error",message:"Please change the work order name!",showTime:"5000"});
                  return
            }
        }
        if(!handleValidateDate(formData?.startAt,"startAt")) return
        if(!handleValidateDate(formData?.endAt,"endAt")) return
        const next = () => {
            handleShowErrorAndWarning({dispatch,type:"success",message:"Work Order created successfully.",showTime:"5000"})
            navigate("/work-orders");
        }
        handleCreateWorkOrder({payload:formData,mode:"duplicate",setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveWorkOrderLoading:!prev.saveWorkOrderLoading})),next})
    }

    const handleValidateDate = (date,key) => {
      const dateToCompare = new Date(date);
      const currentDate = new Date();
      const normalizedDateToCompare = new Date(dateToCompare.getFullYear(), dateToCompare.getMonth(), dateToCompare.getDate());
      const normalizedCurrentDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
      if(normalizedDateToCompare < normalizedCurrentDate){
            if(primaryObject?.[key]?.value){
                  primaryObject[key].value = false;
                  primaryObject[key].errorActivatorMethod(true);
                  primaryObject[key].errorSetterMethod(key === "endAt" ? "End date can not be a date before start date!" : "Start date can not be a past date!");
                  handleSubmit()
                  return
            } else {
                  handleShowErrorAndWarning({dispatch,type:"error",message: key === "endAt" ? "End date can not be a date before start date!" : "Start date can not be a past date!",showTime:"5000"});
                  return
            }
      }
      return true
    }

    const handleFetchAssetsOnScroll = () => {
            if(assets?.totalPageCount > assetsPagination?.page){
                  setAssetsPagination(prev => {
                        handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:{limit:prev?.limit,page:prev?.page + 1}})
                        return {...prev,page:prev?.page+1}
                  })
            }
    }

    const handleFetchUsersOnScroll = () => {
      if(assignees?.totalPageCount > assigneesPagination?.page){
            setAssigneesPagination(prev => {
                  getUsersDropdownData({setterMethod: setAssignees, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType",...assigneesPagination} })
                  return {...prev,page:prev?.page+1}
            })
      }
}

    const handleSearchAsset = ({input}) => {
     
      if(input.length){
            handleGetAssetDropdownData({setterMethod:setSeachedAssets,filterPayload:{...assetsPagination,name:input}})
      } else {
            setSeachedAssets({})
      }
    }

    const handleSeachUsers = ({input}) => {
     
      if(input.length){
            getUsersDropdownData({setterMethod: setSeachedUsers, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType",name:input,...assigneesPagination} })
      } else {
            setSeachedUsers({})
      }
    }

    

    useEffect(() => {
        if(formData?.department?.id || formData?.department?.id){
            getTeamDropdownData({setterMethod: setTeams, dispatch, selectedDepartment: formData?.department?.id || formData?.department?.id })
        }
    },[formData?.department?.id,formData?.department?.id])

    useEffect(() => {
      handleGetAssetDropdownData({setterMethod:setAssets,filterPayload:assetsPagination})
    },[assetsPagination?.page,assetsPagination?.limit])
    
    useState(() => {
        getUsersDropdownData({ pagination:assigneesPagination?.pagination, setterMethod: setAssignees, filterPayload:{selectFields: "name,employeeId", populateFields: "department,userType"} })
    },[assigneesPagination?.page,assigneesPagination?.limit])


    useEffect(() => {
      handleGetSingleWorkOrder({setterMethod:setFormData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,fetchWOLoading:!prev.fetchWOLoading})),workOrderId:Location?.state?.workOrderId,mode:"duplicate"})
      handleGetWorkOrderPriorities({setterMethod:setPriorities})
      getDepartmentDropdownData({setterMethod:setDepartments,dispatch});
    },[])
  
    if (checkUserHasPermission({ moduleName: "workOrders", action: CLONOS_GLOBAL_ACTION_CREATE }))
        return (
              <>
                    <nav className={Styles.work_order_nav} /** c = customize */ >
                          <div className={Styles.work_order_nav_first_child}>
                                <b>Status:</b>
                                {
                                      ["Draft", "Scheduled", "Accepted", "Completed"].map((element, index) => {
                                            if (index > 0) return <div> <FaGreaterThan /> <span>{element}</span></div>
                                            return <span>{element}</span>

                                      })
                                }
                          </div>
                          {/* <div className={Styles.work_order_nav_second_child}>
                                <div className={Styles.work_order_nav_second_child_current_date}><b>Created On :</b> <span>{getCurrentDate()}</span></div>
                          </div> */}
                    </nav>
                    <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                          <section className={Styles.work_order_content_body}>
                                <div id='work_order_first_child_container' className={Styles.work_order_first_child_container}>
                                      <ClonosInput
                                            tabIndex={1}
                                            label="Work Order Title"
                                            isLabel={true}
                                            placeholder="Work Order Title"
                                            isMandatory={true}
                                            type="text"
                                            limit='100'
                                            uniqueKey="name"
                                            defaultValue={formData?.name}
                                            handleGetValues={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                      />
                                      <ClonosRadioAndCheckbox
                                        isLabel={true}
                                        uniqueKey="isWorkPermitRequired"
                                        label="Require work permit"
                                        isChecked={formData?.isWorkPermitRequired}
                                        handleGetValues={handleGetValues}
                                      />
                                      <ClonosTextarea
                                            tabIndex={2}
                                            label="Description"
                                            isLabel={true}
                                            placeholder="Description"
                                            type="text"
                                            limit='500'
                                            defaultValue={formData?.description}
                                            uniqueKey="description"
                                            handleGetValues={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                      />
                                      <ClonosSelect
                                            tabIndex={3}
                                            type="select"
                                            label="Department"
                                            isMandatory={true}
                                            isLabel={true}
                                            disabled={false}
                                            uniqueKey="department"
                                            placeholder="Select"
                                            defaultValue={formData?.department?.name}
                                            options={departments?.map(department => ({label:department?.name,value:department?.id,isNeeded:true}))}
                                            handleGetValues={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                      />

                                      <ClonosSelect
                                            tabIndex={4}
                                            type="select"
                                            label="Priority"
                                            isMandatory={true}
                                            isLabel={true}
                                            uniqueKey="priority"
                                            placeholder="Select"
                                            defaultValue={formData?.priority}
                                            options={priorities?.map(priority => ({label:priority,value:priority,isNeeded:true}))}
                                            handleGetValues={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                      />

                                      <DynamicDropdown
                                            label="Asset"
                                            tabIndex={5}
                                            isAsset={true}
                                            isLabel={true}
                                            title={"Asset"}
                                            url={searchIcon}
                                            uniqueKey="asset"
                                            isCheckbox={false}
                                            isActivator={true}
                                            isMandatory={true}
                                            isSearchable={true}
                                            isDynamicLoad={true}
                                            type="dynamicDropdown"
                                            placeholder={"Search"}
                                            disabled={false}
                                            populatedFields={["number"]}
                                            labelActivator={"Asset Name"}
                                            handleGetValues={handleGetValues}
                                            handleDynamicSearch={handleSearchAsset}
                                            handleMoreData={handleFetchAssetsOnScroll}
                                            defaultValue={[{name:formData?.asset?.generalDetails?.name,id:formData?.asset?.id}]}
                                            heading={"Select from Asset Library"}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            data={searchedAssets?.data ? searchedAssets?.data : assets?.data || []}
                                      />

                                      <div className={Styles.work_order_fc_date_and_time}>
                                            <ClonosInput
                                                  tabIndex={6}
                                                  label="Start Date"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="date"
                                                  isMinimum={true}
                                                  uniqueKey="startAt"
                                                  min={true}
                                                  disabled={false}
                                                  defaultValue={formData?.startAt}
                                                  handleGetValues={handleGetValues}
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />
                                            <ClonosInput
                                                  tabIndex={7}
                                                  label="End Date"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="date"
                                                  isMinimum={true}
                                                  uniqueKey="endAt"
                                                  disabled={(formData?.startAt?.length > 0)  ? false : true}
                                                  min={formData?.startAt}
                                                  defaultValue={formData?.endAt}
                                                  handleGetValues={handleGetValues}
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />
                                      </div>
                                      <div className={Styles.work_order_fc_date_and_time}>
                                            <ClonosInput
                                                  tabIndex={8}
                                                  label="Estimation Days"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="number"
                                                  uniqueKey="estimatedDays"
                                                  placeholder="Estimation Days"
                                                  handleGetValues={handleGetValues}
                                                  defaultValue={formData?.estimatedDays}
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />

                                            <ClonosInput
                                                  tabIndex={9}
                                                  label="Hours"
                                                  isLabel={true}
                                                  isMandatory={true}
                                                  type="number"
                                                  uniqueKey="estimatedHours"
                                                  placeholder="Hours"
                                                  range={[0, 23]}
                                                  defaultValue={formData?.estimatedHours || "0"}
                                                  handleGetValues={handleGetValues}
                                                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            />
                                      </div>
                                      <DynamicDropdown
                                            tabIndex={10}
                                            isUser={true}
                                            isLabel={true}
                                            label="Assignee"
                                            url={searchIcon}
                                            isCheckbox={false}
                                            isActivator={true}
                                            isMandatory={true}
                                            title={"Assignee"}
                                            isSearchable={true}
                                            uniqueKey="assignee"
                                            isDynamicLoad={true}
                                            placeholder={"Search"}
                                            type="dynamicDropdown"
                                            labelActivator={"User Name"}
                                            populatedFields={["userType"]}
                                            handleGetValues={handleGetValues}
                                            handleMoreData={handleFetchUsersOnScroll}
                                            handleDynamicSearch={handleSeachUsers}
                                            defaultValue={formData?.assignees || ""}
                                            heading={"Select from Users Library"}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            data={searchedUsers?.data ? searchedUsers?.data.map(user => ({id:user?.id,name:user?.name,userType:user?.userType?.name})) : assignees?.data?.map(user => ({id:user?.id,name:user?.name,userType:user?.userType?.name}))}
                                      />

                                      <DynamicDropdown
                                            isLabel={true}
                                            label="Team"
                                            tabIndex={11}
                                            title={"Team"}
                                            uniqueKey="existingTeams"
                                            labelActivator={"Team Name"}
                                            heading={"Select from Team Library"}
                                            placeholder={"Search"}
                                            isSearchable={true}
                                            isCheckbox={true}
                                            disabled={!Boolean(formData?.department?.id)}
                                            isDynamicLoad={false}
                                            type="dynamicDropdown"
                                            data={setSerialNumber(teams?.data,teamsPagination?.pagination?.page,teamsPagination?.limit)}
                                            isActivator={true}
                                            isMandatory={false}
                                            url={searchIcon}
                                            stopOverlayCloser={true}
                                            // handleMoreData={handleMoreData}
                                            handleNext={() => {
                                                setLoadersAndFlags(prev => ({...prev,showCustmizedTeamDropdown:true}))
                                            }}
                                            defaultValue={formData?.existingTeams?.length ? formData?.existingTeams : []}
                                            handleGetValues={handleGetValues}
                                          //   handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}

                                      />
                                </div>

                                <div className={Styles.work_order_second_child_container}>
                                      <div>
                                          <div className={Styles.media_wrapper}>
                                                <div onClick={() => setLoadersAndFlags(prev => ({...prev,showImagePreviewModal:true}))}>
                                                      {formData?.images?.length ? <MediaBlueStaticIcon/> : <MediaBlackStaticIcon/>}
                                                      <span style={{color:formData?.images?.length ? "#0A5FFF" : "#000"}}>{formData?.images?.length ? "View Images" :"Add Images"}</span>
                                                </div>
                                                {/* <div onClick={() => setLoadersAndFlags(prev => ({...prev,showRemarksPreviewModal:true}))}>
                                                      {formData?.images?.length ? <MediaBlueStaticIcon/> : <MediaBlackStaticIcon/>}
                                                      <span style={{color:formData?.remarks?.length ? "#0A5FFF" : "#000"}}>{formData?.remarks?.length ? "View Remark":"Add Remarks"}</span>
                                                </div> */}
                                          </div>
                                          <WorkOrderTasks setFormData={setFormData} formData={formData} serverResponse={{tasks:[]}}/> 
                                          <FileUploader
                                                tabIndex={12}
                                                label="Documents"
                                                uniqueKey="documents"
                                                typeOfRecord={"Files"}
                                                title="Documents"
                                                isMandatory={false}
                                                limit={10}
                                                fileSizeInMB={10}
                                                acceptableFileTypes={[".jpg", ".jpeg", ".pdf", ".docs"]}
                                                handleGetSelectedData={handleGetValues}
                                                defaultValue={formData.documents}
                                          />
                                      </div>
                                      <div className={Styles.work_order_second_child_submit}>
                                            <div>
                                                  <ClonosButton
                                                        variant="outlined"
                                                        onClick={() => setLoadersAndFlags(prev => ({...prev,showCancelWorkOrderAlert:true}))}>Cancel</ClonosButton>
                                                  <ClonosButton  variant="outlined" onClick={() => setLoadersAndFlags(prev => ({...prev,showDraftWorkOrderAlert:true}))}>Save as Draft</ClonosButton>
                                                  <ClonosButton
                                                        loading={loadersAndFlags?.saveWorkOrderLoading}
                                                        variant="filled"
                                                        onClick={handleSubmitWorkOrder}
                                                    > 
                                                    Submit
                                                    </ClonosButton>
                                            </div>
                                      </div>
                                </div>
                          </section >
                    </Card>
                    {/* <Modal isOpen={isOpen} closeModalMethod={setIsOpen}>
                          <div className={Styles.work_order_add_task_modal} >
                                <header className={Styles.work_order_add_task_modal_header}>
                                      <span>Add Tasks</span>
                                </header>
                                <section>
                                      <div>
                                            <p>Add step-by-step procedures, safety precautions, required tools or equipment, and any additional documentation or references</p>
                                      </div>
                                      <div>
                                            <span onClick={() =>
                                                  setInputSubtastLength([...inputSubtastLength, []])
                                            }>+ Tasks</span>
                                      </div>
                                      <div>
                                            {inputSubtastLength.map((ele, i) => {
                                                  return (
                                                        <div
                                                              className={Styles.work_order_tasks}
                                                              key={i}
                                                              display="flex"
                                                              justifyContent="space-between"
                                                              margin="10px"
                                                        >
                                                              <input
                                                                    id="subtasks"
                                                                    value={ele}
                                                                    w="80%"
                                                                    onChange={(e) => handleChange(e, i, inputSubtastLength, setInputSubtastLength)}
                                                                    onKeyDown={(e) => {
                                                                          if (e.keyCode === 13) {
                                                                                setInputSubtastLength([...inputSubtastLength, []])
                                                                          }
                                                                    }}
                                                                    required
                                                                    placeholder="Enter Your Task..."

                                                              />

                                                              <AiFillCloseCircle onClick={() => handleDeleteSubtasks(i, inputSubtastLength, setInputSubtastLength)} />
                                                        </div>
                                                  );
                                            })}
                                      </div>
                                </section>
                                <button onClick={() => setIsOpen(false)} className={Styles.work_order_add_task_modal_back} >Back</button>
                                <footer className={Styles.work_order_add_task_modal_footer}>
                                      <button onClick={() => setIsOpen(false)}>Continue</button>
                                </footer>
                          </div>
                    </Modal> */}
                    {/* <Modal isOpen={loadersAndFlags.showAddFromTaskLibraryModal} closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showAddFromTaskLibraryModal:!prev.showAddFromTaskLibraryModal}))}>
                          <TaskLibraryDropdown data={taskLibraryData} closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showAddFromTaskLibraryModal:!prev.showAddFromTaskLibraryModal}))} uniqueKey={"predefineTasks"} handleGetValues={handleGetValues} type={"taskLibrary"} />
                    </Modal> */}
                    <ClonosConfirmationBox
                          isOpen={loadersAndFlags?.showDraftWorkOrderAlert}
                          confirmingMethod={() => {  
                              const next = () => {
                                    setLoadersAndFlags(prev => ({...prev,showDraftWorkOrderAlert:false}));
                                    navigate('/work-orders')
                              };
                              handleDraftWorkOrder({dispatch,payload:formData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,draftWorkOrderLoading:!prev.draftWorkOrderLoading})),next})
                          }}
                          loading={loadersAndFlags?.draftWorkOrderLoading}
                          closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showDraftWorkOrderAlert:false}))}
                          headerTitle="Draft Work Order"
                          message="Are you sure, You want to draft this work order ?"
                    />
                    <ClonosConfirmationBox
                          isOpen={cancelWorkOrderAlert}
                          confirmingMethod={() => {
                                setLoadersAndFlags(prev => ({...prev,cancelWorkOrderAlert:false}));
                                navigate(-1)
                          }}
                          closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,cancelWorkOrderAlert:false}))}
                          headerTitle="Work Order Creation."
                          message="Do you confirm that you are want to cancel the work order creation?"
                    />
                    <CustmizedTeamDropdown isOpen={loadersAndFlags.showCustmizedTeamDropdown} localTeams={formData?.localTeams || []} existingTeams={formData?.existingTeams} setFormData={setFormData} closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showCustmizedTeamDropdown:false}))}/>
                    {/* <ClonosDocumentViewer isOpen={loadersAndFlags.showImagePreviewModal} closeMethod={() => setLoadersAndFlags(prev => ({...prev,showImagePreviewModal:!prev.showImagePreviewModal}))} uploadOption={true}/> */}
                    <ImagePreviewModal images={formData?.images} open={loadersAndFlags.showImagePreviewModal} closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showImagePreviewModal:!prev.showImagePreviewModal}))} uploadOption={true} getUploadedDetails={(val) => setFormData(prev => ({...prev,images:val?.files}))}/> 
              </>

        )

  return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default DuplicateWorkOrder