import React from 'react'
import TemplateCreation from '../../ClonosTemplate/TemplateCreation/TemplateCreation'

const ChecklistTemplateCreatePage = ({ mode }) => {
    return (
        <TemplateCreation mode={mode} />
    )
}

export default ChecklistTemplateCreatePage