// All Imports 

// Style Imports 
import Styles from "./CreateChecklistGeneralDetails.module.css";

// Default Hooks 
import React from 'react'
import { useEffect } from "react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";

// Constants Imports 
import { assetDropdownStaticData, daysStaticData, deparmentsStaticData, teamDropdownStaticData, timePeriodStaticData, userDropdownStaticData } from "../../../../Constants/StaticData";
import { CLONOS_GLOBAL_SPECIFIC_DAY_SATURDAY, CLONOS_GLOBAL_SPECIFIC_DAY_SUNDAY, CLONOS_GLOBAL_TIME_PERIOD_DAY, CLONOS_GLOBAL_TIME_PERIOD_HOUR, CLONOS_GLOBAL_TIME_PERIOD_MONTH, CLONOS_GLOBAL_TIME_PERIOD_WEEK, CLONOS_GLOBAL_TIME_PERIOD_YEAR } from "../../../../Constants/Constant";

// Methods Imports
import {
  handleEditChecklistGeneralDetails,
  handleSaveChecklistGeneralDetails,
  handleGetSingleChecklist,
} from "../../../../utils/ChecklistAndReportsMethods/ChecklistMethods";
import AppUrl from "../../../../utils/AppUrl";
import { doGetApiCall, doPostApiCall } from "../../../../utils/ClonosApi";
import {
  handleGetAssetDropdown,
} from "../../../../utils/WorkOrderMethods/WorkOrderMethods";
import { commonPageState, getDayMonthYear, getToken, handleClientDateInConfiguredTimeZone, handleLoggedInUser, handleRemoveDuplicatesFromAnArray, handleShowErrorAndWarning, isPastDateTime, modifyString, parseISOTimeString } from "../../../../utils/clonosCommon";
import { handleGetStaticDropdownValues } from "../../../../utils/DropdownsMethods/DropdownsMethods";

// Custom Hook Imports 
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";

// Local Components Imports 
import RecurrenceCustomization from "../../Components/FrequencyBasedRecurrenceCustomization/RecurrenceCustomization";
import ClonosSpecifyFromAndTo from "../../Components/ClonosSpecifyFromAndTo/ClonosSpecifyFromAndTo";
import UserSpecificCustomization from "../../Components/UserSpecificCustomization/UserSpecificCustomization";

// General Components Imports
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import DynamicDropdown from "../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosTextarea from "../../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import { ClonosToggleButton } from "../../../../components/CommonComponents/ClonosToggleButton/ClonosToggleButton";
import ClonosRadioAndCheckbox from "../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";

// MUI Imports 
import { Card } from "@mui/material";
import { handleGetValues } from "../../../../utils/ChecklistAndReportsMethods/CommonMethods";
import { isDraft } from "@reduxjs/toolkit";
import useMultiPagination from "../../../../CustomHooks/MultiPaginationHook";
import useDebounce from "../../../../CustomHooks/DebounceHook";
import { ChecklistAndReportsAction } from "../../../../Store/Reducers/ClonosChecklistAndReportsReducer";
import { axiosInstance } from "../../../../Api/AxioClient";

const CreateChecklistGeneralDetails = ({ mode }) => {

  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const [formData, setFormData] = useState({ isRecurrence: false, });

  const [teamDropdownData, setTeamDropdownData] = useState([]);
  const [frequencyDropdownData, setFrequencyDropdownData] = useState([]);
  const [departmentDropdownData, setDepartmentDropdownData] = useState([]);
  const [usersDropdownData, setUsersDropdownData] = useState([]);
  const LOCATION = useLocation();
  const { state } = LOCATION;
  const [lcValues, setLcValues] = useState(
    {
      "editGeneralDetailsLoading": false,
      "checklistGeneralDetailsLoading": false,
      "savingLogsGeneralDetailsAsDraftLoading": false,
      "isChangesMade": false,
      mode,
      assetSearchedData: [],
      approverUsers: []
    }
  );
  const [serverResponse, setServerResponse] = useState({
    generalDetails: {},
    assets: {},
    departments: {},
    teams: {},
    assignees: {},
  });
  const [cancelOrGoBackAlert, setCancelOrGoBackAlert] = useState(false);
  const [saveAsDraftLogAlert, setSaveAsDraftLogAlert] = useState(false);

  const [searchAndFilters, setSearchAndFilters] = useState({ assetSearchAndFilterDataRequest: {} });
  const { assetSearchAndFilterDataRequest } = searchAndFilters;
 
  const [uniqueRecurrenceCombinations, setUniqueRecurrenceCombinations] = useState({});
  const { generalDetails, assets } = serverResponse;
  const { approver } = searchAndFilters; // field search and filter.
  const {
    handleGetErrorActivatorInformation,
    handlePrimaryObjectModifier,
    handleSubmit,
    handleGetUpdatedPrimaryObject,
    handleRemoveField
  } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "generalDetails" });

  const { handleSetPage, handleSetLimit, paginations } = useMultiPagination({
    asset: commonPageState,
  });
  const checklistNameUniqueness = useDebounce(formData?.name, 500);
  const checklistDocumentNumberUniqueness = useDebounce(formData?.documentNumber, 500);
  const [isUnique, setIsUnique] = useState(false);


  // To get the teams based on departments 
  const handleGetTeams = (departments) => {
    doGetApiCall({ url: AppUrl.getTeams, params: { businessUnit: handleLoggedInUser().businessUnit.id, selectFields: "name", departments } }).then((res) => {
      setTeamDropdownData(res?.data?.result?.data);
    });
  };

  // To get the users based on the department and team 
  const handleGetUsers = (props) => {
    const { departments = "", teams = "" } = props || {};
    doGetApiCall({
      url: AppUrl.getAllUsers, params: {
        populateFields: "designation,userType,reportsTo",
        selectFields: "designation,userType,reportsTo,name",
        name: searchAndFilters?.approver,
        departments,
        teams
      }
    }).then(res => {
      const manipulatedUsersData = (res?.data?.result?.data || []).map((item) => {
        return { ...item, designation: item?.designation?.name }
      });
      setUsersDropdownData(manipulatedUsersData);
    });
  };

  // This function will redirect to edit template page.
  const handleGoToEditTemplate = () => {
    Navigate(`/edit-checklist-template/${formData?.name ? formData?.name : generalDetails?.name}`, { state: { checklistId: state?.checklistId, structureId: generalDetails?.structureId } });
  };


  const handleGetAssets = ({ page, limit = 15, name }) => {
    return doGetApiCall({ url: AppUrl.getAssets, params: { page, limit, name } }).then((res) => {
   
      return { ...res?.data?.result, data: (res?.data?.result?.data || []).map(item => ({ id: item?.id, name: item?.generalDetails?.name })) };
    });
  };

  const handleLoadMoreData = ({ uniqueKey }) => {
    
    let pagination = paginations[uniqueKey];
   
    switch (uniqueKey) {
      case "asset": {
        if (assets.totalPageCount === pagination?.page) return;
        let updatedPage = null;
        if (pagination?.limit * pagination?.page === assets.data?.length) {
          updatedPage = pagination?.page + 1
        } else {
          updatedPage = pagination?.page
        }
       
        handleGetAssets({ page: updatedPage }).then(assetDataResponse => {
       
          const updatedAssets = handleRemoveDuplicatesFromAnArray({ data: [...assetDataResponse?.data, ...assets.data] })
          
          setServerResponse(prev => (
            {
              ...prev,
              ["assets"]: { ...assetDataResponse, data: updatedAssets }
            }));
        });
        handleSetPage({ page: updatedPage, key: uniqueKey });
      }
    }
  };



  // USE EFFECTS
  useEffect(() => {
    if (mode === "edit") {
      handleGetSingleChecklist(
        {
          responseSetterMethod: setServerResponse,
          checklistId: state?.checklistId,
          lcStateSetterMethod: setLcValues
        }
      )
    }

    // GET TIME PERIODS
    doGetApiCall({ url: AppUrl?.getTimePeriods }).then(timePeriodsResponse => {
    
      setFrequencyDropdownData(timePeriodsResponse?.data?.result?.map((item, index) => ({ name: modifyString(item, "capitalize"), id: `tp_${index + 1}` })))
    })

    // GET ASSETS 
    handleGetAssets({ page: 1, limit: 15 }).then(assetData => {
      setServerResponse(prev => (
        {
          ...prev,
          ["assets"]: assetData
        }));
    });

    // Department Dropdown Data
    doGetApiCall({ url: AppUrl.getDepartments, params: { businessUnit: handleLoggedInUser()?.businessUnit?.id, selectFields: "name" } }).then((res) => {
      setDepartmentDropdownData(res?.data?.result?.data)
    });

    doGetApiCall({
      url: AppUrl.getAllUsers, params: {
        populateFields: "designation,userType,reportsTo",
        selectFields: "designation,userType,reportsTo,name",
      }
    }).then(res => {
      const manipulatedUsersData = (res?.data?.result?.data || []).map((item) => {
        return { ...item, designation: item?.designation?.name }
      });
      setLcValues({ ...lcValues, approverUsers: manipulatedUsersData });
    });

  }, [mode]);


  useEffect(() => {
    formData.departments && handleGetUsers();
  }, [approver]);

  useEffect(() => {
    if (searchAndFilters?.assetSearchAndFilterDataRequest?.input === "") {
      setLcValues({ ...lcValues, ["assetSearchedData"]: [] });
    }
    if (searchAndFilters?.assetSearchAndFilterDataRequest?.input) {
      handleGetAssets({ name: assetSearchAndFilterDataRequest?.input }).then((assetData) => {
       
        setLcValues({ ...lcValues, ["assetSearchedData"]: assetData?.data });
      });
    };
  }, [assetSearchAndFilterDataRequest]);

  // CHECKING THE UNIQUENESS OF THE FIELDS FROM THE SERVER

  const handleCheckUniquenessOfFields = ({ fieldName, input, message }) => {

    const lcInput = input?.trim();

    if (!lcInput) return;
    if (lcInput === generalDetails?.name || lcInput === generalDetails?.documentNumber) {
      setIsUnique(true);
      return;
    }
    const fieldsControllers = handleGetUpdatedPrimaryObject()?.[fieldName];
    axiosInstance().post(AppUrl?.fieldUniqueness, { [fieldName]: lcInput }, {
      headers: {
        Authorization: `Bearer ${getToken()}`
      }
    }).then(uniquenessCheckerResponse => {
      fieldsControllers?.errorActivatorMethod(false);
      setIsUnique(true);
    }).catch(err => {
      setIsUnique(false);
      handleShowErrorAndWarning({ type: "error", dispatch, message: err?.response?.data?.message, showTime: 5000 })
      fieldsControllers?.errorSetterMethod(message);
      fieldsControllers?.errorActivatorMethod(true);
    })
  }

  useEffect(() => {
    handleCheckUniquenessOfFields({ fieldName: "name", input: checklistNameUniqueness, message: "Checklist name already exist." });
  }, [checklistNameUniqueness]);

  useEffect(() => {
    handleCheckUniquenessOfFields({ fieldName: "documentNumber", input: checklistDocumentNumberUniqueness, message: "Document number already exist." });
  }, [checklistDocumentNumberUniqueness]);

  return (
    <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem", overflowY: "auto" }}>

      <div
        className={Styles.main_container}
        aria-label="Parent container for general details">
        <header className={Styles.checklist_gen_details_header}>
          General Details
        </header>
        <section
          className={Styles.split}>
          <div>
            <ClonosInput
              tabIndex={1}
              label="Name"
              isLabel={true}
              placeholder="Name"
              isMandatory={true}
              type="text"
              limit='50'
              uniqueKey="name"
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              defaultValue={state?.mode === "edit" && generalDetails?.name}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <ClonosTextarea
              tabIndex={2}
              label="Description"
              isLabel={true}
              placeholder="Description"
              isMandatory={false}
              type="text"
              limit="1000"
              uniqueKey="description"
              defaultValue={state?.mode === "edit" && generalDetails?.description}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
            />

            <ClonosInput
              tabIndex={3}
              label="Document Number"
              isLabel={true}
              placeholder="Document Number"
              isMandatory={false}
              type="text"
              uniqueKey="documentNumber"
              defaultValue={state?.mode === "edit" && generalDetails?.documentNumber}
              isSpecialCharacterAllow={true}
              onlyAllowTheseSpecialCharacters={["/"]}
              limit="20"
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <DynamicDropdown
              tabIndex={4}
              label="Asset"
              title={"Asset"}
              uniqueKey={"asset"}
              heading={"Select from Asset Library"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={false}
              isDynamicLoad={assets.totalPageCount === paginations["asset"]?.page ? false : true}
              data={lcValues?.assetSearchedData?.length ? lcValues?.assetSearchedData : assets?.data}
              isActivator={true}
              isMandatory={true}
              defaultValue={mode === "edit" && generalDetails?.asset ? [{ "name": generalDetails?.asset }] : null}
              disabled={(mode === "edit" && generalDetails?.checklistStatus !== "draft") ? true : false}
              handleDynamicSearch={(props) => {
               
                // handleGetAssets({ name: props?.input });
                setSearchAndFilters({ ...searchAndFilters, ["assetSearchAndFilterDataRequest"]: { input: props?.input } });
              }}
              handleMoreData={(props) => handleLoadMoreData({ uniqueKey: props?.uniqueKey })}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <DynamicDropdown
              tabIndex={5}
              title={"Departments"}
              label="Departments"
              uniqueKey={"departments"}
              heading={"Select from Departments"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={false}
              isDynamicLoad={false}
              data={departmentDropdownData}
              isActivator={true}
              isMandatory={true}
              defaultValue={mode === "edit" && generalDetails?.departments?.length ? [{ "name": generalDetails?.departments?.[0] }] : null}
              // handleMoreData={() => { }}
              handleGetValues={(props) => {
                handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues });
                const departments = props?.updatedValue?.map(item => item.id).join(",");
                const fieldsControllers = handleGetUpdatedPrimaryObject();
                fieldsControllers["assignees"]?.resetMethod();
                fieldsControllers["teams"]?.resetMethod();
                handleGetTeams(departments);
                handleGetUsers({ departments });
              }}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <DynamicDropdown
              tabIndex={6}
              handleGetErrorMethods={() => { }}
              title={"Teams"}
              uniqueKey={"teams"}
              label="Teams"
              heading={"Select from Team Library"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={false}
              isDynamicLoad={false}
              data={teamDropdownData}
              isActivator={true}
              disabled={formData?.departments ? false : true}
              defaultValue={mode === "edit" && generalDetails?.teams?.length ? [{ "name": generalDetails?.teams?.[0] }] : null}
              // handleMoreData={() => { }}
              handleGetValues={(props) => {
              
                handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues });
                const teams = props?.updatedValue?.map(item => item.id).join(",");
                handleGetUsers({ teams });
              }}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <DynamicDropdown
              tabIndex={7}
              uniqueKey={"assignees"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={false}
              label="Assignees"
              isActivator={true}
              isMandatory={true}
              isDynamicLoad={false}
              data={usersDropdownData}
              // handleMoreData={handleMoreData}
              disabled={formData?.departments ? false : true}
              populatedFields={["designation"]}
              heading={"Select from Users Library"}
              handleDynamicSearch={(response) => {
                setSearchAndFilters({ ...searchAndFilters, ["approver"]: response?.input })
              }}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              defaultValue={mode === "edit" && generalDetails?.assignees?.length ? [{ "name": generalDetails?.assignees?.[0] }] : null}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
            />

            <div
              area-aria-label="to get value for end date"
              className={`${Styles.split_common}`}
            >
              <ClonosInput
                tabIndex={8}
                label="Start Date"
                isLabel={true}
                isMinimum={true}
                placeholder="Start Date"
                isMandatory={true}
                type="datetime-local"
                disabled={(mode === "edit" && generalDetails?.checklistStatus !== "draft") ? true : false}
                min={true}
                uniqueKey="startDate"
                defaultValue={mode === "edit" && (() => {
                  const parsedString = handleClientDateInConfiguredTimeZone({ dateString: generalDetails?.startDateAndTime, parseType: "object" });
                  return `${parsedString?.year}-${parsedString?.month}-${parsedString?.day}T${parsedString?.hour}:${parsedString?.minute}`
                })()}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                handleGetValues={(props) => {
                  // const localProps = { ...props, updatedValue: convertISTtoUTC(props?.updatedValue) };
                  handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
                }}
              />

              <ClonosInput
                tabIndex={9}
                label="End Date"
                isLabel={true}
                placeholder="End Date"
                isMandatory={true}
                isMinimum={true}
                type="datetime-local"
                uniqueKey="endDate"
                defaultValue={mode === "edit" && (() => {
                  const parsedString = handleClientDateInConfiguredTimeZone({ dateString: generalDetails?.endDateAndTime, parseType: "object" });
                  return `${parsedString?.year}-${parsedString?.month}-${parsedString?.day}T${parsedString?.hour}:${parsedString?.minute}`
                })()}
                disabled={(mode === "edit" && generalDetails?.checklistStatus !== "draft") ? true : formData?.startDate?.length > 0 ? false : true}
                min={formData?.startDate}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              />
            </div>

            <ClonosRadioAndCheckbox
              name="generationMode"
              uniqueKey="isRecurrence"
              isLabel={true}
              label="Recurrence"
              type="checkbox"
              disabled={(mode === "edit" && generalDetails?.checklistStatus !== "draft") ? true : false}
              handleGetValues={(props) => {
                if (!props?.updatedValue) {
                  handleRemoveField(["timePeriod", "recurOn", "inEach"]);
                }
                handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
              }}
            />

            {(formData?.isRecurrence || formData?.isStaticGeneration) && <div
              className={Styles.recurrence_container}
            >
              <div
                aria-label="Frequency selection container"
                className={`${Styles.split_common}`}
              >
                <ClonosInput
                  tabIndex={10}
                  label="Every"
                  isLabel={true}
                  placeholder="1"
                  isMandatory={false}
                  type="number"
                  limit='2'
                  uniqueKey="inEach"
                  // defaultValue={state?.mode === "edit" && generalDetails?.name}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={(props) => {

                    handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues });

                  }}
                />
                <ClonosSelect
                  tabIndex={11}
                  type="select"
                  label="Frequency"
                  isMandatory={true}
                  isLabel={true}
                  uniqueKey="timePeriod"
                  placeholder="Select"
                  options={frequencyDropdownData?.map((type) => ({
                    label: `${type?.name}${Number(formData?.inEach) > 1 ? "(s)" : ""}`,
                    value: type.name,
                    isNeeded: true,
                    isChecked: false
                  }))}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                />

              </div>
              {
                formData?.isRecurrence && <RecurrenceCustomization
                  formData={formData}
                  timePeriod={formData?.timePeriod}
                  type="basedOnTimePeriodRecurrence"
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                />
              }



              {formData?.isRange && <div className={Styles.split_common}>
                <ClonosSpecifyFromAndTo
                  heading="From"
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData })}
                  type="time"
                  uniqueKey="from"
                />
                <ClonosSpecifyFromAndTo
                  heading="To"
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData })}
                  type="time"
                  uniqueKey="to"
                  hourMin={formData?.from ? formData?.from?.hour : null}
                  minuteMin={formData?.from ? formData?.to?.hour > formData?.from?.hour ? null : formData?.from?.minute : null}
                />
              </div>}

              {/* <ClonosRadioAndCheckbox
                uniqueKey="isUserSpecificCustomization"
                isLabel={true}
                label="User Specific Customization"
                type="checkbox"
                isMandatory={formData?.assignees?.length > 1 ? true : false}
                handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData })}
                disabled={(formData?.isRecurrence && formData?.assignees?.length && formData?.timePeriod && ((
                  formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_HOUR ||
                  formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_DAY ||
                  formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_WEEK ||
                  formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_MONTH ||
                  formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_YEAR) ?
                  (
                    formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.recurOn ||
                    formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.occursOnSpecificWeekDay ||
                    formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.specificDays ||
                    formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.weekDays ||
                    formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_YEAR
                  ) ? true :
                    false : false)) ? false : true}
              /> */}

              {
                formData?.isUserSpecificCustomization && <div
                  aria-label="user specific customization container"
                  className={Styles.user_specific_customization_container}
                >
                  {
                    (formData?.assignees || []).map((assignee) => {
                      return <UserSpecificCustomization
                        formData={formData}
                        assignee={assignee}
                        timePeriod={formData?.timePeriod}
                        handleGetValues={(props) => {
                          
                          handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData })
                        }}
                        needToDisable={daysStaticData?.filter((item) => {
                          const value = formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.recurOn?.value;
                          if (value === "onlyOnWeekdays" && [CLONOS_GLOBAL_SPECIFIC_DAY_SATURDAY, CLONOS_GLOBAL_SPECIFIC_DAY_SUNDAY].indexOf(item.uniqueKey) > -1) {
                            return item.uniqueKey;
                          }
                          else if (value === "custom" && formData?.basedOnTimePeriodRecurrence) {
                            const selectedDays = formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.occursOnSpecificWeekDay?.map(lc => lc.uniqueKey)
                            if (selectedDays?.indexOf(item.uniqueKey) < 0) {
                              return item.uniqueKey;
                            }
                          }

                        })?.map(lcItem => lcItem?.uniqueKey) || []}
                        needToDisableSpecificDays={formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.weekDays?.map(item => item.specificDay) || []}
                        needToDisableSpecificNumbering={formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.weekDays?.map(item => item.whichWeek) || []}
                        handleUniqueRecurrenceCombinations={setUniqueRecurrenceCombinations}
                      />
                    })
                  }
                </div>
              }
            </div>
            }
          </div>
          <div>
            <ClonosToggleButton
              label="Schedule Report"
              labelPosition="right"
              type="toggle"
              uniqueKey="isScheduleReport"
              disabled={mode === "edit" ? true : false}
              // disabled={true}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
            />
            {
              formData?.isScheduleReport && <>
                <ClonosSpecifyFromAndTo
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  isMandatory={true}
                  heading="Schedule Time"
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                  type="time" uniqueKey="scheduleTime"
                />
                <DynamicDropdown
                  isActivator={true}
                  label="Approver"
                  isMandatory={true}
                  isSearchable={true}
                  heading="Select from User Library"
                  uniqueKey="approver"
                  data={lcValues?.approverUsers}
                  populatedFields={["designation"]}
                  isDynamicLoad={true}
                  // handleDynamicSearch={(response) => {
                  //   setSearchAndFilters({ ...searchAndFilters, [response?.uniqueKey]: response?.input })
                  // }}
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                />
                <div className={Styles.recurrence_frequence_selector_container}>
                  <ClonosInput
                    tabIndex={10}
                    label="Every"
                    isLabel={true}
                    placeholder="1"
                    isMandatory={false}
                    type="number"
                    limit='2'
                    uniqueKey="scheduleReportInEach"
                    // defaultValue={state?.mode === "edit" && generalDetails?.name}
                    handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  />
                  <ClonosSelect
                    tabIndex={11}
                    type="select"
                    label="Frequency"
                    isMandatory={true}
                    isLabel={false}
                    uniqueKey="scheduleReportTimePeriod"
                    placeholder="Select"
                    options={frequencyDropdownData?.map((type) => ({
                      label: `${type?.name}${Number(formData?.inEach) > 1 ? "(s)" : ""}`,
                      value: type.name,
                      isNeeded: (type?.name === "Hour" || type?.name === "Year") ? false : true
                    }))}
                    handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  />
                </div>
                {
                  formData?.scheduleReportTimePeriod && <RecurrenceCustomization
                    timePeriod={formData?.scheduleReportTimePeriod}
                    formData={formData}
                    handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    type="basedOnScheduleReportTimePeriodRecurrence"
                  />
                }
              </>
            }
          </div>
        </section >
        <footer className={Styles.checklist_gen_details_footer}>
          <div>
            {
              mode !== "edit" && <>
                <ClonosButton
                  loading={lcValues?.savingLogsGeneralDetailsAsDraftLoading}
                  onClick={() => {
                    setSaveAsDraftLogAlert(true)
                  }}
                  style={{
                    color: "#06337E",
                    border: "1px solid #06337E",
                    fontSize: "16px",
                    padding: "0.5rem 1rem",
                  }}
                >Save as Draft
                </ClonosButton>

                <ClonosButton
                  isDisabled={!isUnique}
                  loading={lcValues?.checklistGeneralDetailsLoading}
                  variant="filled"
                  onClick={() => {
                    if (!formData?.isScheduleReport) handleRemoveField(["approver", "scheduleReportInEach", "scheduleReportTimePeriod", "scheduleTime", "isOccurOnTheseWeekDays"])
                    if (!handleSubmit()) return;
                    handleSaveChecklistGeneralDetails({ payload: formData, dispatch, Navigate, isDraft: false, responseSetterMethod: setLcValues });
                  }}
                  style={{ fontSize: "16px", padding: "0.5rem 1rem" }}
                >
                  Continue
                </ClonosButton>
              </>
            }
            {
              mode === "edit" && <>
                <ClonosButton
                  onClick={() => {
                    handleEditChecklistGeneralDetails({ dispatch, payload: formData, checklistId: generalDetails?._id, lcStateSetterMethod: setLcValues })
                    Navigate(-1);
                  }}
                  loading={lcValues?.editGeneralDetailsLoading}
                >Save and Exit</ClonosButton>

                <ClonosButton
                  variant="filled"
                  isDisabled={(!isUnique && (checklistNameUniqueness || checklistDocumentNumberUniqueness)) ? true : false}
                  onClick={() => {
                    if (!handleSubmit()) return;
                    if (generalDetails?.checklistStatus === "draft") {
                      handleEditChecklistGeneralDetails({
                        dispatch,
                        payload: formData,
                        checklistId: generalDetails?._id,
                        lcStateSetterMethod: setLcValues,
                        checklistStatus: generalDetails?.checklistStatus,
                        Navigate,
                      });
                    } else {
                      handleEditChecklistGeneralDetails({ dispatch, payload: formData, checklistId: generalDetails?._id, lcStateSetterMethod: setLcValues })
                      handleGoToEditTemplate()
                    }
                  }}
                >Continue</ClonosButton>
              </>
            }
          </div>
        </footer >
      </div >

      <ClonosConfirmationBox
        isOpen={cancelOrGoBackAlert}
        confirmingMethod={() => {
          Navigate(`/view-checklist/${generalDetails?.name}`, { state: { entryId: state?.entryId, checklistId: state?.checklistId } });
          setCancelOrGoBackAlert(false);
        }}
        closeModalMethod={setCancelOrGoBackAlert}
        headerTitle="Edit Checklist"
        message="Are you sure, You don't want to edit this checklist general details?"
      />

      <ClonosConfirmationBox
        isOpen={saveAsDraftLogAlert}
        confirmingMethod={() => {
          handleSaveChecklistGeneralDetails({ payload: formData, dispatch, Navigate, isDraft: true, responseSetterMethod: setLcValues });
          setSaveAsDraftLogAlert(false)
        }}
        closeModalMethod={() => setSaveAsDraftLogAlert(false)}
        headerTitle="Draft Checklist"
        message="Are you sure, You want to draft this log?"
      />
    </Card>
  );
};


export default React.memo(CreateChecklistGeneralDetails)