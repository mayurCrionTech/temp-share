import React, { useState } from 'react'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE } from '../../../../../Constants/Constant'
import { checkUserHasPermission } from '../../../../../utils/clonosCommon'
import ClonosDataGrid from '../../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import ClonosConfirmationBox from '../../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';

const GridManager = (
  {
    rows, columns,
    pagination,
    setPagination,
    uniqueIdField,
    moduleName,
    isLoading,
    deleteLoading,
    handleDelete,
    handleEdit,
    totalDataCount,
    label
  }
) => {
  const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  


  const handleGetSelectedRowsMethod = (props) => {
    setSelectedRows(props.selectedRows)
  }

  return (
    <>
      <div style={{ padding: "2.5rem 2rem", height: "100%" }}>
        <ClonosDataGrid
          rows={rows}
          columns={columns}
          rowCount={rows?.length}
          pageLimit={pagination?.limit}
          totalCount={totalDataCount}
          uniqueIdField={uniqueIdField}
          isDeleteMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowConfirmationDailog(true) : false}
          handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
          isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => handleEdit({ moduleName, label, updatedValue: selectedRows }) : false}
          onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
          loading={isLoading}
          noRowsOverlayMessage="Entries not present yet, To see the template, Please check versions."
        />
      </div>
      <ClonosConfirmationBox
        isOpen={showConfirmationDailog}
        loading={deleteLoading}
        confirmingMethod={() => {
          handleDelete && handleDelete({ moduleName, label, updatedValue: selectedRows });
          setShowConfirmationDailog()
        }}
        closeModalMethod={setShowConfirmationDailog}
        headerTitle={`Delete ${label}.`}
        message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? `this ${label}` : `these ${label}s`}?`}
      />
    </>
  )
}

export default GridManager