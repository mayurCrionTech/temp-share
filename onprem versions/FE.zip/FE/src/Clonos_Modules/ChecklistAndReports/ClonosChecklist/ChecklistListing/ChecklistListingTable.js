import React, { useState } from 'react'
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { checkUserHasPermission, getFormatedDate, handleClientDateInConfiguredTimeZone } from '../../../../utils/clonosCommon'
import { useNavigate } from 'react-router-dom'
import { handleDeleteChecklist } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods'
import { useDispatch } from 'react-redux'
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData"
import { Tooltip } from '@mui/material'
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE } from '../../../../Constants/Constant'

const ChecklistListingTable = ({ tableData, lcDataSetterMethod, totalCount, pageLimit, setPagination, isLoading, setRefreshApi, setRefreshStatusCount }) => {
   
    const [selectedRows, setSelectedRows] = useState([]);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
    const [loading, setLoading] = useState(false);
    const moduleName = useModuleNameProvider()

    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            // flex: 1,
            width: 60,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            field: "checklistNumber",
            headerName: "CHECKLIST NUMBER",
            width: 100,
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.checklistNumber || "-"
        },
        {
            field: "name",
            headerName: "CHECKLIST NAME",
            // width: 200,
            width: "300",
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            renderCell: (params) => {
                return <div
                    style={{ display: "flex", gap: "0.30rem", alignItems: "center" }}
                > <p onClick={() => {
                    if (params?.row?.checklistStatus === "draft") {
                        navigate(`/view-checklist/${params?.row?.name}`,
                            { state: { checklistId: params?.row?._id, name: params?.row?.name, checklistStatus: params?.row?.checklistStatus } }
                        );
                    } else {
                        handleGotoRecurredChecklistListing({ _id: params?.row?._id, name: params?.row?.name });
                    }
                }} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>
                    {params?.row?.checklistStatus === "draft" && <span
                        style={{ ...statusStyleStaticData[params?.row?.checklistStatus], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                        {statusStaticData[params?.row?.checklistStatus]}
                    </span>}
                </div>
            }
        },
        {
            field: "documentNumber",
            headerName: "DOCUMENT NUMBER",
            width: "200",
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.documentNumber || "-"
        },
        {
            field: "isRecurrence",
            headerName: "RECURRING",
            // width:"200",
            width: 100,
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.isRecurrence ? "Yes" : "No"
        },
        {
            field: "timePeriod",
            headerName: "FREQUENCY",
            // width:"200",
            width: 100,
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.timePeriod ? `${params?.row?.timePeriod}ly` : "No"
        },
        {
            field: "templateStatuses",
            headerName: "STATUS",
            width: 400,
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            headerAlign: "center",
            renderCell: (params) => {
                const data = params?.row?.templateStatuses;
          
                if (data?.length === 0) {
                    return <div style={{ width: "100%", textAlign: "center" }}>
                        -
                    </div>
                }
                let priorityList = [0, 0, 0, 0, 0];
                (data || []).forEach((item) => {
                    if (item.status === "pendingForApproval") {
                        priorityList[0] = item;
                    }
                    else if (item.status === "overdue") {
                        priorityList[1] = item;
                    }
                    else if (item.status === "scheduled") {
                        priorityList[2] = item;
                    }
                    else if (item.status === "revised") {
                        priorityList[3] = item;
                    }
                    else if (item.status === "completed") {
                        priorityList[4] = item;
                    };
                })
                priorityList = priorityList.filter(item => item !== 0);
              
                return <div style={{ gap: "0.75rem", display: "flex", justifyContent: "center", width: "100%" }}>
                    {
                        (priorityList || []).map((item, index) => {
                            if (index > 1) return ""
                            return <span
                                style={{ ...statusStyleStaticData[item.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                                {`${statusStaticData[item.status]} ${item.count > 1 ? `(${item.count})` : ""}`}
                            </span>
                        })
                    }
                </div>
            }
        },
        {
            field: "asset",
            headerName: "ASSET",
            width: 200,
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.asset || "-"
        },
        {
            field: "departments",
            headerName: "DEPARTMENTS",
            width: 250,
            // flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            renderCell: (params) => {
                const data = params?.row?.departments;
                return data?.length === 0 ? <span>Not Mentioned</span> :
                    <div style={{ gap: "0.50rem", display: "flex", }}>
                        {data?.length === 1 && <span>{data[0]}</span>}
                        {data?.length === 2 && <>
                            <span>{data[0]},</span>
                            <span>{data[1]}</span>
                        </>}

                        {data?.length > 2 && <Tooltip title={data.slice(2).join(", ")}>
                            +{data.slice(2).length}more
                        </Tooltip>}
                    </div>
            }
        },
        {
            field: "assignedUsers",
            headerName: "ASSIGNED USERS",
            width: 220,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            renderCell: (params) => {
                const data = params?.row?.assignees;
                return <div style={{ gap: "0.50rem", display: "flex", }}>
                    {data?.length === 0 && <span>-</span>}
                    {data?.length === 2 ? <>
                        <span>{data[0]},</span>
                        <span>{data[1]},</span>
                    </> : <>
                        <span>{data[0]}</span>
                    </>}
                    {data?.length > 1 && <span>{data[0]},</span>}
                    {data?.length > 1 && <span>{data[1]},</span>}
                    {data?.length > 2 && <Tooltip title={data.slice(2).join(", ")}>
                        +{data.slice(2).length}more
                    </Tooltip>}
                </div>
            }
        },
        {
            field: "createdAt",
            headerName: "CREATED ON",
            width: 100,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.createdAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "object" })?.clientView : "-"
        },
        {
            field: "updatedAt",
            headerName: "LAST UPDATED ON",
            width: 150,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.updatedAt, parseType: "object" })?.clientView : "-"
        }
    ]

    /**
     * "handleGetSelectedRowsMethod" help to get all the selected rows from the ClonosDataGrid Component.
     * @param {Object} props  
     * @property {Array} props.selectedRows This will contain the the selected rows IDs
     */
    const handleGetSelectedRowsMethod = (props) => {
        setSelectedRows(props.selectedRows)
    }

    /**
     * "handleGoToRecurredChecklistListing" function help to redirect user from checklist to checklist view
     * @param {Object} props Contain the ID of of the checklist that we awant to view. 
     */
    const handleGotoRecurredChecklistListing = (props) => {
    
        navigate(`/checklist-entries`, { state: { _id: props?._id, name: props?.name } })
    }

    /**
     * "handleGoToEditChecklist" function helps to redirect to edit checklist page.
     */
    const handleGoToEditChecklist = () => {
        navigate("/edit-checklist-generaldetails", { state: { "mode": "edit", "checklistId": selectedRows[0] } });

    }

    


    return (
        <>
            <div style={{ padding: "2.5rem 2rem", height: "100%" }}>
                <ClonosDataGrid
                    rows={tableData}
                    columns={columns}
                    rowCount={tableData?.length}
                    pageLimit={pageLimit}
                    totalCount={totalCount}
                    uniqueIdField={"_id"}
                    // isDeleteMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowConfirmationDailog(true) : false}
                    handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
                    isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => handleGoToEditChecklist() : false}
                    onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                    checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
                    loading={isLoading}
                />
            </div>
            <ClonosConfirmationBox
                isOpen={showConfirmationDailog}
                loading={loading}
                confirmingMethod={() => {
                    setLoading(true)
                    handleDeleteChecklist({ dispatch, selectedRows, lcDataSetterMethod, isLocalUpdate: true, responseSetterMethod: { setLoading, setShowConfirmationDailog, setRefreshApi, setRefreshStatusCount } })
                    // setShowConfirmationDailog(false)
                    // setRefreshApi()
                }}
                closeModalMethod={setShowConfirmationDailog}
                headerTitle="Delete Checklist."
                message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this checklist" : "these checklists"}?`}
            />

        </>
    )
}

export default React.memo(ChecklistListingTable)