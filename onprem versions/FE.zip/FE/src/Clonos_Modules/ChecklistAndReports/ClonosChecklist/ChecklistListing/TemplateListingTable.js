import React, { useEffect, useState } from 'react'
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { checkUserHasPermission, commonPageState, getFormatedDate, globalManipulateTemplatePreviewData, handleLoggedInUser, hasPermission, setSerialNumber } from '../../../../utils/clonosCommon'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import useToggler from '../../../../CustomHooks/TogglerHook'
import { doGetApiCall, doPutApiCall } from '../../../../utils/ClonosApi'
import AppUrl from '../../../../utils/AppUrl'
import { ChecklistAndReportsAction } from '../../../../Store/Reducers/ClonosChecklistAndReportsReducer'
import Modal from '../../../../components/CommonComponents/Modal/Modal'
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner'
import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/ChecklistListing/ChecklistListing.module.css"
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { TemplatePreview } from '../../ClonosTemplate/Components/TemplatePreview/TemplatePreview'
import CloseIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import EditIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/EditIcon'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE } from '../../../../Constants/Constant'
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook'



const TemplateListingTable = ({ tableData, lcDataSetterMethod, isLoading }) => {
    const [selectedRows, setSelectedRows] = useState([]);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [lcValues, setLcValues] = useState({
        limit: commonPageState.limit,
        page: commonPageState?.page,
        totalTemplates: null,
        loading: false,
        savedTemplateServerResponse: [],
        getTemplateDataSetsLoading: false,
        manipulatedDataForPreviewChecklistAttributes: [],
        templateId: null,
        deleteTemplateLoading: false
    });
    const { totalTemplates, page, limit, savedTemplateServerResponse, loading, getTemplateDataSetsLoading, manipulatedDataForPreviewChecklistAttributes, templateId, deleteTemplateLoading } = lcValues;
    const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
    const [refreshApi, setRefreshApi] = useToggler();
    const [isImportedTemplatePreviewModal, setIsImportedTemplatePreviewModal] = useState(false);
    const moduleName = useModuleNameProvider();
 

    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            flex: 1,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            field: "templateName",
            headerName: "NAME",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.templateName || "-",
            renderCell: (param) => {
                return <p className="c-pointer" onClick={() => handleGetTemplateDataSets(param, true)} style={{ textDecoration: "underline", color: "#0A5FFF" }}>{param?.row?.templateName || "-"}</p>
            }
        },
        {
            field: "createdDate",
            headerName: "CREATED ON",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.createdAt ? getFormatedDate(params?.row?.createdAt) : "-"
        },
    ];

    /**
     * "handleGetSelectedRowsMethod" help to get all the selected rows from the ClonosDataGrid Component.
     * @param {Object} props  
     * @property {Array} props.selectedRows This will contain the the selected rows IDs
     */
    const handleGetSelectedRowsMethod = (props) => {
        setSelectedRows(props.selectedRows)
    };

    /**
     * "handleGoToChecklistView" function help to redirect user from checklist to checklist view
     * @param {Object} props Contain the ID of of the checklist that we awant to view. 
     */
    const handleGotoChecklistView = (props) => {
        navigate("/checklist-view", { state: { id: props?.id } })
    };

    /**
     * "handleGoToEditChecklist" function helps to redirect to edit checklist page.
     */
    const handleGoToEditChecklist = () => {
        navigate("/create-checklist-generaldetails", { state: { "mode": "edit", "id": selectedRows[0] } })
    };


    const handleGoToCreateGeneralDetails = () => {
        dispatch(ChecklistAndReportsAction.setUseTemplateInformation({ useTemplate: true, templateId }))
        navigate("/create-checklist-generaldetails")
    };

    const handleGetTemplateDataSets = (props, isPreview) => {
    
        setIsImportedTemplatePreviewModal(true);
        setLcValues(prev => {
            return { ...prev, ["getTemplateDataSetsLoading"]: true, templateId: props.id, templateName: props?.row?.templateName }
        })

        doGetApiCall({ url: `${AppUrl.getTemplateDetails}${props.id}` })
            .then(response => {
                
                setLcValues(prev => {
                    let data = globalManipulateTemplatePreviewData({ data: response?.data?.result?.dataSets });
                    

                    if (!isPreview) {
                        dispatch(ChecklistAndReportsAction.setSelectedAttributesToolkitState(data));
                    }
                    return { ...prev, ["manipulatedDataForPreviewChecklistAttributes"]: data };
                });
            }).finally(() => {
                setLcValues(prev => {
                    return { ...prev, ["getTemplateDataSetsLoading"]: false };
                });
            });
    };

    const handleDeleteTemplate = () => {
        setLcValues(prev => {
            return { ...prev, ["deleteTemplateLoading"]: true }
        })
        doPutApiCall(AppUrl.deleteTemplates, { checklistTemplateIds: selectedRows }).then((res) => {
        }).finally(() => {
            setLcValues(prev => {
                return { ...prev, ["deleteTemplateLoading"]: false }
            })
            setShowConfirmationDailog(false)
            setRefreshApi()
        })
    };

    const handleGotoEditTemplate = () => {
        const element = savedTemplateServerResponse.find(item => item._id === selectedRows[0]);
        navigate(`/edit-checklist-template/${element.templateName}`, { state: { generalTemplateId: selectedRows[0], isGeneralTemplate: true, templateName: element?.templateName } });
    };


    const handleGoToEditGeneralTemplate = () => {
        navigate(`/edit-checklist-template/${lcValues?.templateName}`, { state: { generalTemplateId: lcValues?.templateId, isGeneralTemplate: true, templateName: lcValues?.templateName } })
    };

    useEffect(() => {
        setLcValues(prev => {
            return { ...prev, ["loading"]: true }
        })

        doGetApiCall({ url: AppUrl?.getSaveAsTemplates, params: { page, limit } })
            .then(res => {
             
                setLcValues((prev) => {
                    const result = {
                        status: res?.status,
                        data: res?.data?.result.data,
                        message: res?.data?.message,
                        pagination: {
                            currentPage: res?.data?.result?.currentPage,
                            totalPageCount: res?.data?.result?.totalPageCount,
                            totalDataCount: res?.data?.result?.totalDataCount,
                        }
                    }
                    if (!result?.data || !Array.isArray(result.data)) {
                        console.error('Invalid or missing data in the API response.');
                        return prev;
                    }

                    return {
                        ...prev,
                        savedTemplateServerResponse: setSerialNumber(result?.data || [], page, limit),
                        totalTemplates: result?.pagination?.totalDataCount
                    };
                });
            })
            .finally(() => {
                setLcValues(prev => {
                    return { ...prev, ["loading"]: false }
                })
            });
    }, [page, refreshApi]);
   

    return (
        <>
            <ClonosDataGrid
                rows={savedTemplateServerResponse}
                columns={columns}
                pageLimit={limit}
                rowCount={savedTemplateServerResponse?.length}
                totalCount={totalTemplates}
                uniqueIdField={"_id"}
                isDeleteMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowConfirmationDailog(true) : false}
                handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
                isEditMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleGotoEditTemplate() : false}
                onPageChange={e => setLcValues({ ...lcValues, page: e.page + 1, limit: e.pageSize })}
                isLoading={loading}
                checkboxSelection={true}
            />

            <ClonosConfirmationBox
                isOpen={showConfirmationDailog}
                loading={deleteTemplateLoading}
                confirmingMethod={() => {
                    handleDeleteTemplate()
                }}
                closeModalMethod={setShowConfirmationDailog}
                headerTitle="Delete Template."
                message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this template" : "these templates"}?`}
            />

            <Modal isOpen={isImportedTemplatePreviewModal} closeModalMethod={setIsImportedTemplatePreviewModal} >
                <div className={Styles.imported_template_Preview_container}>
                    <header className={Styles.itpc_header}>
                        <span>{lcValues?.templateName}</span>
                        <div className={Styles.itpc_actions}>
                            {checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) && < EditIcon onClick={() => handleGoToEditGeneralTemplate()} />}
                            {checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && <CloseIcon onClick={setIsImportedTemplatePreviewModal} />}
                        </div>
                    </header>
                    {
                        getTemplateDataSetsLoading ? <ClonosSpinner /> : <>
                            <TemplatePreview attributes={manipulatedDataForPreviewChecklistAttributes} isEdit={false} handleUseTemplate={() => {
                                handleGoToCreateGeneralDetails();
                            }} />
                        </>
                    }
                </div>
            </Modal>
        </>
    )
}

export default React.memo(TemplateListingTable)