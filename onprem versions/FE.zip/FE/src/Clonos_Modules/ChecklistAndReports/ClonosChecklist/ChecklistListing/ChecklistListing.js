import Reports from './Reports';
import { Card } from '@mui/material';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react'
import ChecklistListingTable from './ChecklistListingTable';
import ClonosGridNav from '../../../../utils/ClonosGridNav';
import useToggler from '../../../../CustomHooks/TogglerHook';
import Modal from '../../../../components/CommonComponents/Modal/Modal';
import { checkUserHasPermission, commonPageState, handleAllowDirectAccessPage, handleLoggedInUser, handleSegregateURL, hasPermission, setSerialNumber } from '../../../../utils/clonosCommon';
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button';
import CommonNavigator from '../../../../components/CommonComponents/Navigator/Navigator';
import { PendingForApproval, Checks, AllChecklists } from "../../../../assets/UIUX/icons/Checklist/Checklist"
import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/ChecklistListing/ChecklistListing.module.css"
import { handleGetChecklist, handleGetChecklistStatus, handleToggleBetweenChecklistOrTemplateLibrary } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods';

import "../../../../index.css"
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import TemplateListingTable from './TemplateListingTable';
import { UnAuthorizedModal } from '../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal';
import { doGetApiCall } from '../../../../utils/ClonosApi';
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_FILL_ENTRY, CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_MODULE_REPORTS, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../../Constants/Constant';
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook';
// import { GenerateReportModal } from '../../../reports/generate-report/GenerateReport';
import { GenerateReportModal } from "../../../reports/generate-report/GenerateReport";

let navigatorValues = [
    {
        value: "Checklist",
        status: true,
        visibility: (checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) || checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })) ? true : false
    },
    {
        value: "Template Library",
        status: false,
        visibility: checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) ? true : false
    },
];
const ChecklistListing = () => {
    // Local States
    const [toggleBetweenChecklistOrTemplateLibrary, setToggleBetweenChecklistOrTemplateLibrary] = useState("Checklist");
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [checklistData, setChecklistData] = useState([]);
 
    const [isGenerateReport, setIsGenerateReport] = useState(false);
    const [pagination, setPagination] = useState(commonPageState);
    const [totalCount, setTotalCount] = useState(0);
 
    const [isLoading, setIsLoading] = useToggler();
    const [refreshApi, setRefreshApi] = useToggler();
    const [lcValues, setLcValues] = useState({});
    const { loading } = lcValues;
    const [refreshStatusCount, setRefreshStatusCount] = useToggler();
    const URL = handleSegregateURL();
    const moduleName = useModuleNameProvider();


    // Local Handlers
    const handleToggleBetweenChecklistOrTemplateLibrary = (props) => {
        setToggleBetweenChecklistOrTemplateLibrary(props);
    };

    const handleGotoChecklistCreate = () => {
        navigate('/create-checklist-generaldetails');
    };



    /**
 * useEffect hook to fetch and filter checklist data based on URL parameters and user role.
 * 
 * This effect runs whenever the `pagination` or `refreshApi` dependencies change. It checks if the URL contains specific parameters (`unity`, `AR`, `VR`, and `assetId`) to decide whether to fetch checklist data for a specific asset. It then filters the data based on the logged-in user's role and sets the checklist data accordingly.
 * 
 * - If the URL contains `unity`, `AR`, or `VR` along with `assetId`, it fetches the checklist data for that asset.
 * - Filters the checklist items if the logged-in user is an operator.
 * - Sets the filtered data and total data count.
 * - If the URL does not contain these parameters, it fetches all the checklists.
 * 
 * @param {Object} URL - An object containing URL parameters such as `unity`, `AR`, `VR`, and `assetId`.
 * @param {Object} pagination - An object containing pagination details such as `page` and `limit`.
 * @param {Function} handleLoggedInUser - A function that returns the details of the logged-in user.
 * @param {Function} doGetApiCall - A function to make GET API calls.
 * @param {Function} setChecklistData - A function to set the checklist data in the state.
 * @param {Function} setTotalCount - A function to set the total data count in the state.
 * @param {Function} setSerialNumber - A function to set serial numbers for checklist items.
 * @param {Function} handleGetChecklist - A function to fetch all checklists.
 * @param {Function} dispatch - A function to dispatch actions.
 * @param {Function} setIsLoading - A function to set the loading state.
 * @param {Array} CLONOS_GLOBAL_USER_TYPE_OPERATOR - A constant representing the user type for an operator.
 * @param {Array} refreshApi - A dependency array to trigger the effect when refreshed.
 * 
 * @returns {void}
 */
    useEffect(() => {
        if ((URL?.unity && URL?.assetId) || (URL?.AR && URL?.assetId) || (URL?.VR && URL?.assetId)) {
            const loggedInUserDetails = handleLoggedInUser();
            (async () => {
                // const assetId = await handleAllowDirectAccessPage({ keyName: "assetId" });
                const assetId = URL?.assetId;
                doGetApiCall(`/assets/${assetId}/checklists`).then(response => {
                    let data = response?.data?.result;


                    // Filter checklist items based on the logged-in user or who created that checklist.
                    let filteredData = null; // A variable that will store that will store the filtered data based on the below conditions.
                    if (loggedInUserDetails.role_id === CLONOS_GLOBAL_USER_TYPE_OPERATOR) {
                        // Same for Operator
                        filteredData = data?.data?.filter(
                            (item) => item?.assignee?.userId === loggedInUserDetails?.userId
                        );
                    } else {
                        // Remaining roles will comes under here.
                        filteredData = data?.data;
                    }
                    // Set the filtered data using the provided responseSetterMethod.
                    setTotalCount(data?.totalDataCount)
                    const records = setSerialNumber(filteredData, pagination?.page, pagination?.limit);
                    setChecklistData(records);
                }).finally(() => {

                })
            })()
        } else {
            handleGetChecklist({
                dispatch,
                responseSetterMethod: setChecklistData,
                payload: pagination,
                totalRecordSetter: setTotalCount,
                loadingSetter: setIsLoading
            }); // Get all the Checklists
        }
    }, [pagination, refreshApi])

    useEffect(() => {
        handleGetChecklistStatus({ dispatch, responseSetterMethod: setLcValues })
    }, [refreshStatusCount])
    if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
        return (
            <>
                {(!URL?.unity && !URL?.AR && !URL?.VR) && <ClonosGridNav
                    isLoading={loading}
                    items={[
                        {
                            icon: AllChecklists,
                            iconBg: '#E7EFFF',
                            title: 'Total Checklists',
                            count: lcValues?.checklistStatuses?.total
                        },
                        {
                            icon: Checks,
                            iconBg: '#EBFAEC',
                            title: 'Completed Checklists',
                            count: lcValues?.checklistStatuses?.completed
                        },
                        {
                            icon: PendingForApproval,
                            iconBg: '#F7E9BF',
                            title: 'Checklists Pending for Approval',
                            count: lcValues?.checklistStatuses?.pendingForApproval
                        },

                    ]}>
                    <div className="d-fl-al-cen">
                        {checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_REPORTS, action: CLONOS_GLOBAL_ACTION_CREATE }) && <ClonosButton isDisabled={false} onClick={() => setIsGenerateReport(true)} >Generate Report</ClonosButton>}
                        {checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) && <ClonosButton onClick={() => handleGotoChecklistCreate()} variant={"filled"}>Create Checklist</ClonosButton>}
                    </div>
                </ClonosGridNav >}

                <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto" }}>
                    <CommonNavigator web={true} values={(URL?.unity || URL?.AR || URL?.VR) ? [{ value: "Checklist", status: false, visibility: true }] : navigatorValues} getSelectedValue={handleToggleBetweenChecklistOrTemplateLibrary} />
                    {
                        toggleBetweenChecklistOrTemplateLibrary === "Checklist" ?
                            <ChecklistListingTable
                                lcDataSetterMethod={setChecklistData}
                                tableData={checklistData.length > 0 ? checklistData : []}
                                totalCount={totalCount}
                                pageLimit={pagination.limit}
                                setPagination={setPagination}
                                isLoading={isLoading}
                                setRefreshApi={setRefreshApi}
                                setRefreshStatusCount={setRefreshStatusCount}
                            /> : <div className={Styles.template_container}>
                                {
                                    checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_READ }) ?
                                        <TemplateListingTable
                                            lcDataSetterMethod={setChecklistData}
                                            tableData={checklistData.length > 0 ? checklistData : []}
                                            totalCount={totalCount}
                                            pageLimit={pagination.limit}
                                            setPagination={setPagination}
                                            isLoading={isLoading}
                                            setRefreshApi={setRefreshApi}
                                        /> : <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
                                }
                            </div>
                    }
                </Card>
                {isGenerateReport ? <GenerateReportModal isOpen={isGenerateReport} closeMethod={setIsGenerateReport} moduleToGenerateReport={"Checklist"} /> : <></>}
            </>
        )
    }
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default React.memo(ChecklistListing)

