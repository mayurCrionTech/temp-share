import React, { useEffect, useState } from 'react'
import Subbar from '../../../../../components/CommonComponents/ClonosSubbar/Subbar'
import { handleGetRecurredChecklistEntries, handleGetSingleChecklist, handleGetTemplateVersions, handleGetVersionTemplateDataSets } from '../../../../../utils/ChecklistAndReportsMethods/ChecklistMethods'
import { useLocation, useNavigate } from 'react-router-dom'
import { checkUserHasPermission, commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone } from '../../../../../utils/clonosCommon'
import useModuleNameProvider from '../../../../../CustomHooks/ModuleNameProviderHook'
import useToggler from '../../../../../CustomHooks/TogglerHook'
import CommonNavigator from '../../../../../components/CommonComponents/Navigator/Navigator'
import GridManager from './GridManager'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_DOWNLOAD, CLONOS_GLOBAL_ACTION_FILL_ENTRY, CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_COLOUR_BLUE_HOVER } from '../../../../../Constants/Constant'
import { Card } from '@mui/material'
import Styles from "./RecurredChecklistListing.module.css"
import { statusStaticData, statusStyleStaticData } from '../../../../../Constants/StaticData'
import Modal from '../../../../../components/CommonComponents/Modal/Modal'
import CloseIcon from '../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import { TemplatePreview } from '../../../ClonosTemplate/Components/TemplatePreview/TemplatePreview'
import ClonosSpinner from '../../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner'
import EditIcon from '../../../../../assets/Clonos Common Indicators/Icon_Components/EditIcon'


const navigatorKeyEntries = "checklistEntris";
const navigatorKeyVersions = "versions";
const navigatorKeyReports = "reports";

let navigatorValues = [
    {
        value: "Checklist Entries",
        status: true,
        uniqueKey: navigatorKeyEntries,
        disabled: false,
        visibility: (checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_READ }) || checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })) ? true : false
    },
    {
        value: "Versions",
        status: false,
        uniqueKey: navigatorKeyVersions,
        disabled: false,
        visibility: checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) ? true : false
    },
    {
        value: "Reports",
        status: false,
        uniqueKey: navigatorKeyReports,
        disabled: true,
        visibility: checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) ? true : false
    },
];

const RecurredChecklistListing = () => {
    const LOCATION = useLocation();
    
    const navigate = useNavigate();
    const moduleName = useModuleNameProvider();

    const [serverResponse, setServerResponse] = useState(
        {
            generalDetails: {},
            recurredChecklistEntries: [],
            templateVersions: [],
            versionTemplateDetails: {}
        }); // It will contain all the server response in form of key value pair.

    const [lcValues, setLcValues] = useState({
        generalDetailsLoading: false,
        activeTab: navigatorKeyEntries,
        entriesLoading: false,
        versionsLoading: false,
        deleteLoading: false,
        versionTemplatePreviewLoading: false,
        manipulatedDataForVersionTemplatePreview: []
    }); // It will contain all the local values and data.

    const [refreshApi, setRefreshApi] = useToggler(); // When we need to load the component.
    const [pagination, setPagination] = useState(commonPageState);
    const [isVersionTemplateModal, setIsVersionTemplateModal] = useState(false); // Modal opener and closer state 

    // State Destructure
    const {
        generalDetailsLoading,
        activeTab,
        entriesLoading,
        deleteLoading,
        totalDataCount,
        versionsLoading,
        activePreviewVersionTemplate,
        versionTemplatePreviewLoading,
        manipulatedDataForVersionTemplatePreview
    } = lcValues;

    const {
        generalDetails,
        recurredChecklistEntries,
        templateVersions,
        versionTemplateDetails
    } = serverResponse;



    const entriesColumns = [
        {
            field: "index",
            headerName: "SI.NO",
            // flex: 1,
            width: 60,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            // field: "recurringId",
            field: "entryNumber",
            headerName: "RECURRING ID",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            // valueGetter: (params) => params?.row?.entryNumber || "-"
            // valueGetter: (params) => params?.row?.recurringId || "-"
            renderCell: (params) => {
                return <p
                    onClick={() => handleGotoViewChecklistEntry({ entryId: params?.row?._id, name: LOCATION?.state?.name, checklistId: LOCATION.state._id })}
                    style={{ textDecoration: "underline", color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER, cursor: "pointer" }}>
                    {params?.row?.entryNumber || "-"}
                </p>
            }
        },
        {
            field: "createdAt",
            headerName: "DATE",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.createdAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "object" })?.clientView : "-"
        },
        {
            field: "status",
            headerName: "STATUS",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            // valueGetter: (params) => params?.row?.status || "-"
            renderCell: (params) => {
                return <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{params?.row?.status ? statusStaticData[params?.row?.status] : "-"}</p>
            }
        },
        {
            field: "updatedBy",
            headerName: "UPDATED BY",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.updatedBy || "-"
        },

    ]


    const versionsColumns = [
        {
            field: "index",
            headerName: "SI.NO",
            // flex: 1,
            width: 60,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            field: "templateId",
            headerName: "TEMPLATE ID",
            flex: 1,
            // width: 60,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            // valueGetter: (params) => params?.row?.templateId || "-"
            renderCell: (params) => {
                return <p
                    onClick={() => {
                        setLcValues(prev => {
                            if (prev?.activePreviewVersionTemplate?.versionId !== params?.row?._id) {
                                return { ...prev, activePreviewVersionTemplate: { version: params?.row?.version, versionId: params?.row?._id, isActive: false } }
                            } else {
                                return { ...prev, activePreviewVersionTemplate: { version: params?.row?.version, versionId: params?.row?._id, isActive: true } }
                            };
                        })
                        setIsVersionTemplateModal(true);
                    }}
                    style={{ textDecoration: "underline", color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER, cursor: "pointer" }}>
                    {params?.row?.version || "-"}
                </p>
            }
        },
        {
            field: "createdAt",
            headerName: "DATE",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.createdAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "object" })?.clientView : "-"
        }
    ]


    // To get recurred checklist entries;
    useEffect(() => {
        handleGetSingleChecklist({ responseSetterMethod: setServerResponse, lcStateSetterMethod: setLcValues, checklistId: LOCATION?.state?._id })
    }, []);

    // To manage the drid manager with different tabs 
    useEffect(() => {
        handleGridManagerData(activeTab)
    }, [pagination, refreshApi]);

    useEffect(() => {
        setPagination(() => {
            handleGridManagerData({ activeTab, pagination: commonPageState })
            return commonPageState
        });
    }, [activeTab]);

    // Get Version Template DataSets
    useEffect(() => {
        if (lcValues?.activePreviewVersionTemplate && !lcValues?.activePreviewVersionTemplate?.isActive) {
            handleGetVersionTemplateDataSets({
                responseSetterMethod: setServerResponse,
                lcStateSetterMethod: setLcValues,
                templateId: lcValues?.activePreviewVersionTemplate?.versionId,
            });
        }
    }, [isVersionTemplateModal])


    const handleToggle = (_, uniqueKey) => {
        setLcValues(prev => ({ ...prev, ['activeTab']: uniqueKey }))
    };

    const handleDelete = (props) => {
   
        alert(`Delete feature is currently under development`)
    };

    const handleEdit = (props) => {
        navigate("/edit-checklist-generaldetails", { state: { "mode": "edit", entryId: LOCATION?.state?.entryId, "checklistId": LOCATION?.state?._id } });
    };

    const handleGridManagerData = (props) => {
        if ((props.activeTab || activeTab) === navigatorKeyEntries) {
            handleGetRecurredChecklistEntries(
                {
                    responseSetterMethod: setServerResponse,
                    lcStateSetterMethod: setLcValues,
                    checklistId: LOCATION?.state?._id,
                    pagination: props?.pagination ? props?.pagination : pagination
                }
            )
        }
        else if ((props.activeTab || activeTab) === navigatorKeyVersions) {
            handleGetTemplateVersions(
                {
                    responseSetterMethod: setServerResponse,
                    lcStateSetterMethod: setLcValues,
                    checklistId: LOCATION?.state?._id,
                    pagination: props?.pagination ? props?.pagination : pagination
                }
            )
        }
    }

    const handleGotoViewChecklistEntry = (props) => {
   
        navigate(`/view-checklist/${props?.name}`, { state: { entryId: props?.entryId, checklistId: props.checklistId } })
    }


    const handleEditTemplate = () => {
        navigate("/edit-checklist-generaldetails", { state: { "mode": "edit", "checklistId": LOCATION?.state?._id } });
    }



    return (
        <>
            <Subbar
                isStatus={true}
                isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEdit : null}
                isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? handleDelete : null}
                isDownloadMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DOWNLOAD }) ? null : null}
                subbarData={{ status: generalDetails?.checklistStatus }}
                staticElements={
                    [
                        { "key": "Last Updated On:", value: handleClientDateInConfiguredTimeZone({ dateString: generalDetails?.updatedAt, parseType: "object" })?.clientView },
                        { "key": "Last Updated By:", value: generalDetails?.updatedBy ? generalDetails?.updatedBy : "-" },
                    ]
                }
            />
            <Card
                variant="outlined"
                style={{
                    flex: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    overflowY: "auto",
                    height: "100%",
                    margin: "1rem",
                    borderRadius: "1rem"
                }}
            >
                <CommonNavigator web={true} values={navigatorValues} getSelectedValue={handleToggle} />
                {((recurredChecklistEntries?.length && navigatorKeyEntries === activeTab) || (templateVersions?.length && navigatorKeyVersions === activeTab)) ? < GridManager
                    rows={activeTab === navigatorKeyEntries ? recurredChecklistEntries : activeTab === navigatorKeyVersions ? templateVersions : []}
                    columns={activeTab === navigatorKeyEntries ? entriesColumns : activeTab === navigatorKeyVersions ? versionsColumns : []}
                    pagination={pagination}
                    setPagination={setPagination}
                    uniqueIdField={"_id"}
                    moduleName={moduleName}
                    isLoading={entriesLoading || versionsLoading}
                    deleteLoading={deleteLoading}
                    handleDelete={handleDelete}
                    handleEdit={handleEdit}
                    totalDataCount={totalDataCount}
                    label={"Checklist Entries"}
                /> : <div className={Styles.no_grid_data}>
                    <span>{!recurredChecklistEntries && "Entry is not yet scheduled. To view the template, please check the versions."}</span>
                </div>}
            </Card>
            <Modal isOpen={isVersionTemplateModal} closeModalMethod={setIsVersionTemplateModal} >
                <div className={Styles.imported_template_Preview_container}>
                    <header className={Styles.itpc_header}>
                        <span>{lcValues?.activePreviewVersionTemplate?.version}</span>
                        <div className={Styles.split}>
                            <EditIcon onClick={() => handleEditTemplate()} />
                            <CloseIcon onClick={() => setIsVersionTemplateModal(false)} />
                        </div>
                    </header>
                    {
                        versionTemplatePreviewLoading ? <ClonosSpinner /> : <>
                            <TemplatePreview
                                attributes={manipulatedDataForVersionTemplatePreview}
                                isEdit={false}
                            />
                        </>
                    }
                </div>
            </Modal>
        </>
    )
}

export default RecurredChecklistListing