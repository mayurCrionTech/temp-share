import React, { useState } from 'react'
import Styles from "./ChecklistView.module.css"
import { useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { exportChecklistInformaiton, handleApproveFilledEntry, handleApproveTheValidateRequest, handleChangeChecklistStatus, handleCreateValidateRequests, handleDeleteChecklist, handleEditChecklist, handleFillingEntry, handleGetChecklistEntry, handleGetSingleChecklist, handleGetSingleChecklistDetaSets, handleGetValidateRequests, handleUpdateFilledEntry } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods';
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { checkUserHasPermission, generateUniqueId, getDayMonthYear, getFormatedDate, getToken, handleClientDateInConfiguredTimeZone, handleGetENVVariables, handleLoggedInUser, handleRedirectAfterEvent, modifyString, parseISOTimeString } from '../../../../utils/clonosCommon';
import ClonosConfirmationDialog from '../../../../components/Dialogs/ClonosConfirmationDialog';
import { useRef } from 'react';
import { Card, Tooltip } from '@mui/material';
import Modal from '../../../../components/CommonComponents/Modal/Modal';
import ClonosExportOptions from '../../../../components/CommonComponents/ClonosExportOptions/ClonosExportOptions';
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button';
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import COMMON_EYE_ICON from "../../../../assets/UIUX/icons/Common_Icon/COMMON_EYE_ICON.svg"
import ClonosInput from '../../../../components/CommonComponents/ClonosInput/ClonosInput';
import { ChecklistTemplatePreview } from '../../../../components/ClonosChecklist/ChecklistTemplatePreview';
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import { DataGrid } from '@material-ui/data-grid';
import Subbar from '../../../../components/CommonComponents/ClonosSubbar/Subbar';
import useToggler from '../../../../CustomHooks/TogglerHook';
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_DOWNLOAD, CLONOS_GLOBAL_ACTION_FILL_ENTRY, CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_COLOUR_BLUE_HOVER, CLONOS_GLOBAL_STATUS_COMPLETED, CLONOS_GLOBAL_STATUS_DRAFT, CLONOS_GLOBAL_STATUS_OVERDUE, CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL, CLONOS_GLOBAL_STATUS_REVISED, CLONOS_GLOBAL_STATUS_SCHEDULED, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT, CLONOS_GLOBAL_USER_TYPE_ENGINEER, CLONOS_GLOBAL_USER_TYPE_MANAGER } from '../../../../Constants/Constant';
import { ImagePreviewModal } from '../../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal';
import { TemplatePreview } from '../../ClonosTemplate/Components/TemplatePreview/TemplatePreview';
import CloseIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon';
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook';
import ClonosReadMoreReadLess from '../../../../components/CommonComponents/ClonosReadMoreAndLess/ClonosReadMoreAndLess';
import { statusStaticData, statusStyleStaticData } from '../../../../Constants/StaticData';

const ChecklistView = () => {
    // Local States
    const LOCATION = useLocation();
  
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const moduleName = useModuleNameProvider();
    const generalDetailsRef = useRef(null)
    const [lcIntervals, setLcIntervals] = useState({});
    const [isDownloadModal, setIsDownloadModal] = useState(false);
    const [isPreviewTemplateModal, setIsPreviewTemplateModal] = useState(false);
    const [needToExportFileDetails, setNeedToExportFileDetails] = useState({});
    const [allAreasThatNeedsToExportAsPDFState, setAllAreasThatNeedsToExportAsPDFState] = useState([]);
    const [isEditEntry, setIsEditEntry] = useToggler();

    const [lcValues, setLcValues] = useState({
        validateLoading: false,
        approveLoading: false,
        reviseLoading: false,
        validateRequestServerResponse: null,
        checklistEntryDetailsLoading: false,
        manipulatedDataForTemplatePreview: [],
        updatedFilledEntryLoading: false,
        approveFilledEntryLoading: false
    });

  

    const [serverResponse, setServerResponse] = useState({
        entryDetails: {},
        lcChecklistData: {}
    });

    const [confirmationDialogStates, setConfirmationDialogStates] = useState(
        {
            checklistDeleteState: false,
        }
    );

    const [isValidateConfirmationModal, setIsValidateConfirmationModal] = useState(false);
    const [isNotePreviewModal, setIsNotePreviewModal] = useState(false);
    const [refreshApi, setRefreshApi] = useToggler();
    const [isImagePreviewModal, setIsImagePreviewModal] = useToggler();

    const {
        validateRequestServerResponse,
        images,
        checklistEntryDetailsLoading,
        manipulatedDataForTemplatePreview,
        updatedFilledEntryLoading,
        approveFilledEntryLoading
    } = lcValues;

    const { entryDetails, lcChecklistData } = serverResponse;
   

    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.index || "-"
        },
        {
            field: "asset",
            headerName: "Asset",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.asset || "-",
        },
        {
            field: "fieldName",
            headerName: "Field Name",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.fieldName || "-",
        },
        {
            field: "fieldValue",
            headerName: "Value",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => {

                const row = params.row;
                if (row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT || row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE) {
                    return row?.fieldValue ? row?.fieldValue : "-";
                } else {
                    const filteredData = row?.fieldValue?.filter(item => item?.isActive);
                    const data = filteredData?.map(item => item?.optionValue);
                    return data?.length ? data?.join(" | ") : "-"
                }
            }
        }
    ];


    const handleGetDetails = (props) => {
        setNeedToExportFileDetails(props)
    };

    const handleExportFile = () => {
        exportChecklistInformaiton(
            {
                fileName: needToExportFileDetails?.fileName,
                type: needToExportFileDetails?.format,
                pdfData: allAreasThatNeedsToExportAsPDFState,
                pageType: needToExportFileDetails?.pageType,
                xlsxData: lcChecklistData
            })
        setIsDownloadModal(false)
    };


    const lcHandleGoToChecklistEdit = () => {
        navigate("/edit-checklist-generaldetails", { state: { "mode": "edit", entryId: LOCATION?.state?.entryId, "checklistId": LOCATION?.state?.checklistId } });
    };

    const lcHandleDelete = () => {
        setConfirmationDialogStates({ ...confirmationDialogStates, ["checklistDeleteState"]: true });
    };

    const handleGetUpdatedDataSets = (attributes, handleLoader) => {
        attributes = attributes?.map(attribute => {
            if (
                (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
                    attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
                    attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN) && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })
            ) {
                return { index: attribute?.index, fieldValue: attribute?.fieldValue?.filter(item => item?.isActive).map(item => item?.optionId), type: attribute?.type };
            } else {
                return { index: attribute?.index, fieldValue: attribute?.fieldValue, type: attribute?.type };
            }
        });
        if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) {
            handleUpdateFilledEntry({
                lcStateSetterMethod: setLcValues,
                entryId: LOCATION?.state?.entryId,
                payload: { data: attributes },
                handleRefresh: setRefreshApi,
                handleFinallyExecutors: { setIsEditEntry, handleLoader },
                dispatch
            });
        } else if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })) {
            handleFillingEntry({
                lcStateSetterMethod: setLcValues,
                entryId: LOCATION?.state?.entryId,
                payload: { data: attributes },
                handleRefresh: setRefreshApi,
                handleFinallyExecutors: { setIsEditEntry, handleLoader },
                dispatch
            });
        };
    };

    useEffect(() => {
        if (LOCATION?.state?.checklistStatus !== "draft" && LOCATION?.state?.checklistStatus !== "scheduled") {
            handleGetChecklistEntry({
                responseSetterMethod: setServerResponse,
                entryId: LOCATION?.state?.entryId,
                lcStateSetterMethod: setLcValues,
            });
        } else {
            handleGetSingleChecklist({ responseSetterMethod: setServerResponse, lcStateSetterMethod: setLcValues, checklistId: LOCATION.state?.checklistId })
        }
    }, [refreshApi]);


    useEffect(() => {
        
        setServerResponse(prev => ({ ...prev, ["lcChecklistData"]: serverResponse?.generalDetails }));
    }, [serverResponse?.generalDetails])



    return (
        <>
            <Subbar
                isStatus={true}
                isEditMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? lcHandleGoToChecklistEdit : null}
                isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? lcHandleDelete : null}
                isDownloadMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DOWNLOAD }) ? () => setIsDownloadModal(true) : null}
                subbarData={{ status: entryDetails?.checklistEntry?.status }}
                staticElements={
                    [
                        { "key": "Last Updated On:", value: handleClientDateInConfiguredTimeZone({ dateString: entryDetails?.checklistEntry?.updatedAt, parseType: "object" })?.clientView },
                        { "key": "Last Updated By:", value: lcChecklistData?.updatedBy ? lcChecklistData?.updatedBy : "-" },
                    ]
                }
                htmlElements={[
                    <div style={{ display: manipulatedDataForTemplatePreview?.length > 0 ? "flex" : "none" }} key={generateUniqueId(2)} onClick={() => setIsPreviewTemplateModal(true)}>
                        <img src={COMMON_EYE_ICON} alt='Eye Icon' loading='lazy' />
                        <span style={{
                            color: "#0A5FFF",
                            fontFamily: "Roboto",
                            fontSize: "1rem",
                            fontStyle: "normal",
                            fontWeight: "600",
                            lineHeight: "normal"
                        }}>Preview</span>
                    </div>
                ]}
            />
            <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                <div className={Styles.template_and_general_detail_container}>
                    <div className={Styles.sub_header} aria-label='Sub Header'>
                        <span aria-label='Checklist Title'>{lcChecklistData?.name}</span>
                        <div className={Styles.validate_container} aria-label='Validate the checklist data sets contianer'>
                            {
                                handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER && validateRequestServerResponse?.length > 0 && <>

                                    <ClonosButton loading={lcValues?.reviseLoading} isDisabled={lcValues?.reviseLoading || lcChecklistData?.status === "revised" ? true : false} variant="outlined" onClick={() => {
                                        setLcValues(prev => {
                                            return { ...prev, "reviseLoading": true }
                                        })
                                        handleChangeChecklistStatus({ checklistId: lcChecklistData?.id, dispatch, payload: { status: "revised", isGetResponse: true }, setRefreshApi, responseSetterMethod: setLcValues })
                                        // setRefreshApi()
                                    }}>Revise</ClonosButton>
                                    <ClonosButton
                                        loading={lcValues?.validateLoading || lcValues?.approveLoading}
                                        isDisabled={lcValues?.validateLoading || lcValues?.approveLoading}
                                        onClick={() => setIsValidateConfirmationModal(true)}
                                        variant="filled"
                                    >APPROVE</ClonosButton>
                                </>
                            }
                            {
                                handleLoggedInUser()?.role_id !== CLONOS_GLOBAL_USER_TYPE_MANAGER && handleLoggedInUser().role_id === CLONOS_GLOBAL_USER_TYPE_ENGINEER && lcChecklistData?.status !== "completed" &&
                                <>
                                    {

                                        lcChecklistData?.isManagerApprovalRequired === false && <ClonosButton loading={lcValues?.reviseLoading} isDisabled={lcValues?.reviseLoading || lcChecklistData?.status === "revised" ? true : false} variant="outlined" onClick={() => {
                                            setLcValues(prev => {
                                                return { ...prev, "reviseLoading": true }
                                            })
                                            handleChangeChecklistStatus({ checklistId: lcChecklistData?.id, dispatch, payload: { status: "revised", isGetResponse: true }, setRefreshApi, responseSetterMethod: setLcValues })
                                            // setRefreshApi()
                                        }}>Revise</ClonosButton>
                                    }
                                    <ClonosButton
                                        loading={lcValues?.validateLoading || lcValues?.approveLoading}
                                        isDisabled={lcValues?.validateLoading || validateRequestServerResponse?.length > 0 && true}
                                        onClick={() => {
                                            if (lcChecklistData?.isManagerApprovalRequired === false) {
                                                handleChangeChecklistStatus({ checklistId: lcChecklistData?.id, dispatch, payload: { status: "completed", isGetResponse: true }, setRefreshApi })
                                            }
                                            else {
                                                setIsValidateConfirmationModal(true)
                                            }
                                        }}
                                        variant="filled"
                                    >{lcChecklistData?.isManagerApprovalRequired ? "Validate" : "Approve"}</ClonosButton>
                                </>
                            }
                            {
                                (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) &&
                                    entryDetails?.checklistEntry?.status !== CLONOS_GLOBAL_STATUS_SCHEDULED &&
                                    entryDetails?.checklistEntry?.status !== CLONOS_GLOBAL_STATUS_REVISED &&
                                    lcChecklistData?.checklistStatus !== CLONOS_GLOBAL_STATUS_DRAFT
                                ) && <ClonosButton
                                    onClick={setIsEditEntry}
                                >{isEditEntry ? "Cancel" : "Edit Data"}</ClonosButton>
                            }
                            {
                                (entryDetails?.checklistEntry?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) && <ClonosButton
                                    variant="filled"
                                    isDisabled={isEditEntry}
                                    onClick={() => handleApproveFilledEntry({ lcStateSetterMethod: setLcValues, dispatch, entryId: LOCATION?.state?.entryId, handleRefresh: setRefreshApi })}
                                    loading={approveFilledEntryLoading}
                                >
                                    Approve
                                </ClonosButton>
                            }
                        </div>
                    </div>
                    {checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) && <div className={Styles.checklist_view_general_details_container}>
                        <section aria-label='General details' className={Styles.checklist_view_general_details} >
                            <div className={Styles.checklist_view_general_details_child_container} ref={generalDetailsRef}>
                                <table>
                                    <tr>
                                        <td>Document Number</td>
                                        <td>{lcChecklistData?.documentNumber ? lcChecklistData?.documentNumber : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Name</td>
                                        <td>{lcChecklistData?.name ? lcChecklistData?.name : "Not Mentioned"} <span
                                            style={{ ...statusStyleStaticData[lcChecklistData?.checklistStatus], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                                            {`${statusStaticData[lcChecklistData?.checklistStatus]}`}
                                        </span></td>
                                    </tr>
                                    <tr>
                                        <td>Description</td>
                                        <ClonosReadMoreReadLess text={lcChecklistData?.description ? lcChecklistData?.description : "Not Mentioned"} maxLength={100} />
                                    </tr>
                                    <tr>
                                        <td>{lcChecklistData?.departments?.length > 1 ? "Departments" : "Department"}</td>
                                        <td>{lcChecklistData?.departments?.length ? lcChecklistData?.departments?.map(item => {
                                            return <span>{lcChecklistData?.departments?.length > 1 ? `${item}, ` : item}</span>
                                        }) : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>{`Assigned ${lcChecklistData?.assignees?.length > 1 ? "Users" : "User"}`}</td>
                                        <td>{lcChecklistData?.assignees?.length ? lcChecklistData?.assignees?.map(item => {
                                            return <span>{lcChecklistData?.assignees?.length > 1 ? `${item}, ` : item}</span>
                                        }) : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>{lcChecklistData?.teams?.length > 1 ? "Teams" : "Team"}</td>
                                        <td>{lcChecklistData?.teams?.length ? lcChecklistData?.teams?.map(item => {
                                            return <span>{lcChecklistData?.teams?.length > 1 ? `${item}, ` : item}</span>
                                        }) : "Not Mentioned"}</td>
                                    </tr>
                                </table>
                                <table>
                                    <tr>
                                        <td>Frequency</td>
                                        <td>{lcChecklistData?.recurrenceDetails?.timePeriod ? `${modifyString(lcChecklistData?.recurrenceDetails?.timePeriod, "capitalize")}ly ${lcChecklistData?.recurrenceDetails?.frequency && `(Every ${lcChecklistData?.recurrenceDetails?.frequency})`}` : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Asset</td>
                                        <td style={{ color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER }}>{lcChecklistData?.asset ? lcChecklistData?.asset : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Scheduled Time</td>
                                        <td>{(() => {
                                            const parsedISOTimeString = handleClientDateInConfiguredTimeZone({ dateString: entryDetails?.checklistEntry?.entryCreatedAt, parseType: "object" })
                                           
                                            if (!parsedISOTimeString) return "-"
                                            return `${parsedISOTimeString?.clientView} ${parsedISOTimeString?.time}`
                                        })()}</td>
                                    </tr>
                                    <tr>
                                        <td>Created On</td>
                                        <td>{lcChecklistData?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: lcChecklistData?.createdAt, parseType: "object" }).clientView : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Last Updated On</td>
                                        <td>{entryDetails?.checklistEntry?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: entryDetails?.checklistEntry?.updatedAt, parseType: "object" }).clientView : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Recurrence</td>
                                        <td style={{ color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER }}>{lcChecklistData?.isRecurrence ? "Yes" : "No"}</td>
                                    </tr>
                                </table>
                            </div>
                        </section>
                    </div>}
                    <div className={Styles.checklist_view_template_container}>
                        <div className={Styles.template_heading_contianer}>
                            {entryDetails?.checklistEntry?.images && <span onClick={setIsImagePreviewModal}>View Images</span>}
                            {entryDetails?.checklistEntry?.note && <span onClick={() => setIsNotePreviewModal(true)}>View Notes</span>}
                        </div>
                        {
                            ((isEditEntry && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) || (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY }) && (entryDetails?.checklistEntry?.status === CLONOS_GLOBAL_STATUS_SCHEDULED || entryDetails?.checklistEntry?.status === CLONOS_GLOBAL_STATUS_OVERDUE))) ? <TemplatePreview
                                isEdit={(entryDetails?.checklistEntry?.status === CLONOS_GLOBAL_STATUS_COMPLETED && !checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) ? false : true}
                                loading={updatedFilledEntryLoading}
                                attributes={manipulatedDataForTemplatePreview}
                                handleGetUpdatedDataSets={handleGetUpdatedDataSets}
                            /> : manipulatedDataForTemplatePreview?.length > 0 ? <ClonosDataGrid
                                rows={manipulatedDataForTemplatePreview ? manipulatedDataForTemplatePreview : []}
                                columns={columns}
                                pageLimit={10}
                                isEdit={false}
                                isDelete={false}
                                uniqueIdField="id"
                                loading={checklistEntryDetailsLoading}
                                checkboxSelection={false}
                            /> : <div style={{ height: "200px", width: "100%", display: 'flex', justifyContent: "center", alignItems: "center" }}>
                                <span style={{ fontSize: "1.25rem", fontWeight: "500" }}>No template added yet.</span></div>
                        }
                    </div>

                </div>
            </Card >

            <Modal isOpen={isDownloadModal} closeModalMethod={setIsDownloadModal}>
                <ClonosExportOptions handleGetDetails={handleGetDetails} handleExportFile={handleExportFile} formats={["pdf", "xlsx"]} />
            </Modal>

            <Modal isOpen={isPreviewTemplateModal} closeModalMethod={setIsPreviewTemplateModal}>
                <div className={Styles.preview_container}>
                    <TemplatePreview
                        attributes={manipulatedDataForTemplatePreview}
                        isEdit={false}
                    />
                </div>
            </Modal>

            <Modal
                isOpen={isNotePreviewModal}
                closeModalMethod={setIsNotePreviewModal}
            >
                <div aria-label='view note'
                    className={Styles.view_note}>
                    <header className={Styles.vn_header}>
                        <span>Note</span>
                        <CloseIcon onClick={() => setIsNotePreviewModal(false)} />
                    </header>
                    <p>{entryDetails?.ChecklistEntry?.note}</p>
                </div>
            </Modal>

            <ClonosConfirmationBox // Approval request and request handler confirmation box.
                isOpen={isValidateConfirmationModal}
                confirmingMethod={() => {
                    if (handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER) {
                        handleApproveTheValidateRequest({ dispatch, checklistId: lcChecklistData?.id, requestId: validateRequestServerResponse[0]?.requestId, responseSetterMethod: setLcValues, uniqueKey: "approveLoading", payload: { status: "completed" }, setRefreshApi })
                    } else {
                        handleCreateValidateRequests({ dispatch, checklistId: lcChecklistData?.id, responseSetterMethod: setLcValues, uniqueKey: "validateLoading" })
                        setRefreshApi()
                    }
                    setIsValidateConfirmationModal(false)
                }}
                closeModalMethod={setIsValidateConfirmationModal}
                headerTitle="Sending for approval."
                message={handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER ? "Are you sure, that you are approving this data entry?" : "Do you confirm that you are sending this checklist for further approval?"}
            />

            <ClonosConfirmationBox // Checklist delete confirmation box.
                isOpen={confirmationDialogStates?.checklistDeleteState}
                confirmingMethod={async () => {
                    try {
                        const response = await handleDeleteChecklist({ dispatch, selectedRows: [lcChecklistData.id], isLocalUpdate: false }); // here it will return the response and based on the status we are restructing the user to redirect to the next page like if the status is note

                        if (response && (response.status === 200 || response.status === 201)) {
                            let interval = handleRedirectAfterEvent({ targetRoute: "/checklists", timeout: 1000, navigate });
                            setLcIntervals({ ...lcIntervals, "deleteChecklist": interval });
                        }
                    } catch (error) {
                        console.error('Error during checklist deletion:', error);
                    } finally {
                        setConfirmationDialogStates({ ...confirmationDialogStates, ["checklistDeleteState"]: false });
                    }
                }}
                closeModalMethod={() => setConfirmationDialogStates({ ...confirmationDialogStates, ["checklistDeleteState"]: false })}
                headerTitle="Delete Checklist."
                message="Are you sure, You want to delete this checklist?"
            />

            <ImagePreviewModal // For view the uploaded images of the template
                open={isImagePreviewModal}
                activeImageIndex={1}
                closeModalMethod={setIsImagePreviewModal}
                images={images || []}
            />

        </>
    );
};

export default React.memo(ChecklistView)