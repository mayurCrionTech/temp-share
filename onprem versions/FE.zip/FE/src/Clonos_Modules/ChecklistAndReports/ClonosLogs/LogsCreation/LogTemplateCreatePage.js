// import { useState, memo } from "react";
// import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/TemplateCreationPage.module.css";
// import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
// import PREVIEWICON from "../../../../assets/UIUX/icons/Checklist/eye-preview.svg";
// import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
// import { useSelector } from "react-redux";
// import PLUSICON from "../../../../assets/UIUX/icons/Checklist/white-plus.svg";
// import EXPANDDOWN from "../../../../assets/UIUX/icons/Checklist/caret-down.svg";
// import { useEffect } from "react";
// import { useDispatch } from "react-redux";
// import {
//   commonPageState,
//   getFormatedDate,
//   globalHandleIsAllRequiredFieldAvailable,
//   globalManipulateTemplatePreviewData,
//   globalOnScrollEnd,
//   hasPermission,
// } from "../../../../utils/clonosCommon";
// import { TemplateAttributes } from "../../../../components/ClonosChecklist/TemplateAttributes";
// import ChecklistTemplateTable from "../../../../components/ClonosChecklist/ChecklistTemplateTable";
// import { v4 as uuidv4 } from "uuid";
// import Modal from "../../../../components/CommonComponents/Modal/Modal";
// import { ChecklistTemplatePreview } from "../../../../components/ClonosChecklist/ChecklistTemplatePreview";
// import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
// import { SaveChecklistAsTemplate } from "../../../../components/ClonosChecklist/CreateChecklist/SaveChecklistAsTemplateModal";
// import { handleSaveChecklistDataSetsMethod } from "../../../../utils/ChecklistAndReportsMethods/ChecklistMethods";
// import { useLocation, useNavigate } from "react-router-dom";
// import { UnAuthorizedModal } from "../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
// import { Card } from "@material-ui/core";
// import { Search, SingleCheck } from "../../../../assets/UIUX/icons/Checklist/Checklist";
// import { doGetApiCall, doPostApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import useToggler from "../../../../CustomHooks/TogglerHook";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import useDebounce from "../../../../CustomHooks/DebounceHook";
// import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
// import { LogsAndReportsAction } from "../../../../Store/Reducers/ClonosLogsReducer";
// import { handleSaveLogDataSetsMethod } from "../../../../utils/ChecklistAndReportsMethods/LogsMethod";
// import { SaveLogAsTemplate } from "./SaveLogTemplate";
// import BackIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/BackIcon";



// let primaryObject = {};
// const ChecklistTemplateCreatePage = () => {
//   const dispatch = useDispatch();
//   const Navigate = useNavigate();
//   const LOCATION = useLocation();
//   const { state } = LOCATION;
//   const [lcIntervals, setLcIntevals] = useState({});
//   const [showAttributes, setShowAttributes] = useState(false);
//   const [showPreviewModal, setShowPreviewModal] = useState(false);
//   const [showSaveTemplateModal, setShowSaveTemplateModal] = useState(false)
//   const [selectedAttributes, setSelectedAttributes] = useState([]);
//   const [uploadedAttributesFiles, setUploadedAttributesFiles] = useState([])
//   const { logTemplateAttributes, logGeneralDetailsCreationDetails, useTemplateInformation } = useSelector(
//     (store) => store.logsAndReportsData
//   );
//   const [lcValues, setLcValues] = useState({
//     checklistCreationLoading: false,
//     isSaveAsTemplate: useTemplateInformation?.useTemplate,
//     savedTemplateServerResponse: [],
//     totalTemplates: null,
//     getTemplateDataSetsLoading: false,
//     manipulatedDataForPreviewChecklistAttributes: [],
//     saveAsTemplateLoading: false,
//     searchTemplate: ""
//   });
//   const { savedTemplateServerResponse, totalTemplates, getTemplateDataSetsLoading, manipulatedDataForPreviewChecklistAttributes } = lcValues;
//   const [IsImportTemplateFromLibraryModal, setIsImportTemplateFromLibraryModal] = useState(false);
//   const [pagination, setPagination] = useState(commonPageState);
//   const [isLoading, setIsLoading] = useToggler();
//   const [refreshApi, setRefreshApi] = useToggler();
//   const [isImportedTemplatePreviewModal, setIsImportedTemplatePreviewModal] = useState(false);
//   const [inputValue, setInputValue] = useState('');
//   const delay = 500; // Set your desired debounce delay
//   const debouncedValue = useDebounce(inputValue, delay);
//   const [cancelChecklistTemplateCreationAlert, setCancelChecklistTemplateCreationAlert] = useState(false);


//   // Handler Area
//   const getSelectedAttributeValue = (value) => {
//     let tempAttribute = {
//       id: uuidv4(),
//       attributeName: value,
//       fieldName: "",
//       fieldValue: "",
//       images: [],
//       notes: "",
//     };
//     if (value === "Multiple Choice" || value === "Dropdown" || value === "Checkboxes") {
//       tempAttribute.choosedValue = [];
//       tempAttribute.fieldValue = [
//         { optionId: uuidv4(), optionValue: "" },
//         { optionId: uuidv4(), optionValue: "" }
//       ]
//     }
//     if (useTemplateInformation?.useTemplate) {
//       dispatch(LogsAndReportsAction?.setUseTemplateInformation({ useTemplate: false, templateId: useTemplateInformation?.templateId }))
//       setLcValues(prev => {
//         return { ...prev, ["isSaveAsTemplate"]: false, manipulatedDataForPreviewChecklistAttributes: [] };
//       });
//     } else {
//       setLcValues(prev => {
//         return { ...prev, ["isSaveAsTemplate"]: false, manipulatedDataForPreviewChecklistAttributes: [] };
//       });
//     };
//     dispatch(
//       LogsAndReportsAction.setSelectedAttributesToolkitState([
//         ...logTemplateAttributes,
//         tempAttribute,
//       ])
//     );
//   };

//   const getUploadedAttributesFiles = (value) => {
//     setUploadedAttributesFiles(value)
//   }


//   const handleImportTemplateFromLibrary = () => {
//     setIsImportTemplateFromLibraryModal(false)
//   }


//   const handleGetTemplateDataSets = (id) => {
//     setLcValues(prev => {
//       return { ...prev, ["getTemplateDataSetsLoading"]: true }
//     })
//     doGetApiCall(`logs/templates/${id}/dataSets`, { fieldValue: 1 })
//       .then(res => {
//         let data = globalManipulateTemplatePreviewData({ data: res?.data?.result?.data })
//         dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(data))
//         setLcValues(prev => {
//           return { ...prev, ["manipulatedDataForPreviewChecklistAttributes"]: data }
//         })
//       }).finally(() => {
//         setLcValues(prev => {
//           return { ...prev, ["getTemplateDataSetsLoading"]: false }
//         })
//       })
//   }






//   const handleChange = (event) => {
//     setInputValue(event.target.value);
//   };




//   const handleGetSaveAsTemplates = (isPagination) => {
//     setIsLoading(true);
//     doGetApiCall(AppUrl?.getLogSaveAsTemplates, isPagination ? { page: pagination?.page, limit: pagination?.limit } : { templateName: debouncedValue })
//       .then(res => {
//         setLcValues((prev) => {
//           const result = res?.data?.result;

//           if (!result?.data || !Array.isArray(result.data)) {
//             console.error('Invalid or missing data in the API response.');
//             return prev;
//           }

//           if (isPagination) {
//             let hasMap = {};
//             result.data.forEach(item => (hasMap[item?.id] = 1));

//             const filteredData = (savedTemplateServerResponse || []).filter(item => !hasMap[item.id]);

//             return {
//               ...prev,
//               savedTemplateServerResponse: [...(filteredData || []), ...result.data],
//               totalTemplates: result?.totalDataCount
//             };
//           } else {
//             return {
//               ...prev,
//               savedTemplateServerResponse: result.data,
//               totalTemplates: result?.totalDataCount
//             };
//           }
//         });
//       }).finally(() => {
//         setIsLoading(false);
//       })
//   }


//   const handleGetErrorActivatorInformation = (props) => {
//     primaryObject = { ...primaryObject, [props.uniqueKey]: props }
//   }


//   const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
//     if (response === null || response === "") {
//       primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], ["value"]: false } }
//     }
//     else {
//       primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], ["value"]: true } }
//     }
//   }

//   const handleDeleteKeyFromPrimaryObject = (key) => {
//     if (primaryObject[key]) {
//       delete primaryObject[key]
//     }
//   }

//   const handleIsAnyFieldUpdate = () => {
//     setLcValues(prev => {
//       if (manipulatedDataForPreviewChecklistAttributes?.length > 0) {
//         return { ...prev, ["isSaveAsTemplate"]: false, manipulatedDataForPreviewChecklistAttributes: [] };
//       } else {
//         return { ...prev, ["isSaveAsTemplate"]: false }
//       }
//     });
//   }

//   useEffect(() => {
//     if (manipulatedDataForPreviewChecklistAttributes?.length > 0) {
//       for (let key in primaryObject) {
//         primaryObject[key].value = true
//       };
//     };
//   }, [manipulatedDataForPreviewChecklistAttributes?.length]);


//   useEffect(() => {
//     handleGetSaveAsTemplates(true)
//   }, [pagination, refreshApi]);

//   // Access the debouncedValue for your logic
//   useEffect(() => {
//     if (debouncedValue?.length > 0) {
//       handleGetSaveAsTemplates(false)
//     } else {
//       setPagination(prev => {
//         return { ...prev, page: 1 }
//       })
//       setRefreshApi()
//     }
//   }, [debouncedValue]);

//   useEffect(() => {
//     if (useTemplateInformation?.useTemplate) {
//       handleGetTemplateDataSets(useTemplateInformation?.templateId)
//     }
//     return () => {
//       dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState([]))
//       primaryObject = {}
//     }

//   }, [])

//   useEffect(() => {
//     globalOnScrollEnd(() => {
//       const lcPage = Math.ceil(totalTemplates / pagination?.limit)
//       setPagination(prev => {
//         if (lcPage !== prev?.page) {
//           return { ...prev, page: prev?.page + 1 }
//         }
//         return prev
//       })

//     }, "temp1");

//   }, [IsImportTemplateFromLibraryModal, refreshApi,])


//   if (logGeneralDetailsCreationDetails?.id && hasPermission("/template-creation")) return (
//     <>
//       <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
//         <section
//           aria-level={"Parent section of the input body section."}
//           className={Styles.template_content_container}
//         >
//           <div className={Styles.checklist_template_nav}>
//             <div className={Styles.nav_sub_container}>
//               <div>
//                 <ClonosButton style={{ color: "#0A5FFF", border: "0.5px solid #0A5FFF" }}
//                   onClick={() => setIsImportTemplateFromLibraryModal(true)}
//                 >Import From Library</ClonosButton>
//                 {logTemplateAttributes?.length > 0 && <div onClick={() => setShowPreviewModal(true)} className={Styles.preview_btn_box}>
//                   <img src={PREVIEWICON} />
//                   <p>Preview</p>
//                 </div>}
//               </div>
//               <div>
//                 <div>
//                   {
//                     lcValues?.isSaveAsTemplate ? <div className={Styles.saved_template_container}> <SingleCheck /> <span>Saved as Template</span></div> :
//                       <ClonosButton loading={lcValues?.saveAsTemplateLoading} onClick={() => setShowSaveTemplateModal(true)} style={{ color: "#06337E" }} >
//                         Save as Template
//                       </ClonosButton>
//                   }
//                 </div>
//                 <div
//                   onClick={() => setShowAttributes(!showAttributes)}
//                   className={Styles.add_task_btn_box}
//                 >
//                   <img src={PLUSICON} />
//                   <p>Add Task</p>
//                   <span>
//                     <img src={EXPANDDOWN} />
//                   </span>
//                   {showAttributes && (
//                     <TemplateAttributes
//                       getSelectedValue={(val) => {
//                         getSelectedAttributeValue(val);
//                         setShowAttributes(!showAttributes);
//                       }}
//                     />
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//           <ChecklistTemplateTable
//             attributes={logTemplateAttributes}
//             uploadedAttributesFiles={uploadedAttributesFiles}
//             getUploadedAttributesFiles={(value) => getUploadedAttributesFiles(value)}
//             handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//             handlePrimaryObjectModifier={handlePrimaryObjectModifier}
//             handleDeleteKeyFromPrimaryObject={handleDeleteKeyFromPrimaryObject}
//             handleIsAnyFieldUpdate={handleIsAnyFieldUpdate}
//           />
//           <div className={Styles.btn_controller}>
//             <div className={Styles.btns_container}>
//               <ClonosButton variant="outlined" onClick={() => {
//                 setCancelChecklistTemplateCreationAlert(true)
//               }}>Cancel</ClonosButton>
//               <ClonosButton
//                 variant="filled"
//                 loading={lcValues?.checklistCreationLoading}
//                 onClick={() => {

//                   if (!globalHandleIsAllRequiredFieldAvailable({ primaryObject })) return
//                   handleSaveLogDataSetsMethod(
//                     {
//                       logId: logGeneralDetailsCreationDetails?.id,
//                       payload: logTemplateAttributes,
//                       dispatch,
//                       Navigate,
//                       savingType: 'create',
//                       files: uploadedAttributesFiles,
//                       responseSetterMethod: setLcValues
//                     }
//                   )
//                 }}
//               >Create Log</ClonosButton>

//             </div>
//           </div>
//         </section>
//       </Card>
//       <SaveLogAsTemplate primaryObject={primaryObject} open={showSaveTemplateModal} closeMethod={setShowSaveTemplateModal} checklistGeneralDetailsCreationDetails={logGeneralDetailsCreationDetails} responseSetterMethod={setLcValues} loading={lcValues?.saveAsTemplateLoading} refreshApi={setRefreshApi} />
//       <Modal isOpen={showPreviewModal} closeModalMethod={setShowPreviewModal}>
//         <div className={Styles.preview_modal_sub_container}>
//           <div className={Styles.preview_modal_header}>
//             <h4>{state?.generalDetails?.name}</h4>
//             <div><CloseIcon onClick={() => setShowPreviewModal(false)} /></div>
//           </div>
//           <div aria-label="General Details" className={Styles.general_details_container}>
//             <p>{state?.generalDetails?.description}</p>
//           </div>
//           <div className={Styles.preview_modal_content_container}>
//             <ChecklistTemplatePreview attributes={logTemplateAttributes} uploadedAttributesFiles={uploadedAttributesFiles} getUploadedAttributesFiles={getUploadedAttributesFiles} getUpdatedValues={(val) => { }} />
//           </div>
//           {/* <div className={Styles.preview_modal_btn_controller}>
              
//             </div> */}
//         </div>
//       </Modal>
//       <Modal isOpen={IsImportTemplateFromLibraryModal} closeModalMethod={setIsImportTemplateFromLibraryModal} stopOverlayCloser={true}>
//         <div className={Styles.import_from_library}>
//           <header>
//             <span>Import from template library</span>
//             <CloseIcon onClick={() => setIsImportTemplateFromLibraryModal(false)} tooltipTitle={"Close"} />
//           </header>
//           <section className={Styles.import_from_library_body}>
//             <div className={Styles.import_from_library_search}>
//               <Search onClick={() => setIsImportTemplateFromLibraryModal(false)} />
//               <input placeholder="Search" onChange={e => handleChange(e)} />
//             </div>
//             <div id="temp1" className={Styles.import_from_library_items_container}>
//               {
//                 savedTemplateServerResponse?.map((item) => {
//                   return <div key={item.id} className={Styles.import_from_library_body_item}>
//                     <div
//                       className={Styles.import_from_library_field}
//                       onClick={() => {
//                         handleGetTemplateDataSets(item.id)
//                         primaryObject = {};
//                         setLcValues(prev => {
//                           return { ...prev, ["isSaveAsTemplate"]: false, ["activeTemplateDetails"]: { name: item?.templateName } };
//                         });
//                         setIsImportTemplateFromLibraryModal(false)
//                       }}>
//                       <span>{item?.templateName}</span>
//                       <span>{getFormatedDate(item.createdDate)}</span>
//                     </div>
//                     <span onClick={() => {
//                       setIsImportedTemplatePreviewModal(true);
//                       setLcValues(prev => {
//                         return { ...prev, ["activeTemplateDetails"]: { name: item?.templateName } };
//                       });
//                       handleGetTemplateDataSets(item.id);
//                     }}>Preview</span>
//                   </div>
//                 })
//               }
//               <div style={{ display: 'flex', justifyContent: 'center', width: "100%" }}>
//                 {isLoading && <ClonosSpinner />}
//               </div>
//             </div>
//           </section>
//           <footer>
//             <span onClick={() => setIsImportTemplateFromLibraryModal(false)}>Cancel</span>
//             <span onClick={handleImportTemplateFromLibrary}>Ok</span>
//           </footer>
//         </div>
//       </Modal>
//       <Modal isOpen={isImportedTemplatePreviewModal} closeModalMethod={setIsImportedTemplatePreviewModal} >
//         <div className={Styles.imported_template_Preview_container}>
//           <header>
//             <div>
//               <BackIcon tooltipTitle="Back" onClick={() => setIsImportedTemplatePreviewModal(false)} />
//               <span>{lcValues?.activeTemplateDetails?.name}</span>
//             </div>
//             <CloseIcon tooltipTitle="Close" onClick={() => setIsImportedTemplatePreviewModal(false)} />
//           </header>
//           {
//             getTemplateDataSetsLoading ? <ClonosSpinner /> :
//               <ChecklistTemplatePreview
//                 attributes={manipulatedDataForPreviewChecklistAttributes}
//                 isEdit={false}
//               />
//           }
//         </div>
//       </Modal>
//       <ClonosConfirmationBox
//         isOpen={cancelChecklistTemplateCreationAlert}
//         confirmingMethod={() => {
//           Navigate("/logs")
//         }}
//         closeModalMethod={setCancelChecklistTemplateCreationAlert}
//         headerTitle="Template Creation"
//         message="Are you sure, You don't want to create log template?"
//       />
//     </>
//   );
//   return <UnAuthorizedModal />
// };

// export default memo(ChecklistTemplateCreatePage);
