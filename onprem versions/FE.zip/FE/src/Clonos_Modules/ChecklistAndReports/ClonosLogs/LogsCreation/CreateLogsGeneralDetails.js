import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosLogs/LogsCreationPage.module.css"
import SEARCHICON from "../../../../assets/UIUX/icons/search.svg";
import { useEffect } from "react";
import {
    handleGetAssetDropdown,
    handleGetUsersDropdownData,
} from "../../../../utils/WorkOrderMethods/WorkOrderMethods";
import { useState } from "react";
import { useDispatch } from "react-redux";
import {

    handleEditLogGeneralDetails,
    handleGetSingleChecklist,
    handleGetSingleLogs,
    handleSaveChecklistGeneralDetails,
    handleSaveLogGeneralDetails,
} from "../../../../utils/ChecklistAndReportsMethods/LogsMethod";
import { useLocation, useNavigate } from "react-router-dom";
import { handleGetStaticDropdownValues } from "../../../../utils/DropdownsMethods/DropdownsMethods";
import DynamicDropdown from "../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import { getDayMonthYear } from "../../../../utils/clonosCommon";
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosRadioAndCheckbox from "../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox";
import ClonosTextarea from "../../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import FrequencySelector from "../../../../components/FrequencySelector/FrequencySelector";
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import ClonosSpecifyFromAndTo from "../../Components/ClonosSpecifyFromAndTo/ClonosSpecifyFromAndTo";


let primaryObject = {}
export const CreateLogsGeneralDetails = ({ mode }) => {
    const dispatch = useDispatch();
    const Navigate = useNavigate();
    const [formData, setFormData] = useState({ isRecurring: false });
    const [changedData, setChangedData] = useState({})
    const [errors, setErrors] = useState({});
    const [assetDropdownData, setAssetDropdownData] = useState([]);
    const [teamDropdownData, setTeamDropdownData] = useState([]);
    const [typeDropdownData, setTypeDropdownData] = useState([]);
    const [frequencyDropdownData, setFrequencyDropdownData] = useState([]);
    const [usersDropdownData, setUsersDropdownData] = useState([]);
    const [showUsersLibrary, setShowUsersLibrary] = useState(false);
    const [showTeamsLibrary, setShowTeamsLibrary] = useState(false);
    const [assetPaginationCurrentPage, setAssetPaginationCurrentPage] = useState(1);
    const [showAssetLibrary, setShowAssetLibrary] = useState(false);
    const LOCATION = useLocation();
    const { state } = LOCATION;


    // New States 
    const [lcValues, setLcValues] = useState(
        {
            "editLoading": false,
            "checklistGeneralDetailsLoading": false,
            "savingLogsGeneralDetailsAsDraftLoading": false
        }
    );
    const [lcIntervals, setLcIntervals] = useState({}); // This state will handle all the intervals Ids of all APIs
    const { singleChecklistServerResponse, } = lcValues; // This state will handle all kind of local value , server response, flag states.
    const noneRenderableState = {}; // If we just want to store the data and don't want to render the component, at the time we will save the those values in this state.
    const [cancelOrGoBackAlert, setCancelOrGoBackAlert] = useState(false);




    const handleMoreData = ({ isActivator }) => {
        if (isActivator) {
            setAssetPaginationCurrentPage((prev) => {
                let updatedPageCount = prev + 1;
                handleGetAssetDropdown({
                    setAssetDropdownData,
                    assetDropdownData,
                    assetPaginationCurrentPage: updatedPageCount,
                    dispatch,
                });
                return updatedPageCount;
            });
        }
    };

    const handleGetValues = (props) => {
        const { name, selectedOption, updatedValue, uniqueKey, type } = props;

        if (type === "dynamicDropdown") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? selectedOption[0]?.id : null }
            })
        }
        else if (type === "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? updatedValue?.label : null }
            })
        }

        else if (type === "text" || type === "date" || type === "time" || type === "datetime-local") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
            })
        }

        // else if (mode === "edit") {
        //     setChangedData((prev) => ({
        //         ...prev,
        //         [name]: { name: selectedOption[0]?.name, id: selectedOption[0]?.id },
        //     }))
        // }
        else {
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: updatedValue }
            });
        }

    };

    const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
        if (response === null || response === "") {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": false } }
            return false
        }
        else {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": true } }
            return true
        }
    }

    const lcHandleFrequency = (props) => {
        setFormData((prev) => {
            return { ...prev, ...props?.updatedValue }
        });
    }

    const handleGetErrorActivatorInformation = (props) => {
        primaryObject = { ...primaryObject, [props.uniqueKey]: props }
    }

    const handleGoToEditTemplate = () => {
        // Navigate("")
    }

    useEffect(() => {
        if (mode === "edit") {
            handleGetSingleLogs({ dispatch, logId: state?.id, responseSetterMethod: setLcValues, uniqueKey: "singleChecklistServerResponse" })
        }

        handleGetAssetDropdown({
            setAssetDropdownData,
            assetDropdownData,
            assetPaginationCurrentPage,
            dispatch,
        });
        handleGetStaticDropdownValues({
            staticDropdownNameOrId: "Team",
            dispatch,
            setterFunctionForValues: setTeamDropdownData,
        });
        handleGetUsersDropdownData({
            setUsersDropdownData,
            usersDropdownData,
            dispatch,
        });
        handleGetStaticDropdownValues({
            staticDropdownNameOrId: "Frequency",
            dispatch,
            setterFunctionForValues: setFrequencyDropdownData,
        });
        handleGetStaticDropdownValues({
            staticDropdownNameOrId: "AssetDepartment",
            dispatch,
            setterFunctionForValues: setTypeDropdownData,
        });

        return () => {
            primaryObject = {};
            clearInterval(lcIntervals?.navigateInterval)
        }
    }, [mode])

    useEffect(() => {
        if (mode === "edit") {
            if (lcValues?.singleChecklistServerResponse) {
                setLcValues(prev => {// Here we are segregating the ISO 8601 date and time format into year, month, day, time, hour, minute, second
                    const lcStartDate = getDayMonthYear(singleChecklistServerResponse?.startDate)
                    const lcEndDate = getDayMonthYear(singleChecklistServerResponse?.endDate)
                    return { ...prev, ["formatedStartDateServerResponse"]: lcStartDate, ['formatedEndDateServerResponse']: lcEndDate }
                })
            }
        }
    }, [lcValues?.singleChecklistServerResponse])




    return (
        <>
            <div area-aria-label="Parent container for general details">
                <header className={Styles.checklist_gen_details_header}>
                    General Details
                </header>
                <div
                    aria-label="Container to get fields values."
                    className={Styles.fieldsContainer}
                >
                    <div
                        area-aria-label="field container to get Name"
                        className={Styles.fieldItemBox}
                    >
                        <div
                            area-aria-label="input to get value for Name"
                            className={Styles.checklist_general_details_fieldValueTaker}
                        >
                            <ClonosInput
                                label="Name"
                                isLabel={true}
                                placeholder="Name"
                                isMandatory={true}
                                type="text"
                                limit='100'
                                uniqueKey="name"
                                defaultValue={state?.mode === "edit" && singleChecklistServerResponse?.name}
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            />
                        </div>
                    </div>

                    <div style={{ display: "flex", justifyContent: "left", gap: "1rem", alignItems: "center", width: "100%" }}>
                        <ClonosRadioAndCheckbox
                            isLabel={true}
                            label="Require Manager Approval"
                            uniqueKey="isManagerApprovalRequired"
                            handleGetValues={handleGetValues}
                        />
                        <ClonosRadioAndCheckbox
                            isLabel={true}
                            label="Schedule Report"
                            uniqueKey="isReportScheduled"
                            handleGetValues={handleGetValues}
                        />
                    </div>

                    <div
                        area-aria-label="field container to get Description"
                        className={Styles.fieldItemBox}
                    >
                        <div
                            area-aria-label="textarea to get value for Description"
                            className={Styles.checklist_general_details_fieldValueTaker}
                        >
                            <ClonosTextarea
                                label="Description"
                                isLabel={true}
                                placeholder="Description"
                                isMandatory={false}
                                type="text"
                                uniqueKey="description"
                                defaultValue={state?.mode === "edit" && singleChecklistServerResponse?.description}
                                handleGetValues={handleGetValues}
                            />
                        </div>
                    </div>
                    <div
                        area-aria-label="field container to get Document Number"
                        className={Styles.fieldItemBox}
                    >
                        <div
                            area-aria-label="textarea to get value for Document Number"
                            className={Styles.checklist_general_details_fieldValueTaker}
                        >
                            <ClonosInput
                                label="Document Number"
                                isLabel={true}
                                placeholder="Document Number"
                                isMandatory={false}
                                type="text"
                                uniqueKey="documentNumber"
                                defaultValue={state?.mode === "edit" && singleChecklistServerResponse?.documentNumber}
                                handleGetValues={handleGetValues}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            />
                        </div>
                    </div>
                    <div
                        onClick={() => setShowAssetLibrary(true)}
                        area-aria-label="field container to get Document Number"
                        className={Styles.fieldItemBox}
                    >
                        <DynamicDropdown
                            title={"Asset"}
                            labelActivator={"Asset Name"}
                            isOpen={showAssetLibrary}
                            uniqueKey={"assetId"}
                            heading={"Select from Asset Library"}
                            placeholder={"Search"}
                            isSearchable={true}
                            isCheckbox={false}
                            isUser={true}
                            isDynamicLoad={true}
                            data={assetDropdownData}
                            isActivator={true}
                            isMandatory={true}
                            url={SEARCHICON}
                            defaultValue={state?.mode === "edit" && [{ "name": singleChecklistServerResponse?.asset?.assetName }]}
                            handleMoreData={handleMoreData}
                            handleGetValues={handleGetValues}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                    </div>
                    <div
                        area-aria-label="field container to get Type"
                        className={Styles.fieldItemBox}
                    >

                        <ClonosSelect
                            type="select"
                            label="Type"
                            isMandatory={true}
                            isLabel={true}
                            uniqueKey="type"
                            placeholder="Select"
                            options={typeDropdownData?.map((type) => ({
                                label: type?.name,
                                value: type?.id,
                                isNeeded: true
                            }))}
                            defaultValue={state?.mode === "edit" && singleChecklistServerResponse?.type}
                            handleGetValues={handleGetValues}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                    </div>
                    <div
                        area-aria-label="field container to get Team"
                        className={Styles.fieldItemBox}
                        onClick={() => setShowTeamsLibrary(true)}
                    >
                        <DynamicDropdown
                            handleGetErrorMethods={() => { }}
                            title={"Team"}
                            uniqueKey={"team"}
                            labelActivator={"Team Name"}
                            heading={"Select from Team Library"}
                            placeholder={"Search"}
                            isSearchable={true}
                            isCheckbox={false}
                            isDynamicLoad={false}
                            data={teamDropdownData}
                            isActivator={true}
                            isMandatory={true}
                            url={SEARCHICON}
                            defaultValue={state?.mode === "edit" && [{ "name": singleChecklistServerResponse?.team?.dropdownValues }]}
                            handleMoreData={handleMoreData}
                            handleGetValues={handleGetValues}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                    </div>
                    <div
                        area-aria-label="field container to get Assignee"
                        className={Styles.fieldItemBox}
                        onClick={() => setShowUsersLibrary(true)}
                    >
                        <DynamicDropdown
                            handleGetErrorMethods={() => { }}
                            title={"Assignee"}
                            uniqueKey={"assignee"}
                            labelActivator={"User Name"}
                            isOpen={showUsersLibrary}
                            isOpenMethod={setShowUsersLibrary}
                            heading={"Select from Users Library"}
                            placeholder={"Search"}
                            isSearchable={true}
                            isCheckbox={false}
                            isUser={true}
                            isDynamicLoad={false}
                            data={usersDropdownData}
                            isActivator={true}
                            isMandatory={true}
                            url={SEARCHICON}
                            defaultValue={state?.mode === "edit" && [{ "name": singleChecklistServerResponse?.assignee?.name }]}
                            handleMoreData={handleMoreData}
                            handleGetValues={handleGetValues}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}

                        />
                    </div>
                    <div>
                        <div className={Styles.checklist_gen_details_horizontalFlexBox}>
                            <div
                                area-aria-label="field container to get start and end date"
                                className={Styles.fieldItemBox}
                            >
                                <div
                                    area-aria-label="to get value for end date"
                                    className={Styles.checklist_general_details_fieldValueTaker}
                                >
                                    <ClonosInput
                                        label="Start Date"
                                        isLabel={true}
                                        isMinimum={true}
                                        placeholder="Start Date"
                                        isMandatory={true}
                                        type="datetime-local"
                                        min={true}
                                        uniqueKey="startDate"
                                        defaultValue={state?.mode === "edit" && `${lcValues?.formatedStartDateServerResponse?.year}-${lcValues?.formatedStartDateServerResponse?.month}-${lcValues?.formatedStartDateServerResponse?.day}T${lcValues?.formatedStartDateServerResponse?.hours}:${lcValues?.formatedStartDateServerResponse?.minutes}`}
                                        handleGetValues={handleGetValues}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                </div>
                                {errors.startDate && (
                                    <span className={Styles.error}>{errors.startDate}</span>
                                )}
                            </div>
                            <div
                                area-aria-label="field container to get end date"
                                className={Styles.fieldItemBox}
                            >
                                <div
                                    area-aria-label="to get value for end date"
                                    className={Styles.checklist_general_details_fieldValueTaker}
                                >
                                    <ClonosInput
                                        label="End Date"
                                        isLabel={true}
                                        placeholder="End Date"
                                        isMandatory={true}
                                        isMinimum={true}
                                        type="datetime-local"
                                        uniqueKey="endDate"
                                        defaultValue={state?.mode === "edit" && `${lcValues?.formatedEndDateServerResponse?.year}-${lcValues?.formatedEndDateServerResponse?.month}-${lcValues?.formatedEndDateServerResponse?.day}T${lcValues?.formatedEndDateServerResponse?.hours}:${lcValues?.formatedEndDateServerResponse?.minutes}`}
                                        disabled={formData?.startDate?.length > 0 ? false : true}
                                        min={formData?.startDate}
                                        handleGetValues={handleGetValues}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        area-aria-label="field container to get Assignee"
                        className={Styles.fieldItemBox}
                    >
                        <div
                            area-aria-label="label for Field"
                            className={Styles.checklist_general_details_label}
                        >
                            Is Recurring
                        </div>
                        <div
                            area-aria-label="textarea to get value for Document Number"
                            className={Styles.checklist_general_details_fieldValueTaker}
                        >
                            <FrequencySelector
                                selectTagProps={{
                                    isLabel: true,
                                    label: "Frequency",
                                    position: "top",
                                    uniqueKey: "frequencyType",
                                    options: frequencyDropdownData?.map((item) => {
                                        return { "label": item?.name, "value": item?.id, "isNeeded": true }
                                    }),
                                    defaultValue: singleChecklistServerResponse?.frequencyType?.dropdownValues
                                }}
                                inputTagProps={{
                                    isLabel: true,
                                    label: "Every",
                                    type: "number",
                                    placeholder: "0",
                                    maxLength: "2",
                                    uniqueKey: "frequencyPeriod",
                                    defaultValue: singleChecklistServerResponse?.frequencyPeriod
                                }}
                                handleGetValues={lcHandleFrequency}
                                defaultValue={
                                    {
                                        isRecurring: singleChecklistServerResponse?.isRecurring,
                                        isCustomFrequency: singleChecklistServerResponse?.frequencyPeriod ? true : false

                                    }}
                            />
                        </div>
                        <ClonosSpecifyFromAndTo heading="From" />
                    </div>
                </div>
                <footer className={Styles.checklist_gen_details_footer}>
                    <div>

                        {
                            mode !== "edit" && <>
                                <ClonosButton
                                    onClick={() => {
                                        handleSaveLogGeneralDetails({ payload: formData, dispatch, Navigate, savingType: "draft", responseSetterMethod: setLcValues });
                                    }}
                                    loading={lcValues?.savingLogsGeneralDetailsAsDraftLoading}
                                    style={{
                                        color: "#06337E",
                                        border: "1px solid #06337E",
                                        fontSize: "16px",
                                        padding: "0.5rem 1rem",
                                    }}
                                >Save as Draft
                                </ClonosButton>
                                <ClonosButton
                                    loading={lcValues?.checklistGeneralDetailsLoading}
                                    variant="filled"
                                    onClick={() => {
                                        let flag = false;
                                        let count = 0;
                                        for (let key in primaryObject) {
                                            if (primaryObject[key].value === false) {
                                                primaryObject[key]?.errorActivatorMethod(true)
                                                count++
                                            }
                                        }
                                        if (count === 0) flag = true
                                        flag && handleSaveLogGeneralDetails({ payload: formData, dispatch, Navigate, savingType: "submitted", responseSetterMethod: setLcValues });
                                    }}
                                    style={{ fontSize: "16px", padding: "0.5rem 1rem" }}
                                >
                                    Continue
                                </ClonosButton>
                            </>
                        }
                        {
                            mode === "edit" && <>
                                <ClonosButton isHollow={true}
                                    onClick={() => {
                                        setCancelOrGoBackAlert(true)
                                    }}
                                >{lcValues?.isChecklistEdited ? "Go Back" : "Cancel"}
                                </ClonosButton>
                                {
                                    false && <ClonosButton onClick={handleGoToEditTemplate}>Continue For Edit Template</ClonosButton>
                                }
                                {!lcValues?.isChecklistEdited && <ClonosButton
                                    variant="filled"
                                    onClick={() => {
                                        handleEditLogGeneralDetails({ dispatch, payload: formData, logId: singleChecklistServerResponse?.id, responseSetterMethod: setLcValues })
                                    }}
                                    loading={lcValues?.editLoading}
                                    style={{ fontSize: "16px", padding: "0.5rem 1rem" }}
                                >Update
                                </ClonosButton>}

                                <ClonosConfirmationBox
                                    isOpen={cancelOrGoBackAlert}
                                    confirmingMethod={() => {
                                        Navigate(`/view-log/${singleChecklistServerResponse?.name}`, { state: { id: singleChecklistServerResponse?.id } })
                                        setCancelOrGoBackAlert(false)
                                    }}
                                    closeModalMethod={setCancelOrGoBackAlert}
                                    headerTitle="Edit Log"
                                    message="Are you sure, You don't want to edit this log general details?"
                                />
                            </>
                        }
                    </div>
                </footer >
            </div >
        </>
    );
};
