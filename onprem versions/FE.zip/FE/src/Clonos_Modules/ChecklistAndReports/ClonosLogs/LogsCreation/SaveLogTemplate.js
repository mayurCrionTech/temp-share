import { useNavigate } from "react-router";
import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosLogs/SaveLogAsTemplate.module.css"
import { handleSaveLogDataSetsMethod } from "../../../../utils/ChecklistAndReportsMethods/LogsMethod"
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { useState } from "react";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import { globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../../utils/clonosCommon";


export const SaveLogAsTemplate = ({ open, closeMethod, responseSetterMethod, loading, refreshApi, primaryObject }) => {
    const { logTemplateAttributes, logGeneralDetailsCreationDetails, useTemplateInformation } = useSelector(
        (store) => store.logsAndReportsData
    );
    const Navigate = useNavigate();
    const dispatch = useDispatch();
    const [lcValues, setLcValues] = useState({ "templateName": logGeneralDetailsCreationDetails?.name, isDuplicateTemplate: false, templateNameErrorHandling: {} });


    const handleSaveChecklistAsTemplate = () => {
        if (lcValues?.templateNameErrorHandling?.value === false) {
            lcValues?.templateNameErrorHandling?.errorActivatorMethod(true);
            return;
        };
        if (!globalHandleIsAllRequiredFieldAvailable({ primaryObject })) {
            handleShowErrorAndWarning({ dispatch, type: "error", message: "Please fill all the fields of attributes" });
            closeMethod(false);
            return;
        };
        handleSaveLogDataSetsMethod({ logId: logGeneralDetailsCreationDetails?.id, payload: logTemplateAttributes, dispatch, Navigate, savingType: 'template', responseSetterMethod, templateName: lcValues?.templateName, refreshApi, isDuplicateTemplateSetterMethod: { setLcValues, closeMethod } })
    }

    return (
        <Modal isOpen={open} closeModalMethod={closeMethod}>
            <div className={Styles.sct_subcontainer}>
                <div className={Styles.sct_header}>
                    <h4>Save As Template</h4>
                    <div><CloseIcon onClick={() => closeMethod(false)} /></div>
                </div>
                <div className={Styles.sct_content_container}>
                    <div className={Styles.sct_field_container}>
                        {/* 
                        <label>Template Name<span className={Styles.required}>*</span></label>
                        <input
                            onChange={(e) => setLcValues({ ...lcValues, ["templateName"]: e.target.value })}
                            defaultValue={logGeneralDetailsCreationDetails?.name}
                        /> */}

                        <ClonosInput
                            label="Template Name"
                            isLabel={true}
                            uniqueKey="templateName"
                            handleGetValues={(props) => {
                                setLcValues(prev => {
                                    let data = null
                                    if (props?.updatedValue === "" || props?.updatedValue === null) {
                                        data = { ...prev, [props?.uniqueKey]: props?.updatedValue, ["templateNameErrorHandling"]: { ...prev["templateNameErrorHandling"], ["value"]: false } }
                                    } else {
                                        data = { ...prev, [props?.uniqueKey]: props?.updatedValue, ["templateNameErrorHandling"]: { ...prev["templateNameErrorHandling"], ["value"]: true } }
                                    };
                                    return data;
                                })
                            }}
                            defaultValue={logGeneralDetailsCreationDetails?.name}
                            isMandatory={true}
                            handleGetErrorActivatorInformation={(props) => setLcValues(prev => {
                                return { ...prev, ["templateNameErrorHandling"]: props }
                            })}
                        />
                    </div>
                </div>
                <div className={Styles.cst_btn_controller}>
                    <div>
                        <ClonosButton isHollow={true} style={{ color: "#06337E" }} onClick={() => closeMethod(false)}>Cancel</ClonosButton>
                        <ClonosButton
                            isDisabled={!lcValues?.templateName?.length > 0}
                            loading={loading}
                            variant="filled" onClick={() => {
                                handleSaveChecklistAsTemplate();
                            }} >Save</ClonosButton>
                    </div>
                </div>
            </div>
        </Modal>
    )
}

