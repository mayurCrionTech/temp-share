import React from 'react'
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { handleUpdateLayoutDelaySetter, updateLayout } from '../../../../utils/clonosCommon';
import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosLogs/LogsCreationPage.module.css"
import { useLocation } from 'react-router-dom';
import { Card } from '@mui/material';
import { CreateLogsGeneralDetails } from './CreateLogsGeneralDetails';


const LogsCreatePage = () => {
    // Global States 
    const LOCATION = useLocation();
    const { state } = LOCATION;


    // Local States
    const [lcIntervals, setLcIntevals] = useState({});
    const dispatch = useDispatch()


    useEffect(() => {
        // Update the layout based on dispatch action.
        updateLayout({ dispatch });
        setLcIntevals({ ...lcIntervals, "updateLayoutInterval": handleUpdateLayoutDelaySetter({ dispatch }) })
    }, [])
    return (
        <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
            <section aria-level={"Parent section of the input body section."} className={Styles.checklist_content_container}>
                <div aria-label="All input fields for getting the data from the form.">
                    <CreateLogsGeneralDetails mode={state?.mode} />
                </div>
            </section>
        </Card>
    )
}

export default React.memo(LogsCreatePage)