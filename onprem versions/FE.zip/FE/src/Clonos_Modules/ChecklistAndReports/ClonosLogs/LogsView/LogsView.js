import React, { useState } from 'react'
import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/ChecklistView/ChecklistView.module.css"
import { useLocation, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { generateUniqueId, getDayMonthYear, getFormatedDate, getToken, handleGetENVVariables, handleLoggedInUser, handleRedirectAfterEvent } from '../../../../utils/clonosCommon';
import { useRef } from 'react';
import { Card, Tooltip } from '@mui/material';
import Modal from '../../../../components/CommonComponents/Modal/Modal';
import ClonosExportOptions from '../../../../components/CommonComponents/ClonosExportOptions/ClonosExportOptions';
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button';
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import COMMON_EYE_ICON from "../../../../assets/UIUX/icons/Common_Icon/COMMON_EYE_ICON.svg"
import { ChecklistTemplatePreview } from '../../../../components/ClonosChecklist/ChecklistTemplatePreview';
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import Subbar from '../../../../components/CommonComponents/ClonosSubbar/Subbar';
import useToggler from '../../../../CustomHooks/TogglerHook';
import { handleChangeLogsStatus, exportChecklistInformaiton, handleCreateValidateRequests, handleApproveTheValidateRequest, handleDeleteLogs, handleGetSingleLogs, handleGetSingleLogsDetaSets, handleGetValidateRequests, } from '../../../../utils/ChecklistAndReportsMethods/LogsMethod';
import { CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE, CLONOS_GLOBAL_USER_TYPE_ENGINEER, CLONOS_GLOBAL_USER_TYPE_MANAGER, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../../Constants/Constant';
import { ImagePreviewModal } from '../../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal';

const LogsView = () => {
    // Local States
    const LOCATION = useLocation();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const generalDetailsRef = useRef(null)
    const [lcIntervals, setLcIntervals] = useState({});
    const [isDownloadModal, setIsDownloadModal] = useState(false);
    const [isPreviewTemplateModal, setIsPreviewTemplateModal] = useState(false);
    const [needToExportFileDetails, setNeedToExportFileDetails] = useState({});
    const [allAreasThatNeedsToExportAsPDFState, setAllAreasThatNeedsToExportAsPDFState] = useState([]);
    const [deleteLogAlert, setDeleteLogAlert] = useState(false);
    const [lcValues, setLcValues] = useState({
        validateLoading: false,
        approveLoading: false,
        reviseLoading: false,
        validateRequestServerResponse: null
    });
    const [isValidateConfirmationModal, setIsValidateConfirmationModal] = useState(false);
    const [refreshApi, setRefreshApi] = useToggler();
    const [isImagePreviewModal, setIsImagePreviewModal] = useToggler();
    const { lcChecklistData, singleChecklistDataSetsDetails, validateRequestServerResponse, images } = lcValues;




    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.index || "-"
        },
        {
            field: "fieldName",
            headerName: "Field Name",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.fieldName || "-",
        },
        {
            field: "fieldValue",
            headerName: "Value",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.fieldValue ?
                (params?.row?.attributeName === "text" || params?.row?.attributeName === "number" || params?.row?.attributeName === "date") ? params?.row?.fieldValue[params?.row?.attributeName] ? params?.row?.attributeName === "date" ? getFormatedDate(params?.row?.fieldValue[params?.row?.attributeName]) : params?.row?.fieldValue[params?.row?.attributeName] : "Not Mentioned"
                    :
                    params?.row?.fieldValue[params?.row?.attributeName]?.filter((item) => item?.isSelected === true)?.length ? params?.row?.fieldValue[params?.row?.attributeName]?.filter((item) => item?.isSelected === true)?.map((item, index) => {
                        if (item?.isSelected) {
                            return item?.optionValue
                        }
                    }).join(" | ") : "Not Mentioned" :
                "-"
        }
    ]


    const handleGetDetails = (props) => {
        setNeedToExportFileDetails(props)
    }

    const handleExportFile = () => {
        exportChecklistInformaiton(
            {
                fileName: needToExportFileDetails?.fileName,
                type: needToExportFileDetails?.format,
                pdfData: allAreasThatNeedsToExportAsPDFState,
                pageType: needToExportFileDetails?.pageType,
                xlsxData: lcChecklistData
            })
        setIsDownloadModal(false)
    }

    const lcHandleGoToChecklistEdit = () => {
        navigate("/edit-log-generaldetails", { state: { "mode": "edit", "id": LOCATION?.state?.id } })
    }

    useEffect(() => {
        handleGetSingleLogs({ dispatch, responseSetterMethod: setLcValues, logId: LOCATION?.state?.id, uniqueKey: "lcChecklistData" }) // Getting the single checklist informaiton.
        handleGetValidateRequests({ responseSetterMethod: setLcValues, logId: LOCATION?.state?.id, dispatch, uniqueKey: "validateRequestServerResponse" })
    }, [refreshApi])

    useEffect(() => {
        handleGetSingleLogsDetaSets({ dispatch, responseSetterMethod: setLcValues, logsId: LOCATION?.state?.id }) // Getting the single checklist data sets informaiton.
        setAllAreasThatNeedsToExportAsPDFState([...allAreasThatNeedsToExportAsPDFState, generalDetailsRef.current]) // Here we are stoting all those element that we want to print in PDF exports.
        handleGetValidateRequests({ responseSetterMethod: setLcValues, logId: LOCATION?.state?.id, dispatch, uniqueKey: "validateRequestServerResponse" })
        return () => {
            clearInterval(lcIntervals?.deleteChecklist)
        }
    }, [])



    // useEffect(() => {
    //     if (validateRequestServerResponse?.length) {
    //         handleGetSingleLogs({ dispatch, responseSetterMethod: setLcValues, logId: LOCATION?.state?.id, uniqueKey: "lcChecklistData" }) // Getting the single checklist informaiton.
    //     }
    // }, [validateRequestServerResponse?.length])




    useEffect(() => {
        if (lcValues?.singleChecklistDataSetsDetails) {
            const attributeNames = {
                text: "Text",
                date: "Date",
                number: "Number",
                dropdown: "Dropdown",
                checkboxes: "Checkboxes",
                [CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE]: "Multiple Choice"
            };
            let images = [];
            const manipulatedDataForPreviewChecklistAttributes = singleChecklistDataSetsDetails?.map((element) => {
                element?.images?.length && element?.images.forEach(image => {
                    images.push(image)
                });
                if (element?.attributeName === "text" || element?.attributeName === "date" || element?.attributeName === "number") {
                    return {
                        "id": element?.id,
                        "attributeName": attributeNames[element?.attributeName],
                        "fieldName": element?.fieldName,
                        "fieldValue": element?.fieldValue[element?.attributeName],
                    }
                }
                else {
                    return {
                        "id": element?.id,
                        "attributeName": attributeNames[element?.attributeName],
                        "fieldName": element?.fieldName,
                        "fieldValue": element?.fieldValue[element?.attributeName]?.map((item) => {
                            return {
                                "optionId": item?.id,
                                "optionValue": item?.optionValue
                            }
                        })
                    }
                }
            });
            setLcValues(prev => {
                return { ...prev, manipulatedDataForPreviewChecklistAttributes }
            });
        }
    }, [singleChecklistDataSetsDetails])


    return (
        <>
            <Subbar
                isCopy={handleLoggedInUser()?.permissions.includes("ckl016")}
                isEdit={handleLoggedInUser()?.permissions.includes("ckl002")}
                isDelete={handleLoggedInUser()?.permissions.includes("ckl003")}
                isDownload={handleLoggedInUser()?.permissions.includes("ckl008")}
                isStatus={true}
                isEditMethod={lcHandleGoToChecklistEdit}
                isDeleteMethod={() => setDeleteLogAlert(true)}
                isDownloadMethod={() => setIsDownloadModal(true)}
                subbarData={lcChecklistData}
                staticElements={
                    [
                        { "key": "Last Updated On:", value: getFormatedDate(lcChecklistData?.updatedDate) },
                        { "key": "Last Updated By:", value: lcChecklistData?.updatedBy?.name },
                    ]
                }
                htmlElements={[
                    <div style={{ display: singleChecklistDataSetsDetails?.length > 0 ? "flex" : "none" }} key={generateUniqueId(2)} onClick={() => setIsPreviewTemplateModal(true)}>
                        <img src={COMMON_EYE_ICON} alt='Eye Icon' loading='lazy' />
                        <span style={{
                            color: "#0A5FFF",
                            fontFamily: "Roboto",
                            fontSize: "1rem",
                            fontStyle: "normal",
                            fontWeight: "600",
                            lineHeight: "normal"
                        }}>Preview</span>
                    </div>
                ]}
            />
            <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                <div className={Styles.template_and_general_detail_container}>
                    <div className={Styles.sub_header} aria-label='Sub Header'>
                        <span aria-label='Checklist Title'>{lcChecklistData?.name}</span>
                        <div className={Styles.validate_container} aria-label='Validate the checklist data sets contianer'>
                            {
                                handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER && validateRequestServerResponse?.length > 0 && <>

                                    <ClonosButton loading={lcValues?.reviseLoading} isDisabled={lcValues?.reviseLoading || lcChecklistData?.status === "revised" ? true : false} variant="outlined" onClick={() => {
                                        setLcValues(prev => {
                                            return { ...prev, "reviseLoading": true }
                                        })
                                        handleChangeLogsStatus({ logId: lcChecklistData?.id, dispatch, payload: { status: "revised", isGetResponse: true }, setRefreshApi, responseSetterMethod: setLcValues })
                                        // setRefreshApi()
                                    }}>Revise</ClonosButton>
                                    <ClonosButton
                                        loading={lcValues?.validateLoading || lcValues?.approveLoading}
                                        isDisabled={lcValues?.validateLoading || lcValues?.approveLoading}
                                        onClick={() => setIsValidateConfirmationModal(true)}
                                        variant="filled"
                                    >APPROVE</ClonosButton>
                                </>
                            }
                            {
                                handleLoggedInUser()?.role_id !== CLONOS_GLOBAL_USER_TYPE_OPERATOR && handleLoggedInUser().role_id === CLONOS_GLOBAL_USER_TYPE_ENGINEER && lcChecklistData?.status !== "completed" &&
                                <>
                                    {
                                        lcChecklistData?.isManagerApprovalRequired === false && <ClonosButton loading={lcValues?.reviseLoading} isDisabled={lcValues?.reviseLoading || lcChecklistData?.status === "revised" ? true : false} variant="outlined" onClick={() => {
                                            setLcValues(prev => {
                                                return { ...prev, "reviseLoading": true }
                                            })
                                            handleChangeLogsStatus({ logId: lcChecklistData?.id, dispatch, payload: { status: "revised", isGetResponse: true }, setRefreshApi, responseSetterMethod: setLcValues })
                                            // setRefreshApi()
                                        }}>Revise</ClonosButton>
                                    }
                                    <ClonosButton
                                        loading={lcValues?.validateLoading || lcValues?.approveLoading}
                                        isDisabled={lcValues?.validateLoading || validateRequestServerResponse?.length > 0 && true}
                                        onClick={() => {
                                            if (lcChecklistData?.isManagerApprovalRequired === false) {
                                                handleChangeLogsStatus({ logId: lcChecklistData?.id, dispatch, payload: { status: "completed", isGetResponse: true }, setRefreshApi })
                                            }
                                            else {
                                                setIsValidateConfirmationModal(true)
                                            }
                                        }}
                                        variant="filled"
                                    >{lcChecklistData?.isManagerApprovalRequired ? "Validate" : "Approve"}</ClonosButton>
                                </>
                            }
                        </div>
                    </div>
                    <div className={Styles.checklist_view_general_details_container}>
                        <section aria-label='General details' className={Styles.checklist_view_general_details} >
                            <div className={Styles.checklist_view_general_details_child_container} ref={generalDetailsRef}>
                                <table>
                                    <tr>
                                        <td>Document Number</td>
                                        <td>{lcChecklistData?.documentNumber ? lcChecklistData?.documentNumber : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Name</td>
                                        <td>{lcChecklistData?.name ? lcChecklistData?.name : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Description</td>
                                        <Tooltip title={lcChecklistData?.description}>
                                            <td className={Styles.description}>{lcChecklistData?.description ? lcChecklistData?.description : "Not Mentioned"}</td>

                                        </Tooltip>
                                    </tr>
                                    <tr>
                                        <td>Assigned User</td>
                                        <td>{lcChecklistData?.assignee?.name ? lcChecklistData?.assignee?.name : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Team</td>
                                        <td>{lcChecklistData?.team?.dropdownValues ? lcChecklistData?.team?.dropdownValues : "Not Mentioned"}</td>
                                    </tr>
                                </table>
                                <table>
                                    <tr>
                                        <td>Frequency</td>
                                        <td>{lcChecklistData?.frequencyType?.dropdownValues ? `${lcChecklistData?.frequencyType?.dropdownValues} ${lcChecklistData?.frequencyPeriod && `(Every ${lcChecklistData?.frequencyPeriod})`}` : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Asset</td>
                                        <td style={{ color: "#0A5FFF" }}>{lcChecklistData?.asset?.assetName ? lcChecklistData?.asset?.assetName : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Scheduled Time</td>
                                        <td>{lcChecklistData?.startDate ? `${getFormatedDate(lcChecklistData?.startDate)} ${getDayMonthYear(lcChecklistData?.startDate).time}` : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Created On</td>
                                        <td>{lcChecklistData?.createdDate ? getFormatedDate(lcChecklistData?.createdDate) : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Last Updated On</td>
                                        <td>{lcChecklistData?.updatedDate ? getFormatedDate(lcChecklistData?.updatedDate) : "Not Mentioned"}</td>
                                    </tr>
                                </table>
                            </div>
                        </section>
                    </div>
                    <div className={Styles.checklist_view_template_container}>
                        <div className={Styles.template_heading_contianer}>
                            <span onClick={setIsImagePreviewModal}>View Images</span>
                            <span>View Notes</span>
                        </div>
                        {singleChecklistDataSetsDetails?.length > 0 ? <ClonosDataGrid
                            rows={singleChecklistDataSetsDetails ? singleChecklistDataSetsDetails : []}
                            columns={columns}
                            pageLimit={10}
                            isEdit={false}
                            isDelete={false}
                            uniqueIdField="id"
                            checkboxSelection={false}
                        /> : <div style={{ height: "200px", width: "100%", display: 'flex', justifyContent: "center", alignItems: "center" }}>
                            <span style={{ fontSize: "2rem" }}>No Checklist Template Added</span></div>}
                    </div>
                </div>

            </Card>
            <Modal isOpen={isDownloadModal} closeModalMethod={setIsDownloadModal}>
                <ClonosExportOptions handleGetDetails={handleGetDetails} handleExportFile={handleExportFile} formats={["pdf", "xlsx"]} />
            </Modal>
            <Modal isOpen={isPreviewTemplateModal} closeModalMethod={setIsPreviewTemplateModal}>
                <div className={Styles.preview_container}>
                    <ChecklistTemplatePreview attributes={lcValues?.manipulatedDataForPreviewChecklistAttributes} isEdit={false} />
                </div>
            </Modal>

            <ClonosConfirmationBox
                isOpen={isValidateConfirmationModal}
                confirmingMethod={() => {
                    if (handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER) {
                        handleApproveTheValidateRequest({ dispatch, logId: lcChecklistData?.id, requestId: validateRequestServerResponse[0]?.requestId, responseSetterMethod: setLcValues, uniqueKey: "approveLoading", payload: { status: "completed" }, setRefreshApi })
                    } else {
                        handleCreateValidateRequests({ dispatch, logId: lcChecklistData?.id, responseSetterMethod: setLcValues, uniqueKey: "validateLoading", setRefreshApi })
                    }
                    setIsValidateConfirmationModal(false)
                }}
                closeModalMethod={setIsValidateConfirmationModal}
                headerTitle="Sending for approval."
                message={handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER ? "Are you sure, that you are approving this data entry?" : "Do you confirm that you are sending this log for further approval?"}
            />

            <ClonosConfirmationBox
                isOpen={deleteLogAlert}
                confirmingMethod={async () => {
                    try {
                        const response = await handleDeleteLogs({ dispatch, selectedRows: [lcChecklistData.id], isLocalUpdate: false }); // here it will return the response and based on the status we are restructing the user to redirect to the next page like if the status is note
                        if (response && (response.status === 200 || response.status === 201)) {
                            let interval = handleRedirectAfterEvent({ targetRoute: "/logs", timeout: 1000, navigate });
                            setLcIntervals({ ...lcIntervals, "deleteChecklist": interval });
                        }
                    } catch (error) {
                        console.error('Error during checklist deletion:', error);
                    } finally {
                        setDeleteLogAlert(false)
                    }
                }}
                closeModalMethod={() => setDeleteLogAlert(false)}
                headerTitle="Delete Log."
                message="Are you sure, You want to delete this log?"
            />

            <ImagePreviewModal
                open={isImagePreviewModal}
                activeImageIndex={1}
                closeModalMethod={setIsImagePreviewModal}
                images={images || []}
            />
        </>
    )
}

export default React.memo(LogsView)