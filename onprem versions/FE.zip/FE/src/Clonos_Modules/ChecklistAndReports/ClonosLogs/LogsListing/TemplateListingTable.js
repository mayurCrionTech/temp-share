import React, { useEffect, useState } from 'react'
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { commonPageState, getFormatedDate, globalManipulateTemplatePreviewData, handleLoggedInUser, hasPermission, setSerialNumber } from '../../../../utils/clonosCommon'
import { useNavigate } from 'react-router-dom'
import { handleDeleteChecklist, handleEditChecklist } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods'
import { useDispatch } from 'react-redux'
import { Card } from "@material-ui/core";
import CommonNavigator from '../../../../components/CommonComponents/Navigator/Navigator'
import ClonosConfirmationDialog from '../../../../components/Dialogs/ClonosConfirmationDialog'
import useToggler from '../../../../CustomHooks/TogglerHook'
import { doGetApiCall, doPutApiCall } from '../../../../utils/ClonosApi'
import AppUrl from '../../../../utils/AppUrl'
import { ChecklistAndReportsAction } from '../../../../Store/Reducers/ClonosChecklistAndReportsReducer'
import Modal from '../../../../components/CommonComponents/Modal/Modal'
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner'
// import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/TemplateCreationPage.module.css"
import { ChecklistTemplatePreview } from '../../../../components/ClonosChecklist/ChecklistTemplatePreview'
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button'
import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/ChecklistListing/ChecklistListing.module.css"
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { LogsAndReportsAction } from '../../../../Store/Reducers/ClonosLogsReducer'



const TemplateListingTable = ({ tableData, lcDataSetterMethod, isLoading }) => {
    const [selectedRows, setSelectedRows] = useState([]);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [lcValues, setLcValues] = useState({
        limit: commonPageState.limit,
        page: commonPageState?.page,
        totalTemplates: null,
        loading: false,
        savedTemplateServerResponse: [],
        getTemplateDataSetsLoading: false,
        manipulatedDataForPreviewChecklistAttributes: [],
        templateId: null,
        deleteTemplateLoading: false
    });
    const { totalTemplates, page, limit, savedTemplateServerResponse, loading, getTemplateDataSetsLoading, manipulatedDataForPreviewChecklistAttributes, templateId, deleteTemplateLoading } = lcValues;
    const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
    const [refreshApi, setRefreshApi] = useToggler();
    const [isImportedTemplatePreviewModal, setIsImportedTemplatePreviewModal] = useState(false);


    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            flex: 1,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            field: "templateName",
            headerName: "NAME",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.templateName || "-",
            renderCell: (param) => {
                return <p className="c-pointer" onClick={() => handleGetTemplateDataSets(param?.id)} style={{ textDecoration: "underline", color: "#0A5FFF" }}>{param?.row?.templateName || "-"}</p>
            }
        },
        {
            field: "createdDate",
            headerName: "CREATED ON",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.createdDate ? getFormatedDate(params?.row?.createdDate) : "-"
        },
    ];

    /**
     * "handleGetSelectedRowsMethod" help to get all the selected rows from the ClonosDataGrid Component.
     * @param {Object} props  
     * @property {Array} props.selectedRows This will contain the the selected rows IDs
     */
    const handleGetSelectedRowsMethod = (props) => {
        setSelectedRows(props.selectedRows)
    };

    /**
     * "handleGoToChecklistView" function help to redirect user from checklist to checklist view
     * @param {Object} props Contain the ID of of the checklist that we awant to view. 
     */
    const handleGotoChecklistView = (props) => {
        navigate(`/view-checklist/${props?.name}`, { state: { id: props?.id } })
    };

    /**
     * "handleGoToEditChecklist" function helps to redirect to edit checklist page.
     */
    const handleGoToEditChecklist = () => {
        navigate("/create-checklist-generaldetails", { state: { "mode": "edit", "id": selectedRows[0] } })
    };


    const handleGoToCreateGeneralDetails = () => {
        dispatch(LogsAndReportsAction.setUseTemplateInformation({ useTemplate: true, templateId }))
        navigate("/create-log-generaldetails")
    }

    const handleGetTemplateDataSets = (id) => {
        setIsImportedTemplatePreviewModal(true);
        setLcValues(prev => {
            return { ...prev, ["getTemplateDataSetsLoading"]: true, templateId: id }
        })
        doGetApiCall(`logs/templates/${id}/dataSets`, { fieldValue: 1 })
            .then(res => {
                const sortedDataSets = res?.data?.result?.data?.sort((a, b) => Number(a["index"]) - Number(b["index"]))
                dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(globalManipulateTemplatePreviewData({ data: sortedDataSets })))
                setLcValues(prev => {
                    return { ...prev, ["manipulatedDataForPreviewChecklistAttributes"]: globalManipulateTemplatePreviewData({ data: sortedDataSets }) }
                })
            }).finally(() => {
                setLcValues(prev => {
                    return { ...prev, ["getTemplateDataSetsLoading"]: false }
                })
            })
    }

    const handleDeleteTemplate = () => {
        setLcValues(prev => {
            return { ...prev, ["deleteTemplateLoading"]: true }
        })
        doPutApiCall(AppUrl.deleteLogTemplates, { logTemplateIds: selectedRows }).then((res) => {
        }).finally(() => {
            setLcValues(prev => {
                return { ...prev, ["deleteTemplateLoading"]: false }
            })
            setShowConfirmationDailog(false)
            setRefreshApi()
        })
    }

    useEffect(() => {
        setLcValues(prev => {
            return { ...prev, ["loading"]: true }
        })

        doGetApiCall(AppUrl?.getLogSaveAsTemplates, { page, limit })
            .then(res => {
                setLcValues((prev) => {
                    const result = res?.data?.result;

                    if (!result?.data || !Array.isArray(result.data)) {
                        console.error('Invalid or missing data in the API response.');
                        return prev;
                    }

                    return {
                        ...prev,
                        savedTemplateServerResponse: setSerialNumber(result?.data || [], page, limit),
                        totalTemplates: result?.totalDataCount
                    };
                });
            })
            .finally(() => {
                setLcValues(prev => {
                    return { ...prev, ["loading"]: false }
                })
            });
    }, [page, refreshApi]);

    return (
        <>
            <ClonosDataGrid
                rows={savedTemplateServerResponse}
                columns={columns}
                pageLimit={limit}
                totalCount={totalTemplates}
                uniqueIdField={"id"}
                isDeleteMethod={() => handleLoggedInUser()?.permissions?.includes("ckl003") ? setShowConfirmationDailog(true) : false}
                handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
                isEditMethod={false}
                onPageChange={e => setLcValues({ ...lcValues, page: e.page + 1, limit: e.pageSize })}
                isLoading={loading}
            />
            <ClonosConfirmationBox
                isOpen={showConfirmationDailog}
                loading={deleteTemplateLoading}
                confirmingMethod={() => {
                    handleDeleteTemplate()
                }}
                closeModalMethod={setShowConfirmationDailog}
                headerTitle="Delete Template."
                message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this template" : "these templates"}?`}
            />

            <Modal isOpen={isImportedTemplatePreviewModal} closeModalMethod={setIsImportedTemplatePreviewModal} >
                <div className={Styles.imported_template_Preview_container}>
                    {
                        getTemplateDataSetsLoading ? <ClonosSpinner /> : <>
                            <ChecklistTemplatePreview
                                attributes={manipulatedDataForPreviewChecklistAttributes}
                                isEdit={false}
                            />
                            <footer>
                                <ClonosButton variant="filled" onClick={handleGoToCreateGeneralDetails}>Use Template</ClonosButton>
                            </footer>
                        </>
                    }
                </div>
            </Modal>
        </>
    )
}

export default React.memo(TemplateListingTable)