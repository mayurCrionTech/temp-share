import React, { useState } from 'react'
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { getFormatedDate, handleLoggedInUser, hasPermission } from '../../../../utils/clonosCommon'
import { useNavigate } from 'react-router-dom'
import { handleDeleteChecklist, handleEditChecklist } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods'
import { useDispatch } from 'react-redux'
import { Card } from "@material-ui/core";
import CommonNavigator from '../../../../components/CommonComponents/Navigator/Navigator'
import ClonosConfirmationDialog from '../../../../components/Dialogs/ClonosConfirmationDialog'
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { handleDeleteLogs } from '../../../../utils/ChecklistAndReportsMethods/LogsMethod'
import { statusStaticData } from '../../../../Constants/StaticData'


const LogsListingTable = ({ tableData, lcDataSetterMethod, totalCount, pageLimit, setPagination, isLoading, setRefreshApi, setRefreshStatusCount }) => {
    const [selectedRows, setSelectedRows] = useState([]);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
    const [loading, setLoading] = useState(false);

    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            flex: 1,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
            hideable: false
        },
        {
            field: "logNumber",
            headerName: "LOG NUMBER",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
            // valueGetter: (params) => params?.row?.woNumber || "-"
        },
        {
            field: "name",
            headerName: "LOG NAME",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            renderCell: (params) => {
                return <p onClick={() => handleGotoLogsView(params?.row)} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>

            }
        },
        {
            field: "assignee",
            headerName: "ASSIGNED USER",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.assignee?.name ? params?.row?.assignee?.name : "-"
        },
        {
            field: "team",
            headerName: "TEAM",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.team?.dropdownValues || "-"
        },
        {
            field: "frequencyType",
            headerName: "FREQUENCY",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            // valueGetter: (params) => params?.row?.asset && params?.row?.asset[0]?.name || "-"
        },
        {
            field: "department",
            headerName: "DEPARTMENT",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.department || "No Server Response"
        },
        {
            field: "status",
            headerName: "STATUS",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.status ? statusStaticData[params?.row?.status] : "-"
        },
        {
            field: "createdDate",
            headerName: "CREATED ON",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.createdDate ? getFormatedDate(params?.row?.createdDate) : "-"
        },
        {
            field: "updatedDate",
            headerName: "LAST UPDATED ON",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.updatedDate ? getFormatedDate(params?.row?.updatedDate) : "-"
        }
    ]

    /**
     * "handleGetSelectedRowsMethod" help to get all the selected rows from the ClonosDataGrid Component.
     * @param {Object} props  
     * @property {Array} props.selectedRows This will contain the the selected rows IDs
     */
    const handleGetSelectedRowsMethod = (props) => {
        setSelectedRows(props.selectedRows)
    }

    /**
     * "handleGoToChecklistView" function help to redirect user from checklist to checklist view
     * @param {Object} props Contain the ID of of the checklist that we awant to view. 
     */
    const handleGotoLogsView = (props) => {
        navigate(`/view-log/${props.name}`, { state: { id: props?.id } })
    }

    /**
     * "handleGoToEditLog" function helps to redirect to edit checklist page.
     */
    const handleGoToEditLog = () => {
        navigate("/edit-log-generaldetails", { state: { "mode": "edit", "id": selectedRows[0] } })
    }


    return (
        <>
            <div style={{ padding: "2.5rem 2rem", height: "100%" }}>
                <ClonosDataGrid
                    rows={tableData}
                    columns={columns}
                    pageLimit={pageLimit}
                    totalCount={totalCount}
                    uniqueIdField={"id"}
                    isDeleteMethod={() => hasPermission("/checklist-delete") ? setShowConfirmationDailog(true) : false}
                    handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
                    isEditMethod={hasPermission("/logs-edit") ? () => handleGoToEditLog() : false}
                    onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                    checkboxSelection={hasPermission("/checklist-delete") && hasPermission("/checklist-edit")}
                    isLoading={isLoading}
                />
            </div>
            <ClonosConfirmationBox
                isOpen={showConfirmationDailog}
                loading={loading}
                confirmingMethod={() => {
                    setLoading(true)
                    handleDeleteLogs({ dispatch, selectedRows, lcDataSetterMethod, isLocalUpdate: true, responseSetterMethod: { setLoading, setShowConfirmationDailog, setRefreshApi, setRefreshStatusCount } })
                }}
                closeModalMethod={setShowConfirmationDailog}
                headerTitle="Delete Log."
                message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this log" : "these logs"}?`}

            />

        </>
    )
}

export default React.memo(LogsListingTable)