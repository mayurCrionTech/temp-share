import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import { notificationActions } from "../../../Store/Reducers/ClonosNotificationsReducer";
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall } from "../../../utils/ClonosApi";

// To get the all existing notifications.
const handleGetNotifications = ({
    responseSetterMethod,
    lcStateSetterMethod,
    pagination
}) => {
    doGetApiCall({
        url: AppUrl.getNotifications,
        params: { page: pagination.page, limit: pagination?.limit }
    }).then((response) => {

        const result = {
            status: response?.status,
            message: response?.data?.message,
            data: response?.data?.result?.data,
            totalDataCount: response?.data?.result?.totalDataCount,
            totalPageCount: response?.data?.result?.totalPageCount,
        }
        if (result?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            responseSetterMethod(prev => ({ ...prev, notifications: result }));
        }
    }).finally(() => {
        lcStateSetterMethod(prev => ({ ...prev, ["getNotificationsLoading"]: false }));
    });
}

// To handle the pagination in the infine scroll
const handleUpdatePagination = ({ setServerResponse, setPagination }) => {
    setServerResponse(serverStatePrev => {
      
        setPagination(prev => {
            if (serverStatePrev?.notifications?.totalPageCount + 1 !== prev?.page) {
                return { ...prev, page: prev?.page + 1 }
            }
            return prev
        });
        return serverStatePrev;
    })
};

// To update the store once we got the notification.
const handleUpdateNotificationsStore = ({ storedNotifications, currentNotification, dispatch }) => {
    const newNotificationsData = [...storedNotifications, currentNotification];
    dispatch(notificationActions.setNotificationsToolkitState(newNotificationsData));
}

export {
    handleUpdateNotificationsStore,
    handleGetNotifications,
    handleUpdatePagination
}
