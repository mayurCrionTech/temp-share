import React, { useEffect, useState } from "react";
import Styles from "../../ModuleStyles/ClonosDashboard/Dashboard.module.css";
import { doGetApiCall } from "../../utils/ClonosApi";
import AppUrl from "../../utils/AppUrl";
import {Card} from "@material-ui/core";
import DashboardCard from "./DashboardCard";
import LogChart from "./LogChart";
import ReportsChart from "./ReportsChart";
import DateFilters from "./DateFilters";
import LogEntries from "./LogEntries";
import ClonosSkeletonLoading from "../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

const Dashboard = React.memo(() => {

  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [dashboardData, setDashboardData] = useState([]);
  const [loading, setLoading] = useState(false);


  const fetchDashboardData = () => {
    let url = AppUrl.getDashboards;
  
     // Format the start and end dates to 'YYYY-MM-DDTHH:MM'
      const formattedStartDate = startDate ? new Date(startDate).toISOString().slice(0, 16) : "";
      const formattedEndDate = endDate ? new Date(endDate).toISOString().slice(0, 16) : "";
  
    // Append the date filters to the API URL if they exist
    if (formattedStartDate || formattedEndDate) {
      url += `?startDate=${formattedStartDate}&endDate=${formattedEndDate}`;
    }
  
    setLoading(true); // Start loading when fetching data
    doGetApiCall({ url })
      .then((res) => setDashboardData(res?.data?.result || {}))
      .finally(() => setLoading(false)); // Stop loading after data is fetched
  };
  

  useEffect(() => {
    // setLoading(true);
    fetchDashboardData();
  }, [startDate, endDate]);
 useEffect(()=>{
  doGetApiCall({ url:AppUrl.getDashboards })
  .then((res) => setDashboardData(res?.data?.result || {}))
  .finally(() => setLoading(false));
  
 },[])


 
  return (
    <Card variant="outlined" className={Styles.dashboardContainer}>

 
    <div className={Styles.dashboardHeader}>

        <h4 className={Styles.dashboardTitle}>Log Compliance</h4>

      <div className={Styles.dateFilterWrapper}>
        <DateFilters  
          startDate={startDate} 
          endDate={endDate} 
          setStartDate={setStartDate} 
          setEndDate={setEndDate} 
        />
      </div>
    </div>

     
      
      <main className={Styles.cardWrapper}>
        {loading ? (
          <>
             <ClonosSkeletonLoading width="100%" height="400px" animation="wave" />
             <ClonosSkeletonLoading width="100%" height="400px" animation="wave" />
             <ClonosSkeletonLoading width="100%" height="400px" animation="wave" />
          </>
        ) : (
          <>
            <DashboardCard title="Logs" chart={<LogChart data={dashboardData?.logs} />} />
            <DashboardCard title="Log Entries" chart={<LogEntries data={dashboardData?.logEntries} />} />
            <DashboardCard title="Reports" chart={<ReportsChart data={dashboardData?.reports} />} />
          </>
        )}
      </main>
    </Card>
  );
});

export default Dashboard;



{/* <div className={Styles.dashboardLogoContainer}>
  <div className={Styles.logoWrapper}>
    {renderSVGLogo(dashboardData.logo?.logo1, Styles.logo1)}
    {renderSVGLogo(dashboardData.logo?.logo2, Styles.logo2)}
    
  </div>
</div> */}