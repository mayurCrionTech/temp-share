import React, { useState, useEffect } from "react";
import { Grid, Card, CardContent, Typography } from "@mui/material";
import Styles from './energy-dashboard.module.css';
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

function LiveEnergyData({ energyDashboardData, startDate, endDate }) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Reset loader on startDate or endDate change
    setLoading(true);

    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000); // Adjust duration as needed

    return () => clearTimeout(timer);
  }, [energyDashboardData, startDate, endDate]);

  const cardData = [
    {
      title: "Total Energy Consumed",
      value: (data) => (
        <>
          {(data?.totalEnergyConsumed?.value || 0).toLocaleString()}
          <span style={{ fontSize: "1rem", marginLeft: 4 }}>
            {data?.totalEnergyConsumed?.unit || ""}
          </span>
        </>
      ),
    },
    {
      title: "EB Consumption",
      value: (data) => (
        <>
          {(data?.ebConsumption?.value || 0).toLocaleString()}
          <span style={{ fontSize: "1rem", marginLeft: 4 }}>
            {data?.ebConsumption?.unit || ""}
          </span>
        </>
      ),
    },
    {
      title: "Genset Consumption",
      value: (data) => (
        <>
          {(data?.gensetConsumption?.value || 0).toLocaleString()}
          <span style={{ fontSize: "1rem", marginLeft: 4 }}>
            {data?.gensetConsumption?.unit || ""}
          </span>
        </>
      ),
      subValue: (data) =>
        `${(
          ((data?.gensetConsumption?.value || 0) /
            (data?.totalEnergyConsumed?.value || 1)) *
          100
        ).toFixed(0)}%`,
    },
    {
      title: "Peak Consumption Day",
      value: (data) =>
        data?.peakConsumptionDay?.date
          ? new Date(data.peakConsumptionDay.date).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "N/A",
      subValue: (data) =>
        data?.peakConsumptionDay?.value ? (
          <>
            {data.peakConsumptionDay.value.toLocaleString()}
            <span style={{ fontSize: "0.8rem", marginLeft: 4 }}>
              {data.peakConsumptionDay.unit}
            </span>
          </>
        ) : (
          "0"
        ),
    },
  ];

  return (
    <>
      <Typography variant="h5" gutterBottom className={Styles.energyDashboardTitle}>
        Live Data
      </Typography>

      <Grid container spacing={2}>
        {loading
          ? Array.from({ length: 4 }).map((_, index) => (
              <Grid item xs={12} sm={6} md={3} lg={3} key={index}>
                <ClonosSkeletonLoading width="100%" height="160px" animation="wave" />
              </Grid>
            ))
          : cardData.map((card, index) => (
              <Grid item xs={12} sm={6} md={3} lg={3} key={index} style={{ display: "flex" }}>
                <Card
                  style={{
                    borderRadius: "16px",
                    padding: "8px",
                    width: "100%",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    maxHeight: "250px",
                    overflow: "hidden",
                  }}
                >
                  <CardContent
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                      height: "100%",
                      padding: "8px",
                    }}
                  >
                    <Typography className={Styles.liveEnergyDashboardCard} style={{ textAlign: "center" }}>
                      {card.title}
                    </Typography>

                    <div
                      style={{
                        marginTop: "0.5rem",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        flexGrow: 1,
                      }}
                    >
                      <Typography variant="h5" color="primary" style={{ textAlign: "center" }}>
                        {card.value(energyDashboardData)}
                      </Typography>
                      {card.subValue && (
                        <Typography color="textSecondary" style={{ textAlign: "center", fontSize: "13px" }}>
                          {card.subValue(energyDashboardData)}
                        </Typography>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Grid>
            ))}
      </Grid>
    </>
  );
}

export default LiveEnergyData;
