import React, { useState, useEffect } from "react";
import Styles from './energy-dashboard.module.css';
import { Container, Card } from "@mui/material";
import DateFilters from '../DateFilters';
import LiveEnergyData from "./LiveEnergyData";
import Consumption from "./Consumption/Consumption";
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall } from "../../../utils/ClonosApi";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";

function EnergyDashboard() {
  const [energyDashboardData, setEnergyDashboardData] = useState([]);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [dataLoadedOnce, setDataLoadedOnce] = useState(false);
  const formattedStartDate = startDate ? new Date(startDate).toISOString().slice(0, 16) : "";
  const formattedEndDate = endDate ? new Date(endDate).toISOString().slice(0, 16) : "";
  
  const defaultZeroData = {
    totalEnergyConsumed: { unit: "kWh", value: 0 },
    ebConsumption: { unit: "kWh", value: 0 },
    gensetConsumption: { unit: "kWh", value: 0, efficiency: 0 },
    peakConsumptionDay: { date: "", unit: "kWh", value: 0 },
  };
  
  useEffect(() => {
    setIsLoading(true);

    let url = `${AppUrl.getEnergyDashboard}?totalEnergyConsumed=true&ebConsumption=true&gensetConsumption=true&dailyPeak=true&highestSectionDay=true&clientId=2`;

    if (formattedStartDate && formattedEndDate) {
      url += `&startDate=${formattedStartDate}&endDate=${formattedEndDate}`;
    }

    doGetApiCall({ url }).then((res) => {
      if (res?.data?.result) {
        setEnergyDashboardData(res.data.result);
      } else {
        setEnergyDashboardData(defaultZeroData);
      }
      setIsLoading(false);
      setDataLoadedOnce(true);
    });
  }, [formattedStartDate, formattedEndDate]);
  
  // const isDataEmpty = !energyDashboardData

  // const isDataEmpty = dataLoadedOnce && Array.isArray(energyDashboardData) && energyDashboardData.length === 0;
    const isDataEmpty = !energyDashboardData ||
    (
      !energyDashboardData.totalEnergyConsumed &&
      !energyDashboardData.ebConsumption &&
      !energyDashboardData.gensetConsumption &&
      !energyDashboardData.dailyPeak &&
      !energyDashboardData.highestSectionDay
    );


  return (
  <>
      {/* Show Loader before anything is loaded */}
      {!dataLoadedOnce && isLoading ? (
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "400px" }}>
          <ClonosSpinner />
        </div>
      ) : isDataEmpty ? (
        // If data loaded but is empty, show message card
        <Card variant="outlined" className={Styles.energyDashboardContainer}>
          <p style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            textAlign: "center",
            fontSize: "25px",
            color: "#575757"
          }}>
            Please Contact Admin to Access this page
          </p>
        </Card>
      ) : (
        // If data exists, show full dashboard
        <Card variant="outlined" className={Styles.energyDashboardContainer}>
          <div className={Styles.energyDashboardHeader}>
            <h4 className={Styles.energyDashboardTitle}>Energy Dashboard</h4>
            <div className={Styles.dateFilterWrapper}>
              <DateFilters  
                startDate={startDate} 
                endDate={endDate} 
                setStartDate={setStartDate} 
                setEndDate={setEndDate} 
              />
            </div>
          </div>

          {isLoading ? (
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "200px" }}>
              <ClonosSpinner />
            </div>
          ) : (
            <main> 
              <Container style={{ marginBottom: "20px" }}>
                <LiveEnergyData energyDashboardData={energyDashboardData} startDate={formattedStartDate} endDate={formattedEndDate}/>
                <Consumption startDate={formattedStartDate} endDate={formattedEndDate} />
              </Container>
            </main>
          )}
        </Card>
      )}
   </>

   
        );
      }
      
      export default EnergyDashboard;
   