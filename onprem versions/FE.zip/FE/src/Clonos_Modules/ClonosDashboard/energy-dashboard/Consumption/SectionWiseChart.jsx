import React, { useEffect, useState } from 'react';
import { Card, CardContent, Typography, Grid } from '@material-ui/core';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import Styles from '../energy-dashboard.module.css';
import { doGetApiCall } from '../../../../utils/ClonosApi';
import AppUrl from '../../../../utils/AppUrl';
import ClonosSkeletonLoading from '../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading';
import { Modal, IconButton } from "@material-ui/core";
import ZoomOutMapIcon from '@material-ui/icons/ZoomOutMap';
import CloseRoundedIcon from '@material-ui/icons/CloseRounded';

function SectionWiseChart({ startDate, endDate }) {
  const [sectionWiseData, setSectionWiseData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);

  useEffect(() => {
    let url = `${AppUrl?.getEnergyDashboard}?sectionWise=true&clientId=2`;

    if (startDate && endDate) {
      url += `&startDate=${startDate}&endDate=${endDate}`;
    }

    setLoading(true);

    doGetApiCall({ url }).then((res) => {
      const rawData = res?.data?.result?.sectionWiseConsumption?.data || [];

      const grouped = rawData.reduce((acc, curr) => {
        const section = curr.section?.trim();
        const val = curr.value || 0;

        if (!acc[section]) {
          acc[section] = { section, value: 0 };
        }

        acc[section].value += val;
        return acc;
      }, {});

      const processedData = Object.values(grouped)
        .sort((a, b) => b.value - a.value)
        .slice(0, 8); // Top 8

      setSectionWiseData(processedData);
      setLoading(false);
    });
  }, [startDate, endDate]);

  return (
    <>
    <Card style={{ width: '100%', borderRadius: '16px', padding: '10px' }}>
      {loading ? (
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <ClonosSkeletonLoading width="60%" height={30} animation="wave" style={{ marginBottom: '20px' }} />
              <ClonosSkeletonLoading width="100%" height={300} animation="wave" />
            </Grid>
          </Grid>
        </CardContent>
      ) : (
        <CardContent>
          <Typography gutterBottom className={Styles.liveEnergyDashboardCard}>
            Section-Wise Consumption
          </Typography>
          <div style={{ width: '100%', height: 300 , position:"relative"}}>
            <ResponsiveContainer>
              <BarChart
                data={sectionWiseData}
                layout="vertical"
                margin={{ top: 20, right: 20, left: 30, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  type="number"
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  tick={{ fontSize: 12 }}
                />
                <YAxis
                  type="category"
                  dataKey="section"
                  tick={{
                    fontSize: 12,
                    width: 100,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="#5976A9" />
              </BarChart>
            </ResponsiveContainer>
            
            <IconButton
                  onClick={() => setOpenModal(true)}
                  title="Expand Chart"
                  style={{
                    position: "absolute",
                    bottom:-30,
                    right: -20,
                    backgroundColor: "#fff",
                    // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
                    zIndex: 1, // optional, ensures it appears above chart
                  }}
                >
              <ZoomOutMapIcon />
            </IconButton>

          </div>
        </CardContent>
      )}
    </Card>
    

      <Modal open={openModal} onClose={() => setOpenModal(false)}>
                         <div style={{
                           position: 'absolute',
                           top: '50%',
                           left: '50%',
                           transform: 'translate(-50%, -50%)',
                           background: 'white',
                           padding: 20,
                           borderRadius: 10,
                           outline: 'none',
                           width: '90%',
                           height: '90%',
                           overflow: 'auto'
                         }}>
                         
              <Typography gutterBottom className={Styles.liveEnergyDashboardCard} style={{marginTop:"15px"}}>
                Section-Wise Consumption
              </Typography>
              <div style={{ width: '100%', height: 300 , position:"relative"}}>
                <ResponsiveContainer width="100%" height={500}>
                  <BarChart
                    data={sectionWiseData}
                    layout="vertical"
                     width={500}
                    height={450}
                    margin={{ top: 30, right: 30, left: 40, bottom: 0 }}
                    // margin={{ top: 20, right: 20, left: 30, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      type="number"
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis
                      type="category"
                      dataKey="section"
                      tick={{
                        fontSize: 12,
                        width: 100,
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" fill="#5976A9" />
                  </BarChart>
                </ResponsiveContainer>
                
                <IconButton
                      onClick={() => setOpenModal(false)}
                      title="Close"
                      style={{
                        position: "absolute",
                        bottom:315,
                        right: -20,
                        backgroundColor: "#fff",
                        // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
                        zIndex: 1, // optional, ensures it appears above chart
                      }}
                    >
                     <CloseRoundedIcon style={{fontSize:"30"}}/>
                </IconButton>

              </div>

         </div>

       </Modal> 

    </>   

  );
}

export default SectionWiseChart;
