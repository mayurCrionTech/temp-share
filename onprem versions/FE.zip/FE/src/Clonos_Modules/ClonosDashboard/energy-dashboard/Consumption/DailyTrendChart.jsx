import React, { useEffect, useState } from 'react';
import { Card, CardContent, Typography, Grid } from '@material-ui/core';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Brush
} from 'recharts';
import Styles from '../energy-dashboard.module.css';
import AppUrl from '../../../../utils/AppUrl';
import { doGetApiCall } from '../../../../utils/ClonosApi';
import ClonosSkeletonLoading from '../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading';
import { Modal, IconButton } from "@material-ui/core";
import ZoomOutMapIcon from '@material-ui/icons/ZoomOutMap';
import CloseRoundedIcon from '@material-ui/icons/CloseRounded';
import { format } from 'date-fns'

const getMonthlyTicks = (data) => {
  const seenMonths = new Set();
  return data
    .filter((item) => {
      const month = new Date(item.date).getMonth();
      if (!seenMonths.has(month)) {
        seenMonths.add(month);
        return true;
      }
      return false;
    })
    .map((item) => item.date);
};

function DailyTrendChart({ startDate, endDate }) {
  const [dailyTrend, setDailyTrend] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);
  
  const formatDate = (isoString) => format(new Date(isoString), 'dd MMM yyyy');
  useEffect(() => {
    let url = `${AppUrl?.getEnergyDashboard}?dailyTrend=true&clientId=2`;

    if (startDate && endDate) {
      url += `&startDate=${startDate}&endDate=${endDate}`;
    }

    setLoading(true);

    doGetApiCall({ url }).then((res) => {
      const trendData = res?.data?.result?.dailyTrend?.data || [];
      setDailyTrend(trendData);
      setLoading(false);
    });
  }, [startDate, endDate]);

  const monthTicks = getMonthlyTicks(dailyTrend);

  return (
    <>
    <Card style={{ width: '100%', borderRadius: '16px', padding: '10px' }}>
      {loading ? (
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <ClonosSkeletonLoading width="60%" height={30} animation="wave" style={{ marginBottom: '20px' }} />
              <ClonosSkeletonLoading width="100%" height={200} animation="wave" />
            </Grid>
          </Grid>
        </CardContent>
      ) : (
        <CardContent>
          <Typography gutterBottom className={Styles.liveEnergyDashboardCard}>
            Daily Trend
          </Typography>
          <div style={{ width: '100%', height: 200 ,position:"relative"}}>
            <ResponsiveContainer>
              <LineChart
                data={dailyTrend}
                margin={{ top: 30, right: 30, left: 10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="date"
                  ticks={monthTicks}
                  tickFormatter={(str) => {
                    const date = new Date(str);
                    return date.toLocaleDateString('en-US', { month: 'short' });
                  }}
                />
                <YAxis />
                <Tooltip
                  labelFormatter={(str) =>
                    new Date(str).toLocaleDateString('en-US', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })
                  }
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#6885B1"
                  strokeWidth={2}
                  dot={({ cx, cy, payload }) =>
                    payload.isPeak ? (
                      <>
                        <text
                          x={cx}
                          y={cy - 15}
                          textAnchor="middle"
                          fontSize={12}
                          fill="#000"
                        >
                          {new Date(payload.date).toLocaleDateString('en-US', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </text>
                        <circle cx={cx} cy={cy} r={4} fill="#2C4E87" />
                      </>
                    ) : null
                  }
                />
                
              </LineChart>
              
            </ResponsiveContainer>
            
             <IconButton
                onClick={() => setOpenModal(true)}
                title="Expand Chart"
                style={{
                  position: "absolute",
                  bottom:-30,
                  right: -20,
                  backgroundColor: "#fff",
                  // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
                  zIndex: 1, // optional, ensures it appears above chart
                }}
              >
            <ZoomOutMapIcon />
          </IconButton>
            
          </div>
        </CardContent>
      )}
    </Card>
    
      <Modal open={openModal} onClose={() => setOpenModal(false)}>
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            background: 'white',
            padding: 20,
            borderRadius: 10,
            outline: 'none',
            width: '90%',
            height: '90%',
            overflow: 'auto'
          }}>

          <Typography gutterBottom className={Styles.liveEnergyDashboardCard} style={{marginTop:"15px"}}>
            Daily Trend
          </Typography>
          <div style={{ width: '100%', height: 200 ,position:"relative"}}>
            <ResponsiveContainer width="100%" height={500}>
              <LineChart
                data={dailyTrend}
                width={500}
                height={400}
                margin={{ top: 30, right: 30, left: 30, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="date"
                  ticks={monthTicks}
                  tickFormatter={(str) => {
                    const date = new Date(str);
                    return date.toLocaleDateString('en-US', { month: 'short' });
                  }}
                />
                <YAxis />
                <Tooltip
                  labelFormatter={(str) =>
                    new Date(str).toLocaleDateString('en-US', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })
                  }
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#6885B1"
                  strokeWidth={2}
                  dot={({ cx, cy, payload }) =>
                    payload.isPeak ? (
                      <>
                        <text
                          x={cx}
                          y={cy - 15}
                          textAnchor="middle"
                          fontSize={12}
                          fill="#000"
                        >
                          {new Date(payload.date).toLocaleDateString('en-US', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </text>
                        <circle cx={cx} cy={cy} r={4} fill="#2C4E87" />
                      </>
                    ) : null
                  }
                />
                  <Brush
                    dataKey="date"
                    height={30} 
                    stroke="#6885B1" 
                    travellerWidth={10}
                    tickFormatter={formatDate}
                  />
              </LineChart>
            </ResponsiveContainer>
            
              <IconButton
                  onClick={() => setOpenModal(false)}
                  title="Close"
                  style={{
                    position: "absolute",
                    bottom:215,
                    right: -22,
                    backgroundColor: "#fff",
                    // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
                    zIndex: 1, // optional, ensures it appears above chart
                  }}
                >
                    <CloseRoundedIcon style={{fontSize:"30"}}/>
              </IconButton>
            
          </div>
          
          </div>
      </Modal>
   </>
  );
}

export default DailyTrendChart;
