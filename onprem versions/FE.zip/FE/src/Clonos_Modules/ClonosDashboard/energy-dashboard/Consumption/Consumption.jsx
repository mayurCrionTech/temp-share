import React from 'react';
import { Grid, Typography } from "@mui/material";
import Styles from '../energy-dashboard.module.css';
import MonthlyChart from './MonthlyChart';
import SectionWiseChart from './SectionWiseChart';
import DailyTrendChart from './DailyTrendChart';

function Consumption({startDate,endDate}) {
  return (
    <>
      <div style={{marginTop:"30px"}}>
        <Typography variant="h6" gutterBottom className={Styles.energyDashboardTitle}>
          Consumption
        </Typography>
      </div>

      <Grid container spacing={2}>
        {/* 1st row: MonthlyChart + SectionWiseChart */}
        <Grid item xs={12} md={6}>
          <MonthlyChart startDate={startDate} endDate={endDate}/>
        </Grid>
        <Grid item xs={12} md={6}>
          <SectionWiseChart startDate={startDate} endDate={endDate}/>
        </Grid>

        {/* 2nd row: Full width DailyTrendChart */}
        <Grid item xs={12}>
          <DailyTrendChart startDate={startDate} endDate={endDate}/>
        </Grid>
      </Grid>
    </>
  );
}

export default Consumption;
