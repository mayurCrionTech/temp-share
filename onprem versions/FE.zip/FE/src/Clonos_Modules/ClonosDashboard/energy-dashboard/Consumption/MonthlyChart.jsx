import React, { useEffect, useState } from 'react';
import { Card, CardContent, Typography, Grid } from '@material-ui/core';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import Styles from '../energy-dashboard.module.css';
import { doGetApiCall } from '../../../../utils/ClonosApi';
import AppUrl from '../../../../utils/AppUrl';
import { parseISO, format } from 'date-fns';
import ClonosSkeletonLoading from '../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading';
import { Modal, IconButton } from "@material-ui/core";
import ZoomOutMapIcon from '@material-ui/icons/ZoomOutMap';
import CloseRoundedIcon from '@material-ui/icons/CloseRounded';

function MonthlyChart({ startDate, endDate }) {
  const [monthlyData, setMonthlyData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);

  useEffect(() => {
    let url = `${AppUrl?.getEnergyDashboard}?monthlyOverview=true&clientId=2`;

    if (startDate && endDate) {
      url += `&startDate=${startDate}&endDate=${endDate}`;
    }

    setLoading(true); // show loader

    doGetApiCall({ url }).then((res) => {
      const rawData = res?.data?.result?.monthlyConsumptionOverview?.data;

      if (Array.isArray(rawData)) {
        const grouped = {};

        rawData.forEach((item) => {
          try {
            const date = parseISO(item.date);
            const monthKey = format(date, 'MMM-yy');

            if (!grouped[monthKey]) {
              grouped[monthKey] = {
                month: monthKey,
                eb: 0,
                genset: 0,
                timestamp: date.getTime()
              };
            }

            grouped[monthKey].eb += Number(item.ebConsumption || 0);
            grouped[monthKey].genset += Number(item.gensetConsumption || 0);
          } catch (err) {
            console.error('Date parse error:', item.date);
          }
        });

        const finalData = Object.values(grouped).sort((a, b) => a.timestamp - b.timestamp);
        setMonthlyData(finalData);
      }

      setLoading(false); // hide loader
    });
  }, [startDate, endDate]);

  return (
    <>
    <Card style={{ width: '100%', borderRadius: '16px', padding: '10px' }}>
      {loading ? (
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <ClonosSkeletonLoading width="60%" height={30} animation="wave" style={{ marginBottom: '20px' }} />
              <ClonosSkeletonLoading width="100%" height={300} animation="wave" />
            </Grid>
          </Grid>
        </CardContent>
      ) : (
        <CardContent>
          <Typography gutterBottom className={Styles.liveEnergyDashboardCard}>
            Monthly Consumption Overview
          </Typography>
          <div style={{ width: '100%', height: 300 ,position:"relative"}}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={monthlyData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                style={{ overflowX: 'auto', overflowY: 'hidden' }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis width={50} />
                <Tooltip />
                <Legend />
                <Bar dataKey="eb" stackId="a" fill="#5976A9" name="EB Consumption" opacity="90%" />
                <Bar dataKey="genset" stackId="a" fill="#79bf92" name="Genset Consumption" opacity="90%" />
              </BarChart>
            </ResponsiveContainer>

            <IconButton
                  onClick={() => setOpenModal(true)}
                  title="Expand Chart"
                  style={{
                    position: "absolute",
                    bottom:-30,
                    right: -20,
                    backgroundColor: "#fff",
                    // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
                    zIndex: 1, // optional, ensures it appears above chart
                  }}
                >
              <ZoomOutMapIcon />
            </IconButton>
          </div>
        </CardContent>
      )}
    </Card>

      <Modal open={openModal} onClose={() => setOpenModal(false)}>
                     <div style={{
                       position: 'absolute',
                       top: '50%',
                       left: '50%',
                       transform: 'translate(-50%, -50%)',
                       background: 'white',
                       padding: 20,
                       borderRadius: 10,
                       outline: 'none',
                       width: '90%',
                       height: '90%',
                       overflow: 'auto'
                     }}>
                     <Typography gutterBottom className={Styles.liveEnergyDashboardCard} style={{marginTop:"15px"}}>
                      Monthly Consumption Overview
                    </Typography>
                    <div style={{ width: '100%', height: 300 ,position:"relative"}}>
                      <ResponsiveContainer width="100%" height={500}>
                        <BarChart
                          data={monthlyData}
                          width={500}
                          height={450}
                          margin={{ top: 30, right: 30, left: 30, bottom: 0 }}
                          // margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                          style={{ overflowX: 'auto', overflowY: 'hidden' }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis width={50}/>
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="eb" stackId="a" fill="#5976A9" name="EB Consumption" opacity="90%" />
                          <Bar dataKey="genset" stackId="a" fill="#79bf92" name="Genset Consumption" opacity="90%" />
                        </BarChart>
                      </ResponsiveContainer>

                       <IconButton
                          onClick={() => setOpenModal(false)}
                          title="Close"
                          style={{
                            position: "absolute",
                            bottom:315,
                            right: -20,
                            backgroundColor: "#fff",
                            // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
                            zIndex: 1, // optional, ensures it appears above chart
                          }}
                        >
                            <CloseRoundedIcon style={{fontSize:"30"}}/>
                        </IconButton>
                    </div>
                      
                     </div>
      </Modal>
    </>
  );
}

export default MonthlyChart;
