import React, { useState, useEffect, useCallback } from "react";
import {
  Save,
  X,
  BarChart3,
  
} from "lucide-react";
import styles from "./powerDashboard.module.css" 
import {
  fetchDashboards,
  createDashboard,
  updateDashboard,
  filterDashboards,

} from "./powerDash-Methods"; // your existing API functions
export const API_BASE_URL = "/dashBoards/powerbiDashboard";

// ----------------------------
// DashboardViewer Component
// ----------------------------
const DashboardViewer = ({ dashboard }) => {
  if (!dashboard) {
    return (
      <div className={styles.dashboardEmpty}>
        <BarChart3 className={styles.emptyIcon} />
        <h2 className={styles.emptyTitle}>No Dashboard Selected</h2>
        <p className={styles.emptyText}>
          Select a dashboard from the dropdown above to view it
        </p>
      </div>
    );
  }

  return (
    <div className={styles.dashboardContainer}>
      <div className={styles.dashboardHeader}>
        <div className={styles.dashboardInfo}>
          <BarChart3 className={styles.dashboardIcon} />
          <div>
            <h2 className={styles.dashboardTitle}>{dashboard.name}</h2>
            {dashboard.description && (
              <p className={styles.dashboardDescription}>
                {dashboard.description}
              </p>
            )}
          </div>
        </div>
       
      </div>
      <div className={styles.iframeContainer}>
        <iframe
          title={dashboard.name}
          width="100%"
          height="600"
          src={dashboard.embedUrl}
          allow="fullscreen; clipboard-write; encrypted-media; picture-in-picture"
          frameBorder="0"
          allowFullScreen={true}
          className={styles.dashboardIframe}
        />
      </div>
    </div>
  );
};

// ----------------------------
// Modal Component
// ----------------------------
const Modal = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.modalContent}>
        <div className={styles.modalHeader}>
          <h3 className={styles.modalTitle}>{title}</h3>
          <button onClick={onClose} className={styles.modalClose}>
            <X className={styles.closeIcon} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
};

// ----------------------------
// DashboardForm Component
// ----------------------------
const DashboardForm = ({ dashboard, onSave, onCancel, isEditing }) => {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    embedUrl: "",
    reportId: "",
    category: "General",
    isActive: true,
  });

  useEffect(() => {
    if (dashboard && isEditing) {
      setFormData({
        name: dashboard.name || "",
        description: dashboard.description || "",
        embedUrl: dashboard.embedUrl || "",
        reportId: dashboard.reportId || "",
        category: dashboard.category || "General",
        isActive:
          dashboard.isActive !== undefined ? dashboard.isActive : true,
      });
    }
  }, [dashboard, isEditing]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = () => {
    if (!formData.name.trim() || !formData.embedUrl.trim()) {
      alert("Dashboard name and embed URL are required");
      return;
    }
    onSave(formData);
  };

  return (
    <div className={styles.formContainer}>
      <div className={styles.formGroup}>
        <label className={styles.formLabel}>Dashboard Name *</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
          placeholder="e.g., Gas Plant Analysis Dashboard"
          className={styles.formInput}
        />
      </div>

      <div className={styles.formGroup}>
        <label className={styles.formLabel}>Description</label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          placeholder="Brief description of what this dashboard shows..."
          rows={3}
          className={styles.formTextarea}
        />
      </div>

      <div className={styles.formGroup}>
        <label className={styles.formLabel}>Embed URL *</label>
        <input
          type="url"
          name="embedUrl"
          value={formData.embedUrl}
          onChange={handleInputChange}
          placeholder="https://app.powerbi.com/reportEmbed?reportId=..."
          className={styles.formInput}
        />
        <p className={styles.formHint}>Copy the embed URL from PowerBI</p>
      </div>

      <div className={styles.checkboxGroup}>
        <input
          type="checkbox"
          name="isActive"
          id="isActive"
          checked={formData.isActive}
          onChange={handleInputChange}
          className={styles.formCheckbox}
        />
        <label htmlFor="isActive" className={styles.checkboxLabel}>
          Active Dashboard
        </label>
      </div>

      <div className={styles.formActions}>
        <button
          onClick={handleSubmit}
          className={styles.btnPrimary}
        >
          <Save className={styles.btnIcon} />
          {isEditing ? "Update Dashboard" : "Save Dashboard"}
        </button>
        <button onClick={onCancel} className={styles.btnSecondary}>
          Cancel
        </button>
      </div>
    </div>
  );
};

// ----------------------------
// DashboardManager Component
// ----------------------------
const DashboardManager = () => {
  const [dashboards, setDashboards] = useState([]);
  const [selectedDashboard, setSelectedDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [editingDashboard, setEditingDashboard] = useState(null);

  const fetchDashboardsHandler = useCallback(() => {
    fetchDashboards({
      setLoading,
      setDashboards,
      dashboards: [],
      selectedDashboard: null,
      setSelectedDashboard,
      setError,
    });
  }, [setLoading, setDashboards, setSelectedDashboard, setError]);

  useEffect(() => {
    fetchDashboardsHandler();
  }, [fetchDashboardsHandler]);

  const handleSave = (dashboardData) => {
    if (editingDashboard) {
      updateDashboard({
        dashboardData,
        editingDashboard,
        setError,
        fetchDashboards: fetchDashboardsHandler,
        setShowModal,
        setEditingDashboard,
      });
    } else {
      createDashboard({
        dashboardData,
        setError,
        fetchDashboards: fetchDashboardsHandler,
        setShowModal,
      });
    }
  };

  // const filteredDashboards = filterDashboards(dashboards);

  if (loading) {
    return (
      <div className={styles.loadingContainer}>
        <div className={styles.loadingSpinner}></div>
      </div>
    );
  }

  return (
    <div className={styles.appContainer}>
      <div className={styles.mainContent}>
        <div className={styles.pageHeader}>
          {/* <h1 className={styles.pageTitle}>Dashboard Manager</h1> */}
          
        </div>

       

        <div className={styles.selectorContainer}>
          <div className={styles.selectorContent}>
            <div className={styles.selectorInput}>
              <label className={styles.selectorLabel}>Select Dashboard</label>
              <select
                value={selectedDashboard?._id || ""}
                onChange={(e) => {
                  const dashboard = dashboards.find(
                    (d) => d._id === e.target.value
                  );
                  setSelectedDashboard(dashboard);
                }}
                className={styles.selectorDropdown}
              >
                <option value="">Choose a dashboard...</option>
                {dashboards.map((dashboard) => (
                  <option key={dashboard._id} value={dashboard._id}>
                    {dashboard.name} {dashboard.category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <DashboardViewer dashboard={selectedDashboard} />

        {dashboards.length === 0 && (
          <div className={styles.emptyState}>
            <BarChart3 className={styles.emptyStateIcon} />
            <h3 className={styles.emptyStateTitle}>No dashboards found</h3>
            <p className={styles.emptyStateText}>
              {dashboards.length === 0
                ? "Get started by adding your first dashboard."
                : "Try adjusting your search or filter criteria."}
            </p>
          </div>
        )}
      </div>

      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingDashboard(null);
        }}
        title={editingDashboard ? "Edit Dashboard" : "Add New Dashboard"}
      >
        <DashboardForm
          dashboard={editingDashboard}
          onSave={handleSave}
          onCancel={() => {
            setShowModal(false);
            setEditingDashboard(null);
          }}
          isEditing={!!editingDashboard}
        />
      </Modal>
    </div>
  );
};

export default DashboardManager;
