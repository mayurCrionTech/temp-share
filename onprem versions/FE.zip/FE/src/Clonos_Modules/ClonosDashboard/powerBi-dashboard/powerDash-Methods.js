// src/Clonos_Modules/ClonosDashboard/powerBi-dashboard/powerDash-Methods.js

import { doGetApiCall } from '../../../utils/ClonosApi';
import AppUrl from '../../../utils/AppUrl';
import { API_BASE_URL } from './powerDashBoard'

export const fetchDashboards = async ({
  setLoading,
  setDashboards,
  dashboards,
  selectedDashboard,
  setSelectedDashboard,
  setError,
}) => {
  try {
    setLoading(true);
    const url = AppUrl.getPowerBiDashboard;
    const res = await doGetApiCall({ url });


    if (res?.data?.result) {
      setDashboards(res.data.result);
    } else {
      setDashboards([]);
    }

    if (!selectedDashboard && dashboards.length > 0) {
      const firstActive = dashboards.find(d => d.isActive) || dashboards[0];
      setSelectedDashboard(firstActive);
    }
  } catch (err) {
    setError(err.message);
  } finally {
    setLoading(false);
  }
};

export const createDashboard = async ({
  dashboardData,
  setError,
  fetchDashboards,
  setShowModal,
}) => {
  try {
    const response = await fetch(`${API_BASE_URL}/dashboards`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dashboardData),
    });
    if (!response.ok) throw new Error('Failed to create dashboard');
    await fetchDashboards();
    setShowModal(false);
  } catch (err) {
    setError(err.message);
  }
};

export const updateDashboard = async ({
  dashboardData,
  editingDashboard,
  setError,
  fetchDashboards,
  setShowModal,
  setEditingDashboard,
}) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/dashboards/${editingDashboard._id}`,
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dashboardData),
      }
    );
    if (!response.ok) throw new Error('Failed to update dashboard');
    await fetchDashboards();
    setShowModal(false);
    setEditingDashboard(null);
  } catch (err) {
    setError(err.message);
  }
};

export const deleteDashboard = async ({
  id,
  selectedDashboard,
  setSelectedDashboard,
  setError,
  fetchDashboards,
}) => {
  if (!window.confirm('Are you sure you want to delete this dashboard?')) return;

  try {
    const response = await fetch(`${API_BASE_URL}/dashboards/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete dashboard');

    if (selectedDashboard && selectedDashboard._id === id) {
      setSelectedDashboard(null);
    }

    await fetchDashboards();
  } catch (err) {
    setError(err.message);
  }
};

export const filterDashboards = (
  dashboards,
  searchTerm,
  filterCategory,
  showInactive
) => {
  return dashboards.filter(dashboard => {
    const matchesSearch =
      dashboard.name.includes(searchTerm) ||
      dashboard.description?.includes(searchTerm);
    const matchesCategory =
      filterCategory === 'all' || dashboard.category === filterCategory;
    const matchesActiveFilter =
      showInactive || dashboard.isActive;
    return matchesSearch && matchesCategory && matchesActiveFilter;
  });
};
