

//last working code  wirh only view overview hit when first render  
// import React, { useState, useEffect, useRef, useCallback } from 'react';
// import styles from './analyticsDashboard.module.css';
// import { doGetApiCall } from '../../../../utils/ClonosApi';
// import AppUrl from '../../../../utils/AppUrl';

// /* Helper to convert UTC ISO string to readable local time (HH:mm:ss) */
// export const formatTimeToLocal = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toTimeString().slice(0, 8);
//   } catch {
//     return isoString.includes('T') ? isoString.split('T')[1].slice(0, 8) : isoString;
//   }
// };

// /* Helper to extract YYYY-MM-DD from an ISO string */
// export const formatDateString = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toISOString().slice(0, 10);
//   } catch {
//     return String(isoString).slice(0, 10);
//   }
// };

// /* Helper to safely format range whether it is an Object or a String */
// export const formatRangeDisplay = (range, fallbackUnit = '') => {
//   if (!range) return '—';

//   if (typeof range === 'object') {
//     const min = range.min;
//     const max = range.max;
//     const unit = range.unit || fallbackUnit || '';

//     const hasMin = min !== undefined && min !== null && min !== -Infinity;
//     const hasMax = max !== undefined && max !== null && max !== Infinity;

//     if (hasMin && hasMax) return `${min} - ${max} ${unit}`.trim();
//     if (hasMin) return `> ${min} ${unit}`.trim();
//     if (hasMax) return `< ${max} ${unit}`.trim();
//     return '—';
//   }

//   return `${range} ${fallbackUnit || ''}`.trim();
// };

// export default function AnalyticsDashboard() {
//   /* Search & Filter Controls */
//   const [mode, setMode] = useState('cabin'); // 'hanger' | 'skid' | 'cabin'
//   const [searchInput, setSearchInput] = useState('');
//   const [dateMode, setDateMode] = useState('single');
//   const [singleDate, setSingleDate] = useState('2026-08-13');
//   const [fromDate, setFromDate] = useState('2026-08-13');
//   const [toDate, setToDate] = useState('2026-08-13');

//   /* Live API State */
//   const [cabins, setCabins] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   /* Vehicle Selection & Journey States (Empty on initial render) */
//   const [selectedCabin, setSelectedCabin] = useState(null);
//   const [journeyLoading, setJourneyLoading] = useState(false);
//   const [selectedStageIdx, setSelectedStageIdx] = useState(null);

//   /* Stage Readings API State */
//   const [stageReadingsData, setStageReadingsData] = useState(null);
//   const [stageLoading, setStageLoading] = useState(false);

//   const [isDownloadMenuOpen, setIsDownloadMenuOpen] = useState(false);
//   const downloadWrapRef = useRef(null);

//   useEffect(() => {
//     function handleClickOutside(e) {
//       if (downloadWrapRef.current && !downloadWrapRef.current.contains(e.target)) {
//         setIsDownloadMenuOpen(false);
//       }
//     }
//     document.addEventListener('click', handleClickOutside);
//     return () => document.removeEventListener('click', handleClickOutside);
//   }, []);

//   /**
//    * Normalizer for Vehicle list items
//    */
//   const normalizeVehicleItem = (item) => {
//     const cabin = item.cabinNumber || item.cabin || '—';
//     const hanger = item.hanger || '—';
//     const skid = item.skid !== undefined && item.skid !== null ? String(item.skid) : '—';
//     const type = item.type || item.bodyType || '—';
//     const colour = item.colour || item.color || '—';
//     const passKey = item.passKey || `${cabin}|${skid}`;

//     const rawEntry = item.firstEntryTime || item.firstEntry || item.entryTime || item.entry || item.createdAt;
//     const rawExit = item.lastExitTime || item.lastExit || item.exitTime || item.exit;

//     const date = formatDateString(rawEntry || item.date);
//     const entry = formatTimeToLocal(rawEntry);
//     const exit = formatTimeToLocal(rawExit);

//     let totalDwellMinutes = 0;
//     if (rawEntry && rawExit) {
//       const diffMs = new Date(rawExit) - new Date(rawEntry);
//       if (diffMs > 0) {
//         totalDwellMinutes = Math.round(diffMs / (1000 * 60));
//       }
//     }

//     return {
//       ...item,
//       passKey,
//       cabin,
//       cabinNumber: cabin,
//       hanger,
//       skid,
//       type,
//       colour,
//       date,
//       entry,
//       exit,
//       totalDwell: totalDwellMinutes,
//       stagesSeen: item.stagesSeen ?? item.stages?.length ?? 0,
//       stages: item.stages || [],
//       devCount: item.devCount || 0,
//     };
//   };

//   /**
//    * Normalizer for individual stage objects inside result.lines.PT or result.lines.ED
//    */
//   const normalizeJourneyStage = (st, idx) => {
//     const stageId = st.stageId || st.id || st.code || `ST-${idx + 1}`;
//     const code = st.code || st.stageCode || stageId;
//     const name = st.name || st.stageName || 'Stage';
//     const group = st.group || (code.toUpperCase().startsWith('ED') ? 'ED' : 'PT');

//     const tagCount = st.tagCount !== undefined
//       ? st.tagCount
//       : (st.readings?.length ?? st.tags?.length ?? 0);

//     let dwellMinutes = 0;
//     if (st.dwellSeconds !== undefined && st.dwellSeconds !== null) {
//       dwellMinutes = Math.round(st.dwellSeconds / 60);
//     } else if (st.dwell) {
//       dwellMinutes = st.dwell;
//     } else if (st.entryTime && st.exitTime) {
//       const diff = new Date(st.exitTime) - new Date(st.entryTime);
//       if (diff > 0) dwellMinutes = Math.round(diff / 60000);
//     }

//     return {
//       ...st,
//       stageId,
//       code,
//       name,
//       group,
//       tagCount,
//       dwell: dwellMinutes,
//       entryTime: formatTimeToLocal(st.entryTime),
//       exitTime: formatTimeToLocal(st.exitTime),
//       rawEntryTime: st.entryTime,
//       rawExitTime: st.exitTime,
//     };
//   };

//   /**
//    * 3. STAGE READINGS API: Triggered only when a user clicks a stage node
//    * GET /tags/dashboard/analytics/stage-readings?cabinNumber=...&skid=...&stageId=...
//    */
//   const fetchStageReadings = useCallback(async (cabinNumber, skid, stageId) => {
//     if (!cabinNumber || cabinNumber === '—' || !stageId) return;

//     setStageLoading(true);
//     try {
//       const readingsEndpoint =
//         AppUrl?.getAnalyticsStageReadings ||
//         AppUrl?.analyticsStageReadings ||
//         '/tags/dashboard/analytics/stage-readings';

//       const params = {
//         cabinNumber,
//         skid,
//         stageId,
//       };

//       const res = await doGetApiCall({
//         url: readingsEndpoint,
//         params,
//       });

//       console.log(res, 'stageReadingsApiResponse');

//       const responseData = res?.data?.result ?? res?.data;
//       setStageReadingsData(responseData);
//     } catch (err) {
//       console.error('Failed to fetch stage readings:', err);
//       setStageReadingsData(null);
//     } finally {
//       setStageLoading(false);
//     }
//   }, []);

//   /**
//    * 2. JOURNEY API: Triggered only when a card is clicked
//    * GET /tags/dashboard/analytics/journey?cabinNumber=...&skid=...&includeStatus=true
//    */
//   const fetchVehicleJourney = useCallback(async (cabinObj) => {
//     if (!cabinObj || !cabinObj.cabinNumber || cabinObj.cabinNumber === '—') return;

//     setJourneyLoading(true);
//     setStageReadingsData(null);
//     setSelectedStageIdx(null); // Clear selected stage on new journey load

//     try {
//       const journeyEndpoint =
//         AppUrl?.getAnalyticsJourney ||
//         AppUrl?.analyticsJourney ||
//         '/tags/dashboard/analytics/journey';

//       const params = {
//         cabinNumber: cabinObj.cabinNumber,
//         skid: cabinObj.skid,
//         includeStatus: true,
//       };

//       const res = await doGetApiCall({
//         url: journeyEndpoint,
//         params,
//       });

//       console.log(res, 'journeyApiResponse');

//       const result = res?.data?.result;
//       const lines = result?.lines || {};

//       const ptList = Array.isArray(lines.PT)
//         ? lines.PT.map((st, idx) => normalizeJourneyStage({ ...st, group: 'PT' }, idx))
//         : [];
//       const edList = Array.isArray(lines.ED)
//         ? lines.ED.map((st, idx) => normalizeJourneyStage({ ...st, group: 'ED' }, idx))
//         : [];

//       const allStages = [...ptList, ...edList];

//       setSelectedCabin((prev) => {
//         if (!prev) return prev;
//         return {
//           ...prev,
//           hanger: result?.vehicle?.hanger || prev.hanger,
//           type: result?.vehicle?.type || prev.type,
//           colour: result?.vehicle?.colour || prev.colour,
//           entry: formatTimeToLocal(result?.firstEntryTime) || prev.entry,
//           exit: formatTimeToLocal(result?.lastExitTime) || prev.exit,
//           stages: allStages,
//         };
//       });

//       setCabins((prev) =>
//         prev.map((c) =>
//           c.cabinNumber === cabinObj.cabinNumber && String(c.skid) === String(cabinObj.skid)
//             ? { ...c, stages: allStages }
//             : c
//         )
//       );
//     } catch (err) {
//       console.error('Failed to fetch vehicle journey:', err);
//     } finally {
//       setJourneyLoading(false);
//     }
//   }, []);

//   /**
//    * Card Selection Handler: User clicks a vehicle card
//    */
//   const handleSelectCabin = (cabin) => {
//     const normalized = normalizeVehicleItem(cabin);
//     setSelectedCabin(normalized);
//     setSelectedStageIdx(null);
//     setStageReadingsData(null);
//     fetchVehicleJourney(normalized);
//   };

//   /**
//    * Stage Node Click Handler: User clicks a stage on the rail
//    */
//   const handleStageClick = (originalIdx, stageId) => {
//     setSelectedStageIdx(originalIdx);
//     if (selectedCabin) {
//       fetchStageReadings(selectedCabin.cabinNumber, selectedCabin.skid, stageId);
//     }
//   };

//   /**
//    * 1. INITIAL API: Only calls overview on page render
//    */
//   const fetchOverviewAnalyticsData = useCallback(async () => {
//     setLoading(true);
//     setError(null);
//     setSelectedCabin(null);
//     setSelectedStageIdx(null);
//     setStageReadingsData(null);

//     try {
//       const res = await doGetApiCall({ url: AppUrl?.getOverviewAnalytics });
//       console.log(res, 'overviewRes (Initial Load Only)');

//       const responseData = res?.data?.result;
//       const rawList = Array.isArray(responseData?.results)
//         ? responseData.results
//         : Array.isArray(res?.data?.results)
//         ? res.data.results
//         : Array.isArray(responseData)
//         ? responseData
//         : Array.isArray(res?.data)
//         ? res.data
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);
//       // NOTE: No auto-select or auto-journey call here; waiting for user click
//     } catch (err) {
//       console.error('Failed to fetch initial overview:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to load initial overview records');
//     } finally {
//       setLoading(false);
//     }
//   }, []);

//   useEffect(() => {
//     fetchOverviewAnalyticsData();
//   }, [fetchOverviewAnalyticsData]);

//   /**
//    * SEARCH API: Triggered when user enters value & clicks Search
//    */
//   const handleSearch = async () => {
//     const val = searchInput.trim();
//     if (!val) {
//       fetchOverviewAnalyticsData();
//       return;
//     }

//     setLoading(true);
//     setError(null);
//     setSelectedCabin(null);
//     setSelectedStageIdx(null);
//     setStageReadingsData(null);

//     try {
//       let fromIso = '';
//       let toIso = '';

//       if (dateMode === 'single') {
//         const d = singleDate || '2026-08-13';
//         fromIso = `${d}T00:00:00.000Z`;
//         toIso = `${d}T23:59:59.999Z`;
//       } else {
//         const f = fromDate || '2026-08-13';
//         const t = toDate || fromDate || '2026-08-13';
//         const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
//         fromIso = `${sortedFrom}T00:00:00.000Z`;
//         toIso = `${sortedTo}T23:59:59.999Z`;
//       }

//       const params = {
//         searchBy: mode,
//         value: val,
//         from: fromIso,
//         to: toIso,
//       };

//       const searchEndpoint =
//         AppUrl?.getAnalyticsSearch ||
//         AppUrl?.analyticsSearch ||
//         '/tags/dashboard/analytics/search';

//       const res = await doGetApiCall({
//         url: searchEndpoint,
//         params,
//       });

//       console.log(res, 'searchApiResponse');

//       const rawData = res?.data?.result ?? res?.data?.results ?? res?.data;
//       const rawList = Array.isArray(rawData)
//         ? rawData
//         : rawData?.results && Array.isArray(rawData.results)
//         ? rawData.results
//         : rawData && typeof rawData === 'object' && rawData.cabinNumber
//         ? [rawData]
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);
//     } catch (err) {
//       console.error('Vehicle search error:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to search vehicles');
//       setCabins([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const activeStage = selectedStageIdx !== null && selectedCabin?.stages ? selectedCabin.stages[selectedStageIdx] : null;
//   const totalDwell =
//     selectedCabin?.totalDwell ??
//     (selectedCabin?.stages?.reduce((acc, cur) => acc + (cur.dwell || 0), 0) || 0);

//   /**
//    * Conveyor rail group renderer
//    */
//   const renderConveyorRail = (groupName) => {
//     if (!selectedCabin || !selectedCabin.stages || selectedCabin.stages.length === 0) return null;
//     const stagesInGroup = selectedCabin.stages
//       .map((stage, idx) => ({ ...stage, originalIdx: idx }))
//       .filter((s) => s.group === groupName);

//     if (stagesInGroup.length === 0) return null;

//     return (
//       <div className={styles['rail-wrap']}>
//         <div className={styles['rail-track']}>
//           <div className={styles['rail-line']} />
//           {stagesInGroup.map((s) => (
//             <div
//               key={s.stageId || s.code}
//               className={`${styles['rail-stage']} ${
//                 s.originalIdx === selectedStageIdx ? styles.active : ''
//               }`}
//               onClick={() => handleStageClick(s.originalIdx, s.stageId)}
//             >
//               <div className={styles['rail-node']}>{s.code}</div>
//               <div className={styles['rail-name']}>{s.name}</div>
//               <div className={styles['rail-dwell']}>
//                 {s.entryTime ? `${s.entryTime.slice(0, 5)}–${(s.exitTime || '').slice(0, 5)}` : '—'}
//               </div>
//               <div className={styles['rail-count']}>
//                 {s.tagCount > 0 ? `${s.tagCount} tags` : 'no tags'}
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     );
//   };

//   return (
//     <div className={styles.pageContainer}>
//       <div className={styles.mainCard}>
//         {/* Header Bar */}
//         <header className={styles.topbar}>
//           <div className={styles.brand}>
//             <div>
//               <div className={styles['brand-text']}>PAINT SHOP DIGITAL TWIN</div>
//               <div className={styles['brand-sub']}>Stage Wise · PT / ED Line</div>
//             </div>
//           </div>

//           <div className={styles['search-row']}>
//             {/* Pill Toggle for Mode */}
//             <div className={styles.pillContainer}>
//               {[
//                 { key: 'hanger', label: 'Hanger' },
//                 { key: 'skid', label: 'Skid' },
//                 { key: 'cabin', label: 'Cabin' },
//               ].map(({ key, label }) => (
//                 <button
//                   key={key}
//                   type="button"
//                   className={`${styles.pillButton} ${mode === key ? styles.pillActive : ''}`}
//                   onClick={() => {
//                     setMode(key);
//                     setSearchInput('');
//                   }}
//                 >
//                   {label}
//                 </button>
//               ))}
//             </div>

//             {/* Rectangular Search Field */}
//             <div className={styles.field}>
//               <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <circle cx="11" cy="11" r="7" />
//                 <path d="M21 21l-4.3-4.3" />
//               </svg>
//               <input
//                 type="text"
//                 placeholder={`Search ${mode}...`}
//                 value={searchInput}
//                 onChange={(e) => setSearchInput(e.target.value)}
//                 onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
//               />
//             </div>

//             {/* Pill Toggle for Date Mode */}
//             <div className={styles.pillContainer}>
//               {[
//                 { key: 'single', label: 'Single Day' },
//                 { key: 'range', label: 'Date Range' },
//               ].map(({ key, label }) => (
//                 <button
//                   key={key}
//                   type="button"
//                   className={`${styles.pillButton} ${dateMode === key ? styles.pillActive : ''}`}
//                   onClick={() => setDateMode(key)}
//                 >
//                   {label}
//                 </button>
//               ))}
//             </div>

//             {/* Rectangular Date Box */}
//             <div className={styles['unified-date-box']}>
//               <svg className={styles['calendar-icon']} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <rect x="3" y="5" width="18" height="16" rx="2" />
//                 <path d="M3 10h18M8 3v4M16 3v4" />
//               </svg>

//               {dateMode === 'single' ? (
//                 <input
//                   type="date"
//                   className={styles['bare-date-input']}
//                   value={singleDate}
//                   onChange={(e) => setSingleDate(e.target.value)}
//                 />
//               ) : (
//                 <div className={styles['range-inputs-container']}>
//                   <input
//                     type="date"
//                     className={styles['bare-date-input']}
//                     value={fromDate}
//                     onChange={(e) => setFromDate(e.target.value)}
//                   />
//                   <span className={styles['range-arrow']}>→</span>
//                   <input
//                     type="date"
//                     className={styles['bare-date-input']}
//                     value={toDate}
//                     onChange={(e) => setToDate(e.target.value)}
//                   />
//                 </div>
//               )}
//             </div>

//             {/* Search Trigger Button */}
//             <button
//               type="button"
//               className={`${styles.btn} ${styles['btn-search']}`}
//               onClick={handleSearch}
//             >
//               Search
//             </button>
//           </div>

//           {/* Download Dropdown */}
//           <div className={styles['download-wrap']} ref={downloadWrapRef}>
//             <button
//               className={`${styles.btn} ${styles['btn-download']}`}
//               type="button"
//               onClick={() => setIsDownloadMenuOpen((prev) => !prev)}
//             >
//               <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <path d="M12 3v13m0 0l-4-4m4 4l4-4M4 21h16" />
//               </svg>
//               Download
//               <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
//                 <path d="M6 9l6 6 6-6" />
//               </svg>
//             </button>

//             <div className={`${styles['download-menu']} ${isDownloadMenuOpen ? styles.open : ''}`}>
//               <button className={styles['dm-item']} type="button" disabled={cabins.length === 0}>
//                 <div className={`${styles['dm-item-icon']} ${styles.corr}`}>⇄</div>
//                 <div>
//                   <div className={styles['dm-item-title']}>Correlation Report</div>
//                   <div className={styles['dm-item-sub']}>Vehicle, Hanger, Skid mapping across selected dates</div>
//                 </div>
//               </button>

//               <button className={styles['dm-item']} type="button" disabled={!selectedCabin}>
//                 <div className={`${styles['dm-item-icon']} ${styles.proc}`}>≣</div>
//                 <div>
//                   <div className={styles['dm-item-title']}>Process Report</div>
//                   <div className={styles['dm-item-sub']}>
//                     {selectedCabin ? `All tag readings for ${selectedCabin.cabin}` : 'Select a cabin on the left first'}
//                   </div>
//                 </div>
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* Workspace */}
//         <main className={styles.workspace}>
//           {/* Left Occurrences Pane */}
//           <section className={styles['results-pane']}>
//             <div className={styles['results-header']}>
//               <h2>{mode} occurrences</h2>
//               <span className={styles['results-count']}>
//                 {loading ? 'Loading...' : `${cabins.length} records`}
//               </span>
//             </div>
//             <div className={styles['results-list']}>
//               {loading ? (
//                 <div className={styles['empty-list']}>Fetching overview data...</div>
//               ) : error ? (
//                 <div className={styles['empty-list']} style={{ color: 'var(--danger)' }}>
//                   {error}
//                 </div>
//               ) : cabins.length === 0 ? (
//                 <div className={styles['empty-list']}>
//                   No vehicles found.<br />Try adjusting your search criteria.
//                 </div>
//               ) : (
//                 cabins.map((c, index) => {
//                   const isSelected = selectedCabin?.passKey === c.passKey;
//                   return (
//                     <div
//                       key={c.passKey || `${c.cabin}-${index}`}
//                       className={`${styles['result-card']} ${isSelected ? styles.selected : ''}`}
//                       onClick={() => handleSelectCabin(c)}
//                     >
//                       <div className={styles['rc-top']}>
//                         <span className={styles['rc-id']}>{c.cabin}</span>
//                         <span className={`${styles['rc-dot']} ${styles.ok}`} />
//                       </div>
//                       <div className={styles['rc-meta']}>
//                         {mode === 'hanger' && <span className={styles.mono}>Skid <b>{c.skid}</b></span>}
//                         {mode === 'skid' && <span className={styles.mono}>Hanger <b>{c.hanger}</b></span>}
//                         {mode === 'cabin' && <span className={styles.mono}>{c.hanger} / {c.skid}</span>}
//                         <span>{c.colour}</span>
//                         <span>{c.type}</span>
//                       </div>
//                       <div className={styles['rc-time']}>
//                         {c.date || '—'} {c.entry ? `· in ${c.entry}` : ''}
//                       </div>
//                     </div>
//                   );
//                 })
//               )}
//             </div>
//           </section>

//           {/* Right Detail Pane */}
//           <section className={styles['detail-pane']}>
//             {!selectedCabin ? (
//               <div className={styles['detail-placeholder']}>
//                 <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
//                   <circle cx="11" cy="11" r="7" />
//                   <path d="M21 21l-4.3-4.3" />
//                 </svg>
//                 <div className={styles['ph-title']}>Select a record to view its journey</div>
//                 <div className={styles['ph-sub']}>
//                   Pick any vehicle from the list on the left to load its stage timeline and inspect process readings.
//                 </div>
//               </div>
//             ) : (
//               <>
//                 <div className={styles['detail-header']}>
//                   <div>
//                     <div className={styles['dh-id']}>{selectedCabin.cabin}</div>
//                     <div className={styles['dh-tags']}>
//                       <span className={styles['dh-tag']}>Hanger <b>{selectedCabin.hanger || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Skid <b>{selectedCabin.skid || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Type <b>{selectedCabin.type || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Colour <b>{selectedCabin.colour || '—'}</b></span>
//                       <span className={styles['dh-tag']}>
//                         Entry <b>{selectedCabin.entry || '—'}</b> {selectedCabin.date ? `· ${selectedCabin.date}` : ''}
//                       </span>
//                     </div>
//                   </div>
//                   <div className={styles['dh-stats']}>
//                     <div className={styles['dh-stat']}>
//                       <div className={styles.num}>{totalDwell}m</div>
//                       <div className={styles.lbl}>Total time</div>
//                     </div>
//                     <div className={styles['dh-stat']}>
//                       <div className={styles.num}>{selectedCabin.stages?.length || selectedCabin.stagesSeen || 0}</div>
//                       <div className={styles.lbl}>Stages Seen</div>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Conveyor Rail Stage Tracks */}
//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — PT (Pre-Treatment)</div>
//                   {journeyLoading ? (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '12px 0' }}>
//                       Loading journey stages for {selectedCabin.cabin}...
//                     </div>
//                   ) : renderConveyorRail('PT') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No PT stages recorded for this vehicle.
//                     </div>
//                   )}
//                 </div>

//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — ED (Electro-Deposition)</div>
//                   {!journeyLoading && (renderConveyorRail('ED') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No ED stages recorded for this vehicle.
//                     </div>
//                   ))}
//                 </div>

//                 {/* Stage process tags */}
//                 {selectedStageIdx === null ? (
//                   <div style={{ padding: '24px 0', color: 'var(--text-faint)', fontSize: '12.5px', textAlign: 'center' }}>
//                     Click any stage above on the conveyor rail to inspect its process tags.
//                   </div>
//                 ) : activeStage && (
//                   <div className={styles['param-section']}>
//                     <div className={styles['section-label']}>
//                       Process tags — {stageReadingsData?.name || activeStage.name}
//                     </div>
//                     <div className={styles['param-panel']}>
//                       <div className={styles['param-panel-head']}>
//                         <div>
//                           <div className={styles['pph-title']}>
//                             {stageReadingsData?.stageId || activeStage.code} — {stageReadingsData?.name || activeStage.name}
//                           </div>
//                           <div className={styles['pph-sub']}>
//                             {stageReadingsData?.window?.entryTime
//                               ? `${formatTimeToLocal(stageReadingsData.window.entryTime)} → ${formatTimeToLocal(stageReadingsData.window.exitTime)}`
//                               : activeStage.entryTime
//                               ? `${activeStage.entryTime} → ${activeStage.exitTime || ''}`
//                               : ''}
//                           </div>
//                         </div>
//                         {stageReadingsData?.tags && stageReadingsData.tags.length > 0 && (
//                           <div className={styles['pph-counts']}>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'live').length} Live
//                             </span>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'log').length} Log
//                             </span>
//                           </div>
//                         )}
//                       </div>

//                       {stageLoading ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12px' }}>
//                           Loading tag readings...
//                         </div>
//                       ) : activeStage.code === 'PT-11' || activeStage.code === 'ED-8' ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           Manual visual inspection checkpoint. No PLC tag readings recorded for this stage.
//                         </div>
//                       ) : !stageReadingsData?.tags || stageReadingsData.tags.length === 0 ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           No process tags recorded for this stage.
//                         </div>
//                       ) : (
//                         <div style={{ overflowX: 'auto' }}>
//                           <table className={styles['param-table']}>
//                             <thead>
//                               <tr>
//                                 <th>Tag</th>
//                                 <th>Reference Range</th>
//                                 <th>Reading</th>
//                                 <th>Source</th>
//                                 <th>Process</th>
//                               </tr>
//                             </thead>
//                             <tbody>
//                               {stageReadingsData.tags.map((t, idx) => {
//                                 const hasData = t.status !== 'no_data' && ((t.avg !== null && t.avg !== undefined) || t.value !== undefined);
//                                 const displayValue = hasData
//                                   ? (t.value !== undefined ? t.value : t.avg)
//                                   : null;
//                                 const readingText = displayValue !== null ? `${displayValue} ${t.unit || ''}`.trim() : '—';
//                                 const isOutOfRange = t.status === 'out_of_range';

//                                 return (
//                                   <tr key={t.tagId ? `${t.tagId}-${idx}` : `${t.name}-${idx}`}>
//                                     <td>
//                                       <div className={styles['tag-name']}>{t.name || 'Unnamed Tag'}</div>
//                                       <div className={styles['tag-id']} title={t.tagId}>{t.tagId || '—'}</div>
//                                     </td>
//                                     <td>
//                                       <div className={styles['tag-range']}>
//                                         {formatRangeDisplay(t.range, t.unit)}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <div className={`${styles['tag-reading']} ${isOutOfRange ? styles.warn : styles.ok}`}>
//                                         {readingText}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <span className={`${styles.chip} ${styles['src-live']}`}>
//                                         {t.source || 'Live'}
//                                       </span>
//                                     </td>
//                                     <td>
//                                       {t.status === 'out_of_range' ? (
//                                         <span className={`${styles.chip} ${styles['dev-out']}`}>⚠ Out of range</span>
//                                       ) : t.status === 'within_range' ? (
//                                         <span className={`${styles.chip} ${styles['dev-in']}`}>In range</span>
//                                       ) : (
//                                         <span className={`${styles.chip} ${styles['src-none']}`}>No data</span>
//                                       )}
//                                     </td>
//                                   </tr>
//                                 );
//                               })}
//                             </tbody>
//                           </table>
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                 )}
//               </>
//             )}
//           </section>
//         </main>
//       </div>
//     </div>
//   );
// }
//last work code
// import React, { useState, useEffect, useRef, useCallback } from 'react';
// import styles from './analyticsDashboard.module.css';
// import { doGetApiCall } from '../../../../utils/ClonosApi';
// import AppUrl from '../../../../utils/AppUrl';

// /* Helper to convert UTC ISO string to readable local time (HH:mm:ss) */
// export const formatTimeToLocal = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toTimeString().slice(0, 8);
//   } catch {
//     return isoString.includes('T') ? isoString.split('T')[1].slice(0, 8) : isoString;
//   }
// };

// /* Helper to extract YYYY-MM-DD from an ISO string */
// export const formatDateString = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toISOString().slice(0, 10);
//   } catch {
//     return String(isoString).slice(0, 10);
//   }
// };

// /* Helper to safely format range whether it is an Object or a String */
// export const formatRangeDisplay = (range, fallbackUnit = '') => {
//   if (!range) return '—';

//   if (typeof range === 'object') {
//     const min = range.min;
//     const max = range.max;
//     const unit = range.unit || fallbackUnit || '';

//     const hasMin = min !== undefined && min !== null && min !== -Infinity;
//     const hasMax = max !== undefined && max !== null && max !== Infinity;

//     if (hasMin && hasMax) return `${min} - ${max} ${unit}`.trim();
//     if (hasMin) return `> ${min} ${unit}`.trim();
//     if (hasMax) return `< ${max} ${unit}`.trim();
//     return '—';
//   }

//   return `${range} ${fallbackUnit || ''}`.trim();
// };

// export default function AnalyticsDashboard() {
//   /* Search & Filter Controls */
//   const [mode, setMode] = useState('cabin'); // 'hanger' | 'skid' | 'cabin'
//   const [searchInput, setSearchInput] = useState('');
//   const [dateMode, setDateMode] = useState('single');
//   const [singleDate, setSingleDate] = useState('2026-08-13');
//   const [fromDate, setFromDate] = useState('2026-08-13');
//   const [toDate, setToDate] = useState('2026-08-13');

//   /* Live API State */
//   const [cabins, setCabins] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   /* Vehicle Selection & Journey States (Null on initial mount) */
//   const [selectedCabin, setSelectedCabin] = useState(null);
//   const [journeyLoading, setJourneyLoading] = useState(false);
//   const [selectedStageIdx, setSelectedStageIdx] = useState(0);

//   /* Stage Readings API State */
//   const [stageReadingsData, setStageReadingsData] = useState(null);
//   const [stageLoading, setStageLoading] = useState(false);

//   const [isDownloadMenuOpen, setIsDownloadMenuOpen] = useState(false);
//   const downloadWrapRef = useRef(null);

//   useEffect(() => {
//     function handleClickOutside(e) {
//       if (downloadWrapRef.current && !downloadWrapRef.current.contains(e.target)) {
//         setIsDownloadMenuOpen(false);
//       }
//     }
//     document.addEventListener('click', handleClickOutside);
//     return () => document.removeEventListener('click', handleClickOutside);
//   }, []);

//   /**
//    * Normalizer for Vehicle list items
//    */
//   const normalizeVehicleItem = (item) => {
//     const cabin = item.cabinNumber || item.cabin || '—';
//     const hanger = item.hanger || '—';
//     const skid = item.skid !== undefined && item.skid !== null ? String(item.skid) : '—';
//     const type = item.type || item.bodyType || '—';
//     const colour = item.colour || item.color || '—';
//     const passKey = item.passKey || `${cabin}|${skid}`;

//     const rawEntry = item.firstEntryTime || item.firstEntry || item.entryTime || item.entry || item.createdAt;
//     const rawExit = item.lastExitTime || item.lastExit || item.exitTime || item.exit;

//     const date = formatDateString(rawEntry || item.date);
//     const entry = formatTimeToLocal(rawEntry);
//     const exit = formatTimeToLocal(rawExit);

//     let totalDwellMinutes = 0;
//     if (rawEntry && rawExit) {
//       const diffMs = new Date(rawExit) - new Date(rawEntry);
//       if (diffMs > 0) {
//         totalDwellMinutes = Math.round(diffMs / (1000 * 60));
//       }
//     }

//     return {
//       ...item,
//       passKey,
//       cabin,
//       cabinNumber: cabin,
//       hanger,
//       skid,
//       type,
//       colour,
//       date,
//       entry,
//       exit,
//       totalDwell: totalDwellMinutes,
//       stagesSeen: item.stagesSeen ?? item.stages?.length ?? 0,
//       stages: item.stages || [],
//       devCount: item.devCount || 0,
//     };
//   };

//   /**
//    * Normalizer for individual stage objects inside result.lines.PT or result.lines.ED
//    */
//   const normalizeJourneyStage = (st, idx) => {
//     const stageId = st.stageId || st.id || st.code || `ST-${idx + 1}`;
//     const code = st.code || st.stageCode || stageId;
//     const name = st.name || st.stageName || 'Stage';
//     const group = st.group || (code.toUpperCase().startsWith('ED') ? 'ED' : 'PT');

//     const tagCount = st.tagCount !== undefined
//       ? st.tagCount
//       : (st.readings?.length ?? st.tags?.length ?? 0);

//     let dwellMinutes = 0;
//     if (st.dwellSeconds !== undefined && st.dwellSeconds !== null) {
//       dwellMinutes = Math.round(st.dwellSeconds / 60);
//     } else if (st.dwell) {
//       dwellMinutes = st.dwell;
//     } else if (st.entryTime && st.exitTime) {
//       const diff = new Date(st.exitTime) - new Date(st.entryTime);
//       if (diff > 0) dwellMinutes = Math.round(diff / 60000);
//     }

//     return {
//       ...st,
//       stageId,
//       code,
//       name,
//       group,
//       tagCount,
//       dwell: dwellMinutes,
//       entryTime: formatTimeToLocal(st.entryTime),
//       exitTime: formatTimeToLocal(st.exitTime),
//       rawEntryTime: st.entryTime,
//       rawExitTime: st.exitTime,
//     };
//   };

//   /**
//    * STAGE READINGS API: Triggered ONLY when a stage node is clicked or when a vehicle card is clicked
//    */
//   const fetchStageReadings = useCallback(async (cabinNumber, skid, stageId) => {
//     if (!cabinNumber || cabinNumber === '—' || !stageId) return;

//     setStageLoading(true);
//     try {
//       const readingsEndpoint =
//         AppUrl?.getAnalyticsStageReadings ||
//         AppUrl?.analyticsStageReadings ||
//         '/tags/dashboard/analytics/stage-readings';

//       const params = {
//         cabinNumber,
//         skid,
//         stageId,
//       };

//       const res = await doGetApiCall({
//         url: readingsEndpoint,
//         params,
//       });

//       console.log(res, 'stageReadingsApiResponse');

//       const responseData = res?.data?.result ?? res?.data;
//       setStageReadingsData(responseData);
//     } catch (err) {
//       console.error('Failed to fetch stage readings:', err);
//       setStageReadingsData(null);
//     } finally {
//       setStageLoading(false);
//     }
//   }, []);

//   /**
//    * JOURNEY API: Triggered ONLY when a card is clicked by the user
//    */
//   const fetchVehicleJourney = useCallback(async (cabinObj) => {
//     if (!cabinObj || !cabinObj.cabinNumber || cabinObj.cabinNumber === '—') return;

//     setJourneyLoading(true);
//     try {
//       const journeyEndpoint =
//         AppUrl?.getAnalyticsJourney ||
//         AppUrl?.analyticsJourney ||
//         '/tags/dashboard/analytics/journey';

//       const params = {
//         cabinNumber: cabinObj.cabinNumber,
//         skid: cabinObj.skid,
//         includeStatus: true,
//       };

//       const res = await doGetApiCall({
//         url: journeyEndpoint,
//         params,
//       });

//       console.log(res, 'journeyApiResponse');

//       const result = res?.data?.result;
//       const lines = result?.lines || {};

//       const ptList = Array.isArray(lines.PT)
//         ? lines.PT.map((st, idx) => normalizeJourneyStage({ ...st, group: 'PT' }, idx))
//         : [];
//       const edList = Array.isArray(lines.ED)
//         ? lines.ED.map((st, idx) => normalizeJourneyStage({ ...st, group: 'ED' }, idx))
//         : [];

//       const allStages = [...ptList, ...edList];

//       setSelectedCabin((prev) => {
//         if (!prev) return prev;
//         return {
//           ...prev,
//           hanger: result?.vehicle?.hanger || prev.hanger,
//           type: result?.vehicle?.type || prev.type,
//           colour: result?.vehicle?.colour || prev.colour,
//           entry: formatTimeToLocal(result?.firstEntryTime) || prev.entry,
//           exit: formatTimeToLocal(result?.lastExitTime) || prev.exit,
//           stages: allStages,
//         };
//       });

//       setCabins((prev) =>
//         prev.map((c) =>
//           c.cabinNumber === cabinObj.cabinNumber && String(c.skid) === String(cabinObj.skid)
//             ? { ...c, stages: allStages }
//             : c
//         )
//       );

//       setSelectedStageIdx(0);
//       // Fetch stage readings for the first stage of this vehicle
//       if (allStages.length > 0) {
//         fetchStageReadings(cabinObj.cabinNumber, cabinObj.skid, allStages[0].stageId);
//       }
//     } catch (err) {
//       console.error('Failed to fetch vehicle journey:', err);
//     } finally {
//       setJourneyLoading(false);
//     }
//   }, [fetchStageReadings]);

//   /**
//    * Card Selection Handler: User clicked a card
//    */
//   const handleSelectCabin = (cabin) => {
//     const normalized = normalizeVehicleItem(cabin);
//     setSelectedCabin(normalized);
//     setSelectedStageIdx(0);
//     setStageReadingsData(null);
//     fetchVehicleJourney(normalized);
//   };

//   /**
//    * Stage Node Click Handler: User clicked a stage on the conveyor
//    */
//   const handleStageClick = (originalIdx, stageId) => {
//     setSelectedStageIdx(originalIdx);
//     if (selectedCabin) {
//       fetchStageReadings(selectedCabin.cabinNumber, selectedCabin.skid, stageId);
//     }
//   };

//   /**
//    * 1. INITIAL API: ONLY Overview call runs on initial render
//    */
//   const fetchOverviewAnalyticsData = useCallback(async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const res = await doGetApiCall({ url: AppUrl?.getOverviewAnalytics });
//       console.log(res, 'overviewRes (Initial Load)');

//       const responseData = res?.data?.result;
//       const rawList = Array.isArray(responseData?.results)
//         ? responseData.results
//         : Array.isArray(res?.data?.results)
//         ? res.data.results
//         : Array.isArray(responseData)
//         ? responseData
//         : Array.isArray(res?.data)
//         ? res.data
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);

//       // Do NOT auto-select or call journey/stage APIs here
//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } catch (err) {
//       console.error('Failed to fetch initial overview:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to load initial overview records');
//     } finally {
//       setLoading(false);
//     }
//   }, []);

//   // Run only the overview on page mount
//   useEffect(() => {
//     fetchOverviewAnalyticsData();
//   }, [fetchOverviewAnalyticsData]);

//   /**
//    * 2. SEARCH API: User entered values and clicked Search
//    */
//   const handleSearch = async () => {
//     const val = searchInput.trim();
//     if (!val) {
//       fetchOverviewAnalyticsData();
//       return;
//     }

//     setLoading(true);
//     setError(null);
//     setSelectedCabin(null);
//     setStageReadingsData(null);

//     try {
//       let fromIso = '';
//       let toIso = '';

//       if (dateMode === 'single') {
//         const d = singleDate || '2026-08-13';
//         fromIso = `${d}T00:00:00.000Z`;
//         toIso = `${d}T23:59:59.999Z`;
//       } else {
//         const f = fromDate || '2026-08-13';
//         const t = toDate || fromDate || '2026-08-13';
//         const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
//         fromIso = `${sortedFrom}T00:00:00.000Z`;
//         toIso = `${sortedTo}T23:59:59.999Z`;
//       }

//       const params = {
//         searchBy: mode,
//         value: val,
//         from: fromIso,
//         to: toIso,
//       };

//       const searchEndpoint =
//         AppUrl?.getAnalyticsSearch ||
//         AppUrl?.analyticsSearch ||
//         '/tags/dashboard/analytics/search';

//       const res = await doGetApiCall({
//         url: searchEndpoint,
//         params,
//       });

//       console.log(res, 'searchApiResponse');

//       const rawData = res?.data?.result ?? res?.data?.results ?? res?.data;
//       const rawList = Array.isArray(rawData)
//         ? rawData
//         : rawData?.results && Array.isArray(rawData.results)
//         ? rawData.results
//         : rawData && typeof rawData === 'object' && rawData.cabinNumber
//         ? [rawData]
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);
//       // Keeps right pane waiting for user click
//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } catch (err) {
//       console.error('Vehicle search error:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to search vehicles');
//       setCabins([]);
//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const activeStage = selectedCabin?.stages?.[selectedStageIdx];
//   const totalDwell =
//     selectedCabin?.totalDwell ??
//     (selectedCabin?.stages?.reduce((acc, cur) => acc + (cur.dwell || 0), 0) || 0);

//   /**
//    * Conveyor rail group renderer
//    */
//   const renderConveyorRail = (groupName) => {
//     if (!selectedCabin || !selectedCabin.stages || selectedCabin.stages.length === 0) return null;
//     const stagesInGroup = selectedCabin.stages
//       .map((stage, idx) => ({ ...stage, originalIdx: idx }))
//       .filter((s) => s.group === groupName);

//     if (stagesInGroup.length === 0) return null;

//     return (
//       <div className={styles['rail-wrap']}>
//         <div className={styles['rail-track']}>
//           <div className={styles['rail-line']} />
//           {stagesInGroup.map((s) => (
//             <div
//               key={s.stageId || s.code}
//               className={`${styles['rail-stage']} ${
//                 s.originalIdx === selectedStageIdx ? styles.active : ''
//               }`}
//               onClick={() => handleStageClick(s.originalIdx, s.stageId)}
//             >
//               <div className={styles['rail-node']}>{s.code}</div>
//               <div className={styles['rail-name']}>{s.name}</div>
//               <div className={styles['rail-dwell']}>
//                 {s.entryTime ? `${s.entryTime.slice(0, 5)}–${(s.exitTime || '').slice(0, 5)}` : '—'}
//               </div>
//               <div className={styles['rail-count']}>
//                 {s.tagCount > 0 ? `${s.tagCount} tags` : 'no tags'}
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     );
//   };

//   return (
//     <div className={styles.pageContainer}>
//       <div className={styles.mainCard}>
//         {/* Header Bar */}
//         <header className={styles.topbar}>
//           <div className={styles.brand}>
//             <div>
//               <div className={styles['brand-text']}>PAINT SHOP DIGITAL TWIN</div>
//               <div className={styles['brand-sub']}>Stage Wise · PT / ED Line</div>
//             </div>
//           </div>

//           <div className={styles['search-row']}>
//             {/* Pill Toggle for Mode */}
//             <div className={styles.pillContainer}>
//               {[
//                 { key: 'hanger', label: 'Hanger' },
//                 { key: 'skid', label: 'Skid' },
//                 { key: 'cabin', label: 'Cabin' },
//               ].map(({ key, label }) => (
//                 <button
//                   key={key}
//                   type="button"
//                   className={`${styles.pillButton} ${mode === key ? styles.pillActive : ''}`}
//                   onClick={() => {
//                     setMode(key);
//                     setSearchInput('');
//                   }}
//                 >
//                   {label}
//                 </button>
//               ))}
//             </div>

//             {/* Rectangular Search Field */}
//             <div className={styles.field}>
//               <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <circle cx="11" cy="11" r="7" />
//                 <path d="M21 21l-4.3-4.3" />
//               </svg>
//               <input
//                 type="text"
//                 placeholder={`Search ${mode}...`}
//                 value={searchInput}
//                 onChange={(e) => setSearchInput(e.target.value)}
//                 onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
//               />
//             </div>

//             {/* Pill Toggle for Date Mode */}
//             <div className={styles.pillContainer}>
//               {[
//                 { key: 'single', label: 'Single Day' },
//                 { key: 'range', label: 'Date Range' },
//               ].map(({ key, label }) => (
//                 <button
//                   key={key}
//                   type="button"
//                   className={`${styles.pillButton} ${dateMode === key ? styles.pillActive : ''}`}
//                   onClick={() => setDateMode(key)}
//                 >
//                   {label}
//                 </button>
//               ))}
//             </div>

//             {/* Rectangular Date Box */}
//             <div className={styles['unified-date-box']}>
//               <svg className={styles['calendar-icon']} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <rect x="3" y="5" width="18" height="16" rx="2" />
//                 <path d="M3 10h18M8 3v4M16 3v4" />
//               </svg>

//               {dateMode === 'single' ? (
//                 <input
//                   type="date"
//                   className={styles['bare-date-input']}
//                   value={singleDate}
//                   onChange={(e) => setSingleDate(e.target.value)}
//                 />
//               ) : (
//                 <div className={styles['range-inputs-container']}>
//                   <input
//                     type="date"
//                     className={styles['bare-date-input']}
//                     value={fromDate}
//                     onChange={(e) => setFromDate(e.target.value)}
//                   />
//                   <span className={styles['range-arrow']}>→</span>
//                   <input
//                     type="date"
//                     className={styles['bare-date-input']}
//                     value={toDate}
//                     onChange={(e) => setToDate(e.target.value)}
//                   />
//                 </div>
//               )}
//             </div>

//             {/* Search Trigger Button */}
//             <button
//               type="button"
//               className={`${styles.btn} ${styles['btn-search']}`}
//               onClick={handleSearch}
//             >
//               Search
//             </button>
//           </div>

//           {/* Download Dropdown */}
//           <div className={styles['download-wrap']} ref={downloadWrapRef}>
//             <button
//               className={`${styles.btn} ${styles['btn-download']}`}
//               type="button"
//               onClick={() => setIsDownloadMenuOpen((prev) => !prev)}
//             >
//               <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <path d="M12 3v13m0 0l-4-4m4 4l4-4M4 21h16" />
//               </svg>
//               Download
//               <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
//                 <path d="M6 9l6 6 6-6" />
//               </svg>
//             </button>

//             <div className={`${styles['download-menu']} ${isDownloadMenuOpen ? styles.open : ''}`}>
//               <button className={styles['dm-item']} type="button" disabled={cabins.length === 0}>
//                 <div className={`${styles['dm-item-icon']} ${styles.corr}`}>⇄</div>
//                 <div>
//                   <div className={styles['dm-item-title']}>Correlation Report</div>
//                   <div className={styles['dm-item-sub']}>Vehicle, Hanger, Skid mapping across selected dates</div>
//                 </div>
//               </button>

//               <button className={styles['dm-item']} type="button" disabled={!selectedCabin}>
//                 <div className={`${styles['dm-item-icon']} ${styles.proc}`}>≣</div>
//                 <div>
//                   <div className={styles['dm-item-title']}>Process Report</div>
//                   <div className={styles['dm-item-sub']}>
//                     {selectedCabin ? `All tag readings for ${selectedCabin.cabin}` : 'Select a cabin on the left first'}
//                   </div>
//                 </div>
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* Workspace */}
//         <main className={styles.workspace}>
//           {/* Left Occurrences Pane */}
//           <section className={styles['results-pane']}>
//             <div className={styles['results-header']}>
//               <h2>{mode} occurrences</h2>
//               <span className={styles['results-count']}>
//                 {loading ? 'Loading...' : `${cabins.length} records`}
//               </span>
//             </div>
//             <div className={styles['results-list']}>
//               {loading ? (
//                 <div className={styles['empty-list']}>Fetching data...</div>
//               ) : error ? (
//                 <div className={styles['empty-list']} style={{ color: 'var(--danger)' }}>
//                   {error}
//                 </div>
//               ) : cabins.length === 0 ? (
//                 <div className={styles['empty-list']}>
//                   No vehicles found.<br />Try adjusting your search criteria.
//                 </div>
//               ) : (
//                 cabins.map((c, index) => {
//                   const isSelected = selectedCabin?.passKey === c.passKey;
//                   return (
//                     <div
//                       key={c.passKey || `${c.cabin}-${index}`}
//                       className={`${styles['result-card']} ${isSelected ? styles.selected : ''}`}
//                       onClick={() => handleSelectCabin(c)}
//                     >
//                       <div className={styles['rc-top']}>
//                         <span className={styles['rc-id']}>{c.cabin}</span>
//                         <span className={`${styles['rc-dot']} ${styles.ok}`} />
//                       </div>
//                       <div className={styles['rc-meta']}>
//                         {mode === 'hanger' && <span className={styles.mono}>Skid <b>{c.skid}</b></span>}
//                         {mode === 'skid' && <span className={styles.mono}>Hanger <b>{c.hanger}</b></span>}
//                         {mode === 'cabin' && <span className={styles.mono}>{c.hanger} / {c.skid}</span>}
//                         <span>{c.colour}</span>
//                         <span>{c.type}</span>
//                       </div>
//                       <div className={styles['rc-time']}>
//                         {c.date || '—'} {c.entry ? `· in ${c.entry}` : ''}
//                       </div>
//                     </div>
//                   );
//                 })
//               )}
//             </div>
//           </section>

//           {/* Right Detail Pane */}
//           <section className={styles['detail-pane']}>
//             {!selectedCabin ? (
//               <div className={styles['detail-placeholder']}>
//                 <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
//                   <circle cx="11" cy="11" r="7" />
//                   <path d="M21 21l-4.3-4.3" />
//                 </svg>
//                 <div className={styles['ph-title']}>Select a record to view its journey</div>
//                 <div className={styles['ph-sub']}>
//                   Pick a vehicle row on the left to inspect its complete stage journey and process tag readings.
//                 </div>
//               </div>
//             ) : (
//               <>
//                 <div className={styles['detail-header']}>
//                   <div>
//                     <div className={styles['dh-id']}>{selectedCabin.cabin}</div>
//                     <div className={styles['dh-tags']}>
//                       <span className={styles['dh-tag']}>Hanger <b>{selectedCabin.hanger || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Skid <b>{selectedCabin.skid || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Type <b>{selectedCabin.type || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Colour <b>{selectedCabin.colour || '—'}</b></span>
//                       <span className={styles['dh-tag']}>
//                         Entry <b>{selectedCabin.entry || '—'}</b> {selectedCabin.date ? `· ${selectedCabin.date}` : ''}
//                       </span>
//                     </div>
//                   </div>
//                   <div className={styles['dh-stats']}>
//                     <div className={styles['dh-stat']}>
//                       <div className={styles.num}>{totalDwell}m</div>
//                       <div className={styles.lbl}>Total time</div>
//                     </div>
//                     <div className={styles['dh-stat']}>
//                       <div className={styles.num}>{selectedCabin.stages?.length || selectedCabin.stagesSeen || 0}</div>
//                       <div className={styles.lbl}>Stages Seen</div>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Conveyor Rail Stage Tracks */}
//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — PT (Pre-Treatment)</div>
//                   {journeyLoading ? (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '12px 0' }}>
//                       Loading journey stages for {selectedCabin.cabin}...
//                     </div>
//                   ) : renderConveyorRail('PT') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No PT stages recorded for this vehicle.
//                     </div>
//                   )}
//                 </div>

//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — ED (Electro-Deposition)</div>
//                   {!journeyLoading && (renderConveyorRail('ED') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No ED stages recorded for this vehicle.
//                     </div>
//                   ))}
//                 </div>

//                 {/* Stage process tags */}
//                 {activeStage && (
//                   <div className={styles['param-section']}>
//                     <div className={styles['section-label']}>
//                       Process tags — {stageReadingsData?.name || activeStage.name}
//                     </div>
//                     <div className={styles['param-panel']}>
//                       <div className={styles['param-panel-head']}>
//                         <div>
//                           <div className={styles['pph-title']}>
//                             {stageReadingsData?.stageId || activeStage.code} — {stageReadingsData?.name || activeStage.name}
//                           </div>
//                           <div className={styles['pph-sub']}>
//                             {stageReadingsData?.window?.entryTime
//                               ? `${formatTimeToLocal(stageReadingsData.window.entryTime)} → ${formatTimeToLocal(stageReadingsData.window.exitTime)}`
//                               : activeStage.entryTime
//                               ? `${activeStage.entryTime} → ${activeStage.exitTime || ''}`
//                               : ''}
//                           </div>
//                         </div>
//                         {stageReadingsData?.tags && stageReadingsData.tags.length > 0 && (
//                           <div className={styles['pph-counts']}>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'live').length} Live
//                             </span>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'log').length} Log
//                             </span>
//                           </div>
//                         )}
//                       </div>

//                       {stageLoading ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12px' }}>
//                           Loading tag readings...
//                         </div>
//                       ) : activeStage.code === 'PT-11' || activeStage.code === 'ED-8' ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           Manual visual inspection checkpoint. No PLC tag readings recorded for this stage.[cite: 2]
//                         </div>
//                       ) : !stageReadingsData?.tags || stageReadingsData.tags.length === 0 ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           No process tags recorded for this stage.
//                         </div>
//                       ) : (
//                         <div style={{ overflowX: 'auto' }}>
//                           <table className={styles['param-table']}>
//                             <thead>
//                               <tr>
//                                 <th>Tag</th>
//                                 <th>Reference Range</th>
//                                 <th>Reading</th>
//                                 <th>Source</th>
//                                 <th>Process</th>
//                               </tr>
//                             </thead>
//                             <tbody>
//                               {stageReadingsData.tags.map((t, idx) => {
//                                 const hasData = t.status !== 'no_data' && ((t.avg !== null && t.avg !== undefined) || t.value !== undefined);
//                                 const displayValue = hasData
//                                   ? (t.value !== undefined ? t.value : t.avg)
//                                   : null;
//                                 const readingText = displayValue !== null ? `${displayValue} ${t.unit || ''}`.trim() : '—';
//                                 const isOutOfRange = t.status === 'out_of_range';

//                                 return (
//                                   <tr key={t.tagId ? `${t.tagId}-${idx}` : `${t.name}-${idx}`}>
//                                     <td>
//                                       <div className={styles['tag-name']}>{t.name || 'Unnamed Tag'}</div>
//                                       <div className={styles['tag-id']} title={t.tagId}>{t.tagId || '—'}</div>
//                                     </td>
//                                     <td>
//                                       <div className={styles['tag-range']}>
//                                         {formatRangeDisplay(t.range, t.unit)}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <div className={`${styles['tag-reading']} ${isOutOfRange ? styles.warn : styles.ok}`}>
//                                         {readingText}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <span className={`${styles.chip} ${styles['src-live']}`}>
//                                         {t.source || 'Live'}
//                                       </span>
//                                     </td>
//                                     <td>
//                                       {t.status === 'out_of_range' ? (
//                                         <span className={`${styles.chip} ${styles['dev-out']}`}>⚠ Out of range</span>
//                                       ) : t.status === 'within_range' ? (
//                                         <span className={`${styles.chip} ${styles['dev-in']}`}>In range</span>
//                                       ) : (
//                                         <span className={`${styles.chip} ${styles['src-none']}`}>No data</span>
//                                       )}
//                                     </td>
//                                   </tr>
//                                 );
//                               })}
//                             </tbody>
//                           </table>
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                 )}
//               </>
//             )}
//           </section>
//         </main>
//       </div>
//     </div>
//   );
// }

// import React, { useState, useEffect, useRef, useCallback } from 'react';
// import styles from './analyticsDashboard.module.css';
// import { doGetApiCall } from '../../../../utils/ClonosApi';
// import AppUrl from '../../../../utils/AppUrl';

// /* Helper to convert UTC ISO string to readable local time (HH:mm:ss) */
// export const formatTimeToLocal = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toTimeString().slice(0, 8);
//   } catch {
//     return isoString.includes('T') ? isoString.split('T')[1].slice(0, 8) : isoString;
//   }
// };

// /* Helper to extract YYYY-MM-DD from an ISO string */
// export const formatDateString = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toISOString().slice(0, 10);
//   } catch {
//     return String(isoString).slice(0, 10);
//   }
// };

// /* Helper to safely format range whether it is an Object or a String */
// export const formatRangeDisplay = (range, fallbackUnit = '') => {
//   if (!range) return '—';

//   if (typeof range === 'object') {
//     const min = range.min;
//     const max = range.max;
//     const unit = range.unit || fallbackUnit || '';

//     const hasMin = min !== undefined && min !== null && min !== -Infinity;
//     const hasMax = max !== undefined && max !== null && max !== Infinity;

//     if (hasMin && hasMax) return `${min} - ${max} ${unit}`.trim();
//     if (hasMin) return `> ${min} ${unit}`.trim();
//     if (hasMax) return `< ${max} ${unit}`.trim();
//     return '—';
//   }

//   return `${range} ${fallbackUnit || ''}`.trim();
// };

// export default function AnalyticsDashboard() {
//   /* Search & Filter Controls */
//   const [mode, setMode] = useState('cabin');
//   const [searchInput, setSearchInput] = useState('');
//   const [dateMode, setDateMode] = useState('single');
//   const [singleDate, setSingleDate] = useState('2026-08-13');
//   const [fromDate, setFromDate] = useState('2026-08-13');
//   const [toDate, setToDate] = useState('2026-08-13');

//   /* Live API State */
//   const [cabins, setCabins] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   /* Vehicle Selection & Journey States */
//   const [selectedCabin, setSelectedCabin] = useState(null);
//   const [journeyLoading, setJourneyLoading] = useState(false);
//   const [selectedStageIdx, setSelectedStageIdx] = useState(0);

//   /* Stage Readings API State */
//   const [stageReadingsData, setStageReadingsData] = useState(null);
//   const [stageLoading, setStageLoading] = useState(false);

//   /* Download Menu State */
//   const [isDownloadMenuOpen, setIsDownloadMenuOpen] = useState(false);
//   const downloadWrapRef = useRef(null);

//   useEffect(() => {
//     function handleClickOutside(e) {
//       if (downloadWrapRef.current && !downloadWrapRef.current.contains(e.target)) {
//         setIsDownloadMenuOpen(false);
//       }
//     }
//     document.addEventListener('click', handleClickOutside);
//     return () => document.removeEventListener('click', handleClickOutside);
//   }, []);

//   /**
//    * Helper to trigger binary Blob file downloads (.xlsx)
//    */
//   const downloadFileBlob = (data, filename) => {
//     const blob = new Blob([data], {
//       type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
//     });
//     const url = window.URL.createObjectURL(blob);
//     const link = document.createElement('a');
//     link.href = url;
//     link.download = filename;
//     document.body.appendChild(link);
//     link.click();
//     document.body.removeChild(link);
//     window.URL.revokeObjectURL(url);
//   };

//   /**
//    * Normalizer for Vehicle list items
//    */
//   const normalizeVehicleItem = (item) => {
//     const cabin = item.cabinNumber || item.cabin || '—';
//     const hanger = item.hanger || '—';
//     const skid = item.skid !== undefined && item.skid !== null ? String(item.skid) : '—';
//     const type = item.type || item.bodyType || '—';
//     const colour = item.colour || item.color || '—';
//     const passKey = item.passKey || `${cabin}|${skid}`;

//     const rawEntry = item.firstEntryTime || item.firstEntry || item.entryTime || item.entry || item.createdAt;
//     const rawExit = item.lastExitTime || item.lastExit || item.exitTime || item.exit;

//     const date = formatDateString(rawEntry || item.date);
//     const entry = formatTimeToLocal(rawEntry);
//     const exit = formatTimeToLocal(rawExit);

//     let totalDwellMinutes = 0;
//     if (rawEntry && rawExit) {
//       const diffMs = new Date(rawExit) - new Date(rawEntry);
//       if (diffMs > 0) {
//         totalDwellMinutes = Math.round(diffMs / (1000 * 60));
//       }
//     }

//     return {
//       ...item,
//       passKey,
//       cabin,
//       cabinNumber: cabin,
//       hanger,
//       skid,
//       type,
//       colour,
//       date,
//       entry,
//       exit,
//       totalDwell: totalDwellMinutes,
//       stagesSeen: item.stagesSeen ?? item.stages?.length ?? 0,
//       stages: item.stages || [],
//       devCount: item.devCount || 0,
//     };
//   };

//   /**
//    * Normalizer for individual stage objects inside result.lines.PT or result.lines.ED
//    */
//   const normalizeJourneyStage = (st, idx) => {
//     const stageId = st.stageId || st.id || st.code || `ST-${idx + 1}`;
//     const code = st.code || st.stageCode || stageId;
//     const name = st.name || st.stageName || 'Stage';
//     const group = st.group || (code.toUpperCase().startsWith('ED') ? 'ED' : 'PT');

//     const tagCount = st.tagCount !== undefined
//       ? st.tagCount
//       : (st.readings?.length ?? st.tags?.length ?? 0);

//     let dwellMinutes = 0;
//     if (st.dwellSeconds !== undefined && st.dwellSeconds !== null) {
//       dwellMinutes = Math.round(st.dwellSeconds / 60);
//     } else if (st.dwell) {
//       dwellMinutes = st.dwell;
//     } else if (st.entryTime && st.exitTime) {
//       const diff = new Date(st.exitTime) - new Date(st.entryTime);
//       if (diff > 0) dwellMinutes = Math.round(diff / 60000);
//     }

//     return {
//       ...st,
//       stageId,
//       code,
//       name,
//       group,
//       tagCount,
//       dwell: dwellMinutes,
//       entryTime: formatTimeToLocal(st.entryTime),
//       exitTime: formatTimeToLocal(st.exitTime),
//       rawEntryTime: st.entryTime,
//       rawExitTime: st.exitTime,
//     };
//   };

//   /**
//    * 3. STAGE READINGS API
//    */
//   const fetchStageReadings = useCallback(async (cabinNumber, skid, stageId) => {
//     if (!cabinNumber || cabinNumber === '—' || !stageId) return;

//     setStageLoading(true);
//     try {
//       const readingsEndpoint =
//         AppUrl?.getAnalyticsStageReadings ||
//         AppUrl?.analyticsStageReadings ||
//         '/tags/dashboard/analytics/stage-readings';

//       const params = {
//         cabinNumber,
//         skid,
//         stageId,
//       };

//       const res = await doGetApiCall({
//         url: readingsEndpoint,
//         params,
//       });

//       console.log(res, 'stageReadingsApiResponse');

//       const responseData = res?.data?.result ?? res?.data;
//       setStageReadingsData(responseData);
//     } catch (err) {
//       console.error('Failed to fetch stage readings:', err);
//       setStageReadingsData(null);
//     } finally {
//       setStageLoading(false);
//     }
//   }, []);

//   /**
//    * 2. JOURNEY API
//    */
//   const fetchVehicleJourney = useCallback(async (cabinObj) => {
//     if (!cabinObj || !cabinObj.cabinNumber || cabinObj.cabinNumber === '—') return;

//     setJourneyLoading(true);
//     try {
//       const journeyEndpoint =
//         AppUrl?.getAnalyticsJourney ||
//         AppUrl?.analyticsJourney ||
//         '/tags/dashboard/analytics/journey';

//       const params = {
//         cabinNumber: cabinObj.cabinNumber,
//         skid: cabinObj.skid,
//         includeStatus: true,
//       };

//       const res = await doGetApiCall({
//         url: journeyEndpoint,
//         params,
//       });

//       console.log(res, 'journeyApiResponse');

//       const result = res?.data?.result;
//       const lines = result?.lines || {};

//       const ptList = Array.isArray(lines.PT)
//         ? lines.PT.map((st, idx) => normalizeJourneyStage({ ...st, group: 'PT' }, idx))
//         : [];
//       const edList = Array.isArray(lines.ED)
//         ? lines.ED.map((st, idx) => normalizeJourneyStage({ ...st, group: 'ED' }, idx))
//         : [];

//       const allStages = [...ptList, ...edList];

//       setSelectedCabin((prev) => {
//         if (!prev) return prev;
//         return {
//           ...prev,
//           hanger: result?.vehicle?.hanger || prev.hanger,
//           type: result?.vehicle?.type || prev.type,
//           colour: result?.vehicle?.colour || prev.colour,
//           entry: formatTimeToLocal(result?.firstEntryTime) || prev.entry,
//           exit: formatTimeToLocal(result?.lastExitTime) || prev.exit,
//           stages: allStages,
//         };
//       });

//       setCabins((prev) =>
//         prev.map((c) =>
//           c.cabinNumber === cabinObj.cabinNumber && String(c.skid) === String(cabinObj.skid)
//             ? { ...c, stages: allStages }
//             : c
//         )
//       );

//       setSelectedStageIdx(0);
//       if (allStages.length > 0) {
//         fetchStageReadings(cabinObj.cabinNumber, cabinObj.skid, allStages[0].stageId);
//       }
//     } catch (err) {
//       console.error('Failed to fetch vehicle journey:', err);
//     } finally {
//       setJourneyLoading(false);
//     }
//   }, [fetchStageReadings]);

//   /**
//    * Card Selection Handler
//    */
//   const handleSelectCabin = (cabin) => {
//     const normalized = normalizeVehicleItem(cabin);
//     setSelectedCabin(normalized);
//     setSelectedStageIdx(0);
//     setStageReadingsData(null);
//     fetchVehicleJourney(normalized);
//   };

//   /**
//    * Stage Node Click Handler
//    */
//   const handleStageClick = (originalIdx, stageId) => {
//     setSelectedStageIdx(originalIdx);
//     if (selectedCabin) {
//       fetchStageReadings(selectedCabin.cabinNumber, selectedCabin.skid, stageId);
//     }
//   };

//   /**
//    * 1. INITIAL API: Overview Call
//    */
//   const fetchOverviewAnalyticsData = useCallback(async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const res = await doGetApiCall({ url: AppUrl?.getOverviewAnalytics });
//       console.log(res, 'overviewRes (Initial Load)');

//       const responseData = res?.data?.result;
//       const rawList = Array.isArray(responseData?.results)
//         ? responseData.results
//         : Array.isArray(res?.data?.results)
//         ? res.data.results
//         : Array.isArray(responseData)
//         ? responseData
//         : Array.isArray(res?.data)
//         ? res.data
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);

//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } catch (err) {
//       console.error('Failed to fetch initial overview:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to load initial overview records');
//     } finally {
//       setLoading(false);
//     }
//   }, []);

//   useEffect(() => {
//     fetchOverviewAnalyticsData();
//   }, [fetchOverviewAnalyticsData]);

//   /**
//    * 2. SEARCH API
//    */
//   const handleSearch = async () => {
//     const val = searchInput.trim();
//     if (!val) {
//       fetchOverviewAnalyticsData();
//       return;
//     }

//     setLoading(true);
//     setError(null);
//     setSelectedCabin(null);
//     setStageReadingsData(null);

//     try {
//       let fromIso = '';
//       let toIso = '';

//       if (dateMode === 'single') {
//         const d = singleDate || '2026-08-13';
//         fromIso = `${d}T00:00:00.000Z`;
//         toIso = `${d}T23:59:59.999Z`;
//       } else {
//         const f = fromDate || '2026-08-13';
//         const t = toDate || fromDate || '2026-08-13';
//         const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
//         fromIso = `${sortedFrom}T00:00:00.000Z`;
//         toIso = `${sortedTo}T23:59:59.999Z`;
//       }

//       const params = {
//         searchBy: mode,
//         value: val,
//         from: fromIso,
//         to: toIso,
//       };

//       const searchEndpoint =
//         AppUrl?.getAnalyticsSearch ||
//         AppUrl?.analyticsSearch ||
//         '/tags/dashboard/analytics/search';

//       const res = await doGetApiCall({
//         url: searchEndpoint,
//         params,
//       });

//       console.log(res, 'searchApiResponse');

//       const rawData = res?.data?.result ?? res?.data?.results ?? res?.data;
//       const rawList = Array.isArray(rawData)
//         ? rawData
//         : rawData?.results && Array.isArray(rawData.results)
//         ? rawData.results
//         : rawData && typeof rawData === 'object' && rawData.cabinNumber
//         ? [rawData]
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);
//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } catch (err) {
//       console.error('Vehicle search error:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to search vehicles');
//       setCabins([]);
//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } finally {
//       setLoading(false);
//     }
//   };

//   /**
//    * 4. CORRELATION XLSX REPORT
//    */
//   const handleDownloadCorrelation = async () => {
//     const val = searchInput.trim() || selectedCabin?.cabinNumber || 'all';
//     setIsDownloadMenuOpen(false);

//     try {
//       let fromIso = '';
//       let toIso = '';

//       if (dateMode === 'single') {
//         const d = singleDate || '2026-08-13';
//         fromIso = `${d}T00:00:00.000Z`;
//         toIso = `${d}T23:59:59.999Z`;
//       } else {
//         const f = fromDate || '2026-08-13';
//         const t = toDate || fromDate || '2026-08-13';
//         const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
//         fromIso = `${sortedFrom}T00:00:00.000Z`;
//         toIso = `${sortedTo}T23:59:59.999Z`;
//       }

//       const endpoint =
//         AppUrl?.getAnalyticsCorrelationReport ||
//         AppUrl?.analyticsCorrelationReport ||
//         '/tags/dashboard/analytics/reports/correlation';

//       const res = await doGetApiCall({
//         url: endpoint,
//         params: {
//           searchBy: mode,
//           value: val,
//           from: fromIso,
//           to: toIso,
//         },
//         responseType: 'blob',
//       });

//       downloadFileBlob(res.data, `correlation-report-${val}.xlsx`);
//     } catch (err) {
//       console.error('Failed to download correlation report:', err);
//     }
//   };

//   /**
//    * 5. PROCESS XLSX REPORT
//    */
//   const handleDownloadProcess = async () => {
//     if (!selectedCabin) return;
//     setIsDownloadMenuOpen(false);

//     try {
//       const endpoint =
//         AppUrl?.getAnalyticsProcessReport ||
//         AppUrl?.analyticsProcessReport ||
//         '/tags/dashboard/analytics/reports/process';

//       const res = await doGetApiCall({
//         url: endpoint,
//         params: {
//           cabinNumber: selectedCabin.cabinNumber,
//           skid: selectedCabin.skid,
//         },
//         responseType: 'blob',
//       });

//       downloadFileBlob(
//         res.data,
//         `process-report-${selectedCabin.cabinNumber}-${selectedCabin.skid}.xlsx`
//       );
//     } catch (err) {
//       console.error('Failed to download process report:', err);
//     }
//   };

//   const activeStage = selectedCabin?.stages?.[selectedStageIdx];
//   const totalDwell =
//     selectedCabin?.totalDwell ??
//     (selectedCabin?.stages?.reduce((acc, cur) => acc + (cur.dwell || 0), 0) || 0);

//   /**
//    * Conveyor rail group renderer
//    */
//   const renderConveyorRail = (groupName) => {
//     if (!selectedCabin || !selectedCabin.stages || selectedCabin.stages.length === 0) return null;
//     const stagesInGroup = selectedCabin.stages
//       .map((stage, idx) => ({ ...stage, originalIdx: idx }))
//       .filter((s) => s.group === groupName);

//     if (stagesInGroup.length === 0) return null;

//     return (
//       <div className={styles['rail-wrap']}>
//         <div className={styles['rail-track']}>
//           <div className={styles['rail-line']} />
//           {stagesInGroup.map((s) => (
//             <div
//               key={s.stageId || s.code}
//               className={`${styles['rail-stage']} ${
//                 s.originalIdx === selectedStageIdx ? styles.active : ''
//               }`}
//               onClick={() => handleStageClick(s.originalIdx, s.stageId)}
//             >
//               <div className={styles['rail-node']}>{s.code}</div>
//               <div className={styles['rail-name']}>{s.name}</div>
//               <div className={styles['rail-dwell']}>
//                 {s.entryTime ? `${s.entryTime.slice(0, 5)}–${(s.exitTime || '').slice(0, 5)}` : '—'}
//               </div>
//               <div className={styles['rail-count']}>
//                 {s.tagCount > 0 ? `${s.tagCount} tags` : 'no tags'}
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     );
//   };

//   return (
//     <div className={styles.pageContainer}>
//       <div className={styles.mainCard}>
//         {/* Header Bar */}
//         <header className={styles.topbar}>
//           <div className={styles.brand}>
//             <div>
//               <div className={styles['brand-text']}>PAINT SHOP DIGITAL TWIN</div>
//               <div className={styles['brand-sub']}>Stage Wise · PT / ED Line</div>
//             </div>
//           </div>

//           <div className={styles['search-row']}>
//             {/* Pill Toggle for Mode */}
//             <div className={styles.pillContainer}>
//               {[
//                 { key: 'hanger', label: 'Hanger' },
//                 { key: 'skid', label: 'Skid' },
//                 { key: 'cabin', label: 'Cabin' },
//               ].map(({ key, label }) => (
//                 <button
//                   key={key}
//                   type="button"
//                   className={`${styles.pillButton} ${mode === key ? styles.pillActive : ''}`}
//                   onClick={() => {
//                     setMode(key);
//                     setSearchInput('');
//                   }}
//                 >
//                   {label}
//                 </button>
//               ))}
//             </div>

//             {/* Rectangular Search Field */}
//             <div className={styles.field}>
//               <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <circle cx="11" cy="11" r="7" />
//                 <path d="M21 21l-4.3-4.3" />
//               </svg>
//               <input
//                 type="text"
//                 placeholder={`Search ${mode}...`}
//                 value={searchInput}
//                 onChange={(e) => setSearchInput(e.target.value)}
//                 onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
//               />
//             </div>

//             {/* Pill Toggle for Date Mode */}
//             <div className={styles.pillContainer}>
//               {[
//                 { key: 'single', label: 'Single Day' },
//                 { key: 'range', label: 'Date Range' },
//               ].map(({ key, label }) => (
//                 <button
//                   key={key}
//                   type="button"
//                   className={`${styles.pillButton} ${dateMode === key ? styles.pillActive : ''}`}
//                   onClick={() => setDateMode(key)}
//                 >
//                   {label}
//                 </button>
//               ))}
//             </div>

//             {/* Rectangular Date Box */}
//             <div className={styles['unified-date-box']}>
//               <svg className={styles['calendar-icon']} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <rect x="3" y="5" width="18" height="16" rx="2" />
//                 <path d="M3 10h18M8 3v4M16 3v4" />
//               </svg>

//               {dateMode === 'single' ? (
//                 <input
//                   type="date"
//                   className={styles['bare-date-input']}
//                   value={singleDate}
//                   onChange={(e) => setSingleDate(e.target.value)}
//                 />
//               ) : (
//                 <div className={styles['range-inputs-container']}>
//                   <input
//                     type="date"
//                     className={styles['bare-date-input']}
//                     value={fromDate}
//                     onChange={(e) => setFromDate(e.target.value)}
//                   />
//                   <span className={styles['range-arrow']}>→</span>
//                   <input
//                     type="date"
//                     className={styles['bare-date-input']}
//                     value={toDate}
//                     onChange={(e) => setToDate(e.target.value)}
//                   />
//                 </div>
//               )}
//             </div>

//             {/* Search Trigger Button */}
//             <button
//               type="button"
//               className={`${styles.btn} ${styles['btn-search']}`}
//               onClick={handleSearch}
//             >
//               Search
//             </button>
//           </div>

//           {/* Download Dropdown */}
//           <div className={styles['download-wrap']} ref={downloadWrapRef}>
//             <button
//               className={`${styles.btn} ${styles['btn-download']}`}
//               type="button"
//               onClick={() => setIsDownloadMenuOpen((prev) => !prev)}
//             >
//               <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//                 <path d="M12 3v13m0 0l-4-4m4 4l4-4M4 21h16" />
//               </svg>
//               Download
//               <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
//                 <path d="M6 9l6 6 6-6" />
//               </svg>
//             </button>

//             <div className={`${styles['download-menu']} ${isDownloadMenuOpen ? styles.open : ''}`}>
//               <button
//                 className={styles['dm-item']}
//                 type="button"
//                 onClick={handleDownloadCorrelation}
//                 disabled={cabins.length === 0}
//               >
//                 <div className={`${styles['dm-item-icon']} ${styles.corr}`}>⇄</div>
//                 <div>
//                   <div className={styles['dm-item-title']}>Correlation Report</div>
//                   <div className={styles['dm-item-sub']}>
//                     Vehicle, Hanger, Skid mapping across selected dates (.xlsx)
//                   </div>
//                 </div>
//               </button>

//               <button
//                 className={styles['dm-item']}
//                 type="button"
//                 onClick={handleDownloadProcess}
//                 disabled={!selectedCabin}
//               >
//                 <div className={`${styles['dm-item-icon']} ${styles.proc}`}>≣</div>
//                 <div>
//                   <div className={styles['dm-item-title']}>Process Report</div>
//                   <div className={styles['dm-item-sub']}>
//                     {selectedCabin
//                       ? `All tag readings for ${selectedCabin.cabin} (.xlsx)`
//                       : 'Select a cabin on the left first'}
//                   </div>
//                 </div>
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* Workspace */}
//         <main className={styles.workspace}>
//           {/* Left Occurrences Pane */}
//           <section className={styles['results-pane']}>
//             <div className={styles['results-header']}>
//               <h2>{mode} occurrences</h2>
//               <span className={styles['results-count']}>
//                 {loading ? 'Loading...' : `${cabins.length} records`}
//               </span>
//             </div>
//             <div className={styles['results-list']}>
//               {loading ? (
//                 <div className={styles['empty-list']}>Fetching data...</div>
//               ) : error ? (
//                 <div className={styles['empty-list']} style={{ color: 'var(--danger)' }}>
//                   {error}
//                 </div>
//               ) : cabins.length === 0 ? (
//                 <div className={styles['empty-list']}>
//                   No vehicles found.<br />Try adjusting your search criteria.
//                 </div>
//               ) : (
//                 cabins.map((c, index) => {
//                   const isSelected = selectedCabin?.passKey === c.passKey;
//                   return (
//                     <div
//                       key={c.passKey || `${c.cabin}-${index}`}
//                       className={`${styles['result-card']} ${isSelected ? styles.selected : ''}`}
//                       onClick={() => handleSelectCabin(c)}
//                     >
//                       <div className={styles['rc-top']}>
//                         <span className={styles['rc-id']}>{c.cabin}</span>
//                         <span className={`${styles['rc-dot']} ${styles.ok}`} />
//                       </div>
//                       <div className={styles['rc-meta']}>
//                         {mode === 'hanger' && <span className={styles.mono}>Skid <b>{c.skid}</b></span>}
//                         {mode === 'skid' && <span className={styles.mono}>Hanger <b>{c.hanger}</b></span>}
//                         {mode === 'cabin' && <span className={styles.mono}>{c.hanger} / {c.skid}</span>}
//                         <span>{c.colour}</span>
//                         <span>{c.type}</span>
//                       </div>
//                       <div className={styles['rc-time']}>
//                         {c.date || '—'} {c.entry ? `· in ${c.entry}` : ''}
//                       </div>
//                     </div>
//                   );
//                 })
//               )}
//             </div>
//           </section>

//           {/* Right Detail Pane */}
//           <section className={styles['detail-pane']}>
//             {!selectedCabin ? (
//               <div className={styles['detail-placeholder']}>
//                 <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
//                   <circle cx="11" cy="11" r="7" />
//                   <path d="M21 21l-4.3-4.3" />
//                 </svg>
//                 <div className={styles['ph-title']}>Select a record to view its journey</div>
//                 <div className={styles['ph-sub']}>
//                   Pick a vehicle row on the left to inspect its complete stage journey and process tag readings.
//                 </div>
//               </div>
//             ) : (
//               <>
//                 <div className={styles['detail-header']}>
//                   <div>
//                     <div className={styles['dh-id']}>{selectedCabin.cabin}</div>
//                     <div className={styles['dh-tags']}>
//                       <span className={styles['dh-tag']}>Hanger <b>{selectedCabin.hanger || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Skid <b>{selectedCabin.skid || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Type <b>{selectedCabin.type || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Colour <b>{selectedCabin.colour || '—'}</b></span>
//                       <span className={styles['dh-tag']}>
//                         Entry <b>{selectedCabin.entry || '—'}</b> {selectedCabin.date ? `· ${selectedCabin.date}` : ''}
//                       </span>
//                     </div>
//                   </div>
//                   <div className={styles['dh-stats']}>
//                     <div className={styles['dh-stat']}>
//                       <div className={styles.num}>{totalDwell}m</div>
//                       <div className={styles.lbl}>Total time</div>
//                     </div>
//                     <div className={styles['dh-stat']}>
//                       <div className={styles.num}>{selectedCabin.stages?.length || selectedCabin.stagesSeen || 0}</div>
//                       <div className={styles.lbl}>Stages Seen</div>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Conveyor Rail Stage Tracks */}
//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — PT (Pre-Treatment)</div>
//                   {journeyLoading ? (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '12px 0' }}>
//                       Loading journey stages for {selectedCabin.cabin}...
//                     </div>
//                   ) : renderConveyorRail('PT') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No PT stages recorded for this vehicle.
//                     </div>
//                   )}
//                 </div>

//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — ED (Electro-Deposition)</div>
//                   {!journeyLoading && (renderConveyorRail('ED') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No ED stages recorded for this vehicle.
//                     </div>
//                   ))}
//                 </div>

//                 {/* Stage process tags */}
//                 {activeStage && (
//                   <div className={styles['param-section']}>
//                     <div className={styles['section-label']}>
//                       Process tags — {stageReadingsData?.name || activeStage.name}
//                     </div>
//                     <div className={styles['param-panel']}>
//                       <div className={styles['param-panel-head']}>
//                         <div>
//                           <div className={styles['pph-title']}>
//                             {stageReadingsData?.stageId || activeStage.code} — {stageReadingsData?.name || activeStage.name}
//                           </div>
//                           <div className={styles['pph-sub']}>
//                             {stageReadingsData?.window?.entryTime
//                               ? `${formatTimeToLocal(stageReadingsData.window.entryTime)} → ${formatTimeToLocal(stageReadingsData.window.exitTime)}`
//                               : activeStage.entryTime
//                               ? `${activeStage.entryTime} → ${activeStage.exitTime || ''}`
//                               : ''}
//                           </div>
//                         </div>
//                         {stageReadingsData?.tags && stageReadingsData.tags.length > 0 && (
//                           <div className={styles['pph-counts']}>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'live').length} Live
//                             </span>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'log').length} Log
//                             </span>
//                           </div>
//                         )}
//                       </div>

//                       {stageLoading ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12px' }}>
//                           Loading tag readings...
//                         </div>
//                       ) : activeStage.code === 'PT-11' || activeStage.code === 'ED-8' ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           Manual visual inspection checkpoint. No PLC tag readings recorded for this stage.
//                         </div>
//                       ) : !stageReadingsData?.tags || stageReadingsData.tags.length === 0 ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           No process tags recorded for this stage.
//                         </div>
//                       ) : (
//                         <div style={{ overflowX: 'auto' }}>
//                           <table className={styles['param-table']}>
//                             <thead>
//                               <tr>
//                                 <th>Tag</th>
//                                 <th>Reference Range</th>
//                                 <th>Reading</th>
//                                 <th>Source</th>
//                                 <th>Process</th>
//                               </tr>
//                             </thead>
//                             <tbody>
//                               {stageReadingsData.tags.map((t, idx) => {
//                                 const hasData = t.status !== 'no_data' && ((t.avg !== null && t.avg !== undefined) || t.value !== undefined);
//                                 const displayValue = hasData
//                                   ? (t.value !== undefined ? t.value : t.avg)
//                                   : null;
//                                 const readingText = displayValue !== null ? `${displayValue} ${t.unit || ''}`.trim() : '—';
//                                 const isOutOfRange = t.status === 'out_of_range';

//                                 return (
//                                   <tr key={t.tagId ? `${t.tagId}-${idx}` : `${t.name}-${idx}`}>
//                                     <td>
//                                       <div className={styles['tag-name']}>{t.name || 'Unnamed Tag'}</div>
//                                       <div className={styles['tag-id']} title={t.tagId}>{t.tagId || '—'}</div>
//                                     </td>
//                                     <td>
//                                       <div className={styles['tag-range']}>
//                                         {formatRangeDisplay(t.range, t.unit)}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <div className={`${styles['tag-reading']} ${isOutOfRange ? styles.warn : styles.ok}`}>
//                                         {readingText}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <span className={`${styles.chip} ${styles['src-live']}`}>
//                                         {t.source || 'Live'}
//                                       </span>
//                                     </td>
//                                     <td>
//                                       {t.status === 'out_of_range' ? (
//                                         <span className={`${styles.chip} ${styles['dev-out']}`}>⚠ Out of range</span>
//                                       ) : t.status === 'within_range' ? (
//                                         <span className={`${styles.chip} ${styles['dev-in']}`}>In range</span>
//                                       ) : (
//                                         <span className={`${styles.chip} ${styles['src-none']}`}>No data</span>
//                                       )}
//                                     </td>
//                                   </tr>
//                                 );
//                               })}
//                             </tbody>
//                           </table>
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                 )}
//               </>
//             )}
//           </section>
//         </main>
//       </div>
//     </div>
//   );
// }

//last deployed code
// import React, { useState, useEffect, useRef, useCallback } from 'react';
// import styles from './analyticsDashboard.module.css';
// import { doGetApiCall } from '../../../../utils/ClonosApi';
// import AppUrl from '../../../../utils/AppUrl';

// /* Helper to convert UTC ISO string to readable local time (HH:mm:ss) */
// export const formatTimeToLocal = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toTimeString().slice(0, 8);
//   } catch {
//     return isoString.includes('T') ? isoString.split('T')[1].slice(0, 8) : isoString;
//   }
// };

// /* Helper to extract YYYY-MM-DD from an ISO string */
// export const formatDateString = (isoString) => {
//   if (!isoString) return '—';
//   try {
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return String(isoString);
//     return d.toISOString().slice(0, 10);
//   } catch {
//     return String(isoString).slice(0, 10);
//   }
// };

// /* Helper to safely format range whether it is an Object or a String */
// export const formatRangeDisplay = (range, fallbackUnit = '') => {
//   if (!range) return '—';

//   if (typeof range === 'object') {
//     const min = range.min;
//     const max = range.max;
//     const unit = range.unit || fallbackUnit || '';

//     const hasMin = min !== undefined && min !== null && min !== -Infinity;
//     const hasMax = max !== undefined && max !== null && max !== Infinity;

//     if (hasMin && hasMax) return `${min} - ${max} ${unit}`.trim();
//     if (hasMin) return `> ${min} ${unit}`.trim();
//     if (hasMax) return `< ${max} ${unit}`.trim();
//     return '—';
//   }

//   return `${range} ${fallbackUnit || ''}`.trim();
// };

// export default function AnalyticsDashboard() {
//   /* Search & Filter Controls */
//   const [mode, setMode] = useState('cabin');
//   const [searchInput, setSearchInput] = useState('');
//   const [dateMode, setDateMode] = useState('single');
//   const [singleDate, setSingleDate] = useState('2026-08-13');
//   const [fromDate, setFromDate] = useState('2026-08-13');
//   const [toDate, setToDate] = useState('2026-08-13');

//   /* Live API State */
//   const [cabins, setCabins] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   /* Vehicle Selection & Journey States */
//   const [selectedCabin, setSelectedCabin] = useState(null);
//   const [journeyLoading, setJourneyLoading] = useState(false);
//   const [selectedStageIdx, setSelectedStageIdx] = useState(0);

//   /* Stage Readings API State */
//   const [stageReadingsData, setStageReadingsData] = useState(null);
//   const [stageLoading, setStageLoading] = useState(false);

//   /* Download Menu State */
//   const [isDownloadMenuOpen, setIsDownloadMenuOpen] = useState(false);
//   const downloadWrapRef = useRef(null);

//   useEffect(() => {
//     function handleClickOutside(e) {
//       if (downloadWrapRef.current && !downloadWrapRef.current.contains(e.target)) {
//         setIsDownloadMenuOpen(false);
//       }
//     }
//     document.addEventListener('click', handleClickOutside);
//     return () => document.removeEventListener('click', handleClickOutside);
//   }, []);



//   /**
//    * Normalizer for Vehicle list items
//    */
//   const normalizeVehicleItem = (item) => {
//     const cabin = item.cabinNumber || item.cabin || '—';
//     const hanger = item.hanger || '—';
//     const skid = item.skid !== undefined && item.skid !== null ? String(item.skid) : '—';
//     const type = item.type || item.bodyType || '—';
//     const colour = item.colour || item.color || '—';
//     const passKey = item.passKey || `${cabin}|${skid}`;

//     const rawEntry = item.firstEntryTime || item.firstEntry || item.entryTime || item.entry || item.createdAt;
//     const rawExit = item.lastExitTime || item.lastExit || item.exitTime || item.exit;

//     const date = formatDateString(rawEntry || item.date);
//     const entry = formatTimeToLocal(rawEntry);
//     const exit = formatTimeToLocal(rawExit);

//     let totalDwellMinutes = 0;
//     if (rawEntry && rawExit) {
//       const diffMs = new Date(rawExit) - new Date(rawEntry);
//       if (diffMs > 0) {
//         totalDwellMinutes = Math.round(diffMs / (1000 * 60));
//       }
//     }

//     return {
//       ...item,
//       passKey,
//       cabin,
//       cabinNumber: cabin,
//       hanger,
//       skid,
//       type,
//       colour,
//       date,
//       entry,
//       exit,
//       totalDwell: totalDwellMinutes,
//       stagesSeen: item.stagesSeen ?? item.stages?.length ?? 0,
//       stages: item.stages || [],
//       devCount: item.devCount || 0,
//     };
//   };

//   /**
//    * Normalizer for individual stage objects inside result.lines.PT or result.lines.ED
//    * Maps QID-166 inRange field
//    */
//   const normalizeJourneyStage = (st, idx) => {
//     const stageId = st.stageId || st.id || st.code || `ST-${idx + 1}`;
//     const code = st.code || st.stageCode || stageId;
//     const name = st.name || st.stageName || 'Stage';
//     const group = st.group || (code.toUpperCase().startsWith('ED') ? 'ED' : 'PT');

//     const tagCount = st.tagCount !== undefined
//       ? st.tagCount
//       : (st.readings?.length ?? st.tags?.length ?? 0);

//     let dwellMinutes = 0;
//     if (st.dwellSeconds !== undefined && st.dwellSeconds !== null) {
//       dwellMinutes = Math.round(st.dwellSeconds / 60);
//     } else if (st.dwell) {
//       dwellMinutes = st.dwell;
//     } else if (st.entryTime && st.exitTime) {
//       const diff = new Date(st.exitTime) - new Date(st.entryTime);
//       if (diff > 0) dwellMinutes = Math.round(diff / 60000);
//     }

//     // inRange: true (within range), false (out of range), null (no data / manual inspection)[cite: 5]
//     const inRange = st.inRange !== undefined ? st.inRange : null;
//     const hasDev = inRange === false; // deviation if any tag is out of range[cite: 5]

//     return {
//       ...st,
//       stageId,
//       code,
//       name,
//       group,
//       tagCount,
//       dwell: dwellMinutes,
//       inRange,
//       hasDev,
//       entryTime: formatTimeToLocal(st.entryTime),
//       exitTime: formatTimeToLocal(st.exitTime),
//       rawEntryTime: st.entryTime,
//       rawExitTime: st.exitTime,
//     };
//   };

//   /**
//    * 3. STAGE READINGS API
//    */
//   const fetchStageReadings = useCallback(async (cabinNumber, skid, stageId) => {
//     if (!cabinNumber || cabinNumber === '—' || !stageId) return;

//     setStageLoading(true);
//     try {
//       const readingsEndpoint =
//         AppUrl?.getAnalyticsStageReadings ||
//         AppUrl?.analyticsStageReadings ||
//         '/tags/dashboard/analytics/stage-readings';

//       const params = {
//         cabinNumber,
//         skid,
//         stageId,
//         includeStatus: true,
//       };

//       const res = await doGetApiCall({
//         url: readingsEndpoint,
//         params,
//       });

//       console.log(res, 'stageReadingsApiResponse');

//       const responseData = res?.data?.result ?? res?.data;
//       setStageReadingsData(responseData);
//     } catch (err) {
//       console.error('Failed to fetch stage readings:', err);
//       setStageReadingsData(null);
//     } finally {
//       setStageLoading(false);
//     }
//   }, []);

//   /**
//    * 2. JOURNEY API
//    */
//   const fetchVehicleJourney = useCallback(async (cabinObj) => {
//     if (!cabinObj || !cabinObj.cabinNumber || cabinObj.cabinNumber === '—') return;

//     setJourneyLoading(true);
//     try {
//       const journeyEndpoint =
//         AppUrl?.getAnalyticsJourney ||
//         AppUrl?.analyticsJourney ||
//         '/tags/dashboard/analytics/journey';

//       const params = {
//         cabinNumber: cabinObj.cabinNumber,
//         skid: cabinObj.skid,
//         includeStatus: true,
//       };

//       const res = await doGetApiCall({
//         url: journeyEndpoint,
//         params,
//       });

//       console.log(res, 'journeyApiResponse');

//       const result = res?.data?.result;
//       const lines = result?.lines || {};

//       const ptList = Array.isArray(lines.PT)
//         ? lines.PT.map((st, idx) => normalizeJourneyStage({ ...st, group: 'PT' }, idx))
//         : [];
//       const edList = Array.isArray(lines.ED)
//         ? lines.ED.map((st, idx) => normalizeJourneyStage({ ...st, group: 'ED' }, idx))
//         : [];

//       const allStages = [...ptList, ...edList];
//       // Count deviations based on QID-166 inRange === false[cite: 5]
//       const devCount = allStages.filter((s) => s.inRange === false).length;

//       setSelectedCabin((prev) => {
//         if (!prev) return prev;
//         return {
//           ...prev,
//           hanger: result?.vehicle?.hanger || prev.hanger,
//           type: result?.vehicle?.type || prev.type,
//           colour: result?.vehicle?.colour || prev.colour,
//           entry: formatTimeToLocal(result?.firstEntryTime) || prev.entry,
//           exit: formatTimeToLocal(result?.lastExitTime) || prev.exit,
//           stages: allStages,
//           devCount,
//         };
//       });

//       setCabins((prev) =>
//         prev.map((c) =>
//           c.cabinNumber === cabinObj.cabinNumber && String(c.skid) === String(cabinObj.skid)
//             ? { ...c, stages: allStages, devCount }
//             : c
//         )
//       );

//       // Select first deviated stage, or the first stage by default
//       const firstDevIdx = allStages.findIndex((s) => s.inRange === false);
//       const targetIdx = firstDevIdx >= 0 ? firstDevIdx : 0;
//       setSelectedStageIdx(targetIdx);

//       if (allStages.length > 0) {
//         fetchStageReadings(cabinObj.cabinNumber, cabinObj.skid, allStages[targetIdx].stageId);
//       }
//     } catch (err) {
//       console.error('Failed to fetch vehicle journey:', err);
//     } finally {
//       setJourneyLoading(false);
//     }
//   }, [fetchStageReadings]);

//   /**
//    * Card Selection Handler
//    */
//   const handleSelectCabin = (cabin) => {
//     const normalized = normalizeVehicleItem(cabin);
//     setSelectedCabin(normalized);
//     setSelectedStageIdx(0);
//     setStageReadingsData(null);
//     fetchVehicleJourney(normalized);
//   };

//   /**
//    * Stage Node Click Handler
//    */
//   const handleStageClick = (originalIdx, stageId) => {
//     setSelectedStageIdx(originalIdx);
//     if (selectedCabin) {
//       fetchStageReadings(selectedCabin.cabinNumber, selectedCabin.skid, stageId);
//     }
//   };

//   /**
//    * 1. INITIAL API: Overview Call
//    */
//   const fetchOverviewAnalyticsData = useCallback(async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const res = await doGetApiCall({ url: AppUrl?.getOverviewAnalytics });
//       console.log(res, 'overviewRes (Initial Load)');

//       const responseData = res?.data?.result;
//       const rawList = Array.isArray(responseData?.results)
//         ? responseData.results
//         : Array.isArray(res?.data?.results)
//         ? res.data.results
//         : Array.isArray(responseData)
//         ? responseData
//         : Array.isArray(res?.data)
//         ? res.data
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);

//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } catch (err) {
//       console.error('Failed to fetch initial overview:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to load initial overview records');
//     } finally {
//       setLoading(false);
//     }
//   }, []);

//   useEffect(() => {
//     fetchOverviewAnalyticsData();
//   }, [fetchOverviewAnalyticsData]);

//   /**
//    * 2. SEARCH API
//    */
//   const handleSearch = async () => {
//     const val = searchInput.trim();
//     if (!val) {
//       fetchOverviewAnalyticsData();
//       return;
//     }

//     setLoading(true);
//     setError(null);
//     setSelectedCabin(null);
//     setStageReadingsData(null);

//     try {
//       let fromIso = '';
//       let toIso = '';

//       if (dateMode === 'single') {
//         const d = singleDate || '2026-08-13';
//         fromIso = `${d}T00:00:00.000Z`;
//         toIso = `${d}T23:59:59.999Z`;
//       } else {
//         const f = fromDate || '2026-08-13';
//         const t = toDate || fromDate || '2026-08-13';
//         const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
//         fromIso = `${sortedFrom}T00:00:00.000Z`;
//         toIso = `${sortedTo}T23:59:59.999Z`;
//       }

//       const params = {
//         searchBy: mode,
//         value: val,
//         from: fromIso,
//         to: toIso,
//       };

//       const searchEndpoint =
//         AppUrl?.getAnalyticsSearch ||
//         AppUrl?.analyticsSearch ||
//         '/tags/dashboard/analytics/search';

//       const res = await doGetApiCall({
//         url: searchEndpoint,
//         params,
//       });

//       console.log(res, 'searchApiResponse');

//       const rawData = res?.data?.result ?? res?.data?.results ?? res?.data;
//       const rawList = Array.isArray(rawData)
//         ? rawData
//         : rawData?.results && Array.isArray(rawData.results)
//         ? rawData.results
//         : rawData && typeof rawData === 'object' && rawData.cabinNumber
//         ? [rawData]
//         : [];

//       const normalized = rawList.map(normalizeVehicleItem);
//       setCabins(normalized);
//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } catch (err) {
//       console.error('Vehicle search error:', err);
//       setError(err?.response?.data?.message || err?.message || 'Failed to search vehicles');
//       setCabins([]);
//       setSelectedCabin(null);
//       setStageReadingsData(null);
//     } finally {
//       setLoading(false);
//     }
//   };


//    /**
//    * Helper to trigger binary octet-stream file downloads (.csv)
//    */
//   const downloadBinaryCsvBlob = async (apiResponse, defaultFilename) => {
//     if (!apiResponse) return;

//     const rawData = apiResponse?.data !== undefined ? apiResponse.data : apiResponse;

//     // Check if server returned a JSON error payload instead of binary
//     if (rawData instanceof Blob && rawData.type && rawData.type.includes('application/json')) {
//       try {
//         const text = await rawData.text();
//         const json = JSON.parse(text);
//         alert(json.message || 'No report data found for this selection.');
//         return;
//       } catch {
//         // Continue if it is binary
//       }
//     }

//     // Wrap as binary octet-stream
//     const blob = rawData instanceof Blob
//       ? rawData
//       : new Blob([rawData], { type: 'application/octet-stream' });

//     const url = window.URL.createObjectURL(blob);
//     const link = document.createElement('a');
//     link.href = url;
//     link.download = defaultFilename.endsWith('.csv') ? defaultFilename : `${defaultFilename}.csv`;
//     document.body.appendChild(link);
//     link.click();
//     document.body.removeChild(link);
//     window.URL.revokeObjectURL(url);
//   };

//  /**
//    * 4. CORRELATION CSV REPORT
//    */
//   const handleDownloadCorrelation = async () => {
//     const val = searchInput.trim() || selectedCabin?.cabinNumber || 'all';
//     setIsDownloadMenuOpen(false);

//     try {
//       let fromIso = '';
//       let toIso = '';

//       if (dateMode === 'single') {
//         const d = singleDate || '2026-08-13';
//         fromIso = `${d}T00:00:00.000Z`;
//         toIso = `${d}T23:59:59.999Z`;
//       } else {
//         const f = fromDate || '2026-08-13';
//         const t = toDate || fromDate || '2026-08-13';
//         const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
//         fromIso = `${sortedFrom}T00:00:00.000Z`;
//         toIso = `${sortedTo}T23:59:59.999Z`;
//       }

//       const endpoint =
//         AppUrl?.getAnalyticsCorrelationReport ||
//         AppUrl?.analyticsCorrelationReport ||
//         '/tags/dashboard/analytics/reports/correlation';

//       const res = await doGetApiCall({
//         url: endpoint,
//         params: {
//           searchBy: mode,
//           value: val,
//           from: fromIso,
//           to: toIso,
//         },
//         responseType: 'blob',
//         config: {
//           responseType: 'blob',
//         },
//       });

//       await downloadBinaryCsvBlob(res, `correlation-report-${mode}-${val}.csv`);
//     } catch (err) {
//       console.error('Failed to download correlation report:', err);
//       // Handle Axios error response when responseType is blob
//       if (err?.response?.data instanceof Blob) {
//         try {
//           const errText = await err.response.data.text();
//           const errJson = JSON.parse(errText);
//           alert(errJson.message || 'No correlation data found for the given search.');
//           return;
//         } catch {
//           // Fall through
//         }
//       }
//       alert(err?.response?.data?.message || err?.message || 'Could not download correlation report.');
//     }
//   };

//   /**
//    * 5. PROCESS CSV REPORT
//    */
//   const handleDownloadProcess = async () => {
//     if (!selectedCabin) return;
//     setIsDownloadMenuOpen(false);

//     try {
//       const endpoint =
//         AppUrl?.getAnalyticsProcessReport ||
//         AppUrl?.analyticsProcessReport ||
//         '/tags/dashboard/analytics/reports/process';

//       const res = await doGetApiCall({
//         url: endpoint,
//         params: {
//           cabinNumber: selectedCabin.cabinNumber,
//           skid: selectedCabin.skid,
//         },
//         responseType: 'blob',
//         config: {
//           responseType: 'blob',
//         },
//       });

//       await downloadBinaryCsvBlob(
//         res,
//         `process-report-${selectedCabin.cabinNumber || selectedCabin.skid}.csv`
//       );
//     } catch (err) {
//       console.error('Failed to download process report:', err);
//       // Handle Axios error response when responseType is blob
//       if (err?.response?.data instanceof Blob) {
//         try {
//           const errText = await err.response.data.text();
//           const errJson = JSON.parse(errText);
//           alert(errJson.message || 'No process data found for this vehicle.');
//           return;
//         } catch {
//           // Fall through
//         }
//       }
//       alert(err?.response?.data?.message || err?.message || 'Could not download process report.');
//     }
//   };

//   const activeStage = selectedCabin?.stages?.[selectedStageIdx];
//   const totalDwell =
//     selectedCabin?.totalDwell ??
//     (selectedCabin?.stages?.reduce((acc, cur) => acc + (cur.dwell || 0), 0) || 0);

//   /**
//    * Conveyor rail group renderer using QID-166 inRange
//    */
//   const renderConveyorRail = (groupName) => {
//     if (!selectedCabin || !selectedCabin.stages || selectedCabin.stages.length === 0) return null;
//     const stagesInGroup = selectedCabin.stages
//       .map((stage, idx) => ({ ...stage, originalIdx: idx }))
//       .filter((s) => s.group === groupName);

//     if (stagesInGroup.length === 0) return null;

//     return (
//       <div className={styles['rail-wrap']}>
//         <div className={styles['rail-track']}>
//           <div className={styles['rail-line']} />
//           {stagesInGroup.map((s) => {
//             // Apply QID-166 specification for inRange[cite: 5]
//             let statusClass = styles.none; // default: grey dashed[cite: 5]
//             if (s.code === 'PT-11' || s.code === 'ED-8' || s.inRange === null) {
//               statusClass = styles.none; // grey dashed (inspection / no data)[cite: 5]
//             } else if (s.inRange === false) {
//               statusClass = styles.warn; // red ring (out of range)[cite: 5]
//             } else if (s.inRange === true) {
//               statusClass = styles.ok;   // green ring (within range)[cite: 5]
//             }

//             const isSelected = s.originalIdx === selectedStageIdx;

//             return (
//               <div
//                 key={s.stageId || s.code}
//                 className={`${styles['rail-stage']} ${statusClass} ${
//                   isSelected ? styles.active : ''
//                 }`}
//                 onClick={() => handleStageClick(s.originalIdx, s.stageId)}
//               >
//                 <div className={styles['rail-node']}>{s.code}</div>
//                 <div className={styles['rail-name']}>{s.name}</div>
//                 <div className={styles['rail-dwell']}>
//                   {s.entryTime ? `${s.entryTime.slice(0, 5)}–${(s.exitTime || '').slice(0, 5)}` : '—'}
//                 </div>
//                 <div className={styles['rail-count']}>
//                   {s.tagCount > 0 ? `${s.tagCount} tags` : 'no tags'}
//                 </div>
//               </div>
//             );
//           })}
//         </div>
//       </div>
//     );
//   };

//   return (
//     <div className={styles.pageContainer}>
//       <div className={styles.mainCard}>
//         {/* Header Bar */}
//        <header className={styles.topbar}>
//   {/* Left: Brand Identity */}
//   <div className={styles.brand}>
//     <div className={styles['brand-text']}>PAINT SHOP DIGITAL TWIN</div>
//     <div className={styles['brand-sub']}>Stage Wise · PT / ED Line</div>
//   </div>

//   {/* Center/Main: Consolidated Search Composite Control */}
//   <div className={styles['search-composite']}>
//     <div className={styles['segment-toggle']}>
//       {['hanger', 'skid', 'cabin'].map((k) => (
//         <button
//           key={k}
//           type="button"
//           className={`${styles['segment-btn']} ${mode === k ? styles.active : ''}`}
//           onClick={() => {
//             setMode(k);
//             setSearchInput('');
//           }}
//         >
//           {k.charAt(0).toUpperCase() + k.slice(1)}
//         </button>
//       ))}
//     </div>

//     <div className={styles['search-input-wrap']}>
//       <svg className={styles['search-icon']} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//         <circle cx="11" cy="11" r="7" />
//         <path d="M21 21l-4.3-4.3" />
//       </svg>
//       <input
//         type="text"
//         placeholder={`Enter ${mode} ID...`}
//         value={searchInput}
//         onChange={(e) => setSearchInput(e.target.value)}
//         onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
//       />
//     </div>

//     <button
//       type="button"
//       className={styles['search-submit-btn']}
//       onClick={handleSearch}
//     >
//       Search
//     </button>
//   </div>

//   {/* Right: Date Filter & Actions */}
//   <div className={styles['actions-cluster']}>
//     <div className={styles['date-composite']}>
//       <div className={styles['date-mode-toggle']}>
//         <button
//           type="button"
//           className={`${styles['date-mode-btn']} ${dateMode === 'single' ? styles.active : ''}`}
//           onClick={() => setDateMode('single')}
//         >
//           Day
//         </button>
//         <button
//           type="button"
//           className={`${styles['date-mode-btn']} ${dateMode === 'range' ? styles.active : ''}`}
//           onClick={() => setDateMode('range')}
//         >
//           Range
//         </button>
//       </div>

//       <div className={styles['date-fields']}>
//         <svg className={styles['calendar-icon']} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//           <rect x="3" y="5" width="18" height="16" rx="2" />
//           <path d="M3 10h18M8 3v4M16 3v4" />
//         </svg>

//         {dateMode === 'single' ? (
//           <input
//             type="date"
//             className={styles['date-input']}
//             value={singleDate}
//             onChange={(e) => setSingleDate(e.target.value)}
//           />
//         ) : (
//           <div className={styles['range-pair']}>
//             <input
//               type="date"
//               className={styles['date-input']}
//               value={fromDate}
//               onChange={(e) => setFromDate(e.target.value)}
//             />
//             {/* <span className={styles['range-sep']}>–</span> */}
//             <input
//               type="date"
//               className={styles['date-input']}
//               value={toDate}
//               onChange={(e) => setToDate(e.target.value)}
//             />
//           </div>
//         )}
//       </div>
//     </div>

//     {/* Export Dropdown */}
//     <div className={styles['download-wrap']} ref={downloadWrapRef}>
//       <button
//         className={styles['btn-export']}
//         type="button"
//         onClick={() => setIsDownloadMenuOpen((prev) => !prev)}
//       >
//         <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//           <path d="M12 3v13m0 0l-4-4m4 4l4-4M4 21h16" />
//         </svg>
//         <span>Export</span>
//         <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
//           <path d="M6 9l6 6 6-6" />
//         </svg>
//       </button>

//       <div className={`${styles['download-menu']} ${isDownloadMenuOpen ? styles.open : ''}`}>
//         <button
//           className={styles['dm-item']}
//           type="button"
//           onClick={handleDownloadCorrelation}
//           disabled={cabins.length === 0}
//         >
//           <div className={`${styles['dm-item-icon']} ${styles.corr}`}>⇄</div>
//           <div>
//             <div className={styles['dm-item-title']}>Correlation Report</div>
//             <div className={styles['dm-item-sub']}>Vehicle, Hanger, Skid mapping (.csv)</div>
//           </div>
//         </button>

//         <button
//           className={styles['dm-item']}
//           type="button"
//           onClick={handleDownloadProcess}
//           disabled={!selectedCabin}
//         >
//           <div className={`${styles['dm-item-icon']} ${styles.proc}`}>≣</div>
//           <div>
//             <div className={styles['dm-item-title']}>Process Report</div>
//             <div className={styles['dm-item-sub']}>
//               {selectedCabin
//                 ? `All tag readings for ${selectedCabin.cabin} (.csv)`
//                 : 'Select a cabin on the left first'}
//             </div>
//           </div>
//         </button>
//       </div>
//     </div>
//   </div>
// </header>

//         {/* Workspace */}
//         <main className={styles.workspace}>
//           {/* Left Occurrences Pane */}
//           <section className={styles['results-pane']}>
//             <div className={styles['results-header']}>
//               <h2>{mode} occurrences</h2>
//               <span className={styles['results-count']}>
//                 {loading ? 'Loading...' : `${cabins.length} records`}
//               </span>
//             </div>
//             <div className={styles['results-list']}>
//               {loading ? (
//                 <div className={styles['empty-list']}>Fetching data...</div>
//               ) : error ? (
//                 <div className={styles['empty-list']} style={{ color: 'var(--danger)' }}>
//                   {error}
//                 </div>
//               ) : cabins.length === 0 ? (
//                 <div className={styles['empty-list']}>
//                   No vehicles found.<br />Try adjusting your search criteria.
//                 </div>
//               ) : (
//                 cabins.map((c, index) => {
//                   const isSelected = selectedCabin?.passKey === c.passKey;
//                   const devCount = c.devCount || 0;
//                   return (
//                     <div
//                       key={c.passKey || `${c.cabin}-${index}`}
//                       className={`${styles['result-card']} ${isSelected ? styles.selected : ''}`}
//                       onClick={() => handleSelectCabin(c)}
//                     >
//                       <div className={styles['rc-top']}>
//                         <span className={styles['rc-id']}>{c.cabin}</span>
//                         <span className={`${styles['rc-dot']} ${devCount > 0 ? styles.warn : styles.ok}`} />
//                       </div>
//                       <div className={styles['rc-meta']}>
//                         {mode === 'hanger' && <span className={styles.mono}>Skid <b>{c.skid}</b></span>}
//                         {mode === 'skid' && <span className={styles.mono}>Hanger <b>{c.hanger}</b></span>}
//                         {mode === 'cabin' && <span className={styles.mono}>{c.hanger} / {c.skid}</span>}
//                         <span>{c.colour}</span>
//                         <span>{c.type}</span>
//                       </div>
//                       <div className={styles['rc-time']}>
//                         {c.date || '—'} {c.entry ? `· in ${c.entry}` : ''}
//                       </div>
//                     </div>
//                   );
//                 })
//               )}
//             </div>
//           </section>

//           {/* Right Detail Pane */}
//           <section className={styles['detail-pane']}>
//             {!selectedCabin ? (
//               <div className={styles['detail-placeholder']}>
//                 <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
//                   <circle cx="11" cy="11" r="7" />
//                   <path d="M21 21l-4.3-4.3" />
//                 </svg>
//                 <div className={styles['ph-title']}>Select a record to view its journey</div>
//                 <div className={styles['ph-sub']}>
//                   Pick a vehicle row on the left to inspect its complete stage journey and process tag readings.
//                 </div>
//               </div>
//             ) : (
//               <>
//                 <div className={styles['detail-header']}>
//                   <div>
//                     <div className={styles['dh-id']}>{selectedCabin.cabin}</div>
//                     <div className={styles['dh-tags']}>
//                       <span className={styles['dh-tag']}>Hanger <b>{selectedCabin.hanger || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Skid <b>{selectedCabin.skid || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Type <b>{selectedCabin.type || '—'}</b></span>
//                       <span className={styles['dh-tag']}>Colour <b>{selectedCabin.colour || '—'}</b></span>
//                       <span className={styles['dh-tag']}>
//                         Entry <b>{selectedCabin.entry || '—'}</b> {selectedCabin.date ? `· ${selectedCabin.date}` : ''}
//                       </span>
//                     </div>
//                   </div>
//                   <div className={styles['dh-stats']}>
//                     <div className={styles['dh-stat']}>
//                       <div className={styles.num}>{totalDwell}m</div>
//                       <div className={styles.lbl}>Total time</div>
//                     </div>
//                     <div className={`${styles['dh-stat']} ${(selectedCabin.devCount || 0) > 0 ? styles.danger : styles.ok}`}>
//                       <div className={styles.num}>{selectedCabin.stages?.length || selectedCabin.stagesSeen || 0}</div>
//                       <div className={styles.lbl}>Stages Seen</div>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Conveyor Rail Stage Tracks */}
//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — PT (Pre-Treatment)</div>
//                   {journeyLoading ? (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '12px 0' }}>
//                       Loading journey stages for {selectedCabin.cabin}...
//                     </div>
//                   ) : renderConveyorRail('PT') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No PT stages recorded for this vehicle.
//                     </div>
//                   )}
//                 </div>

//                 <div className={styles['rail-section']}>
//                   <div className={styles['section-label']}>Stage journey — ED (Electro-Deposition)</div>
//                   {!journeyLoading && (renderConveyorRail('ED') || (
//                     <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
//                       No ED stages recorded for this vehicle.
//                     </div>
//                   ))}
//                 </div>

//                 {/* Stage process tags */}
//                 {activeStage && (
//                   <div className={styles['param-section']}>
//                     <div className={styles['section-label']}>
//                       Process tags — {stageReadingsData?.name || activeStage.name}
//                     </div>
//                     <div className={styles['param-panel']}>
//                       <div className={styles['param-panel-head']}>
//                         <div>
//                           <div className={styles['pph-title']}>
//                             {stageReadingsData?.stageId || activeStage.code} — {stageReadingsData?.name || activeStage.name}
//                           </div>
//                           <div className={styles['pph-sub']}>
//                             {stageReadingsData?.window?.entryTime
//                               ? `${formatTimeToLocal(stageReadingsData.window.entryTime)} → ${formatTimeToLocal(stageReadingsData.window.exitTime)}`
//                               : activeStage.entryTime
//                               ? `${activeStage.entryTime} → ${activeStage.exitTime || ''}`
//                               : ''}
//                           </div>
//                         </div>
//                         {stageReadingsData?.tags && stageReadingsData.tags.length > 0 && (
//                           <div className={styles['pph-counts']}>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'live').length} Live
//                             </span>
//                             <span>
//                               {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'log').length} Log
//                             </span>
//                           </div>
//                         )}
//                       </div>

//                       {stageLoading ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12px' }}>
//                           Loading tag readings...
//                         </div>
//                       ) : activeStage.code === 'PT-11' || activeStage.code === 'ED-8' ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           Manual visual inspection checkpoint. No PLC tag readings recorded for this stage.
//                         </div>
//                       ) : !stageReadingsData?.tags || stageReadingsData.tags.length === 0 ? (
//                         <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
//                           No process tags recorded for this stage.
//                         </div>
//                       ) : (
//                         <div style={{ overflowX: 'auto' }}>
//                           <table className={styles['param-table']}>
//                             <thead>
//                               <tr>
//                                 <th>Tag</th>
//                                 <th>Reference Range</th>
//                                 <th>Reading</th>
//                                 <th>Source</th>
//                                 <th>Process</th>
//                               </tr>
//                             </thead>
//                             <tbody>
//                              {stageReadingsData.tags.map((t, idx) => {
//                                 const hasData =
//                                   t.status !== 'no_data' &&
//                                   ((t.avg !== null && t.avg !== undefined) || t.value !== undefined);
//                                 const displayValue = hasData
//                                   ? t.value !== undefined
//                                     ? t.value
//                                     : t.avg
//                                   : null;
//                                 const readingText =
//                                   displayValue !== null ? `${displayValue} ${t.unit || ''}`.trim() : '—';

//                                 // Support both "in_range" from the new doc and legacy "within_range"
//                                 const isOutOfRange = t.status === 'out_of_range';
//                                 const isInRange = t.status === 'in_range' || t.status === 'within_range';

//                                 return (
//                                   <tr key={t.tagId ? `${t.tagId}-${idx}` : `${t.name}-${idx}`}>
//                                     <td>
//                                       <div className={styles['tag-name']}>{t.name || 'Unnamed Tag'}</div>
//                                       {/* <div className={styles['tag-id']} title={t.tagId}>{t.tagId || '—'}</div> */}
//                                     </td>
//                                     <td>
//                                       <div className={styles['tag-range']}>
//                                         {formatRangeDisplay(t.range, t.unit)}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <div
//                                         className={`${styles['tag-reading']} ${
//                                           isOutOfRange ? styles.warn : isInRange ? styles.ok : ''
//                                         }`}
//                                       >
//                                         {readingText}
//                                       </div>
//                                     </td>
//                                     <td>
//                                       <span className={`${styles.chip} ${styles['src-live']}`}>
//                                         {t.source || 'Live'}
//                                       </span>
//                                     </td>
//                                     <td>
//                                       {isOutOfRange ? (
//                                         <span className={`${styles.chip} ${styles['dev-out']}`}>⚠ Out of range</span>
//                                       ) : isInRange ? (
//                                         <span className={`${styles.chip} ${styles['dev-in']}`}>In range</span>
//                                       ) : (
//                                         <span className={`${styles.chip} ${styles['src-none']}`}>No data</span>
//                                       )}
//                                     </td>
//                                   </tr>
//                                 );
//                               })}
//                             </tbody>
//                           </table>
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                 )}
//               </>
//             )}
//           </section>
//         </main>
//       </div>
//     </div>
//   );
// }

// last deployed code
import React, { useState, useEffect, useRef, useCallback } from 'react';
import styles from './analyticsDashboard.module.css';
import { doGetApiCall } from '../../../../utils/ClonosApi';
import AppUrl from '../../../../utils/AppUrl';

/* Helper to get today's local date in YYYY-MM-DD format */
export const getTodayDateString = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

/* Helper to convert UTC ISO string to readable local time (HH:mm:ss) */
export const formatTimeToLocal = (isoString) => {
  if (!isoString) return '—';
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return String(isoString);
    return d.toTimeString().slice(0, 8);
  } catch {
    return isoString.includes('T') ? isoString.split('T')[1].slice(0, 8) : isoString;
  }
};

/* Helper to extract YYYY-MM-DD from an ISO string */
export const formatDateString = (isoString) => {
  if (!isoString) return '—';
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return String(isoString);
    return d.toISOString().slice(0, 10);
  } catch {
    return String(isoString).slice(0, 10);
  }
};

/* Helper to safely format range whether it is an Object or a String */
export const formatRangeDisplay = (range, fallbackUnit = '') => {
  if (!range) return '—';

  if (typeof range === 'object') {
    const min = range.min;
    const max = range.max;
    const unit = range.unit || fallbackUnit || '';

    const hasMin = min !== undefined && min !== null && min !== -Infinity;
    const hasMax = max !== undefined && max !== null && max !== Infinity;

    if (hasMin && hasMax) return `${min} - ${max} ${unit}`.trim();
    if (hasMin) return `> ${min} ${unit}`.trim();
    if (hasMax) return `< ${max} ${unit}`.trim();
    return '—';
  }

  return `${range} ${fallbackUnit || ''}`.trim();
};

export default function AnalyticsDashboard() {
  /* Search & Filter Controls */
  const [mode, setMode] = useState('cabin');
  const [searchInput, setSearchInput] = useState('');
  const [dateMode, setDateMode] = useState('single');

  /* Defaults to current local date */
  const [singleDate, setSingleDate] = useState(() => getTodayDateString());
  const [fromDate, setFromDate] = useState(() => getTodayDateString());
  const [toDate, setToDate] = useState(() => getTodayDateString());

  /* Live API State */
  const [cabins, setCabins] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  /* Vehicle Selection & Journey States */
  const [selectedCabin, setSelectedCabin] = useState(null);
  const [journeyLoading, setJourneyLoading] = useState(false);
  const [selectedStageIdx, setSelectedStageIdx] = useState(0);

  /* Stage Readings API State */
  const [stageReadingsData, setStageReadingsData] = useState(null);
  const [stageLoading, setStageLoading] = useState(false);

  /* Download Menu State */
  const [isDownloadMenuOpen, setIsDownloadMenuOpen] = useState(false);
  const downloadWrapRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (downloadWrapRef.current && !downloadWrapRef.current.contains(e.target)) {
        setIsDownloadMenuOpen(false);
      }
    }
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  /**
   * Normalizer for Vehicle list items
   */
  const normalizeVehicleItem = (item) => {
    const cabin = item.cabinNumber || item.cabin || '—';
    const hanger = item.hanger || '—';
    const skid = item.skid !== undefined && item.skid !== null ? String(item.skid) : '—';
    const type = item.type || item.bodyType || '—';
    const colour = item.colour || item.color || '—';
    const passKey = item.passKey || `${cabin}|${skid}`;

    const rawEntry = item.firstEntryTime || item.firstEntry || item.entryTime || item.entry || item.createdAt;
    const rawExit = item.lastExitTime || item.lastExit || item.exitTime || item.exit;

    const date = formatDateString(rawEntry || item.date);
    const entry = formatTimeToLocal(rawEntry);
    const exit = formatTimeToLocal(rawExit);

    let totalDwellMinutes = 0;
    if (rawEntry && rawExit) {
      const diffMs = new Date(rawExit) - new Date(rawEntry);
      if (diffMs > 0) {
        totalDwellMinutes = Math.round(diffMs / (1000 * 60));
      }
    }

    return {
      ...item,
      passKey,
      cabin,
      cabinNumber: cabin,
      hanger,
      skid,
      type,
      colour,
      date,
      entry,
      exit,
      totalDwell: totalDwellMinutes,
      stagesSeen: item.stagesSeen ?? item.stages?.length ?? 0,
      stages: item.stages || [],
      devCount: item.devCount || 0,
    };
  };

  /**
   * Normalizer for individual stage objects
   */
  const normalizeJourneyStage = (st, idx) => {
    console.log(st,"responsestjourney")
    const stageId = st.stageId || st.id || st.code || `ST-${idx + 1}`;
    const code = st.code || st.stageCode || stageId;
    const name = st.name || st.stageName || 'Stage';
    const group = st.group || (code.toUpperCase().startsWith('ED') ? 'ED' : 'PT');

    const tagCount = st.tagCount !== undefined
      ? st.tagCount
      : (st.readings?.length ?? st.tags?.length ?? 0);
    const totalTime = st.dwellSeconds
    let dwellMinutes = 0;
    if (st.dwellSeconds !== undefined && st.dwellSeconds !== null) {
      dwellMinutes = Math.round(st.dwellSeconds / 60);
    } else if (st.dwell) {
      dwellMinutes = st.dwell;
    } else if (st.entryTime && st.exitTime) {
      const diff = new Date(st.exitTime) - new Date(st.entryTime);
      if (diff > 0) dwellMinutes = Math.round(diff / 60000);
    }

    const inRange = st.inRange !== undefined ? st.inRange : null;
    const hasDev = inRange === false;

    return {
      ...st,
      stageId,
      code,
      name,
      group,
      tagCount,
      totalTime,
      dwell: dwellMinutes,
      inRange,
      hasDev,
      entryTime: formatTimeToLocal(st.entryTime),
      exitTime: formatTimeToLocal(st.exitTime),
      rawEntryTime: st.entryTime,
      rawExitTime: st.exitTime,
    };
  };

  /**
   * 3. STAGE READINGS API
   */
  const fetchStageReadings = useCallback(async (cabinNumber, skid, stageId) => {
    if (!cabinNumber || cabinNumber === '—' || !stageId) return;

    setStageLoading(true);
    try {
      const readingsEndpoint =
        AppUrl?.getAnalyticsStageReadings ||
        AppUrl?.analyticsStageReadings ||
        '/tags/dashboard/analytics/stage-readings';

      const params = {
        cabinNumber,
        skid,
        stageId,
      };

      const res = await doGetApiCall({
        url: readingsEndpoint,
        params,
      });

      console.log(res, 'stageReadingsApiResponse');

      const responseData = res?.data?.result ?? res?.data;
      setStageReadingsData(responseData);
    } catch (err) {
      console.error('Failed to fetch stage readings:', err);
      setStageReadingsData(null);
    } finally {
      setStageLoading(false);
    }
  }, []);

  /**
   * 2. JOURNEY API
   */
  const fetchVehicleJourney = useCallback(async (cabinObj) => {
    if (!cabinObj || !cabinObj.cabinNumber || cabinObj.cabinNumber === '—') return;

    setJourneyLoading(true);
    try {
      const journeyEndpoint =
        AppUrl?.getAnalyticsJourney ||
        AppUrl?.analyticsJourney ||
        '/tags/dashboard/analytics/journey';

      const params = {
        cabinNumber: cabinObj.cabinNumber,
        skid: cabinObj.skid,
        includeStatus: true,
      };

      const res = await doGetApiCall({
        url: journeyEndpoint,
        params,
      });

      console.log(res, 'journeyApiResponse');

      const result = res?.data?.result;
      const lines = result?.lines || {};

      const ptList = Array.isArray(lines.PT)
        ? lines.PT.map((st, idx) => normalizeJourneyStage({ ...st, group: 'PT' }, idx))
        : [];
      const edList = Array.isArray(lines.ED)
        ? lines.ED.map((st, idx) => normalizeJourneyStage({ ...st, group: 'ED' }, idx))
        : [];

      const allStages = [...ptList, ...edList];
      const devCount = allStages.filter((s) => s.inRange === false).length;

      setSelectedCabin((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          hanger: result?.vehicle?.hanger || prev.hanger,
          type: result?.vehicle?.type || prev.type,
          colour: result?.vehicle?.colour || prev.colour,
          entry: formatTimeToLocal(result?.firstEntryTime) || prev.entry,
          exit: formatTimeToLocal(result?.lastExitTime) || prev.exit,
          stages: allStages,
          devCount,
        };
      });

      setCabins((prev) =>
        prev.map((c) =>
          c.cabinNumber === cabinObj.cabinNumber && String(c.skid) === String(cabinObj.skid)
            ? { ...c, stages: allStages, devCount }
            : c
        )
      );

      const firstDevIdx = allStages.findIndex((s) => s.inRange === false);
      const targetIdx = firstDevIdx >= 0 ? firstDevIdx : 0;
      setSelectedStageIdx(targetIdx);

      if (allStages.length > 0) {
        fetchStageReadings(cabinObj.cabinNumber, cabinObj.skid, allStages[targetIdx].stageId);
      }
    } catch (err) {
      console.error('Failed to fetch vehicle journey:', err);
    } finally {
      setJourneyLoading(false);
    }
  }, [fetchStageReadings]);

  /**
   * Card Selection Handler
   */
  const handleSelectCabin = (cabin) => {
    const normalized = normalizeVehicleItem(cabin);
    setSelectedCabin(normalized);
    setSelectedStageIdx(0);
    setStageReadingsData(null);
    fetchVehicleJourney(normalized);
  };

  /**
   * Stage Node Click Handler
   */
  const handleStageClick = (originalIdx, stageId) => {
    setSelectedStageIdx(originalIdx);
    if (selectedCabin) {
      fetchStageReadings(selectedCabin.cabinNumber, selectedCabin.skid, stageId);
    }
  };

  /**
   * 1. INITIAL API: Overview Call
   */
  const fetchOverviewAnalyticsData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await doGetApiCall({ url: AppUrl?.getOverviewAnalytics });
      console.log(res, 'overviewRes (Initial Load)');

      const responseData = res?.data?.result;
      const rawList = Array.isArray(responseData?.results)
        ? responseData.results
        : Array.isArray(res?.data?.results)
        ? res.data.results
        : Array.isArray(responseData)
        ? responseData
        : Array.isArray(res?.data)
        ? res.data
        : [];

      const normalized = rawList.map(normalizeVehicleItem);
      setCabins(normalized);

      setSelectedCabin(null);
      setStageReadingsData(null);
    } catch (err) {
      console.error('Failed to fetch initial overview:', err);
      setError(err?.response?.data?.message || err?.message || 'Failed to load initial overview records');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchOverviewAnalyticsData();
  }, [fetchOverviewAnalyticsData]);

  /**
   * 2. SEARCH API
   */
  const handleSearch = async () => {
    const val = searchInput.trim();
    if (!val) {
      fetchOverviewAnalyticsData();
      return;
    }

    setLoading(true);
    setError(null);
    setSelectedCabin(null);
    setStageReadingsData(null);

    try {
      const params = {
        searchBy: mode,
        value: val,
      };

      if (dateMode === 'single' && singleDate) {
        params.from = `${singleDate}T00:00:00.000Z`;
        params.to = `${singleDate}T23:59:59.999Z`;
      } else if (dateMode === 'range' && (fromDate || toDate)) {
        const f = fromDate || toDate;
        const t = toDate || fromDate;
        const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
        params.from = `${sortedFrom}T00:00:00.000Z`;
        params.to = `${sortedTo}T23:59:59.999Z`;
      }

      const searchEndpoint =
        AppUrl?.getAnalyticsSearch ||
        AppUrl?.analyticsSearch ||
        '/tags/dashboard/analytics/search';

      const res = await doGetApiCall({
        url: searchEndpoint,
        params,
      });

      console.log(res, 'searchApiResponse');

      const rawData = res?.data?.result ?? res?.data?.results ?? res?.data;
      const rawList = Array.isArray(rawData)
        ? rawData
        : rawData?.results && Array.isArray(rawData.results)
        ? rawData.results
        : rawData && typeof rawData === 'object' && rawData.cabinNumber
        ? [rawData]
        : [];

      const normalized = rawList.map(normalizeVehicleItem);
      setCabins(normalized);
      setSelectedCabin(null);
      setStageReadingsData(null);
    } catch (err) {
      console.error('Vehicle search error:', err);
      setError(err?.response?.data?.message || err?.message || 'Failed to search vehicles');
      setCabins([]);
      setSelectedCabin(null);
      setStageReadingsData(null);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Helper to trigger binary octet-stream file downloads (.csv)
   */
  const downloadBinaryCsvBlob = async (apiResponse, defaultFilename) => {
    if (!apiResponse) return;

    const rawData = apiResponse?.data !== undefined ? apiResponse.data : apiResponse;

    // Check if server returned a plain JS error object
    if (rawData && typeof rawData === 'object' && !(rawData instanceof Blob)) {
      if (rawData.message || rawData.errorInfo) {
        return;
      }
    }

    // Check if server returned error JSON wrapped in a Blob
    if (rawData instanceof Blob) {
      if (rawData.type && rawData.type.includes('application/json')) {
        try {
          const text = await rawData.text();
          JSON.parse(text);
          return;
        } catch {
          // If parse fails, proceed
        }
      }

      if (rawData.size < 1000) {
        try {
          const text = await rawData.text();
          if (text.trim().startsWith('{') && text.includes('"message"')) {
            return;
          }
        } catch {
          // Proceed if actually binary
        }
      }
    }

    const blob = rawData instanceof Blob
      ? rawData
      : new Blob([rawData], { type: 'application/octet-stream' });

    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = defaultFilename.endsWith('.csv') ? defaultFilename : `${defaultFilename}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  /**
   * 4. CORRELATION CSV REPORT
   */
  const handleDownloadCorrelation = async () => {
    const val = searchInput.trim() || selectedCabin?.cabinNumber || 'all';
    setIsDownloadMenuOpen(false);

    try {
      const params = {
        searchBy: mode,
        value: val,
      };

      if (dateMode === 'single' && singleDate) {
        params.from = `${singleDate}T00:00:00.000Z`;
        params.to = `${singleDate}T23:59:59.999Z`;
      } else if (dateMode === 'range' && (fromDate || toDate)) {
        const f = fromDate || toDate;
        const t = toDate || fromDate;
        const [sortedFrom, sortedTo] = f > t ? [t, f] : [f, t];
        params.from = `${sortedFrom}T00:00:00.000Z`;
        params.to = `${sortedTo}T23:59:59.999Z`;
      }

      const endpoint =
        AppUrl?.getAnalyticsCorrelationReport ||
        AppUrl?.analyticsCorrelationReport ||
        '/tags/dashboard/analytics/reports/correlation';

      const res = await doGetApiCall({
        url: endpoint,
        params,
        responseType: 'blob',
        config: {
          responseType: 'blob',
        },
      });

      console.log(res, 'binaryCorrelationCsvRes');
      await downloadBinaryCsvBlob(res, `correlation-report-${mode}-${val}.csv`);
    } catch (err) {
      console.error('Failed to download correlation report:', err);
      if (err?.response?.data instanceof Blob) {
        try {
          await err.response.data.text();
          return;
        } catch {
          // Fall through
        }
      }
    }
  };

  /**
   * 5. PROCESS CSV REPORT
   */
  const handleDownloadProcess = async () => {
    if (!selectedCabin) return;
    setIsDownloadMenuOpen(false);

    try {
      const endpoint =
        AppUrl?.getAnalyticsProcessReport ||
        AppUrl?.analyticsProcessReport ||
        '/tags/dashboard/analytics/reports/process';

      const res = await doGetApiCall({
        url: endpoint,
        params: {
          cabinNumber: selectedCabin.cabinNumber,
          skid: selectedCabin.skid,
        },
        responseType: 'blob',
        config: {
          responseType: 'blob',
        },
      });

      console.log(res, 'binaryProcessCsvRes');
      await downloadBinaryCsvBlob(
        res,
        `process-report-${selectedCabin.cabinNumber || selectedCabin.skid}.csv`
      );
    } catch (err) {
      console.error('Failed to download process report:', err);
      if (err?.response?.data instanceof Blob) {
        try {
          await err.response.data.text();
          return;
        } catch {
          // Fall through
        }
      }
    }
  };

  const activeStage = selectedCabin?.stages?.[selectedStageIdx];
  const totalDwell =
    selectedCabin?.totalDwell ??
    (selectedCabin?.stages?.reduce((acc, cur) => acc + (cur.dwell || 0), 0) || 0);

  /**
   * Conveyor rail group renderer using QID-166 inRange
   */
  const renderConveyorRail = (groupName) => {
    if (!selectedCabin || !selectedCabin.stages || selectedCabin.stages.length === 0) return null;
    const stagesInGroup = selectedCabin.stages
      .map((stage, idx) => ({ ...stage, originalIdx: idx }))
      .filter((s) => s.group === groupName);

    if (stagesInGroup.length === 0) return null;

    return (
      <div className={styles['rail-wrap']}>
        <div className={styles['rail-track']}>
          <div className={styles['rail-line']} />
          {stagesInGroup.map((s) => {
            let statusClass = styles.none;
            if (s.code === 'PT-11' || s.code === 'ED-8' || s.inRange === null) {
              statusClass = styles.none;
            } else if (s.inRange === false) {
              statusClass = styles.warn;
            } else if (s.inRange === true) {
              statusClass = styles.ok;
            }
            console.log(s,"renderrail")
            const isSelected = s.originalIdx === selectedStageIdx;
            const dwellDisplay =
              s.dwellSeconds !== undefined && s.dwellSeconds !== null
                ? `${Math.floor(s.dwellSeconds / 60)}m ${s.dwellSeconds % 60}s`
                : '—';
            return (
              <div
                key={s.stageId || s.code}
                className={`${styles['rail-stage']} ${statusClass} ${
                  isSelected ? styles.active : ''
                }`}
                onClick={() => handleStageClick(s.originalIdx, s.stageId)}
              >
                <div className={styles['rail-node']}>{s.code}</div>
                <div className={styles['rail-name']}>{s.name}</div>
                <div className={styles['rail-dwell']}>{dwellDisplay}</div>
                <div className={styles['rail-count']}>
                  {s.tagCount > 0 ? `${s.tagCount} tags` : 'no tags'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className={styles.pageContainer}>
      <div className={styles.mainCard}>
        {/* Consolidated Header Bar */}
        <header className={styles.topbar}>
          {/* Brand Identity */}
          <div className={styles.brand}>
            <div className={styles['brand-text']}>PAINT SHOP DIGITAL TWIN</div>
            <div className={styles['brand-sub']}>Stage Wise · PT / ED Line</div>
          </div>

          {/* Search Composite Bar */}
          <div className={styles['search-composite']}>
            <div className={styles['segment-toggle']}>
              {['hanger', 'skid', 'cabin'].map((k) => (
                <button
                  key={k}
                  type="button"
                  className={`${styles['segment-btn']} ${mode === k ? styles.active : ''}`}
                  onClick={() => {
                    setMode(k);
                    // setSearchInput('');
                  }}
                >
                  {k.charAt(0).toUpperCase() + k.slice(1)}
                </button>
              ))}
            </div>

            <div className={styles['search-input-wrap']}>
              <svg className={styles['search-icon']} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="7" />
                <path d="M21 21l-4.3-4.3" />
              </svg>
              <input
                type="text"
                placeholder={`Enter ${mode} ID...`}
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>

            <button
              type="button"
              className={styles['search-submit-btn']}
              onClick={handleSearch}
            >
              Search
            </button>
          </div>

          {/* Actions Cluster: Compact Date & Export */}
          <div className={styles['actions-cluster']}>
            <div className={styles['date-composite']}>
              <div className={styles['date-mode-toggle']}>
                <button
                  type="button"
                  className={`${styles['date-mode-btn']} ${dateMode === 'single' ? styles.active : ''}`}
                  onClick={() => setDateMode('single')}
                >
                  Day
                </button>
                <button
                  type="button"
                  className={`${styles['date-mode-btn']} ${dateMode === 'range' ? styles.active : ''}`}
                  onClick={() => setDateMode('range')}
                >
                  Range
                </button>
              </div>

              <div className={styles['date-fields']}>
                {dateMode === 'single' ? (
                  <input
                    type="date"
                    className={styles['date-input']}
                    value={singleDate}
                    onChange={(e) => setSingleDate(e.target.value)}
                  />
                ) : (
                  <div className={styles['range-pair']}>
                    <input
                      type="date"
                      className={styles['date-input']}
                      value={fromDate}
                      onChange={(e) => setFromDate(e.target.value)}
                    />
                    <span className={styles['range-sep']}>–</span>
                    <input
                      type="date"
                      className={styles['date-input']}
                      value={toDate}
                      onChange={(e) => setToDate(e.target.value)}
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Export Dropdown */}
            <div className={styles['download-wrap']} ref={downloadWrapRef}>
              <button
                className={styles['btn-export']}
                type="button"
                onClick={() => setIsDownloadMenuOpen((prev) => !prev)}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 3v13m0 0l-4-4m4 4l4-4M4 21h16" />
                </svg>
                <span>Export</span>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>

              <div className={`${styles['download-menu']} ${isDownloadMenuOpen ? styles.open : ''}`}>
                <button
                  className={styles['dm-item']}
                  type="button"
                  onClick={handleDownloadCorrelation}
                  disabled={cabins.length === 0}
                >
                  <div className={`${styles['dm-item-icon']} ${styles.corr}`}>⇄</div>
                  <div>
                    <div className={styles['dm-item-title']}>Correlation Report</div>
                    <div className={styles['dm-item-sub']}>Vehicle, Hanger, Skid mapping (.csv)</div>
                  </div>
                </button>

                <button
                  className={styles['dm-item']}
                  type="button"
                  onClick={handleDownloadProcess}
                  disabled={!selectedCabin}
                >
                  <div className={`${styles['dm-item-icon']} ${styles.proc}`}>≣</div>
                  <div>
                    <div className={styles['dm-item-title']}>Process Report</div>
                    <div className={styles['dm-item-sub']}>
                      {selectedCabin
                        ? `All tag readings for ${selectedCabin.cabin} (.csv)`
                        : 'Select a cabin on the left first'}
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Workspace */}
        <main className={styles.workspace}>
          {/* Left Occurrences Pane */}
          <section className={styles['results-pane']}>
            <div className={styles['results-header']}>
              <h2>{mode} occurrences</h2>
              <span className={styles['results-count']}>
                {loading ? 'Loading...' : `${cabins.length} records`}
              </span>
            </div>
            <div className={styles['results-list']}>
              {loading ? (
                <div className={styles['empty-list']}>Fetching data...</div>
              ) : error ? (
                <div className={styles['empty-list']} style={{ color: 'var(--danger)' }}>
                  {error}
                </div>
              ) : cabins.length === 0 ? (
                <div className={styles['empty-list']}>
                  No vehicles found.<br />Try adjusting your search criteria.
                </div>
              ) : (
                cabins.map((c, index) => {
                  const isSelected = selectedCabin?.passKey === c.passKey;
                  const devCount = c.devCount || 0;
                  return (
                    <div
                      key={c.passKey || `${c.cabin}-${index}`}
                      className={`${styles['result-card']} ${isSelected ? styles.selected : ''}`}
                      onClick={() => handleSelectCabin(c)}
                    >
                      <div className={styles['rc-top']}>
                        <span className={styles['rc-id']}>{c.cabin}</span>
                        <span className={`${styles['rc-dot']} ${devCount > 0 ? styles.warn : styles.ok}`} />
                      </div>
                      <div className={styles['rc-meta']}>
                        {mode === 'hanger' && <span className={styles.mono}>Hanger <b>{c.hanger}</b></span>}
                        {mode === 'skid' && <span className={styles.mono}>Skid <b>{c.skid}</b></span>}
                        {mode === 'cabin' && <span className={styles.mono}>{c.hanger} / {c.skid}</span>}
                        <span>{c.colour}</span>
                        <span>{c.type}</span>
                      </div>
                      <div className={styles['rc-time']}>
                        {c.date || '—'} {c.entry ? `· in ${c.entry}` : ''}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          {/* Right Detail Pane */}
          <section className={styles['detail-pane']}>
            {!selectedCabin ? (
              <div className={styles['detail-placeholder']}>
                <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
                  <circle cx="11" cy="11" r="7" />
                  <path d="M21 21l-4.3-4.3" />
                </svg>
                <div className={styles['ph-title']}>Select a record to view its journey</div>
                <div className={styles['ph-sub']}>
                  Pick a vehicle row on the left to inspect its complete stage journey and process tag readings.
                </div>
              </div>
            ) : (
              <>
                <div className={styles['detail-header']}>
                  <div>
                    <div className={styles['dh-id']}>{selectedCabin.cabin}</div>
                    <div className={styles['dh-tags']}>
                      <span className={styles['dh-tag']}>Hanger <b>{selectedCabin.hanger || '—'}</b></span>
                      <span className={styles['dh-tag']}>Skid <b>{selectedCabin.skid || '—'}</b></span>
                      <span className={styles['dh-tag']}>Type <b>{selectedCabin.type || '—'}</b></span>
                      <span className={styles['dh-tag']}>Colour <b>{selectedCabin.colour || '—'}</b></span>
                      <span className={styles['dh-tag']}>
                        Entry <b>{selectedCabin.entry || '—'}</b> {selectedCabin.date ? `· ${selectedCabin.date}` : ''}
                      </span>
                      <span className={styles['dh-tag']}>
                        Exit <b>{selectedCabin.exit || '—'}</b> {selectedCabin.date ? `· ${selectedCabin.date}` : ''}
                      </span>
                    </div>
                  </div>
                  <div className={styles['dh-stats']}>
                    <div className={styles['dh-stat']}>
                      <div className={styles.num}>{totalDwell}m</div>
                      <div className={styles.lbl}>Total time</div>
                    </div>
                  </div>
                </div>

                {/* Conveyor Rail Stage Tracks */}
                <div className={styles['rail-section']}>
                  <div className={styles['section-label']}>Stage journey — PT (Pre-Treatment)</div>
                  {journeyLoading ? (
                    <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '12px 0' }}>
                      Loading journey stages for {selectedCabin.cabin}...
                    </div>
                  ) : renderConveyorRail('PT') || (
                    <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
                      No PT stages recorded for this vehicle.
                    </div>
                  )}
                </div>

                <div className={styles['rail-section']}>
                  <div className={styles['section-label']}>Stage journey — ED (Electro-Deposition)</div>
                  {!journeyLoading && (renderConveyorRail('ED') || (
                    <div style={{ color: 'var(--text-faint)', fontSize: '12px', padding: '10px 0' }}>
                      No ED stages recorded for this vehicle.
                    </div>
                  ))}
                </div>

                {/* Stage process tags */}
                {activeStage && (
                  <div className={styles['param-section']}>
                    <div className={styles['section-label']}>
                      Process tags — {stageReadingsData?.name || activeStage.name}
                    </div>
                    <div className={styles['param-panel']}>
                      <div className={styles['param-panel-head']}>
                        <div>
                          <div className={styles['pph-title']}>
                            {stageReadingsData?.stageId || activeStage.code} — {stageReadingsData?.name || activeStage.name}
                          </div>
                         <div className={styles['pph-sub']}>
                            {stageReadingsData?.window?.entryTime
                              ? `${formatTimeToLocal(stageReadingsData.window.entryTime)} → ${formatTimeToLocal(stageReadingsData.window.exitTime)}`
                              : activeStage.entryTime
                              ? `${activeStage.entryTime} → ${activeStage.exitTime || ''}`
                              : ''}
                          </div>
                        </div>
                        {stageReadingsData?.tags && stageReadingsData.tags.length > 0 && (
                          <div className={styles['pph-counts']}>
                            <span>
                              {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'live').length} Live
                            </span>
                            <span>
                              {stageReadingsData.tags.filter((t) => (t.source || '').toLowerCase() === 'log').length} Log
                            </span>
                          </div>
                        )}
                      </div>

                      {stageLoading ? (
                        <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12px' }}>
                          Loading tag readings...
                        </div>
                      ) : activeStage.code === 'PT-11' || activeStage.code === 'ED-8' ? (
                        <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
                          Manual visual inspection checkpoint. No PLC tag readings recorded for this stage.
                        </div>
                      ) : !stageReadingsData?.tags || stageReadingsData.tags.length === 0 ? (
                        <div style={{ padding: '24px 18px', color: 'var(--text-faint)', fontSize: '12.5px' }}>
                          No process tags recorded for this stage.
                        </div>
                      ) : (
                        <div style={{ overflowX: 'auto' }}>
                          <table className={styles['param-table']}>
                            <thead>
                              <tr>
                                <th>Tag</th>
                                <th>Reference Range</th>
                                <th>Reading</th>
                                <th>Source</th>
                                <th>Process</th>
                              </tr>
                            </thead>
                            <tbody>
                              {stageReadingsData.tags.map((t, idx) => {
                                const hasData = t.status !== 'no_data' && ((t.avg !== null && t.avg !== undefined) || t.value !== undefined);
                                const displayValue = hasData
                                  ? (t.value !== undefined ? t.value : t.avg)
                                  : null;
                                const readingText = displayValue !== null ? `${displayValue} ${t.unit || ''}`.trim() : '—';
                                const isOutOfRange = t.status === 'out_of_range';
                                const isInRange = t.status === 'in_range' || t.status === 'within_range';

                                return (
                                  <tr key={t.tagId ? `${t.tagId}-${idx}` : `${t.name}-${idx}`}>
                                    <td>
                                      <div className={styles['tag-name']}>{t.name || 'Unnamed Tag'}</div>
                                      {/* <div className={styles['tag-id']} title={t.tagId}>{t.tagId || '—'}</div> */}
                                    </td>
                                    <td>
                                      <div className={styles['tag-range']}>
                                        {formatRangeDisplay(t.range, t.unit)}
                                      </div>
                                    </td>
                                    <td>
                                      <div className={`${styles['tag-reading']} ${isOutOfRange ? styles.warn : isInRange ? styles.ok : ''}`}>
                                        {readingText}
                                      </div>
                                    </td>
                                    <td>
                                      <span className={`${styles.chip} ${styles['src-live']}`}>
                                        {t.source || 'Live'}
                                      </span>
                                    </td>
                                    <td>
                                      {isOutOfRange ? (
                                        <span className={`${styles.chip} ${styles['dev-out']}`}>⚠ Out of range</span>
                                      ) : isInRange ? (
                                        <span className={`${styles.chip} ${styles['dev-in']}`}>In range</span>
                                      ) : (
                                        <span className={`${styles.chip} ${styles['src-none']}`}>No data</span>
                                      )}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </>
            )}
          </section>
        </main>
      </div>
    </div>
  );
}