import React, { useState, useEffect } from 'react';
import { Card, Box, CircularProgress } from '@mui/material';
import styles from './kpiDashboard.module.css';
import { doGetApiCall } from '../../../../utils/ClonosApi';
import AppUrl from '../../../../utils/AppUrl';



/**
 * Cleanly formats numeric values: integers as plain strings, decimals rounded to at most 2 places,
 * and null/undefined values as a placeholder dash.
 */
const formatMetricValue = (rawValue) => {
  if (rawValue === null || rawValue === undefined || isNaN(rawValue)) {
    return '—';
  }

  return Number(rawValue).toFixed(2);
};

// Check if current tab is opened in standalone/wallboard mode
const isStandaloneMode = () => {
  const params = new URLSearchParams(window.location.search);
  return params.get('mode') === 'standalone';
};
// Shortens verbose units so they don't crowd the card
const formatUnit = (rawUnit) => {
  if (!rawUnit || rawUnit === '-') return '';
  if (rawUnit.toLowerCase().includes('point')) return 'Points';
  if (rawUnit.toLowerCase().includes('celsius')) return 'ºC';
  return rawUnit;
};

// Replaces "Points" with "Pts" and "Celsius" with "ºC" inside setRange
const formatSetRange = (rawSetRange) => {
  if (!rawSetRange) return '—';
  return rawSetRange
    .replace(/\bPoints\b/gi, 'Pts')
    .replace(/\bCelsius\b/gi, 'ºC')
    .trim();
};

/**
 * Calculates percentage positions for the KPI target limit band and actual value cursor marker.
 *
 * @param {Object} kpiItem - KPI object containing value and threshold boundaries.
 * @returns {{ targetBandLeftPct: number, targetBandWidthPct: number, cursorPositionPct: number }}
 */
function calculateTrackGeometry(kpiItem) {
  const currentValue = typeof kpiItem?.value === 'number' ? kpiItem.value : null;
  const lowerLimit = kpiItem?.range?.minValue;
  const upperLimit = kpiItem?.range?.maxValue;

  // Return zero-state coordinates if value is unrecorded
  if (currentValue === null) {
    return {
      targetBandLeftPct: 0,
      targetBandWidthPct: 0,
      cursorPositionPct: 0
    };
  }

  let scaleMinBoundary;
  let scaleMaxBoundary;
  let targetBandStart;
  let targetBandEnd;

  const hasRangeBoundaries = (
    lowerLimit !== undefined && lowerLimit !== null &&
    upperLimit !== undefined && upperLimit !== null
  );

  if (hasRangeBoundaries) {
    // Add visual breathing room (55% of the tolerance span) on either side of the limits
    const toleranceSpan = upperLimit - lowerLimit;
    const padding = (toleranceSpan * 0.55) || 1;

    scaleMinBoundary = lowerLimit - padding;
    scaleMaxBoundary = upperLimit + padding;
    targetBandStart = lowerLimit;
    targetBandEnd = upperLimit;
  } else {
    // Single-threshold upper bound fallback (e.g. <= 5 or < 30)
    const effectiveUpper = upperLimit || 100;

    scaleMinBoundary = 0;
    scaleMaxBoundary = effectiveUpper * 1.7;
    targetBandStart = 0;
    targetBandEnd = effectiveUpper;
  }

  // Maps numeric coordinates to a 0% - 100% linear track position
  const calculatePercentage = (val) => {
    const rawPercentage = ((val - scaleMinBoundary) / (scaleMaxBoundary - scaleMinBoundary)) * 100;
    return Math.max(0, Math.min(100, rawPercentage));
  };

  const targetBandLeftPct = calculatePercentage(targetBandStart);
  const targetBandRightPct = calculatePercentage(targetBandEnd);
  const targetBandWidthPct = targetBandRightPct - targetBandLeftPct;
  const cursorPositionPct = calculatePercentage(currentValue);

  return {
    targetBandLeftPct,
    targetBandWidthPct,
    cursorPositionPct
  };
}

const padWithLeadingZero = (num) => String(num).padStart(2, '0');

/**
 * Converts an ISO timestamp string into the standard format (e.g., "Updated 22-Sep 14:05:30").
 */
function formatLastUpdatedTimestamp(isoTimestamp) {
  if (!isoTimestamp) return '—';
  
  const parsedDate = new Date(isoTimestamp);
  if (isNaN(parsedDate.getTime())) return `Updated ${isoTimestamp}`;
  
  const day = `${padWithLeadingZero(parsedDate.getDate())}-${parsedDate.toLocaleString('en-GB', { month: 'short' })}`;
  const time = `${padWithLeadingZero(parsedDate.getHours())}:${padWithLeadingZero(parsedDate.getMinutes())}:${padWithLeadingZero(parsedDate.getSeconds())}`;
  
  return `Updated ${day} ${time}`;
}

function KpiDashboard() {
  const [preTreatmentData, setPreTreatmentData] = useState([]);
  const [electroDepositionData, setElectroDepositionData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [systemClock, setSystemClock] = useState({ currentTime: '--:--:--', currentDate: '—' });
  const isStandalone = isStandaloneMode();

  // Handler to open standalone dashboard in a new tab
  const handleOpenInNewTab = () => {
    const url = new URL(window.location.href);
    url.searchParams.set('mode', 'standalone');
    window.open(url.toString(), '_blank', 'noopener,noreferrer');
  };
  // System clock timer
  useEffect(() => {
    const updateWallboardClock = () => {
      const now = new Date();
      setSystemClock({
        currentTime: `${padWithLeadingZero(now.getHours())}:${padWithLeadingZero(now.getMinutes())}:${padWithLeadingZero(now.getSeconds())}`,
        currentDate: now.toLocaleDateString('en-GB', {
          weekday: 'short',
          day: '2-digit',
          month: 'short',
          year: 'numeric'
        })
      });
    };

    updateWallboardClock();
    const clockIntervalId = setInterval(updateWallboardClock, 1000);
    return () => clearInterval(clockIntervalId);
  }, []);

  // Fetch KPI data from backend
  const fetchKpiDashboardData = () => {
    doGetApiCall({ url: AppUrl?.getKpiDashboard })
      .then((response) => {
        const dashboardPayload = response?.data?.result;
        if (dashboardPayload) {
          setPreTreatmentData(dashboardPayload.pt || []);
          setElectroDepositionData(dashboardPayload.ed || []);
        }
      })
      .catch((error) => {
        console.error('Failed to fetch KPI dashboard parameters:', error);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  useEffect(() => {
    fetchKpiDashboardData();
    // Auto-refresh interval (every 10 seconds) for real-time live tags
    const pollingIntervalId = setInterval(fetchKpiDashboardData, 15000);
    return () => clearInterval(pollingIntervalId);
  }, []);

  // Aggregated limit metrics
  const combinedKpis = [...preTreatmentData, ...electroDepositionData];
  const totalOutOfLimit = combinedKpis.filter((item) => item.status === 'Out of limit' || item.health === false).length;
  const totalInLimit = combinedKpis.length - totalOutOfLimit;

  const ptCorrectionNeededCount = preTreatmentData.filter((item) => item.status === 'Out of limit' || item.health === false).length;
  const edCorrectionNeededCount = electroDepositionData.filter((item) => item.status === 'Out of limit' || item.health === false).length;

 const renderKpiCard = (kpiItem, index) => {
    const isWithinSpecification = kpiItem.status === 'In limit' || (kpiItem.status === undefined && kpiItem.health !== false);
    const geometry = calculateTrackGeometry(kpiItem);
    // 1. Resolve unit cleanly
     const resolvedUnit = formatUnit(kpiItem.unit);
     
    return (
      <article
        key={`${kpiItem.tagId || index}-${kpiItem.subStage}-${kpiItem.parameter}`}
        className={`${styles.kpiCard} ${isWithinSpecification ? styles.ok : styles.bad}`}
      >
        
        {/* Zone 1: Substage and Parameter Names */}
        <div className={styles.cardHeaderZone}>
          <div className={styles.cardStage} title={kpiItem.subStage}>
            {kpiItem.subStage}
          </div>
          <div className={styles.cardParam} title={kpiItem.parameter}>
            {kpiItem.parameter}
          </div>
        </div>

        {/* Zone 2: Centered Large Metric Value */}
        <div className={styles.valRow}>
          <span className={styles.valNum}>{formatMetricValue(kpiItem.value)}</span>
          <span className={styles.valUnit}>{resolvedUnit}</span>
        </div>

        {/* Zone 3: Scale Bar, Range Specs, and Last Updated */}
        <div className={styles.cardFooterZone}>
          <div className={styles.track}>
            <span
              className={styles.band}
              style={{
                left: `${geometry.targetBandLeftPct}%`,
                width: `${geometry.targetBandWidthPct}%`
              }}
            />
            {kpiItem.value !== null && (
              <span
                className={styles.marker}
                style={{
                  left: `${geometry.cursorPositionPct}%`
                }}
              />
            )}
          </div>
          
        <div className={styles.specRow}>
        <span className={styles.specRangeText} title={`Set ${formatSetRange(kpiItem.setRange)}`}>
            Set {formatSetRange(kpiItem.setRange)}
        </span>
        
        </div>
        
        <div className={styles.specRow}>
          <span className={styles.stateText}>
              {kpiItem.status || (isWithinSpecification ? 'In limit' : 'Out of limit')}
          </span>
        </div>

          <div className={styles.stampLine}>
            {/* <span className={styles.dot} /> */}
            {formatLastUpdatedTimestamp(kpiItem.timestamp)}
          </div>
        </div>
      </article>
    );
  };

  return (
  <Box
  sx={{
    p: { xs: 1, sm: 1.5, lg: 1.5 },
    width: '100%',
    // Stays auto (scrollable) until 1200px desktop screen
    height: { xs: 'auto', lg: 'calc(100vh - 65px)' },
    boxSizing: 'border-box',
    overflowY: { xs: 'auto', lg: 'hidden' },
    overflowX: 'hidden',
    display: 'flex',
    flexDirection: 'column'
  }}
>
  <Card
    variant="outlined"
    sx={{
      flex: 1,
      minHeight: 0,
      height: { xs: 'auto', lg: '100%' },
      display: 'flex',
      flexDirection: 'column',
      p: 1.5,
      borderRadius: '10px',
      backgroundColor: '#ffffff',
      borderColor: '#e2e8f0',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.04)',
      overflowY: { xs: 'visible', lg: 'hidden' },
      overflowX: 'hidden'
    }}
  >
        {isLoading && preTreatmentData.length === 0 ? (
          <Box sx={{ display: 'flex', flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <CircularProgress size={36} sx={{ color: '#0284c7' }} />
          </Box>
        ) : (
          <div className={styles.kpiDashboardRoot}>
            {/* Header Bar */}
            <div className={styles.headerBar}>
              <div className={styles.wallboardTitle}>
                Paint Shop Digital Twin — Pre-Treatment &amp; Electro-Deposition
              </div>
              <div className={styles.tallyWrap}>
                <div className={`${styles.chip} ${styles.ok}`}>
                  <b>{totalInLimit}</b>
                  <span>In limit</span>
                </div>
                <div className={`${styles.chip} ${styles.bad}`}>
                  <b>{totalOutOfLimit}</b>
                  <span>Out of limit</span>
                </div>
                <div className={styles.clockBox}>
                  <div className={styles.clockTime}>{systemClock.currentTime}</div>
                  <div className={styles.clockDate}>{systemClock.currentDate}</div>
                </div>
              </div>
            </div>

            {/* Side-by-Side Main Sections */}
            <div className={styles.boardMain}>
              {/* Pre-Treatment (PT) Section */}
              <section className={styles.sectionPt}>
                <div className={styles.secHead}>
                  <span className={styles.secTag}>PT</span>
                  <span className={styles.secTitle}>Pre-Treatment</span>
                  {ptCorrectionNeededCount > 0 && (
                    <span className={styles.secWarn}>
                      {ptCorrectionNeededCount} correction needed
                    </span>
                  )}
                  <span className={styles.secCount}>
                    {preTreatmentData.length} parameters
                  </span>
                </div>
                <div className={styles.gridPt}>
                  {preTreatmentData.map(renderKpiCard)}
                </div>
              </section>

              {/* Electro-Deposition (ED) Section */}
              <section className={styles.sectionEd}>
                <div className={styles.secHead}>
                  <span className={styles.secTag}>ED</span>
                  <span className={styles.secTitle}>Electro-Deposition</span>
                  {edCorrectionNeededCount > 0 && (
                    <span className={styles.secWarn}>
                      {edCorrectionNeededCount} correction needed
                    </span>
                  )}
                  <span className={styles.secCount}>
                    {electroDepositionData.length} parameters
                  </span>
                </div>
                <div className={styles.gridEd}>
                  {electroDepositionData.map(renderKpiCard)}
                </div>
              </section>
            </div>
          </div>
        )}
      </Card>
    </Box>
  );
}

export default KpiDashboard;