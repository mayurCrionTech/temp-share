// import React, { useState, useMemo, useEffect } from 'react';
// import {
//   ResponsiveContainer,
//   LineChart,
//   Line,
//   XAxis,
//   YAxis,
//   Tooltip,
//   CartesianGrid,
//   ReferenceLine,
// } from 'recharts';
// import styles from './process-analytics-dashboard.module.css';
// import { doGetApiCall } from '../../../../utils/ClonosApi';

// const DATA = {
//   PT: {
//     label: 'PT',
//     full: 'Pre-Treatment',
//     stages: [
//       {
//         name: 'Degreasing Spray',
//         tags: [
//           { id: '699426acbfb07d6db09a050d', name: 'Bath Temperature', low: 50, high: 60, unit: 'ºC', mockVal: 54.2 },
//           { id: '699426acbfb07d6db09a050a', name: 'Spray Pressure Bottom', low: 0.9, high: 1.1, unit: 'Bar', mockVal: 1.35 },
//           { id: '699426acbfb07d6db09a0507', name: 'Spray Pressure Top', low: 0.9, high: 1.1, unit: 'Bar', mockVal: 0.72 },
//           { id: '699426acbfb07d6db09a0510', name: 'Heat Exchanger ∆P', low: null, high: 0.7, unit: 'Bar', mockVal: 0.45 },
//           { id: '699426acbfb07d6db09a051f', name: 'Cyclone Inlet Pressure', low: 2.0, high: 2.4, unit: 'Bar', mockVal: 2.15 },
//           { id: '699426acbfb07d6db09a0525', name: 'Oil Separator Temperature', low: 80, high: 85, unit: '°C', mockVal: 88.0 },
//           { id: '699426acbfb07d6db09a0528', name: 'Oil Separator Flow', low: 10, high: 15, unit: 'LPM', mockVal: 12.4 },
//           { id: '699426acbfb07d6db09a0519', name: 'Free Alkali', low: 16, high: 19, unit: 'Points', mockVal: 17.5 },
//         ],
//       },
//       {
//         name: 'Degreasing Dip',
//         tags: [
//           { id: '699426acbfb07d6db09a052b', name: 'Bath Temperature', low: 52, high: 58, unit: 'ºC', mockVal: 55.0 },
//           { id: '699426acbfb07d6db09a052e', name: 'Circulation Pressure - LH', low: 1.0, high: 1.4, unit: 'Bar', mockVal: 1.62 },
//           { id: '699426acbfb07d6db09a0531', name: 'Circulation Pressure - RH', low: 1.0, high: 1.5, unit: 'Bar', mockVal: 1.2 },
//         ],
//       },
//       {
//         name: 'Phosphating',
//         tags: [
//           { id: '699426acbfb07d6db09a057c', name: 'Bath Temperature', low: 40, high: 45, unit: 'ºC', mockVal: 42.1 },
//           { id: '699426acbfb07d6db09a058b', name: 'Total Acidity', low: 22, high: 24, unit: 'Points', mockVal: 25.8 },
//         ],
//       },
//     ],
//   },
//   ED: {
//     label: 'ED',
//     full: 'Electro-Deposition',
//     stages: [
//       {
//         name: 'E-Coat',
//         tags: [
//           { id: '6a7c688963f1464aebae7898', name: 'Bath Level', low: 240, high: 300, unit: 'Cms', mockVal: 275 },
//           { id: '699d79acefe574e9bb79f5d4', name: 'Bath Temperature', low: 30, high: 32, unit: '˚C', mockVal: 33.8 },
//           { id: '699d79afefe574e9bb7b4755', name: 'Circulation Pressure - Bottom 1', low: 1.6, high: 2.0, unit: 'Bar', mockVal: 1.8 },
//         ],
//       },
//     ],
//   },
//   OVEN: {
//     label: 'OVEN',
//     full: 'Oven',
//     stages: [
//       {
//         name: 'Oven Zones',
//         tags: [
//           { id: '699d7a0fefe574e9bbac0efa', name: 'Preheat Zone', low: null, high: null, unit: '˚C', pending: true, mockVal: 160 },
//           { id: '699d7a11efe574e9bbad607b', name: 'Heat Up Zone', low: null, high: null, unit: '˚C', pending: true, mockVal: 195 },
//         ],
//       },
//     ],
//   },
// };

// // const SERIES_COLORS = ['#165BAA', '#E06A1B'];
// const SERIES_COLORS = ['#165BAA', '#D97706']; // Primary Royal Blue & Warm Amber
// // const SERIES_COLORS = ['#0284C7', '#7C3AED']; // Ocean Cerulean & Deep Violet
// // const SERIES_COLORS = ['#0F766E', '#4F46E5']; // Deep Teal & Electric Indigo
// // const SERIES_COLORS = ['#06337E', '#C026D3']; // Clonos Navy & Fuchsia Orchid

// export default function ProcessAnalyticsDashboard() {
//   const [currentProcess, setCurrentProcess] = useState('PT');
//   const [currentStageIdx, setCurrentStageIdx] = useState(0);
//   const [selectedTags, setSelectedTags] = useState([]); // Max 2 tags comparison
//   const [customLimits, setCustomLimits] = useState({});

//   // 1. Inputs Draft State (updates immediately as user types/picks)
// const [dateMode, setDateMode] = useState('range'); // 'day' | 'range'
// const [singleDate, setSingleDate] = useState('2026-09-29T04:30');
// const [fromDate, setFromDate] = useState('2026-09-22T04:30');
// const [toDate, setToDate] = useState('2026-09-29T04:30');

// // 2. Applied State (Chart ONLY listens to this)
// const [appliedParams, setAppliedParams] = useState({
//   mode: 'range',
//   singleDate: '2026-09-29T04:30',
//   fromDate: '2026-09-22T04:30',
//   toDate: '2026-09-29T04:30',
// });

// // 3. Handler called ONLY on "Apply" button click
// const handleApplyDate = () => {
//   setAppliedParams({
//     mode: dateMode,
//     singleDate,
//     fromDate,
//     toDate,
//   });
// };

//   const getEffectiveLimits = (tag) => {
//     const override = customLimits[tag.id];
//     return override || { low: tag.low, high: tag.high };
//   };

//   const isOOS = (val, tag) => {
//     const { low, high } = getEffectiveLimits(tag);
//     if (low != null && val < low) return true;
//     if (high != null && val > high) return true;
//     return false;
//   };

//   const handleTagToggle = (stageName, tag) => {
//     const existsIndex = selectedTags.findIndex((s) => s.tag.id === tag.id);
//     if (existsIndex >= 0) {
//       setSelectedTags((prev) => prev.filter((_, idx) => idx !== existsIndex));
//     } else {
//       if (selectedTags.length >= 2) {
//         setSelectedTags((prev) => [prev[1], { process: currentProcess, stage: stageName, tag }]);
//       } else {
//         setSelectedTags((prev) => [...prev, { process: currentProcess, stage: stageName, tag }]);
//       }
//     }
//   };

//   const getTrackGeometry = (val, tag) => {
//     const { low, high } = getEffectiveLimits(tag);
//     if (low == null && high == null) return { pct: 50 };
//     const minVal = low != null ? low : high * 0.7;
//     const maxVal = high != null ? high : low * 1.3;
//     const span = maxVal - minVal || 1;
//     const buffer = span * 0.35;
//     const domainLow = minVal - buffer;
//     const domainHigh = maxVal + buffer;
//     const pct = Math.max(0, Math.min(100, ((val - domainLow) / (domainHigh - domainLow)) * 100));
//     return { pct };
//   };

//   // 1. Add custom limit change handler
// const handleLimitChange = (tagId, field, value) => {
//   const numVal = value === '' ? null : parseFloat(value);
//   setCustomLimits((prev) => {
//     const existing = prev[tagId] || { low: null, high: null };
//     return {
//       ...prev,
//       [tagId]: {
//         ...existing,
//         [field]: isNaN(numVal) ? null : numVal,
//       },
//     };
//   });
// };
 
// const chartData = useMemo(() => {
//   if (selectedTags.length === 0) return [];
//   const pointsCount = 30;
//   const rows = [];

//   let startMs, endMs;
//   if (appliedParams.mode === 'day') {
//     const d = new Date(appliedParams.singleDate);
//     startMs = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0).getTime();
//     endMs = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59).getTime();
//   } else {
//     startMs = new Date(appliedParams.fromDate).getTime();
//     endMs = new Date(appliedParams.toDate).getTime();
//   }

//   const step = (endMs - startMs) / pointsCount;

//   for (let i = 0; i <= pointsCount; i++) {
//     const pointTime = new Date(startMs + i * step);
//     const timeLabel =
//       appliedParams.mode === 'day'
//         ? pointTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
//         : `${pointTime.getDate()} ${pointTime.toLocaleString('en-GB', { month: 'short' })} ${pointTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;

//     const row = { timestamp: timeLabel };
//     selectedTags.forEach((s) => {
//       const { low, high } = getEffectiveLimits(s.tag);
//       const center = low != null && high != null ? (low + high) / 2 : 50;
//       const delta = high != null && low != null ? (high - low) / 2 : 10;
//       const val = +(center + Math.sin(i * 0.8) * delta * 1.05 + (Math.random() - 0.5) * delta * 0.15).toFixed(2);
//       row[s.tag.id] = val;
//     });
//     rows.push(row);
//   }
//   return rows;
// }, [selectedTags, appliedParams, customLimits]);

//   const summaryStats = useMemo(() => {
//     if (selectedTags.length === 0 || chartData.length === 0) return null;
//     const tag = selectedTags[0].tag;
//     const values = chartData.map((d) => d[tag.id]).filter((v) => v !== undefined);
//     if (!values.length) return null;

//     const count = values.length;
//     const avg = (values.reduce((a, b) => a + b, 0) / count).toFixed(3);
//     const min = Math.min(...values).toFixed(3);
//     const max = Math.max(...values).toFixed(3);
//     const oosCount = values.filter((v) => isOOS(v, tag)).length;

//     return { count, avg, min, max, oosCount };
//   }, [chartData, selectedTags]);


//   const readingsSummary = useMemo(() => {
//   if (selectedTags.length === 0 || chartData.length === 0) return [];

//   return selectedTags.map((s, idx) => {
//     const tag = s.tag;
//     const values = chartData
//       .map((d) => d[tag.id])
//       .filter((v) => v !== undefined && !isNaN(v));

//     if (!values.length) {
//       return {
//         tag,
//         color: SERIES_COLORS[idx],
//         count: 0,
//         avg: '—',
//         min: '—',
//         max: '—',
//         oosCount: 0,
//       };
//     }

//     const count = values.length;
//     const sum = values.reduce((a, b) => a + b, 0);
//     const avg = (sum / count).toFixed(2);
//     const min = Math.min(...values).toFixed(2);
//     const max = Math.max(...values).toFixed(2);
//     const oosCount = values.filter((v) => isOOS(v, tag)).length;

//     return {
//       tag,
//       color: SERIES_COLORS[idx],
//       count,
//       avg: `${avg} ${tag.unit || ''}`.trim(),
//       min,
//       max,
//       oosCount,
//     };
//   });
// }, [chartData, selectedTags, customLimits]);

//   const activeStage = DATA[currentProcess]?.stages[currentStageIdx] || DATA.PT.stages[0];
//   const tagA = selectedTags[0]?.tag;
//   const tagB = selectedTags[1]?.tag;
//   const isDualAxis = Boolean(tagA && tagB && tagA.unit !== tagB.unit);


// const getParameterMaster=async()=>{
//       const res = await doGetApiCall({url:`/tags/dashboard/trend/parameter-master`})
//       console.log(res,"parametermasterres")
// }

// useEffect(()=>{
//     getParameterMaster()
// },[])

//   return (
//     <div className={styles.pageWrapper}>
//       <div className={styles.mainCard}>
//         {/* Header Strip */}
//         <div className={styles.cardTopHeader}>
//           <div className={styles.titleGroup}>
//             <div className={styles.mainTitle}>Process Analytics Dashboard</div>
//             <div className={styles.subMeta}>
//               E-log · Last sync: 29 Sept 2026, 10:50 am
//             </div>
//           </div>
//           <div className={styles.liveBadge}>
//             <span className={styles.liveDot}></span> Live
//           </div>
//         </div>

//         {/* Scrollable Content Body */}
//         <div className={styles.cardBody}>
//           {/* PRIMARY TOGGLE: Capsule pill group */}
//           <div className={styles.toggleRow}>
//             <div className={styles.pillContainer}>
//               {Object.keys(DATA).map((key) => (
//                 <button
//                   key={key}
//                   type="button"
//                   className={`${styles.pillButton} ${currentProcess === key ? styles.pillActive : ''}`}
//                   onClick={() => {
//                     setCurrentProcess(key);
//                     setCurrentStageIdx(0);
//                   }}
//                 >
//                   {DATA[key].full}
//                 </button>
//               ))}
//             </div>
//           </div>

//           {/* SUB-PILLS (Stages): Separated standalone buttons matched to #06337E */}
//           <div className={styles.subPillRow}>
//             {DATA[currentProcess].stages.map((st, idx) => (
//               <button
//                 key={st.name}
//                 type="button"
//                 className={`${styles.stagePill} ${currentStageIdx === idx ? styles.stagePillActive : ''}`}
//                 onClick={() => setCurrentStageIdx(idx)}
//               >
//                 {st.name}
//               </button>
//             ))}
//           </div>

//           {/* Section Header */}
//           <div className={styles.sectionHeaderRow}>
//             <div className={styles.sectionTitle}>
//               {activeStage.name.toUpperCase()} — LIVE DATA
//             </div>
//           </div>

//           {/* KPI Cards Grid with Left Accent & Filled Progress Track */}
//           <div className={styles.cardGrid}>
//             {activeStage.tags.map((tag) => {
//   const { low, high } = getEffectiveLimits(tag);
//   const isSelected = selectedTags.some((s) => s.tag.id === tag.id);
//   const val = tag.mockVal ?? (low != null && high != null ? +((low + high) / 2).toFixed(2) : 0.0);
//   const oos = !tag.pending && isOOS(val, tag);
//   const geo = getTrackGeometry(val, tag);

//   return (
//     <div
//       key={tag.id}
//       className={`
//         ${styles.kpiCard} 
//         ${oos ? styles.kpiCardBreach : styles.kpiCardNormal}
//         ${isSelected ? styles.kpiCardSelected : ''}
//       `}
//       onClick={() => handleTagToggle(activeStage.name, tag)}
//     >
//       <div className={styles.cardHeader}>
//         <span className={styles.cardTagTitle}>{tag.name}</span>
//         <div className={`${styles.cardCheckbox} ${isSelected ? styles.checkboxChecked : ''}`}>
//           {isSelected ? '✓' : ''}
//         </div>
//       </div>

//       {/* Value */}
//       <div className={`${styles.cardValue} ${oos ? styles.valueBreach : styles.valueNormal}`}>
//         {tag.pending ? '—' : val.toFixed(2)}
//       </div>

//       <div className={styles.cardMeta}>Updated at: 29/09/2026, 23:45</div>
//       <div className={styles.cardMeta}>
//         Spec: {low ?? '–∞'} – {high ?? '+∞'} {tag.unit}
//       </div>

//       {/* Conditionally Render: User Input Fields (Oven / Pending) vs Gauge Track (Normal) */}
//       {tag.pending ? (
//        <div className={styles.manualLimitSection} onClick={(e) => e.stopPropagation()}>
//       <div className={styles.manualInputsRow}>
//         <input
//           type="number"
//           step="any"
//           placeholder="Low"
//           className={styles.limitInput}
//           value={customLimits[tag.id]?.low ?? ''}
//           onChange={(e) => handleLimitChange(tag.id, 'low', e.target.value)}
//         />
//         <input
//           type="number"
//           step="any"
//           placeholder="High"
//           className={styles.limitInput}
//           value={customLimits[tag.id]?.high ?? ''}
//           onChange={(e) => handleLimitChange(tag.id, 'high', e.target.value)}
//         />
//       </div>
//       <div className={styles.pendingHint}>
//         limits not yet set — enter above
//       </div>
// </div>
//       ) : (
//         <>
//           <div className={styles.rangeTrack}>
//             <div
//               className={`${styles.rangeFill} ${oos ? styles.fillBreach : styles.fillNormal}`}
//               style={{ width: `${geo.pct}%` }}
//             />
//             <div
//               className={`${styles.rangeMarker} ${oos ? styles.markerBreach : styles.markerNormal}`}
//               style={{ left: `${geo.pct}%` }}
//             />
//           </div>
//           <div className={styles.rangeLabels}>
//             <span>{low ?? ''}</span>
//             <span>{high ?? ''}</span>
//           </div>
//         </>
//       )}
//     </div>
//   );
// })}
//           </div>

//           {/* Active Comparison Chip Bar */}
//           {selectedTags.length > 0 && (
//             <div className={styles.compareBar}>
//               <span className={styles.compareLabel}>Active Comparison (Max 2):</span>
//               {selectedTags.map((s, idx) => (
//                 <span key={s.tag.id} className={styles.chip}>
//                   <span className={styles.chipDot} style={{ background: SERIES_COLORS[idx] }}></span>
//                   {s.tag.name} ({s.tag.unit || 'val'})
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleTagToggle(s.stage, s.tag);
//                     }}
//                   >
//                     ×
//                   </button>
//                 </span>
//               ))}
//             </div>
//           )}

//           {/* Chart Section Container (Card with White Surface) */}
//           <div className={styles.chartSection}>
//             <div className={styles.chartHeaderRow}>
//               <div>
//                 <div className={styles.chartTitle}>
//                   {selectedTags.length > 0
//                     ? `${selectedTags[0].stage} — ${selectedTags.map((s) => s.tag.name).join(' vs ')}`
//                     : 'Process Trend Overview'}
//                 </div>
//                 {tagA && (
//                   <div className={styles.chartSpecSub}>
//                     {isDualAxis
//                       ? `Comparing different units: Left (${tagA.unit}) vs Right (${tagB.unit})`
//                       : `Spec range: ${getEffectiveLimits(tagA).low ?? '–∞'} – ${getEffectiveLimits(tagA).high ?? '+∞'} ${tagA.unit}`}
//                   </div>
//                 )}
//               </div>

//               {/* Date Controls Group with Smooth Transition */}
//               {/* Date Controls Group */}
//             <div className={styles.dateControlGroup}>
//               {/* Mode Field */}
//               <div className={styles.modeField}>
//                 <label className={styles.dateLabel}>MODE</label>
//                 <div className={styles.dateModeContainer}>
//                   <button
//                     type="button"
//                     className={`${styles.dateModeBtn} ${dateMode === 'day' ? styles.dateModeActive : ''}`}
//                     onClick={() => setDateMode('day')}
//                   >
//                     Single Day
//                   </button>
//                   <button
//                     type="button"
//                     className={`${styles.dateModeBtn} ${dateMode === 'range' ? styles.dateModeActive : ''}`}
//                     onClick={() => setDateMode('range')}
//                   >
//                     Range
//                   </button>
//                 </div>
//               </div>

//               {/* First Date Field (Draft value) */}
//               <div className={styles.dateField}>
//                 <label className={styles.dateLabel}>{dateMode === 'day' ? 'DATE' : 'FROM'}</label>
//                 <input
//                   type="datetime-local"
//                   value={dateMode === 'day' ? singleDate : fromDate}
//                   onChange={(e) => {
//                     if (dateMode === 'day') setSingleDate(e.target.value);
//                     else setFromDate(e.target.value);
//                   }}
//                 />
//               </div>

//               {/* Second Date Field (Draft value) */}
//               <div
//                 className={`${styles.dateField} ${styles.collapsibleField} ${
//                   dateMode === 'range' ? styles.fieldExpanded : styles.fieldCollapsed
//                 }`}
//               >
//                 <label className={styles.dateLabel}>TO</label>
//                 <input
//                   type="datetime-local"
//                   value={toDate}
//                   onChange={(e) => setToDate(e.target.value)}
//                   tabIndex={dateMode === 'range' ? 0 : -1}
//                 />
//               </div>

//               {/* Apply Button commits the changes */}
//               <button
//                 type="button"
//                 className={styles.applyBtn}
//                 onClick={handleApplyDate}
//               >
//                 Apply
//               </button>
//             </div>
//             </div>

//             {/* Recharts Canvas */}
//             {selectedTags.length > 0 ? (
//               <div className={styles.chartWrapper}>
//                 <ResponsiveContainer width="100%" height={230}>
//                   <LineChart data={chartData} margin={{ top: 14, right: 40, left: 10, bottom: 5 }}>
//                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ECEFF1" />
//                     <XAxis dataKey="timestamp" stroke="#90A4AE" tick={{ fontSize: 9.5 }} />

//                     {/* Tag A: Left Y-Axis */}
//                     <YAxis
//                       yAxisId="left"
//                       orientation="left"
//                       stroke={SERIES_COLORS[0]}
//                       unit={` ${tagA.unit}`}
//                       domain={['auto', 'auto']}
//                       tick={{ fontSize: 9.5, fill: '#546E7A' }}
//                     />

//                     {/* Tag B: Right Y-Axis */}
//                     {tagB && (
//                       <YAxis
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         orientation="right"
//                         stroke={SERIES_COLORS[1]}
//                         unit={` ${tagB.unit}`}
//                         domain={['auto', 'auto']}
//                         tick={{ fontSize: 9.5, fill: '#546E7A' }}
//                         hide={!isDualAxis}
//                       />
//                     )}

//                     {/* Clean White Card Tooltip (No black overlay) */}
//                     <Tooltip
//                       contentStyle={{
//                         backgroundColor: '#FFFFFF',
//                         borderColor: '#DCE3EC',
//                         borderRadius: 6,
//                         boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
//                         fontSize: 11,
//                         color: '#1E2530',
//                         padding: '6px 10px',
//                       }}
//                       labelStyle={{ color: '#546E7A', fontWeight: 600, marginBottom: 4 }}
//                       itemStyle={{ padding: '1px 0' }}
//                     />

                  
//                     {/* ================= TAG A LIMITS (Always on Left Axis) ================= */}
//                     {getEffectiveLimits(tagA).low != null && (
//                       <ReferenceLine
//                         yAxisId="left"
//                         y={getEffectiveLimits(tagA).low}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `L-Lower Limit (${getEffectiveLimits(tagA).low})`,
//                           position: 'insideBottomLeft',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {getEffectiveLimits(tagA).high != null && (
//                       <ReferenceLine
//                         yAxisId="left"
//                         y={getEffectiveLimits(tagA).high}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `L-Upper Limit (${getEffectiveLimits(tagA).high})`,
//                           position: 'insideTopLeft',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* ================= TAG B LIMITS (Shows for BOTH Same Unit & Different Units) ================= */}
//                     {tagB && getEffectiveLimits(tagB).low != null && (
//                       <ReferenceLine
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         y={getEffectiveLimits(tagB).low}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `R-Lower Limit (${getEffectiveLimits(tagB).low})`,
//                           position: 'insideBottomRight',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {tagB && getEffectiveLimits(tagB).high != null && (
//                       <ReferenceLine
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         y={getEffectiveLimits(tagB).high}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `R-Upper Limit (${getEffectiveLimits(tagB).high})`,
//                           position: 'insideTopRight',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* Primary Line Series (Tag A) */}
//                     <Line
//                       yAxisId="left"
//                       type="monotone"
//                       dataKey={tagA.id}
//                       name={tagA.name}
//                       stroke={SERIES_COLORS[0]}
//                       strokeWidth={1.8}
//                       dot={{ r: 2, fill: SERIES_COLORS[0], strokeWidth: 0 }}
//                       activeDot={{ r: 4, fill: SERIES_COLORS[0], stroke: '#FFFFFF', strokeWidth: 2 }}
//                     />

//                     {/* Secondary Line Series (Tag B) */}
//                     {tagB && (
//                       <Line
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         type="monotone"
//                         dataKey={tagB.id}
//                         name={tagB.name}
//                         stroke={SERIES_COLORS[1]}
//                         strokeWidth={1.8}
//                         dot={{ r: 2, fill: SERIES_COLORS[1], strokeWidth: 0 }}
//                         activeDot={{ r: 4, fill: SERIES_COLORS[1], stroke: '#FFFFFF', strokeWidth: 2 }}
//                       />
//                     )}
//                   </LineChart>
//                 </ResponsiveContainer>

//                 {/* Footer Legend & Summary */}
//                 <div className={styles.chartFooter}>
//                    <div className={styles.legendGroup}>
//                     <span className={styles.legendItem}>
//                       <span className={styles.legendLineBlue}></span> {tagA.name}
//                     </span>
//                     {tagB && (
//                       <span className={styles.legendItem}>
//                         <span className={styles.legendLineOrange}></span> {tagB.name}
//                       </span>
//                     )}
//                     <span className={styles.legendItem}>
//                       <span className={styles.legendLineRedDashed}></span> {tagA.name} Limits ({getEffectiveLimits(tagA).low ?? '–∞'} – {getEffectiveLimits(tagA).high ?? '+∞'})
//                     </span>
//                     {tagB && (
//                       <span className={styles.legendItem}>
//                         <span className={styles.legendLineRedDashed}></span> {tagB.name} Limits ({getEffectiveLimits(tagB).low ?? '–∞'} – {getEffectiveLimits(tagB).high ?? '+∞'})
//                       </span>
//                     )}
//                   </div>

//                   {summaryStats && (
//                     <div className={styles.statsSummary}>
//                       <span>Readings: <b>{summaryStats.count}</b></span>
//                       <span>Avg: <b>{summaryStats.avg}</b></span>
//                       <span>Min: <b>{summaryStats.min}</b></span>
//                       <span>Max: <b>{summaryStats.max}</b></span>
//                       <span>
//                         Out of spec:{' '}
//                         <b className={summaryStats.oosCount > 0 ? styles.oosText : ''}>
//                           {summaryStats.oosCount} / {summaryStats.count}
//                         </b>
//                       </span>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             ) : (
//               <div className={styles.emptyNotice}>
//                 Select a parameter card checkbox above to begin plotting.
//               </div>
//             )}



//           </div>

//                       {/* READINGS SUMMARY TABLE CARD */}
//         {selectedTags.length > 0 && readingsSummary.length > 0 && (
//           <div className={styles.summaryTableCard}>
//             <div className={styles.summaryTableTitle}>Readings summary</div>
//             <div className={styles.tableWrapper}>
//               <table className={styles.summaryTable}>
//                 <thead>
//                   <tr>
//                     <th className={styles.thTag}>TAG</th>
//                     <th className={styles.thCol}>READINGS</th>
//                     <th className={styles.thCol}>AVG</th>
//                     <th className={styles.thCol}>MIN</th>
//                     <th className={styles.thCol}>MAX</th>
//                     <th className={styles.thCol}>OUT OF SPEC</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {readingsSummary.map((row) => (
//                     <tr key={row.tag.id}>
//                       <td className={styles.tdTag}>
//                         <span
//                           className={styles.rowDot}
//                           style={{ backgroundColor: row.color }}
//                         />
//                         <span className={styles.rowTagName}>{row.tag.name}</span>
//                       </td>
//                       <td className={styles.tdVal}>{row.count}</td>
//                       <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.avg}</td>
//                       <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.min}</td>
//                       <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.max}</td>
//                       <td className={`${styles.tdVal} ${styles.tdOos}`}>
//                         {row.oosCount} / {row.count}
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>
//           </div>
//         )}
//         </div>

//       </div>
//     </div>
//   );
// }

//final work code--
// import React, { useState, useMemo, useEffect } from 'react';
// import {
//   ResponsiveContainer,
//   LineChart,
//   Line,
//   XAxis,
//   YAxis,
//   Tooltip,
//   CartesianGrid,
//   ReferenceLine,
// } from 'recharts';
// import styles from './process-analytics-dashboard.module.css';
// import { doGetApiCall } from '../../../../utils/ClonosApi';

// const PROCESS_TABS = [
//   { key: 'PT', full: 'Pre-Treatment' },
//   { key: 'ED', full: 'Electro-Deposition' },
//   { key: 'OVEN', full: 'Oven' },
// ];

// const SERIES_COLORS = ['#165BAA', '#D97706']; // Tag A: Primary Blue, Tag B: Warm Amber

// export default function ProcessAnalyticsDashboard() {
//   // 1. Backend Master & History States
//   const [parameterMaster, setParameterMaster] = useState([]);
//   const [historyRaw, setHistoryRaw] = useState([]);
//   const [loadingMaster, setLoadingMaster] = useState(false);
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   // 2. Navigation & Selection States
//   const [currentProcess, setCurrentProcess] = useState('PT');
//   const [currentStageName, setCurrentStageName] = useState('');
//   const [selectedTags, setSelectedTags] = useState([]); // Strictly capped at 2 tags
//   const [customLimits, setCustomLimits] = useState({});

//   // 3. Inputs Draft State
//   const [dateMode, setDateMode] = useState('range');
//   const [singleDate, setSingleDate] = useState('2026-08-04T04:30');
//   const [fromDate, setFromDate] = useState('2026-08-01T00:00');
//   const [toDate, setToDate] = useState('2026-08-31T23:59');

//   // 4. Applied State (History API and Chart ONLY listen to this)
//   const [appliedParams, setAppliedParams] = useState({
//     mode: 'range',
//     startDate: '2026-08-01T00:00:00.000Z',
//     endDate: '2026-08-31T23:59:59.999Z',
//     bucket: 'day',
//     appliedLimitsVersion: 0,
//   });

//   // Fetch Parameter Master on mount
//   useEffect(() => {
//     const getParameterMaster = async () => {
//       try {
//         setLoadingMaster(true);
//         const res = await doGetApiCall({ url: '/tags/dashboard/trend/parameter-master' });
//         if (res?.data?.result && Array.isArray(res.data.result)) {
//           setParameterMaster(res.data.result);
//         }
//       } catch (err) {
//         console.error('Failed to fetch parameter master:', err);
//       } finally {
//         setLoadingMaster(false);
//       }
//     };
//     getParameterMaster();
//   }, []);

//   // Dynamically group parameters by process and stage
//   const groupedStages = useMemo(() => {
//     const processItems = parameterMaster.filter(
//       (item) => (item.process || '').toUpperCase() === currentProcess
//     );

//     const stagesMap = new Map();
//     processItems.forEach((item) => {
//       const stageName = (item.stage || 'General').trim();
//       if (!stagesMap.has(stageName)) {
//         stagesMap.set(stageName, []);
//       }
//       stagesMap.get(stageName).push(item);
//     });

//     return Array.from(stagesMap.entries()).map(([name, tags]) => ({
//       name,
//       tags,
//     }));
//   }, [parameterMaster, currentProcess]);

//   // Synchronize current stage when switching process tabs
//   useEffect(() => {
//     if (groupedStages.length > 0) {
//       const exists = groupedStages.some((st) => st.name === currentStageName);
//       if (!exists) {
//         setCurrentStageName(groupedStages[0].name);
//       }
//     } else {
//       setCurrentStageName('');
//     }
//   }, [groupedStages, currentProcess, currentStageName]);

//   const activeStage = useMemo(() => {
//     return (
//       groupedStages.find((st) => st.name === currentStageName) ||
//       groupedStages[0] || { name: '', tags: [] }
//     );
//   }, [groupedStages, currentStageName]);

//   // Handler called on "Apply" button click
//   const handleApplyDate = () => {
//     let startIso, endIso;
//     if (dateMode === 'day') {
//       if (!singleDate) return;
//       const base = new Date(singleDate);
//       const start = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 0, 0, 0);
//       const end = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 23, 59, 59);
//       startIso = start.toISOString();
//       endIso = end.toISOString();
//     } else {
//       if (!fromDate || !toDate) return;
//       startIso = new Date(fromDate).toISOString();
//       endIso = new Date(toDate).toISOString();
//     }

//     setAppliedParams((prev) => ({
//       mode: dateMode,
//       startDate: startIso,
//       endDate: endIso,
//       bucket: dateMode === 'day' ? 'hour' : 'day',
//       appliedLimitsVersion: prev.appliedLimitsVersion + 1,
//     }));
//   };

//   // Safe limits retrieval (draft strings parsed to numbers without mutating inputs)
//   const getEffectiveLimits = (tag) => {
//     if (!tag) return { low: null, high: null };
//     const override = customLimits[tag.tagId];

//     const parsedLow =
//       override?.low !== undefined && override?.low !== ''
//         ? parseFloat(override.low)
//         : tag.min;
//     const parsedHigh =
//       override?.high !== undefined && override?.high !== ''
//         ? parseFloat(override.high)
//         : tag.max;

//     return {
//       low: isNaN(parsedLow) ? null : parsedLow,
//       high: isNaN(parsedHigh) ? null : parsedHigh,
//     };
//   };

//   const isOOS = (val, tag) => {
//     const { low, high } = getEffectiveLimits(tag);
//     if (low != null && val < low) return true;
//     if (high != null && val > high) return true;
//     return false;
//   };

//   // Card Selection Toggle (Atomic FIFO strictly capped at 2 cards)
//   const handleTagToggle = (stageName, tag) => {
//     setSelectedTags((prev) => {
//       const isSameTag = (item) =>
//         item.tag.tagId === tag.tagId && item.tag.parameter === tag.parameter;

//       const exists = prev.some(isSameTag);

//       if (exists) {
//         return prev.filter((item) => !isSameTag(item));
//       }

//       const newItem = { process: currentProcess, stage: stageName, tag };

//       if (prev.length >= 2) {
//         return [prev[prev.length - 1], newItem];
//       }

//       return [...prev, newItem];
//     });
//   };

//   const getTrackGeometry = (val, tag) => {
//     const { low, high } = getEffectiveLimits(tag);
//     if (low == null && high == null) return { pct: 50 };
//     const minVal = low != null ? low : high * 0.7;
//     const maxVal = high != null ? high : low * 1.3;
//     const span = maxVal - minVal || 1;
//     const buffer = span * 0.35;
//     const domainLow = minVal - buffer;
//     const domainHigh = maxVal + buffer;
//     const pct = Math.max(0, Math.min(100, ((val - domainLow) / (domainHigh - domainLow)) * 100));
//     return { pct };
//   };

//   // Handle manual input field typing smoothly
//   const handleLimitChange = (tagId, field, value) => {
//     setCustomLimits((prev) => {
//       const existing = prev[tagId] || { low: '', high: '' };
//       return {
//         ...prev,
//         [tagId]: {
//           ...existing,
//           [field]: value,
//         },
//       };
//     });
//   };

//   // 5. Fetch History API (Runs on tag selection or Apply button click, NOT on every key stroke)
//   useEffect(() => {
//     const fetchHistory = async () => {
//       if (selectedTags.length === 0) {
//         setHistoryRaw([]);
//         return;
//       }

//       const tagIds = selectedTags.map((s) => s.tag.tagId).filter(Boolean).join(',');
//       if (!tagIds) return;

//       try {
//         setLoadingHistory(true);

//         const activeOverrides = {};
//         selectedTags.forEach((s) => {
//           const custom = customLimits[s.tag.tagId];
//           const lowNum = custom?.low !== '' && custom?.low !== undefined ? parseFloat(custom.low) : null;
//           const highNum = custom?.high !== '' && custom?.high !== undefined ? parseFloat(custom.high) : null;

//           if (lowNum != null || highNum != null) {
//             activeOverrides[s.tag.tagId] = {
//               min: !isNaN(lowNum) ? lowNum : undefined,
//               max: !isNaN(highNum) ? highNum : undefined,
//             };
//           }
//         });

//         let url = `/tags/dashboard/trend/history?tagIds=${tagIds}&startDate=${appliedParams.startDate}&endDate=${appliedParams.endDate}&bucket=${appliedParams.bucket}`;
//         if (Object.keys(activeOverrides).length > 0) {
//           url += `&temporaryRanges=${encodeURIComponent(JSON.stringify(activeOverrides))}`;
//         }

//         const res = await doGetApiCall({ url });
//         if (res?.data?.result && Array.isArray(res.data.result)) {
//           setHistoryRaw(res.data.result);
//         } else {
//           setHistoryRaw([]);
//         }
//       } catch (err) {
//         console.error('History fetch failed:', err);
//         setHistoryRaw([]);
//       } finally {
//         setLoadingHistory(false);
//       }
//     };

//     fetchHistory();
//   }, [selectedTags, appliedParams]);

//   // 6. Pivot History Records for Recharts
//   const chartData = useMemo(() => {
//     if (!historyRaw || historyRaw.length === 0) return [];

//     const timeMap = new Map();

//     historyRaw.forEach((item) => {
//       const rawTime = item.bucketStart || item.timestamp;
//       if (!rawTime) return;

//       if (!timeMap.has(rawTime)) {
//         const d = new Date(rawTime);
//         const label =
//           appliedParams.bucket === 'hour'
//             ? d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
//             : `${String(d.getDate()).padStart(2, '0')} ${d.toLocaleString('en-GB', { month: 'short' })}`;

//         timeMap.set(rawTime, {
//           rawTime,
//           timestamp: label,
//         });
//       }

//       const row = timeMap.get(rawTime);
//       const val = item.average != null ? item.average : item.value;
//       if (val != null) {
//         row[item.tagId] = Number(val);
//       }
//     });

//     return Array.from(timeMap.values()).sort(
//       (a, b) => new Date(a.rawTime) - new Date(b.rawTime)
//     );
//   }, [historyRaw, appliedParams.bucket]);

//   const tagA = selectedTags[0]?.tag;
//   const tagB = selectedTags[1]?.tag;

//   const normalizeUnit = (u) => (u || '').trim().replace(/[º˚]/g, '°').toLowerCase();
//   const isDualAxis = Boolean(
//     tagA && tagB && normalizeUnit(tagA.unit) !== normalizeUnit(tagB.unit)
//   );

//   // Dynamic Y-axis domains so axis spine and limit lines always stay visible
//   const getYDomain = (tag) => {
//     if (!tag) return ['auto', 'auto'];

//     const { low, high } = getEffectiveLimits(tag);
//     const dataValues = chartData
//       .map((d) => d[tag.tagId])
//       .filter((v) => v !== undefined && v !== null && !isNaN(v));

//     if (dataValues.length > 0) {
//       let min = Math.min(...dataValues);
//       let max = Math.max(...dataValues);

//       if (low != null) min = Math.min(min, low);
//       if (high != null) max = Math.max(max, high);

//       const padding = (max - min) * 0.1 || (max !== 0 ? Math.abs(max) * 0.1 : 1);
//       return [+(min - padding).toFixed(2), +(max + padding).toFixed(2)];
//     }

//     if (low != null && high != null) {
//       const span = Math.abs(high - low) || 1;
//       return [+(low - span * 0.25).toFixed(2), +(high + span * 0.25).toFixed(2)];
//     }
//     if (low != null) {
//       return [+(low * 0.8).toFixed(2), +(low * 1.3).toFixed(2)];
//     }
//     if (high != null) {
//       return [+(high * 0.7).toFixed(2), +(high * 1.2).toFixed(2)];
//     }

//     return [0, 100];
//   };

//   const domainLeft = useMemo(() => getYDomain(tagA), [tagA, chartData, customLimits]);
//   const domainRight = useMemo(
//     () => (isDualAxis ? getYDomain(tagB) : domainLeft),
//     [tagB, chartData, customLimits, isDualAxis, domainLeft]
//   );

//   // Separate Statistics for BOTH Tag A and Tag B
//   const tagStatsList = useMemo(() => {
//     if (selectedTags.length === 0 || chartData.length === 0) return [];

//     return selectedTags.map((s, idx) => {
//       const tag = s.tag;
//       const values = chartData
//         .map((d) => d[tag.tagId])
//         .filter((v) => v !== undefined && v !== null && !isNaN(v));

//       if (!values.length) {
//         return {
//           tag,
//           color: SERIES_COLORS[idx],
//           count: 0,
//           avg: '—',
//           min: '—',
//           max: '—',
//           oosCount: 0,
//         };
//       }

//       const count = values.length;
//       const sum = values.reduce((a, b) => a + b, 0);
//       const avg = (sum / count).toFixed(3);
//       const min = Math.min(...values).toFixed(3);
//       const max = Math.max(...values).toFixed(3);
//       const oosCount = values.filter((v) => isOOS(v, tag)).length;

//       return {
//         tag,
//         color: SERIES_COLORS[idx],
//         count,
//         avg: `${avg} ${tag.unit || ''}`.trim(),
//         min: `${min} ${tag.unit || ''}`.trim(),
//         max: `${max} ${tag.unit || ''}`.trim(),
//         oosCount,
//       };
//     });
//   }, [chartData, selectedTags, customLimits]);

//   // Readings Summary Table
//   const readingsSummary = useMemo(() => {
//     if (selectedTags.length === 0) return [];

//     return selectedTags.map((s, idx) => {
//       const tag = s.tag;
//       const values = chartData
//         .map((d) => d[tag.tagId])
//         .filter((v) => v !== undefined && !isNaN(v));

//       if (!values.length) {
//         return {
//           tag,
//           color: SERIES_COLORS[idx],
//           count: 0,
//           avg: '—',
//           min: '—',
//           max: '—',
//           oosCount: 0,
//         };
//       }

//       const count = values.length;
//       const sum = values.reduce((a, b) => a + b, 0);
//       const avg = (sum / count).toFixed(2);
//       const min = Math.min(...values).toFixed(2);
//       const max = Math.max(...values).toFixed(2);
//       const oosCount = values.filter((v) => isOOS(v, tag)).length;

//       return {
//         tag,
//         color: SERIES_COLORS[idx],
//         count,
//         avg: `${avg} ${tag.unit || ''}`.trim(),
//         min,
//         max,
//         oosCount,
//       };
//     });
//   }, [chartData, selectedTags, customLimits]);

//   return (
//     <div className={styles.pageWrapper}>
//       <div className={styles.mainCard}>
//         {/* Header Strip */}
//         <div className={styles.cardTopHeader}>
//           <div className={styles.titleGroup}>
//             <div className={styles.mainTitle}>Process Analytics Dashboard</div>
//             <div className={styles.subMeta}>
//               E-log · {parameterMaster.length > 0 ? `${parameterMaster.length} Parameters Configured` : 'Connecting...'}
//             </div>
//           </div>
//           <div className={styles.liveBadge}>
//             <span className={styles.liveDot}></span> Live
//           </div>
//         </div>

//         {/* Scrollable Content Body */}
//         <div className={styles.cardBody}>
//           {/* Primary Process Tabs */}
//           <div className={styles.toggleRow}>
//             <div className={styles.pillContainer}>
//               {PROCESS_TABS.map((tab) => (
//                 <button
//                   key={tab.key}
//                   type="button"
//                   className={`${styles.pillButton} ${currentProcess === tab.key ? styles.pillActive : ''}`}
//                   onClick={() => {
//                     setCurrentProcess(tab.key);
//                     setCurrentStageName('');
//                   }}
//                 >
//                   {tab.full}
//                 </button>
//               ))}
//             </div>
//           </div>

//           {/* Sub-Pills (Stages) */}
//           {groupedStages.length > 0 && (
//             <div className={styles.subPillRow}>
//               {groupedStages.map((st) => (
//                 <button
//                   key={st.name}
//                   type="button"
//                   className={`${styles.stagePill} ${activeStage.name === st.name ? styles.stagePillActive : ''}`}
//                   onClick={() => setCurrentStageName(st.name)}
//                 >
//                   {st.name}
//                 </button>
//               ))}
//             </div>
//           )}

//           {/* Section Header */}
//           <div className={styles.sectionHeaderRow}>
//             <div className={styles.sectionTitle}>
//               {activeStage.name ? `${activeStage.name.toUpperCase()} — LIVE DATA` : 'NO STAGE SELECTED'}
//             </div>
//           </div>

//           {/* KPI Cards Grid */}
//           <div className={styles.cardGrid}>
//             {loadingMaster ? (
//               <div className={styles.emptyNotice}>Loading parameters...</div>
//             ) : activeStage.tags.length > 0 ? (
//               activeStage.tags.map((tag, idx) => {
//                 const { low, high } = getEffectiveLimits(tag);
//                 const isSelected = selectedTags.some(
//                   (s) => s.tag.tagId === tag.tagId && s.tag.parameter === tag.parameter
//                 );

//                 // Oven tags never have default min/max: keep them as inputs permanently
//                 const isManualTag = tag.min == null && tag.max == null;

//                 const val = tag.latestValue != null ? Number(tag.latestValue) : null;
//                 const oos = !isManualTag && val != null && isOOS(val, tag);
//                 const geo = getTrackGeometry(val, tag);

//                 return (
//                   <div
//                     key={`${tag.id || idx}-${tag.tagId}-${activeStage.name}`}
//                     className={`
//                       ${styles.kpiCard} 
//                       ${oos ? styles.kpiCardBreach : styles.kpiCardNormal}
//                       ${isSelected ? styles.kpiCardSelected : ''}
//                     `}
//                     onClick={() => handleTagToggle(activeStage.name, tag)}
//                   >
//                     <div className={styles.cardHeader}>
//                       <span className={styles.cardTagTitle} title={tag.parameter}>
//                         {tag.parameter}
//                       </span>
//                       <div className={`${styles.cardCheckbox} ${isSelected ? styles.checkboxChecked : ''}`}>
//                         {isSelected ? '✓' : ''}
//                       </div>
//                     </div>

//                     <div className={`${styles.cardValue} ${oos ? styles.valueBreach : styles.valueNormal}`}>
//                       {val != null ? val.toFixed(2) : '—'}
//                     </div>

//                     <div className={styles.cardMeta}>
//                       Updated at: {tag.lastUpdated ? new Date(tag.lastUpdated).toLocaleString('en-GB') : 'Waiting for sync...'}
//                     </div>
//                     <div className={styles.cardMeta}>
//                       Spec: {tag.range || `${low ?? '–∞'} – ${high ?? '+∞'}`} {tag.unit || ''}
//                     </div>

//                     {/* Inputs persist for manual/oven stages without unmounting */}
//                     {isManualTag ? (
//                       <div className={styles.manualLimitSection} onClick={(e) => e.stopPropagation()}>
//                         <div className={styles.manualInputsRow}>
//                           <input
//                             type="number"
//                             step="any"
//                             placeholder="Low"
//                             className={styles.limitInput}
//                             value={customLimits[tag.tagId]?.low ?? ''}
//                             onChange={(e) => handleLimitChange(tag.tagId, 'low', e.target.value)}
//                           />
//                           <input
//                             type="number"
//                             step="any"
//                             placeholder="High"
//                             className={styles.limitInput}
//                             value={customLimits[tag.tagId]?.high ?? ''}
//                             onChange={(e) => handleLimitChange(tag.tagId, 'high', e.target.value)}
//                           />
//                         </div>
//                         <div className={styles.pendingHint}>enter custom limits</div>
//                       </div>
//                     ) : (
//                       <>
//                         <div className={styles.rangeTrack}>
//                           <div
//                             className={`${styles.rangeFill} ${oos ? styles.fillBreach : styles.fillNormal}`}
//                             style={{ width: `${geo.pct}%` }}
//                           />
//                           <div
//                             className={`${styles.rangeMarker} ${oos ? styles.markerBreach : styles.markerNormal}`}
//                             style={{ left: `${geo.pct}%` }}
//                           />
//                         </div>
//                         <div className={styles.rangeLabels}>
//                           <span>{low ?? ''}</span>
//                           <span>{high ?? ''}</span>
//                         </div>
//                       </>
//                     )}
//                   </div>
//                 );
//               })
//             ) : (
//               <div className={styles.emptyNotice}>No parameters found for this stage.</div>
//             )}
//           </div>

//           {/* Active Comparison Bar */}
//           {selectedTags.length > 0 && (
//             <div className={styles.compareBar}>
//               <span className={styles.compareLabel}>Active Comparison ({selectedTags.length}/2):</span>
//               {selectedTags.map((s, idx) => (
//                 <span key={`${s.tag.tagId}-${s.tag.parameter}`} className={styles.chip}>
//                   <span className={styles.chipDot} style={{ background: SERIES_COLORS[idx] }}></span>
//                   {s.tag.parameter} ({s.tag.unit || 'val'})
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleTagToggle(s.stage, s.tag);
//                     }}
//                   >
//                     ×
//                   </button>
//                 </span>
//               ))}
//             </div>
//           )}

//           {/* Chart Section */}
//           <div className={styles.chartSection}>
//             <div className={styles.chartHeaderRow}>
//               <div>
//                 <div className={styles.chartTitle}>
//                   {selectedTags.length > 0
//                     ? `${selectedTags[0].stage} — ${selectedTags.map((s) => s.tag.parameter).join(' vs ')}`
//                     : 'Process Trend Overview'}
//                 </div>
//                 {tagA && (
//                   <div className={styles.chartSpecSub}>
//                     {isDualAxis
//                       ? `Comparing different units: Left (${tagA.unit}) vs Right (${tagB?.unit})`
//                       : `Spec range: ${getEffectiveLimits(tagA).low ?? '–∞'} – ${getEffectiveLimits(tagA).high ?? '+∞'} ${tagA.unit}`}
//                   </div>
//                 )}
//               </div>

//               {/* Date Controls */}
//               <div className={styles.dateControlGroup}>
//                 <div className={styles.modeField}>
//                   <label className={styles.dateLabel}>MODE</label>
//                   <div className={styles.dateModeContainer}>
//                     <button
//                       type="button"
//                       className={`${styles.dateModeBtn} ${dateMode === 'day' ? styles.dateModeActive : ''}`}
//                       onClick={() => setDateMode('day')}
//                     >
//                       Single Day
//                     </button>
//                     <button
//                       type="button"
//                       className={`${styles.dateModeBtn} ${dateMode === 'range' ? styles.dateModeActive : ''}`}
//                       onClick={() => setDateMode('range')}
//                     >
//                       Range
//                     </button>
//                   </div>
//                 </div>

//                 <div className={styles.dateField}>
//                   <label className={styles.dateLabel}>{dateMode === 'day' ? 'DATE' : 'FROM'}</label>
//                   <input
//                     type="datetime-local"
//                     value={dateMode === 'day' ? singleDate : fromDate}
//                     onChange={(e) => {
//                       if (dateMode === 'day') setSingleDate(e.target.value);
//                       else setFromDate(e.target.value);
//                     }}
//                   />
//                 </div>

//                 <div
//                   className={`${styles.dateField} ${styles.collapsibleField} ${
//                     dateMode === 'range' ? styles.fieldExpanded : styles.fieldCollapsed
//                   }`}
//                 >
//                   <label className={styles.dateLabel}>TO</label>
//                   <input
//                     type="datetime-local"
//                     value={toDate}
//                     onChange={(e) => setToDate(e.target.value)}
//                     tabIndex={dateMode === 'range' ? 0 : -1}
//                   />
//                 </div>

//                 <button
//                   type="button"
//                   className={styles.applyBtn}
//                   onClick={handleApplyDate}
//                 >
//                   Apply
//                 </button>
//               </div>
//             </div>

//             {/* Recharts Canvas */}
//             {selectedTags.length > 0 ? (
//               <div className={styles.chartWrapper}>
//                 {loadingHistory && <div className={styles.chartLoadingOverlay}>Updating trend...</div>}
//                 <ResponsiveContainer width="100%" height={230}>
//                   <LineChart data={chartData} margin={{ top: 14, right: 40, left: 10, bottom: 5 }}>
//                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ECEFF1" />
//                     <XAxis dataKey="timestamp" stroke="#90A4AE" tick={{ fontSize: 9.5 }} />

//                     {/* Tag A: Left Y-Axis */}
//                     <YAxis
//                       yAxisId="left"
//                       orientation="left"
//                       stroke={SERIES_COLORS[0]}
//                       unit={tagA?.unit ? ` ${tagA.unit}` : ''}
//                       domain={domainLeft}
//                       tick={{ fontSize: 9.5, fill: '#546E7A' }}
//                       allowDataOverflow={false}
//                     />

//                     {/* Tag B: Right Y-Axis */}
//                     {tagB && (
//                       <YAxis
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         orientation="right"
//                         stroke={SERIES_COLORS[1]}
//                         unit={tagB?.unit ? ` ${tagB.unit}` : ''}
//                         domain={domainRight}
//                         tick={{ fontSize: 9.5, fill: '#546E7A' }}
//                         hide={!isDualAxis}
//                         allowDataOverflow={false}
//                       />
//                     )}

//                     <Tooltip
//                       contentStyle={{
//                         backgroundColor: '#FFFFFF',
//                         borderColor: '#DCE3EC',
//                         borderRadius: 6,
//                         boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
//                         fontSize: 11,
//                         color: '#1E2530',
//                         padding: '6px 10px',
//                       }}
//                       labelStyle={{ color: '#546E7A', fontWeight: 600, marginBottom: 4 }}
//                       itemStyle={{ padding: '1px 0' }}
//                     />

//                     {/* TAG A LIMITS (Plotted on Left Axis) */}
//                     {getEffectiveLimits(tagA).low != null && (
//                       <ReferenceLine
//                         yAxisId="left"
//                         y={getEffectiveLimits(tagA).low}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `L-Lower Limit (${getEffectiveLimits(tagA).low})`,
//                           position: 'insideBottomLeft',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {getEffectiveLimits(tagA).high != null && (
//                       <ReferenceLine
//                         yAxisId="left"
//                         y={getEffectiveLimits(tagA).high}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `L-Upper Limit (${getEffectiveLimits(tagA).high})`,
//                           position: 'insideTopLeft',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* TAG B LIMITS */}
//                     {tagB && getEffectiveLimits(tagB).low != null && (
//                       <ReferenceLine
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         y={getEffectiveLimits(tagB).low}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `R-Lower Limit (${getEffectiveLimits(tagB).low})`,
//                           position: 'insideBottomRight',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {tagB && getEffectiveLimits(tagB).high != null && (
//                       <ReferenceLine
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         y={getEffectiveLimits(tagB).high}
//                         stroke="#D32F2F"
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         label={{
//                           value: `R-Upper Limit (${getEffectiveLimits(tagB).high})`,
//                           position: 'insideTopRight',
//                           fontSize: 9.5,
//                           fill: '#D32F2F',
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* Primary Line Series (Tag A) */}
//                     <Line
//                       yAxisId="left"
//                       type="monotone"
//                       dataKey={tagA.tagId}
//                       name={tagA.parameter}
//                       stroke={SERIES_COLORS[0]}
//                       strokeWidth={1.8}
//                       dot={{ r: 2, fill: SERIES_COLORS[0], strokeWidth: 0 }}
//                       activeDot={{ r: 4, fill: SERIES_COLORS[0], stroke: '#FFFFFF', strokeWidth: 2 }}
//                       connectNulls
//                     />

//                     {/* Secondary Line Series (Tag B) */}
//                     {tagB && (
//                       <Line
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         type="monotone"
//                         dataKey={tagB.tagId}
//                         name={tagB.parameter}
//                         stroke={SERIES_COLORS[1]}
//                         strokeWidth={1.8}
//                         dot={{ r: 2, fill: SERIES_COLORS[1], strokeWidth: 0 }}
//                         activeDot={{ r: 4, fill: SERIES_COLORS[1], stroke: '#FFFFFF', strokeWidth: 2 }}
//                         connectNulls
//                       />
//                     )}
//                   </LineChart>
//                 </ResponsiveContainer>

//                 {/* Footer Legend & Side-by-Side (Left / Right) Analytics Strips */}
//                 <div className={styles.chartFooter}>
//                   <div className={styles.legendGroup}>
//                     <span className={styles.legendItem}>
//                       <span className={styles.legendLineBlue}></span> {tagA.parameter}
//                     </span>
//                     {tagB && (
//                       <span className={styles.legendItem}>
//                         <span className={styles.legendLineOrange}></span> {tagB.parameter}
//                       </span>
//                     )}
//                     <span className={styles.legendItem}>
//                       <span className={styles.legendLineRedDashed}></span> {tagA.parameter} Limits ({getEffectiveLimits(tagA).low ?? '–∞'} – {getEffectiveLimits(tagA).high ?? '+∞'})
//                     </span>
//                     {tagB && (
//                       <span className={styles.legendItem}>
//                         <span className={styles.legendLineRedDashed}></span> {tagB.parameter} Limits ({getEffectiveLimits(tagB).low ?? '–∞'} – {getEffectiveLimits(tagB).high ?? '+∞'})
//                       </span>
//                     )}
//                   </div>

//                   {/* Side-by-Side Dual Column Panels (Left = Tag A, Right = Tag B) */}
//                   {tagStatsList.length > 0 && (
//                     <div
//                       style={{
//                         display: 'grid',
//                         gridTemplateColumns: tagStatsList.length === 2 ? '1fr 1fr' : '1fr',
//                         gap: '12px',
//                         marginTop: '12px',
//                       }}
//                     >
//                       {tagStatsList.map((stat, idx) => (
//                         <div
//                           key={`${stat.tag.tagId}-${stat.tag.parameter}`}
//                           style={{
//                             display: 'flex',
//                             flexDirection: 'column',
//                             gap: '6px',
//                             padding: '9px 12px',
//                             backgroundColor: idx === 0 ? '#F3F7FC' : '#FEF8F1',
//                             borderLeft: `4px solid ${stat.color}`,
//                             borderRadius: '4px',
//                             fontSize: '11px',
//                             color: '#37474F',
//                             boxSizing: 'border-box',
//                           }}
//                         >
//                           <div
//                             style={{
//                               display: 'flex',
//                               alignItems: 'center',
//                               justifyContent: 'space-between',
//                               borderBottom: '1px solid rgba(0,0,0,0.06)',
//                               paddingBottom: '4px',
//                             }}
//                           >
//                             <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, color: stat.color }}>
//                               <span style={{ width: 8, height: 8, borderRadius: '50%', backgroundColor: stat.color }} />
//                               <span>{idx === 0 ? 'LEFT AXIS (TAG A)' : 'RIGHT AXIS (TAG B)'}: {stat.tag.parameter}</span>
//                             </div>
//                             <span style={{ fontSize: '10px', color: '#78909C', fontWeight: 600 }}>
//                               Spec: {getEffectiveLimits(stat.tag).low ?? '–∞'} – {getEffectiveLimits(stat.tag).high ?? '+∞'} {stat.tag.unit || ''}
//                             </span>
//                           </div>

//                           <div
//                             style={{
//                               display: 'flex',
//                               alignItems: 'center',
//                               justifyContent: 'space-between',
//                               flexWrap: 'wrap',
//                               gap: '8px',
//                               paddingTop: '2px',
//                             }}
//                           >
//                             <span>Readings: <b>{stat.count}</b></span>
//                             <span>Avg: <b>{stat.avg}</b></span>
//                             <span>Min: <b>{stat.min}</b></span>
//                             <span>Max: <b>{stat.max}</b></span>
//                             <span>
//                               OOS:{' '}
//                               <b style={{ color: stat.oosCount > 0 ? '#D32F2F' : '#37474F' }}>
//                                 {stat.oosCount} / {stat.count}
//                               </b>
//                             </span>
//                           </div>
//                         </div>
//                       ))}
//                     </div>
//                   )}
//                 </div>
//               </div>
//             ) : (
//               <div className={styles.emptyNotice}>
//                 Select a parameter card checkbox above to begin plotting.
//               </div>
//             )}
//           </div>

//           {/* Readings Summary Table */}
//           {selectedTags.length > 0 && readingsSummary.length > 0 && (
//             <div className={styles.summaryTableCard}>
//               <div className={styles.summaryTableTitle}>Readings summary</div>
//               <div className={styles.tableWrapper}>
//                 <table className={styles.summaryTable}>
//                   <thead>
//                     <tr>
//                       <th className={styles.thTag}>TAG</th>
//                       <th className={styles.thCol}>READINGS</th>
//                       <th className={styles.thCol}>AVG</th>
//                       <th className={styles.thCol}>MIN</th>
//                       <th className={styles.thCol}>MAX</th>
//                       <th className={styles.thCol}>OUT OF SPEC</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {readingsSummary.map((row) => (
//                       <tr key={`${row.tag.tagId}-${row.tag.parameter}`}>
//                         <td className={styles.tdTag}>
//                           <span
//                             className={styles.rowDot}
//                             style={{ backgroundColor: row.color }}
//                           />
//                           <span className={styles.rowTagName}>{row.tag.parameter}</span>
//                         </td>
//                         <td className={styles.tdVal}>{row.count}</td>
//                         <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.avg}</td>
//                         <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.min}</td>
//                         <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.max}</td>
//                         <td className={`${styles.tdVal} ${styles.tdOos}`}>
//                           {row.oosCount} / {row.count}
//                         </td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }
//this is last working codde
// import React, { useState, useMemo, useEffect } from 'react';
// import {
//   ResponsiveContainer,
//   LineChart,
//   Line,
//   XAxis,
//   YAxis,
//   Tooltip,
//   CartesianGrid,
//   ReferenceLine,
// } from 'recharts';
// import styles from './process-analytics-dashboard.module.css';
// import { doGetApiCall } from '../../../../utils/ClonosApi';

// const PROCESS_TABS = [
//   { key: 'PT', full: 'Pre-Treatment' },
//   { key: 'ED', full: 'Electro-Deposition' },
//   { key: 'OVEN', full: 'Oven' },
// ];

// const SERIES_COLORS = ['#165BAA', '#D97706']; // Tag A: Primary Blue, Tag B: Warm Amber
// const LIMIT_LINE_COLOR = '#D32F2F'; // Standard Red for all 4 target lines

// export default function ProcessAnalyticsDashboard() {
//   // 1. Backend Master & History States
//   const [parameterMaster, setParameterMaster] = useState([]);
//   const [historyRaw, setHistoryRaw] = useState([]);
//   const [loadingMaster, setLoadingMaster] = useState(false);
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   // 2. Navigation & Selection States
//   const [currentProcess, setCurrentProcess] = useState('PT');
//   const [currentStageName, setCurrentStageName] = useState('');
//   const [selectedTags, setSelectedTags] = useState([]); // Strictly max 2 tags
//   const [customLimits, setCustomLimits] = useState({});

//   // 3. Inputs Draft State
//   const [dateMode, setDateMode] = useState('range');
//   const [singleDate, setSingleDate] = useState('2026-08-04T04:30');
//   const [fromDate, setFromDate] = useState('2026-08-01T00:00');
//   const [toDate, setToDate] = useState('2026-08-31T23:59');

//   // 4. Applied State (History API and Chart ONLY listen to this)
//   const [appliedParams, setAppliedParams] = useState({
//     mode: 'range',
//     startDate: '2026-08-01T00:00:00.000Z',
//     endDate: '2026-08-31T23:59:59.999Z',
//     bucket: 'day',
//     appliedLimitsVersion: 0,
//   });

//   // Fetch Parameter Master on mount
//   useEffect(() => {
//     const getParameterMaster = async () => {
//       try {
//         setLoadingMaster(true);
//         const res = await doGetApiCall({ url: '/tags/dashboard/trend/parameter-master' });
//         if (res?.data?.result && Array.isArray(res.data.result)) {
//           setParameterMaster(res.data.result);
//         }
//       } catch (err) {
//         console.error('Failed to fetch parameter master:', err);
//       } finally {
//         setLoadingMaster(false);
//       }
//     };
//     getParameterMaster();
//   }, []);

//   // Dynamically group parameters by process and stage
//   const groupedStages = useMemo(() => {
//     const processItems = parameterMaster.filter(
//       (item) => (item.process || '').toUpperCase() === currentProcess
//     );

//     const stagesMap = new Map();
//     processItems.forEach((item) => {
//       const stageName = (item.stage || 'General').trim();
//       if (!stagesMap.has(stageName)) {
//         stagesMap.set(stageName, []);
//       }
//       stagesMap.get(stageName).push(item);
//     });

//     return Array.from(stagesMap.entries()).map(([name, tags]) => ({
//       name,
//       tags,
//     }));
//   }, [parameterMaster, currentProcess]);

//   // Synchronize current stage when switching process tabs
//   useEffect(() => {
//     if (groupedStages.length > 0) {
//       const exists = groupedStages.some((st) => st.name === currentStageName);
//       if (!exists) {
//         setCurrentStageName(groupedStages[0].name);
//       }
//     } else {
//       setCurrentStageName('');
//     }
//   }, [groupedStages, currentProcess, currentStageName]);

//   const activeStage = useMemo(() => {
//     return (
//       groupedStages.find((st) => st.name === currentStageName) ||
//       groupedStages[0] || { name: '', tags: [] }
//     );
//   }, [groupedStages, currentStageName]);

//   // Handler called on "Apply" button click
//   const handleApplyDate = () => {
//     let startIso, endIso;
//     if (dateMode === 'day') {
//       if (!singleDate) return;
//       const base = new Date(singleDate);
//       const start = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 0, 0, 0);
//       const end = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 23, 59, 59);
//       startIso = start.toISOString();
//       endIso = end.toISOString();
//     } else {
//       if (!fromDate || !toDate) return;
//       startIso = new Date(fromDate).toISOString();
//       endIso = new Date(toDate).toISOString();
//     }

//     setAppliedParams((prev) => ({
//       mode: dateMode,
//       startDate: startIso,
//       endDate: endIso,
//       bucket: dateMode === 'day' ? 'hour' : 'day',
//       appliedLimitsVersion: prev.appliedLimitsVersion + 1,
//     }));
//   };

//   // Safe limits retrieval (draft strings parsed to numbers without mutating inputs)
//   const getEffectiveLimits = (tag) => {
//     if (!tag) return { low: null, high: null };
//     const override = customLimits[tag.tagId];

//     const parsedLow =
//       override?.low !== undefined && override?.low !== ''
//         ? parseFloat(override.low)
//         : tag.min;
//     const parsedHigh =
//       override?.high !== undefined && override?.high !== ''
//         ? parseFloat(override.high)
//         : tag.max;

//     return {
//       low: isNaN(parsedLow) ? null : parsedLow,
//       high: isNaN(parsedHigh) ? null : parsedHigh,
//     };
//   };

//   const isOOS = (val, tag) => {
//     const { low, high } = getEffectiveLimits(tag);
//     if (low != null && val < low) return true;
//     if (high != null && val > high) return true;
//     return false;
//   };

//   // Card Selection Toggle (Atomic FIFO strictly capped at 2 cards)
//   const handleTagToggle = (stageName, tag) => {
//     setSelectedTags((prev) => {
//       const isSameTag = (item) =>
//         item.tag.tagId === tag.tagId && item.tag.parameter === tag.parameter;

//       const exists = prev.some(isSameTag);

//       if (exists) {
//         return prev.filter((item) => !isSameTag(item));
//       }

//       const newItem = { process: currentProcess, stage: stageName, tag };

//       if (prev.length >= 2) {
//         return [prev[prev.length - 1], newItem];
//       }

//       return [...prev, newItem];
//     });
//   };

//   const getTrackGeometry = (val, tag) => {
//     const { low, high } = getEffectiveLimits(tag);
//     if (low == null && high == null) return { pct: 50 };
//     const minVal = low != null ? low : high * 0.7;
//     const maxVal = high != null ? high : low * 1.3;
//     const span = maxVal - minVal || 1;
//     const buffer = span * 0.35;
//     const domainLow = minVal - buffer;
//     const domainHigh = maxVal + buffer;
//     const pct = Math.max(0, Math.min(100, ((val - domainLow) / (domainHigh - domainLow)) * 100));
//     return { pct };
//   };

//   // Handle manual input field typing smoothly
//   const handleLimitChange = (tagId, field, value) => {
//     setCustomLimits((prev) => {
//       const existing = prev[tagId] || { low: '', high: '' };
//       return {
//         ...prev,
//         [tagId]: {
//           ...existing,
//           [field]: value,
//         },
//       };
//     });
//   };

//   // 5. Fetch History API (Triggered on tag selection or Apply button click)
//   useEffect(() => {
//     const fetchHistory = async () => {
//       if (selectedTags.length === 0) {
//         setHistoryRaw([]);
//         return;
//       }

//       const tagIds = selectedTags.map((s) => s.tag.tagId).filter(Boolean).join(',');
//       if (!tagIds) return;

//       try {
//         setLoadingHistory(true);

//         const activeOverrides = {};
//         selectedTags.forEach((s) => {
//           const custom = customLimits[s.tag.tagId];
//           const lowNum = custom?.low !== '' && custom?.low !== undefined ? parseFloat(custom.low) : null;
//           const highNum = custom?.high !== '' && custom?.high !== undefined ? parseFloat(custom.high) : null;

//           if (lowNum != null || highNum != null) {
//             activeOverrides[s.tag.tagId] = {
//               min: !isNaN(lowNum) ? lowNum : undefined,
//               max: !isNaN(highNum) ? highNum : undefined,
//             };
//           }
//         });

//         let url = `/tags/dashboard/trend/history?tagIds=${tagIds}&startDate=${appliedParams.startDate}&endDate=${appliedParams.endDate}&bucket=${appliedParams.bucket}`;
//         if (Object.keys(activeOverrides).length > 0) {
//           url += `&temporaryRanges=${encodeURIComponent(JSON.stringify(activeOverrides))}`;
//         }

//         const res = await doGetApiCall({ url });
//         if (res?.data?.result && Array.isArray(res.data.result)) {
//           setHistoryRaw(res.data.result);
//         } else {
//           setHistoryRaw([]);
//         }
//       } catch (err) {
//         console.error('History fetch failed:', err);
//         setHistoryRaw([]);
//       } finally {
//         setLoadingHistory(false);
//       }
//     };

//     fetchHistory();
//   }, [selectedTags, appliedParams]);

//   // 6. Pivot History Records for Recharts
//   const chartData = useMemo(() => {
//     if (!historyRaw || historyRaw.length === 0) return [];

//     const timeMap = new Map();

//     historyRaw.forEach((item) => {
//       const rawTime = item.bucketStart || item.timestamp;
//       if (!rawTime) return;

//       if (!timeMap.has(rawTime)) {
//         const d = new Date(rawTime);
//         const label =
//           appliedParams.bucket === 'hour'
//             ? d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
//             : `${String(d.getDate()).padStart(2, '0')} ${d.toLocaleString('en-GB', { month: 'short' })}`;

//         timeMap.set(rawTime, {
//           rawTime,
//           timestamp: label,
//         });
//       }

//       const row = timeMap.get(rawTime);
//       const val = item.average != null ? item.average : item.value;
//       if (val != null) {
//         row[item.tagId] = Number(val);
//       }
//     });

//     return Array.from(timeMap.values()).sort(
//       (a, b) => new Date(a.rawTime) - new Date(b.rawTime)
//     );
//   }, [historyRaw, appliedParams.bucket]);

//   const tagA = selectedTags[0]?.tag;
//   const tagB = selectedTags[1]?.tag;

//   const normalizeUnit = (u) => (u || '').trim().replace(/[º˚]/g, '°').toLowerCase();
//   const isDualAxis = Boolean(
//     tagA && tagB && normalizeUnit(tagA.unit) !== normalizeUnit(tagB.unit)
//   );

//   // Dynamic Y-axis domains ensuring all 4 target limits and data remain fully visible
//   const calculateDomain = (tagsForAxis) => {
//     const activeTags = tagsForAxis.filter(Boolean);
//     if (activeTags.length === 0) return [0, 100];

//     let minVal = Infinity;
//     let maxVal = -Infinity;

//     activeTags.forEach((tag) => {
//       const { low, high } = getEffectiveLimits(tag);

//       // Account for target limit lines
//       if (low != null && !isNaN(Number(low))) {
//         minVal = Math.min(minVal, Number(low));
//         maxVal = Math.max(maxVal, Number(low));
//       }
//       if (high != null && !isNaN(Number(high))) {
//         minVal = Math.min(minVal, Number(high));
//         maxVal = Math.max(maxVal, Number(high));
//       }

//       // Account for chart points
//       chartData.forEach((row) => {
//         const val = row[tag.tagId];
//         if (val !== undefined && val !== null && !isNaN(val)) {
//           minVal = Math.min(minVal, Number(val));
//           maxVal = Math.max(maxVal, Number(val));
//         }
//       });
//     });

//     if (minVal === Infinity || maxVal === -Infinity) {
//       return [0, 100];
//     }

//     if (minVal === maxVal) {
//       minVal = minVal > 0 ? minVal * 0.8 : minVal - 1;
//       maxVal = maxVal > 0 ? maxVal * 1.2 : maxVal + 1;
//     }

//     const span = maxVal - minVal;
//     const padding = span * 0.15; // 15% buffer so reference lines never hit borders

//     return [
//       +(minVal - padding).toFixed(2),
//       +(maxVal + padding).toFixed(2),
//     ];
//   };

//   const domainLeft = useMemo(
//     () => (isDualAxis ? calculateDomain([tagA]) : calculateDomain([tagA, tagB])),
//     [tagA, tagB, chartData, customLimits, isDualAxis]
//   );

//   const domainRight = useMemo(
//     () => (isDualAxis ? calculateDomain([tagB]) : domainLeft),
//     [tagB, chartData, customLimits, isDualAxis, domainLeft]
//   );

//   // Separate Statistics for BOTH Tag A and Tag B
//   const tagStatsList = useMemo(() => {
//     if (selectedTags.length === 0 || chartData.length === 0) return [];

//     return selectedTags.map((s, idx) => {
//       const tag = s.tag;
//       const values = chartData
//         .map((d) => d[tag.tagId])
//         .filter((v) => v !== undefined && v !== null && !isNaN(v));

//       if (!values.length) {
//         return {
//           tag,
//           color: SERIES_COLORS[idx],
//           count: 0,
//           avg: '—',
//           min: '—',
//           max: '—',
//           oosCount: 0,
//         };
//       }

//       const count = values.length;
//       const sum = values.reduce((a, b) => a + b, 0);
//       const avg = (sum / count).toFixed(3);
//       const min = Math.min(...values).toFixed(3);
//       const max = Math.max(...values).toFixed(3);
//       const oosCount = values.filter((v) => isOOS(v, tag)).length;

//       return {
//         tag,
//         color: SERIES_COLORS[idx],
//         count,
//         avg: `${avg} ${tag.unit || ''}`.trim(),
//         min: `${min} ${tag.unit || ''}`.trim(),
//         max: `${max} ${tag.unit || ''}`.trim(),
//         oosCount,
//       };
//     });
//   }, [chartData, selectedTags, customLimits]);

//   // Readings Summary Table
//   const readingsSummary = useMemo(() => {
//     if (selectedTags.length === 0) return [];

//     return selectedTags.map((s, idx) => {
//       const tag = s.tag;
//       const values = chartData
//         .map((d) => d[tag.tagId])
//         .filter((v) => v !== undefined && !isNaN(v));

//       if (!values.length) {
//         return {
//           tag,
//           color: SERIES_COLORS[idx],
//           count: 0,
//           avg: '—',
//           min: '—',
//           max: '—',
//           oosCount: 0,
//         };
//       }

//       const count = values.length;
//       const sum = values.reduce((a, b) => a + b, 0);
//       const avg = (sum / count).toFixed(2);
//       const min = Math.min(...values).toFixed(2);
//       const max = Math.max(...values).toFixed(2);
//       const oosCount = values.filter((v) => isOOS(v, tag)).length;

//       return {
//         tag,
//         color: SERIES_COLORS[idx],
//         count,
//         avg: `${avg} ${tag.unit || ''}`.trim(),
//         min,
//         max,
//         oosCount,
//       };
//     });
//   }, [chartData, selectedTags, customLimits]);

//   return (
//     <div className={styles.pageWrapper}>
//       <div className={styles.mainCard}>
//         {/* Header Strip */}
//         <div className={styles.cardTopHeader}>
//           <div className={styles.titleGroup}>
//             <div className={styles.mainTitle}>Trend Analysis</div>
//             <div className={styles.subMeta}>
//               E-log · {parameterMaster.length > 0 ? `${parameterMaster.length} Parameters Configured` : 'Connecting...'}
//             </div>
//           </div>
//           <div className={styles.liveBadge}>
//             <span className={styles.liveDot}></span> Live
//           </div>
//         </div>

//         {/* Scrollable Content Body */}
//         <div className={styles.cardBody}>
//           {/* Primary Process Tabs */}
//           <div className={styles.toggleRow}>
//             <div className={styles.pillContainer}>
//               {PROCESS_TABS.map((tab) => (
//                 <button
//                   key={tab.key}
//                   type="button"
//                   className={`${styles.pillButton} ${currentProcess === tab.key ? styles.pillActive : ''}`}
//                   onClick={() => {
//                     setCurrentProcess(tab.key);
//                     setCurrentStageName('');
//                   }}
//                 >
//                   {tab.full}
//                 </button>
//               ))}
//             </div>
//           </div>

//           {/* Sub-Pills (Stages) */}
//           {groupedStages.length > 0 && (
//             <div className={styles.subPillRow}>
//               {groupedStages.map((st) => (
//                 <button
//                   key={st.name}
//                   type="button"
//                   className={`${styles.stagePill} ${activeStage.name === st.name ? styles.stagePillActive : ''}`}
//                   onClick={() => setCurrentStageName(st.name)}
//                 >
//                   {st.name}
//                 </button>
//               ))}
//             </div>
//           )}

//           {/* Section Header */}
//           <div className={styles.sectionHeaderRow}>
//             <div className={styles.sectionTitle}>
//               {activeStage.name ? `${activeStage.name.toUpperCase()} — LIVE DATA` : 'NO STAGE SELECTED'}
//             </div>
//           </div>

//           {/* KPI Cards Grid */}
//           <div className={styles.cardGrid}>
//             {loadingMaster ? (
//               <div className={styles.emptyNotice}>Loading parameters...</div>
//             ) : activeStage.tags.length > 0 ? (
//               activeStage.tags.map((tag, idx) => {
//                 const { low, high } = getEffectiveLimits(tag);
//                 const isSelected = selectedTags.some(
//                   (s) => s.tag.tagId === tag.tagId && s.tag.parameter === tag.parameter
//                 );

//                 const isManualTag = tag.min == null && tag.max == null;
//                 const val = tag.latestValue != null ? Number(tag.latestValue) : null;
//                 const oos = !isManualTag && val != null && isOOS(val, tag);
//                 const geo = getTrackGeometry(val, tag);

//                 return (
//                   <div
//                     key={`${tag.id || idx}-${tag.tagId}-${activeStage.name}`}
//                     className={`
//                       ${styles.kpiCard} 
//                       ${oos ? styles.kpiCardBreach : styles.kpiCardNormal}
//                       ${isSelected ? styles.kpiCardSelected : ''}
//                     `}
//                     onClick={() => handleTagToggle(activeStage.name, tag)}
//                   >
//                     <div className={styles.cardHeader}>
//                       <span className={styles.cardTagTitle} title={tag.parameter}>
//                         {tag.parameter}
//                       </span>
//                       <div className={`${styles.cardCheckbox} ${isSelected ? styles.checkboxChecked : ''}`}>
//                         {isSelected ? '✓' : ''}
//                       </div>
//                     </div>

//                     <div className={`${styles.cardValue} ${oos ? styles.valueBreach : styles.valueNormal}`}>
//                       {val != null ? val.toFixed(2) : '—'}
//                     </div>

//                     <div className={styles.cardMeta}>
//                       Updated at: {tag.lastUpdated ? new Date(tag.lastUpdated).toLocaleString('en-GB') : 'Waiting for sync...'}
//                     </div>
//                     <div className={styles.cardMeta}>
//                       Spec: {tag.range || `${low ?? '–∞'} – ${high ?? '+∞'}`} {tag.unit || ''}
//                     </div>

//                     {isManualTag ? (
//                       <div className={styles.manualLimitSection} onClick={(e) => e.stopPropagation()}>
//                         <div className={styles.manualInputsRow}>
//                           <input
//                             type="number"
//                             step="any"
//                             placeholder="Low"
//                             className={styles.limitInput}
//                             value={customLimits[tag.tagId]?.low ?? ''}
//                             onChange={(e) => handleLimitChange(tag.tagId, 'low', e.target.value)}
//                           />
//                           <input
//                             type="number"
//                             step="any"
//                             placeholder="High"
//                             className={styles.limitInput}
//                             value={customLimits[tag.tagId]?.high ?? ''}
//                             onChange={(e) => handleLimitChange(tag.tagId, 'high', e.target.value)}
//                           />
//                         </div>
//                         <div className={styles.pendingHint}>enter custom limits</div>
//                       </div>
//                     ) : (
//                       <>
//                         <div className={styles.rangeTrack}>
//                           <div
//                             className={`${styles.rangeFill} ${oos ? styles.fillBreach : styles.fillNormal}`}
//                             style={{ width: `${geo.pct}%` }}
//                           />
//                           <div
//                             className={`${styles.rangeMarker} ${oos ? styles.markerBreach : styles.markerNormal}`}
//                             style={{ left: `${geo.pct}%` }}
//                           />
//                         </div>
//                         <div className={styles.rangeLabels}>
//                           <span>{low ?? ''}</span>
//                           <span>{high ?? ''}</span>
//                         </div>
//                       </>
//                     )}
//                   </div>
//                 );
//               })
//             ) : (
//               <div className={styles.emptyNotice}>No parameters found for this stage.</div>
//             )}
//           </div>

//           {/* Active Comparison Bar */}
//           {selectedTags.length > 0 && (
//             <div className={styles.compareBar}>
//               <span className={styles.compareLabel}>Active Comparison ({selectedTags.length}/2):</span>
//               {selectedTags.map((s, idx) => (
//                 <span key={`${s.tag.tagId}-${s.tag.parameter}`} className={styles.chip}>
//                   <span className={styles.chipDot} style={{ background: SERIES_COLORS[idx] }}></span>
//                   {s.tag.parameter} ({s.tag.unit || 'val'})
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleTagToggle(s.stage, s.tag);
//                     }}
//                   >
//                     ×
//                   </button>
//                 </span>
//               ))}
//             </div>
//           )}

//           {/* Chart Section */}
//           <div className={styles.chartSection}>
//             <div className={styles.chartHeaderRow}>
//               <div>
//                 <div className={styles.chartTitle}>
//                   {selectedTags.length > 0
//                     ? `${selectedTags[0].stage} — ${selectedTags.map((s) => s.tag.parameter).join(' vs ')}`
//                     : 'Process Trend Overview'}
//                 </div>
//                 {tagA && (
//                   <div className={styles.chartSpecSub}>
//                     {isDualAxis
//                       ? `Comparing different units: Left (${tagA.unit}) vs Right (${tagB?.unit})`
//                       : `Spec range: ${getEffectiveLimits(tagA).low ?? '–∞'} – ${getEffectiveLimits(tagA).high ?? '+∞'} ${tagA.unit}`}
//                   </div>
//                 )}
//               </div>

//               {/* Date Controls */}
//               <div className={styles.dateControlGroup}>
//                 <div className={styles.modeField}>
//                   <label className={styles.dateLabel}>MODE</label>
//                   <div className={styles.dateModeContainer}>
//                     <button
//                       type="button"
//                       className={`${styles.dateModeBtn} ${dateMode === 'day' ? styles.dateModeActive : ''}`}
//                       onClick={() => setDateMode('day')}
//                     >
//                       Single Day
//                     </button>
//                     <button
//                       type="button"
//                       className={`${styles.dateModeBtn} ${dateMode === 'range' ? styles.dateModeActive : ''}`}
//                       onClick={() => setDateMode('range')}
//                     >
//                       Range
//                     </button>
//                   </div>
//                 </div>

//                 <div className={styles.dateField}>
//                   <label className={styles.dateLabel}>{dateMode === 'day' ? 'DATE' : 'FROM'}</label>
//                   <input
//                     type="datetime-local"
//                     value={dateMode === 'day' ? singleDate : fromDate}
//                     onChange={(e) => {
//                       if (dateMode === 'day') setSingleDate(e.target.value);
//                       else setFromDate(e.target.value);
//                     }}
//                   />
//                 </div>

//                 <div
//                   className={`${styles.dateField} ${styles.collapsibleField} ${
//                     dateMode === 'range' ? styles.fieldExpanded : styles.fieldCollapsed
//                   }`}
//                 >
//                   <label className={styles.dateLabel}>TO</label>
//                   <input
//                     type="datetime-local"
//                     value={toDate}
//                     onChange={(e) => setToDate(e.target.value)}
//                     tabIndex={dateMode === 'range' ? 0 : -1}
//                   />
//                 </div>

//                 <button
//                   type="button"
//                   className={styles.applyBtn}
//                   onClick={handleApplyDate}
//                 >
//                   Apply
//                 </button>
//               </div>
//             </div>

//             {/* Recharts Canvas */}
//             {selectedTags.length > 0 ? (
//               <div className={styles.chartWrapper}>
//                 {loadingHistory && <div className={styles.chartLoadingOverlay}>Updating trend...</div>}
//                 <ResponsiveContainer width="100%" height={230}>
//                   <LineChart data={chartData} margin={{ top: 14, right: 40, left: 10, bottom: 5 }}>
//                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ECEFF1" />
//                     <XAxis dataKey="timestamp" stroke="#90A4AE" tick={{ fontSize: 9.5 }} />

//                     {/* Tag A: Left Y-Axis */}
//                     <YAxis
//                       yAxisId="left"
//                       orientation="left"
//                       stroke={SERIES_COLORS[0]}
//                       unit={tagA?.unit ? ` ${tagA.unit}` : ''}
//                       domain={domainLeft}
//                       tick={{ fontSize: 9.5, fill: '#546E7A' }}
//                       allowDataOverflow={false}
//                     />

//                     {/* Tag B: Right Y-Axis */}
//                     {tagB && (
//                       <YAxis
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         orientation="right"
//                         stroke={SERIES_COLORS[1]}
//                         unit={tagB?.unit ? ` ${tagB.unit}` : ''}
//                         domain={domainRight}
//                         tick={{ fontSize: 9.5, fill: '#546E7A' }}
//                         hide={!isDualAxis}
//                         allowDataOverflow={false}
//                       />
//                     )}

//                     <Tooltip
//                       contentStyle={{
//                         backgroundColor: '#FFFFFF',
//                         borderColor: '#DCE3EC',
//                         borderRadius: 6,
//                         boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
//                         fontSize: 11,
//                         color: '#1E2530',
//                         padding: '6px 10px',
//                       }}
//                       labelStyle={{ color: '#546E7A', fontWeight: 600, marginBottom: 4 }}
//                       itemStyle={{ padding: '1px 0' }}
//                     />

//                     {/* ================= 1. TAG A: LOWER LIMIT (RED) ================= */}
//                     {tagA && getEffectiveLimits(tagA).low != null && (
//                       <ReferenceLine
//                         yAxisId="left"
//                         y={getEffectiveLimits(tagA).low}
//                         stroke={LIMIT_LINE_COLOR}
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         ifOverflow="extendDomain"
//                         label={{
//                           value: `L-Lower Limit (${getEffectiveLimits(tagA).low})`,
//                           position: 'insideBottomLeft',
//                           fontSize: 9.5,
//                           fill: LIMIT_LINE_COLOR,
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* ================= 2. TAG A: UPPER LIMIT (RED) ================= */}
//                     {tagA && getEffectiveLimits(tagA).high != null && (
//                       <ReferenceLine
//                         yAxisId="left"
//                         y={getEffectiveLimits(tagA).high}
//                         stroke={LIMIT_LINE_COLOR}
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         ifOverflow="extendDomain"
//                         label={{
//                           value: `L-Upper Limit (${getEffectiveLimits(tagA).high})`,
//                           position: 'insideTopLeft',
//                           fontSize: 9.5,
//                           fill: LIMIT_LINE_COLOR,
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* ================= 3. TAG B: LOWER LIMIT (RED) ================= */}
//                     {tagB && getEffectiveLimits(tagB).low != null && (
//                       <ReferenceLine
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         y={getEffectiveLimits(tagB).low}
//                         stroke={LIMIT_LINE_COLOR}
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         ifOverflow="extendDomain"
//                         label={{
//                           value: `R-Lower Limit (${getEffectiveLimits(tagB).low})`,
//                           position: 'insideBottomRight',
//                           fontSize: 9.5,
//                           fill: LIMIT_LINE_COLOR,
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* ================= 4. TAG B: UPPER LIMIT (RED) ================= */}
//                     {tagB && getEffectiveLimits(tagB).high != null && (
//                       <ReferenceLine
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         y={getEffectiveLimits(tagB).high}
//                         stroke={LIMIT_LINE_COLOR}
//                         strokeDasharray="3 3"
//                         strokeWidth={1.2}
//                         ifOverflow="extendDomain"
//                         label={{
//                           value: `R-Upper Limit (${getEffectiveLimits(tagB).high})`,
//                           position: 'insideTopRight',
//                           fontSize: 9.5,
//                           fill: LIMIT_LINE_COLOR,
//                           fontWeight: 600,
//                           offset: 4,
//                         }}
//                       />
//                     )}

//                     {/* Primary Line Series (Tag A) */}
//                     <Line
//                       yAxisId="left"
//                       type="monotone"
//                       dataKey={tagA.tagId}
//                       name={tagA.parameter}
//                       stroke={SERIES_COLORS[0]}
//                       strokeWidth={1.8}
//                       dot={{ r: 2, fill: SERIES_COLORS[0], strokeWidth: 0 }}
//                       activeDot={{ r: 4, fill: SERIES_COLORS[0], stroke: '#FFFFFF', strokeWidth: 2 }}
//                       connectNulls
//                     />

//                     {/* Secondary Line Series (Tag B) */}
//                     {tagB && (
//                       <Line
//                         yAxisId={isDualAxis ? 'right' : 'left'}
//                         type="monotone"
//                         dataKey={tagB.tagId}
//                         name={tagB.parameter}
//                         stroke={SERIES_COLORS[1]}
//                         strokeWidth={1.8}
//                         dot={{ r: 2, fill: SERIES_COLORS[1], strokeWidth: 0 }}
//                         activeDot={{ r: 4, fill: SERIES_COLORS[1], stroke: '#FFFFFF', strokeWidth: 2 }}
//                         connectNulls
//                       />
//                     )}
//                   </LineChart>
//                 </ResponsiveContainer>

//                 {/* Footer Legend & Side-by-Side (Left / Right) Analytics Strips */}
//                 <div className={styles.chartFooter}>
//                   {/* Legend Items */}
//                   <div className={styles.legendGroup}>
//                     <span className={styles.legendItem}>
//                       <span className={styles.legendLineBlue}></span> {tagA.parameter}
//                     </span>
//                     {tagB && (
//                       <span className={styles.legendItem}>
//                         <span className={styles.legendLineOrange}></span> {tagB.parameter}
//                       </span>
//                     )}

//                     {/* Red Dashed Limit Labels in Legend */}
//                     {(getEffectiveLimits(tagA).low != null || getEffectiveLimits(tagA).high != null) && (
//                       <span className={styles.legendItem}>
//                         <span className={styles.legendLineRedDashed}></span>
//                         {tagA.parameter} Limits ({getEffectiveLimits(tagA).low ?? '–∞'} – {getEffectiveLimits(tagA).high ?? '+∞'})
//                       </span>
//                     )}

//                     {tagB && (getEffectiveLimits(tagB).low != null || getEffectiveLimits(tagB).high != null) && (
//                       <span className={styles.legendItem}>
//                         <span className={styles.legendLineRedDashed}></span>
//                         {tagB.parameter} Limits ({getEffectiveLimits(tagB).low ?? '–∞'} – {getEffectiveLimits(tagB).high ?? '+∞'})
//                       </span>
//                     )}
//                   </div>

//                   {/* Side-by-Side Dual Column Panels (Left = Tag A, Right = Tag B) */}
//                   {tagStatsList.length > 0 && (
//                     <div
//                       style={{
//                         display: 'grid',
//                         gridTemplateColumns: tagStatsList.length === 2 ? '1fr 1fr' : '1fr',
//                         gap: '12px',
//                         marginTop: '12px',
//                       }}
//                     >
//                       {tagStatsList.map((stat, idx) => (
//                         <div
//                           key={`${stat.tag.tagId}-${stat.tag.parameter}`}
//                           style={{
//                             display: 'flex',
//                             flexDirection: 'column',
//                             gap: '6px',
//                             padding: '9px 12px',
//                             backgroundColor: idx === 0 ? '#F3F7FC' : '#FEF8F1',
//                             borderLeft: `4px solid ${stat.color}`,
//                             borderRadius: '4px',
//                             fontSize: '11px',
//                             color: '#37474F',
//                             boxSizing: 'border-box',
//                           }}
//                         >
//                           <div
//                             style={{
//                               display: 'flex',
//                               alignItems: 'center',
//                               justifyContent: 'space-between',
//                               borderBottom: '1px solid rgba(0,0,0,0.06)',
//                               paddingBottom: '4px',
//                             }}
//                           >
//                             <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, color: stat.color }}>
//                               <span style={{ width: 8, height: 8, borderRadius: '50%', backgroundColor: stat.color }} />
//                               <span>{idx === 0 ? 'LEFT AXIS (TAG A)' : 'RIGHT AXIS (TAG B)'}: {stat.tag.parameter}</span>
//                             </div>
//                             <span style={{ fontSize: '10px', color: '#78909C', fontWeight: 600 }}>
//                               Spec: {getEffectiveLimits(stat.tag).low ?? '–∞'} – {getEffectiveLimits(stat.tag).high ?? '+∞'} {stat.tag.unit || ''}
//                             </span>
//                           </div>

//                           <div
//                             style={{
//                               display: 'flex',
//                               alignItems: 'center',
//                               justifyContent: 'space-between',
//                               flexWrap: 'wrap',
//                               gap: '8px',
//                               paddingTop: '2px',
//                             }}
//                           >
//                             <span>Readings: <b>{stat.count}</b></span>
//                             <span>Avg: <b>{stat.avg}</b></span>
//                             <span>Min: <b>{stat.min}</b></span>
//                             <span>Max: <b>{stat.max}</b></span>
//                             <span>
//                               OOS:{' '}
//                               <b style={{ color: stat.oosCount > 0 ? '#D32F2F' : '#37474F' }}>
//                                 {stat.oosCount} / {stat.count}
//                               </b>
//                             </span>
//                           </div>
//                         </div>
//                       ))}
//                     </div>
//                   )}
//                 </div>
//               </div>
//             ) : (
//               <div className={styles.emptyNotice}>
//                 Select a parameter card checkbox above to begin plotting.
//               </div>
//             )}
//           </div>

//           {/* Readings Summary Table */}
//           {selectedTags.length > 0 && readingsSummary.length > 0 && (
//             <div className={styles.summaryTableCard}>
//               <div className={styles.summaryTableTitle}>Readings summary</div>
//               <div className={styles.tableWrapper}>
//                 <table className={styles.summaryTable}>
//                   <thead>
//                     <tr>
//                       <th className={styles.thTag}>TAG</th>
//                       <th className={styles.thCol}>READINGS</th>
//                       <th className={styles.thCol}>AVG</th>
//                       <th className={styles.thCol}>MIN</th>
//                       <th className={styles.thCol}>MAX</th>
//                       <th className={styles.thCol}>OUT OF SPEC</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {readingsSummary.map((row) => (
//                       <tr key={`${row.tag.tagId}-${row.tag.parameter}`}>
//                         <td className={styles.tdTag}>
//                           <span
//                             className={styles.rowDot}
//                             style={{ backgroundColor: row.color }}
//                           />
//                           <span className={styles.rowTagName}>{row.tag.parameter}</span>
//                         </td>
//                         <td className={styles.tdVal}>{row.count}</td>
//                         <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.avg}</td>
//                         <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.min}</td>
//                         <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.max}</td>
//                         <td className={`${styles.tdVal} ${styles.tdOos}`}>
//                           {row.oosCount} / {row.count}
//                         </td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }

//last work code
import React, { useState, useMemo, useEffect } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import styles from './trendAnalysisDashboard.module.css';
import { doGetApiCall } from '../../../../utils/ClonosApi';

const PROCESS_TABS = [
  { key: 'PT', full: 'Pre-Treatment' },
  { key: 'ED', full: 'Electro-Deposition' },
  { key: 'OVEN', full: 'Oven' },
];

const SERIES_COLORS = ['#165BAA', '#D97706']; // Tag A: Primary Blue, Tag B: Warm Amber
const LIMIT_LINE_COLOR = '#D32F2F'; // Standard Red for all 4 target lines

// Helpers to format local datetime strings for datetime-local picker inputs (YYYY-MM-DDTHH:mm)
const formatToLocalDateTimeInput = (date) => {
  const d = new Date(date);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

export default function TrendAnalysisDashboard() {
  // 1. Backend Master & History States
  const [parameterMaster, setParameterMaster] = useState([]);
  const [historyRaw, setHistoryRaw] = useState([]);
  const [loadingMaster, setLoadingMaster] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // 2. Navigation & Selection States
  const [currentProcess, setCurrentProcess] = useState('PT');
  const [currentStageName, setCurrentStageName] = useState('');
  const [selectedTags, setSelectedTags] = useState([]); // Strictly max 2 tags
  const [customLimits, setCustomLimits] = useState({});

  // 3. Dynamic Date Initialization:
  // - Single Day: Current Date
  // - Range: Last 7 Days (Now - 7 days to Now)
  const now = useMemo(() => new Date(), []);
  const sevenDaysAgo = useMemo(() => new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), []);

  const [dateMode, setDateMode] = useState('range');
  const [singleDate, setSingleDate] = useState(() => formatToLocalDateTimeInput(now));
  const [fromDate, setFromDate] = useState(() => formatToLocalDateTimeInput(sevenDaysAgo));
  const [toDate, setToDate] = useState(() => formatToLocalDateTimeInput(now));

  // 4. Applied State (History API and Chart ONLY listen to this)
  const [appliedParams, setAppliedParams] = useState(() => ({
    mode: 'range',
    startDate: sevenDaysAgo.toISOString(),
    endDate: now.toISOString(),
    bucket: 'day',
    appliedLimitsVersion: 0,
  }));

  // Fetch Parameter Master on mount
  useEffect(() => {
    const getParameterMaster = async () => {
      try {
        setLoadingMaster(true);
        const res = await doGetApiCall({ url: '/tags/dashboard/trend/parameter-master' });
        if (res?.data?.result && Array.isArray(res.data.result)) {
          setParameterMaster(res.data.result);
        }
      } catch (err) {
        console.error('Failed to fetch parameter master:', err);
      } finally {
        setLoadingMaster(false);
      }
    };
    getParameterMaster();
  }, []);

  // Dynamically group parameters by process and stage
  const groupedStages = useMemo(() => {
    const processItems = parameterMaster.filter(
      (item) => (item.process || '').toUpperCase() === currentProcess
    );

    const stagesMap = new Map();
    processItems.forEach((item) => {
      const stageName = (item.stage || 'General').trim();
      if (!stagesMap.has(stageName)) {
        stagesMap.set(stageName, []);
      }
      stagesMap.get(stageName).push(item);
    });

    return Array.from(stagesMap.entries()).map(([name, tags]) => ({
      name,
      tags,
    }));
  }, [parameterMaster, currentProcess]);

  // Synchronize current stage when switching process tabs
  useEffect(() => {
    if (groupedStages.length > 0) {
      const exists = groupedStages.some((st) => st.name === currentStageName);
      if (!exists) {
        setCurrentStageName(groupedStages[0].name);
      }
    } else {
      setCurrentStageName('');
    }
  }, [groupedStages, currentProcess, currentStageName]);

  const activeStage = useMemo(() => {
    return (
      groupedStages.find((st) => st.name === currentStageName) ||
      groupedStages[0] || { name: '', tags: [] }
    );
  }, [groupedStages, currentStageName]);

  // Handler called on "Apply" button click
  const handleApplyDate = () => {
    let startIso, endIso;
    if (dateMode === 'day') {
      if (!singleDate) return;
      const base = new Date(singleDate);
      const start = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 0, 0, 0);
      const end = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 23, 59, 59, 999);
      startIso = start.toISOString();
      endIso = end.toISOString();
    } else {
      if (!fromDate || !toDate) return;
      startIso = new Date(fromDate).toISOString();
      endIso = new Date(toDate).toISOString();
    }

    setAppliedParams((prev) => ({
      mode: dateMode,
      startDate: startIso,
      endDate: endIso,
      bucket: dateMode === 'day' ? 'hour' : 'day',
      appliedLimitsVersion: prev.appliedLimitsVersion + 1,
    }));
  };

  // Safe limits retrieval (draft strings parsed to numbers without mutating inputs)
  const getEffectiveLimits = (tag) => {
    if (!tag) return { low: null, high: null };
    const override = customLimits[tag.tagId];

    const parsedLow =
      override?.low !== undefined && override?.low !== ''
        ? parseFloat(override.low)
        : tag.min;
    const parsedHigh =
      override?.high !== undefined && override?.high !== ''
        ? parseFloat(override.high)
        : tag.max;

    return {
      low: isNaN(parsedLow) ? null : parsedLow,
      high: isNaN(parsedHigh) ? null : parsedHigh,
    };
  };

  const isOOS = (val, tag) => {
    const { low, high } = getEffectiveLimits(tag);
    if (low != null && val < low) return true;
    if (high != null && val > high) return true;
    return false;
  };

  // Card Selection Toggle (Atomic FIFO strictly capped at 2 cards)
  const handleTagToggle = (stageName, tag) => {
    setSelectedTags((prev) => {
      const isSameTag = (item) =>
        item.tag.tagId === tag.tagId && item.tag.parameter === tag.parameter;

      const exists = prev.some(isSameTag);

      if (exists) {
        return prev.filter((item) => !isSameTag(item));
      }

      const newItem = { process: currentProcess, stage: stageName, tag };

      if (prev.length >= 2) {
        return [prev[prev.length - 1], newItem];
      }

      return [...prev, newItem];
    });
  };

  const getTrackGeometry = (val, tag) => {
    const { low, high } = getEffectiveLimits(tag);
    if (low == null && high == null) return { pct: 50 };
    const minVal = low != null ? low : high * 0.7;
    const maxVal = high != null ? high : low * 1.3;
    const span = maxVal - minVal || 1;
    const buffer = span * 0.35;
    const domainLow = minVal - buffer;
    const domainHigh = maxVal + buffer;
    const pct = Math.max(0, Math.min(100, ((val - domainLow) / (domainHigh - domainLow)) * 100));
    return { pct };
  };

  // Handle manual input field typing smoothly
  const handleLimitChange = (tagId, field, value) => {
    setCustomLimits((prev) => {
      const existing = prev[tagId] || { low: '', high: '' };
      return {
        ...prev,
        [tagId]: {
          ...existing,
          [field]: value,
        },
      };
    });
  };

  // 5. Fetch History API (Triggered on tag selection or Apply button click)
  useEffect(() => {
    const fetchHistory = async () => {
      if (selectedTags.length === 0) {
        setHistoryRaw([]);
        return;
      }

      const tagIds = selectedTags.map((s) => s.tag.tagId).filter(Boolean).join(',');
      if (!tagIds) return;

      try {
        setLoadingHistory(true);

        const activeOverrides = {};
        selectedTags.forEach((s) => {
          const custom = customLimits[s.tag.tagId];
          const lowNum = custom?.low !== '' && custom?.low !== undefined ? parseFloat(custom.low) : null;
          const highNum = custom?.high !== '' && custom?.high !== undefined ? parseFloat(custom.high) : null;

          if (lowNum != null || highNum != null) {
            activeOverrides[s.tag.tagId] = {
              min: !isNaN(lowNum) ? lowNum : undefined,
              max: !isNaN(highNum) ? highNum : undefined,
            };
          }
        });

        let url = `/tags/dashboard/trend/history?tagIds=${tagIds}&startDate=${appliedParams.startDate}&endDate=${appliedParams.endDate}&bucket=${appliedParams.bucket}`;
        if (Object.keys(activeOverrides).length > 0) {
          url += `&temporaryRanges=${encodeURIComponent(JSON.stringify(activeOverrides))}`;
        }

        const res = await doGetApiCall({ url });
        if (res?.data?.result && Array.isArray(res.data.result)) {
          setHistoryRaw(res.data.result);
        } else {
          setHistoryRaw([]);
        }
      } catch (err) {
        console.error('History fetch failed:', err);
        setHistoryRaw([]);
      } finally {
        setLoadingHistory(false);
      }
    };

    fetchHistory();
  }, [selectedTags, appliedParams]);

  // 6. Pivot History Records for Recharts
  const chartData = useMemo(() => {
    if (!historyRaw || historyRaw.length === 0) return [];

    const timeMap = new Map();

    historyRaw.forEach((item) => {
      const rawTime = item.bucketStart || item.timestamp;
      if (!rawTime) return;

      if (!timeMap.has(rawTime)) {
        const d = new Date(rawTime);
        const label =
          appliedParams.bucket === 'hour'
            ? d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
            : `${String(d.getDate()).padStart(2, '0')} ${d.toLocaleString('en-GB', { month: 'short' })}`;

        timeMap.set(rawTime, {
          rawTime,
          timestamp: label,
        });
      }

      const row = timeMap.get(rawTime);
      const val = item.average != null ? item.average : item.value;
      if (val != null) {
        row[item.tagId] = Number(val);
      }
    });

    return Array.from(timeMap.values()).sort(
      (a, b) => new Date(a.rawTime) - new Date(b.rawTime)
    );
  }, [historyRaw, appliedParams.bucket]);

  const tagA = selectedTags[0]?.tag;
  const tagB = selectedTags[1]?.tag;

  const normalizeUnit = (u) => (u || '').trim().replace(/[º˚]/g, '°').toLowerCase();
  const isDualAxis = Boolean(
    tagA && tagB && normalizeUnit(tagA.unit) !== normalizeUnit(tagB.unit)
  );

  // Dynamic Y-axis domains ensuring all 4 target limits and data remain fully visible
  const calculateDomain = (tagsForAxis) => {
    const activeTags = tagsForAxis.filter(Boolean);
    if (activeTags.length === 0) return [0, 100];

    let minVal = Infinity;
    let maxVal = -Infinity;

    activeTags.forEach((tag) => {
      const { low, high } = getEffectiveLimits(tag);

      // Account for target limit lines
      if (low != null && !isNaN(Number(low))) {
        minVal = Math.min(minVal, Number(low));
        maxVal = Math.max(maxVal, Number(low));
      }
      if (high != null && !isNaN(Number(high))) {
        minVal = Math.min(minVal, Number(high));
        maxVal = Math.max(maxVal, Number(high));
      }

      // Account for chart points
      chartData.forEach((row) => {
        const val = row[tag.tagId];
        if (val !== undefined && val !== null && !isNaN(val)) {
          minVal = Math.min(minVal, Number(val));
          maxVal = Math.max(maxVal, Number(val));
        }
      });
    });

    if (minVal === Infinity || maxVal === -Infinity) {
      return [0, 100];
    }

    if (minVal === maxVal) {
      minVal = minVal > 0 ? minVal * 0.8 : minVal - 1;
      maxVal = maxVal > 0 ? maxVal * 1.2 : maxVal + 1;
    }

    const span = maxVal - minVal;
    const padding = span * 0.15; // 15% buffer so reference lines never hit borders

    return [
      +(minVal - padding).toFixed(2),
      +(maxVal + padding).toFixed(2),
    ];
  };

  const domainLeft = useMemo(
    () => (isDualAxis ? calculateDomain([tagA]) : calculateDomain([tagA, tagB])),
    [tagA, tagB, chartData, customLimits, isDualAxis]
  );

  const domainRight = useMemo(
    () => (isDualAxis ? calculateDomain([tagB]) : domainLeft),
    [tagB, chartData, customLimits, isDualAxis, domainLeft]
  );

  // Separate Statistics for BOTH Tag A and Tag B
  const tagStatsList = useMemo(() => {
    if (selectedTags.length === 0 || chartData.length === 0) return [];

    return selectedTags.map((s, idx) => {
      const tag = s.tag;
      const values = chartData
        .map((d) => d[tag.tagId])
        .filter((v) => v !== undefined && v !== null && !isNaN(v));

      if (!values.length) {
        return {
          tag,
          color: SERIES_COLORS[idx],
          count: 0,
          avg: '—',
          min: '—',
          max: '—',
          oosCount: 0,
        };
      }

      const count = values.length;
      const sum = values.reduce((a, b) => a + b, 0);
      const avg = (sum / count).toFixed(3);
      const min = Math.min(...values).toFixed(3);
      const max = Math.max(...values).toFixed(3);
      const oosCount = values.filter((v) => isOOS(v, tag)).length;

      return {
        tag,
        color: SERIES_COLORS[idx],
        count,
        avg: `${avg} ${tag.unit || ''}`.trim(),
        min: `${min} ${tag.unit || ''}`.trim(),
        max: `${max} ${tag.unit || ''}`.trim(),
        oosCount,
      };
    });
  }, [chartData, selectedTags, customLimits]);

  // Readings Summary Table
  const readingsSummary = useMemo(() => {
    if (selectedTags.length === 0) return [];

    return selectedTags.map((s, idx) => {
      const tag = s.tag;
      const values = chartData
        .map((d) => d[tag.tagId])
        .filter((v) => v !== undefined && !isNaN(v));

      if (!values.length) {
        return {
          tag,
          color: SERIES_COLORS[idx],
          count: 0,
          avg: '—',
          min: '—',
          max: '—',
          oosCount: 0,
        };
      }

      const count = values.length;
      const sum = values.reduce((a, b) => a + b, 0);
      const avg = (sum / count).toFixed(2);
      const min = Math.min(...values).toFixed(2);
      const max = Math.max(...values).toFixed(2);
      const oosCount = values.filter((v) => isOOS(v, tag)).length;

      return {
        tag,
        color: SERIES_COLORS[idx],
        count,
        avg: `${avg} ${tag.unit || ''}`.trim(),
        min,
        max,
        oosCount,
      };
    });
  }, [chartData, selectedTags, customLimits]);

  return (
    <div className={styles.pageWrapper}>
      <div className={styles.mainCard}>
        {/* Header Strip */}
        <div className={styles.cardTopHeader}>
          <div className={styles.titleGroup}>
            <div className={styles.mainTitle}>Trend Analysis</div>
            <div className={styles.subMeta}> 
              E-log · {parameterMaster.length > 0 ? `${parameterMaster.length} Parameters Configured` : 'Connecting...'}
            </div>
          </div>
          <div className={styles.liveBadge}>
            <span className={styles.liveDot}></span> Live
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className={styles.cardBody}>
          {/* Primary Process Tabs */}
          <div className={styles.toggleRow}>
            <div className={styles.pillContainer}>
              {PROCESS_TABS.map((tab) => (
                <button
                  key={tab.key}
                  type="button"
                  className={`${styles.pillButton} ${currentProcess === tab.key ? styles.pillActive : ''}`}
                  onClick={() => {
                    setCurrentProcess(tab.key);
                    setCurrentStageName('');
                  }}
                >
                  {tab.full}
                </button>
              ))}
            </div>
          </div>

          {/* Sub-Pills (Stages) */}
          {groupedStages.length > 0 && (
            <div className={styles.subPillRow}>
              {groupedStages.map((st) => (
                <button
                  key={st.name}
                  type="button"
                  className={`${styles.stagePill} ${activeStage.name === st.name ? styles.stagePillActive : ''}`}
                  onClick={() => setCurrentStageName(st.name)}
                >
                  {st.name}
                </button>
              ))}
            </div>
          )}

          {/* Section Header */}
          <div className={styles.sectionHeaderRow}>
            <div className={styles.sectionTitle}>
              {activeStage.name ? `${activeStage.name.toUpperCase()} — LIVE DATA` : 'NO STAGE SELECTED'}
            </div>
          </div>

          {/* KPI Cards Grid */}
          <div className={styles.cardGrid}>
            {loadingMaster ? (
              <div className={styles.emptyNotice}>Loading parameters...</div>
            ) : activeStage.tags.length > 0 ? (
              activeStage.tags.map((tag, idx) => {
                const { low, high } = getEffectiveLimits(tag);
                const isSelected = selectedTags.some(
                  (s) => s.tag.tagId === tag.tagId && s.tag.parameter === tag.parameter
                );

                const isManualTag = tag.min == null && tag.max == null;
                const val = tag.latestValue != null ? Number(tag.latestValue) : null;
                const oos = !isManualTag && val != null && isOOS(val, tag);
                const geo = getTrackGeometry(val, tag);

                return (
                  <div
                    key={`${tag.id || idx}-${tag.tagId}-${activeStage.name}`}
                    className={`
                      ${styles.kpiCard} 
                      ${oos ? styles.kpiCardBreach : styles.kpiCardNormal}
                      ${isSelected ? styles.kpiCardSelected : ''}
                    `}
                    onClick={() => handleTagToggle(activeStage.name, tag)}
                  >
                    <div className={styles.cardHeader}>
                      <span className={styles.cardTagTitle} title={tag.parameter}>
                        {tag.parameter}
                      </span>
                      <div className={`${styles.cardCheckbox} ${isSelected ? styles.checkboxChecked : ''}`}>
                        {isSelected ? '✓' : ''}
                      </div>
                    </div>

                    <div className={`${styles.cardValue} ${oos ? styles.valueBreach : styles.valueNormal}`}>
                      {val != null ? val.toFixed(2) : '—'}
                    </div>

                    <div className={styles.cardMeta}>
                      Updated at: {tag.lastUpdated ? new Date(tag.lastUpdated).toLocaleString('en-GB') : 'Waiting for sync...'}
                    </div>
                    <div className={styles.cardMeta}>
                      Spec: {tag.range || `${low ?? '–∞'} – ${high ?? '+∞'}`} {tag.unit || ''}
                    </div>

                    {isManualTag ? (
                      <div className={styles.manualLimitSection} onClick={(e) => e.stopPropagation()}>
                        <div className={styles.manualInputsRow}>
                          <input
                            type="number"
                            step="any"
                            placeholder="Low"
                            className={styles.limitInput}
                            value={customLimits[tag.tagId]?.low ?? ''}
                            onChange={(e) => handleLimitChange(tag.tagId, 'low', e.target.value)}
                          />
                          <input
                            type="number"
                            step="any"
                            placeholder="High"
                            className={styles.limitInput}
                            value={customLimits[tag.tagId]?.high ?? ''}
                            onChange={(e) => handleLimitChange(tag.tagId, 'high', e.target.value)}
                          />
                        </div>
                        <div className={styles.pendingHint}>enter custom limits</div>
                      </div>
                    ) : (
                      <>
                        <div className={styles.rangeTrack}>
                          <div
                            className={`${styles.rangeFill} ${oos ? styles.fillBreach : styles.fillNormal}`}
                            style={{ width: `${geo.pct}%` }}
                          />
                          <div
                            className={`${styles.rangeMarker} ${oos ? styles.markerBreach : styles.markerNormal}`}
                            style={{ left: `${geo.pct}%` }}
                          />
                        </div>
                        <div className={styles.rangeLabels}>
                          <span>{low ?? ''}</span>
                          <span>{high ?? ''}</span>
                        </div>
                      </>
                    )}
                  </div>
                );
              })
            ) : (
              <div className={styles.emptyNotice}>No parameters found for this stage.</div>
            )}
          </div>

          {/* Active Comparison Bar */}
          {selectedTags.length > 0 && (
            <div className={styles.compareBar}>
              <span className={styles.compareLabel}>Active Comparison ({selectedTags.length}/2):</span>
              {selectedTags.map((s, idx) => (
                <span key={`${s.tag.tagId}-${s.tag.parameter}`} className={styles.chip}>
                  <span className={styles.chipDot} style={{ background: SERIES_COLORS[idx] }}></span>
                  {s.tag.parameter} ({s.tag.unit || 'val'})
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTagToggle(s.stage, s.tag);
                    }}
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}

          {/* Chart Section */}
          <div className={styles.chartSection}>
            <div className={styles.chartHeaderRow}>
              <div>
                <div className={styles.chartTitle}>
                  {selectedTags.length > 0
                    ? `${selectedTags[0].stage} — ${selectedTags.map((s) => s.tag.parameter).join(' vs ')}`
                    : 'Process Trend Overview'}
                </div>
                {tagA && (
                  <div className={styles.chartSpecSub}>
                    {isDualAxis
                      ? `Comparing different units: Left (${tagA.unit}) vs Right (${tagB?.unit})`
                      : `Spec range: ${getEffectiveLimits(tagA).low ?? '–∞'} – ${getEffectiveLimits(tagA).high ?? '+∞'} ${tagA.unit}`}
                  </div>
                )}
              </div>

              {/* Date Controls */}
              <div className={styles.dateControlGroup}>
                <div className={styles.modeField}>
                  <label className={styles.dateLabel}>MODE</label>
                  <div className={styles.dateModeContainer}>
                    <button
                      type="button"
                      className={`${styles.dateModeBtn} ${dateMode === 'day' ? styles.dateModeActive : ''}`}
                      onClick={() => setDateMode('day')}
                    >
                      Single Day
                    </button>
                    <button
                      type="button"
                      className={`${styles.dateModeBtn} ${dateMode === 'range' ? styles.dateModeActive : ''}`}
                      onClick={() => setDateMode('range')}
                    >
                      Range
                    </button>
                  </div>
                </div>

                <div className={styles.dateField}>
                  <label className={styles.dateLabel}>{dateMode === 'day' ? 'DATE' : 'FROM'}</label>
                  <input
                    type="datetime-local"
                    value={dateMode === 'day' ? singleDate : fromDate}
                    onChange={(e) => {
                      if (dateMode === 'day') setSingleDate(e.target.value);
                      else setFromDate(e.target.value);
                    }}
                  />
                </div>

                <div
                  className={`${styles.dateField} ${styles.collapsibleField} ${
                    dateMode === 'range' ? styles.fieldExpanded : styles.fieldCollapsed
                  }`}
                >
                  <label className={styles.dateLabel}>TO</label>
                  <input
                    type="datetime-local"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                    tabIndex={dateMode === 'range' ? 0 : -1}
                  />
                </div>

                <button
                  type="button"
                  className={styles.applyBtn}
                  onClick={handleApplyDate}
                >
                  Apply
                </button>
              </div>
            </div>

            {/* Recharts Canvas */}
            {selectedTags.length > 0 ? (
              <div className={styles.chartWrapper}>
                {loadingHistory && <div className={styles.chartLoadingOverlay}>Updating trend...</div>}
                <ResponsiveContainer width="100%" height={230}>
                  <LineChart data={chartData} margin={{ top: 14, right: 40, left: 10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ECEFF1" />
                    <XAxis dataKey="timestamp" stroke="#90A4AE" tick={{ fontSize: 9.5 }} />

                    {/* Tag A: Left Y-Axis */}
                    <YAxis
                      yAxisId="left"
                      orientation="left"
                      stroke={SERIES_COLORS[0]}
                      unit={tagA?.unit ? ` ${tagA.unit}` : ''}
                      domain={domainLeft}
                      tick={{ fontSize: 9.5, fill: '#546E7A' }}
                      allowDataOverflow={false}
                    />

                    {/* Tag B: Right Y-Axis */}
                    {tagB && (
                      <YAxis
                        yAxisId={isDualAxis ? 'right' : 'left'}
                        orientation="right"
                        stroke={SERIES_COLORS[1]}
                        unit={tagB?.unit ? ` ${tagB.unit}` : ''}
                        domain={domainRight}
                        tick={{ fontSize: 9.5, fill: '#546E7A' }}
                        hide={!isDualAxis}
                        allowDataOverflow={false}
                      />
                    )}

                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#FFFFFF',
                        borderColor: '#DCE3EC',
                        borderRadius: 6,
                        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
                        fontSize: 11,
                        color: '#1E2530',
                        padding: '6px 10px',
                      }}
                      labelStyle={{ color: '#546E7A', fontWeight: 600, marginBottom: 4 }}
                      itemStyle={{ padding: '1px 0' }}
                    />

                    {/* ================= 1. TAG A: LOWER LIMIT (RED) ================= */}
                    {tagA && getEffectiveLimits(tagA).low != null && (
                      <ReferenceLine
                        yAxisId="left"
                        y={getEffectiveLimits(tagA).low}
                        stroke={LIMIT_LINE_COLOR}
                        strokeDasharray="3 3"
                        strokeWidth={1.2}
                        ifOverflow="extendDomain"
                        label={{
                          value: `L-Lower Limit (${getEffectiveLimits(tagA).low})`,
                          position: 'insideBottomLeft',
                          fontSize: 9.5,
                          fill: LIMIT_LINE_COLOR,
                          fontWeight: 600,
                          offset: 4,
                        }}
                      />
                    )}

                    {/* ================= 2. TAG A: UPPER LIMIT (RED) ================= */}
                    {tagA && getEffectiveLimits(tagA).high != null && (
                      <ReferenceLine
                        yAxisId="left"
                        y={getEffectiveLimits(tagA).high}
                        stroke={LIMIT_LINE_COLOR}
                        strokeDasharray="3 3"
                        strokeWidth={1.2}
                        ifOverflow="extendDomain"
                        label={{
                          value: `L-Upper Limit (${getEffectiveLimits(tagA).high})`,
                          position: 'insideTopLeft',
                          fontSize: 9.5,
                          fill: LIMIT_LINE_COLOR,
                          fontWeight: 600,
                          offset: 4,
                        }}
                      />
                    )}

                    {/* ================= 3. TAG B: LOWER LIMIT (RED) ================= */}
                    {tagB && getEffectiveLimits(tagB).low != null && (
                      <ReferenceLine
                        yAxisId={isDualAxis ? 'right' : 'left'}
                        y={getEffectiveLimits(tagB).low}
                        stroke={LIMIT_LINE_COLOR}
                        strokeDasharray="3 3"
                        strokeWidth={1.2}
                        ifOverflow="extendDomain"
                        label={{
                          value: `R-Lower Limit (${getEffectiveLimits(tagB).low})`,
                          position: 'insideBottomRight',
                          fontSize: 9.5,
                          fill: LIMIT_LINE_COLOR,
                          fontWeight: 600,
                          offset: 4,
                        }}
                      />
                    )}

                    {/* ================= 4. TAG B: UPPER LIMIT (RED) ================= */}
                    {tagB && getEffectiveLimits(tagB).high != null && (
                      <ReferenceLine
                        yAxisId={isDualAxis ? 'right' : 'left'}
                        y={getEffectiveLimits(tagB).high}
                        stroke={LIMIT_LINE_COLOR}
                        strokeDasharray="3 3"
                        strokeWidth={1.2}
                        ifOverflow="extendDomain"
                        label={{
                          value: `R-Upper Limit (${getEffectiveLimits(tagB).high})`,
                          position: 'insideTopRight',
                          fontSize: 9.5,
                          fill: LIMIT_LINE_COLOR,
                          fontWeight: 600,
                          offset: 4,
                        }}
                      />
                    )}

                    {/* Primary Line Series (Tag A) */}
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey={tagA.tagId}
                      name={tagA.parameter}
                      stroke={SERIES_COLORS[0]}
                      strokeWidth={1.8}
                      dot={{ r: 2, fill: SERIES_COLORS[0], strokeWidth: 0 }}
                      activeDot={{ r: 4, fill: SERIES_COLORS[0], stroke: '#FFFFFF', strokeWidth: 2 }}
                      connectNulls
                    />

                    {/* Secondary Line Series (Tag B) */}
                    {tagB && (
                      <Line
                        yAxisId={isDualAxis ? 'right' : 'left'}
                        type="monotone"
                        dataKey={tagB.tagId}
                        name={tagB.parameter}
                        stroke={SERIES_COLORS[1]}
                        strokeWidth={1.8}
                        dot={{ r: 2, fill: SERIES_COLORS[1], strokeWidth: 0 }}
                        activeDot={{ r: 4, fill: SERIES_COLORS[1], stroke: '#FFFFFF', strokeWidth: 2 }}
                        connectNulls
                      />
                    )}
                  </LineChart>
                </ResponsiveContainer>

                {/* Footer Legend & Side-by-Side (Left / Right) Analytics Strips */}
                <div className={styles.chartFooter}>
                  {/* Legend Items */}
                  <div className={styles.legendGroup}>
                    <span className={styles.legendItem}>
                      <span className={styles.legendLineBlue}></span> {tagA.parameter}
                    </span>
                    {tagB && (
                      <span className={styles.legendItem}>
                        <span className={styles.legendLineOrange}></span> {tagB.parameter}
                      </span>
                    )}

                    {/* Red Dashed Limit Labels in Legend */}
                    {(getEffectiveLimits(tagA).low != null || getEffectiveLimits(tagA).high != null) && (
                      <span className={styles.legendItem}>
                        <span className={styles.legendLineRedDashed}></span>
                        {tagA.parameter} Limits ({getEffectiveLimits(tagA).low ?? '–∞'} – {getEffectiveLimits(tagA).high ?? '+∞'})
                      </span>
                    )}

                    {tagB && (getEffectiveLimits(tagB).low != null || getEffectiveLimits(tagB).high != null) && (
                      <span className={styles.legendItem}>
                        <span className={styles.legendLineRedDashed}></span>
                        {tagB.parameter} Limits ({getEffectiveLimits(tagB).low ?? '–∞'} – {getEffectiveLimits(tagB).high ?? '+∞'})
                      </span>
                    )}
                  </div>

                  {/* Side-by-Side Dual Column Panels (Left = Tag A, Right = Tag B) */}
                  {tagStatsList.length > 0 && (
                    <div
                      style={{
                        display: 'grid',
                        gridTemplateColumns: tagStatsList.length === 2 ? '1fr 1fr' : '1fr',
                        gap: '12px',
                        marginTop: '12px',
                      }}
                    >
                      {tagStatsList.map((stat, idx) => (
                        <div
                          key={`${stat.tag.tagId}-${stat.tag.parameter}`}
                          style={{
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '6px',
                            padding: '9px 12px',
                            backgroundColor: idx === 0 ? '#F3F7FC' : '#FEF8F1',
                            borderLeft: `4px solid ${stat.color}`,
                            borderRadius: '4px',
                            fontSize: '11px',
                            color: '#37474F',
                            boxSizing: 'border-box',
                          }}
                        >
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              borderBottom: '1px solid rgba(0,0,0,0.06)',
                              paddingBottom: '4px',
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, color: stat.color }}>
                              <span style={{ width: 8, height: 8, borderRadius: '50%', backgroundColor: stat.color }} />
                              <span>{idx === 0 ? 'LEFT AXIS (TAG A)' : 'RIGHT AXIS (TAG B)'}: {stat.tag.parameter}</span>
                            </div>
                            <span style={{ fontSize: '10px', color: '#78909C', fontWeight: 600 }}>
                              Spec: {getEffectiveLimits(stat.tag).low ?? '–∞'} – {getEffectiveLimits(stat.tag).high ?? '+∞'} {stat.tag.unit || ''}
                            </span>
                          </div>

                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              flexWrap: 'wrap',
                              gap: '8px',
                              paddingTop: '2px',
                            }}
                          >
                            <span>Readings: <b>{stat.count}</b></span>
                            <span>Avg: <b>{stat.avg}</b></span>
                            <span>Min: <b>{stat.min}</b></span>
                            <span>Max: <b>{stat.max}</b></span>
                            <span>
                              OOS:{' '}
                              <b style={{ color: stat.oosCount > 0 ? '#D32F2F' : '#37474F' }}>
                                {stat.oosCount} / {stat.count}
                              </b>
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className={styles.emptyNotice}>
                Select a parameter card checkbox above to begin plotting.
              </div>
            )}
          </div>

          {/* Readings Summary Table */}
          {selectedTags.length > 0 && readingsSummary.length > 0 && (
            <div className={styles.summaryTableCard}>
              <div className={styles.summaryTableTitle}>Readings summary</div>
              <div className={styles.tableWrapper}>
                <table className={styles.summaryTable}>
                  <thead>
                    <tr>
                      <th className={styles.thTag}>TAG</th>
                      <th className={styles.thCol}>READINGS</th>
                      <th className={styles.thCol}>AVG</th>
                      <th className={styles.thCol}>MIN</th>
                      <th className={styles.thCol}>MAX</th>
                      <th className={styles.thCol}>OUT OF SPEC</th>
                    </tr>
                  </thead>
                  <tbody>
                    {readingsSummary.map((row) => (
                      <tr key={`${row.tag.tagId}-${row.tag.parameter}`}>
                        <td className={styles.tdTag}>
                          <span
                            className={styles.rowDot}
                            style={{ backgroundColor: row.color }}
                          />
                          <span className={styles.rowTagName}>{row.tag.parameter}</span>
                        </td>
                        <td className={styles.tdVal}>{row.count}</td>
                        <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.avg}</td>
                        <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.min}</td>
                        <td className={`${styles.tdVal} ${styles.tdMono}`}>{row.max}</td>
                        <td className={`${styles.tdVal} ${styles.tdOos}`}>
                          {row.oosCount} / {row.count}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}