import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../process-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { setSerialNumber } from "../../../../utils/clonosCommon";
import { doGetApiCall } from "../../../../utils/ClonosApi";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function ProcessDowntime() {

   const [processDowntimeData,setProcessDowntimeData]=useState([])
    const [totalCount,setTotalCount]=useState({})
        
    const [pagination, setPagination] = useState({page:1,limit:5})
        
    

// Function to get condition based on downtime
function getCondition(downtime) {
  if (downtime === 0) return "Excellent";
  if (downtime > 0 && downtime < 10) return "Good";
  return "Poor";
}



  function getprocessDowntimeData(pagination) {
    doGetApiCall({
      url: `processDashboards/activehours`,
      params: pagination
    })
    .then((res) => {
      const rawData = res?.data?.result?.downtime?.data || [];
      
  
      const processdownData = rawData.map((item, index) => ({
        id: index + 1, 
        ...item,
        condition: getCondition(item.downtime),
      }));
  
      setProcessDowntimeData(processdownData);
      setTotalCount(res?.data?.result?.downtime?.totalDataCount || 0);
    });
  }
  

  
      // Load initial data
    useEffect(() => {
      getprocessDowntimeData(pagination);
    }, [pagination]);
  

  // ✅ Define MUI columns
  const downtimeColumns = [
    { field: "processName", headerName: "Process Name", flex: 1 },
    {
      field: "logName",
      headerName: "Log Name",
      flex: 1,
      headerAlign: "center",
      align: "center",
    },
    {
      field: "downtime",
      headerName: "Down Time",
      flex: 1,
      headerAlign: "center",
      align: "center",

    },

    {
      field: "condition",
      headerName: "CONDITION",
      flex: 1,
      headerAlign: "center",
      align: "center",
      headerClassName: "datadrid_common_header",
      cellClassName: "datagrid_common_cell",
      renderCell: (params) => (
        <p
          style={{
            ...statusStyleStaticData[params?.row?.condition],
            padding: "0.25rem 0.5rem",
            borderRadius: "0.25rem",
            cursor: "default",
          }}
        >
          {params?.row?.condition
            ? statusStaticData[params?.row?.condition]
            : "-"}
        </p>
      ),
    },
  ];

  return (
    <>
                    <Grid item xs={12} sm={6} md={4}>
                      <Card className={`${Styles.card} ${Styles.cardFixed}`}>
                        <CardContent className={Styles.cardContent}>
                      <div className={Styles.cardHeader}>
    <Typography className={Styles.assetDashboardTitle}>Process Downtime (Non-Asset)</Typography>
    <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
    Idle time due to Process
    </Typography>
    <hr className={Styles.divider} />
</div>
 
    <ClonosDataGrid
      rows={setSerialNumber(processDowntimeData,pagination.page,pagination.limit)}
      columns={downtimeColumns}
      uniqueIdField="id"
      onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
      isLoading={false}
      totalCount={totalCount}
      pageLimit={5}  
      checkboxSelection={false}
      // paginationMode="client"
    />
    </CardContent>
    </Card>
    </Grid>
       </>
  );
}

export default ProcessDowntime