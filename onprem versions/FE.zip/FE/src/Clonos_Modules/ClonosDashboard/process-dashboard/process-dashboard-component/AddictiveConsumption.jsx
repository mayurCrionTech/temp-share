
// import React, { useEffect, useState,useMemo } from "react";
// import Styles from  '../process-dashboard.module.css';
// // import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// // import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// // import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// // import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// // import ClonosGridNav from "../../../utils/ClonosGridNav"
// import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
// import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";
// import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { setSerialNumber } from "../../../../utils/clonosCommon";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// // import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// // import { Box } from '@mui/material'

// // import {
// //   DataGrid,
// //   gridPageCountSelector,
// //   useGridApiContext,
// //   useGridSelector,
// // } from '@mui/x-data-grid';
// // import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// // import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// // import { doGetApiCall } from "../../../utils/ClonosApi";
// // import AppUrl from "../../../utils/AppUrl";

// function AddictiveConsumption() {

//     const [addictiveConsumptionData,setAddictiveConsumptionData]=useState([])
//     const [totalCount,setTotalCount]=useState({})
    
//     const [pagination, setPagination] = useState({page:1,limit:5})
      
  
// function getAddictiveConsumptionData(pagination) {
//   doGetApiCall({
//     url: `processDashboards/activehours`,
//     params: pagination
//   })
//   .then((res) => {
//     const rawData = res?.data?.result?.additiveConsumption?.data || [];
//     console.log(rawData, "rawDatafromres");

//     const addictivesData = rawData.map((item, index) => ({
//       id: index + 1, 
//       ...item,
//       condition: getCondition(item.totalAdditiveKG, item.perUnit)  // or your expected value
//     }));

//     setAddictiveConsumptionData(addictivesData);
//     setTotalCount(res?.data?.result?.additiveConsumption?.totalDataCount || 0);
//   });
// }

// console.log(addictiveConsumptionData,"addictiveConsumptionData")

//     // Load initial data
//   useEffect(() => {
//     getAddictiveConsumptionData(pagination);
//   }, [pagination]);


// const getCondition = (actual, expected) => {
//   // case 1: both zero → no condition
//   if (expected === 0 && actual === 0) return "-";

//   // case 2: expected is zero, actual exists → overutilisation (poor)
//   if (expected === 0 && actual > 0) return "POOR";

//   // now safe to calculate percentage:
//   const percentage = ((actual - expected) / expected) * 100;

//   if (percentage >= -5 && percentage <= 5) return "EXCELLENT";
//   if (percentage < -5 && percentage >= -20) return "GOOD";
//   if (percentage > 20) return "POOR";

//   return "-";
// };





//   // ✅ Define MUI columns
//   const addictiveConsumptionColumns = [
//     { field: "processName", headerName: "Process Name", flex: 1 },
//     {
//       field: "additivesAdded",
//       headerName: "Additive’s Added",
//       flex: 2,
//       headerAlign: "center",
//       align: "center",
//     },
   
//     {
//       field: "condition",
//       headerName: "CONDITION",
//       flex: 1,
//       headerAlign: "center",
//       align: "center",
//       headerClassName: "datadrid_common_header",
//       cellClassName: "datagrid_common_cell",
//       renderCell: (params) => {
//   const condition = params?.row?.condition;

//   if (condition === "-" || !condition) {
//     return <p style={{ padding: "0.25rem 0.5rem" }}>-</p>;
//   }

//   return (
//     <p
//       style={{
//         ...statusStyleStaticData[condition],
//         padding: "0.25rem 0.5rem",
//         borderRadius: "0.25rem",
//         cursor: "default",
//       }}
//     >
//       {statusStaticData[condition]}
//     </p>
//   );
// }

//       // renderCell: (params) => (
//       //   <p
//       //     style={{
//       //       ...statusStyleStaticData[params?.row?.condition],
//       //       padding: "0.25rem 0.5rem",
//       //       borderRadius: "0.25rem",
//       //       cursor: "default",
//       //     }}
//       //   >
//       //     {params?.row?.condition
//       //       ? statusStaticData[params?.row?.condition]
//       //       : "-"}
//       //   </p>
//       // ),
//     },
//   ];

//   return (
//     <>
//   <Grid item xs={12} sm={6} md={4}>
//     <Card className={`${Styles.card} ${Styles.cardFixed}`}>
//       <CardContent className={Styles.cardContent}>
//       <div className={Styles.cardHeader}>
//           <Typography className={Styles.assetDashboardTitle}>Additive Consumption per unit</Typography>
//           <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
//               Amount of additive per unit produced
//           </Typography>
//           <hr className={Styles.divider} />
//       </div>
 
//     <ClonosDataGrid
//       rows={setSerialNumber(addictiveConsumptionData,pagination.page,pagination.limit)}
//       columns={addictiveConsumptionColumns}
//       uniqueIdField="id"
//       onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
//       isLoading={false}
//       totalCount={totalCount}
//       pageLimit={5}  
//       checkboxSelection={false}
//       // paginationMode="client"
//     />
//     </CardContent>
//     </Card>
//     </Grid>
//        </>
//   );
// }

// export default AddictiveConsumption




// import React, { useEffect, useState } from "react";
// import Styles from '../process-dashboard.module.css';
// import { Grid, Card, CardContent, Typography } from "@mui/material";
// import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { setSerialNumber } from "../../../../utils/clonosCommon";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";

// function AddictiveConsumption() {
//   const [addictiveConsumptionData, setAddictiveConsumptionData] = useState([]);
//   const [totalCount, setTotalCount] = useState(0);
//   const [pagination, setPagination] = useState({ page: 1, limit: 5 });

//   // ✅ Expected additive values per process
//   // kg/t for solid additives, % for others (converted later)
//   const expectedAdditives = {
//     "Neutralization": { 
//         "Caustic Soda": 1.46,   // kg/t
//         "Phosphoric Acid": 0.3, // kg/t
//         "Citric Acid": 0.1      // kg/t
//     },
//     "Dewaxing": { 
//         "Soap": 0.46            // % per batch
//     },
//     "Bleaching": { 
//         "Earth": 8              // % per batch
//     }
//     // Energy, Deodorization etc. not tracked
//   };

//   // ✅ Calculate condition based on % deviation and additive scale
//   const calculateCondition = (processName, additiveNames, actualTotalKG, outputKG=1) => {
//     const processExpected = expectedAdditives[processName];
//     if (!processExpected || Object.keys(processExpected).length === 0) return "-";

//     const totalExpected = additiveNames.reduce((sum, name) => {
//       let expected = processExpected[name] || 0;
//       // If expected <1, treat as % and convert to kg
//       if (expected > 0 && expected < 1) {
//         expected = (expected / 100) * outputKG;
//       }
//       return sum + expected;
//     }, 0);

//     if (totalExpected === 0) return actualTotalKG === 0 ? "-" : "Poor";

//     const deviation = ((actualTotalKG - totalExpected) / totalExpected) * 100;

//     if (deviation >= -5 && deviation <= 5) return "Excellent"; // ±5%
//     if (deviation > 5 && deviation <= 20) return "Good";        // slight overuse
//     if (deviation > 20) return "Poor";                          // extreme overuse
//     if (deviation < -5 && deviation >= -20) return "Good";      // underutilization
//     if (deviation < -20) return "Poor";                         // extreme underuse

//     return "-";
//   };

//   // ✅ Fetch additive consumption data from API
//   const getAddictiveConsumptionData = (pagination) => {
//     doGetApiCall({
//       url: `processDashboards/activehours`,
//       params: pagination
//     })
//     .then((res) => {
//       const rawData = res?.data?.result?.additiveConsumption?.data || [];

//       const addictivesData = rawData.map((item, index) => {
//         const additiveNames = item.additivesAdded.split(",").map(a => a.trim());
//         return {
//           id: index + 1,
//           ...item,
//           condition: calculateCondition(
//             item.processName,
//             additiveNames,
//             item.totalAdditiveKG,
//             item.outputKG || 1
//           )
//         };
//       });

//       setAddictiveConsumptionData(addictivesData);
//       setTotalCount(res?.data?.result?.additiveConsumption?.totalDataCount || 0);
//     });
//   };

//   // ✅ Load data on component mount / pagination change
//   useEffect(() => {
//     getAddictiveConsumptionData(pagination);
//   }, [pagination]);

//   // ✅ MUI columns for data grid
//   const addictiveConsumptionColumns = [
//     { field: "processName", headerName: "Process Name", flex: 1 },
//     {
//       field: "additivesAdded",
//       headerName: "Additive’s Added",
//       flex: 2,
//       headerAlign: "center",
//       align: "center",
//     },
//     {
//       field: "condition",
//       headerName: "CONDITION",
//       flex: 1,
//       headerAlign: "center",
//       align: "center",
//       headerClassName: "datadrid_common_header",
//       cellClassName: "datagrid_common_cell",
//       renderCell: (params) => (
//         <p
//           style={{
//             ...statusStyleStaticData[params?.row?.condition],
//             padding: "0.25rem 0.5rem",
//             borderRadius: "0.25rem",
//             cursor: "default",
//           }}
//         >
//           {params?.row?.condition ? statusStaticData[params?.row?.condition] : "-"}
//         </p>
//       ),
//     },
//   ];

//   return (
//     <Grid item xs={12} sm={6} md={4}>
//       <Card className={`${Styles.card} ${Styles.cardFixed}`}>
//         <CardContent className={Styles.cardContent}>
//           <div className={Styles.cardHeader}>
//             <Typography className={Styles.assetDashboardTitle}>
//               Additive Consumption per unit
//             </Typography>
//             <Typography variant="body2" style={{ fontSize: "12px" }} color="textSecondary">
//               Amount of additive per unit produced
//             </Typography>
//             <hr className={Styles.divider} />
//           </div>
//           <ClonosDataGrid
//             rows={setSerialNumber(addictiveConsumptionData, pagination.page, pagination.limit)}
//             columns={addictiveConsumptionColumns}
//             uniqueIdField="id"
//             onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
//             isLoading={false}
//             totalCount={totalCount}
//             pageLimit={5}
//             checkboxSelection={false}
//           />
//         </CardContent>
//       </Card>
//     </Grid>
//   );
// }

// export default AddictiveConsumption;


import React, { useEffect, useState } from "react";
import Styles from '../process-dashboard.module.css';
import { Grid, Card, CardContent, Typography } from "@mui/material";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { setSerialNumber } from "../../../../utils/clonosCommon";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";

function AddictiveConsumption() {
  const [addictiveConsumptionData, setAddictiveConsumptionData] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [pagination, setPagination] = useState({ page: 1, limit: 5 });

  // Additive expected mapping
  const additiveMapping = {
    "Caustic Soda": { value: 1.46, type: "kg" },        // kg/t
    "Phosphoric Acid": { value: 0.3, type: "kg" },      // kg/t
    "Citric Acid": { value: 0.1, type: "percent" },     // %
    "Steam": { value: 0.46, type: "percent" },          // Soap %
    "Bleaching earth dosing 630 A-% (0.5 - 2.0)": { value: 8, type: "percent" }, // Earth %
  };

  const plantEfficiency = 0.8; // 80%
  const fallbackBatchSize = 1; // tons if outputKG = 0

  // Calculate condition based on actual totalAdditiveKG and expected additive
  const calculateCondition = (additivesAdded, actualKG, outputKG) => {
    const additiveNames = additivesAdded.split(",").map(a => a.trim());
    const batchSize = outputKG > 0 ? outputKG : fallbackBatchSize;

    let expectedTotalKG = 0;

    additiveNames.forEach(name => {
      const additive = additiveMapping[name];
      if (additive) {
        let expectedKG = additive.value;

        if (additive.type === "percent") {
          expectedKG = (expectedKG / 100) * batchSize;
        } else {
          // kg/t → scale by batch size
          expectedKG = expectedKG * batchSize;
        }

        // Apply plant efficiency
        expectedKG *= plantEfficiency;

        expectedTotalKG += expectedKG;
      }
    });

    if (expectedTotalKG === 0) return "-";

    const deviation = actualKG - expectedTotalKG;

    if (Math.abs(deviation) <= 5) return "Excellent";
    if ((deviation > 5 && deviation <= 20) || (deviation < -5 && deviation >= -20)) return "Good";
    if (deviation > 20 || deviation < -20) return "Poor";

    return "-";
  };

  // Fetch additive consumption data
  const getAddictiveConsumptionData = (pagination) => {
    doGetApiCall({
      url: `processDashboards/activehours`,
      params: pagination
    })
      .then((res) => {
        const rawData = res?.data?.result?.additiveConsumption?.data || [];
        const finalData = rawData.map((item, index) => ({
          id: index + 1,
          ...item,
          condition: calculateCondition(item.additivesAdded, item.totalAdditiveKG, item.outputKG)
        }));

        setAddictiveConsumptionData(finalData);
        setTotalCount(res?.data?.result?.additiveConsumption?.totalDataCount || 0);
      })
      .catch(err => {
        console.error("Failed to fetch additive consumption:", err);
        setAddictiveConsumptionData([]);
        setTotalCount(0);
      });
  };

  useEffect(() => {
    getAddictiveConsumptionData(pagination);
  }, [pagination]);

  const addictiveConsumptionColumns = [
    { field: "processName", headerName: "Process Name", flex: 1 },

    { field: "additivesAdded", headerName: "Additive’s Added", flex: 2, align: "center", headerAlign: "center" },

    // { field: "totalAdditiveKG", headerName: "Total Additive (KG)", flex: 1, align: "center", headerAlign: "center" },
    {
      field: "condition",
      headerName: "CONDITION",
      flex: 1,
      align: "center",
      headerAlign: "center",
      renderCell: (params) => (
        <p
          style={{
            ...statusStyleStaticData[params.row.condition],
            padding: "4px 8px",
            borderRadius: "4px"
          }}
        >
          {statusStaticData[params.row.condition] || "-"}
        </p>
      ),
    }
  ];

  return (
    <Grid item xs={12} sm={6} md={4}>
      <Card className={`${Styles.card} ${Styles.cardFixed}`}>
        <CardContent className={Styles.cardContent}>
          <div className={Styles.cardHeader}>
            <Typography className={Styles.assetDashboardTitle}>
              Additive Consumption per unit
            </Typography>
            <Typography variant="body2" style={{ fontSize: "12px" }} color="textSecondary">
              Amount of additive per unit produced
            </Typography>
            <hr className={Styles.divider} />
          </div>
          <ClonosDataGrid
            rows={setSerialNumber(addictiveConsumptionData, pagination.page, pagination.limit)}
            columns={addictiveConsumptionColumns}
            uniqueIdField="id"
            onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
            totalCount={totalCount}
            pageLimit={5}
            checkboxSelection={false}
          />
        </CardContent>
      </Card>
    </Grid>
  );
}

export default AddictiveConsumption;
