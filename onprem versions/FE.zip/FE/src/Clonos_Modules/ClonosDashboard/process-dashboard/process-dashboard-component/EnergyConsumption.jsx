import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../process-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { setSerialNumber } from "../../../../utils/clonosCommon";
import { doGetApiCall } from "../../../../utils/ClonosApi";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function EnergyConsumption() {

  const [energyConsumptionData,setEnergyConsumptionData]=useState([])
  const [totalCount,setTotalCount]=useState({})
      
  const [pagination, setPagination] = useState({page:1,limit:5})
      

// const defaultDesignValues = {
//   "Refinery": 20000,
//   "Cooling Tower": 5000,
//   "Wax Press": 7000,
//   "Tank Form": 200,
//   "Wax Pre Heater": 1000
// };

  

// function getEnergyCondition(actualValue, parameterName) {
//   const designValue = defaultDesignValues[parameterName] || 10000; // fallback if not defined
//   const lowerLimit = designValue * 0.95; // ±5% Excellent
//   const upperLimit = designValue * 1.05;
//   const goodLimit = designValue * 0.8;   // -20% Good
//   const poorLimit = designValue * 1.2;   // +20% Poor

//   if (actualValue >= lowerLimit && actualValue <= upperLimit) return "Excellent";
//   if (actualValue >= goodLimit && actualValue < lowerLimit) return "Good";
//   return "Poor";
// }

const defaultDesignValue = 30; // single reference value for all parameters
function getEnergyCondition(actualValue) {
  const lowerLimit = defaultDesignValue * 0.95; // ±5% Excellent
  const upperLimit = defaultDesignValue * 1.05;
  const goodLimit = defaultDesignValue * 0.8;   // -20% Good
  const poorLimit = defaultDesignValue * 1.2;   // +20% Poor

  if (actualValue >= lowerLimit && actualValue <= upperLimit) return "Excellent";
  if (actualValue >= goodLimit && actualValue < lowerLimit) return "Good";
  return "Poor";
}



function getEnergyConsumptionData(pagination) {
  doGetApiCall({
    url: `processDashboards/activehours`,
    params: pagination
  })
  .then((res) => {
    const rawData = res?.data?.result?.energyConsumption?.data || [];
  

    const energyData = rawData.map((item, index) => ({
      id: index + 1,
      ...item,
      condition: getEnergyCondition(item.value),
      // condition: getEnergyCondition(item.value, item.parameterName),
    }));

    setEnergyConsumptionData(energyData);
    setTotalCount(res?.data?.result?.energyConsumption?.totalDataCount || 0);
  });
}



    // Load initial data
  useEffect(() => {
    getEnergyConsumptionData(pagination);
  }, [pagination]);

  // ✅ Define MUI columns
  const energyConsumptionColumns = [
    { field: "parameterName", headerName: "Product Name", flex: 1.5 },
    // {
    //   field: "unit",
    //   headerName: "Unit’s Produced",
    //   flex: 1,
    //   headerAlign: "center",
    //   align: "center",
    // //   renderCell: (params) => {
    // //     const months = uptimeRatioData?.months || [];
    // //     const hours = params.row.monthlyActiveHours || [];

    // //     return (
    // //       <div style={{ display: "flex", gap: 4, justifyContent: "center", gap: "6px", flexWrap: "nowrap",  }}>
    // //         {months.map((month, i) => {
    // //           const total = getTotalUptime(month);
    // //           const actual = hours[i] ?? 0;
    // //           return <SplitUptimeBar key={i} actual={actual} total={total} month={month} />;
    // //         })}
    // //       </div>
    // //     );
    // //   },
    // },
    {
      field: "value",
      headerName: "KWh/ton Consumed",
      flex: 1,
      headerAlign: "center",
      align: "center",
    //   renderCell: (params) => {
    //     const months = uptimeRatioData?.months || [];
    //     const hours = params.row.monthlyActiveHours || [];

    //     return (
    //       <div style={{ display: "flex", gap: 4, justifyContent: "center", gap: "6px", flexWrap: "nowrap",  }}>
    //         {months.map((month, i) => {
    //           const total = getTotalUptime(month);
    //           const actual = hours[i] ?? 0;
    //           return <SplitUptimeBar key={i} actual={actual} total={total} month={month} />;
    //         })}
    //       </div>
    //     );
    //   },
    },

    {
      field: "condition",
      headerName: "CONDITION",
      flex: 1,
      headerAlign: "center",
      align: "center",
      headerClassName: "datadrid_common_header",
      cellClassName: "datagrid_common_cell",
      renderCell: (params) => (
        <p
          style={{
            ...statusStyleStaticData[params?.row?.condition],
            padding: "0.25rem 0.5rem",
            borderRadius: "0.25rem",
            cursor: "default",
          }}
        >
          {params?.row?.condition
            ? statusStaticData[params?.row?.condition]
            : "-"}
        </p>
      ),
    },
  ];

  return (
    <>
                    <Grid item xs={12} sm={6} md={4}>
                      <Card className={`${Styles.card} ${Styles.cardFixed}`}>
                        <CardContent className={Styles.cardContent}>
                      <div className={Styles.cardHeader}>
    <Typography className={Styles.assetDashboardTitle}>Energy Consumption</Typography>
    <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
   Energy Required to produced one unit
    </Typography>
    <hr className={Styles.divider} />
</div>
 
    <ClonosDataGrid
      rows={setSerialNumber(energyConsumptionData,pagination.page,pagination.limit)}
      columns={energyConsumptionColumns}
      uniqueIdField="id"
      onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
      isLoading={false}
      totalCount={totalCount}
      pageLimit={5}  
      checkboxSelection={false}
      // paginationMode="client"
    />
    </CardContent>
    </Card>
    </Grid>
       </>
  );
}

export default EnergyConsumption