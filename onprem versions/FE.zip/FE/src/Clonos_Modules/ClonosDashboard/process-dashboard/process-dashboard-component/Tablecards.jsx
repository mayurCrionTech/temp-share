import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../process-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import ProcessDowntime from "./ProcessDowntime";
import WaterConsumption from "./WaterConsumption";
import AddictiveConsumption from "./AddictiveConsumption";
import EnergyConsumption from "./EnergyConsumption";
import SteamAndThermalEnergy from "./SteamAndThermalEnergy";
import ProcessStabilityIndex from "./ProcessStabilityIndex";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

// function Tablecards() {
  
//   return (
//    <Container className={Styles.section}>
//   <div className={Styles.uptimeAndMaintenanceRow}>
//     {/* <div className={Styles.cardWrapper}>
//         <ProcessDowntime/>

//     </div> */}
//     <div className={Styles.cardWrapper}>
      
//        <WaterConsumption/>
//     </div>
//      <div className={Styles.cardWrapper}>
//        <AddictiveConsumption/>
//     </div>
//     <div className={Styles.cardWrapper}>
      
//       <EnergyConsumption/>
//     </div>
//      {/* <div className={Styles.cardWrapper}>
//        <SteamAndThermalEnergy/>

//     </div> */}
//     {/* <div className={Styles.cardWrapper}>
      
//        <ProcessStabilityIndex/>
//     </div> */}
//   </div>
// </Container>
//   )
// }


function Tablecards() {
  return (
    // <Container className={Styles.section}>
      <div className={Styles.uptimeAndMaintenanceRow}>
        <div className={Styles.cardWrapper}>
          <ProcessDowntime/>
        </div>

        <div className={Styles.cardWrapper}>
          <SteamAndThermalEnergy/>
        </div>
        <div className={Styles.cardWrapper}>
          <AddictiveConsumption/>
        </div>
        <div className={Styles.cardWrapper}>
          <EnergyConsumption/>
        </div>
      </div>
    // </Container>
  )
}


export default Tablecards