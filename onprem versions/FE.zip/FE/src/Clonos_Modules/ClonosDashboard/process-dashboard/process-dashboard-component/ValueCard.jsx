// import React, { useEffect, useState,useMemo } from "react";
// import Styles from  '../process-dashboard.module.css';
// // import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// // import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// // import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// // import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// // import ClonosGridNav from "../../../utils/ClonosGridNav"
// import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
// // import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// // import { Box } from '@mui/material'

// // import {
// //   DataGrid,
// //   gridPageCountSelector,
// //   useGridApiContext,
// //   useGridSelector,
// // } from '@mui/x-data-grid';
// // import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// // import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// // import { doGetApiCall } from "../../../utils/ClonosApi";
// // import AppUrl from "../../../utils/AppUrl";


// function ValueCard({processData}) {

//  const valueData = [
//   {
//     id: 4,
//     title: "Production Loss",
//     subtitle: "Total quantity lost due to rejects, reworks and breakdown",
//     value:processData?.productionLoss,
//     unit: "%",
//     scaleTitle: "Production Loss (Scale)",
//     scale: [
//       { color: "#60D468", text: "Excellent", range: "< 6 %  production", min: -Infinity, max: 5.99 },
//       { color: "#FEBC2F", text: "Good", range: "6 - 16 %  production", min: 6, max: 16 },
//       { color: "#D24B5A", text: "Poor", range: "> 16 %  Production", min: 16.01, max: Infinity },
//     ],
//   },
//   // {
//   //   id: 5,
//   //   title: "Changeover Time",
//   //   subtitle: "Time taken to switch batches / formulation",
//   //   value: processData?.changeoverTime ,
//   //   unit: "Minutes",
//   //   scaleTitle: "Changeover Time (Scale)",
//   //   scale: [
//   //     { color: "#60D468", text: "Excellent", range: "< 30 Minutes", min: -Infinity, max: 29.99 },
//   //     { color: "#FEBC2F", text: "Good", range: "30 - 120 Minutes", min: 30, max: 120 },
//   //     { color: "#D24B5A", text: "Poor", range: "> 120 Minutes", min: 120.01, max: Infinity },
//   //   ],
//   // },
  
// ];


// const circleData = [
//   {
//     id: 6,
//     title: "Material Utilization Efficiency",
//     subtitle: "Useful Material output vs total material input",
//     value:processData?.materialUtilization,
//     unit: "%",
//     scaleTitle: "Material Utilization (Scale)",
//     scale: [
//       { color: "#60D468", text: "Excellent", range: "100 %", min: 99.01,max:100 },
//       { color: "#FEBC2F", text: "Good", range: "70 - 99 %", min: 70, max: 99 },
//       { color: "#D24B5A", text: "Poor", range: "<70 %", min: 0, max: 69.99 },
//     ],
//   },
  
  
// ];

// //   const matchScale = (value, scale) => {
// //   if (value === null || !Array.isArray(scale)) return null;

// //   for (const row of scale) {
// //     const s = String(row.range).toLowerCase().trim();

// //     // 1) Between: "1 - 4", "6 - 40"
// //     const between = s.match(/(-?\d+(\.\d+)?)\s*(?:-|–|to)\s*(-?\d+(\.\d+)?)/);
// //     if (between) {
// //       const min = parseFloat(between[1]);
// //       const max = parseFloat(between[3]);
// //       if (value >= min && value <= max) return row;
// //       continue;
// //     }

// //     // 2) Less-than: "< 5", "<= 5"
// //     const ltEq = s.match(/^<=\s*(-?\d+(\.\d+)?)/);
// //     if (ltEq && value <= parseFloat(ltEq[1])) return row;

// //     const lt = s.match(/^<\s*(-?\d+(\.\d+)?)/);
// //     if (lt && value < parseFloat(lt[1])) return row;

// //     // 3) Greater-than: ">= 8", "> 8"
// //     const gtEq = s.match(/^>=\s*(-?\d+(\.\d+)?)/);
// //     if (gtEq && value >= parseFloat(gtEq[1])) return row;

// //     const gt = s.match(/^>\s*(-?\d+(\.\d+)?)/);
// //     if (gt && value > parseFloat(gt[1])) return row;
// //   }

// //   return null; // no match
// // };


// const matchScale = (value, scale) => {
//   if (value === null || !Array.isArray(scale)) return null;

//   const numericValue = Number(value); // 🔥 FIX

//   for (const row of scale) {
//     const { min = -Infinity, max = Infinity } = row;
//     if (numericValue >= min && numericValue <= max) return row;
//   }

//   return null;
// };


//   return (
//    <>
//    <Container className={Styles.section}>
//   <div className={Styles.valueCardContainer}>
//     {valueData?.map((item, i) => (
//       <Card key={i} className={`${Styles.card} ${Styles.cardFixed}`}>
//         <CardContent className={Styles.cardContent}>
//           <Typography className={Styles.assetDashboardTitle}>{item?.title}</Typography>
//           <Typography variant="body2" color="textSecondary" style={{fontSize:"12px"}}>
//             {item?.subtitle}
//           </Typography>
//           <hr className={Styles.divider} />

//           {/* left value + right scale */}
//           <div className={Styles.valueContentRow}>
//             <div className={Styles.valueNumber}>
//               {(() => {
//                 const active = matchScale(item.value, item.scale);
//                 const color = active?.color || item?.color || '#23A45E';
//                 return (
//                   <>
//                     <span className={Styles.valueBig} style={{ color }}>
//                       {item?.value}
//                     </span>
//                     <span className={Styles.valueUnit} style={{ color }}>
//                       {item?.unit}
//                     </span>
//                   </>
//                 );
//               })()}
//             </div>

//             <div className={Styles.scaleCol}>
//               <Typography className={Styles.scaleTitle}>{item?.scaleTitle}</Typography>
//               {item.scale.map((ele, j) => (
//                 <div key={j} className={Styles.scaleRow}>
//                   <div className={Styles.scaleLeft}>
//                     <span className={Styles.legendDot} style={{ backgroundColor: ele.color }} />
//                     <Typography className={Styles.scaleText}>{ele.text}</Typography>
//                   </div>
//                   <Typography className={Styles.scaleRange}>{ele.range}</Typography>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </CardContent>
//       </Card>
//     ))}
//      {circleData?.map((item, i) => (
//       <Card key={i} className={`${Styles.card} ${Styles.cardFixed}`}>
//         <CardContent className={Styles.cardContent}>
//           <Typography className={Styles.assetDashboardTitle}>{item?.title}</Typography>
//           <Typography variant="body2" color="textSecondary" style={{fontSize:"12px"}}>
//             {item?.subtitle}
//           </Typography>
//           <hr className={Styles.divider} />

//           {/* left value + right scale */}
//           <div className={Styles.valueContentRow}>
//             <div className={Styles.valueNumber}>
//               {(() => {
//                 const active = matchScale(item.value, item.scale);
//                 console.log(active,"activelable")
//                 const color = active?.color || item?.color || '#23A45E';
//                 return (
//                   <>
//                   <span className={Styles.circleWrapper}>
//   <svg
//     className={Styles.progressRing}
//     width="180"
//     height="180"
//     viewBox="0 0 120 120"
//   >
//     {/* Base gray ring */}
//     <circle
//       className={Styles.baseRing}
//       cx="60"
//       cy="60"
//       r="55"
//       stroke="#747474" 
//       strokeWidth="1"
//       fill="none"
   
//     />

//     {/* Green progress ring */}
//     <circle
//       className={Styles.progressRingCircle}
//       cx="60"
//       cy="60"
//       r="55"
//       stroke={color}
//       strokeWidth="4"
//       fill="none"
//       strokeDasharray={2 * Math.PI * 55}
//       strokeDashoffset={(1 - item.value / 100) * 2 * Math.PI * 55}
//       strokeLinecap="round"
//     />
//   </svg>

//   <div className={Styles.circleContent}>
//   <p>{item.value ?? 0}% is stocked</p>
//   <h3 style={{ color }}>{active?.text || "No Scale"}</h3>

//   </div>
// </span>

   
//                   </>
//                 );
//               })()}
//             </div>

//             <div className={Styles.scaleCol}>
//               <Typography className={Styles.scaleTitle}>{item?.scaleTitle}</Typography>
//               {item.scale.map((ele, j) => (
//                 <div key={j} className={Styles.scaleRow}>
//                   <div className={Styles.scaleLeft}>
//                     <span className={Styles.legendDot} style={{ backgroundColor: ele.color }} />
//                     <Typography className={Styles.scaleText}>{ele.text}</Typography>
//                   </div>
//                   <Typography className={Styles.scaleRange}>{ele.range}</Typography>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </CardContent>
//       </Card>
//     ))}
//   </div>
// </Container>

//    </>
//   )
// }

// export default ValueCard



import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../process-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";


function ValueCard({processData}) {

 const valueData = [
  {
    id: 4,
    title: "Production Loss",
    subtitle: "Total quantity lost due to rejects, reworks and breakdown",
    value:processData?.productionLoss,
    unit: "%",
    scaleTitle: "Production Loss (Scale)",
    scale: [
      { color: "#60D468", text: "Excellent", range: "< 6 %  production", min: -Infinity, max: 5.99 },
      { color: "#FEBC2F", text: "Good", range: "6 - 16 %  production", min: 6, max: 16 },
      { color: "#D24B5A", text: "Poor", range: "> 16 %  Production", min: 16.01, max: Infinity },
    ],
  },
  // {
  //   id: 5,
  //   title: "Changeover Time",
  //   subtitle: "Time taken to switch batches / formulation",
  //   value: processData?.changeoverTime ,
  //   unit: "Minutes",
  //   scaleTitle: "Changeover Time (Scale)",
  //   scale: [
  //     { color: "#60D468", text: "Excellent", range: "< 30 Minutes", min: -Infinity, max: 29.99 },
  //     { color: "#FEBC2F", text: "Good", range: "30 - 120 Minutes", min: 30, max: 120 },
  //     { color: "#D24B5A", text: "Poor", range: "> 120 Minutes", min: 120.01, max: Infinity },
  //   ],
  // },
  
];


const circleData = [
  {
    id: 6,
    title: "Material Utilization Efficiency",
    subtitle: "Useful Material output vs total material input",
    value:processData?.materialUtilization,
    unit: "%",
    scaleTitle: "Material Utilization (Scale)",
    scale: [
      { color: "#60D468", text: "Excellent", range: "100 %", min: 99.01,max:100 },
      { color: "#FEBC2F", text: "Good", range: "70 - 99 %", min: 70, max: 99 },
      { color: "#D24B5A", text: "Poor", range: "<70 %", min: 0, max: 69.99 },
    ],
  },
  
  
];

//   const matchScale = (value, scale) => {
//   if (value === null || !Array.isArray(scale)) return null;

//   for (const row of scale) {
//     const s = String(row.range).toLowerCase().trim();

//     // 1) Between: "1 - 4", "6 - 40"
//     const between = s.match(/(-?\d+(\.\d+)?)\s*(?:-|–|to)\s*(-?\d+(\.\d+)?)/);
//     if (between) {
//       const min = parseFloat(between[1]);
//       const max = parseFloat(between[3]);
//       if (value >= min && value <= max) return row;
//       continue;
//     }

//     // 2) Less-than: "< 5", "<= 5"
//     const ltEq = s.match(/^<=\s*(-?\d+(\.\d+)?)/);
//     if (ltEq && value <= parseFloat(ltEq[1])) return row;

//     const lt = s.match(/^<\s*(-?\d+(\.\d+)?)/);
//     if (lt && value < parseFloat(lt[1])) return row;

//     // 3) Greater-than: ">= 8", "> 8"
//     const gtEq = s.match(/^>=\s*(-?\d+(\.\d+)?)/);
//     if (gtEq && value >= parseFloat(gtEq[1])) return row;

//     const gt = s.match(/^>\s*(-?\d+(\.\d+)?)/);
//     if (gt && value > parseFloat(gt[1])) return row;
//   }

//   return null; // no match
// };


const matchScale = (value, scale) => {
  if (value === null || !Array.isArray(scale)) return null;

  const numericValue = Number(value); // 🔥 FIX

  for (const row of scale) {
    const { min = -Infinity, max = Infinity } = row;
    if (numericValue >= min && numericValue <= max) return row;
  }

  return null;
};


  return (
   <>
  {valueData?.map((item, i) => (
    <Card key={`val-${i}`} className={`${Styles.card} ${Styles.cardFixed}`}>
      <CardContent className={Styles.cardContent}>
        <Typography className={Styles.assetDashboardTitle}>{item?.title}</Typography>
        <Typography variant="body2" color="textSecondary" style={{ fontSize: "12px" }}>
          {item?.subtitle}
        </Typography>
        <hr className={Styles.divider} />

        <div className={Styles.valueContentRow}>
          <div className={Styles.valueNumber}>
            {(() => {
              const active = matchScale(item.value, item.scale);
              const color = active?.color || item?.color || "#23A45E";
              return (
                <>
                  <span className={Styles.valueBig} style={{ color }}>
                    {item?.value}
                  </span>
                  <span className={Styles.valueUnit} style={{ color }}>
                    {item?.unit}
                  </span>
                </>
              );
            })()}
          </div>

          <div className={Styles.scaleCol}>
            <Typography className={Styles.scaleTitle}>{item?.scaleTitle}</Typography>
            {item.scale.map((ele, j) => (
              <div key={j} className={Styles.scaleRow}>
                <div className={Styles.scaleLeft}>
                  <span className={Styles.legendDot} style={{ backgroundColor: ele.color }} />
                  <Typography className={Styles.scaleText}>{ele.text}</Typography>
                </div>
                <Typography className={Styles.scaleRange}>{ele.range}</Typography>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  ))}

  {circleData?.map((item, i) => (
    <Card key={`circle-${i}`} className={`${Styles.card} ${Styles.cardFixed}`}>
      <CardContent className={Styles.cardContent}>
        <Typography className={Styles.assetDashboardTitle}>{item?.title}</Typography>
        <Typography variant="body2" color="textSecondary" style={{ fontSize: "12px" }}>
          {item?.subtitle}
        </Typography>
        <hr className={Styles.divider} />

        <div className={Styles.valueContentRow}>
          <div className={Styles.valueNumber}>
            <span className={Styles.circleWrapper}>
              <svg className={Styles.progressRing} width="180" height="180" viewBox="0 0 120 120">
                <circle
                  cx="60"
                  cy="60"
                  r="55"
                  stroke="#747474"
                  strokeWidth="1"
                  fill="none"
                />

                <circle
                  cx="60"
                  cy="60"
                  r="55"
                  stroke={matchScale(item.value, item.scale)?.color || "#23A45E"}
                  strokeWidth="4"
                  fill="none"
                  strokeDasharray={2 * Math.PI * 55}
                  strokeDashoffset={(1 - item.value / 100) * 2 * Math.PI * 55}
                  strokeLinecap="round"
                />
              </svg>

              <div className={Styles.circleContent}>
                <p>{item.value ?? 0}% of is stocked</p>
                <h3 style={{ color: matchScale(item.value, item.scale)?.color }}>
                  {matchScale(item.value, item.scale)?.text || "No Scale"}
                </h3>
              </div>
            </span>
          </div>

          <div className={Styles.scaleCol}>
            <Typography className={Styles.scaleTitle}>{item?.scaleTitle}</Typography>
            {item.scale.map((ele, j) => (
              <div key={j} className={Styles.scaleRow}>
                <div className={Styles.scaleLeft}>
                  <span className={Styles.legendDot} style={{ backgroundColor: ele.color }} />
                  <Typography className={Styles.scaleText}>{ele.text}</Typography>
                </div>
                <Typography className={Styles.scaleRange}>{ele.range}</Typography>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  ))}
</>

  )
}

export default ValueCard