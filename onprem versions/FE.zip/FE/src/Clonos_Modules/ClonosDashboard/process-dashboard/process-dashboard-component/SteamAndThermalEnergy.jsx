import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../process-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { setSerialNumber } from "../../../../utils/clonosCommon";
import { doGetApiCall } from "../../../../utils/ClonosApi";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function SteamAndThermalEnergy() {

     const [steamandThermalConsumptionData,setSteamandThermalConsumptionData]=useState([])
     const [totalCount,setTotalCount]=useState({})
         
     const [pagination, setPagination] = useState({page:1,limit:5})
         

   const defaultSteamDesignValues = {
  "Steam Generation": 85, // default design steam in KG
};
  
     
 function getSteamCondition(actualSteam, processName) {
  const designValue = defaultSteamDesignValues[processName] || 30; // fallback
  const lowerLimit = designValue * 0.95; // ±5% Excellent
  const upperLimit = designValue * 1.05;
  const goodLimit = designValue * 0.8;   // -20% Good
  const poorLimit = designValue * 1.2;   // +20% Poor

  if (actualSteam >= lowerLimit && actualSteam <= upperLimit) return "Excellent";
  if (actualSteam >= goodLimit && actualSteam < lowerLimit) return "Good";
  return "Poor";
}



   function getSteamAndThermalConsumptionData(pagination) {
     doGetApiCall({
       url: `processDashboards/activehours`,
       params: pagination
     })
     .then((res) => {
       const rawData = res?.data?.result?.steamThermalEnergy?.data || [];
     
   
       const steamAndThermalData = rawData.map((item, index) => ({
         id: index + 1, 
         ...item,
         condition: getSteamCondition(item.totalSteamKG, item.processName),
       }));
   
       setSteamandThermalConsumptionData(steamAndThermalData);
       setTotalCount(res?.data?.result?.steamThermalEnergy?.totalDataCount || 0);
     });
   }
   
  
   
       // Load initial data
     useEffect(() => {
       getSteamAndThermalConsumptionData(pagination);
     }, [pagination]);

  // ✅ Define MUI columns
  const steamAndThermalConsumptionColumns = [
    { field: "processName", headerName: "Process Name", flex: 1 },
    // {
    //   field: "produce",
    //   headerName: "Unit’s Produced",
    //   flex: 1,
    //   headerAlign: "center",
    //   align: "center",
    //   renderCell: (params) => {
    //     const months = uptimeRatioData?.months || [];
    //     const hours = params.row.monthlyActiveHours || [];

    //     return (
    //       <div style={{ display: "flex", gap: 4, justifyContent: "center", gap: "6px", flexWrap: "nowrap",  }}>
    //         {months.map((month, i) => {
    //           const total = getTotalUptime(month);
    //           const actual = hours[i] ?? 0;
    //           return <SplitUptimeBar key={i} actual={actual} total={total} month={month} />;
    //         })}
    //       </div>
    //     );
    //   },
    // },
    {
      field: "totalSteamKG",
      headerName: "KG Steam/T Consumed",
      flex: 1,
      headerAlign: "center",
      align: "center",
    },

    {
      field: "condition",
      headerName: "CONDITION",
      flex: 1,
      headerAlign: "center",
      align: "center",
      headerClassName: "datadrid_common_header",
      cellClassName: "datagrid_common_cell",
      renderCell: (params) => (
        <p
          style={{
            ...statusStyleStaticData[params?.row?.condition],
            padding: "0.25rem 0.5rem",
            borderRadius: "0.25rem",
            cursor: "default",
          }}
        >
          {params?.row?.condition
            ? statusStaticData[params?.row?.condition]
            : "-"}
        </p>
      ),
    },
  ];

  return (
    <>
                    <Grid item xs={12} sm={6} md={4}>
                      <Card className={`${Styles.card} ${Styles.cardFixed}`}>
                        <CardContent className={Styles.cardContent}>
                      <div className={Styles.cardHeader}>
    <Typography className={Styles.assetDashboardTitle}>Steam / Thermal Energy</Typography>
    <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
  Thermal Energy
    </Typography>
    <hr className={Styles.divider} />
</div>
 
    <ClonosDataGrid
      rows={setSerialNumber(steamandThermalConsumptionData,pagination.page,pagination.limit)}
      columns={steamAndThermalConsumptionColumns}
      uniqueIdField="id"
      onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
      isLoading={false}
      totalCount={totalCount}
      pageLimit={5}  
      checkboxSelection={false}
      // paginationMode="client"
    />
    </CardContent>
    </Card>
    </Grid>
       </>
  );
}

export default SteamAndThermalEnergy