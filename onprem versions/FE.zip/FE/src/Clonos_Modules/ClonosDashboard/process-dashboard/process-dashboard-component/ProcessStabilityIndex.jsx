import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../process-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { setSerialNumber } from "../../../../utils/clonosCommon";
import { doGetApiCall } from "../../../../utils/ClonosApi";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function ProcessStabilityIndex() {

    const [uptimeRatioData,setUptimeRatioData]=useState({})
    
        const [pagination, setPagination] = useState({page:1,limit:5})
      
  
        function getuptimeRatioData(pagination){
            doGetApiCall(({url:`assetDashBoards/activehours?activeAssetHours=true`,params:pagination}))
            .then((res)=>{
              
                setUptimeRatioData(res?.data?.result)
            })
       }

//     // Load initial data
//   useEffect(() => {
//     getuptimeRatioData(pagination);
//   }, [pagination]);

  // ✅ Define MUI columns
  const uptimeColumns = [
    { field: "name", headerName: "Process Name", flex: 1.5 },
    {
      field: "parameter",
      headerName: "Process Parameter",
      flex: 1,
      headerAlign: "center",
      align: "center",
    //   renderCell: (params) => {
    //     const months = uptimeRatioData?.months || [];
    //     const hours = params.row.monthlyActiveHours || [];

    //     return (
    //       <div style={{ display: "flex", gap: 4, justifyContent: "center", gap: "6px", flexWrap: "nowrap",  }}>
    //         {months.map((month, i) => {
    //           const total = getTotalUptime(month);
    //           const actual = hours[i] ?? 0;
    //           return <SplitUptimeBar key={i} actual={actual} total={total} month={month} />;
    //         })}
    //       </div>
    //     );
    //   },
    },
   
    {
      field: "condition",
      headerName: "CONDITION",
      flex: 1,
      headerAlign: "center",
      align: "center",
      headerClassName: "datadrid_common_header",
      cellClassName: "datagrid_common_cell",
    //   renderCell: (params) => (
    //     <p
    //       style={{
    //         ...statusStyleStaticData[params?.row?.condition],
    //         padding: "0.25rem 0.5rem",
    //         borderRadius: "0.25rem",
    //         cursor: "default",
    //       }}
    //     >
    //       {params?.row?.condition
    //         ? statusStaticData[params?.row?.condition]
    //         : "-"}
    //     </p>
    //   ),
    },
  ];

  return (
    <>
                    <Grid item xs={12} sm={6} md={4}>
                      <Card className={`${Styles.card} ${Styles.cardFixed}`}>
                        <CardContent className={Styles.cardContent}>
                      <div className={Styles.cardHeader}>
    <Typography className={Styles.assetDashboardTitle}>Process Stability Index (SPI)</Typography>
    <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
 Consistency of process parameters
    </Typography>
    <hr className={Styles.divider} />
</div>
 
    <ClonosDataGrid
    //   rows={setSerialNumber(uptimeRows,pagination.page,pagination.limit)}
      columns={uptimeColumns}
      uniqueIdField="id"
      onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
      isLoading={false}
      totalCount={uptimeRatioData?.assets?.totalDataCount}
      pageLimit={5}  
      checkboxSelection={false}
      // paginationMode="client"
    />
    </CardContent>
    </Card>
    </Grid>
       </>
  );
}

export default ProcessStabilityIndex