import React, { useEffect, useState } from "react";
import { Grid, Card, CardContent, Typography } from "@mui/material";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import Styles from "./process-dashboard.module.css";

const LiveData = ({ latestData }) => {
  const [loading, setLoading] = useState(true);

  // Template for the cards
  const template = [
    "Phosphoric Acid",
    "Caustic Soda",
    "Earth Powder",
    "Coal",
    "Steam",
    "Power"
  ];

  // Function to capitalize words
  const capitalizeWords = (str) =>
    str.replace(/\b\w/g, (char) => char.toUpperCase());

  // Map data by name
  const dataMap = new Map();
  latestData.forEach((item) => {
    dataMap.set(item.name.toLowerCase(), item);
  });

  // Simulate loading state (in a real-world scenario, remove this)
  useEffect(() => {
    if (latestData.length > 0) {
      setLoading(false);
    }
  }, [latestData]);

  return (
    <>
      <Typography variant="h6" gutterBottom className={Styles.processDashboardTitle}>
        Live Data
      </Typography>
      <Grid container spacing={3}>
        {loading ? (
          // Show skeleton loading for all cards initially
          template.map((label, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <ClonosSkeletonLoading width="100%" height="100px" animation="wave" />
            </Grid>
          ))
        ) : (
          // Show actual data or "Data not available" message
          template.map((label, index) => {
            const data = dataMap.get(label.toLowerCase());

            return (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Card
                  style={{
                    borderRadius: "16px",
                    padding: "10px",
                    height:"165px",
                    minHeight: "130px", // Fixed height for all cards
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                >
                  <CardContent>
                    <Typography variant="h6" className={Styles.processDashboardTitle}>
                      {label}
                    </Typography>

                    {data ? (
                      <>
                        <Typography variant="h4" color="primary">
                          {data.value}{" "}
                          <span style={{ fontSize: "large" }}>{data.units}</span>
                        </Typography>
                        {data.min !== null && data.max !== null && (
                          <Typography variant="body2">
                            Safe Range: {String(data.min)} - {String(data.max)}
                          </Typography>
                        )}
                        {data.lastUpdatedAt && (
                          <Typography variant="body2">Updated at: {data.lastUpdatedAt}</Typography>
                        )}
                      </>
                    ) : (
                      <Typography variant="body2" color="text.secondary">
                        -
                      </Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            );
          })
        )}
      </Grid>
    </>
  );
};

export default LiveData;
