// import React, { useEffect, useState } from "react";
// import Styles from './process-dashboard.module.css';
// import { Container, Card } from "@mui/material";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import DateFilters from '../DateFilters';
// import LiveData from "./LiveData";
// import HistoricalTrends from "./HistoricalTrends";
// import AppUrl from "../../../utils/AppUrl";
// import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";

// function ProcessDashboard() {
//   const [startDate, setStartDate] = useState(null);
//   const [endDate, setEndDate] = useState(null);
//   const [latestData, setLatestData] = useState([]);
//   const [previousIds, setPreviousIds] = useState(new Set());
//   const [isLoading, setIsLoading] = useState(true);
//   const [dataLoadedOnce, setDataLoadedOnce] = useState(false);

//   const formattedStartDate = startDate ? new Date(startDate).toISOString().slice(0, 16) : "";
//   const formattedEndDate = endDate ? new Date(endDate).toISOString().slice(0, 16) : "";

//   const fetchLiveData = (start = null, end = null) => {
//     setIsLoading(true);

//     let url = `${AppUrl.getLatestProcessEntries}?clientId=2`;
//     if (start && end) {
//       url += `&startDate=${start}&endDate=${end}`;
//     }

//     doGetApiCall({ url })
//       .then((res) => {
//         if (res?.data?.result) {
//           const extractedData = Object.entries(res.data.result).map(([key, value]) =>
//             value
//               ? {
//                   id: value._id,
//                   name: key.replace(/([A-Z])/g, " $1").trim(),
//                   value: value.fieldValue || 0,
//                   units: value.units ?? "",
//                   min: value.range?.min ?? null,
//                   max: value.range?.max ?? null,
//                   lastUpdatedAt: new Date(value.entryCreatedAt).toLocaleString(),
//                 }
//               : null
//           ).filter(Boolean);

//           const newIds = new Set(extractedData.map((item) => item.id));
//           const isNewDataAvailable = [...newIds].some((id) => !previousIds.has(id));

//           if (isNewDataAvailable || !dataLoadedOnce) {
//             setLatestData(extractedData);
//             setPreviousIds(newIds);
//           }
//         } else {
//           setLatestData([]);
//         }
//         setDataLoadedOnce(true);
//       })
//       .catch((err) => {
//         console.error("Error fetching live data:", err);
//         setLatestData([]);
//         setDataLoadedOnce(true);
//       })
//       .finally(() => {
//         setIsLoading(false);
//       });
//   };

//   useEffect(() => {
//     fetchLiveData();
//     const interval = setInterval(() => fetchLiveData(formattedStartDate, formattedStartDate), 120000);
//     return () => clearInterval(interval);
//   }, []);

//   useEffect(() => {
//     if (formattedStartDate && formattedEndDate) {
//       if (new Date(formattedStartDate) > new Date(formattedEndDate)) {
//         // If startDate is after endDate, show empty (0) data
//         const zeroData = latestData.map(item => ({
//           ...item,
//           value: 0,
//           lastUpdatedAt: "",
//         }));
//         setLatestData(zeroData);
//       } else {
//         fetchLiveData(formattedStartDate, formattedEndDate);
//       }
//     }
//   }, [formattedStartDate, formattedEndDate]);
   
// console.log(latestData,"latestData")
// // const isDataEmpty =latestData.length===0;
// const isDataEmpty = dataLoadedOnce && Array.isArray(latestData) && latestData.length === 0;


//   return (
//  <>
//       {/* Initial loading spinner before data is loaded */}
//       {!dataLoadedOnce && isLoading ? (
//         <div className={Styles.loaderWrapper}>
//           <ClonosSpinner />
//         </div>
//       ) : isDataEmpty ? (
//         // Show message if data loaded but empty
//         <Card variant="outlined" className={Styles.processDashboardContainer}>
//           <p style={{
//             display: "flex",
//             justifyContent: "center",
//             alignItems: "center",
//             height: "100%",
//             textAlign: "center",
//             fontSize: "25px",
//             color: "#575757"
//           }}>
//             Please Contact Admin to Access this page
//           </p>
//         </Card>
//       ) : (
//         // Show full process dashboard
//         <Card variant="outlined" className={Styles.processDashboardContainer}>
//           <div className={Styles.processDashboardHeader}>
//             <h4 className={Styles.processDashboardTitle}>Process Dashboard</h4>
//             <div className={Styles.dateFilterWrapper}>
//               <DateFilters
//                 startDate={startDate}
//                 endDate={endDate}
//                 setStartDate={setStartDate}
//                 setEndDate={setEndDate}
//               />
//             </div>
//           </div>

//           {isLoading ? (
//             <div className={Styles.loaderWrapper}>
//               <ClonosSpinner />
//             </div>
//           ) : (
//             <main>
//               <Container style={{ marginBottom: "20px" }}>
//                 <LiveData latestData={latestData} />
//                 <br />
//                 <HistoricalTrends startDate={startDate} endDate={endDate} />
//               </Container>
//             </main>
//           )}
//         </Card>
//       )}
// </>


//   );
// }

// export default ProcessDashboard;




import React, { useEffect, useState,useMemo } from "react";
import Styles from './process-dashboard.module.css';
import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
import { Box } from '@mui/material'
import { doGetApiCall } from "../../../utils/ClonosApi";
import GaugeCard from "./process-dashboard-component/GaugeCard";
import ValueCard from "./process-dashboard-component/ValueCard";
import Tablecards from "./process-dashboard-component/Tablecards";
import ReworkAndVariance from "./process-dashboard-component/ReworkAndVariance";
import { ProcessUnderDowntimeIcon, TotalProcessIcon } from "../../../assets/AssetsSVGComponents/TotalProcess";
import AppUrl from "../../../utils/AppUrl";


function ProcessDashboard() {
      const URL = handleSegregateURL();
      const [processData,setProcessData]=useState({})

      function getProcessDashboards(){
            doGetApiCall(({url:AppUrl?.getProcessDashboards}))
            .then((res)=>{
                // console.log(res,"processres")
                setProcessData(res?.data?.result)
            })
      }


      useEffect(() => {
        getProcessDashboards();

      }, []);


  return (
    <>
           {
            (!URL?.unity && !URL?.AR && !URL?.VR) &&
            
                  <ClonosGridNav  items={[
              {
                icon: TotalProcessIcon,
                iconBg: '#E7EFFF',
                title: 'Total Process',
                // count: assetCounts?.totalAssets || 0,
                count:  processData?.totalProcesses ?? 0
              },
              {
                icon: ProcessUnderDowntimeIcon,
                iconBg: '#FBEDEF',
                title: 'Process under Downtime',
                count: processData?.processesUnderDowntime ?? 0  
              },
              
            ]}>
              
            </ClonosGridNav>         
            
          }
    
    <div className={Styles.processDashboardContainer}>
      {/* <main>
         <GaugeCard processData={processData}/>
         <ValueCard processData={processData}/>
         <Tablecards/>
         <ReworkAndVariance/>
         
      </main> */}

      <main className={Styles.mainGrid}>
        <GaugeCard processData={processData} />
        <ValueCard processData={processData} />

        {/* Table spans 2 columns */}
        <div className={Styles.tableSpan}>
          <Tablecards/>
        </div>
      </main>

    </div>
    </>


  );
}

export default ProcessDashboard;

