import React from "react";
import { TextField } from "@material-ui/core";

const DateFilters = ({ startDate, endDate, setStartDate, setEndDate }) => {
  // Get current date-time in the same format as datetime-local expects
  const currentDateTime = new Date().toISOString().slice(0, 16);
  return (
    <div style={{ display: "flex", gap: "1rem", marginBottom: "1rem",marginTop:"1rem" }}>
      <TextField
        label="Start Date"
        type="datetime-local"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
        InputLabelProps={{ shrink: true }}
         inputProps={{ max: currentDateTime }}
      />
      <TextField
        label="End Date"
        type="datetime-local"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
        InputLabelProps={{ shrink: true }}
         inputProps={{ max: currentDateTime }}
      />
    </div>
  );
};

export default DateFilters;
