import React from "react";
import { Typography, LinearProgress, makeStyles,Tooltip } from "@material-ui/core";
import Styles from "../../ModuleStyles/ClonosDashboard/Dashboard.module.css";

function LogEntries({ data }) {

  const totalLogEntriesCount = data?.totalCount || 0;
  const onTimeEntries = data?.onTimeEntries || 0;
  const approvals = data?.approvals || 0;
  const overdue = data?.overdue || 0;

  const onTimeEntriesPercentage = (data?.onTimeEntries / totalLogEntriesCount) * 100 || 0;
  const approvalPercentage = (data?.approvals / totalLogEntriesCount) * 100 || 0;
  const overduePercentage = (data?.overdue / totalLogEntriesCount) * 100 || 0;

  const useStyles = makeStyles({
    onTime: { backgroundColor: "#34B53A" }, // Green for On-time
    approval: { backgroundColor: "#E5B82F" }, // Yellow for Approvals
    overdue: { backgroundColor: "#D24B5A" }, // Red for Overdue
    customTooltip: {
      backgroundColor: "#ffffff",
      color: "#333",
      fontSize: "13px",
      padding: "10px 14px",
      borderRadius: "8px",
      boxShadow: "0 2px 6px rgba(0, 0, 0, 0.2)",
      border: "1px solid #ccc",
    },
    arrow: {
      color: "#ffffff",
    },
  });

  const classes = useStyles();

  const progressData = [
    { label: "Total", value: totalLogEntriesCount, percentage: 100, bgColor: "#E2FBD7", tooltip: `${totalLogEntriesCount}` },
    { label: "On-time Entries", value: onTimeEntriesPercentage.toFixed(2) + "%", percentage: onTimeEntriesPercentage, bgColor: "#E2FBD7", className: classes.onTime , tooltip: `${onTimeEntries}` },
    { label: "Approvals", value: approvalPercentage.toFixed(2) + "%", percentage: approvalPercentage, bgColor: "#F7E9BF", className: classes.approval , tooltip: `${approvals}`},
    { label: "Overdue", value: overduePercentage.toFixed(2) + "%", percentage: overduePercentage, bgColor: "#F1C7CC", className: classes.overdue, tooltip: `${overdue}` },
  ];

  return (
    <div className={Styles.chartContainer}>
      <div style={{marginLeft:"10px" ,marginRight:"10px"}}>
        {progressData.map((entry, index) => (
          <div key={index} style={{ width: "100%", marginTop: index === 0 ? 0 : "10px"  }}>
            {/* Label and Value (Left and Right) */}
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "3px" }}>
              <Typography variant="body2">{entry.label}</Typography>
              <Typography variant="body2"  style={{fontWeight:"500"}}>{entry.value}</Typography>
            </div>
            <Tooltip
              title={<span>{entry.tooltip}</span>}
              arrow
              placement="top"
              classes={{ tooltip: classes.customTooltip, arrow: classes.arrow }}
            >
              <LinearProgress
                variant="determinate"
                value={entry.percentage}
                classes={entry.className ? { bar: entry.className } : {}}
                style={{
                  width: "100%",
                  backgroundColor: entry.bgColor,
                  height: "5px",
                  borderRadius: "3px",
                  cursor: "pointer",
                }}
              />
            </Tooltip>
          </div>
        ))}
      </div>
    </div>
  );
}

export default LogEntries;
