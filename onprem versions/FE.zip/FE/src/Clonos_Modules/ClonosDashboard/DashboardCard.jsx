import React from "react";
import { Card, CardContent, Typography} from "@material-ui/core";
import Styles from "../../ModuleStyles/ClonosDashboard/Dashboard.module.css"

const DashboardCard = ({ title, chart }) => (
 
  <Card className={Styles.card}>
    <CardContent className={Styles.cardContent}>
      {/* Title aligned to the left with a horizontal line below */}
      <Typography gutterBottom variant="h5" className={Styles.cardTitle}>
        {title}
      </Typography>
      <hr className={Styles.cardDivider} /> {/* Horizontal line */}
      
      <div className={Styles.chartWrapper}>
        {chart ? chart : <p>"No data available"</p>}
      </div>
    </CardContent>
    
  </Card>


);

export default DashboardCard;

