import React, { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  Grid,
  Box,
  Typography,
  Divider,
} from "@mui/material";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Label,
} from "recharts";
import { TextField } from "@material-ui/core";
import Styles from "../livedata.module.css";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import AppUrl from "../../../../utils/AppUrl";
import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

/* ---------------- Constants ---------------- */
const COLORS = ["#8884d8", "#82ca9d", "#ffc658"];




/* ---------------- Component ---------------- */

function AdditivesAndSteamData() {
const [liveData, setLiveData] = useState([]);
const [shiftWiseData, setShiftWiseData] = useState([]);
  const [date, setDate] = useState(null);

const [loading, setLoading] = useState(true);

   const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");
   
  const formatName = (text = "") => {
  return text.replace(/[_-]/g, " ").trim();
};



const fetchAdditivesData = async (selectedDate) => {
  try {
    let url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=ADDITIVES`;
    if (selectedDate) url += `&date=${selectedDate}`;

    const res = await doGetApiCall({ url });

    const result = res?.data?.result || {};

    /* ---------- LIVE DATA ---------- */
    const formattedLiveData = (result.liveData || []).map((item, index) => ({
      id: index + 1,
      label: formatName(item.name),
      value: item.averageRateOfFlow || 0,
      unit: item.unit,
      updatedAt: item.latestTimestamp,
      maxValue:item.maxValue
    }));

    /* ---------- SHIFT WISE ---------- */

const formattedShiftWise = (result.ShiftWiseAdditiveConsumption || []).map(
  (item) => {
    const shifts = {};
    let unit = "";

    item.data.forEach((d) => {
      shifts[d.shift] = d.MFMProductionEntryData?.quantity ?? 0;
      unit = d.MFMProductionEntryData?.uom || "";
    });

    return {
      name: formatName(item.additiveName),
      unit,     // ← now comes from API (t)
      shifts,
    };
  }
);



    setLiveData(formattedLiveData);
    setShiftWiseData(formattedShiftWise);
    setLoading(false);
    return true; // ✅ success
  } catch (error) {
    console.error(error);
    setLoading(false);
     return false; // ✅ failure
  }finally {
    setLoading(false);
  }
};


useEffect(() => {
  let isMounted = true;
  let timeoutId;

  const fetchLiveDataWithDelay = async () => {
    try {
      const success = await fetchAdditivesData(date);
      if (success && isMounted) {
        timeoutId = setTimeout(fetchLiveDataWithDelay, 30000); // 30 sec
      } else {
        console.warn("Stopping interval due to failed response");
      }
    } catch (err) {
      console.error("API error:", err);
    }
  };

  fetchLiveDataWithDelay(); // initial call

  return () => {
    isMounted = false;
    clearTimeout(timeoutId);
  };
}, [date]);



const AdditivesSkeleton = () => {
  return (
    <>
      {/* ================= Header ================= */}
      <Box className={Styles.livedataDashboardHeader}>
        <ClonosSkeletonLoading width="260px" height="32px" animation="wave" />
        <ClonosSkeletonLoading width="200px" height="40px" animation="wave" />
      </Box>

      {/* ================= LIVE DATA ================= */}
      <Box px={2} py={2}>
        <ClonosSkeletonLoading width="180px" height="24px" animation="wave" />

        <Grid container spacing={2} mt={1}>
          {[1, 2, 3].map((i) => (
            <Grid item xs={12} md={4} key={i}>
              <Card
                variant="outlined"
                sx={{ borderRadius: 3, boxShadow: 3 }}
              >
                <CardContent>
                  {/* Title */}
                  <ClonosSkeletonLoading
                    width="70%"
                    height="20px"
                    animation="wave"
                  />

                  {/* Divider */}
                  <Box my={1}>
                    <ClonosSkeletonLoading
                      width="100%"
                      height="2px"
                      animation="wave"
                    />
                  </Box>

                  {/* Gauge placeholder */}
                  <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    height={220}
                  >
                    <ClonosSkeletonLoading
                      width="180px"
                      height="180px"
                      animation="wave"
                    />
                  </Box>

                  {/* Value */}
                  <Box display="flex" justifyContent="center" mt={1}>
                    <ClonosSkeletonLoading
                      width="120px"
                      height="24px"
                      animation="wave"
                    />
                  </Box>

                  {/* Timestamp */}
                  <Box display="flex" justifyContent="center" mt={0.5}>
                    <ClonosSkeletonLoading
                      width="180px"
                      height="16px"
                      animation="wave"
                    />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* ================= SHIFT WISE ================= */}
      <Box px={2} py={2}>
        <ClonosSkeletonLoading width="220px" height="24px" animation="wave" />

        <Grid container spacing={2} mt={1}>
          {[1, 2, 3].map((i) => (
            <Grid item xs={12} md={4} key={i}>
              <Card
                variant="outlined"
                sx={{
                  borderRadius: 3,
                  boxShadow: 3,
                  textAlign: "center",
                  p: 2,
                  minHeight: 360,
                }}
              >
                {/* Title */}
                <ClonosSkeletonLoading
                  width="70%"
                  height="20px"
                  animation="wave"
                />

                <Box my={1}>
                  <ClonosSkeletonLoading
                    width="100%"
                    height="2px"
                    animation="wave"
                  />
                </Box>

                {/* Donut placeholder */}
                <Box
                  display="flex"
                  justifyContent="center"
                  alignItems="center"
                  height={240}
                >
                  <ClonosSkeletonLoading
                    width="160px"
                    height="160px"
                    animation="wave"
                  />
                </Box>

                {/* Legend */}
                <Box display="flex" justifyContent="center" gap={2} mt={1}>
                  {[1, 2, 3].map((l) => (
                    <ClonosSkeletonLoading
                      key={l}
                      width="60px"
                      height="16px"
                      animation="wave"
                    />
                  ))}
                </Box>

                {/* Shift values */}
                <Grid container spacing={1} mt={1}>
                  {[1, 2, 3].map((s) => (
                    <Grid item xs={4} key={s}>
                      <ClonosSkeletonLoading
                        width="60px"
                        height="16px"
                        animation="wave"
                      />
                      <ClonosSkeletonLoading
                        width="50px"
                        height="20px"
                        animation="wave"
                      />
                    </Grid>
                  ))}
                </Grid>

                {/* Total */}
                <Box mt={2} display="flex" justifyContent="center">
                  <ClonosSkeletonLoading
                    width="160px"
                    height="20px"
                    animation="wave"
                  />
                </Box>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>
    </>
  );
};

if (loading) {
  return (
    <div variant="outlined" className={Styles.livedataDashboardContainer}>
      <AdditivesSkeleton />
    </div>
  );
}

  return (
    <Card variant="outlined" className={Styles.livedataDashboardContainer}>
      {/* ================= Header ================= */}
      <Box className={Styles.livedataDashboardHeader}>
        <Typography variant="h6" className={Styles.livedataDashboardTitle}>
          Live Dashboard - Additives And  Steam
        </Typography>
         <Box className={Styles.dateFilterWrapper}>
                
        
                    <TextField
                    label="Select Date"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                    style={{ width: "200px" }}
                    inputProps={{
                      max: new Date().toISOString().split("T")[0], // ⛔ prevents future dates
                    }}
                  />
        
                </Box>
      </Box>

      {/* ================= LIVE DATA ================= */}
       <Box px={2} py={2}>
        <Typography
          variant="subtitle1"
          gutterBottom
          className={Styles.livedataDashboardTitle}
        >
          Live Data
        </Typography>
        <Grid item xs={12} md={6}>
          
             
                <div className={Styles.gaugeRow}>
            {liveData?.map((item) => {
              const gaugeSize = 220;
              const STROKE = 14;
              const CX = gaugeSize / 2;
              const CY = gaugeSize / 2 + 8;
              const R = Math.min(CX, CY) - STROKE;

              const v = Math.max(0, Math.min(item.maxValue, item.value));
              const theta = Math.PI * (1 - v / item.maxValue);

              const startX = CX - R;
              const endX = CX + R;
              const y = CY;
              const arcPath = `M ${startX} ${y} A ${R} ${R} 0 0 1 ${endX} ${y}`;

              const OUTER_R = R + STROKE / 2;
              const CLEARANCE = Math.max(3, STROKE * 0.15);
              const ix = CX + (OUTER_R + CLEARANCE) * Math.cos(theta);
              const iy = CY - (OUTER_R + CLEARANCE) * Math.sin(theta);

              const rotateDeg = (-theta * 180) / Math.PI + 180;

              const baseW = 19;
              const baseH = 17;
              const indScale = 1;

              return (
                <Card variant="outlined" sx={{ borderRadius: 3, boxShadow: 3 }}>
                  <CardContent className={Styles.cardContent}>
                    <div className={Styles.cardHeader}>
                      <Typography className={Styles.assetDashboardTitle}>{item.label}</Typography>
                      <hr className={Styles.divider} />
                    </div>

                    <div className={Styles.row}>
                      {/* Gauge */}
                      <div className={Styles.gaugeWrap}>
                        <svg
                          className={Styles.gaugeSvg}
                          width={gaugeSize}
                          height={gaugeSize}
                          viewBox={`0 0 ${gaugeSize} ${gaugeSize}`}
                          preserveAspectRatio="xMidYMid meet"
                        >
                          <defs>
                            <linearGradient
                              id={`grad-${item.id}`}
                              x1={startX}
                              y1={y}
                              x2={endX}
                              y2={y}
                              gradientUnits="userSpaceOnUse"
                            >
                              <stop offset="0%" stopColor="#F92836" />
                              <stop offset="50%" stopColor="#DAEC14" />
                              <stop offset="100%" stopColor="#239E58" />
                            </linearGradient>
                          </defs>

                          <path d={arcPath} stroke="#ddd" strokeWidth={STROKE} fill="none" strokeLinecap="round" />
                          <path d={arcPath} stroke={`url(#grad-${item.id})`} strokeWidth={STROKE} fill="none" strokeLinecap="round" />

                          <g
                            transform={`translate(${ix} ${iy}) rotate(${rotateDeg}) scale(${indScale}) translate(${-baseW / 2} ${-baseH / 2})`}
                            style={{ color: "#C5C5D8" }}
                          >
                            <path
                              d="M4.81363 15.5606L14.8286 13.1474C15.5238 12.9793 16.1199 12.5322 16.4744 11.9092L19.2767 6.97792C19.952 5.7911 19.5876 4.28581 18.4449 3.53613L13.6998 0.424687C13.1017 0.0310579 12.367 -0.0955421 11.6699 0.0725908L1.65684 2.4858C0.494333 2.7647 -0.218634 3.93174 0.0606079 5.09086L2.2054 13.9663C2.48464 15.1274 3.6531 15.8395 4.81363 15.5606Z"
                              fill="currentColor"
                            />
                          </g>
                        </svg>

                        {/* Overlay label */}
                        <div className={Styles.gaugeOverlay}>
                          <Typography variant="h6">
                            {item.value.toFixed(2)} {item.unit}
                          </Typography>
                          
                         {item.updatedAt && (
                          <Typography variant="caption" color="textSecondary" className={Styles.labelCaption}>
                            Last Updated: {formatDate(item.updatedAt)}
                          </Typography>
                        )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
        </Grid>
      </Box>

      {/* ================= SHIFT-WISE ================= */}
      
<Box px={2} py={2}>
  <Typography
    variant="subtitle1"
    gutterBottom
    className={Styles.livedataDashboardTitle}
  >
    Shift-wise Consumption
  </Typography>

  <Grid container spacing={2}>
    {shiftWiseData.map((item) => {
      const shifts = Object.entries(item.shifts);

      const pieData = shifts.map(([shift, value], index) => ({
        name: `Shift ${shift}`,
        value,
        color: COLORS[index],
      }));

      const total = shifts.reduce(
        (sum, [, v]) => sum + v,
        0
      );

      return (
        <Grid item xs={12} md={4} key={item.name}>
          <Card
            variant="outlined"
            sx={{
              borderRadius: 3,
              boxShadow: 3,
              textAlign: "center",
              p: 2,
              minHeight: 360,
            }}
          >
            {/* Title */}
            <Typography align="left" className={Styles.assetDashboardTitle}>
              {item.name}
            </Typography>
              <hr className={Styles.divider} />
            {/* Donut */}
           <ResponsiveContainer width="100%" height={240}>
              <PieChart>
               <Pie
  data={pieData}
  dataKey="value"
  cx="50%"
  cy="50%"
  innerRadius={55}
  outerRadius={75}
  labelLine
  label={({ name, percent }) =>
            `${name} ${(percent * 100).toFixed(2)}%`
          }
>
  {pieData.map((entry, i) => (
    <Cell key={i} fill={entry.color} />
  ))}
   <Label
            value="Totalizer"
            position="centerTop"
            dy={-10}
            style={{ fontSize: 14, fontWeight: 500, textAnchor: 'middle' }}
          />
          <Label
            value="%"
            position="centerBottom"
            dy={20}
            style={{ fontSize: 14, fontWeight: 500, textAnchor: 'middle' }}
          />
</Pie>

              </PieChart>
            </ResponsiveContainer>

            {/* Legend (compact, refinery style) */}
            <Box
              display="flex"
              justifyContent="center"
              gap={2}
              mt={1}
            >
              {pieData.map((entry) => (
                <Box
                  key={entry.name}
                  display="flex"
                  alignItems="center"
                  gap={0.5}
                >
                  <Box
                    sx={{
                      width: 10,
                      height: 10,
                      borderRadius: "50%",
                      backgroundColor: entry.color,
                    }}
                  />
                  <Typography variant="caption">
                    {entry.name}
                  </Typography>
                </Box>
              ))}
            </Box>

            {/* Shift values with color indicators */}
            <Grid container spacing={1} mt={1}>
              {shifts.map(([shift, value], index) => (
                <Grid item xs={4} key={shift}>
                  <Box
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    gap={0.5}
                  >
                    {/* <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: "50%",
                        backgroundColor: COLORS[index],
                      }}
                    /> */}
                    <Typography variant="caption">
                      Shift {shift}
                    </Typography>
                  </Box>
                  <Typography
                    variant="body2"
                    fontWeight={600}
                  >
                    {value.toFixed(2)}
                  </Typography>
                </Grid>
              ))}
            </Grid>

            {/* Total */}
            <Divider sx={{ my: 1.5 }} />
            <Typography
              variant="body2"
              fontWeight={700}
              color="primary"
              align="center"
            >
              Total: {total.toFixed(2)} {item.unit}
            </Typography>
          </Card>
        </Grid>
      );
    })}
  </Grid>
</Box>

    </Card>
  );
}

export default AdditivesAndSteamData;
