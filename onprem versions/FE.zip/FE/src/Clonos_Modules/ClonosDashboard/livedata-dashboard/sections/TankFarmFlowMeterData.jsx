// import React, { useEffect, useState } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";
// import DateFilters from "../../DateFilters";

// const TankFarmFlowMeterData = () => {
//   const [meters, setMeters] = useState([]);
//   const [loading, setLoading] = useState(true);

//   const fetchData = async () => {
//     try {
//       const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//       const res = await doGetApiCall({ url });
//       const data = res?.data?.result?.data || [];

//       const formatted = data.map((entry) => ({
//         group: entry.group,
//         averageFlowRate: entry.averageFlowRate,
//         flowRateCount: entry.flowRateCount,
//         totalizerValue: entry.totalizerValue,
//         totalizerTimestamp: entry.totalizerTimestamp,
//         unitOfFlowRate: entry.unitOfFlowRate,
//         unitOfToatalizer: entry.unitOfToatalizer,
//       }));

//       setMeters(formatted);
//     } catch (err) {
//       console.error("Error fetching tank farm flow meter data:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 30000);
//     return () => clearInterval(interval);
//   }, []);

//   const formatDate = (dateStr) =>
//     new Date(dateStr).toLocaleString("en-GB");

//     if (loading) return <div className={Styles.loaderWrapper}><ClonosSpinner /></div>

//   return (
//     <>
//        <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//                <div className={Styles.livedataDashboardHeader}>
//                          <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm Flow Meter</h4>
                         
//                 </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//          {/* <Typography variant="h6" gutterBottom className={Styles.livedataDashboardTitle}>
//           Live Data
//         </Typography> */}
//         <Grid container spacing={3}>
//           {meters.map((meter, index) => (
//             <Grid item xs={12} sm={6} md={4} key={index}>
//               <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//                 <CardContent>
//                   <Typography variant="h6" align="center" className={Styles.livedataDashboardTitle}>{meter.group}</Typography>
//                   <Typography variant="h6" color="primary">
//                      <strong className={Styles.dataLabelStyle}>FLOW RATE:</strong>{" "}
//                       {meter.averageFlowRate?.toFixed(2) ?? "-"} {meter.unitOfFlowRate}
//                   </Typography>
//                   <Typography variant="h6" color="primary">
//                     <strong className={Styles.dataLabelStyle}>TOTALIZER:</strong>{" "}
//                      {meter.totalizerValue?.toFixed(2) ?? "-"} {meter.unitOfToatalizer}
//                   </Typography>
//                   <Typography variant="body2" mt={1}>
//                     Updated on: {formatDate(meter.totalizerTimestamp)}
//                   </Typography>
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//      </Card>
//     </>
//   );
// };

// export default TankFarmFlowMeterData;


// import React, { useEffect, useState, useRef } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";

// const TankFarmFlowMeterData = () => {
//   const [meters, setMeters] = useState([]);
//   const [loading, setLoading] = useState(true); // loader only for first fetch
//   const isFirstLoad = useRef(true);

//   const fetchData = async () => {
//     try {
//       if (isFirstLoad.current) setLoading(true); // loader only first time

//       const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//       const res = await doGetApiCall({ url });
//       const data = res?.data?.result?.data || [];

//       const formatted = data.map((entry) => ({
//         group: entry.group,
//         averageFlowRate: entry.averageFlowRate,
//         flowRateCount: entry.flowRateCount,
//         totalizerValue: entry.totalizerValue,
//         totalizerTimestamp: entry.totalizerTimestamp,
//         unitOfFlowRate: entry.unitOfFlowRate,
//         unitOfToatalizer: entry.unitOfToatalizer,
//       }));

//       setMeters(formatted);
//     } catch (err) {
//       console.error("Error fetching tank farm flow meter data:", err);
//     } finally {
//       setLoading(false);
//       isFirstLoad.current = false; // next time, no loader
//     }
//   };

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 30000);
//     return () => clearInterval(interval);
//   }, []);

//   const formatDate = (dateStr) =>
//     new Date(dateStr).toLocaleString("en-GB");

//   if (loading)
//     return (
//       <div className={Styles.loaderWrapper}>
//         <ClonosSpinner />
//       </div>
//     );

//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm Flow Meter
//         </h4>
//       </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {meters.map((meter, index) => (
//             <Grid item xs={12} sm={6} md={4} key={index}>
//               <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//                 <CardContent>
//                   <Typography
//                     variant="h6"
//                     align="center"
//                     className={Styles.livedataDashboardTitle}
//                   >
//                     {meter.group}
//                   </Typography>
//                   <Typography variant="h6" color="primary">
//                     <strong className={Styles.dataLabelStyle}>FLOW RATE:</strong>{" "}
//                     {meter.averageFlowRate?.toFixed(2) ?? "-"} {meter.unitOfFlowRate}
//                   </Typography>
//                   <Typography variant="h6" color="primary">
//                     <strong className={Styles.dataLabelStyle}>TOTALIZER:</strong>{" "}
//                     {meter.totalizerValue?.toFixed(2) ?? "-"} {meter.unitOfToatalizer}
//                   </Typography>
//                   <Typography variant="body2" mt={1}>
//                     Updated on: {formatDate(meter.totalizerTimestamp)}
//                   </Typography>
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//     </Card>
//   );
// };

// export default TankFarmFlowMeterData;


// import React, { useEffect, useState, useRef } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import { Speed, TrendingUp } from "@mui/icons-material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";

// const TankFarmFlowMeterData = () => {
//   const [meters, setMeters] = useState([]);
//   const [loading, setLoading] = useState(true); // loader only for first fetch
//   const isFirstLoad = useRef(true);

//   // store previous numeric values keyed by group (or fallback key)
//   const prevValuesRef = useRef({});
//   // keep timers to clear on unmount
//   const clearTimersRef = useRef([]);

//   const fetchData = async () => {
//     try {
//       if (isFirstLoad.current) setLoading(true);

//       const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//       const res = await doGetApiCall({ url });
//       const data = res?.data?.result?.data || [];

//       // Normalize incoming data
//       const formatted = data.map((entry, idx) => ({
//         key: entry.group ?? `meter-${idx}`,
//         group: entry.group,
//         averageFlowRate: typeof entry.averageFlowRate === "number" ? entry.averageFlowRate : Number(entry.averageFlowRate || NaN),
//         flowRateCount: entry.flowRateCount,
//         totalizerValue: typeof entry.totalizerValue === "number" ? entry.totalizerValue : Number(entry.totalizerValue || NaN),
//         totalizerTimestamp: entry.totalizerTimestamp,
//         unitOfFlowRate: entry.unitOfFlowRate,
//         unitOfToatalizer: entry.unitOfToatalizer,
//       }));

//       // Build new meters with change flags
//       const newMeters = formatted.map((m) => {
//         const prev = prevValuesRef.current[m.key];
//         const isFlowUp = prev && Number.isFinite(prev.averageFlowRate) && Number.isFinite(m.averageFlowRate) && m.averageFlowRate > prev.averageFlowRate;
//         const isFlowDown = prev && Number.isFinite(prev.averageFlowRate) && Number.isFinite(m.averageFlowRate) && m.averageFlowRate < prev.averageFlowRate;
//         const isTotalizerUp = prev && Number.isFinite(prev.totalizerValue) && Number.isFinite(m.totalizerValue) && m.totalizerValue > prev.totalizerValue;
//         const isTotalizerDown = prev && Number.isFinite(prev.totalizerValue) && Number.isFinite(m.totalizerValue) && m.totalizerValue < prev.totalizerValue;

//         return {
//           ...m,
//           isFlowUp,
//           isFlowDown,
//           isTotalizerUp,
//           isTotalizerDown,
//         };
//       });

//       // Update previous-values store for next comparison
//       formatted.forEach((m) => {
//         prevValuesRef.current[m.key] = {
//           averageFlowRate: m.averageFlowRate,
//           totalizerValue: m.totalizerValue,
//         };
//       });

//       setMeters(newMeters);

//       // Remove transient change flags after 1.2s so animation can replay next update
//       const t = setTimeout(() => {
//         setMeters((cur) =>
//           cur.map((it) => ({
//             ...it,
//             isFlowUp: false,
//             isFlowDown: false,
//             isTotalizerUp: false,
//             isTotalizerDown: false,
//           }))
//         );
//       }, 1200);
//       clearTimersRef.current.push(t);
//     } catch (err) {
//       console.error("Error fetching tank farm flow meter data:", err);
//     } finally {
//       setLoading(false);
//       isFirstLoad.current = false;
//     }
//   };

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 30000);
//     return () => {
//       clearInterval(interval);
//       // clear any pending timeouts
//       clearTimersRef.current.forEach((tt) => clearTimeout(tt));
//       clearTimersRef.current = [];
//     };
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const formatDate = (dateStr) => {
//     if (!dateStr) return "-";
//     const d = new Date(dateStr);
//     if (isNaN(d)) return dateStr;
//     return d.toLocaleString("en-GB");
//   };

//   if (loading)
//     return (
//       <div className={Styles.loaderWrapper}>
//         <ClonosSpinner />
//       </div>
//     );

//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm Flow Meter
//         </h4>
//       </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {meters.map((meter) => (
//             <Grid item xs={12} sm={6} md={4} key={meter.key}>
//               <Card
//                 className={Styles.meterCard}
//                 sx={{
//                   borderRadius: 3,
//                   boxShadow: 3,
//                   transition: "transform 0.25s, box-shadow 0.25s",
//                   "&:hover": { transform: "translateY(-6px)", boxShadow: 6 },
//                 }}
//               >
//                 <CardContent>
//                   <Typography
//                     variant="h6"
//                     align="center"
//                     className={Styles.meterHeader}
//                     sx={{ mb: 1 }}
//                   >
//                     {meter.group}
//                   </Typography>

//                   <div className={Styles.metricRow}>
//                     <Speed fontSize="small" className={Styles.metricIcon} />
//                     <Typography
//                       variant="h6"
//                       color="primary"
//                       className={`${Styles.metricValue} ${
//                         meter.isFlowUp ? Styles.valueUp : meter.isFlowDown ? Styles.valueDown : ""
//                       }`}
//                     >
//                       <strong className={Styles.dataLabelStyle}>FLOW RATE:</strong>{" "}
//                       {Number.isFinite(meter.averageFlowRate) ? meter.averageFlowRate.toFixed(2) : "-"}{" "}
//                       {meter.unitOfFlowRate ?? ""}
//                     </Typography>
//                   </div>

//                   <div className={Styles.metricRow}>
//                     <TrendingUp fontSize="small" className={Styles.metricIcon} />
//                     <Typography
//                       variant="h6"
//                       color="primary"
//                       className={`${Styles.metricValue} ${
//                         meter.isTotalizerUp ? Styles.valueUp : meter.isTotalizerDown ? Styles.valueDown : ""
//                       }`}
//                     >
//                       <strong className={Styles.dataLabelStyle}>TOTALIZER:</strong>{" "}
//                       {Number.isFinite(meter.totalizerValue) ? meter.totalizerValue.toFixed(2) : "-"}{" "}
//                       {meter.unitOfToatalizer ?? ""}
//                     </Typography>
//                   </div>

//                   <Typography variant="body2" mt={1} sx={{ color: "text.secondary" }}>
//                     Updated on: {formatDate(meter.totalizerTimestamp)}
//                   </Typography>
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//     </Card>
//   );
// };

// export default TankFarmFlowMeterData;




//working code

// import React, { useEffect, useState, useRef } from "react";
// import { Card, CardContent, Grid, Typography, Box, Divider } from "@mui/material";
// import { Speed, Timeline } from "@mui/icons-material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";

// const TankFarmFlowMeterData = () => {
//   const [meters, setMeters] = useState([]);
//   const [loading, setLoading] = useState(true);

//   // const fetchData = async () => {
//   //   try {
//   //     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//   //     const res = await doGetApiCall({ url });
//   //     const data = res?.data?.result?.data || [];

//   //     const formatted = data.map((entry) => ({
//   //       group: entry.group,
//   //       averageFlowRate: entry.averageFlowRate,
//   //       flowRateCount: entry.flowRateCount,
//   //       totalizerValue: entry.totalizerValue,
//   //       totalizerTimestamp: entry.totalizerTimestamp,
//   //       unitOfFlowRate: entry.unitOfFlowRate,
//   //       unitOfToatalizer: entry.unitOfToatalizer,
//   //     }));

//   //     setMeters(formatted);
//   //   } catch (err) {
//   //     console.error("Error fetching tank farm flow meter data:", err);
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };

//   // useEffect(() => {
//   //   fetchData();
//   //   const interval = setInterval(fetchData, 30000);
//   //   return () => clearInterval(interval);
//   // }, []);


//  const fetchData = async () => {
//   try {
//     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//     const res = await doGetApiCall({ url });
//     const data = res?.data?.result?.data || [];

//     const formatted = data.map((entry) => ({
//       group: entry.group,
//       averageFlowRate: entry.averageFlowRate,
//       flowRateCount: entry.flowRateCount,
//       totalizerValue: entry.totalizerValue,
//       totalizerTimestamp: entry.totalizerTimestamp,
//       unitOfFlowRate: entry.unitOfFlowRate,
//       unitOfToatalizer: entry.unitOfToatalizer,
//     }));

//     setMeters(formatted);
//     return true; // ✅ return true on success
//   } catch (err) {
//     console.error("Error fetching tank farm flow meter data:", err);
//     return false; // ✅ return false on error
//   } finally {
//     setLoading(false);
//   }
// };

// useEffect(() => {
//   let isMounted = true;
//   let timeoutId;

//   const fetchDataWithDelay = async () => {
//     try {
//       const success = await fetchData(); 
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchDataWithDelay, 30000); // 30 sec
//       } else {
//         console.warn("Stopping interval due to failed response");
//       }
//     } catch (error) {
//       console.error("API error:", error);
//     }
//   };

//   fetchDataWithDelay(); // initial call

//   return () => {
//     isMounted = false;
//     clearTimeout(timeoutId);
//   };
// }, []);


//   const formatDate = (dateStr) => {
//     if (!dateStr) return "-";
//     return new Date(dateStr).toLocaleString("en-GB");
//   };

//   if (loading) {
//     return (
//       <div className={Styles.loaderWrapper}>
//         <ClonosSpinner />
//       </div>
//     );
//   }

//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm Flow Meter
//         </h4>
//       </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {meters.map((meter) => (
//             <Grid item xs={12} sm={6} md={4} key={meter.id}>
//               <Card
//                 sx={{
//                   borderRadius: 3,
//                   boxShadow: 4,
//                   display: "flex",
//                   flexDirection: "column",
//                   height: "100%",
//                 }}
//               >
//                 {/* Card Header */}
//                 <Box
//                   sx={{
//                     background: "linear-gradient(90deg, #2C4E87 0%, #6885B1 100%)",
//                     color: "white",
//                     textAlign: "center",
//                     py: 1,
//                     borderTopLeftRadius: 12,
//                     borderTopRightRadius: 12,
//                   }}
//                 >
//                   <Typography variant="subtitle1" fontWeight="bold">
//                     {meter.group}
//                   </Typography>
//                 </Box>

//                 {/* Card Content */}
//                 <CardContent sx={{ flexGrow: 1 }}>
//                   <Box display="flex" alignItems="center" mb={2}>
//                     <Speed sx={{ mr: 1, color: "primary.main" }} />
//                     <Box>
//                       <Typography variant="body2" color="textSecondary">
//                         FLOW RATE
//                       </Typography>
//                       <Typography variant="h6" fontWeight="bold">
//                         {meter.averageFlowRate?.toFixed(2) ?? "-"}{" "}
//                         <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                           {meter.unitOfFlowRate}
//                         </span>
//                       </Typography>
//                     </Box>
//                   </Box>

//                   <Divider />

//                   <Box display="flex" alignItems="center" mt={2}>
//                     <Timeline sx={{ mr: 1, color: "success.main" }} />
//                     <Box>
//                       <Typography variant="body2" color="textSecondary">
//                         TOTALIZER
//                       </Typography>
//                       <Typography variant="h6" fontWeight="bold">
//                         {meter.totalizerValue?.toFixed(2) ?? "-"}{" "}
//                         <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                           {meter.unitOfToatalizer}
//                         </span>
//                       </Typography>
//                     </Box>
//                   </Box>
//                 </CardContent>

//                 {/* Footer */}
//                 <Box
//                   sx={{
//                     textAlign: "center",
//                     backgroundColor: "#f9f9f9",
//                     py: 1,
//                     borderTop: "1px solid #eee",
//                   }}
//                 >
//                   <Typography variant="caption" color="textSecondary">
//                     Updated on: {formatDate(meter.totalizerTimestamp)}
//                   </Typography>
//                 </Box>
//               </Card>
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//     </Card>
//   );
// };

// export default TankFarmFlowMeterData;

//last work code

// import React, { useEffect, useState } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";
// import DateFilters from "../../DateFilters";
// import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

// const TankFarmFlowMeterData = () => {
//   const [meters, setMeters] = useState([]);
//   const [loading, setLoading] = useState(true);

//   // const fetchData = async () => {
//   //   try {
//   //     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//   //     const res = await doGetApiCall({ url });
//   //     const data = res?.data?.result?.data || [];

//   //     const formatted = data.map((entry) => ({
//   //       group: entry.group,
//   //       averageFlowRate: entry.averageFlowRate,
//   //       flowRateCount: entry.flowRateCount,
//   //       totalizerValue: entry.totalizerValue,
//   //       totalizerTimestamp: entry.totalizerTimestamp,
//   //       unitOfFlowRate: entry.unitOfFlowRate,
//   //       unitOfToatalizer: entry.unitOfToatalizer,
//   //     }));

//   //     setMeters(formatted);
//   //   } catch (err) {
//   //     console.error("Error fetching tank farm flow meter data:", err);
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };

//   // useEffect(() => {
//   //   fetchData();
//   //   const interval = setInterval(fetchData, 30000);
//   //   return () => clearInterval(interval);
//   // }, []);


//  const fetchData = async () => {
//   try {
//     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//     const res = await doGetApiCall({ url });
//     const data = res?.data?.result?.data || [];

//     const formatted = data.map((entry) => ({
//       group: entry.group,
//       averageFlowRate: entry.averageFlowRate,
//       flowRateCount: entry.flowRateCount,
//       totalizerValue: entry.totalizerValue,
//       totalizerTimestamp: entry.totalizerTimestamp,
//       unitOfFlowRate: entry.unitOfFlowRate,
//       unitOfToatalizer: entry.unitOfToatalizer,
//     }));

//     setMeters(formatted);
//     return true; // ✅ return true on success
//   } catch (err) {
//     console.error("Error fetching tank farm flow meter data:", err);
//     return false; // ✅ return false on error
//   } finally {
//     setLoading(false);
//   }
// };

// useEffect(() => {
//   let isMounted = true;
//   let timeoutId;

//   const fetchDataWithDelay = async () => {
//     try {
//       const success = await fetchData(); 
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchDataWithDelay, 30000); // 30 sec
//       } else {
//         console.warn("Stopping interval due to failed response");
//       }
//     } catch (error) {
//       console.error("API error:", error);
//     }
//   };

//   fetchDataWithDelay(); // initial call

//   return () => {
//     isMounted = false;
//     clearTimeout(timeoutId);
//   };
// }, []);


//   const formatDate = (dateStr) =>
//     new Date(dateStr).toLocaleString("en-GB");

//   const TankFarmFlowMeterCardSkeleton = () => {
//   return (
//     <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//       <CardContent>
//         {/* Group Name */}
//         <ClonosSkeletonLoading width="60%" height="26px" animation="wave" />

//         {/* Flow Rate */}
//         <ClonosSkeletonLoading
//           width="80%"
//           height="22px"
//           animation="wave"
//           style={{ marginTop: "12px" }}
//         />

//         {/* Totalizer */}
//         <ClonosSkeletonLoading
//           width="80%"
//           height="22px"
//           animation="wave"
//           style={{ marginTop: "8px" }}
//         />

//         {/* Updated Timestamp */}
//         <ClonosSkeletonLoading
//           width="50%"
//           height="18px"
//           animation="wave"
//           style={{ marginTop: "10px" }}
//         />
//       </CardContent>
//     </Card>
//   );
// };

// if (loading) {
//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm Flow Meter
//         </h4>
//       </div>

//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {[1, 2, 3, 4, 5, 6].map((i) => (
//             <Grid item xs={12} sm={6} md={4} key={i}>
//               <TankFarmFlowMeterCardSkeleton />
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//     </Card>
//   );
// }


//     // if (loading) return <div className={Styles.loaderWrapper}><ClonosSpinner /></div>

//   return (
//     <>
//        <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//                <div className={Styles.livedataDashboardHeader}>
//                          <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm Flow Meter</h4>
                         
//                 </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//          {/* <Typography variant="h6" gutterBottom className={Styles.livedataDashboardTitle}>
//           Live Data
//         </Typography> */}
//         <Grid container spacing={3}>
//           {meters.map((meter, index) => (
//             <Grid item xs={12} sm={6} md={4} key={index}>
//               <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//                 <CardContent>
//                   <Typography variant="h6" align="center" className={Styles.livedataDashboardTitle}>{meter.group}</Typography>
//                   <Typography variant="h6" color="primary">
//                      <strong className={Styles.dataLabelStyle}>FLOW RATE:</strong>{" "}
//                       {meter.averageFlowRate?.toFixed(2) ?? "-"} {meter.unitOfFlowRate}
//                   </Typography>
//                   <Typography variant="h6" color="primary">
//                     <strong className={Styles.dataLabelStyle}>TOTALIZER:</strong>{" "}
//                      {meter.totalizerValue?.toFixed(2) ?? "-"} {meter.unitOfToatalizer}
//                   </Typography>
//                   <Typography variant="body2" mt={1}>
//                     Updated on: {formatDate(meter.totalizerTimestamp)}
//                   </Typography>
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//      </Card>
//     </>
//   );
// };

// export default TankFarmFlowMeterData;



// import React, { useEffect, useState } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";
// import DateFilters from "../../DateFilters";
// import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

// const TankFarmFlowMeterData = () => {
//   const [meters, setMeters] = useState([]);
//   const [loading, setLoading] = useState(true);

  

//  const fetchData = async () => {
//   try {
//     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//     const res = await doGetApiCall({ url });
//     const data = res?.data?.result?.data || [];
//       console.log(data,"data")
//     const formatted = data.map((entry) => ({
//       group: entry.group,
//       averageFlowRate: entry.averageFlowRate,
//       flowRateCount: entry.flowRateCount,
//       totalizerValue: entry.totalizerValue,
//       totalizerTimestamp: entry.totalizerTimestamp,
//       unitOfFlowRate: entry.unitOfFlowRate,
//       unitOfToatalizer: entry.unitOfToatalizer,
//     }));

//     setMeters(formatted);

//     console.log(meters,"meters")
//     return true; // ✅ return true on success
//   } catch (err) {
//     console.error("Error fetching tank farm flow meter data:", err);
//     return false; // ✅ return false on error
//   } finally {
//     setLoading(false);
//   }
// };

// useEffect(() => {
//   let isMounted = true;
//   let timeoutId;

//   const fetchDataWithDelay = async () => {
//     try {
//       const success = await fetchData(); 
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchDataWithDelay, 30000); // 30 sec
//       } else {
//         console.warn("Stopping interval due to failed response");
//       }
//     } catch (error) {
//       console.error("API error:", error);
//     }
//   };

//   fetchDataWithDelay(); // initial call

//   return () => {
//     isMounted = false;
//     clearTimeout(timeoutId);
//   };
// }, []);


//   const formatDate = (dateStr) =>
//     new Date(dateStr).toLocaleString("en-GB");

//   const TankFarmFlowMeterCardSkeleton = () => {
//   return (
//     <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//       <CardContent>
//         {/* Group Name */}
//         <ClonosSkeletonLoading width="60%" height="26px" animation="wave" />

//         {/* Flow Rate */}
//         <ClonosSkeletonLoading
//           width="80%"
//           height="22px"
//           animation="wave"
//           style={{ marginTop: "12px" }}
//         />

//         {/* Totalizer */}
//         <ClonosSkeletonLoading
//           width="80%"
//           height="22px"
//           animation="wave"
//           style={{ marginTop: "8px" }}
//         />

//         {/* Updated Timestamp */}
//         <ClonosSkeletonLoading
//           width="50%"
//           height="18px"
//           animation="wave"
//           style={{ marginTop: "10px" }}
//         />
//       </CardContent>
//     </Card>
//   );
// };

// if (loading) {
//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm Flow Meter
//         </h4>
//       </div>

//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {[1, 2, 3, 4, 5, 6].map((i) => (
//             <Grid item xs={12} sm={6} md={4} key={i}>
//               <TankFarmFlowMeterCardSkeleton />
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//     </Card>
//   );
// }


//     // if (loading) return <div className={Styles.loaderWrapper}><ClonosSpinner /></div>

//   return (
//     <>
//        <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//                <div className={Styles.livedataDashboardHeader}>
//                          <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm Flow Meter</h4>
                         
//                 </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//          {/* <Typography variant="h6" gutterBottom className={Styles.livedataDashboardTitle}>
//           Live Data
//         </Typography> */}
//         <Grid container spacing={3}>
//           {meters.map((meter, index) => (
//             <Grid item xs={12} sm={6} md={4} key={index}>
//               <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//                 <CardContent>
//                   <Typography variant="h6" align="center" className={Styles.livedataDashboardTitle}>{meter.group}</Typography>
//                   <Typography variant="h6" color="primary">
//                      <strong className={Styles.dataLabelStyle}>FLOW RATE:</strong>{" "}
//                       {meter.averageFlowRate?.toFixed(2) ?? "-"} {meter.unitOfFlowRate}
//                   </Typography>
//                   <Typography variant="h6" color="primary">
//                     <strong className={Styles.dataLabelStyle}>TOTALIZER:</strong>{" "}
//                      {meter.totalizerValue?.toFixed(2) ?? "-"} {meter.unitOfToatalizer}
//                   </Typography>
//                   <Typography variant="body2" mt={1}>
//                     Updated on: {formatDate(meter.totalizerTimestamp)}
//                   </Typography>
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//      </Card>
//     </>
//   );
// };

// export default TankFarmFlowMeterData;



// import React, { useEffect, useState } from "react";
// import Styles from "../livedata.module.css";
// import AppUrl from "../../../../utils/AppUrl";
// import { Container, Card, CardContent, Typography,Grid,Box } from "@mui/material";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

// function TankFarmFlowMeterData() {
//   const [meters, setMeters] = useState([]);
//   const [loading, setLoading] = useState(true);

//   const fetchData = async () => {
//     try {
//       const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
//       const res = await doGetApiCall({ url });

//       const data = res?.data?.result?.data || [];
//       console.log("flowmeter", data);

//       const formatted = data.map((m) => ({
//         group: m.group,
//         averageFlowRate: m.averageFlowRate ?? 0,
//         totalizerValue: m.totalizerValue ?? 0,
//         unitOfFlowRate: m.unitOfFlowRate ?? "",
//         unitOfTotalizer: m.unitOfToatalizer ?? "",
//         timestamp: m.totalizerTimestamp,
//       }));

//       setMeters(formatted);
//       return true;

//     } catch (err) {
//       console.error("Flowmeter error:", err);
//       return false;
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     let isMounted = true;
//     let timeoutId;

//     const fetchDataWithDelay = async () => {
//       const success = await fetchData();
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchDataWithDelay, 30000);
//       }
//     };

//     fetchDataWithDelay();
//     return () => {
//       isMounted = false;
//       clearTimeout(timeoutId);
//     };
//   }, []);

//   const formatDate = (d) => new Date(d).toLocaleString("en-GB");

//   // Convert into gauge card structure (same as tank farm)
//   const flowmeterGaugeData = meters.flatMap((meter, index) => [
//     {
//       id: `${index}-flowrate`,
//       title: "Flowrate",
//       subtitle: meter.group,
//       value: meter.averageFlowRate,
//       subLabel: meter.unitOfFlowRate,
//       timestamp: meter.timestamp,
//     },
//     {
//       id: `${index}-totalizer`,
//       title: "Totalizer",
//       subtitle: meter.group,
//       value: meter.totalizerValue,
//       subLabel: meter.unitOfTotalizer,
//       timestamp: meter.timestamp,
//     },
//   ]);


//  if (loading) {
//     return (
//       <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//         <div className={Styles.livedataDashboardHeader} style={{ padding: '16px' }}>
//           <ClonosSkeletonLoading width="50%" height="32px" animation="wave" />
//         </div>
//         <Container className={Styles.section}>
//           <Grid container spacing={2}>
//             {[...Array(6)].map((_, i) => (
//               <Grid item xs={12} sm={6} md={4} key={i}>
//                 <Card variant="outlined" sx={{ padding: 2 }}>
//                   <ClonosSkeletonLoading width="100%" height="220px" animation="wave" />
//                   <Box mt={1}>
//                     <ClonosSkeletonLoading width="60%" height="20px" animation="wave" />
//                   </Box>
//                   <Box mt={1}>
//                     <ClonosSkeletonLoading width="40%" height="16px" animation="wave" />
//                   </Box>
//                 </Card>
//               </Grid>
//             ))}
//           </Grid>
//         </Container>
//       </Card>
//     );
//   }

//   return (
//     <div className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - TankFarm Flow Meter</h4>
//       </div>

//       <div className={Styles.section}>
//         <div className={Styles.gaugeRow}>
//           {flowmeterGaugeData.map((item) => {
//             const gaugeSize = 220;
//               const STROKE = 14;
//               const CX = gaugeSize / 2;
//               const CY = gaugeSize / 2 + 8;
//               const R = Math.min(CX, CY) - STROKE;

//               const v = Math.max(0, Math.min(100, item.value));
//               const theta = Math.PI * (1 - v / 100);

//               const startX = CX - R;
//               const endX = CX + R;
//               const y = CY;
//               const arcPath = `M ${startX} ${y} A ${R} ${R} 0 0 1 ${endX} ${y}`;

//               const OUTER_R = R + STROKE / 2;
//               const CLEARANCE = Math.max(3, STROKE * 0.15);
//               const ix = CX + (OUTER_R + CLEARANCE) * Math.cos(theta);
//               const iy = CY - (OUTER_R + CLEARANCE) * Math.sin(theta);

//               const rotateDeg = (-theta * 180) / Math.PI + 180;

//               const baseW = 19;
//               const baseH = 17;
//               const indScale = 1;

//             return (
//               <Card key={item.id} variant="outlined" sx={{ borderRadius: 3, boxShadow: 3 }}>
//                 <CardContent className={Styles.cardContent}>
//                   <div className={Styles.cardHeader}>
//                     <Typography className={Styles.assetDashboardTitle}>
//                       {item.title}
//                     </Typography>
//                     <Typography style={{ fontSize: "12px", fontWeight: 600 ,color:"#333"}}>
//                       {item.subtitle}
//                     </Typography>
//                     <hr className={Styles.divider} />
//                   </div>

//                   <div className={Styles.row}>
//                     <div className={Styles.gaugeWrap}>
//                       <svg
//                         className={Styles.gaugeSvg}
//                         width={gaugeSize}
//                         height={gaugeSize}
//                         viewBox={`0 0 ${gaugeSize} ${gaugeSize}`}
//                         preserveAspectRatio="xMidYMid meet"
//                       >

//                         <defs>
//                           <linearGradient
//                             id={`grad-${item.id}`}
//                             x1={startX}
//                             y1={y}
//                             x2={endX}
//                             y2={y}
//                             gradientUnits="userSpaceOnUse"
//                           >
//                             <stop offset="0%" stopColor="#F92836" />
//                             <stop offset="50%" stopColor="#DAEC14" />
//                             <stop offset="100%" stopColor="#239E58" />
//                           </linearGradient>
//                         </defs>

//                           <path d={arcPath} stroke="#ddd" strokeWidth={STROKE} fill="none" strokeLinecap="round" />
//                           <path d={arcPath} stroke={`url(#grad-${item.id})`} strokeWidth={STROKE} fill="none" strokeLinecap="round" />


//                         <g
//                             transform={`translate(${ix} ${iy}) rotate(${rotateDeg}) scale(${indScale}) translate(${-baseW / 2} ${-baseH / 2})`}
//                             style={{ color: "#C5C5D8" }}
//                           >
//                            <path
//                               d="M4.81363 15.5606L14.8286 13.1474C15.5238 12.9793 16.1199 12.5322 16.4744 11.9092L19.2767 6.97792C19.952 5.7911 19.5876 4.28581 18.4449 3.53613L13.6998 0.424687C13.1017 0.0310579 12.367 -0.0955421 11.6699 0.0725908L1.65684 2.4858C0.494333 2.7647 -0.218634 3.93174 0.0606079 5.09086L2.2054 13.9663C2.48464 15.1274 3.6531 15.8395 4.81363 15.5606Z"
//                               fill="currentColor"
//                             />
//                         </g>
//                       </svg>

//                       <div className={Styles.gaugeOverlay}>
//                         <Typography variant="h6">
//                           {item.value?.toFixed(2)} {item.subLabel}
//                         </Typography>

//                         {item.timestamp && (
//                           <Typography variant="caption" color="textSecondary" className={Styles.labelCaption}>
//                             Last Updated: {formatDate(item.timestamp)}
//                           </Typography>
//                         )}
//                       </div>
//                     </div>
//                   </div>
//                 </CardContent>
//               </Card>
//             );
//           })}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default TankFarmFlowMeterData;


import React, { useEffect, useState } from "react";
import Styles from "../livedata.module.css";
import AppUrl from "../../../../utils/AppUrl";
import { Container, Card, CardContent, Typography, Grid, Box } from "@mui/material";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

import { PieChart, Pie, Label } from "recharts";

function TankFarmFlowMeterData() {
  const [meters, setMeters] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;
      const res = await doGetApiCall({ url });

      const data = res?.data?.result?.data || [];

      const formatted = data.map((m) => ({
        group: m.group,
        flowrate: m.averageFlowRate ?? 0,
        totalizer: m.totalizerValue ?? 0,
        flowrateUnit: m.unitOfFlowRate ?? "",
        totalizerUnit: m.unitOfToatalizer ?? "",
        timestamp: m.totalizerTimestamp,
        maxValue:m.maxValue
      }));

      setMeters(formatted);
      return true;

    } catch (err) {
      console.error("Flowmeter error:", err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    let timeoutId;

    const fetchDataWithDelay = async () => {
      const success = await fetchData();
      if (success && isMounted) {
        timeoutId = setTimeout(fetchDataWithDelay, 30000);
      }
    };

    fetchDataWithDelay();
    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, []);

  const formatDate = (d) => new Date(d).toLocaleString("en-GB");

  if (loading) {
    return (
      <Card variant="outlined" className={Styles.livedataDashboardContainer}>
        <div className={Styles.livedataDashboardHeader} style={{ padding: "16px" }}>
          <ClonosSkeletonLoading width="50%" height="32px" animation="wave" />
        </div>
        <Container className={Styles.section}>
          <Grid container spacing={2}>
            {[...Array(6)].map((_, i) => (
              <Grid item xs={12} sm={6} md={4} key={i}>
                <Card variant="outlined" sx={{ padding: 2 }}>
                  <ClonosSkeletonLoading width="100%" height="220px" animation="wave" />
                  <Box mt={1}>
                    <ClonosSkeletonLoading width="60%" height="20px" animation="wave" />
                  </Box>
                  <Box mt={1}>
                    <ClonosSkeletonLoading width="40%" height="16px" animation="wave" />
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Card>
    );
  }

  return (
    <div className={Styles.livedataDashboardContainer}>
      <div className={Styles.livedataDashboardHeader}>
        <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - TankFarm Flow Meter</h4>
      </div>

      <div className={Styles.section}>
        <Grid container spacing={3}>
          {meters.map((item, index) => {
            const gaugeSize = 180;
            const STROKE = 14;
            const CX = gaugeSize / 2;
            const CY = gaugeSize / 2 + 8;
            const R = Math.min(CX, CY) - STROKE;

            const v = Math.max(0, Math.min(item.maxValue, item.flowrate));
            const theta = Math.PI * (1 - v / item.maxValue);

            const startX = CX - R;
            const endX = CX + R;
            const y = CY;
            const arcPath = `M ${startX} ${y} A ${R} ${R} 0 0 1 ${endX} ${y}`;

            const OUTER_R = R + STROKE / 2;
            const CLEARANCE = Math.max(3, STROKE * 0.15);
            const ix = CX + (OUTER_R + CLEARANCE) * Math.cos(theta);
            const iy = CY - (OUTER_R + CLEARANCE) * Math.sin(theta);

            const rotateDeg = (-theta * 180) / Math.PI + 180;
            const baseW = 19;
            const baseH = 17;
            const indScale = 1;

            return (
              <Grid item xs={12} md={6} key={index}>
                <Card variant="outlined" sx={{ borderRadius: 3, boxShadow: 3 }}>
                  <CardContent>
                    {/* Card Header */}
                    <Typography sx={{ fontWeight: 700, fontSize: 16, mb: 1 }}>
                      {item.group}
                    </Typography>
                    <hr className={Styles.divider} />

                    {/* Row: Gauge + Pie */}
                    <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 2 }}>
                      {/* FLOWRATE GAUGE */}
                      <Box sx={{ flex: 1, position: "relative", textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center" }}>
                        <svg width={gaugeSize} height={gaugeSize * 0.65} viewBox={`0 0 ${gaugeSize} ${gaugeSize * 0.65}`} style={{ overflow: "visible" }}>
                          <defs>
                            <linearGradient id={`grad-${index}`} x1={startX} y1={y} x2={endX} y2={y} gradientUnits="userSpaceOnUse">
                              <stop offset="0%" stopColor="#F92836" />
                              <stop offset="50%" stopColor="#DAEC14" />
                              <stop offset="100%" stopColor="#239E58" />
                            </linearGradient>
                          </defs>

                          <path d={arcPath} stroke="#ddd" strokeWidth={STROKE} fill="none" strokeLinecap="round" />
                          <path d={arcPath} stroke={`url(#grad-${index})`} strokeWidth={STROKE} fill="none" strokeLinecap="round" />

                          <g
                            transform={`translate(${ix} ${iy}) rotate(${rotateDeg}) scale(${indScale}) translate(${-baseW / 2} ${-baseH / 2})`}
                            style={{ color: "#C5C5D8" }}
                          >
                            <path
                              d="M4.81363 15.5606L14.8286 13.1474C15.5238 12.9793 16.1199 12.5322 16.4744 11.9092L19.2767 6.97792C19.952 5.7911 19.5876 4.28581 18.4449 3.53613L13.6998 0.424687C13.1017 0.0310579 12.367 -0.0955421 11.6699 0.0725908L1.65684 2.4858C0.494333 2.7647 -0.218634 3.93174 0.0606079 5.09086L2.2054 13.9663C2.48464 15.1274 3.6531 15.8395 4.81363 15.5606Z"
                              fill="currentColor"
                            />
                          </g>

                          {/* Value inside the gauge */}
                          <text x={CX} y={CY} textAnchor="middle" fontSize="20" fontWeight="600" fill="#000">
                            {item.flowrate.toFixed(2)} {item.flowrateUnit}
                          </text>
                        </svg>

                        {/* Last Updated below gauge */}
                        {item.timestamp && (
                          <Typography variant="caption" color="textSecondary" >
                            Last Updated:
                          </Typography>
                        )}
                        {item.timestamp && (
                          <Typography variant="caption" color="textSecondary">
                            {formatDate(item.timestamp)}
                          </Typography>
                        )}
                      </Box>

                      {/* TOTALIZER PIE */}
                      <Box sx={{ flex: 1, position: "relative", textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center" }}>
                        <PieChart width={170} height={170}>
                          <Pie
                            data={[{ value: item.totalizer }]}
                            dataKey="value"
                            innerRadius={50}
                            outerRadius={65}
                            stroke="none"
                            fill="#8884d8"
                            isAnimationActive={true}
                            
                            
                          />
                         
                        </PieChart>

                        {/* Totalizer text inside pie chart */}
                        <Box
                          sx={{
                            position: "absolute",
                            top: "45%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            textAlign: "center",
                          }}
                        >
                          <Typography sx={{ fontSize: 12, color: "text.secondary" }}>
                            Totalizer
                          </Typography>
                        </Box>

                        {/* Value below pie chart */}
                        <Typography  sx={{ fontWeight: 600, fontSize: 14  }}>
                          Total: {item.totalizer.toFixed(2)} {item.totalizerUnit}
                        </Typography>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </div>
    </div>
  );
}

export default TankFarmFlowMeterData;