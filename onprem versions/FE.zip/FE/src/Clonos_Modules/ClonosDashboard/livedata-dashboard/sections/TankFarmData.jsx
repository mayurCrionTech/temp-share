// import React, { useEffect, useState } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";
// import DateFilters from "../../DateFilters";

// const TankFarmData = () => {
//   const [tanks, setTanks] = useState([]);
//   const [loading, setLoading] = useState(true);

//   const fetchData = async () => {
//     try {
//       const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//       const res = await doGetApiCall({ url });
//       const data = res?.data?.result?.data || [];

//       const formatted = data.map((tank) => {
//         const tagMap = {};
//         tank.tags.forEach((tag) => {
//           const name = tag.tagName.toLowerCase();
//           if (name.includes("level")) tagMap.level = tag;
//           else if (name.includes("volume")) tagMap.volume = tag;
//           else if (name.includes("temperature")) tagMap.temperature = tag;
//         });
//         return {
//           tankName: tank.tankName,
//           productName: tank.productName,
//           readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
//         };
//       });

//       setTanks(formatted);
//     } catch (err) {
//       console.error("Error fetching tank farm data:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 30000);
//     return () => clearInterval(interval);
//   }, []);

//   const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");

//    if (loading) return <div className={Styles.loaderWrapper}><ClonosSpinner /></div>

//   return (
//     <>
//       <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//          <div className={Styles.livedataDashboardHeader}>
//                    <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm</h4>
//          </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//          {/* <Typography variant="h6" gutterBottom className={Styles.livedataDashboardTitle}>
//                   Live Data
//                 </Typography> */}
//         <Grid container spacing={3}>
//           {tanks.map((tank, index) => {
//             const [level, temp, volume] = tank.readings;
//             const timestamp = level?.timestamp || temp?.timestamp || volume?.timestamp;

//             return (
//               <Grid item xs={12} sm={6} md={4} key={index}>
//                 <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//                   <CardContent>
//                      <Typography variant="h4" align="center" className={Styles.dataHeaderLabelStyle}>
//                             {tank.tankName} - {tank.productName}
//                      </Typography>
                    
//                       {level && (
//                         <Typography variant="h6" color="primary" fontWeight={600}>
//                           <strong className={Styles.dataLabelStyle}>LEVEL:</strong>{" "}
//                           {level.value?.toFixed(2)} {level.unit}
//                         </Typography>
//                        )}
                     
//                       {temp && (
//                         <Typography variant="h6" color="primary" fontWeight={600}>
//                           <strong className={Styles.dataLabelStyle}>TEMPRETURE:</strong>{" "}
//                           {temp.value?.toFixed(2)} {temp.unit}
//                         </Typography>
//                       )}

//                       {volume && (
//                         <Typography variant="h6" color="primary" fontWeight={600}>
//                           <strong className={Styles.dataLabelStyle}>VOLUME:</strong>{" "}
//                           {volume.value?.toFixed(2)} {volume.unit}
//                         </Typography>
//                       )}

//                       {timestamp && (
//                         <Typography variant="body2"  mt={1}>
//                           Updated on: {formatDate(timestamp)}
//                         </Typography>
//                       )}
//                   </CardContent>
//                 </Card>
//               </Grid>
//             );
//           })}
//         </Grid>
//       </Box>

//       </Card>
//     </>
//   );
// };

// export default TankFarmData;


// import React, { useEffect, useState, useRef } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";
// import DateFilters from "../../DateFilters";

// const TankFarmData = () => {
//   const [tanks, setTanks] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const isFirstLoad = useRef(true);

//   const fetchData = async () => {
//     try {
//       if (isFirstLoad.current) setLoading(true); // loader only first fetch

//       const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//       const res = await doGetApiCall({ url });
//       const data = res?.data?.result?.data || [];

//       const formatted = data.map((tank) => {
//         const tagMap = {};
//         tank.tags.forEach((tag) => {
//           const name = tag.tagName.toLowerCase();
//           if (name.includes("level")) tagMap.level = tag;
//           else if (name.includes("volume")) tagMap.volume = tag;
//           else if (name.includes("temperature")) tagMap.temperature = tag;
//         });
//         return {
//           tankName: tank.tankName,
//           productName: tank.productName,
//           readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
//         };
//       });

//       setTanks(formatted);
//     } catch (err) {
//       console.error("Error fetching tank farm data:", err);
//     } finally {
//       setLoading(false);
//       isFirstLoad.current = false; // after first fetch, no loader
//     }
//   };

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 30000);
//     return () => clearInterval(interval);
//   }, []);

//   const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");

//   if (loading)
//     return (
//       <div className={Styles.loaderWrapper}>
//         <ClonosSpinner />
//       </div>
//     );

//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm
//         </h4>
//       </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {tanks.map((tank, index) => {
//             const [level, temp, volume] = tank.readings;
//             const timestamp =
//               level?.timestamp || temp?.timestamp || volume?.timestamp;

//             return (
//               <Grid item xs={12} sm={6} md={4} key={index}>
//                 <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//                   <CardContent>
//                     <Typography
//                       variant="h4"
//                       align="center"
//                       className={Styles.dataHeaderLabelStyle}
//                     >
//                       {tank.tankName} - {tank.productName}
//                     </Typography>

//                     {level && (
//                       <Typography variant="h6" color="primary" fontWeight={600}>
//                         <strong className={Styles.dataLabelStyle}>LEVEL:</strong>{" "}
//                         {level.value?.toFixed(2)} {level.unit}
//                       </Typography>
//                     )}

//                     {temp && (
//                       <Typography variant="h6" color="primary" fontWeight={600}>
//                         <strong className={Styles.dataLabelStyle}>
//                           TEMPERATURE:
//                         </strong>{" "}
//                         {temp.value?.toFixed(2)} {temp.unit}
//                       </Typography>
//                     )}

//                     {volume && (
//                       <Typography variant="h6" color="primary" fontWeight={600}>
//                         <strong className={Styles.dataLabelStyle}>VOLUME:</strong>{" "}
//                         {volume.value?.toFixed(2)} {volume.unit}
//                       </Typography>
//                     )}

//                     {timestamp && (
//                       <Typography variant="body2" mt={1}>
//                         Updated on: {formatDate(timestamp)}
//                       </Typography>
//                     )}
//                   </CardContent>
//                 </Card>
//               </Grid>
//             );
//           })}
//         </Grid>
//       </Box>
//     </Card>
//   );
// };

// export default TankFarmData;


// import React, { useEffect, useState, useRef } from "react";
// import { Card, CardContent, Grid, Typography, Box, Divider } from "@mui/material";
// import { Waves, LocalFireDepartment, Scale } from "@mui/icons-material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";

// const TankFarmData = () => {
//   const [tanks, setTanks] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const isFirstLoad = useRef(true);

//   const fetchData = async () => {
//     try {
//       if (isFirstLoad.current) setLoading(true);

//       const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//       const res = await doGetApiCall({ url });
//       const data = res?.data?.result?.data || [];

//       const formatted = data.map((tank, idx) => {
//         const tagMap = {};
//         tank.tags.forEach((tag) => {
//           const name = tag.tagName.toLowerCase();
//           if (name.includes("level")) tagMap.level = tag;
//           else if (name.includes("volume")) tagMap.volume = tag;
//           else if (name.includes("temperature")) tagMap.temperature = tag;
//         });
//         return {
//           id: idx,
//           tankName: tank.tankName,
//           productName: tank.productName,
//           level: tagMap.level,
//           temperature: tagMap.temperature,
//           volume: tagMap.volume,
//         };
//       });

//       setTanks(formatted);
//     } catch (err) {
//       console.error("Error fetching tank farm data:", err);
//     } finally {
//       setLoading(false);
//       isFirstLoad.current = false;
//     }
//   };

//   useEffect(() => {
//     fetchData();
//     const interval = setInterval(fetchData, 30000);
//     return () => clearInterval(interval);
//   }, []);

//   const formatDate = (dateStr) => {
//     if (!dateStr) return "-";
//     return new Date(dateStr).toLocaleString("en-GB");
//   };

//   if (loading) {
//     return (
//       <div className={Styles.loaderWrapper}>
//         <ClonosSpinner />
//       </div>
//     );
//   }

//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm
//         </h4>
//       </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {tanks.map((tank) => {
//             const timestamp =
//               tank.level?.timestamp || tank.temperature?.timestamp || tank.volume?.timestamp;

//             return (
//               <Grid item xs={12} sm={6} md={4} key={tank.id}>
//                 <Card
//                   sx={{
//                     borderRadius: 3,
//                     boxShadow: 4,
//                     display: "flex",
//                     flexDirection: "column",
//                     height: "100%",
//                   }}
//                 >
//                   {/* Header */}
//                   <Box
//                     sx={{
//                       background: "linear-gradient(90deg, #1976d2, #42a5f5)",
//                       color: "white",
//                       textAlign: "center",
//                       py: 1,
//                       borderTopLeftRadius: 12,
//                       borderTopRightRadius: 12,
//                     }}
//                   >
//                     <Typography variant="subtitle1" fontWeight="bold">
//                       {tank.tankName} - {tank.productName}
//                     </Typography>
//                   </Box>

//                   {/* Content */}
//                   <CardContent sx={{ flexGrow: 1 }}>
//                     {/* Level */}
//                     {tank.level && (
//                       <Box display="flex" alignItems="center" mb={2}>
//                         <Waves sx={{ mr: 1, color: "primary.main" }} />
//                         <Box>
//                           <Typography variant="body2" color="textSecondary">
//                             LEVEL
//                           </Typography>
//                           <Typography variant="h6" fontWeight="bold">
//                             {tank.level.value?.toFixed(2)}{" "}
//                             <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                               {tank.level.unit}
//                             </span>
//                           </Typography>
//                         </Box>
//                       </Box>
//                     )}

//                     <Divider />

//                     {/* Temperature */}
//                     {tank.temperature && (
//                       <Box display="flex" alignItems="center" mt={2} mb={2}>
//                         <LocalFireDepartment sx={{ mr: 1, color: "error.main" }} />
//                         <Box>
//                           <Typography variant="body2" color="textSecondary">
//                             TEMPERATURE
//                           </Typography>
//                           <Typography variant="h6" fontWeight="bold">
//                             {tank.temperature.value?.toFixed(2)}{" "}
//                             <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                               {tank.temperature.unit}
//                             </span>
//                           </Typography>
//                         </Box>
//                       </Box>
//                     )}

//                     <Divider />

//                     {/* Volume */}
//                     {tank.volume && (
//                       <Box display="flex" alignItems="center" mt={2}>
//                         <Scale sx={{ mr: 1, color: "success.main" }} />
//                         <Box>
//                           <Typography variant="body2" color="textSecondary">
//                             VOLUME
//                           </Typography>
//                           <Typography variant="h6" fontWeight="bold">
//                             {tank.volume.value?.toFixed(2)}{" "}
//                             <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                               {tank.volume.unit}
//                             </span>
//                           </Typography>
//                         </Box>
//                       </Box>
//                     )}
//                   </CardContent>

//                   {/* Footer */}
//                   <Box
//                     sx={{
//                       textAlign: "center",
//                       backgroundColor: "#f9f9f9",
//                       py: 1,
//                       borderTop: "1px solid #eee",
//                     }}
//                   >
//                     <Typography variant="caption" color="textSecondary">
//                       Updated on: {formatDate(timestamp)}
//                     </Typography>
//                   </Box>
//                 </Card>
//               </Grid>
//             );
//           })}
//         </Grid>
//       </Box>
//     </Card>
//   );
// };

// export default TankFarmData;

//workingcode
// import React, { useEffect, useState, useRef } from "react";
// import { Card,CardContent,Grid, Typography,Box,Divider} from "@mui/material";
// import { WaterDrop,DeviceThermostat,Inventory2,} from "@mui/icons-material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";

// const TankFarmData = () => {
//   const [tanks, setTanks] = useState([]);
//   const [loading, setLoading] = useState(true);

//   // const fetchData = async () => {
//   //   try {
//   //     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//   //     const res = await doGetApiCall({ url });
//   //     const data = res?.data?.result?.data || [];

//   //     const formatted = data.map((tank) => {
//   //       const tagMap = {};
//   //       tank.tags.forEach((tag) => {
//   //         const name = tag.tagName.toLowerCase();
//   //         if (name.includes("level")) tagMap.level = tag;
//   //         else if (name.includes("volume")) tagMap.volume = tag;
//   //         else if (name.includes("temperature")) tagMap.temperature = tag;
//   //       });
//   //       return {
//   //         tankName: tank.tankName,
//   //         productName: tank.productName,
//   //         readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
//   //       };
//   //     });

//   //     setTanks(formatted);
//   //   } catch (err) {
//   //     console.error("Error fetching tank farm data:", err);
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };

//   // useEffect(() => {
//   //   fetchData();
//   //   const interval = setInterval(fetchData, 30000);
//   //   return () => clearInterval(interval);
//   // }, []);

//   const fetchData = async () => {
//   try {
//     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//     const res = await doGetApiCall({ url });
//     const data = res?.data?.result?.data || [];

//     const formatted = data.map((tank) => {
//       const tagMap = {};
//       tank.tags.forEach((tag) => {
//         const name = tag.tagName.toLowerCase();
//         if (name.includes("level")) tagMap.level = tag;
//         else if (name.includes("volume")) tagMap.volume = tag;
//         else if (name.includes("temperature")) tagMap.temperature = tag;
//       });
//       return {
//         tankName: tank.tankName,
//         productName: tank.productName,
//         readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
//       };
//     });

//     setTanks(formatted);
//     return true; // ✅ Return true if successful
//   } catch (err) {
//     console.error("Error fetching tank farm data:", err);
//     return false; // ✅ Return false on error
//   } finally {
//     setLoading(false);
//   }
// };

// useEffect(() => {
//   let isMounted = true;
//   let timeoutId;

//   const fetchDataWithDelay = async () => {
//     try {
//       const success = await fetchData(); 
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchDataWithDelay, 30000); // 30 sec
//       } else {
//         console.warn("Stopping interval due to failed response");
//       }
//     } catch (error) {
//       console.error("API error:", error);
//     }
//   };

//   fetchDataWithDelay(); // initial call

//   return () => {
//     isMounted = false;
//     clearTimeout(timeoutId);
//   };
// }, []);



//   const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");

//   if (loading)
//     return (
//       <div className={Styles.loaderWrapper}>
//         <ClonosSpinner />
//       </div>
//     );

//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Tank Farm
//         </h4>
//       </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {tanks.map((tank, index) => {
//             const [level, temp, volume] = tank.readings;
//             const timestamp =
//               level?.timestamp || temp?.timestamp || volume?.timestamp;

//             return (
//               <Grid item xs={12} sm={6} md={4} key={index}>
//                 <Card
//                   sx={{
//                     borderRadius: 3,
//                     boxShadow: 4,
//                     display: "flex",
//                     flexDirection: "column",
//                     height: "100%",
//                   }}
//                 >
//                   {/* Card Header */}
//                   <Box
//                     sx={{
//                       background: "linear-gradient(90deg, #2C4E87 0%, #6885B1 100%)",
//                       color: "white",
//                       textAlign: "center",
//                       py: 1,
//                       borderTopLeftRadius: 12,
//                       borderTopRightRadius: 12,
//                     }}
//                   >
//                     <Typography variant="subtitle1" fontWeight="bold">
//                       {tank.tankName} - {tank.productName}
//                     </Typography>
//                   </Box>

//                   {/* Card Content */}
//                   <CardContent sx={{ flexGrow: 1 }}>
//                     {level && (
//                       <Box display="flex" alignItems="center" mb={2}>
//                         <WaterDrop sx={{ mr: 1, color: "primary.main" }} />
//                         <Box>
//                           <Typography variant="body2" color="textSecondary">
//                             LEVEL
//                           </Typography>
//                           <Typography variant="h6" fontWeight="bold">
//                             {level.value?.toFixed(2)}{" "}
//                             <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                               {level.unit}
//                             </span>
//                           </Typography>
//                         </Box>
//                       </Box>
//                     )}

//                     <Divider />

//                     {temp && (
//                       <Box display="flex" alignItems="center" mt={2} mb={2}>
//                         <DeviceThermostat
//                           sx={{ mr: 1, color: "error.main" }}
//                         />
//                         <Box>
//                           <Typography variant="body2" color="textSecondary">
//                             TEMPERATURE
//                           </Typography>
//                           <Typography variant="h6" fontWeight="bold">
//                             {temp.value?.toFixed(2)}{" "}
//                             <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                               {temp.unit}
//                             </span>
//                           </Typography>
//                         </Box>
//                       </Box>
//                     )}

//                     <Divider />

//                     {volume && (
//                       <Box display="flex" alignItems="center" mt={2}>
//                         <Inventory2 sx={{ mr: 1, color: "success.main" }} />
//                         <Box>
//                           <Typography variant="body2" color="textSecondary">
//                             VOLUME
//                           </Typography>
//                           <Typography variant="h6" fontWeight="bold">
//                             {volume.value?.toFixed(2)}{" "}
//                             <span style={{ fontSize: "0.8rem", color: "#555" }}>
//                               {volume.unit}
//                             </span>
//                           </Typography>
//                         </Box>
//                       </Box>
//                     )}
//                   </CardContent>

//                   {/* Footer */}
//                   {timestamp && (
//                     <Box
//                       sx={{
//                         textAlign: "center",
//                         backgroundColor: "#f9f9f9",
//                         py: 1,
//                         borderTop: "1px solid #eee",
//                       }}
//                     >
//                       <Typography variant="caption" color="textSecondary">
//                         Updated on: {formatDate(timestamp)}
//                       </Typography>
//                     </Box>
//                   )}
//                 </Card>
//               </Grid>
//             );
//           })}
//         </Grid>
//       </Box>
//     </Card>
//   );
// };

// export default TankFarmData;


//last work code

// import React, { useEffect, useState } from "react";
// import { Card, CardContent, Grid, Typography, Box } from "@mui/material";
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";
// import DateFilters from "../../DateFilters";
// import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

// const TankFarmData = () => {
//   const [tanks, setTanks] = useState([]);
//   const [loading, setLoading] = useState(true);

//   // const fetchData = async () => {
//   //   try {
//   //     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//   //     const res = await doGetApiCall({ url });
//   //     const data = res?.data?.result?.data || [];

//   //     const formatted = data.map((tank) => {
//   //       const tagMap = {};
//   //       tank.tags.forEach((tag) => {
//   //         const name = tag.tagName.toLowerCase();
//   //         if (name.includes("level")) tagMap.level = tag;
//   //         else if (name.includes("volume")) tagMap.volume = tag;
//   //         else if (name.includes("temperature")) tagMap.temperature = tag;
//   //       });
//   //       return {
//   //         tankName: tank.tankName,
//   //         productName: tank.productName,
//   //         readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
//   //       };
//   //     });

//   //     setTanks(formatted);
//   //   } catch (err) {
//   //     console.error("Error fetching tank farm data:", err);
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };

//   // useEffect(() => {
//   //   fetchData();
//   //   const interval = setInterval(fetchData, 30000);
//   //   return () => clearInterval(interval);
//   // }, []);

//   const fetchData = async () => {
//   try {
//     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//     const res = await doGetApiCall({ url });
//     const data = res?.data?.result?.data || [];

//     const formatted = data.map((tank) => {
//       const tagMap = {};
//       tank.tags.forEach((tag) => {
//         const name = tag.tagName.toLowerCase();
//         if (name.includes("level")) tagMap.level = tag;
//         else if (name.includes("volume")) tagMap.volume = tag;
//         else if (name.includes("temperature")) tagMap.temperature = tag;
//       });
//       return {
//         tankName: tank.tankName,
//         productName: tank.productName,
//         readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
//       };
//     });

//     setTanks(formatted);
//     return true; // ✅ Return true if successful
//   } catch (err) {
//     console.error("Error fetching tank farm data:", err);
//     return false; // ✅ Return false on error
//   } finally {
//     setLoading(false);
//   }
// };

// useEffect(() => {
//   let isMounted = true;
//   let timeoutId;

//   const fetchDataWithDelay = async () => {
//     try {
//       const success = await fetchData(); 
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchDataWithDelay, 30000); // 30 sec
//       } else {
//         console.warn("Stopping interval due to failed response");
//       }
//     } catch (error) {
//       console.error("API error:", error);
//     }
//   };

//   fetchDataWithDelay(); // initial call

//   return () => {
//     isMounted = false;
//     clearTimeout(timeoutId);
//   };
// }, []);



//   const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");

//    const TankFarmCardSkeleton = () => {
//   return (
//     <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//       <CardContent>
//         {/* Tank Name */}
//         <ClonosSkeletonLoading width="70%" height="28px" animation="wave" />

//         {/* LEVEL */}
//         <ClonosSkeletonLoading
//           width="80%"
//           height="22px"
//           animation="wave"
//           style={{ marginTop: "12px" }}
//         />

//         {/* TEMPERATURE */}
//         <ClonosSkeletonLoading
//           width="80%"
//           height="22px"
//           animation="wave"
//           style={{ marginTop: "8px" }}
//         />

//         {/* VOLUME */}
//         <ClonosSkeletonLoading
//           width="80%"
//           height="22px"
//           animation="wave"
//           style={{ marginTop: "8px" }}
//         />

//         {/* Updated On */}
//         <ClonosSkeletonLoading
//           width="50%"
//           height="18px"
//           animation="wave"
//           style={{ marginTop: "10px" }}
//         />
//       </CardContent>
//     </Card>
//   );
// };

//    if (loading) {
//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <div className={Styles.livedataDashboardHeader}>
//         <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm</h4>
//       </div>

//       <Box px={{ xs: 2, md: 4 }} py={2}>
//         <Grid container spacing={3}>
//           {[1, 2, 3, 4, 5, 6].map((i) => (
//             <Grid item xs={12} sm={6} md={4} key={i}>
//               <TankFarmCardSkeleton />
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//     </Card>
//   );
// }


//   //  if (loading) return <div className={Styles.loaderWrapper}><ClonosSpinner /></div>

//   return (
//     <>
//       <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//          <div className={Styles.livedataDashboardHeader}>
//                    <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm</h4>
//          </div>
//       <Box px={{ xs: 2, md: 4 }} py={2}>
//          {/* <Typography variant="h6" gutterBottom className={Styles.livedataDashboardTitle}>
//                   Live Data
//                 </Typography> */}
//         <Grid container spacing={3}>
//           {tanks.map((tank, index) => {
//             const [level, temp, volume] = tank.readings;
//             const timestamp = level?.timestamp || temp?.timestamp || volume?.timestamp;

//             return (
//               <Grid item xs={12} sm={6} md={4} key={index}>
//                 <Card sx={{ borderRadius: 3, boxShadow: 3 }}>
//                   <CardContent>
//                      <Typography variant="h4" align="center" className={Styles.dataHeaderLabelStyle}>
//                             {tank.tankName} - {tank.productName}
//                      </Typography>
                    
//                       {level && (
//                         <Typography variant="h6" color="primary" fontWeight={600}>
//                           <strong className={Styles.dataLabelStyle}>LEVEL:</strong>{" "}
//                           {level.value?.toFixed(2)} {level.unit}
//                         </Typography>
//                        )}
                     
//                       {temp && (
//                         <Typography variant="h6" color="primary" fontWeight={600}>
//                           <strong className={Styles.dataLabelStyle}>TEMPERATURE:</strong>{" "}
//                           {temp.value?.toFixed(2)} {temp.unit}
//                         </Typography>
//                       )}

//                       {volume && (
//                         <Typography variant="h6" color="primary" fontWeight={600}>
//                           <strong className={Styles.dataLabelStyle}>VOLUME:</strong>{" "}
//                           {volume.value?.toFixed(2)} {volume.unit}
//                         </Typography>
//                       )}

//                       {timestamp && (
//                         <Typography variant="body2"  mt={1}>
//                           Updated on: {formatDate(timestamp)}
//                         </Typography>
//                       )}
//                   </CardContent>
//                 </Card>
//               </Grid>
//             );
//           })}
//         </Grid>
//       </Box>

//       </Card>
//     </>
//   );
// };

// export default TankFarmData;



// import React, { useEffect, useState,useMemo } from "react";
// import Styles from  '../livedata.module.css';
// import AppUrl from "../../../../utils/AppUrl";
// // import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// // import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// // import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// // import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// // import ClonosGridNav from "../../../utils/ClonosGridNav"
// import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
// // import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// // import { Box } from '@mui/material'

// // import {
// //   DataGrid,
// //   gridPageCountSelector,
// //   useGridApiContext,
// //   useGridSelector,
// // } from '@mui/x-data-grid';
// // import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// // import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// // import AppUrl from "../../../utils/AppUrl";

// function TankFarmData() {

//   const [tanks, setTanks] = useState([]);
//   const [loading, setLoading] = useState(true);

//   const fetchData = async () => {
//   try {
//     const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
//     const res = await doGetApiCall({ url });
//     const data = res?.data?.result?.data || [];
// console.log(data,"tankdata")
//     const formatted = data.map((tank) => {
//       const tagMap = {};
//       tank.tags.forEach((tag) => {
//         const name = tag.tagName.toLowerCase();
//         if (name.includes("level")) tagMap.level = tag;
//         else if (name.includes("volume")) tagMap.volume = tag;
//         else if (name.includes("temperature")) tagMap.temperature = tag;
//       });
//       return {
//         tankName: tank.tankName,
//         productName: tank.productName,
//         readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
//       };
//     });

//     setTanks(formatted);
//     return true; // ✅ Return true if successful
//   } catch (err) {
//     console.error("Error fetching tank farm data:", err);
//     return false; // ✅ Return false on error
//   } finally {
//     setLoading(false);
//   }
// };

// console.log(tanks,"tanks")
// useEffect(() => {
//   let isMounted = true;
//   let timeoutId;

//   const fetchDataWithDelay = async () => {
//     try {
//       const success = await fetchData(); 
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchDataWithDelay, 30000); // 30 sec
//       } else {
//         console.warn("Stopping interval due to failed response");
//       }
//     } catch (error) {
//       console.error("API error:", error);
//     }
//   };

//   fetchDataWithDelay(); // initial call

//   return () => {
//     isMounted = false;
//     clearTimeout(timeoutId);
//   };
// }, []);



//   const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");


//    const getLabel = (value, scale) => {
//   if (value === null) return "Loading...";
    
//   for (const s of scale) {
//     if (s.min !== undefined && s.max !== undefined) {
//       if (value >= s.min && value <= s.max) return s.text;
//     } else if (s.max !== undefined) {
//       if (value < s.max) return s.text;
//     } else if (s.min !== undefined) {
//       if (value >= s.min) return s.text;
//     }
//   }
//   return "N/A";
// };


// // const tankFarmData = [
// //   {
// //     id: 1,
// //     title: "Asset Availability",
// //     subtitle: "% of time asset is available for use",
// //     value: 76,
// //     subLabel: "of assets are available",
// //     scaleTitle: "Asset Availability (Scale)",
// //     scale: [
// //       { color: "#13C63B", text: "Excellent", min: 99, max: 100, range: "99 - 100%" },
// //       { color: "#DAEC14", text: "Good", min: 80, max: 98.99, range: "80 - 98.99%" },
// //       { color: "#F92836", text: "Poor", max: 79.99, range: "< 80%" },
// //     ],
// //   },
// //   {
// //     id: 2,
// //     title: "Asset Utilization",
// //     subtitle: "Actual Productive Time vs Available Time",
// //     value: 76,
// //     subLabel: "of assets are utilized",
// //     scaleTitle: "Asset Utilization (Scale)",
// //     scale: [
// //       { color: "#13C63B", text: "Excellent", min: 100, range: "100%" },
// //       { color: "#DAEC14", text: "Good", min: 70, max: 99.99, range: "70 - 99.99%" },
// //       { color: "#F92836", text: "Poor", max: 69.99, range: "< 70%" },
// //     ],
// //   },
// //   {
// //     id: 3,
// //     title: "Overall Equipment Effectiveness",
// //     subtitle: "Combined Measure of availability, Performance, Quality",
// //     value: 78,
// //     subLabel: "of Overall Equipment Effectiveness",
// //     scaleTitle: "Overall Equipment Effectiveness (Scale)",
// //     scale: [
// //       { color: "#13C63B", text: "Excellent", min: 90, max: 100, range: "90 - 100%" },
// //       { color: "#DAEC14", text: "Good", min: 75, max: 90, range: "75 - 89%" },
// //       { color: "#F92836", text: "Poor", max: 75, range: "<75%" },
// //     ],
// //   },
// // ].map(item => ({
// //   ...item,
// //   label: getLabel(item.value, item.scale),
// // }));

// const tankFarmData = tanks.flatMap((tank, tIndex) => {
//   const [level, temperature, volume] = tank.readings;

//   return [
//     {
//       id: `${tIndex}-level`,
//       title: "Level",
//       subtitle: `${tank.tankName} - ${tank.productName}`,
//       value: level?.value ?? 0,
//       subLabel: level?.unit ?? "",
//     },
//     {
//       id: `${tIndex}-temperature`,
//       title: "Temperature",
//       subtitle: `${tank.tankName} - ${tank.productName}`,
//       value: temperature?.value ?? 0,
//       subLabel: temperature?.unit ?? "",
//     },
//     {
//       id: `${tIndex}-volume`,
//       title: "Volume",
//       subtitle: `${tank.tankName} - ${tank.productName}`,
//       value: volume?.value ?? 0,
//       subLabel: volume?.unit ?? "",
//     },
//   ];
// });


//   return (
//    <>
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//           <div className={Styles.livedataDashboardHeader}>
//                     <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm</h4>
//           </div>
//       <Container className={Styles.section}>
          
//   <    div className={Styles.gaugeRow}>

//             {tankFarmData?.map((item, index) => {
//               const gaugeSize = 170;  // match .gaugeWrap (170px)
//               const STROKE = 14;
//               const CX = gaugeSize / 2;
//               const CY = gaugeSize / 2 + 8;
//               const R = Math.min(CX, CY) - STROKE;
    
//               const v = Math.max(0, Math.min(100, item.value));
//               const theta = Math.PI * (1 - v / 100);
    
//               const startX = CX - R;
//               const endX = CX + R;
//               const y = CY;
//               const arcPath = `M ${startX} ${y} A ${R} ${R} 0 0 1 ${endX} ${y}`;
    
//               const OUTER_R = R + STROKE / 2;
//               const CLEARANCE = Math.max(3, STROKE * 0.15);
//               const ix = CX + (OUTER_R + CLEARANCE) * Math.cos(theta);
//               const iy = CY - (OUTER_R + CLEARANCE) * Math.sin(theta);
    
//               const rotateDeg = (-theta * 180) / Math.PI + 180;
    
//               const baseW = 19;
//               const baseH = 17;
//               const indScale = 1;
    
          
    
    
//               return (
               
//                   <Card className={`${Styles.card} ${Styles.cardFixed}`}>
//                     <CardContent className={Styles.cardContent}>
//                       <div className={Styles.cardHeader}>
//                         <Typography className={Styles.assetDashboardTitle}>{item?.title}</Typography>
//                         <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
//                           {item?.subtitle}
//                         </Typography>
//                         <hr className={Styles.divider} />
//                       </div>
    
//                       <div className={Styles.row}>
//                         {/* Gauge */}
//                         <div className={Styles.gaugeWrap}>
//                           <svg
//                             className={Styles.gaugeSvg}
//                             width={gaugeSize}
//                             height={gaugeSize}
//                             viewBox={`0 0 ${gaugeSize} ${gaugeSize}`}
//                             preserveAspectRatio="xMidYMid meet"
//                           >
//                             <defs>
//                               <linearGradient
//                                 id={`grad-${item.id}`}
//                                 x1={startX}
//                                 y1={y}
//                                 x2={endX}
//                                 y2={y}
//                                 gradientUnits="userSpaceOnUse"
//                               >
//                                 <stop offset="0%" stopColor="#F92836" />
//                                 <stop offset="50%" stopColor="#DAEC14" />
//                                 <stop offset="100%" stopColor="#239E58" />
//                               </linearGradient>
//                             </defs>
    
//                             <path d={arcPath} stroke="#ddd" strokeWidth={STROKE} fill="none" strokeLinecap="round" />
//                             <path d={arcPath} stroke={`url(#grad-${item.id})`} strokeWidth={STROKE} fill="none" strokeLinecap="round" />
    
//                             <g
//                               transform={`translate(${ix} ${iy}) rotate(${rotateDeg}) scale(${indScale}) translate(${-baseW / 2} ${-baseH / 2})`}
//                               style={{ color: '#C5C5D8' }}
//                             >
//                               <path
//                                 d="M4.81363 15.5606L14.8286 13.1474C15.5238 12.9793 16.1199 12.5322 16.4744 11.9092L19.2767 6.97792C19.952 5.7911 19.5876 4.28581 18.4449 3.53613L13.6998 0.424687C13.1017 0.0310579 12.367 -0.0955421 11.6699 0.0725908L1.65684 2.4858C0.494333 2.7647 -0.218634 3.93174 0.0606079 5.09086L2.2054 13.9663C2.48464 15.1274 3.6531 15.8395 4.81363 15.5606Z"
//                                 fill="currentColor"
//                               />
//                             </g>
//                           </svg>
                        
    
//                           {/* Overlay label */}
//                           <div className={Styles.gaugeOverlay}>
//                             <Typography variant="h6">
//                               {item.value.toFixed(2)} {item.subLabel}
//                             </Typography>
//                             <Typography variant="caption" color="textSecondary" className={Styles.labelCaption}>
//                               {item.title} - {item.subtitle}
//                             </Typography>
//                           </div>

//                         </div>
    
//                         {/* Scale (small text) */}
//                         {/* <div className={Styles.gaugescaleCol}>
//                           <Typography className={Styles.scaleTitle}>{item?.scaleTitle}</Typography>
//                           {item.scale.map((ele, i) => (
//                             <div key={i} className={Styles.scaleRow}>
//                               <Typography className={Styles.scaleText}>{ele.text}</Typography>
//                               <Typography className={Styles.scaleRange}>{ele.range}</Typography>
//                             </div>
//                           ))}
//                         </div> */}
//                       </div>
//                     </CardContent>
//                   </Card>
                
//               );
//             })}
//           </>
//         </Container>
//         </Card>
//    </>
//   )
// }

// export default TankFarmData


import React, { useEffect, useState } from "react";
import Styles from '../livedata.module.css';
import AppUrl from "../../../../utils/AppUrl";
import { Container, Card, CardContent, Typography,Grid,Box } from "@mui/material";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

function TankFarmData() {
  const [tanks, setTanks] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;
      const res = await doGetApiCall({ url });
      const data = res?.data?.result?.data || [];


      const formatted = data.map((tank) => {
        const tagMap = {};
        tank.tags.forEach((tag) => {
          const name = tag.tagName.toLowerCase();
          if (name.includes("level")) tagMap.level = tag;
          else if (name.includes("volume")) tagMap.volume = tag;
          else if (name.includes("temperature")) tagMap.temperature = tag;
        });
        return {
          tankName: tank.tankName,
          productName: tank.productName,
          tankCapacity: tank.capacity,
          tankLevel:tank.maxLevel,
          tankTempreture:tank.maxTemp,
          readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
        };
      });

      setTanks(formatted);
      return true;
    } catch (err) {
      console.error("Error fetching tank farm data:", err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    let timeoutId;

    const fetchDataWithDelay = async () => {
      try {
        const success = await fetchData();
        if (success && isMounted) {
          timeoutId = setTimeout(fetchDataWithDelay, 30000); // 30 sec
        } else {
          console.warn("Stopping interval due to failed response");
        }
      } catch (error) {
        console.error("API error:", error);
      }
    };

    fetchDataWithDelay(); // initial call

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, []);


  const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");
  const tankFarmData = tanks.flatMap((tank, tIndex) => {
    const [level, temperature, volume] = tank.readings;
    const timestamp = level?.timestamp || temperature?.timestamp || volume?.timestamp;

    return [
      {
        id: `${tIndex}-level`,
        title: "Level",
        subtitle: `${tank.tankName} `,
        value: level?.value ?? 0,
        subLabel: level?.unit ?? "",
        tankCapacity:`${tank.tankCapacity}`,
        maxValue:`${tank.tankLevel}`,
        timestamp,
      },
      {
        id: `${tIndex}-temperature`,
        title: "Temperature",
        subtitle: `${tank.tankName} `,
        value: temperature?.value ?? 0,
        subLabel: temperature?.unit ?? "",
        tankCapacity:`${tank.tankCapacity}`,
        maxValue:`${tank.tankTempreture}`,
        timestamp,
      },
      {
        id: `${tIndex}-volume`,
        title: "Volume",
        subtitle: `${tank.tankName}`,
        value: volume?.value ?? 0,
        subLabel: volume?.unit ?? "",
        tankCapacity:`${tank.tankCapacity}`,
        maxValue:`${tank.tankCapacity}`,
        timestamp,
      },
    ];
  });

   if (loading) {
    return (
      <Card variant="outlined" className={Styles.livedataDashboardContainer}>
        <div className={Styles.livedataDashboardHeader} style={{ padding: '16px' }}>
          <ClonosSkeletonLoading width="40%" height="32px" animation="wave" />
        </div>
        <Container className={Styles.section}>
          <Grid container spacing={2}>
            {[...Array(6)].map((_, i) => (
              <Grid item xs={12} sm={6} md={4} key={i}>
                <Card variant="outlined" sx={{ padding: 2 }}>
                  <ClonosSkeletonLoading width="100%" height="220px" animation="wave" />
                  <Box mt={1}>
                    <ClonosSkeletonLoading width="60%" height="20px" animation="wave" />
                  </Box>
                  <Box mt={1}>
                    <ClonosSkeletonLoading width="40%" height="16px" animation="wave" />
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Card>
    );
  }

  return (
    <>
      <div className={Styles.livedataDashboardContainer}>
        <div className={Styles.livedataDashboardHeader}>
          <h4 className={Styles.livedataDashboardTitle}>Live Dashboard - Tank Farm</h4>
        </div>
        <div className={Styles.section}>
          <div className={Styles.gaugeRow}>
            {tankFarmData?.map((item) => {
              const gaugeSize = 220;
              const STROKE = 14;
              const CX = gaugeSize / 2;
              const CY = gaugeSize / 2 + 8;
              const R = Math.min(CX, CY) - STROKE;
//               const maxCapacity = item.tankCapacity; // in MT
// const currentValue = item.value;       // in MT

// const v = Math.max(
//   0,
//   Math.min(100, (currentValue / maxCapacity) * 100)
// );

           
              const v = Math.max(0, Math.min(item.maxValue, item.value));
              const theta = Math.PI * (1 - v / item.maxValue);

              const startX = CX - R;
              const endX = CX + R;
              const y = CY;
              const arcPath = `M ${startX} ${y} A ${R} ${R} 0 0 1 ${endX} ${y}`;

              const OUTER_R = R + STROKE / 2;
              const CLEARANCE = Math.max(3, STROKE * 0.15);
              const ix = CX + (OUTER_R + CLEARANCE) * Math.cos(theta);
              const iy = CY - (OUTER_R + CLEARANCE) * Math.sin(theta);

              const rotateDeg = (-theta * 180) / Math.PI + 180;

              const baseW = 19;
              const baseH = 17;
              const indScale = 1;

              return (
                <Card key={item.id} variant="outlined" sx={{ borderRadius: 3, boxShadow: 3 }}>
                  <CardContent className={Styles.cardContent}>
                    <div className={Styles.cardHeader}>
                      <Typography className={Styles.assetDashboardTitle}>{item.title}</Typography>
                      <Typography style={{ fontSize: "12px", fontWeight: 600 ,color:"#333"}}>
                        {item.subtitle} 
                      </Typography>
                      <Typography style={{ fontSize: "12px", fontWeight: 600 ,color:"#333"}}>
                        CAPACITY: {item.tankCapacity} MT
                      </Typography>
                      <hr className={Styles.divider} />
                    </div>

                    <div className={Styles.row}>
                      {/* Gauge */}
                      <div className={Styles.gaugeWrap}>
                        <svg
                          className={Styles.gaugeSvg}
                          width={gaugeSize}
                          height={gaugeSize}
                          viewBox={`0 0 ${gaugeSize} ${gaugeSize}`}
                          preserveAspectRatio="xMidYMid meet"
                        >
                          <defs>
                            <linearGradient
                              id={`grad-${item.id}`}
                              x1={startX}
                              y1={y}
                              x2={endX}
                              y2={y}
                              gradientUnits="userSpaceOnUse"
                            >
                              <stop offset="0%" stopColor="#F92836" />
                              <stop offset="50%" stopColor="#DAEC14" />
                              <stop offset="100%" stopColor="#239E58" />
                            </linearGradient>
                          </defs>

                          <path d={arcPath} stroke="#ddd" strokeWidth={STROKE} fill="none" strokeLinecap="round" />
                          <path d={arcPath} stroke={`url(#grad-${item.id})`} strokeWidth={STROKE} fill="none" strokeLinecap="round" />

                          <g
                            transform={`translate(${ix} ${iy}) rotate(${rotateDeg}) scale(${indScale}) translate(${-baseW / 2} ${-baseH / 2})`}
                            style={{ color: "#C5C5D8" }}
                          >
                            <path
                              d="M4.81363 15.5606L14.8286 13.1474C15.5238 12.9793 16.1199 12.5322 16.4744 11.9092L19.2767 6.97792C19.952 5.7911 19.5876 4.28581 18.4449 3.53613L13.6998 0.424687C13.1017 0.0310579 12.367 -0.0955421 11.6699 0.0725908L1.65684 2.4858C0.494333 2.7647 -0.218634 3.93174 0.0606079 5.09086L2.2054 13.9663C2.48464 15.1274 3.6531 15.8395 4.81363 15.5606Z"
                              fill="currentColor"
                            />
                          </g>
                        </svg>

                        {/* Overlay label */}
                        <div className={Styles.gaugeOverlay}>
                          <Typography variant="h6">
                            {item.value.toFixed(2)} {item.subLabel}
                          </Typography>
                          
                         {item.timestamp && (
                          <Typography variant="caption" color="textSecondary" className={Styles.labelCaption}>
                            Last Updated: {formatDate(item.timestamp)}
                          </Typography>
                        )}

                        
                        </div>
                      </div>
                    </div>
                      
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}

export default TankFarmData;
