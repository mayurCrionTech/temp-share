// import React, { useEffect, useState } from "react";
// import {
//   Card,
//   CardContent,
//   Grid,
//   Box,
//   Typography,
//   Divider,
//   LinearProgress,
// } from "@mui/material";
// import { TextField } from "@material-ui/core";
// import {
//   PieChart,
//   Pie,
//   Cell,
//   Tooltip,
//   Legend,
//   ResponsiveContainer,
//   Label 
// } from "recharts";

// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
// import { doGetApiCall } from "../../../../utils/ClonosApi";
// import AppUrl from "../../../../utils/AppUrl";
// import Styles from "../livedata.module.css";

// // COLORS for Pie chart
// const COLORS = ["#8884d8", "#82ca9d", "#ffc658"];

// const RefineryData = () => {
//   const [data, setData] = useState(null);
//   const [loading, setLoading] = useState(true);
//    const [date, setDate] = useState(null);
 

//   //  const fetchLiveData = async (date) => {
//   //     try {
//   //       let url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=PLC_A`;
//   //       if (date) {
//   //       url += `&date=${date}`;
//   //       }
//   //       const res = await doGetApiCall({ url });
//   //       const result = res?.data?.result || {};

//   //       const shiftLabels = ["A", "B", "C"];
//   //       const map = {};
//   //       (result.ShiftWiseMFMProductionEntry ?? []).forEach((e) => {
//   //         map[e.shift] = e;
//   //       });

//   //       const lossMap = {};
//   //       (result.ShiftWiseMFMProductionLoss ?? []).forEach((e) => {
//   //         lossMap[e.shift] = e;
//   //       });

//   //       const shiftData = shiftLabels.map((s) => ({
//   //         shift: s,
//   //         MFMProductionEntryData: map[s]?.MFMProductionEntryData ?? {
//   //           quantity: 0,
//   //           uom: "KG",
//   //         },
//   //         MFMProductionLossData: lossMap[s]?.MFMProductionLossData ?? {
//   //           quantity: 0,
//   //           uom: "KG",
//   //         },
//   //       }));

//   //       const live = result.liveData || [];
//   //       const crude = live.find((i) =>
//   //         i.name.toLowerCase().includes("crude")
//   //       ) || {};
//   //       const dio = live.find((i) => i.name.toLowerCase().includes("dio")) || {};

//   //       setData({
//   //         crudeInlet: crude.averageRateOfFlow || 0,
//   //         crudeInletUnit: crude.unit || "",
//   //         crudeInletUpdatedAt: crude.latestTimestamp,
//   //         dioFinal: dio.averageRateOfFlow || 0,
//   //         dioFinalUnit: dio.unit || "",
//   //         dioFinalUpdatedAt: dio.latestTimestamp,
//   //         shiftData,
//   //         totalProductionLoss: result.ShiftWisetotalMFMProductionLoss || 0,
//   //         totalProducdutionEntry:result.ShiftWisetotalMFMProductionEntry || 0
//   //       });
//   //     } catch (err) {
//   //       console.error(err);
//   //     } finally {
//   //       setLoading(false);
//   //     }
//   //   }

//   // useEffect(() => {
   
//   //   fetchLiveData(date);
//   //    const interval = setInterval(fetchLiveData(date), 30000);
//   //   return () => clearInterval(interval);
//   // }, [date]);

// const fetchLiveData = async (selectedDate) => {
//   try {
//     let url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=PLC_A`;
//     if (selectedDate) url += `&date=${selectedDate}`;

//     const res = await doGetApiCall({ url });
//     const result = res?.data?.result || {};

//     const shiftLabels = ["A", "B", "C"];
//     const map = {};
//     (result.ShiftWiseMFMProductionEntry ?? []).forEach((e) => {
//       map[e.shift] = e;
//     });

//     const lossMap = {};
//     (result.ShiftWiseMFMProductionLoss ?? []).forEach((e) => {
//       lossMap[e.shift] = e;
//     });

//     const shiftData = shiftLabels.map((s) => ({
//       shift: s,
//       MFMProductionEntryData: map[s]?.MFMProductionEntryData ?? { quantity: 0, uom: "KG" },
//       MFMProductionLossData: lossMap[s]?.MFMProductionLossData ?? { quantity: 0, uom: "KG" },
//     }));

//     const live = result.liveData || [];
//     const crude = live.find((i) => i.name.toLowerCase().includes("crude")) || {};
//     const dio = live.find((i) => i.name.toLowerCase().includes("dio")) || {};

//     setData({
//       crudeInlet: crude.averageRateOfFlow || 0,
//       crudeInletUnit: crude.unit || "",
//       crudeInletUpdatedAt: crude.latestTimestamp,
//       dioFinal: dio.averageRateOfFlow || 0,
//       dioFinalUnit: dio.unit || "",
//       dioFinalUpdatedAt: dio.latestTimestamp,
//       shiftData,
//       totalProductionLoss: result.ShiftWisetotalMFMProductionLoss || 0,
//       totalProducdutionEntry: result.ShiftWisetotalMFMProductionEntry || 0,
//     });

//     return true; // ✅ success
//   } catch (err) {
//     console.error("Error fetching refinery live data:", err);
//     return false; // ✅ failure
//   } finally {
//     setLoading(false);
//   }
// };

// useEffect(() => {
//   let isMounted = true;
//   let timeoutId;

//   const fetchLiveDataWithDelay = async () => {
//     try {
//       const success = await fetchLiveData(date);
//       if (success && isMounted) {
//         timeoutId = setTimeout(fetchLiveDataWithDelay, 30000); // 30 sec
//       } else {
//         console.warn("Stopping interval due to failed response");
//       }
//     } catch (err) {
//       console.error("API error:", err);
//     }
//   };

//   fetchLiveDataWithDelay(); // initial call

//   return () => {
//     isMounted = false;
//     clearTimeout(timeoutId);
//   };
// }, [date]);


//   const pieData = data?.shiftData?.map((e) => ({
//     name: `Shift ${e.shift}`,
//     value: e.MFMProductionEntryData.quantity,
//   }));

//   if (loading) {
//     return (
//       <div className={Styles.loaderWrapper}>
//         <ClonosSpinner />
//       </div>
//     );
//   }

//   const cardStyle = {
//     borderRadius: 3,
//     boxShadow: 3,
//     display: "flex",
//     flexDirection: "column",
//     justifyContent: "space-between",
//     height: "100%",
//   };

//   const liveItems = [
//     {
//       label: "Crude Inlet",
//       value: data.crudeInlet,
//       unit: data.crudeInletUnit,
//       updatedAt: data.crudeInletUpdatedAt,
//     },
//     {
//       label: "Dio Final",
//       value: data.dioFinal,
//       unit: data.dioFinalUnit,
//       updatedAt: data.dioFinalUpdatedAt,
//     },
//   ];

//   return (
//     <Card variant="outlined" className={Styles.livedataDashboardContainer}>
//       <Box className={Styles.livedataDashboardHeader}>
//         <Typography variant="h6" className={Styles.livedataDashboardTitle}>
//           Live Dashboard - Refinery
//         </Typography>
//         <Box className={Styles.dateFilterWrapper}>
        

//             <TextField
//             label="Select Date"
//             type="date"
//             value={date}
//             onChange={(e) => setDate(e.target.value)}
//             InputLabelProps={{ shrink: true }}
//             style={{ width: "200px" }}
//             inputProps={{
//               max: new Date().toISOString().split("T")[0], // ⛔ prevents future dates
//             }}
//           />

//         </Box>
//       </Box>

//       {/* Live Data Cards */}
//       <Box px={2} py={2}>
//         <Typography
//           variant="subtitle1"
//           gutterBottom
//           className={Styles.livedataDashboardTitle}
//         >
//           Live Data
//         </Typography>
//         <Grid container spacing={2}>
//           {liveItems.map((item, idx) => (
//             <Grid item xs={12} md={4} sm={6} key={idx}>
//               <Card variant="outlined" sx={cardStyle}>
//                 <CardContent>
//                   <Typography variant="h6" className={Styles.livedataDashboardTitle}>
//                       {item.label}
//                     </Typography>
//                     <Typography variant="h5" fontWeight={600} color="primary">
//                       {item.value.toFixed(2)}{" "}
//                       <Typography component="span" variant="body1" fontWeight={600} color="primary">
//                         {item.unit}
//                       </Typography>
//                     </Typography>
//                     {item.updatedAt && (
//                       <Typography variant="body2"  mt={1}>
//                         Updated on: {new Date(item.updatedAt).toLocaleString("en-GB")}
//                       </Typography>
//                     )}
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))}
//         </Grid>
//       </Box>
//  {/* {new Date(item.updatedAt).toLocaleString("en-GB")} */}
//       {/* Shift-wise KG/hr */}
//       <Box px={2} py={2}>
//         <Typography
//           variant="subtitle1"
//           gutterBottom
//           className={Styles.livedataDashboardTitle}
//         >
//           Production-wise (KG)
//         </Typography>
//         <Card variant="outlined" sx={{ borderRadius: 3, boxShadow: 3, p: 2 }}>
//           <Grid container spacing={2} alignItems="center">
           

// <Grid item xs={12} md={6}>
//   <Box display="flex" flexDirection="column" alignItems="center">
//     {/* Shifts Row */}
//     <Box
//       display="flex"
//       justifyContent="center"
//       gap={4}
//       flexWrap="wrap"
//       mb={2}
//     >
//       {data.shiftData.map((item, idx) => (
//         <Box
//           key={idx}
//           textAlign="center"
//           sx={{
//             minWidth: 120,   // 👈 ensures space per shift box
//           }}
//         >
//           <Typography variant="body2" color="textSecondary">
//             Shift {item.shift}
//           </Typography>
//           <Typography variant="h6" fontWeight={600} color="primary">
//             {item.MFMProductionEntryData.quantity.toFixed(2)}{" "}
//             <Typography component="span" variant="body2" fontWeight={500}>
//               {item.MFMProductionEntryData.uom}
//             </Typography>
//           </Typography>
//         </Box>
//       ))}
//     </Box>

//     {/* Total Production */}
//     <Box textAlign="center">
//       <Typography variant="body2" color="textSecondary">
//         Total Production
//       </Typography>
//       <Typography variant="h6" fontWeight={600} color="primary">
//         {data?.totalProducdutionEntry}
//       </Typography>
//     </Box>
//   </Box>
// </Grid>

//      {/* Donut Chart */}        
//  <Grid item xs={12} md={6}>
//   <ResponsiveContainer width="100%" height={200}>
//     <PieChart>
//       {pieData.length === 0 || pieData.every(item => item.value === 0) ? (
//         // 🔸 Empty Pie Placeholder (gray ring)
//         <Pie
//           data={[{ name: 'No Data', value: 0 }]}
//           dataKey="value"
//           cx="40%"
//           cy="50%"
//           innerRadius={50}
//           outerRadius={70}
//         >
//           <Cell fill="#f0f0f0" /> {/* light gray fill */}
//         </Pie>
//       ) : (
//         // 🔹 Actual Pie Chart with data
//         <Pie
//           data={pieData}
//           dataKey="value"
//           nameKey="name"
//           cx="40%"
//           cy="50%"
//           innerRadius={50}
//           outerRadius={70}
          
//           label={({ name, percent }) =>
//             `${name} ${(percent * 100).toFixed(2)}%`
//           }
//         >
//           {pieData.map((_, i) => (
//             <Cell key={i} fill={COLORS[i % COLORS.length]} />
//           ))}
//           <Label
//           value="Production"
//           position="centerTop"
//           dy={-10}
//           style={{ fontSize: 14, fontWeight: 500, textAnchor: 'middle' }}
//         />
//         <Label
//           value="%"
//           position="centerBottom"
//           dy={20}
//           style={{ fontSize: 14, fontWeight: 500, textAnchor: 'middle' }}
//         />
//         </Pie>
//       )}

//       <Tooltip />
//       {/* <Legend
//         layout="vertical"
//         verticalAlign="middle"
//         align="right"
//          style={{borderRadius:'50%'}}
//       /> */}
//       <Legend
//   layout="vertical"
//   verticalAlign="middle"
//   align="right"
//   content={({ payload }) => (
//     <ul style={{ listStyle: 'none', padding: 0, marginRight: 0 }}>
//       {payload.map((entry, index) => (
//         <li
//           key={`item-${index}`}
//           style={{
//             display: 'flex',
//             alignItems: 'center',
//             marginBottom: 6,
//           }}
//         >
//           <div
//             style={{
//               width: 12,
//               height: 12,
//               backgroundColor: entry.color,
//               borderRadius: '50%', // 👈 Makes it a circle
//               marginRight: 8,
//             }}
//           />
//           <span style={{ fontSize: 12 ,marginRight: 28}}>{entry.value}</span>
//         </li>
//       ))}
//     </ul>
//   )}
// />

//     </PieChart>
//   </ResponsiveContainer>
// </Grid>

//           </Grid>
//         </Card>
//       </Box>

//       {/* Progress Bars for Production Loss */}

//       {/* Stacked Progress Bar for Production Loss */}
//       <Box px={2} py={2}>
//         <Typography
//           variant="subtitle1"
//           gutterBottom
//           className={Styles.livedataDashboardTitle}
//         >
//           Production Loss (KG)
//         </Typography>
//         <Card variant="outlined" sx={{ borderRadius: 3, boxShadow: 3, p: 2 }}>
//           <Box mb={2}>
//             <Typography variant="body2" gutterBottom>
//               Shift-wise Contribution
//             </Typography>

//             {/* Single Horizontal Bar with Shift Splits */}
//             <Box
//               display="flex"
//               height={20}
//               borderRadius={5}
//               overflow="hidden"
//               boxShadow={1}
//               sx={{ backgroundColor: "#eee" }}
//             >
//               {data.shiftData.map((item, idx) => {
//                 const color = COLORS[idx % COLORS.length];
//                 const value = item.MFMProductionLossData.quantity;
//                 const total = data.totalProductionLoss || 1; // avoid division by zero
//                 const percent = (value / total) * 100;

//                 return (
//                   <Box
//                     key={idx}
//                     sx={{
//                       width:`${percent}%`, // 👈 Force a minimum width for visibility
//                       minWidth: percent > 0 && percent < 1 ? "4px" : undefined, // fallback
//                       backgroundColor: color,
//                       display: "flex",
//                       alignItems: "center",
//                       justifyContent: "center",
//                       color: "#fff",
//                       fontSize: "0.75rem",
//                       fontWeight: 500,
//                     }}
//                   >
//                   {percent >= 10 && `Shift ${item.shift}`}
//                   </Box>
//                 );
//               })}
//             </Box>
//           </Box>

//           {/* Labels under the bar */}
//           <Grid container spacing={2} mt={1}>
//             {data.shiftData.map((item, idx) => {
//               const value = item.MFMProductionLossData.quantity;
//               const color = COLORS[idx % COLORS.length];
//               return (
//                 <Grid item xs={12} sm={4} key={idx}>
//                   <Box display="flex" alignItems="center">
//                     <Box
//                       sx={{
//                         width: 12,
//                         height: 12,
//                         backgroundColor: color,
//                         borderRadius: 1,
//                         mr: 1,
//                       }}
//                     />
//                     <Typography variant="body2">
//                       Shift {item.shift}: {value.toFixed(2)}{" "}
//                       {item.MFMProductionLossData.unit}
//                     </Typography>
//                   </Box>
//                 </Grid>
//               );
//             })}
//           </Grid>

//           <Divider sx={{ my: 2 }} />

//           {/* Total */}
//           <Typography variant="h6" align="right" color="primary">
//             Total Production Loss: {data.totalProductionLoss.toFixed(2)} KG
//           </Typography>
//         </Card>
//       </Box>

//     </Card>
//   );
// };

// export default RefineryData;






import React, { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  Grid,
  Box,
  Typography,
  Divider,
  LinearProgress,
  Container,
} from "@mui/material";
import { TextField } from "@material-ui/core";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Label 
} from "recharts";

import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import AppUrl from "../../../../utils/AppUrl";
import Styles from "../livedata.module.css";
import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";

// COLORS for Pie chart
const COLORS = ["#8884d8", "#82ca9d", "#ffc658"];

const RefineryData = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
   const [date, setDate] = useState(null);
 

  

const fetchLiveData = async (selectedDate) => {
  try {
    let url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=PLC_A`;
    if (selectedDate) url += `&date=${selectedDate}`;

    const res = await doGetApiCall({ url });
    const result = res?.data?.result || {};

    const shiftLabels = ["A", "B", "C"];
    const map = {};
    (result.ShiftWiseMFMProductionEntry ?? []).forEach((e) => {
      map[e.shift] = e;
    });

    const lossMap = {};
    (result.ShiftWiseMFMProductionLoss ?? []).forEach((e) => {
      lossMap[e.shift] = e;
    });

    const shiftData = shiftLabels.map((s) => ({
      shift: s,
      MFMProductionEntryData: map[s]?.MFMProductionEntryData ?? { quantity: 0, uom: "KG" },
      MFMProductionLossData: lossMap[s]?.MFMProductionLossData ?? { quantity: 0, uom: "KG" },
    }));

    const live = result.liveData || [];
    const crude = live.find((i) => i.name.toLowerCase().includes("crude")) || {};
    const dio = live.find((i) => i.name.toLowerCase().includes("dio")) || {};
  
    setData({
      crudeInlet: crude.averageRateOfFlow || 0,
      crudeInletUnit: crude.unit || "",
      crudeInletUpdatedAt: crude.latestTimestamp,
      crudeMaxValue:crude.maximum,
      dioFinal: dio.averageRateOfFlow || 0,
      dioFinalUnit: dio.unit || "",
      dioFinalUpdatedAt: dio.latestTimestamp,
      dioMaxValue:dio.maximum,
      shiftData,
      totalProductionLoss: result.ShiftWisetotalMFMProductionLoss || 0,
      totalProducdutionEntry: result.ShiftWisetotalMFMProductionEntry || 0,
    });

    return true; // ✅ success
  } catch (err) {
    console.error("Error fetching refinery live data:", err);
    return false; // ✅ failure
  } finally {
    setLoading(false);
  }
};

useEffect(() => {
  let isMounted = true;
  let timeoutId;

  const fetchLiveDataWithDelay = async () => {
    try {
      const success = await fetchLiveData(date);
      if (success && isMounted) {
        timeoutId = setTimeout(fetchLiveDataWithDelay, 30000); // 30 sec
      } else {
        console.warn("Stopping interval due to failed response");
      }
    } catch (err) {
      console.error("API error:", err);
    }
  };

  fetchLiveDataWithDelay(); // initial call

  return () => {
    isMounted = false;
    clearTimeout(timeoutId);
  };
}, [date]);


 const formatDate = (dateStr) => new Date(dateStr).toLocaleString("en-GB");

  const pieData = data?.shiftData?.map((e) => ({
    name: `Shift ${e.shift}`,
    value: e.MFMProductionEntryData.quantity,
  }));

 if (loading) {
    return (
      <Card variant="outlined" className={Styles.livedataDashboardContainer}>
        <Box className={Styles.livedataDashboardHeader} px={2} py={2}>
          <ClonosSkeletonLoading width="40%" height="32px" animation="wave" />
          <Box mt={2}>
            <ClonosSkeletonLoading width="200px" height="28px" animation="wave" />
          </Box>
        </Box>

        <Box px={2} py={2}>
          <Typography variant="subtitle1" gutterBottom>
            Live Data
          </Typography>
          <Grid container spacing={2}>
            {[1, 2].map((i) => (
              <Grid item xs={12} md={6} key={i}>
                <Card variant="outlined" sx={{ p: 2 }}>
                  <ClonosSkeletonLoading width="100%" height="200px" animation="wave" />
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>

        <Box px={2} py={2}>
          <Typography variant="subtitle1" gutterBottom>
            Shift-wise Production (KG)
          </Typography>
          <Card variant="outlined" sx={{ p: 2 }}>
            <ClonosSkeletonLoading width="100%" height="150px" animation="wave" />
          </Card>
        </Box>

        <Box px={2} py={2}>
          <Typography variant="subtitle1" gutterBottom>
            Production Loss (KG)
          </Typography>
          <Card variant="outlined" sx={{ p: 2 }}>
            <ClonosSkeletonLoading width="100%" height="50px" animation="wave" />
            <Box mt={2}>
              <ClonosSkeletonLoading width="100%" height="150px" animation="wave" />
            </Box>
          </Card>
        </Box>
      </Card>
    );
  }

  const cardStyle = {
    borderRadius: 3,
    boxShadow: 3,
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    height: "100%",
  };

  const liveItems = [
    {
      label: "Crude Inlet",
      value: data.crudeInlet,
      unit: data.crudeInletUnit,
      updatedAt: data.crudeInletUpdatedAt,
      maxValue: data.crudeMaxValue
    },
    {
      label: "Deo Final",
      value: data.dioFinal,
      unit: data.dioFinalUnit,
      updatedAt: data.dioFinalUpdatedAt,
      maxValue: data.dioMaxValue
    },
  ];

  
  
  return (
    <div variant="outlined" className={Styles.livedataDashboardContainer}>
      <Box className={Styles.livedataDashboardHeader}>
        <Typography variant="h6" className={Styles.livedataDashboardTitle}>
          Live Dashboard - Refinery
        </Typography>
        <Box className={Styles.dateFilterWrapper}>
        

            <TextField
            label="Select Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            style={{ width: "200px" }}
            inputProps={{
              max: new Date().toISOString().split("T")[0], // ⛔ prevents future dates
            }}
          />

        </Box>
      </Box>

      {/* Live Data Cards */}
      <Box px={2} py={2}>
        <Typography
          variant="subtitle1"
          gutterBottom
          className={Styles.livedataDashboardTitle}
        >
          Live Data
        </Typography>
        <Grid item xs={12} md={6}>
          
             
                <div className={Styles.gaugeRow}>
            {liveItems?.map((item) => {
              const gaugeSize = 220;
              const STROKE = 14;
              const CX = gaugeSize / 2;
              const CY = gaugeSize / 2 + 8;
              const R = Math.min(CX, CY) - STROKE;

              // Clamp value between 0 and item.maxValue
              const v = Math.max(0, Math.min(item.maxValue, item.value));

              // Convert to 0–1 internally, but still using v
              const theta = Math.PI * (1 - v / item.maxValue);

             
              const startX = CX - R;
              const endX = CX + R;
              const y = CY;
              const arcPath = `M ${startX} ${y} A ${R} ${R} 0 0 1 ${endX} ${y}`;

              const OUTER_R = R + STROKE / 2;
              const CLEARANCE = Math.max(3, STROKE * 0.15);
              const ix = CX + (OUTER_R + CLEARANCE) * Math.cos(theta);
              const iy = CY - (OUTER_R + CLEARANCE) * Math.sin(theta);

              const rotateDeg = (-theta * 180) / Math.PI + 180;

              const baseW = 19;
              const baseH = 17;
              const indScale = 1;

              return (
                <Card variant="outlined" sx={{ borderRadius: 3, boxShadow: 3 }}>
                  <CardContent className={Styles.cardContent}>
                    <div className={Styles.cardHeader}>
                      <Typography className={Styles.assetDashboardTitle}>{item.label}</Typography>
                      <hr className={Styles.divider} />
                    </div>

                    <div className={Styles.row}>
                      {/* Gauge */}
                      <div className={Styles.gaugeWrap}>
                        <svg
                          className={Styles.gaugeSvg}
                          width={gaugeSize}
                          height={gaugeSize}
                          viewBox={`0 0 ${gaugeSize} ${gaugeSize}`}
                          preserveAspectRatio="xMidYMid meet"
                        >
                          <defs>
                            <linearGradient
                              id={`grad-${item.id}`}
                              x1={startX}
                              y1={y}
                              x2={endX}
                              y2={y}
                              gradientUnits="userSpaceOnUse"
                            >
                              <stop offset="0%" stopColor="#F92836" />
                              <stop offset="50%" stopColor="#DAEC14" />
                              <stop offset="100%" stopColor="#239E58" />
                            </linearGradient>
                          </defs>

                          <path d={arcPath} stroke="#ddd" strokeWidth={STROKE} fill="none" strokeLinecap="round" />
                          <path d={arcPath} stroke={`url(#grad-${item.id})`} strokeWidth={STROKE} fill="none" strokeLinecap="round" />

                          <g
                            transform={`translate(${ix} ${iy}) rotate(${rotateDeg}) scale(${indScale}) translate(${-baseW / 2} ${-baseH / 2})`}
                            style={{ color: "#C5C5D8" }}
                          >
                            <path
                              d="M4.81363 15.5606L14.8286 13.1474C15.5238 12.9793 16.1199 12.5322 16.4744 11.9092L19.2767 6.97792C19.952 5.7911 19.5876 4.28581 18.4449 3.53613L13.6998 0.424687C13.1017 0.0310579 12.367 -0.0955421 11.6699 0.0725908L1.65684 2.4858C0.494333 2.7647 -0.218634 3.93174 0.0606079 5.09086L2.2054 13.9663C2.48464 15.1274 3.6531 15.8395 4.81363 15.5606Z"
                              fill="currentColor"
                            />
                          </g>
                        </svg>

                        {/* Overlay label */}
                        <div className={Styles.gaugeOverlay}>
                          <Typography variant="h6">
                            {item.value.toFixed(2)} {item.unit}
                          </Typography>
                          
                         {item.updatedAt && (
                          <Typography variant="caption" color="textSecondary" className={Styles.labelCaption}>
                            Last Updated: {formatDate(item.updatedAt)}
                          </Typography>
                        )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
        </Grid>
      </Box>
 {/* {new Date(item.updatedAt).toLocaleString("en-GB")} */}
      {/* Shift-wise KG/hr */}
      <Box px={2} py={2}>
        <Typography
          variant="subtitle1"
          gutterBottom
          className={Styles.livedataDashboardTitle}
        >
          Shift-wise Production (KG)
        </Typography>
        <Card variant="outlined" sx={{ borderRadius: 3, boxShadow: 3, p: 2 }}>
          <Grid container spacing={2} alignItems="center">
           

<Grid item xs={12} md={6}>
  <Box display="flex" flexDirection="column" alignItems="center">
    {/* Shifts Row */}
    <Box
      display="flex"
      justifyContent="center"
      gap={4}
      flexWrap="wrap"
      mb={2}
    >
      {data.shiftData.map((item, idx) => (
        <Box
          key={idx}
          textAlign="center"
          sx={{
            minWidth: 120,   // 👈 ensures space per shift box
          }}
        >
          <Typography variant="body2" color="textSecondary">
            Shift {item.shift}
          </Typography>
          <Typography variant="h6" fontWeight={600} color="primary">
            {item.MFMProductionEntryData.quantity.toFixed(2)}{" "}
            <Typography component="span" variant="body2" fontWeight={500}>
              {item.MFMProductionEntryData.uom}
            </Typography>
          </Typography>
        </Box>
      ))}
    </Box>

    {/* Total Production */}
    <Box textAlign="center">
      <Typography variant="body2" color="textSecondary">
        Total Production
      </Typography>
      <Typography variant="h6" fontWeight={600} color="primary">
        {data?.totalProducdutionEntry}
      </Typography>
    </Box>
  </Box>
</Grid>

     {/* Donut Chart */}        
 <Grid item xs={12} md={6}>
  <ResponsiveContainer width="100%" height={200}>
    <PieChart>
      {pieData.length === 0 || pieData.every(item => item.value === 0) ? (
        // 🔸 Empty Pie Placeholder (gray ring)
        <Pie
          data={[{ name: 'No Data', value: 0 }]}
          dataKey="value"
          cx="40%"
          cy="50%"
          innerRadius={50}
          outerRadius={70}
        >
          <Cell fill="#f0f0f0" /> {/* light gray fill */}
        </Pie>
      ) : (
        // 🔹 Actual Pie Chart with data
        <Pie
          data={pieData}
          dataKey="value"
          nameKey="name"
          cx="40%"
          cy="50%"
          innerRadius={50}
          outerRadius={70}
          
          label={({ name, percent }) =>
            `${name} ${(percent * 100).toFixed(2)}%`
          }
        >
          {pieData.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
          <Label
          value="Production"
          position="centerTop"
          dy={-10}
          style={{ fontSize: 14, fontWeight: 500, textAnchor: 'middle' }}
        />
        <Label
          value="%"
          position="centerBottom"
          dy={20}
          style={{ fontSize: 14, fontWeight: 500, textAnchor: 'middle' }}
        />
        </Pie>
      )}

      <Tooltip />
      {/* <Legend
        layout="vertical"
        verticalAlign="middle"
        align="right"
         style={{borderRadius:'50%'}}
      /> */}
      <Legend
  layout="vertical"
  verticalAlign="middle"
  align="right"
  content={({ payload }) => (
    <ul style={{ listStyle: 'none', padding: 0, marginRight: 0 }}>
      {payload.map((entry, index) => (
        <li
          key={`item-${index}`}
          style={{
            display: 'flex',
            alignItems: 'center',
            marginBottom: 6,
          }}
        >
          <div
            style={{
              width: 12,
              height: 12,
              backgroundColor: entry.color,
              borderRadius: '50%', // 👈 Makes it a circle
              marginRight: 8,
            }}
          />
          <span style={{ fontSize: 12 ,marginRight: 28}}>{entry.value}</span>
        </li>
      ))}
    </ul>
  )}
/>

    </PieChart>
  </ResponsiveContainer>
</Grid>

          </Grid>
        </Card>
      </Box>

      {/* Progress Bars for Production Loss */}

      {/* Stacked Progress Bar for Production Loss */}
      <Box px={2} py={2}>
        <Typography
          variant="subtitle1"
          gutterBottom
          className={Styles.livedataDashboardTitle}
        >
          Production Loss (KG)
        </Typography>
        <Card variant="outlined" sx={{ borderRadius: 3, boxShadow: 3, p: 2 }}>
          <Box mb={2}>
            <Typography variant="body2" gutterBottom>
              Shift-wise Contribution
            </Typography>

            {/* Single Horizontal Bar with Shift Splits */}
            <Box
              display="flex"
              height={20}
              borderRadius={5}
              overflow="hidden"
              boxShadow={1}
              sx={{ backgroundColor: "#eee" }}
            >
              {data.shiftData.map((item, idx) => {
                const color = COLORS[idx % COLORS.length];
                const value = item.MFMProductionLossData.quantity;
                const total = data.totalProductionLoss || 1; // avoid division by zero
                const percent = (value / total) * 100;

                return (
                  <Box
                    key={idx}
                    sx={{
                      width:`${percent}%`, // 👈 Force a minimum width for visibility
                      minWidth: percent > 0 && percent < 1 ? "4px" : undefined, // fallback
                      backgroundColor: color,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#fff",
                      fontSize: "0.75rem",
                      fontWeight: 500,
                    }}
                  >
                  {percent >= 10 && `Shift ${item.shift}`}
                  </Box>
                );
              })}
            </Box>
          </Box>

          {/* Labels under the bar */}
          <Grid container spacing={2} mt={1}>
            {data.shiftData.map((item, idx) => {
              const value = item.MFMProductionLossData.quantity;
              const color = COLORS[idx % COLORS.length];
              return (
                <Grid item xs={12} sm={4} key={idx}>
                  <Box display="flex" alignItems="center">
                    <Box
                      sx={{
                        width: 12,
                        height: 12,
                        backgroundColor: color,
                        borderRadius: 1,
                        mr: 1,
                      }}
                    />
                    <Typography variant="body2">
                      Shift {item.shift}: {value.toFixed(2)}{" "}
                      {item.MFMProductionLossData.unit}
                    </Typography>
                  </Box>
                </Grid>
              );
            })}
          </Grid>

          <Divider sx={{ my: 2 }} />

          {/* Total */}
          <Typography variant="h6" align="right" color="primary">
            Total Production Loss: {data.totalProductionLoss.toFixed(2)} KG
          </Typography>
        </Card>
      </Box>

    </div>
  );
};

export default RefineryData;
