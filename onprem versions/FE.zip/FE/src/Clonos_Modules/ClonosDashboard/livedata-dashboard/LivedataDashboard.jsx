import React, { useEffect, useState } from "react";
import { Routes, Route, useNavigate, useLocation } from "react-router-dom";
import Styles from './livedata.module.css';
import { Container, Card, Box,Typography, } from "@mui/material";
import { doGetApiCall } from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";


// Section Components (we'll define them separately later)
const RefineryDataPage = React.lazy(() => import('./sections/RefinaryData'));
const TankFarmDataPage = React.lazy(() => import('./sections/TankFarmData'));
const TankFarmFlowMeterDataPage = React.lazy(() => import('./sections/TankFarmFlowMeterData'));
const AdditivesAndSteamPage =React.lazy(() => import('./sections/AdditivesAndSteamData'));

function LivedataDashboard() {
  const [sections, setSections] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [dataLoadedOnce, setDataLoadedOnce] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    let url = `${AppUrl.getLiveDataDashboardSections}?clientId=2`;
    doGetApiCall({ url }).then((res) => {
      const resultObj = res?.data?.result || {};
      setSections(resultObj); 
      setDataLoadedOnce(true);
      setIsLoading(false);
    }).catch((err) => {
      console.error("Error fetching sections:", err);
      setSections([]);
      setDataLoadedOnce(true);
      setIsLoading(false);
    });
  }, []);

  const isSections = sections.length === 0;

  const renderPlantSelector = () => {
    return (
      <>
        {!dataLoadedOnce && isLoading ? (
          <div className={Styles.loaderWrapper}>
            <ClonosSpinner />
          </div>
        ) : isSections ? (
          <div variant="outlined" className={Styles.livedataDashboardContainer}>
            <p className={Styles.emptyMessage}>
              Please Contact Admin to Access this page
            </p>
          </div>
        ) : (
          <div variant="outlined" className={Styles.livedataDashboardContainer}>
             <Box className={Styles.livedataDashboardHeader}>
                  <Typography variant="h6" className={Styles.livedataDashboardTitle}>
                    Live Dashboard 
                  </Typography>
              </Box>
            <div className={Styles.plantSelectorContainer}>
              {/* <h3 className={Styles.plantSelectorTitle}>Select a Section</h3> */}
              <div className={Styles.plantCardWrapper}>
                {Object.entries(sections).map(([key, value], index) => {
                  const route = generateRouteFromSection(value);
                  return (
                    <Card
                      key={index}
                      className={Styles.plantCard}
                      onClick={() => navigate(route)}
                    >
                      {key}
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </>
    );
  };

  const generateRouteFromSection = (sectionName) => {
    switch (sectionName) {
      case "PLC_A":
        return "refinery";
      case "KRPL TANKFARM-FLOW METER E&H":
        return "tank-farmflow-meter";
      case "KRPL TANKFARM-TANK E&H":
        return "tank-farm";
        case "ADDITIVES AND STEAM":
        return "additives-steam";
      default:
        return "unknown";
    }
  };

  // If no nested route is selected, show card selector
  const isAtBaseRoute = location.pathname === "/live-dashboard";

  return (
  <>
      {isAtBaseRoute ? (
        renderPlantSelector()
      ) : (
        <Routes>
          <Route path="refinery" element={<RefineryDataPage />} />
          <Route path="tank-farmflow-meter" element={<TankFarmFlowMeterDataPage />} />
          <Route path="tank-farm" element={<TankFarmDataPage />} />
          <Route path="additives-steam"element={<AdditivesAndSteamPage/>} />
        </Routes>
      )}
   
  </> 
  );
}

export default LivedataDashboard;
