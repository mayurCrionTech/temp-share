import React, { useEffect, useState } from "react";
import { Card, CardContent, Typography, Grid, Box } from "@mui/material";
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall } from "../../../utils/ClonosApi";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";

const RefineryLiveData = () => {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    setIsLoading(true);
    const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=PLC_A`;

    try {
      const res = await doGetApiCall({ url });
      const result = res?.data?.result;
      setData({
        crudeInlet: result?.crudeInlet,
        dioFinal: result?.dioFinal,
      });
    } catch (err) {
      console.error("Error fetching refinery data", err);
      setData(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatDate = (dateStr) =>
    new Date(dateStr).toLocaleString("en-GB", {
      hour12: true,
    });

  if (isLoading) return <ClonosSpinner />;

  const refineryItems = [
    {
      label: "Crude Inlet",
      value: data?.crudeInlet?.averageRateOfFlow ?? 0,
      unit: data?.crudeInlet?.unit,
      updatedAt: data?.crudeInlet?.latestTimestamp,
    },
    {
      label: "Deo Final",
      value: data?.dioFinal?.averageRateOfFlow ?? 0,
      unit: data?.dioFinal?.unit,
      updatedAt: data?.dioFinal?.latestTimestamp,
    },
  ];

  return (
    <Box px={2} py={2}>
      <Typography variant="h5" mb={2}>Refinery Live Data</Typography>
      <Grid container spacing={3}>
        {refineryItems.map((item, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <Card sx={{ minHeight: 120 }}>
              <CardContent>
                <Typography variant="h6">{item.label}</Typography>
                <Typography variant="h4" color="primary">
                  {item.value?.toFixed(2)} {item.unit}
                </Typography>
                <Typography variant="body2">
                  Updated on: {formatDate(item.updatedAt)}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default RefineryLiveData;
