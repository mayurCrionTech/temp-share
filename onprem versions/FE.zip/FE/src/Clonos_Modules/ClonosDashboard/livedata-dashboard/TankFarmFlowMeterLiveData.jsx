import React, { useEffect, useState } from "react";
import { Card, CardContent, Typography, Grid, Box } from "@mui/material";
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall } from "../../../utils/ClonosApi";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";

const TankFarmFlowMeterLiveData = () => {
  const [meters, setMeters] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    setIsLoading(true);
    const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-FLOW METER E&H`;

    try {
      const res = await doGetApiCall({ url });
      const result = res?.data?.result?.data || [];

      const formatted = result.map((entry) => ({
        group: entry.group,
        averageFlowRate: entry.averageFlowRate,
        flowRateTag: entry.flowRateTag,
        flowRateCount: entry.flowRateCount,
        totalizerTag: entry.totalizerTag,
        totalizerValue: entry.totalizerValue,
        totalizerTimestamp: entry.totalizerTimestamp,
        unitOfFlowRate: entry.unitOfFlowRate,
        unitOfToatalizer: entry.unitOfToatalizer,
      }));

      setMeters(formatted);
    } catch (err) {
      console.error("Flow Meter error:", err);
      setMeters([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatDate = (dateStr) =>
    new Date(dateStr).toLocaleString("en-GB", { hour12: true });

  if (isLoading) return <ClonosSpinner />;

  return (
    <Box px={2} py={2}>
      <Typography variant="h5" mb={2}>Tank Farm Flow Meter Live Data</Typography>
      <Grid container spacing={3}>
        {meters.map((meter, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Card>
              <CardContent>
                <Typography variant="h6" align="center">{meter.group}</Typography>
                <Typography><b>Flow Rate:</b> {meter.averageFlowRate} {meter.unitOfFlowRate}</Typography>
                <Typography><b>Totalizer:</b> {meter.totalizerValue} {meter.unitOfToatalizer}</Typography>
                {meter.totalizerTimestamp && (
                  <Typography variant="body2">
                    Updated on: {formatDate(meter.totalizerTimestamp)}
                  </Typography>
                )}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default TankFarmFlowMeterLiveData;
