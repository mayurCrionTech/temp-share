import React, { useEffect, useState } from "react";
import { Card, CardContent, Typography, Grid, Box } from "@mui/material";
import AppUrl from "../../../utils/AppUrl";
import { doGetApiCall } from "../../../utils/ClonosApi";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";

const TankFarmLiveData = () => {
  const [tanks, setTanks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    setIsLoading(true);
    const url = `${AppUrl.getLiveDataDashboard}?clientId=2&sectionName=KRPL TANKFARM-TANK E&H`;

    try {
      const res = await doGetApiCall({ url });
      const result = res?.data?.result?.data || [];

      const formatted = result.map((tank) => {
        const tagMap = {};
        tank.tags.forEach((tag) => {
          const name = tag.tagName.toLowerCase();
          if (name.includes("level")) {
            tagMap.level = tag;
          } else if (name.includes("volume")) {
            tagMap.volume = tag;
          } else if (name.includes("temperature")) {
            tagMap.temperature = tag;
          }
        });

        return {
          tankName: tank.tankName,
          productName: tank.productName,
          readings: [tagMap.level, tagMap.temperature, tagMap.volume].filter(Boolean),
        };
      });

      setTanks(formatted);
    } catch (err) {
      console.error("Tank Farm error:", err);
      setTanks([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatDate = (dateStr) =>
    new Date(dateStr).toLocaleString("en-GB", { hour12: true });

  if (isLoading) return <ClonosSpinner />;

  return (
    <Box px={2} py={2}>
      <Typography variant="h5" mb={2}>Tank Farm Live Data</Typography>
      <Grid container spacing={3}>
        {tanks.map((tank, index) => {
          const [level, temp, volume] = tank.readings || [];
          const timestamp = level?.timestamp || temp?.timestamp || volume?.timestamp;

          return (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card>
                <CardContent>
                  <Typography variant="h6" align="center">
                    {tank.tankName} - {tank.productName}
                  </Typography>
                  {level && (
                    <Typography><b>Level:</b> {level.value} {level.unit}</Typography>
                  )}
                  {temp && (
                    <Typography><b>Temperature:</b> {temp.value} {temp.unit}</Typography>
                  )}
                  {volume && (
                    <Typography><b>Volume:</b> {volume.value} {volume.unit}</Typography>
                  )}
                  {timestamp && (
                    <Typography variant="body2">
                      Updated on: {formatDate(timestamp)}
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
};

export default TankFarmLiveData;
