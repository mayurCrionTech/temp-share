import React from "react";
import { PieChart, Pie, Cell, Tooltip } from "recharts";

const logColors = ["#60D468", "#E5B82F" ];
const emptyColor = "#E0E0E0"; // Light gray for empty ring

const formatKey = (key) => {
  return key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase());
};

const ReportsChart = ({ data }) => {
  const requiredKeys = { completed: 0, pendingForApproval: 0 };

  let reportsData = Object.entries({ ...requiredKeys, ...data })
    .filter(([key]) => key !== "totalCount")
    .map(([key, value], index) => ({
      name: formatKey(key),
      value,
      color: logColors[index % logColors.length],
    }));

  const totalReportsCount = data?.totalCount || 0;
  const hasData = reportsData.some((item) => item.value > 0);

  return (
    <div className="chartWrapper">
      <div style={{ display: "flex", alignItems: "center", gap: "15px", width: "100%" }}>
        {/* Chart Container */}
        <div style={{ flex: "0 0 50%", display: "flex", justifyContent: "center" }}>
          <PieChart width={160} height={160}>
            {/* Always Show Empty Ring in Background */}
            <Pie
              data={[{ value: 1 }]} // Dummy data for full ring
              dataKey="value"
              cx="50%"
              cy="50%"
              outerRadius={60}
              innerRadius={40}
              fill={emptyColor}
              stroke="none"
            />

            {/* Main Pie (Only when data exists) */}
            {hasData && (
              <Pie
                data={reportsData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={60}
                innerRadius={40}
                label={({ cx, cy }) => (
                  <>
                    <text
                      x={cx}
                      y={cy - 5}
                      textAnchor="middle"
                      dominantBaseline="central"
                      style={{ fontSize: "16px", fontWeight: "bold" }}
                    >
                      {totalReportsCount || 0}
                    </text>
                    <text
                      x={cx}
                      y={cy + 12}
                      textAnchor="middle"
                      dominantBaseline="central"
                      style={{ fontSize: "12px", fill: "#666" }}
                    >
                      Total Reports
                    </text>
                  </>
                )}
                labelLine={false}
              >
                {reportsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            )}
            <Tooltip />
          </PieChart>
        </div>

        {/* Custom Legend Container */}
        <div style={{ display: "flex", flexDirection: "column", width: "100%" }}>
          {reportsData.map((entry, index) => (
            <div
              key={`legend-${index}`}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-evenly",
                width: "100%",
                padding: "5px",
                whiteSpace: "nowrap",
              }}
            >
              {/* Round Color Indicator */}
              <span
                style={{
                  display: "inline-block",
                  width: 12,
                  height: 12,
                  borderRadius: "50%",
                  backgroundColor: entry.color,
                  marginRight: "10px",
                  marginLeft: "-30px", // Keeping your previous spacing
                }}
              />

              {/* Legend Name */}
              <span
                style={{
                  color: "#333",
                  flexGrow: 1,
                  textTransform: "capitalize",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  width: "30%",
                }}
              >
                {entry.name}
              </span>

              {/* Report Data Value */}
              <span
                style={{
                  fontWeight: "bold",
                  minWidth: "30px",
                  textAlign: "right",
                  marginRight:"10px"
                }}
              >
                {entry.value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ReportsChart;
