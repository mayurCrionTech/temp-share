import React, { useEffect, useState } from "react";
import Styles from './analytics-dashboard.module.css';
import { Container, Card } from "@mui/material";
import { doGetApiCall } from "../../../utils/ClonosApi";
import DateFilters from '../DateFilters';
import AppUrl from "../../../utils/AppUrl";
import HistoricalTrends from "./HistoricalTrends"
import LiveData from "./LiveData";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";


function AnalyticsDashboard () {
  
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [latestData, setLatestData] = useState([]);
  const [previousIds, setPreviousIds] = useState(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [dataLoadedOnce, setDataLoadedOnce] = useState(false);

  const formattedStartDate = startDate ? new Date(startDate).toISOString().slice(0, 16) : "";
  const formattedEndDate = endDate ? new Date(endDate).toISOString().slice(0, 16) : "";

  const fetchLiveData = (start = null, end = null) => {
    setIsLoading(true);

    let url = `${AppUrl.getLatestAnalyticsEntries}?clientId=3`;

    if (start && end) {
      url += `&startDate=${start}&endDate=${end}`;
    }

    doGetApiCall({ url })
      .then((res) => {
        if (res?.data?.result) {
          const extractedData = Object.entries(res.data.result).map(([key, value]) =>
            value
              ? {
                  id: value._id,
                  name: key.replace(/([A-Z])/g, " $1").trim(),
                  value: value.fieldValue || 0,
                  units: value.units ?? "",
                  min: value.range?.min ?? null,
                  normal:value.range?.normal ?? null,
                  max: value.range?.max ?? null,
                  lastUpdatedAt: value.sampleCollectedDate,
                }
              : null
          ).filter(Boolean);

          const newIds = new Set(extractedData.map((item) => item.id));
          const isNewDataAvailable = [...newIds].some((id) => !previousIds.has(id));

          if (isNewDataAvailable || !dataLoadedOnce) {
            setLatestData(extractedData);
            setPreviousIds(newIds);
          }
        } else {
          setLatestData([]);
        }
        setDataLoadedOnce(true);
      })
      .catch((err) => {
        console.error("Error fetching live data:", err);
        setLatestData([]);
        setDataLoadedOnce(true);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  useEffect(() => {
    fetchLiveData();
    const interval = setInterval(() => fetchLiveData(formattedStartDate, formattedStartDate), 120000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (formattedStartDate && formattedEndDate) {
      if (new Date(formattedStartDate) > new Date(formattedEndDate)) {
        // If startDate is after endDate, show empty (0) data
        const zeroData = latestData.map(item => ({
          ...item,
          value: 0,
          lastUpdatedAt: "",
        }));
        setLatestData(zeroData);
      } else {
        fetchLiveData(formattedStartDate, formattedEndDate);
      }
    }
  }, [formattedStartDate, formattedEndDate]);


// const isDataEmpty =!latestData 
const isDataEmpty = latestData.length === 0;


  return (
 <>
      {/* Initial loading spinner before any data is loaded */}
      {!dataLoadedOnce && isLoading ? (
        <div className={Styles.loaderWrapper}>
          <ClonosSpinner />
        </div>
      ) : isDataEmpty ? (
        // Show message if data loaded but empty
        <Card variant="outlined" className={Styles.analyticsDashboardContainer}>
          <p style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            textAlign: "center",
            fontSize: "25px",
            color: "#575757"
          }}>
            Please Contact Admin to Access this page
          </p>
        </Card>
      ) : (
        // Show full analytics dashboard
        <Card variant="outlined" className={Styles.analyticsDashboardContainer}>
          <div className={Styles.analyticsDashboardHeader}>
            <h4 className={Styles.analyticsDashboardTitle}>Analytics Dashboard</h4>
            <div className={Styles.dateFilterWrapper}>
              <DateFilters
                startDate={startDate}
                endDate={endDate}
                setStartDate={setStartDate}
                setEndDate={setEndDate}
              />
            </div>
          </div>

          {isLoading ? (
            <div className={Styles.loaderWrapper}>
              <ClonosSpinner />
            </div>
          ) : (
            <main>
              <Container style={{ marginBottom: "20px" }}>
                <LiveData latestData={latestData} />
                <br />
                <HistoricalTrends startDate={startDate} endDate={endDate} />
              </Container>
            </main>
          )}
        </Card>
      )}
  </>

  );
}

export default AnalyticsDashboard;
