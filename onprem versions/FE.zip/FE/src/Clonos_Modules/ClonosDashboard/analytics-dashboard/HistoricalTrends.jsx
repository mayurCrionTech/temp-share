import React, { useEffect, useState } from "react";
import { Grid, Typography, Card, CardContent } from "@mui/material";
import TrendChart from "./TrendChart";
import Styles from "./analytics-dashboard.module.css";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { doGetApiCall } from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";

const METRICS = [
  "oxygen",
  "nitrogen",
  "hydrogen",
  "methane",
  "ethylene",
  "ethane",
  "acetylene",
  "propylenePropane",
  "carbondioxide",
  "carbonmonoxide",
  "totalCombustibles"
];

const HistoricalTrends = ({ startDate, endDate }) => {
  const [historicalData, setHistoricalData] = useState({});
  const [loadingMetrics, setLoadingMetrics] = useState(new Set());

  useEffect(() => {
    fetchHistoricalData();
  }, [startDate, endDate]);

  const fetchHistoricalData = () => {
    METRICS.forEach((metric) => {
      setLoadingMetrics((prev) => new Set(prev).add(metric));

      let url = `${AppUrl.getAnalyticsDashboard}?${metric}=true&clientId=3`;

      if (startDate && endDate) {
  const formattedStartDate = startDate
    ? new Date(startDate).toISOString().split('T')[0]
    : "";
  const formattedEndDate = endDate
    ? new Date(endDate).toISOString().split('T')[0]
    : "";
  url += `&startDate=${formattedStartDate}&endDate=${formattedEndDate}`;
  
}

      
     
      doGetApiCall({ url })
        .then((res) => {
          if (res?.data?.result) {
            setHistoricalData((prev) => ({
              ...prev,
              [metric]: res.data.result[metric],
            }));
          }
        })
        .catch((err) => console.error(`Error fetching ${metric} data:`, err))
        .finally(() => {
          setLoadingMetrics((prev) => {
            const updated = new Set(prev);
            updated.delete(metric);
            return updated;
          });
        });
    });
  };


  return (
    <div>
      <Typography
        variant="h6"
        gutterBottom
        className={Styles.analyticsDashboardTitle}
      >
        Historical Trends
      </Typography>
      <Grid container spacing={3}>
        {METRICS.map((metric) => (
          <Grid item xs={12} sm={6} key={metric}>
            {loadingMetrics.has(metric) ? (
              // Show Skeleton while loading
              <Card style={{ borderRadius: "16px", padding: "10px", minHeight: "300px" }}>
                <CardContent>
                  <Typography variant="h6">
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <ClonosSkeletonLoading
                        width="60%"
                        height="50px"
                        animation="wave"
                      />
                      <ClonosSkeletonLoading
                        width="30%"
                        height="50px"
                        animation="wave"
                      />
                    </div>
                  </Typography>
                  <ClonosSkeletonLoading
                    width="100%"
                    height="200px"
                    animation="wave"
                  />
                </CardContent>
              </Card>
            ) : historicalData[metric]?.data?.length ? (
              // Show Chart if data exists
              <TrendChart
                title={metric}
                data={historicalData[metric].data}
                min={historicalData[metric].data[0]?.range?.min ?? null}
                max={historicalData[metric].data[0]?.range?.max ?? null}
                normal={historicalData[metric].data[0]?.range?.normal ?? null}
                units={historicalData[metric].data[0]?.units}
              />
            ) : (
              // Show fallback message if no data
              <Card
                style={{
                  borderRadius: "16px",
                  padding: "10px",
                  
                  minHeight: "415px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: 0.8,
                }}
              >
                <CardContent>
                  <Typography
                    variant="h6"
                    align="center"
                    color="textSecondary"
                    style={{ fontWeight: 500 }}
                  >
                    Data not available for {metric}
                  </Typography>
                </CardContent>
              </Card>
            )}
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default HistoricalTrends;
