import React, { useState, useMemo } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine, Brush
} from "recharts";
import { Modal, IconButton } from "@material-ui/core";
import ZoomOutMapIcon from '@material-ui/icons/ZoomOutMap';
import CloseRoundedIcon from '@material-ui/icons/CloseRounded';

import {
  Card, CardContent, Typography, Box, FormControl, InputLabel, Select, MenuItem
} from "@material-ui/core";

import Styles from './analytics-dashboard.module.css'

const capitalizeWords = (str) => {
  return str.replace(/([A-Z])/g, " $1").trim().replace(/\b\w/g, (char) => char.toUpperCase());
};

const TrendChart = ({ title, data = [], min, max,normal, units = "" }) => {
  const [zoomRange, setZoomRange] = useState(null);
  const [aggregation, setAggregation] = useState("none");
  const [timeframe, setTimeframe] = useState("none");
  const [openModal, setOpenModal] = useState(false);

  const formattedData = useMemo(() => {
  const sortedData = data
    .map((entry) => ({
      ...entry,
      timestamp: new Date(entry.sampleCollectedDate).getTime(),
      fieldValue: parseFloat(entry.fieldValue) || 0
    }))
    .sort((a, b) => a.timestamp - b.timestamp);

  const uniqueByTimestamp = new Map();

  for (const item of sortedData) {
    const existing = uniqueByTimestamp.get(item.timestamp);
    // If no entry yet, or current one is a peak, replace it
    if (!existing || item.isPeak) {
      uniqueByTimestamp.set(item.timestamp, item);
    }
  }

  return [...uniqueByTimestamp.values()];
}, [data]);



 
  const formatXAxis = (timestamp) => {
    if (!timestamp) return "";
    const date = new Date(timestamp);
  
    const visibleData = zoomRange
      ? formattedData.filter(d => d.timestamp >= zoomRange.start && d.timestamp <= zoomRange.end)
      : formattedData; // Use formattedData instead of aggregatedData
  
    if (visibleData.length === 0) return "";
  
    const firstDate = new Date(visibleData[0].timestamp);
    const lastDate = new Date(visibleData[visibleData.length - 1].timestamp);
    const diffInDays = Math.floor((lastDate - firstDate) / (24 * 60 * 60 * 1000));
  
    if (diffInDays > 365) {
      return date.getFullYear().toString();
    } else if (diffInDays > 31) {
      return `${date.toLocaleString("default", { month: "short" })} ${date.getFullYear()}`;
    } else if (diffInDays > 7) {
      return `${date.getDate()} ${date.toLocaleString("default", { month: "short" })}`;
    } else {
      return `${date.getDate()} ${date.toLocaleString("default", { month: "short" })} ${date.getHours()}:${date.getMinutes().toString().padStart(2, "0")}`;
    }
  };
  
  const handleBrushChange = (e) => {
    if (e && e.startIndex !== undefined && e.endIndex !== undefined) {
      const start = formattedData[e.startIndex]?.timestamp;
      const end = formattedData[e.endIndex]?.timestamp;
      if (start && end) {
        if (start === formattedData[0]?.timestamp && end === formattedData[formattedData.length - 1]?.timestamp) {
          setZoomRange(null);
        } else {
          setZoomRange({ start, end });
        }
      }
    } else {
      setZoomRange(null);
    }
  };

  
  const aggregatedData = useMemo(() => {
    if (aggregation === "none") return formattedData;
    const grouped = {};
  
    formattedData.forEach((entry) => {
      const date = new Date(entry.timestamp);
      let key;
  
      if (timeframe === "monthly") {
        key = `${date.getFullYear()}-${date.getMonth() + 1}`;
      } else if (timeframe === "weekly") {
        key = `${date.getFullYear()}-W${Math.ceil(date.getDate() / 7)}`;
      } else if (timeframe === "day") {
        key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
      } else {
        key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} ${date.getHours()}:00`;
      }
  
      if (!grouped[key]) {
        grouped[key] = { timestamps: [], values: [] };
      }

      grouped[key].timestamps.push(entry.timestamp);
      grouped[key].values.push(entry.fieldValue);
    });
  
    return Object.keys(grouped)
      .map((key) => {
        const { timestamps, values } = grouped[key];
        const averageTimestamp = timestamps.length
          ? timestamps.reduce((sum, t) => sum + t, 0) / timestamps.length
          : timestamps[0];

        // Calculate mean first (used in variance & stddev)
        const mean = values.reduce((a, b) => a + b, 0) / values.length;

          let aggregatedValue;
          switch (aggregation) {
            case "sum":
              aggregatedValue = values.reduce((a, b) => a + b, 0);
              break;
            case "average":
              aggregatedValue = values.reduce((a, b) => a + b, 0) / values.length;
              break;
            case "min":
              aggregatedValue = Math.min(...values);
              break;
            case "max":
              aggregatedValue = Math.max(...values);
              break;
            case 'count':
              aggregatedValue = values.length;
              break; 
            case "median":
              const sortedValues = [...values].sort((a, b) => a - b);
              const mid = Math.floor(sortedValues.length / 2);
              aggregatedValue =
                sortedValues.length % 2 === 0
                  ? (sortedValues[mid - 1] + sortedValues[mid]) / 2
                  : sortedValues[mid];
              break;
              case "variance":
                // Population variance
                aggregatedValue = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
                break;
              case "stddev":
                // Population standard deviation
                const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
                aggregatedValue = Math.sqrt(variance);
                break;
              default:
                aggregatedValue = values[0]; // Default case
            }
    
          return {
            timestamp: averageTimestamp,
            fieldValue: aggregatedValue,
          };
      })
      .sort((a, b) => a.timestamp - b.timestamp);
  }, [formattedData, aggregation, timeframe]);
  
  return (
    <>
    
    <Card style={{ borderRadius: "16px", padding: "10px" }}>
      <CardContent>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h6" className={Styles.analyticsDashboardTitle}>{capitalizeWords(title)}</Typography>
          <Box display="flex">
          <FormControl size="small" variant="outlined" style={{ marginRight: 20 }}>
            <InputLabel>Aggregation</InputLabel>
            <Select value={aggregation} onChange={(e) => setAggregation(e.target.value)} label="Aggregation">
              <MenuItem value="none">None</MenuItem>
              <MenuItem value="sum">Sum</MenuItem>
              <MenuItem value="average">Average</MenuItem>
              <MenuItem value="min">Min</MenuItem>
              <MenuItem value="max">Max</MenuItem>
              <MenuItem value="count">Count</MenuItem>
              <MenuItem value="median">Median</MenuItem>
              <MenuItem value="variance">Variance</MenuItem>
              <MenuItem value="stddev">Standard Deviations</MenuItem>
            </Select>
           </FormControl>

            {aggregation !== "none" && (
              <FormControl size="small" variant="outlined" style={{ marginRight: 16 }}>
                <InputLabel>Timeframe</InputLabel>
                <Select value={timeframe} onChange={(e) => setTimeframe(e.target.value)} label="Timeframe">
                  <MenuItem value="none">None</MenuItem>
                  <MenuItem value="day">Day</MenuItem>
                  <MenuItem value="weekly">Weekly</MenuItem>
                  <MenuItem value="monthly">Monthly</MenuItem>
                </Select>
              </FormControl>
            )}
          </Box>
        </Box>
        <div style={{ position: "relative" }}>
           <ResponsiveContainer height={320}>
          <LineChart data={aggregatedData} width={500}
          height={300}
          margin={{ top: 30, right: 35, left: 10, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="timestamp" 
              tickFormatter={formatXAxis} 
              domain={["dataMin", "dataMax"]} 
              type="number" 
              tickCount={5} 
            />
            <YAxis 
              domain={[0, max + 50]} 
              tickFormatter={(value) => value.toFixed(2)} 
            />
            <Tooltip 
              labelFormatter={(label) => new Date(label).toLocaleString("en-GB", { 
                year: "numeric", 
                month: "2-digit", 
                day: "2-digit", 
                hour: "2-digit", 
                minute: "2-digit", 
                second: "2-digit",
                hour12: false 
              })} 
              formatter={(value) => [`${value.toFixed(2)} ${units}`, "Value"]} 
            />

            <Legend 
              iconType="circle" 
              formatter={() => (
                <span style={{ color: "black", verticalAlign: "middle" }}>
                  {units}
                </span>
              )}
              
              wrapperStyle={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "10px 0" }} 
            />
            
             {min !== null && max !== null && normal !==null && ( 
                <>
                  <ReferenceLine y={min} stroke="red" strokeDasharray="5 5" label={`Min`} />
                   <ReferenceLine y={normal} stroke="yellow" strokeDasharray="5 5" label={`Normal`} />
                  <ReferenceLine y={max} stroke="green" strokeDasharray="5 5" label={`Max`} />
                </>
             )}

            <Line 
              type="monotone" 
              dataKey="fieldValue" 
              stroke="#6885B1" 
              //stroke="#8884d8"
              strokeWidth={2} 
              dot={({ cx, cy, payload }) =>
                    payload.isPeak ? (
                      <>
                        <text
                          x={cx}
                          y={cy - 15}
                         textAnchor="middle"
                          fontSize={12}
                          fill="#000"
                        >
                          {new Date(payload.sampleCollectedDate).toLocaleDateString('en-US', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </text>
                        <circle cx={cx} cy={cy} r={4} fill="#2C4E87" />
                      </>
                    ) : null
                  }
            />
            
            <Brush 
              dataKey="timestamp" 
              height={30} 
              stroke="#6885B1" 
              //stroke="#8884d8"
              travellerWidth={12} 
              onChange={handleBrushChange} 
              tickFormatter={formatXAxis} 
            />
          </LineChart>
        
        </ResponsiveContainer>


      <IconButton
        onClick={() => setOpenModal(true)}
        title="Expand Chart"
        style={{
          position: "absolute",
          bottom:-30,
          right: -20,
          backgroundColor: "#fff",
          // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
          zIndex: 1, // optional, ensures it appears above chart
        }}
      >
    <ZoomOutMapIcon />
  </IconButton>
        </div>
       
      </CardContent>
    </Card>


     <Modal open={openModal} onClose={() => setOpenModal(false)}>
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            background: 'white',
            padding: 20,
            borderRadius: 10,
            outline: 'none',
            width: '90%',
            height: '90%',
            overflow: 'auto'
          }}>
   
           <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}mt={5}>
             <Typography variant="h6" className={Styles.analyticsDashboardTitle}>{capitalizeWords(title)}</Typography>
          <Box display="flex">
          <FormControl size="small" variant="outlined" style={{ marginRight: 20 }}>
            <InputLabel>Aggregation</InputLabel>
            <Select value={aggregation} onChange={(e) => setAggregation(e.target.value)} label="Aggregation">
              <MenuItem value="none">None</MenuItem>
              <MenuItem value="sum">Sum</MenuItem>
              <MenuItem value="average">Average</MenuItem>
              <MenuItem value="min">Min</MenuItem>
              <MenuItem value="max">Max</MenuItem>
              <MenuItem value="count">Count</MenuItem>
              <MenuItem value="median">Median</MenuItem>
              <MenuItem value="variance">Variance</MenuItem>
              <MenuItem value="stddev">Standard Deviations</MenuItem>
            </Select>
           </FormControl>

            {aggregation !== "none" && (
              <FormControl size="small" variant="outlined" style={{ marginRight: 16 }}>
                <InputLabel>Timeframe</InputLabel>
                <Select value={timeframe} onChange={(e) => setTimeframe(e.target.value)} label="Timeframe">
                  <MenuItem value="none">None</MenuItem>
                  <MenuItem value="day">Day</MenuItem>
                  <MenuItem value="weekly">Weekly</MenuItem>
                  <MenuItem value="monthly">Monthly</MenuItem>
                </Select>
              </FormControl>
            )}
          </Box>
        </Box>
      <div style={{ position: "relative" }}>
           <ResponsiveContainer width="100%" height={500}>
          <LineChart data={aggregatedData} width={500}
          height={400}
          margin={{ top: 30, right: 35, left: 10, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="timestamp" 
              tickFormatter={formatXAxis} 
              domain={["dataMin", "dataMax"]} 
              type="number" 
              tickCount={5} 
            />
            <YAxis 
              domain={[0, max + 50]} 
              tickFormatter={(value) => value.toFixed(2)} 
            />
            <Tooltip 
              labelFormatter={(label) => new Date(label).toLocaleString("en-GB", { 
                year: "numeric", 
                month: "2-digit", 
                day: "2-digit", 
                hour: "2-digit", 
                minute: "2-digit", 
                second: "2-digit",
                hour12: false 
              })} 
              formatter={(value) => [`${value.toFixed(2)} ${units}`, "Value"]} 
            />

            <Legend 
              iconType="circle" 
              formatter={() => (
                <span style={{ color: "black", verticalAlign: "middle" }}>
                  {units}
                </span>
              )}
              
              wrapperStyle={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "10px 0" }} 
            />
            
             {min !== null && max !== null && normal !==null &&(
                <>
                  <ReferenceLine y={min} stroke="red" strokeDasharray="5 5" label={`Min`} />
                  <ReferenceLine y={normal} stroke="yellow" strokeDasharray="5 5" label={`Normal`} />
                  <ReferenceLine y={max} stroke="green" strokeDasharray="5 5" label={`Max`} />
                </>
             )}

            <Line 
              type="monotone" 
              dataKey="fieldValue" 
              stroke="#6885B1" 
              //stroke="#8884d8"
              strokeWidth={2} 
              dot={({ cx, cy, payload }) =>
                    
                    payload.isPeak? (
                      <>
                        <text
                          x={cx}
                          y={cy - 15}
                         textAnchor="middle"
                          fontSize={12}
                          fill="#000"
                        >
                          {new Date(payload.sampleCollectedDate).toLocaleDateString('en-US', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </text>
                        <circle cx={cx} cy={cy} r={4} fill="#2C4E87" />
                      </>
                    ) : null
                  }
            />
            
            <Brush 
              dataKey="timestamp" 
              height={30} 
              stroke="#6885B1" 
              //stroke="#8884d8"
              travellerWidth={12} 
              onChange={handleBrushChange} 
              tickFormatter={formatXAxis} 
            />
          </LineChart>
        
        </ResponsiveContainer>

        <IconButton
          onClick={() => setOpenModal(false)}
          title="Close"
          style={{
            position: "absolute",
            top:-120,
            right: -22,
            backgroundColor: "#fff",
            // boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
            zIndex: 1, // optional, ensures it appears above chart
            
          }}
        >
            <CloseRoundedIcon style={{fontSize:"30"}}/>
        </IconButton>

        </div> 
     </div>
    </Modal>


</>

  );
};

export default TrendChart;
