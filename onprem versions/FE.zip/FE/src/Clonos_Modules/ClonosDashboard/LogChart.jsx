import React from "react";
import { PieChart, Pie, Cell, Tooltip } from "recharts";

const logColors = ["#60D468", "#E5B82F", "#06337E" ];
const emptyColor = "#E0E0E0"; // Light gray for empty ring

const formatKey = (key) => {
  return key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase());
};

const LogChart = ({ data }) => {
  const requiredKeys = { completed: 0, liveLogs: 0, scheduled: 0 };

  // Merge incoming data with default keys
  let logData = Object.entries({ ...requiredKeys, ...data })
    .filter(([key]) => key !== "totalCount")
    .map(([key, value], index) => ({
      name: formatKey(key),
      value,
      color: logColors[index % logColors.length],
    }));

  const totalLogCount = data?.totalCount || 0;

  // Check if all values are 0 (no real data)
  const hasData = logData.some((item) => item.value > 0);

  return (
    <>
      <div className="chartWrapper">
        <div style={{ display: "flex", alignItems: "center", gap: "15px", width: "100%", marginRight:"auto"}}>
          {/* Chart Container */}
          <div style={{ flex: "0 0 50%", display: "flex", justifyContent: "center" }}>
            <PieChart width={160} height={160}>
              {/* Always Show Empty Ring in Background */}
              <Pie
                data={[{ value: 1 }]} // Dummy data for full ring
                dataKey="value"
                cx="50%"
                cy="50%"
                outerRadius={60}
                innerRadius={40}
                fill={emptyColor}
                stroke="none"
              />

              {/* Main Pie (Only when data exists) */}
              {hasData && (
                <Pie
                  data={logData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={60}
                  innerRadius={40}
                  label={({ cx, cy }) => (
                    <>
                      <text
                        x={cx}
                        y={cy - 5} // Moves the count slightly up
                        textAnchor="middle"
                        dominantBaseline="central"
                        style={{ fontSize: "16px", fontWeight: "bold" }}
                      >
                        {totalLogCount}
                      </text>
                      <text
                        x={cx}
                        y={cy + 12} // Moves "Total Logs" slightly down
                        textAnchor="middle"
                        dominantBaseline="central"
                        style={{ fontSize: "12px", fill: "#666" }}
                      >
                        Total Logs
                      </text>
                    </>
                  )}
                  labelLine={false}
                >
                  {logData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              )}
              <Tooltip />
            </PieChart>
          </div>

          {/* Custom Legend Container */}
          <div style={{ display: "flex", flexDirection: "column", width: "100%" }}>
            {logData.map((entry, index) => (
              <div
                key={`legend-${index}`}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  width: "100%",
                  padding: "5px",
                  whiteSpace: "nowrap",
                }}
              >
                {/* Round Color Indicator */}
                <span
                  style={{
                    display: "inline-block",
                    width: 12,
                    height: 12,
                    borderRadius: "50%",
                    backgroundColor: entry.color,
                    marginRight: "10px",
                  }}
                />

                {/* Legend Name */}
                <span
                  style={{
                    color: "#333",
                    flexGrow: 1,
                    textTransform: "capitalize",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    width: "40%",
                    marginRight: "20px",
                  }}
                >
                  {entry.name}
                </span>

                {/* Log Data Value (Always Show 0 if Empty) */}
                <span
                  style={{
                    fontWeight: "bold",
                    minWidth: "30px",
                    textAlign: "right",
                  }}
                >
                  {entry.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default LogChart;

