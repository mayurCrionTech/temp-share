import React, { useEffect, useState,useMemo } from "react";
import Styles from './asset-dashboard.module.css';
import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
import { Box } from '@mui/material'
import { doGetApiCall } from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";
import GaugeCard from "./asset-dashboard-component/GaugeCard";
import ValueCard from "./asset-dashboard-component/ValueCard";
import TableCard from "./asset-dashboard-component/TableCard";


function AssetDashboard() {
    const URL = handleSegregateURL();
    const [pagination,setPagination]=useState({page:1, limit: 5})
    const [assetData,setAssetData]=useState({})
   
  
 function getAssetDashboards(){
      doGetApiCall(({url:AppUrl?.getAssetDashboards}))
      .then((res)=>{
         
          setAssetData(res?.data?.result)
      })
 }


useEffect(() => {
  getAssetDashboards();

}, []);


  return (

     <>
    	 {
				(!URL?.unity && !URL?.AR && !URL?.VR) &&
        
              <ClonosGridNav  items={[
					{
						icon: TotalAssetsIcon,
						iconBg: '#E7EFFF',
						title: 'Total Assets',
						// count: assetCounts?.totalAssets || 0,
                        count:  assetData?.totalAssets
					},
					{
						icon: ActiveAssetsIcon,
						iconBg: '#EBFAEC',
						title: 'Active Assets',
						count: assetData?.activeAssets    
					},
					{
						icon: BreakdownAssets,
						iconBg: '#FBEDEF',
						title: 'Breakdown Assets',
						count: assetData?.breakdownAssets
					}
				]}>
					
				</ClonosGridNav>
         
				
			}
  

			  
			<div className={Styles.assetDashboardContainer}>
				<main>
					<GaugeCard assetData={assetData} />
					<ValueCard assetData={assetData} />
					<TableCard />
				</main>
			</div>
				

</>
  );
}

export default AssetDashboard;

