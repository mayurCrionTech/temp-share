import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../asset-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";


function ValueCard({assetData}) {

//  const valueData = [
//     {
//       id: 4,
//       title: "Mean Time Between Failures (MTBF)",
//       subtitle: "Average Uptime between two Breakdowns",
//       value: assetData?.meanTimeBetweenFailures,
//       // color: "#13C63B",
//       unit: "Hours",
//       scaleTitle:"MTBF (Scale)",
//       scale: [
//         { color: "#60D468", text: "Excellent", range: "< 1 Hour" },
//         { color: "#FEBC2F", text: "Good", range: "1 - 4 Hours" },
//         { color: "#D24B5A", text: "Poor", range: "> 8 Hours" },
//       ],
//     },
//     {
//       id: 5,
//       title: "Mean Time To Repair (MTTR)",
//       subtitle: "Average time to restore an asset after failure",
//       value:assetData?.meanTimeToRepair ,
//       // color: "#F92836",
//       unit: "Hours",
//       scaleTitle:"MTTR (Scale)",
//       scale: [
//         { color: "#60D468", text: "Excellent", range: "< 1 Hour" },
//         { color: "#FEBC2F", text: "Good", range: "1 - 8 Hours" },
//         { color: "#D24B5A", text: "Poor", range: "> 8 Hours" },
//       ],
//     },
//     {
//       id: 6,
//       title: "Down Time",
//       subtitle: "Total time during failures / Unplanned stops",
//       value: assetData?.downTime,
//       // color: "#DAEC14",
//       unit: "Hours",
//       scaleTitle:"Downtime (Scale)",
//       scale: [
//         { color: "#60D468", text: "Excellent", range: "< 5 Hours" },
//         { color: "#FEBC2F", text: "Good", range: "6 - 40 Hours" },
//         { color: "#D24B5A", text: "Poor", range: "> 40 Hours" },
//       ],
//     },
//   ];

const valueData = [
  {
    id: 4,
    title: "Mean Time Between Failures (MTBF)",
    subtitle: "Average Uptime between two Breakdowns",
    value: assetData?.meanTimeBetweenFailures,
    unit: "Hours",
    scaleTitle: "MTBF (Scale)",
    scale: [
      { color: "#60D468", text: "Excellent", range: "> 8 Hours", min: 8.01, max: Infinity },
      { color: "#FEBC2F", text: "Good", range: "1 - 8 Hours", min: 1, max: 8 },
      { color: "#D24B5A", text: "Poor", range: "< 1 Hour", min: -Infinity, max: 0.99 },
     
    ],
  },
  {
    id: 5,
    title: "Mean Time To Repair (MTTR)",
    subtitle: "Average time to restore an asset after failure",
    value: assetData?.meanTimeToRepair,
    unit: "Hours",
    scaleTitle: "MTTR (Scale)",
    scale: [
      { color: "#60D468", text: "Excellent", range: "< 1 Hour", min: -Infinity, max: 0.99 },
      { color: "#FEBC2F", text: "Good", range: "1 - 8 Hours", min: 1, max: 8 },
      { color: "#D24B5A", text: "Poor", range: "> 8 Hours", min: 8.01, max: Infinity },
    ],
  },
  {
    id: 6,
    title: "Down Time",
    subtitle: "Total time during failures / Unplanned stops",
    value: assetData?.downTime,
    unit: "Hours",
    scaleTitle: "Downtime (Scale)",
    scale: [
      { color: "#60D468", text: "Excellent", range: "< 6 Hours", min: -Infinity, max: 5.99 },
      { color: "#FEBC2F", text: "Good", range: "6 - 40 Hours", min: 6, max: 40 },
      { color: "#D24B5A", text: "Poor", range: "> 40 Hours", min: 40.01, max: Infinity },
    ],
  },
];

//   const matchScale = (value, scale) => {
//   if (value === null || !Array.isArray(scale)) return null;

//   for (const row of scale) {
//     const s = String(row.range).toLowerCase().trim();

//     // 1) Between: "1 - 4", "6 - 40"
//     const between = s.match(/(-?\d+(\.\d+)?)\s*(?:-|–|to)\s*(-?\d+(\.\d+)?)/);
//     if (between) {
//       const min = parseFloat(between[1]);
//       const max = parseFloat(between[3]);
//       if (value >= min && value <= max) return row;
//       continue;
//     }

//     // 2) Less-than: "< 5", "<= 5"
//     const ltEq = s.match(/^<=\s*(-?\d+(\.\d+)?)/);
//     if (ltEq && value <= parseFloat(ltEq[1])) return row;

//     const lt = s.match(/^<\s*(-?\d+(\.\d+)?)/);
//     if (lt && value < parseFloat(lt[1])) return row;

//     // 3) Greater-than: ">= 8", "> 8"
//     const gtEq = s.match(/^>=\s*(-?\d+(\.\d+)?)/);
//     if (gtEq && value >= parseFloat(gtEq[1])) return row;

//     const gt = s.match(/^>\s*(-?\d+(\.\d+)?)/);
//     if (gt && value > parseFloat(gt[1])) return row;
//   }

//   return null; // no match
// };


const matchScale = (value, scale) => {
  if (value === null || !Array.isArray(scale)) return null;

  for (const row of scale) {
    const { min = -Infinity, max = Infinity } = row;
    if (value >= min && value <= max) return row;
  }

  return null;
};

  return (
   <>
   <div className={Styles.section}>
  <div className={Styles.valueCardContainer}>
    {valueData?.map((item, i) => (
      <Card key={i}  sx={{ borderRadius: '16px' }}>
        <CardContent className={Styles.cardContent}>
          <Typography className={Styles.assetDashboardTitle}>{item?.title}</Typography>
          <Typography variant="body2" color="textSecondary" style={{fontSize:"12px"}}>
            {item?.subtitle}
          </Typography>
          <hr className={Styles.divider} />

          {/* left value + right scale */}
          <div className={Styles.valueContentRow}>
            <div className={Styles.valueNumber}>
              {(() => {
                const active = matchScale(item.value, item.scale);
                const color = active?.color || item?.color || '#23A45E';
                return (
                  <>
                    <span className={Styles.valueBig} style={{ color }}>
                      {item?.value}
                    </span>
                    <span className={Styles.valueUnit} style={{ color }}>
                      {item?.unit}
                    </span>
                  </>
                );
              })()}
            </div>

            <div className={Styles.scaleCol}>
              <Typography className={Styles.scaleTitle}>{item?.scaleTitle}</Typography>
              {item.scale.map((ele, j) => (
                <div key={j} className={Styles.scaleRow}>
                  <div className={Styles.scaleLeft}>
                    <span className={Styles.legendDot} style={{ backgroundColor: ele.color }} />
                    <Typography className={Styles.scaleText}>{ele.text}</Typography>
                  </div>
                  <Typography className={Styles.scaleRange}>{ele.range}</Typography>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    ))}
  </div>
</div>

   </>
  )
}

export default ValueCard