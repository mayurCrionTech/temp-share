import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../asset-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination,  } from "@mui/material";
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { setSerialNumber } from "../../../../utils/clonosCommon";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import {  Tooltip } from "@material-ui/core";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function UptimeRatioGrid() {

    const [uptimeRatioData,setUptimeRatioData]=useState({})
    
        const [pagination, setPagination] = useState({page:1,limit:5})
      
  
        function getuptimeRatioData(pagination){
            doGetApiCall(({url:`assetDashBoards/activehours?activeAssetHours=true`,params:pagination}))
            .then((res)=>{
              
                setUptimeRatioData(res?.data?.result)
            })
       }

    // Load initial data
  useEffect(() => {
    getuptimeRatioData(pagination);
  }, [pagination]);




    // ✅ Helper to calculate total hours in each month
const getTotalUptime = (monthStr) => {
  const [monthName, year] = monthStr.split(" ");
  const monthIndex = new Date(`${monthName} 1, ${year}`).getMonth();
  const days = new Date(year, monthIndex + 1, 0).getDate();
  return days * 24;
};

// ✅ Split bar component for each month

const SplitUptimeBar = ({ actual, total, month }) => {
  const uptimePercent = (actual / total) * 100;

  const barWidth = 10;
  const barHeight = 30;

  // Extract month and short year (e.g., "Oct 2025" → "Oct 25")
  const [monthName, fullYear] = month.split(" ");
  const shortYear = fullYear?.slice(-2);

  // Common container style
  const barContainerStyle = {
    width: barWidth,
    height: barHeight,
    borderRadius: 2,
    overflow: "hidden",
    flexShrink: 0,
    flexGrow: 0,
    position: "relative",
  };

  let bar;

  // 🟥 Full breakdown
  if (actual === 0) {
    bar = <div style={{ ...barContainerStyle, backgroundColor: "#D24B5A" }} />;
  }
  // 🟩 Full uptime
  else if (actual === total) {
    bar = <div style={{ ...barContainerStyle, backgroundColor: "#60D468" }} />;
  }
  // 🟥🟩 Split bar
  else {
    bar = (
      <div style={{ ...barContainerStyle, backgroundColor: "#D24B5A" }}>
        <div
          style={{
            position: "absolute",
            bottom: 0,
            width: "100%",
            height: `${uptimePercent}%`,
            backgroundColor: "#60D468",
          }}
        />
      </div>
    );
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <Tooltip title={`${monthName} - ${shortYear}`}>
        {bar}
      </Tooltip>
     
      {/* <span
        style={{
          marginTop: 3,
          fontSize: "10px",
          color: "#333",
          textAlign: "center",
          whiteSpace: "nowrap",
        }}
      >
        {`${monthName} ${shortYear}`}
      </span> */}
    </div>
  );
};





const getCondition = (uptimeHoursArr, months) => {
  if (!uptimeHoursArr?.length || !months?.length) return "-";

  let totalUptime = 0;
  let totalPossible = 0;

  months.forEach((month, i) => {
    const total = getTotalUptime(month);
    const actual = uptimeHoursArr[i] ?? 0;
    totalUptime += actual;
    totalPossible += total;
  });

  const percentage = (totalUptime / totalPossible) * 100;

  if (percentage > 90) return "Excellent";
  if (percentage >= 50) return "Good";
  return "Poor";
};


   
   // ✅ Handle empty data safely
    const uptimeRows = uptimeRatioData?.assets?.data?.map((asset, index) => {
        const condition = getCondition(
          asset.monthlyActiveHours,
          uptimeRatioData.months
        );
      return {
        id: index + 1,
        name: asset.assetName,
        monthlyActiveHours: asset.monthlyActiveHours,
        condition,
      };
    }) || [];

  // ✅ Define MUI columns
  const uptimeColumns = [
    { field: "name", headerName: "ASSET NAME", flex: 1.5 },

    {
      field: "months",
      headerName: "LAST 12 MONTHS",
      flex:1.5,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        const months = uptimeRatioData?.months || [];
        const hours = params.row.monthlyActiveHours || [];

        return (
          <div style={{ display: "flex", gap: 4, justifyContent: "center", gap: "6px", flexWrap: "nowrap",  }}>
            {months.map((month, i) => {
              const total = getTotalUptime(month);
              const actual = hours[i] ?? 0;
              return <SplitUptimeBar key={i} actual={actual} total={total} month={month} />;
            })}
          </div>
        );
      },
    },

    {
      field: "condition",
      headerName: "CONDITION",
      flex: 1,
      headerAlign: "center",
      align: "center",
      headerClassName: "datadrid_common_header",
      cellClassName: "datagrid_common_cell",
      renderCell: (params) => (
        <p
          style={{
            ...statusStyleStaticData[params?.row?.condition],
            padding: "0.25rem 0.5rem",
            borderRadius: "0.25rem",
            cursor: "default",
          }}
        >
          {params?.row?.condition
            ? statusStaticData[params?.row?.condition]
            : "-"}
        </p>
      ),
    },
  ];

  return (
    <>
                    <Grid item xs={12} sm={6} md={4}>
                      <Card sx={{ borderRadius: '16px' }}>
                        <CardContent className={Styles.cardContent}>
                      <div className={Styles.cardHeader}>
    <Typography className={Styles.assetDashboardTitle}>Uptime Ratio</Typography>
    <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
     % of total operational hour’s without failure
    </Typography>
    <hr className={Styles.divider} />
</div>
 
    <ClonosDataGrid
      rows={setSerialNumber(uptimeRows,pagination.page,pagination.limit)}
      columns={uptimeColumns}
      uniqueIdField="id"
      onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
      isLoading={false}
      totalCount={uptimeRatioData?.assets?.totalDataCount}
      pageLimit={5}  
      checkboxSelection={false}
      // paginationMode="client"
    />
    </CardContent>
    </Card>
    </Grid>
       </>
  );
}

export default UptimeRatioGrid