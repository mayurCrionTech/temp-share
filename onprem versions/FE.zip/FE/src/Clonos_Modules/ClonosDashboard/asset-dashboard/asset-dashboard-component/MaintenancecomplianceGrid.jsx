import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../asset-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import { statusStaticData, statusStyleStaticData } from "../../../../Constants/StaticData";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { setSerialNumber } from "../../../../utils/clonosCommon";
import { doGetApiCall } from "../../../../utils/ClonosApi";
import {Tooltip } from "@material-ui/core";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function MaintenancecomplianceGrid() {
     
   const [maintenancedata,setMaintenancedata]=useState({})
   const [pagination, setPagination] = useState({page:1,limit:5})

      function getMaintainenceData(pagination){
             doGetApiCall(({url:`/assetDashBoards/activehours?onTimeWorkorders=true`,params:pagination}))
             .then((res)=>{
                 
                 setMaintenancedata(res?.data?.result)
             })
        }

  useEffect(() => {
    getMaintainenceData(pagination);
  }, [pagination]);


    // 🧮 Helper: calculate maintenance condition based on days difference
const getmaintenanceCondition = (planned, executed) => {
  const diffHours = Math.abs(planned - executed);
  const diffDays = diffHours / 24;

  if (diffDays <= 1) return "Excellent"; // within 24 hrs
  if (diffDays <= 7) return "Good";      // 1–7 days
  return "Poor";                         // >7 days
};

// 🎨 Bar component (vertical color bar per month)
const SplitMaintenanceBar = ({ planned, executed, month }) => {
  const diffHours = Math.abs(planned - executed);
  const diffDays = diffHours / 24;

  let color = "#D24B5A"; // 🔴 Poor
  if (diffDays <= 1) color = "#60D468"; // 🟩 Excellent
  else if (diffDays <= 7) color = "#FFD93D"; // 🟨 Good

  const [monthName, fullYear] = month.split(" ");
  const shortYear = fullYear?.slice(-2);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
       <Tooltip title={`${monthName} - ${shortYear}`}>
            <div
              style={{
                width: 10,
                height: 30,
                borderRadius: 2,
                backgroundColor: color,
                flexShrink: 0,
                flexGrow: 0,
              }}
            />
          </Tooltip>
      
        
      {/* <span style={{ fontSize: "10px", marginTop: 3, color: "#333" }}>
        {monthName}
      </span> */}
    </div>
  );
};

  
 
 
     // ✅ Convert data into grid-friendly format
   const maintenanceRows = maintenancedata?.assets?.data?.map((asset, i) => {
   const months = maintenancedata.months;
 
   // Calculate overall average difference
   const totalPlanned = asset.monthlyPlannedHours.reduce((a, b) => a + b, 0);
   const totalExecuted = asset.monthlyExecutedHours.reduce((a, b) => a + b, 0);
   const avgPlanned = totalPlanned / 12;
   const avgExecuted = totalExecuted / 12;

   const overallCondition = getmaintenanceCondition(avgPlanned, avgExecuted);
 
 
   return {
     id: i + 1,
     name: asset.assetName,
     months,
     monthlyPlannedHours: asset.monthlyPlannedHours,
     monthlyExecutedHours: asset.monthlyExecutedHours,
     condition: overallCondition,
   };
 });
 
  
    const maintenanceColumns = [
   {
     field: "name",
     headerName: "ASSET NAME",
     flex: 1.5,
   },
   {
     field: "months",
     headerName: "LAST 12 MONTHS",
     flex: 1.5,
     headerAlign: "center",
     align: "center",
     renderCell: (params) => {
       const months = params.row.months || [];
       const planned = params.row.monthlyPlannedHours || [];
       const executed = params.row.monthlyExecutedHours || [];
 
       return (
         <div
           style={{
             display: "flex",
             gap: "6px",
             justifyContent: "center",
             flexWrap: "nowrap",
           }}
         >
           {months.map((month, i) => (
            
             <SplitMaintenanceBar
               key={i}
               planned={planned[i]}
               executed={executed[i]}
               month={month}
             />
           ))}
         </div>
       );
     },
   },
    {
       field: "condition",
       headerName: "CONDITION",
       flex: 1,
       headerAlign: "center",
       align: "center",
       headerClassName: "datadrid_common_header",
       cellClassName: "datagrid_common_cell",
       renderCell: (params) => (
         <p
           style={{
             ...statusStyleStaticData[params?.row?.condition],
             padding: "0.25rem 0.5rem",
             borderRadius: "0.25rem",
             cursor: "default",
           }}
         >
           {params?.row?.condition
             ? statusStaticData[params?.row?.condition]
             : "-"}
         </p>
       ),
     },
 ];
 
   return (
      <>
      <Grid item xs={12}>
      <Card sx={{ borderRadius: '16px' }}>
        <CardContent className={Styles.cardContent}>
       <div className={Styles.cardHeader}>
          <Typography className={Styles.assetDashboardTitle}>Maintenance compliance</Typography>
          <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
           Composite score (Condition Monitoring, Vibration, temperature, etc.)
          </Typography>
          <hr className={Styles.divider} />
        </div>
  
 
         <ClonosDataGrid
           rows={setSerialNumber(maintenanceRows,pagination.page,pagination.limit)}
           columns={maintenanceColumns}
           uniqueIdField="id"
           onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
           // isLoading={isLoading}
           totalCount={maintenancedata?.assets?.totalDataCount}
           pageLimit={5}  
           checkboxSelection={ false }
          //  paginationMode="client"
         />

         </CardContent>
         </Card>
         </Grid>
       </>
   );
 
}

export default MaintenancecomplianceGrid