import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../asset-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function GaugeCard({assetData}) {


   const getLabel = (value, scale) => {
  if (value === null) return "Loading...";
    
  for (const s of scale) {
    if (s.min !== undefined && s.max !== undefined) {
      if (value >= s.min && value <= s.max) return s.text;
    } else if (s.max !== undefined) {
      if (value < s.max) return s.text;
    } else if (s.min !== undefined) {
      if (value >= s.min) return s.text;
    }
  }
  return "N/A";
};

// const gaugeData = [
//   {
//     id: 1,
//     title: "Asset Availability",
//     subtitle: "% of time asset is available for use",
//     value: assetData?.assetAvailability,
//     subLabel: "of assets are available",
//     scaleTitle: "Asset Availability (Scale)",
//     scale: [
//       { color: "#13C63B", text: "Excellent", min: 99, max: 100, range: "99 - 100%" },
//       { color: "#DAEC14", text: "Good", min: 90, max: 98, range: "90 - 98%" },
//       { color: "#F92836", text: "Poor", max: 80, range: "<80%" },
//     ],
//   },
//   {
//     id: 2,
//     title: "Asset Utilization",
//     subtitle: "Actual Productive Time vs Available Time",
//     value: assetData?.assetUtilization,
//     subLabel: "of assets are utilized",
//     scaleTitle: "Asset Utilization (Scale)",
//     scale: [
//       { color: "#13C63B", text: "Excellent", min: 96, max: 100, range: "100%" },
//       { color: "#DAEC14", text: "Good", min: 80, max: 95, range: "80 - 95%" },
//       { color: "#F92836", text: "Poor", max: 70, range: "<70%" },
//     ],
//   },
//   {
//     id: 3,
//     title: "Overall Equipment Effectiveness",
//     subtitle: "Combined Measure of availability, Performance, Quality",
//     value: 78,
//     subLabel: "of Overall Equipment Effectiveness",
//     scaleTitle: "Overall Equipment Effectiveness (Scale)",
//     scale: [
//       { color: "#13C63B", text: "Excellent", min: 91, max: 100, range: "100%" },
//       { color: "#DAEC14", text: "Good", min: 75, max: 90, range: "75 - 90%" },
//       { color: "#F92836", text: "Poor", max: 60, range: "<60%" },
//     ],
//   },
// ].map(item => ({
//   ...item,
//   label: getLabel(item.value, item.scale),
// }));

const gaugeData = [
  {
    id: 1,
    title: "Asset Availability",
    subtitle: "% of time asset is available for use",
    value: assetData?.assetAvailability,
    subLabel: "of assets are available",
    scaleTitle: "Asset Availability (Scale)",
    scale: [
      { color: "#13C63B", text: "Excellent", min: 99, max: 100, range: "99 - 100%" },
      { color: "#DAEC14", text: "Good", min: 80, max: 98.99, range: "80 - 98.99%" },
      { color: "#F92836", text: "Poor", max: 79.99, range: "< 80%" },
    ],
  },
  {
    id: 2,
    title: "Asset Utilization",
    subtitle: "Actual Productive Time vs Available Time",
    value: assetData?.assetUtilization,
    subLabel: "of assets are utilized",
    scaleTitle: "Asset Utilization (Scale)",
    scale: [
      { color: "#13C63B", text: "Excellent", min: 100, range: "100%" },
      { color: "#DAEC14", text: "Good", min: 70, max: 99.99, range: "70 - 99.99%" },
      { color: "#F92836", text: "Poor", max: 69.99, range: "< 70%" },
    ],
  },
  // {
  //   id: 3,
  //   title: "Overall Equipment Effectiveness",
  //   subtitle: "Combined Measure of availability, Performance, Quality",
  //   value: 78,
  //   subLabel: "of Overall Equipment Effectiveness",
  //   scaleTitle: "Overall Equipment Effectiveness (Scale)",
  //   scale: [
  //     { color: "#13C63B", text: "Excellent", min: 90, max: 100, range: "90 - 100%" },
  //     { color: "#DAEC14", text: "Good", min: 75, max: 90, range: "75 - 89%" },
  //     { color: "#F92836", text: "Poor", max: 75, range: "<75%" },
  //   ],
  // },
].map(item => ({
  ...item,
  label: getLabel(item.value, item.scale),
}));



  return (
   <>
      <div className={Styles.section}>
          
  <div className={Styles.gaugeRow}>

            {gaugeData?.map((item, index) => {
              const gaugeSize = 170;  // match .gaugeWrap (170px)
              const STROKE = 14;
              const CX = gaugeSize / 2;
              const CY = gaugeSize / 2 + 8;
              const R = Math.min(CX, CY) - STROKE;
    
              const v = Math.max(0, Math.min(100, item.value));
              const theta = Math.PI * (1 - v / 100);
    
              const startX = CX - R;
              const endX = CX + R;
              const y = CY;
              const arcPath = `M ${startX} ${y} A ${R} ${R} 0 0 1 ${endX} ${y}`;
    
              const OUTER_R = R + STROKE / 2;
              const CLEARANCE = Math.max(3, STROKE * 0.15);
              const ix = CX + (OUTER_R + CLEARANCE) * Math.cos(theta);
              const iy = CY - (OUTER_R + CLEARANCE) * Math.sin(theta);
    
              const rotateDeg = (-theta * 180) / Math.PI + 180;
    
              const baseW = 19;
              const baseH = 17;
              const indScale = 1;
    
          
    
    
              return (
               
                  <Card sx={{ borderRadius: '16px' }}>
                    <CardContent className={Styles.cardContent}>
                      <div className={Styles.cardHeader}>
                        <Typography className={Styles.assetDashboardTitle}>{item?.title}</Typography>
                        <Typography variant="body2" style={{fontSize:"12px"}} color="textSecondary">
                          {item?.subtitle}
                        </Typography>
                        <hr className={Styles.divider} />
                      </div>
    
                      <div className={Styles.row}>
                        {/* Gauge */}
                        <div className={Styles.gaugeWrap}>
                          <svg
                            className={Styles.gaugeSvg}
                            width={gaugeSize}
                            height={gaugeSize}
                            viewBox={`0 0 ${gaugeSize} ${gaugeSize}`}
                            preserveAspectRatio="xMidYMid meet"
                          >
                            <defs>
                              <linearGradient
                                id={`grad-${item.id}`}
                                x1={startX}
                                y1={y}
                                x2={endX}
                                y2={y}
                                gradientUnits="userSpaceOnUse"
                              >
                                <stop offset="0%" stopColor="#F92836" />
                                <stop offset="50%" stopColor="#DAEC14" />
                                <stop offset="100%" stopColor="#239E58" />
                              </linearGradient>
                            </defs>
    
                            <path d={arcPath} stroke="#ddd" strokeWidth={STROKE} fill="none" strokeLinecap="round" />
                            <path d={arcPath} stroke={`url(#grad-${item.id})`} strokeWidth={STROKE} fill="none" strokeLinecap="round" />
    
                            <g
                              transform={`translate(${ix} ${iy}) rotate(${rotateDeg}) scale(${indScale}) translate(${-baseW / 2} ${-baseH / 2})`}
                              style={{ color: '#C5C5D8' }}
                            >
                              <path
                                d="M4.81363 15.5606L14.8286 13.1474C15.5238 12.9793 16.1199 12.5322 16.4744 11.9092L19.2767 6.97792C19.952 5.7911 19.5876 4.28581 18.4449 3.53613L13.6998 0.424687C13.1017 0.0310579 12.367 -0.0955421 11.6699 0.0725908L1.65684 2.4858C0.494333 2.7647 -0.218634 3.93174 0.0606079 5.09086L2.2054 13.9663C2.48464 15.1274 3.6531 15.8395 4.81363 15.5606Z"
                                fill="currentColor"
                              />
                            </g>
                          </svg>
                        
    
                          {/* Overlay label */}
                          <div className={Styles.gaugeOverlay}>
                            <Typography variant="h6" >
                              {item.label}
                            </Typography>
                            <Typography variant="caption" color="textSecondary" className={Styles.labelCaption}>
                              {item.value}% {item.subLabel || ''}
                            </Typography>
                          </div>
                        </div>
    
                        {/* Scale (small text) */}
                        <div className={Styles.scaleCol}>
                          <Typography className={Styles.scaleTitle}>{item?.scaleTitle}</Typography>
                          {item.scale.map((ele, i) => (
                            <div key={i} className={Styles.scaleRow}>
                              <Typography className={Styles.scaleText}>{ele.text}</Typography>
                              <Typography className={Styles.scaleRange}>{ele.range}</Typography>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                
              );
            })}
          </div>
        </div>
   </>
  )
}

export default GaugeCard
