import React, { useEffect, useState,useMemo } from "react";
import Styles from  '../asset-dashboard.module.css';
// import { handleSegregateURL, setSerialNumber } from "../../../utils/clonosCommon";
// import { TotalAssetsIcon } from "../../../assets/AssetsSVGComponents/TotalAssets";
// import { ActiveAssetsIcon } from "../../../assets/AssetsSVGComponents/ActiveAsssets";
// import { BreakdownAssets } from "../../../assets/AssetsSVGComponents/AssetUnderMaintenance";
// import ClonosGridNav from "../../../utils/ClonosGridNav"
import { Container,Grid, Card, CardContent, Typography,Pagination  } from "@mui/material";
import UptimeRatioGrid from "./UptimeRatioGrid";
import MaintenancecomplianceGrid from "./MaintenancecomplianceGrid";
import { doGetApiCall } from "../../../../utils/ClonosApi";
// import { Gauge ,gaugeClasses} from '@mui/x-charts/Gauge';
// import { Box } from '@mui/material'

// import {
//   DataGrid,
//   gridPageCountSelector,
//   useGridApiContext,
//   useGridSelector,
// } from '@mui/x-data-grid';
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import AppUrl from "../../../utils/AppUrl";

function TableCard() {

   
  return (
   <>
{/* <Container className={Styles.section}> */}
  <div className={Styles.tableRow}>
    <div className={Styles.cardWrapper}>
        <UptimeRatioGrid  />
      {/* <UptimeRatioGrid uptimeRatioData={uptimeRatioData} uptimePage={uptimePage} /> */}
    </div>
    <div className={Styles.cardWrapper}>
      <MaintenancecomplianceGrid /> 
      {/* <MaintenancecomplianceGrid maintenancedata={maintenancedata} /> */}
    </div>
  </div>
{/* </Container> */}

   
   </>
  )
}

export default TableCard