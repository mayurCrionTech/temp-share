// import React, { useEffect, useState } from "react";
// import Styles from './quality-dashboard.module.css';
// import { Container, Card } from "@mui/material";
// import { doGetApiCall } from "../../../utils/ClonosApi";
// import DateFilters from '../DateFilters';
// import AppUrl from "../../../utils/AppUrl";
// import HistoricalTrends from "./HistoricalTrends"
// import LiveData from "./LiveData";
// import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";

// function QualityDashboard() {
    
//       const [startDate, setStartDate] = useState(null);
//       const [endDate, setEndDate] = useState(null);
//       const [latestData, setLatestData] = useState([]);
//       const [previousIds, setPreviousIds] = useState(new Set());
//       const [isLoading, setIsLoading] = useState(true);
//       const [dataLoadedOnce, setDataLoadedOnce] = useState(false);
    
//       const formattedStartDate = startDate ? new Date(startDate).toISOString().slice(0, 16) : "";
//       const formattedEndDate = endDate ? new Date(endDate).toISOString().slice(0, 16) : "";
    
//       const fetchLiveData = (start = null, end = null) => {
//         setIsLoading(true);
    
//         let url = `${AppUrl.getLatestAnalyticsEntries}?clientId=3`;
    
//         if (start && end) {
//           url += `&startDate=${start}&endDate=${end}`;
//         }
    
//         // doGetApiCall({ url })
//         //   .then((res) => {
//         //     if (res?.data?.result) {
//         //       const extractedData = Object.entries(res.data.result).map(([key, value]) =>
//         //         value
//         //           ? {
//         //               id: value._id,
//         //               name: key.replace(/([A-Z])/g, " $1").trim(),
//         //               value: value.fieldValue || 0,
//         //               units: value.units ?? "",
//         //               min: value.range?.min ?? null,
//         //               normal:value.range?.normal ?? null,
//         //               max: value.range?.max ?? null,
//         //               lastUpdatedAt: value.sampleCollectedDate,
//         //             }
//         //           : null
//         //       ).filter(Boolean);
    
//         //       const newIds = new Set(extractedData.map((item) => item.id));
//         //       const isNewDataAvailable = [...newIds].some((id) => !previousIds.has(id));
    
//         //       if (isNewDataAvailable || !dataLoadedOnce) {
//         //         setLatestData(extractedData);
//         //         setPreviousIds(newIds);
//         //       }
//         //     } else {
//         //       setLatestData([]);
//         //     }
//         //     setDataLoadedOnce(true);
//         //   })
//         //   .catch((err) => {
//         //     console.error("Error fetching live data:", err);
//         //     setLatestData([]);
//         //     setDataLoadedOnce(true);
//         //   })
//         //   .finally(() => {
//         //     setIsLoading(false);
//         //   });
//       };
    
//       useEffect(() => {
//         fetchLiveData();
//         const interval = setInterval(() => fetchLiveData(formattedStartDate, formattedStartDate), 120000);
//         return () => clearInterval(interval);
//       }, []);
    
//       useEffect(() => {
//         if (formattedStartDate && formattedEndDate) {
//           if (new Date(formattedStartDate) > new Date(formattedEndDate)) {
//             // If startDate is after endDate, show empty (0) data
//             const zeroData = latestData.map(item => ({
//               ...item,
//               value: 0,
//               lastUpdatedAt: "",
//             }));
//             setLatestData(zeroData);
//           } else {
//             fetchLiveData(formattedStartDate, formattedEndDate);
//           }
//         }
//       }, [formattedStartDate, formattedEndDate]);
    
    
    
//     console.log(latestData,"latestData")
//     // const isDataEmpty =!latestData 
//     const isDataEmpty = latestData.length === 0;
//     console.log(isDataEmpty,"isDataEmpty")
//   return (
// //      <>
// //       {/* Initial loading spinner before any data is loaded */}
// //       {!dataLoadedOnce && isLoading ? (
// //         <div className={Styles.loaderWrapper}>
// //           <ClonosSpinner />
// //         </div>
// //       ) : isDataEmpty ? (
// //         // Show message if data loaded but empty
// //         <Card variant="outlined" className={Styles.analyticsDashboardContainer}>
// //           <p style={{
// //             display: "flex",
// //             justifyContent: "center",
// //             alignItems: "center",
// //             height: "100%",
// //             textAlign: "center",
// //             fontSize: "25px",
// //             color: "#575757"
// //           }}>
// //             Please Contact Admin to Access this page
// //           </p>
// //         </Card>
// //       ) : (
// //         // Show full analytics dashboard
// //         <Card variant="outlined" className={Styles.analyticsDashboardContainer}>
// //           <div className={Styles.analyticsDashboardHeader}>
// //             <h4 className={Styles.analyticsDashboardTitle}>Analytics Dashboard</h4>
// //             <div className={Styles.dateFilterWrapper}>
// //               <DateFilters
// //                 startDate={startDate}
// //                 endDate={endDate}
// //                 setStartDate={setStartDate}
// //                 setEndDate={setEndDate}
// //               />
// //             </div>
// //           </div>

// //           {isLoading ? (
// //             <div className={Styles.loaderWrapper}>
// //               <ClonosSpinner />
// //             </div>
// //           ) : (
// //             <main>
// //               <Container style={{ marginBottom: "20px" }}>
// //                 {/* <LiveData latestData={latestData} /> */}
// //                 <br />
// //                 {/* <HistoricalTrends startDate={startDate} endDate={endDate} /> */}
// //               </Container>
// //             </main>
// //           )}
// //         </Card>
// //       )}
// //   </>

//   <>
//     <Card variant="outlined" className={Styles.qualityDashboardContainer}>
//           <div className={Styles.qualityDashboardHeader}>
//             <h4 className={Styles.qualityDashboardTitle}>Quality Dashboard</h4>
//             <div className={Styles.dateFilterWrapper}>
//               <DateFilters
//                 startDate={startDate}
//                 endDate={endDate}
//                 setStartDate={setStartDate}
//                 setEndDate={setEndDate}
//               />
//             </div>
//           </div>

//             <main>
//               <Container style={{ marginBottom: "20px" }}>
//                 <LiveData latestData={latestData} />
//                 <br />
//                 <HistoricalTrends startDate={startDate} endDate={endDate} />
//               </Container>
//             </main>
    
//         </Card>
//        </>
//   )
// }

// export default QualityDashboard



import React, { useEffect, useState } from "react";
import Styles from './quality-dashboard.module.css';
import { Container, Card } from "@mui/material";
import { doGetApiCall } from "../../../utils/ClonosApi";
import DateFilters from '../DateFilters';
import AppUrl from "../../../utils/AppUrl";
import HistoricalTrends from "./HistoricalTrends";
import LiveData from "./LiveData";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";

function QualityDashboard() {
  const [selectedPlant, setSelectedPlant] = useState(null);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [latestData, setLatestData] = useState([]);
  const [previousIds, setPreviousIds] = useState(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [dataLoadedOnce, setDataLoadedOnce] = useState(false);
  const [plants,setPlants]=useState([])

  const formattedStartDate = startDate ? new Date(startDate).toISOString().slice(0, 16) : "";
  const formattedEndDate = endDate ? new Date(endDate).toISOString().slice(0, 16) : "";

 

  
  const fetchLiveData = (start = null, end = null, selectedPlant) => {
  setIsLoading(true);

  let url = `${AppUrl.getLatestQualityEntries}?clientId=2`;

  if (start && end) {
    url += `&startDate=${start}&endDate=${end}`;
  }

  if (selectedPlant) {
    const formattedPlantName = selectedPlant.toLowerCase().replace(/\s+/g, '');
    url += `&plantName=${formattedPlantName}`;
  }


  doGetApiCall({ url })
    .then((res) => {
      if (res?.data?.result) {
        const extractedData = Object.entries(res.data.result).map(([key, value]) =>
          value
            ? {
                id: value._id,
                name: key,
                value: value.fieldValue || 0,
                units: value.units ?? "",
                lastUpdatedAt: new Date(value.entryCreatedAt).toLocaleString(),
              }
            : null
        ).filter(Boolean);

        const newIds = new Set(extractedData.map((item) => item.id));
        const isNewDataAvailable = [...newIds].some((id) => !previousIds.has(id));

        if (isNewDataAvailable || !dataLoadedOnce) {
          setLatestData(extractedData);
          setPreviousIds(newIds);
        }
      } else {
        setLatestData([]);
      }
      setDataLoadedOnce(true);
    })
    .catch((err) => {
      console.error("Error fetching live data:", err);
      setLatestData([]);
      setDataLoadedOnce(true);
    })
    .finally(() => {
      setIsLoading(false);
    });
};

  useEffect(() => {
    if (selectedPlant) {
      fetchLiveData(formattedStartDate, formattedEndDate, selectedPlant);
      // const interval = setInterval(() => fetchLiveData(formattedStartDate, formattedEndDate,selectedPlant), 120000);
      // return () => clearInterval(interval);
    }
  }, [selectedPlant, formattedStartDate, formattedEndDate]);

  useEffect(() => {
    if (formattedStartDate && formattedEndDate && selectedPlant) {
      if (new Date(formattedStartDate) > new Date(formattedEndDate)) {
        const zeroData = latestData.map(item => ({
          ...item,
          value: 0,
          lastUpdatedAt: "",
        }));
        setLatestData(zeroData);
      } else {
        fetchLiveData(formattedStartDate, formattedEndDate, selectedPlant);
      }
    }
  }, [formattedStartDate, formattedEndDate]);
  
  useEffect(()=>{
     let url = `${AppUrl.getQualityDashboardPlant}?clientId=2`;
    doGetApiCall({url}).then((res)=> setPlants(res?.data?.result))
  },[])
  const isPlants = plants.length === 0;

  const renderPlantSelector = () => {
  return (
    isPlants ? (
      <Card variant="outlined" className={Styles.qualityDashboardContainer}>
        <p
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            textAlign: "center",
            fontSize: "25px",
            color: "#575757"
          }}
        >
          Please Contact Admin to Access this page
        </p>
      </Card>
    ) : (
      <Card variant="outlined" className={Styles.qualityDashboardContainer}>
        <div className={Styles.plantSelectorContainer}>
          <h3 className={Styles.plantSelectorTitle}>Select a Plant</h3>
          <div className={Styles.plantCardWrapper}>
            {["Plant 4"].map((plant, index) => (
              <Card
                key={index}
                className={Styles.plantCard}
                onClick={() => setSelectedPlant(plant)}
              >
                {plant}
              </Card>
            ))}
          </div>
        </div>
      </Card>
    )
  );
};


  if (!selectedPlant) return renderPlantSelector();

  return (
    // <>
    //   {!dataLoadedOnce && isLoading ? (
    //     <div className={Styles.loaderWrapper}>
    //       <ClonosSpinner />
    //     </div>
    //   ) : isDataEmpty ? (
    //     <Card variant="outlined" className={Styles.analyticsDashboardContainer}>
    //       <p style={{
    //         display: "flex",
    //         justifyContent: "center",
    //         alignItems: "center",
    //         height: "100%",
    //         textAlign: "center",
    //         fontSize: "25px",
    //         color: "#575757"
    //       }}>
    //         Please Contact Admin to Access this page
    //       </p>
    //     </Card>
    //   ) : (
    //     <Card variant="outlined" className={Styles.qualityDashboardContainer}>
    //       <div className={Styles.qualityDashboardHeader}>
    //         <h4 className={Styles.qualityDashboardTitle}>Quality Dashboard - {selectedPlant}</h4>
    //         <div className={Styles.dateFilterWrapper}>
    //           <DateFilters
    //             startDate={startDate}
    //             endDate={endDate}
    //             setStartDate={setStartDate}
    //             setEndDate={setEndDate}
    //           />
    //         </div>
    //       </div>

    //       {isLoading ? (
    //         <div className={Styles.loaderWrapper}>
    //           <ClonosSpinner />
    //         </div>
    //       ) : (
    //         <main>
    //           <Container style={{ marginBottom: "20px" }}>
    //             <LiveData latestData={latestData} />
    //             <br />
    //             <HistoricalTrends startDate={startDate} endDate={endDate} />
    //           </Container>
    //         </main>
    //       )}
    //     </Card>
    //   )}
    // </>

  <Card variant="outlined" className={Styles.qualityDashboardContainer}>
          <div className={Styles.qualityDashboardHeader}>
            <h4 className={Styles.qualityDashboardTitle}>Quality Dashboard - {selectedPlant}</h4>
            <div className={Styles.dateFilterWrapper}>
              <DateFilters
                startDate={startDate}
                endDate={endDate}
                setStartDate={setStartDate}
                setEndDate={setEndDate}
              />
            </div>
          </div>

          {isLoading ? (
            <div className={Styles.loaderWrapper}>
              <ClonosSpinner />
            </div>
          ) : (
            <main>
              <Container style={{ marginBottom: "20px" }}>
                <LiveData latestData={latestData} />
                <br />
                <HistoricalTrends startDate={startDate} endDate={endDate} selectedPlant={selectedPlant}/>
              </Container>
            </main>
          )}
        </Card>
  );
}

export default QualityDashboard;

