import React, { useEffect, useState } from "react";
import { Grid, Typography, Card, CardContent } from "@mui/material";
import TrendChart from "./TrendChart";
import Styles from "./quality-dashboard.module.css";
import ClonosSkeletonLoading from "../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { doGetApiCall } from "../../../utils/ClonosApi";
import AppUrl from "../../../utils/AppUrl";

const METRICS = [
  "FFA",
  "Sediments",
  "S1-FFA",
  "S1 Soap",
  "S2-FFA",
  "S2 Soap",
  "S3 Outlet_FFA",
  "S3 Outlet_Soap (ppm)",
  "Bleached oil_Colour",
  "Deo Final_Colour",
  "Deo Final_FFA",
  "Deo Final_TBHQ (ppm)",
];

const HistoricalTrends = ({ startDate, endDate,selectedPlant }) => {
  const [historicalData, setHistoricalData] = useState({});
  const [loadingMetrics, setLoadingMetrics] = useState(new Set());

  useEffect(() => {
    fetchHistoricalData(startDate, endDate,selectedPlant);
  }, [startDate, endDate, selectedPlant]);

  const fetchHistoricalData = () => {
    METRICS.forEach((metric) => {
      setLoadingMetrics((prev) => new Set(prev).add(metric));

      let url = `${AppUrl.getQualityDashboard}?${metric}=true&clientId=2`;
       if (selectedPlant) {
        const formattedPlantName = selectedPlant.toLowerCase().replace(/\s+/g, "");
        url += `&plantName=${formattedPlantName}`;
      }
      if (startDate && endDate) {
  const formattedStartDate = startDate
    ? new Date(startDate).toISOString().split('T')[0]
    : "";
  const formattedEndDate = endDate
    ? new Date(endDate).toISOString().split('T')[0]
    : "";
  url += `&startDate=${formattedStartDate}&endDate=${formattedEndDate}`;
  
}

     
     
      doGetApiCall({ url })
        .then((res) => {
          
          if (res?.data?.result) {
            setHistoricalData((prev) => ({
              ...prev,
              [metric]: res.data.result[metric],
            }));
          }
        })
        .catch((err) => console.error(`Error fetching ${metric} data:`, err))
        .finally(() => {
          setLoadingMetrics((prev) => {
            const updated = new Set(prev);
            updated.delete(metric);
            return updated;
          });
        });
    });
  };


  return (
    <div>
      <Typography
        variant="h6"
        gutterBottom
        className={Styles.qualityDashboardTitle}
      >
        Historical Trends
      </Typography>
      <Grid container spacing={3}>
        {METRICS.map((metric) => (
          <Grid item xs={12} sm={6} key={metric}>
            {loadingMetrics.has(metric) ? (
              // Show Skeleton while loading
              <Card style={{ borderRadius: "16px", padding: "10px", minHeight: "300px" }}>
                <CardContent>
                  <Typography variant="h6">
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <ClonosSkeletonLoading
                        width="60%"
                        height="50px"
                        animation="wave"
                      />
                      <ClonosSkeletonLoading
                        width="30%"
                        height="50px"
                        animation="wave"
                      />
                    </div>
                  </Typography>
                  <ClonosSkeletonLoading
                    width="100%"
                    height="200px"
                    animation="wave"
                  />
                </CardContent>
              </Card>
            ) : historicalData[metric]? (
              // Show Chart if data exists
              <TrendChart
                title={metric}
                data={historicalData[metric]}
                // min={historicalData[metric].data[0]?.range?.min ?? null}
                // max={historicalData[metric].data[0]?.range?.max ?? null}
                units={historicalData[metric][0]?.units}
              />
            ) : (
              // Show fallback message if no data
              <Card
                style={{
                  borderRadius: "16px",
                  padding: "10px",
                  
                  minHeight: "415px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: 0.8,
                }}
              >
                <CardContent>
                  <Typography
                    variant="h6"
                    align="center"
                    color="textSecondary"
                    style={{ fontWeight: 500 }}
                  >
                    Data not available for {metric}
                  </Typography>
                </CardContent>
              </Card>
            )}
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default HistoricalTrends;
