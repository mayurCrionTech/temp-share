import React, { useState } from "react";
import { Typography, Grid, Card, Box } from "@mui/material";
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { statusStaticData, statusStyleStaticData, priorityStyleStaticData } from '../../../Constants/StaticData'
import Styles from './LogCompilance-dashboard.module.css'

// Circle widget styles
// const circleStyle = (color) => ({
//   width: 140,
//   height: 140,
//   borderRadius: "50%",
//   border: `4px solid ${color}`,
//   display: "flex",
//   flexDirection: "column",
//   justifyContent: "center",
//   alignItems: "center",
//   color,
//   fontWeight: "bold",
//   fontSize: "18px"
// });

const circleStyle = (color,bgcolor="#fff") => ({
  width: 140,
  height: 140,
  borderRadius: "50%",
  border: `4px solid ${color}`,
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  alignItems: "center",
  color,
  fontWeight: "bold",
  backgroundColor: `${bgcolor}`,
  boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
  transition: "transform 0.3s, box-shadow 0.3s",
  cursor: "pointer",
  "&:hover": {
    transform: "scale(1.05)",
    boxShadow: "0 6px 16px rgba(0,0,0,0.2)",
  },
});


// Table columns
const columns = [
  {
    field: "id",
    headerName: "SI.NO",
    width: 50
  },
  {
    field: "name",
    headerName: "LOG NAME",
    flex: 1,
    valueGetter: (params) => params?.row?.name || "-"
  },
  // {
  //   field: "logNumber",
  //   headerName: "LOG NUMBER",
  //   flex: 1,
  //   valueGetter: (params) => params?.row?.logNumber || "-"
  // },
   {
    field: "entryGenerated",
    headerName: "LOG ENTRY GENERATED",
    flex: 1,
     align:"center",
    valueGetter: (params) => params?.row?.entryGenerated || "-"
  },
   {
    field: "entryEntered",
    headerName: "LOG ENTRY ENTERED",
    flex: 1,
     align:"center",
    valueGetter: (params) => params?.row?.entryEntered || "-"
  },
    {
    field: "percentCompletion",
    headerName: "LOG ENTRY COMPLETION (%)",
    flex: 1.3,
    align:"center",
    valueGetter: (params) => params?.row?.percentCompletion || "-"
  },

  {
    field: "createdBy",
    headerName: "CREATED BY",
    flex: 1,
    valueGetter: (params) => params?.row?.createdBy || "-"
  },
  // {
  //   field: "createdAt",
  //   headerName: "CREATED AT",
  //   flex: 1,
  //   valueGetter: (params) => params?.row?.createdAt || "-"
  // },
  {
    field: "status",
    headerName: "STATUS",
    flex: 1,
    headerAlign:"center",
    align:"center",
    renderCell: (params) => {
        return <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{params?.row?.status ? statusStaticData[params?.row?.status] : "-"}</p>
    }
  }
];
 

// Add serial numbers
const setSerialNumber = (data, page = 1, limit = 10) =>
  data.map((item, index) => ({
    ...item,
    id: (page - 1) * limit + index + 1
  }));

const LogCompilanceData = ({ latestData ,pagination, setPagination}) => {
  
  const {
    Approval = 0,
    Overdue = 0,
    Completed = 0,
    logsTable = [],
    totalCount
  } = latestData || {};

  const rows = setSerialNumber(logsTable, pagination.page, pagination.limit);

  return (
    <>
      {/* Overview Title */}
      <Typography variant="h6" gutterBottom className={Styles.logCompilanceDashboardTitle}>
        Compliance Overview 
      </Typography>
     
      {/* Circle Metrics - centered */}
       <Card variant="outlined" style={{marginTop:"20px", marginBottom:"20px"}} sx={{
          p: 3,
          boxShadow: 3,
          borderRadius: 3,
          // background: "linear-gradient(135deg, #f9f9f9 0%, #ffffff 100%)",
          backgroundColor:"#ffffff",
          display: "flex",                // make card a flexbox
          justifyContent: "center",       // center horizontally
          alignItems: "center",           // center vertically
        }}>
          <Box
                  display="flex"
            justifyContent="center"
            alignItems="center"
            gap={6}
            flexWrap="wrap"
            width="100%"
          >
            <div style={circleStyle("#E5B82F","#FCF8EA")}>
              <div>Approval</div>
              <div style={{ fontSize: "24px" }}>{Approval}</div>
            </div>

            <div style={circleStyle("#D24B5A", "#FBEDEF")}>
              <div>Overdue</div>
              <div style={{ fontSize: "24px" }}>{Overdue}</div>
            </div>

            <div style={circleStyle("#60D468", "#EBFAEC")}>
              <div>Completed</div>
              <div style={{ fontSize: "24px" }}>{Completed}</div>
            </div>
          </Box>
       </Card>
     

      {/* Logs Table */}
      <Typography variant="h6" gutterBottom  className={Styles.logCompilanceDashboardTitle} >
        Logs
      </Typography>

      <Card variant="outlined"   style={{ padding: "1rem",marginTop:"20px" , backgroundColor:"#ffffff",}} sx={{
    p: 3,
    boxShadow: 3,
    borderRadius: 3,
    // background: "linear-gradient(135deg, #f9f9f9 0%, #ffffff 100%)",
    
  }}>
       
        {rows.length === 0 ? (
          <Typography
            variant="body1"
            align="center"
            sx={{ color: "text.secondary", p: 2 }}
          >
            No logs available 
          </Typography>
        ) : (
          
          <ClonosDataGrid
            rows={rows}
            columns={columns}
            uniqueIdField="id"
            isLoading={false}
            totalCount={totalCount}
            pageLimit={pagination.limit}
            checkboxSelection={false}
            onPageChange={(e) =>
              setPagination({ page: e.page + 1, limit: e.pageSize })
            }
          />
        )}
      </Card>
       
    </>
  );
};

export default LogCompilanceData;


