import React, { useState,useEffect } from "react";
import Styles from './LogCompilance-dashboard.module.css';
import { Container, Card } from "@mui/material";
import DateFilters from '../DateFilters';
import LogCompilanceData from "./LogCompilanceData";
import AppUrl from "../../../utils/AppUrl";
import { doDownloadApiCall, doGetApiCall, doPostApiCall } from "../../../utils/ClonosApi";
import { commonPageState, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import { IoDocumentTextOutline } from "react-icons/io5";
import { useDispatch } from "react-redux";

function LogCompilanceDashboard() {
  const dispatch =useDispatch()
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [logCompilanceData, setLogCompilanceData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState(commonPageState);
  const [isHovered, setIsHovered] = useState(false);
  const [isLoading, setIsLoading] = useState(false);



const fetchDashboardData = () => {
    let url = AppUrl.getDashboards;
  
     // Format the start and end dates to 'YYYY-MM-DDTHH:MM'
      const formattedStartDate = startDate ? new Date(startDate).toISOString().slice(0, 16) : "";
      const formattedEndDate = endDate ? new Date(endDate).toISOString().slice(0, 16) : "";
  
    // Append the date filters to the API URL if they exist
    if (formattedStartDate || formattedEndDate) {
      url += `?startDate=${formattedStartDate}&endDate=${formattedEndDate}`;
    }
  
    setLoading(true); // Start loading when fetching data
    
    doGetApiCall({ url , params:pagination })
      .then((res) => setLogCompilanceData(res?.data?.result || {}))
      .finally(() => setLoading(false)); // Stop loading after data is fetched
  };
  

  useEffect(() => {
    // setLoading(true);
    fetchDashboardData();
  }, [startDate, endDate, pagination.page,pagination.limit]);

 useEffect(()=>{
  doGetApiCall({ url:AppUrl.getDashboards, params:pagination })
  .then((res) => setLogCompilanceData(res?.data?.result || {}))
  .finally(() => setLoading(false));
  
 },[])

   const handleLogCompilanceReport= (startDate,endDate)=>{
   
          if (!startDate || !endDate){
             return  handleShowErrorAndWarning({dispatch,type:"error",message: "Please select both Start Date and End Date before generating report",showTime:"5000"})
           }
           setIsLoading(true); // Show spinner before API call
           const formatDate = (date) => date.split("T")[0]; 
           const filename = `Log_Compliance_Report_${formatDate(startDate)}_to_${formatDate(endDate)}.xlsx`;

           doDownloadApiCall({
            url: '/reports/logComplianceReport',
            payload: { startDate, endDate }
          })
          .then((res) => {
            
              const blob = new Blob([res.data], { type: res.headers['content-type'] });
              const url = window.URL.createObjectURL(blob);

              const a = document.createElement('a');
              a.href = url;
              // a.download = 'Log_Compliance_Report.xlsx'; 
              a.download = filename;
              document.body.appendChild(a);
              a.click();
              a.remove();

              window.URL.revokeObjectURL(url);
          })
          .catch(err => {
              console.error("Download error:", err);
          });

           setIsLoading(false);
        
       }



  return (
    <>
       
      <div className={Styles.logCompilanceDashboardContainer}>
      
        <div className={Styles.logCompilanceDashboardHeader}>
          <h4 className={Styles.logCompilanceDashboardTitle}>Log Compliance Dashboard</h4>

          <div className={Styles.dateFilterWrapper}>
            <div
              className={Styles.reportButton}
              onClick={() => handleLogCompilanceReport(startDate, endDate)}
              // onMouseEnter={() => setIsHovered(true)}
              // onMouseLeave={() => setIsHovered(false)}
            >
              <IoDocumentTextOutline size={20} />
              <span>Report</span>
            </div>
            <DateFilters
              startDate={startDate}
              endDate={endDate}
              setStartDate={setStartDate}
              setEndDate={setEndDate}
            />

            
          </div>
        </div>


        <main>
          <div className={Styles.logCompilanceContainer}>
           
            <LogCompilanceData latestData={logCompilanceData}   pagination={pagination} setPagination={setPagination}/>
          </div>
        </main>
      </div>
    </>
  );
}

export default LogCompilanceDashboard;



