import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, IconButton } from "@material-ui/core";
import FullscreenIcon from "@material-ui/icons/Fullscreen";
import FullscreenExitIcon from "@material-ui/icons/FullscreenExit";
import CloseIcon from "@material-ui/icons/Close";

const View3DPage = () => {
  const cardRef = useRef(null);
  const hideTimerRef = useRef(null);

  const navigate = useNavigate();
  const location = useLocation();

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [loadIframe, setLoadIframe] = useState(false);
  const [showControls, setShowControls] = useState(true);

  const is3DPage = location.pathname === "/3dview";

  // Load iframe ONLY on /3dview
  useEffect(() => {
    if (is3DPage) {
      setLoadIframe(true);
    }
  }, [is3DPage]);

  // GLOBAL mouse move (works inside iframe)
  useEffect(() => {
    const handleMouseMove = () => {
      setShowControls(true);

      if (hideTimerRef.current) {
        clearTimeout(hideTimerRef.current);
      }

      hideTimerRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    };

    window.addEventListener("mousemove", handleMouseMove);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      if (hideTimerRef.current) {
        clearTimeout(hideTimerRef.current);
      }
    };
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      cardRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleClose = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    }

    setLoadIframe(false);
    navigate("/");
  };

  if (!loadIframe) return null;

  return (
    <Card
      ref={cardRef}
      variant="outlined"
      style={{
        flex: 1,
        margin: "1rem",
        borderRadius: "1rem",
        overflow: "hidden",
        position: "relative",
        height: "calc(100% - 2rem)",
      }}
    >
      <iframe
        // src="http://20.193.255.57:2501"
        // src="https://dicv3d.clonos.in"
        // src="http://53.214.23.49:2015"
        src="https://sawmpche0025.che.dc.tbintra.net:2015"
        title="3D View"
        allow="fullscreen"
        style={{
          width: "100%",
          height: "100%",
          border: "none",
        }}
      />

      {/* Fullscreen Button */}
      <IconButton
        onClick={toggleFullscreen}
        style={{
          position: "absolute",
          bottom: 12,
          right: 12,
          // background: "#ffffffcc",
          // color: "#00000099",
            background: "#00000099",
          color: "#ffffffcc",
          opacity: showControls ? 1 : 0,
          pointerEvents: showControls ? "auto" : "none",
          transition: "opacity 0.3s ease",
           padding: 4,          
          // borderRadius: 8,     
        }}
      >
        {isFullscreen ? <FullscreenExitIcon /> : <FullscreenIcon />}
      </IconButton>

      {/* Close Button */}
      <IconButton
        onClick={handleClose}
        style={{
          position: "absolute",
          top: 12,
          right: 12,
          // background: "#ffffffcc",
          // color: "#00000099",
              background: "#00000099",
          color: "#ffffffcc",
          opacity: showControls ? 1 : 0,
          pointerEvents: showControls ? "auto" : "none",
          transition: "opacity 0.3s ease",
           padding: 4,        
          // borderRadius: 8,    
        }}
      >
        <CloseIcon />
      </IconButton>
    </Card>
  );
};

export default View3DPage;
