import { Card } from "@mui/material"
import Styles from "../../../ModuleStyles/Auth/Permissions/Permissions.module.css"
import { ActiveUsersCountSVG, AllUsersCountSVG } from "../../../assets/UsersSVGComponents/AllUsersSVG"
import ClonosGridNav from "../../../utils/ClonosGridNav"
import CommonNavigator from "../../../components/CommonComponents/Navigator/Navigator"
import { useEffect, useState } from "react"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import { PermissionsTable } from "../ClonosUser/components/PermissionsTable"
import { getAllActivePermissionsModules, getAllDesignationsWithPermissions, getPermissionsOfActiveModule, getUsersWithPermissions, handleAssignMultiplePermissionsToDesignations, handleAssignMultiplePermissionsToUsers, handleModuleBasePermissions, managePermissionsModulesLocally } from "../../../utils/PermissionsMethods/PermissionsMethod"
import { MultiplePermissionsManager } from "../ClonosUser/MutiplePermissionsManager/MultiplePermissionsManager"
import { useDispatch } from "react-redux"
import useToggler from "../../../CustomHooks/TogglerHook"
import { permissionsActions } from "../../../Store/Reducers/ClonosPermissionsReducer"
import { useSelector } from "react-redux"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_MODULE_USERS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant"
import { checkUserHasPermission, handleShowErrorAndWarning } from "../../../utils/clonosCommon"
import { getUsersCounts } from "../../../utils/UsersMethods/usersMethods"
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook"
const permissionsNavigatorValues = [{value:"Users List",status:true,visibility:true},{value:"Designations Permissions",status:false,visibility:true}];


 /*
    date            qid / cr#         comments
    07-Apr-2026     #160             Broken Access Control - Permission Restriction FrontEnd
    */
const Permissions = () => {
    const dispatch = useDispatch();
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_USERS);
    const [pagination,setPagination] = useState({page:1,limit:15})
    const [modulesNavigatorValues,setModulesNavigatorValues] = useState([]);
    const [submitLoader,setSubmitLoader] = useToggler();
    const {usersWithPermissions,changedPermissions,designationsWithPermissions} = useSelector(store => store.permissionsData);
    const [navLoader,setNavLoader] = useToggler();
    const [usersCount,setUsersCount] = useState({})
    const [modulesLoader,setModulesLoader] = useToggler();
    const [permissionsLoaders,setPermissionsLoader] = useToggler();
    const [usersCounts,setUsersCounts] = useState({});
    const [defaultPermissions,setDefaultPermissions] = useState([])
    const [showMultiplePermissionsAssigner,setShowMultiplePermissionsAssigner] = useState(false);
    const [activePermissionsTab,setActivePermissionsTab] = useState("Users List");
    const [activeModuleTab,setActiveModuleTab] = useState("Assets");
    const [permissionsColumns,setPermissionsColumns] = useState([])
    const [useEffectUpdate,setUseEffectUpdate] = useToggler();


    const handleUpdate = async () => {
        const requestPayload = [];
        if(activePermissionsTab === "Users List"){
            for (let permissionId in changedPermissions){
                let obj = {id:permissionId,...changedPermissions[permissionId]};
                requestPayload.push(obj)
            }
            const isAssigned = await handleAssignMultiplePermissionsToUsers({payload:requestPayload,dispatch,setSubmitLoader});
            if(isAssigned === true){
                handleShowErrorAndWarning({dispatch,message:"Permissions updated successfully.",showTime:"5000",type:"success"})
                const users = await getUsersWithPermissions({dispatch,setIsLoading:setPermissionsLoader});
                if(users?.data?.length){
                    const res_data = users?.data;
                    setDefaultPermissions(res_data)
                    dispatch(permissionsActions.getAllUsersWithPermissions(res_data));
                }
                dispatch(permissionsActions.getChangedPermissions({}));
                setUseEffectUpdate()
            }
        } else if(activePermissionsTab === "Designations Permissions") {
            for(let key in changedPermissions){
                let obj = {id:key,permissions:changedPermissions[key]?.permissions};
                requestPayload.push(obj)
            }
            const res = await handleAssignMultiplePermissionsToDesignations({payload:requestPayload,dispatch,setSubmitLoader});
            handleShowErrorAndWarning({dispatch,message:"Permissions updated successfully.",showTime:"5000",type:"success"})
            if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
                const res = await getAllDesignationsWithPermissions({dispatch,setIsLoading:setPermissionsLoader})
                if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
                    const res_data = res?.result?.data;
                    setDefaultPermissions(res_data)
                    dispatch(permissionsActions.getDesignationsWithPermissions(res_data));
                    dispatch(permissionsActions.getChangedPermissions([]));
                }
            }
        }
    }

    const handleRestoreDefault= () => {
        if(activePermissionsTab === "Users List"){
            dispatch(permissionsActions.getAllUsersWithPermissions(defaultPermissions))
        } else if(activePermissionsTab === "Designations Permissions"){
            dispatch(permissionsActions.getDesignationsWithPermissions(defaultPermissions))
        }
        dispatch(permissionsActions.getChangedPermissions({}));
        setUseEffectUpdate()
    }


    useEffect(() => {
        handleModuleBasePermissions({activeTab:activeModuleTab,setPermissionsColumns,permissionsType:activePermissionsTab === "Users List" ? "Users" : activePermissionsTab === "Designations Permissions" ? "Designation" : "",data:activePermissionsTab === "Users List" ? usersWithPermissions : activePermissionsTab === "Designations Permissions"? designationsWithPermissions : [],changedPermissions,modulesNavigatorValues,dispatch,setUseEffectUpdate,setIsLoading:setPermissionsLoader});
    },[activeModuleTab,activePermissionsTab,modulesNavigatorValues?.length,useEffectUpdate])

    useEffect(() => {
        (async () => {
           if(!modulesNavigatorValues?.length){
            const activeModules = await managePermissionsModulesLocally({dispatch,setActiveModuleTab,setIsLoading:setModulesLoader});
            setModulesNavigatorValues(activeModules)
           }
           if(activePermissionsTab === "Users List"){
             const fetchedUsers = await getUsersWithPermissions({dispatch,setIsLoading:setPermissionsLoader});
             if(fetchedUsers?.data?.length){
                const res_data =fetchedUsers?.data;
                setDefaultPermissions(res_data)
                dispatch(permissionsActions.getAllUsersWithPermissions(res_data));
                setUseEffectUpdate()
             }
           } else if(activePermissionsTab === "Designations Permissions"){
            const fetchedDesignations = await getAllDesignationsWithPermissions({dispatch,setIsLoading:setPermissionsLoader})
            if(fetchedDesignations?.data){
                setDefaultPermissions(fetchedDesignations?.data);
                dispatch(permissionsActions.getDesignationsWithPermissions(fetchedDesignations?.data))
                setUseEffectUpdate()
            }
           }
        })()

        return () => {
            if(activePermissionsTab === "Users List") dispatch(permissionsActions.getAllUsersWithPermissions([]));
            if(activePermissionsTab === "Designations Permissions") dispatch(permissionsActions.getDesignationsWithPermissions([]))
        }
    },[activePermissionsTab,pagination])

    useEffect(() => {
        getUsersCounts({ dispatch, setterMethod: setUsersCounts,setLoading:setNavLoader })
    },[])

    /*
    date            qid / cr#         comments
    07-Apr-2026     #160             Broken Access Control - Permission Restriction FrontEnd
    */
   if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE })){
    return (
        <>
            <ClonosGridNav items={[
                {
                    icon: AllUsersCountSVG,
                    iconBg: '#E7EFFF',
                    title: 'Total Users',
                    count: usersCounts?.totalUsers
                },
                {
                    icon: ActiveUsersCountSVG,
                    iconBg: '#EBFAEC',
                    title: 'Active Users',
                    count: usersCounts?.enabledUsers
                },
            ]}>
            </ClonosGridNav>
            <Card style={{margin:"0rem 1rem 1rem 1rem",height:"100%"}}>
                <div style={{height:"10%",minHeight:"70px"}}>
                    <CommonNavigator values={permissionsNavigatorValues} getSelectedValue={(val) => setActivePermissionsTab(val)} web={true} />
                </div>
                {(!modulesNavigatorValues?.length && (!modulesLoader && !permissionsLoaders)) ? 
                <div className={Styles.no_data_wrapper}>
                    <h4>Oops! No details found.</h4>    
                </div> :  
                <div className={Styles.p_s_1}>
                    <div className={Styles.p_s_navigator_wrapper}>
                        <CommonNavigator isLoading={modulesLoader} values={modulesNavigatorValues} getSelectedValue={(val) => setActiveModuleTab(val)} web={true} style={{background:"none"}}/>
                    </div>
                    <div className={Styles.p_s_btn_wrapper}>
                        <ClonosButton onClick={() => setShowMultiplePermissionsAssigner(true)}>Multiple Permissions</ClonosButton>
                        <ClonosButton variant="filled" onClick={handleRestoreDefault}>Restore Default</ClonosButton>
                    </div>
                    <div className={Styles.p_s_grid_wrapper}>
                        <PermissionsTable isLoading={(modulesLoader || permissionsLoaders) && !(Object.keys(usersWithPermissions)?.length || Object.keys(designationsWithPermissions)?.length)} columns={permissionsColumns} rows={activePermissionsTab === "Users List" ? usersWithPermissions : activePermissionsTab === "Designations Permissions" ? designationsWithPermissions : [] } isMultiSelect={true} hideFooter={false}/>
                    </div>
                    <div className={Styles.p_s_btn_controller}>
                        <ClonosButton onClick={handleRestoreDefault}>Cancel</ClonosButton>
                        <ClonosButton loading={submitLoader} onClick={handleUpdate} >Update</ClonosButton>
                    </div>
                </div> 
                
                }
            </Card>
            {
                showMultiplePermissionsAssigner ? <MultiplePermissionsManager isOpen={showMultiplePermissionsAssigner} closeMethod={setShowMultiplePermissionsAssigner} activePermissionsTab={activePermissionsTab} activeModuleTab={activeModuleTab} modulesNavigatorValues={modulesNavigatorValues}/> : <></>
            }
        </>
    )
}
     return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
   
}

export default Permissions
