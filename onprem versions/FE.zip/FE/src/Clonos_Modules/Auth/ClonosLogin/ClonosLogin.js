import React, { useEffect, useState } from 'react';
import Styles from "../../../ModuleStyles/Auth/ClonosLogin/ClonosLogin.module.css";
import CLONOS_APP_LOGO from "../../../assets/UIUX/icons/CLONOS_APP_LOGO.svg";
import LOGIN_CAROUSEL_IMAGE_1 from "../../../assets/UIUX/images/LOGIN_CAROUSEL_SVG_1.svg"
import LOGIN_CAROUSEL_IMAGE_2 from "../../../assets/UIUX/images/LOGIN_CAROUSEL_SVG_2.svg"
import LOGIN_CAROUSEL_IMAGE_3 from "../../../assets/UIUX/images/LOGIN_CAROUSEL_SVG_3.svg"
import { getLoggedInUserDetailsByUserId, handleLogin, handleStartCarousel } from '../../../utils/AuthMethods/ClonosLoginMethods';
import ClonosInput from '../../../components/CommonComponents/ClonosInput/ClonosInput';
import { ClonosButton } from '../../../components/CommonComponents/Button/Button';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { CLONOS_GLOBAL_VENDOR } from '../../../Constants/Constant';
import { axiosInstance } from '../../../Api/AxioClient';
import { AppUrl } from '../../../utils/AppUrl';
import { handleEncryptionURLKeys, handleLoggedInUser, handleShowErrorAndWarning, setUserSession } from '../../../utils/clonosCommon';
import Cookies from 'js-cookie';
import { jwtDecode } from 'jwt-decode';
import useToggler from '../../../CustomHooks/TogglerHook';
import Modal from '../../../components/CommonComponents/Modal/Modal';
import CloseIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon';

let primaryObject = {};
const ClonosLogin = () => {
	const [lcValues, setLcValues] = useState({ email: "", password: "" });
	const [lcIntervals, setLcIntervals] = useState({ loading: false });
	const [carouselCurrentIndex, setCarouselCurrentIndex] = useState(1);
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const [showSignup, setShowSignup] = useState(false);
	const [signupValues, setSignupValues] = useState({ email: '', password: '', confirmPassword: '' });
	const [signupLoading, setSignupLoading] = useState(false);
	const [signupError, setSignupError] = useState('');
	const [signupSuccess, setSignupSuccess] = useState('');
    const [forgetPasswordModal, setForgetPasswordModal]=useToggler()

	// New states for organization selection
	const [showOrgSelection, setShowOrgSelection] = useState(false);
	const [authData, setAuthData] = useState(null);
	const [selectedOrg, setSelectedOrg] = useState(null);
	const [selectedBusinessUnit, setSelectedBusinessUnit] = useState(null);
	const [organizations, setOrganizations] = useState([]);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState('');

	let carouselData = [
		{
			index: 1,
			image: LOGIN_CAROUSEL_IMAGE_1,
			heading: "Smart Solutions for Oil & Gas",
			paragraph: "Manage your Assets, Optimize the Process flow, Increase the Assets Reliability and Beyond!",
			isActive: true
		},
		{
			index: 2,
			image: LOGIN_CAROUSEL_IMAGE_2,
			heading: "3D Digital Twins",
			paragraph: "Fueling Your Future with 3D Precision: Oil & Gas Made Simple",
			isActive: false
		},
		{
			index: 3,
			image: LOGIN_CAROUSEL_IMAGE_3,
			heading: "Igniting Efficiency",
			paragraph: "Your Oil & Gas Industry SAAS Partner",
			isActive: false
		},
	]
   
	

	const lcHandleGetValues = (props) => {
		const { name, selectedOption, updatedValue, uniqueKey, type } = props;
		const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
		setLcValues({ ...lcValues, [uniqueKey]: valueSetter ? updatedValue : "" })
	}

	const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
		if (response === null || response === "") {
			primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": false } }
			return false
		}
		else {
			primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": true } }
			return true
		}
	}

	const handleGetErrorActivatorInformation = (props) => {
		primaryObject = { ...primaryObject, [props.uniqueKey]: props }
	}

	const handleKeyPress = (e) => {
		if (e.key === 'Enter') {
			handleInitialLogin({ dispatch, navigate, payload: lcValues, responseSetterMethod: setLcValues, primaryObject })
		}
	};

	useEffect(() => {
		handleStartCarousel({ interval: 2000, setLcIntervals, carouselData, setCarouselCurrentIndex });
		return () => {
			clearInterval(lcIntervals["carouselImageIndicatorInterval"]);
		}
	}, [])

	useEffect(() => {
		// Attach event listener to the document body
		document.body.addEventListener('keydown', handleKeyPress);
		return () => {
			document.body.removeEventListener('keydown', handleKeyPress);
		}
	}, [lcValues])

	const handleSignupInput = (props) => {
		const { uniqueKey, updatedValue } = props;
		setSignupValues((prev) => ({ ...prev, [uniqueKey]: updatedValue }));
	};

	const handleSignup = async () => {
		setSignupError('');
		setSignupSuccess('');
		if (!signupValues.email || !signupValues.password || !signupValues.confirmPassword) {
			// toast.error('All fields are required.');
			 handleShowErrorAndWarning({ dispatch, type: "error", message: `All fields are required.`, showTime: 5000 })
			return;
		}
		if (signupValues.password !== signupValues.confirmPassword) {
			// toast.error('Passwords do not match.');
			 handleShowErrorAndWarning({ dispatch, type: "error", message: `Passwords do not match.`, showTime: 5000 })
			return;
		}
		setSignupLoading(true);
		try {
			const axiosForJSON = axiosInstance('application/json');
			const res = await axiosForJSON.post(AppUrl.registerUser, {
				email: signupValues.email,
				password: handleEncryptionURLKeys({ needToEncrypt: signupValues.password }),
				source: '#CLONOS@web',
			});
			if (res.status === 200) {
				// toast.success('User registered successfully! You can now log in.');
				 handleShowErrorAndWarning({ dispatch, type: "success", message: 'User registered successfully! You can now log in.', showTime: 5000 })
				setSignupValues({ email: '', password: '', confirmPassword: '' });
			} else {
						 handleShowErrorAndWarning({ dispatch, type: "error", message: res.data?.message || 'Registration failed.', showTime: 5000 })
				// toast.error(res.data?.message || 'Registration failed.');
			}
		} catch (err) {
			// toast.error(err.response?.data?.message || 'Registration failed.');
			 handleShowErrorAndWarning({ dispatch, type: "error", message: err.response?.data?.message || 'Registration failed.', showTime: 5000 })
		} finally {
			setSignupLoading(false);
		}
	};


	/*
date            qid / cr#         comments
15-Apr-2026     CR0014             The secret key is stored in session storage as x-device-key and is sent in the request headers for each API call.

*/

	const handleInitialLogin = async () => {
		setLoading(true);
		setError('');
		try {
			const axiosForJSON = axiosInstance('application/json');
			const res = await axiosForJSON.post(AppUrl.signin, {
				email: lcValues.email,
				password: handleEncryptionURLKeys({ needToEncrypt: lcValues.password }),
				source: '#CLONOS@web',
			});
			

			if (res.data?.result?.businessUnitToken) {
				// User has multiple organizations/business units
				setAuthData({
					authId: res.data.result.authId,
					businessUnitToken: res.data.result.businessUnitToken
				});
				await fetchLinkedUnits(res.data.result.authId, res.data.result.businessUnitToken);
				setShowOrgSelection(true);
			} else if (res.data?.result?.accessToken) {
				// Single business unit - set up session and navigate
				const token = res.data.result.accessToken;
				const tokenDecoded = jwtDecode(token);
				// console.log(tokenDecoded,"tokenDecoded")
				const tokenExpiry = new Date(tokenDecoded.exp * 1000);
				const secretKey = tokenDecoded?.secretKey
				
				// Set token in cookies
				Cookies.set("token", token, { expires: tokenExpiry });
				sessionStorage.setItem("x-device-key", JSON.stringify(secretKey));
				// // Set token in localStorage
				// localStorage.setItem('token', token);
				
				// // Create user session object
				// const userDetails = {
				// 	userId: tokenDecoded.id,
				// 	permissions: tokenDecoded.permissions || {},
				// 	isSuperAdmin: tokenDecoded.isSuperAdmin || false
				// };
				
				// // Store user details in localStorage
				// localStorage.setItem('loginUser', JSON.stringify(userDetails));

				const user = await getLoggedInUserDetailsByUserId({ userId: tokenDecoded?.id, token: token,secretKey:secretKey}) || {};
				setUserSession({
					token: token,
					isSuperAdmin: tokenDecoded.isSuperAdmin || false,
					userDetails: { ...user, permissions: tokenDecoded?.permissions}
				});
				
			    handleShowErrorAndWarning({ dispatch, type: "success", message: `Welcome ${handleLoggedInUser()?.name.split(" ")[0]}, Login Successful.`, showTime: 5000 })
				// Navigate to home page
				navigate('/home');
				// window.location.reload();
				
			}
		} catch (err) {
			 handleShowErrorAndWarning({ dispatch, type: "error", message: err.response?.data?.message || 'Registration failed.', showTime: 5000 })
			// setError(err.response?.data?.message || 'Login failed');
		} finally {
			setLoading(false);
		}
	};

	const fetchLinkedUnits = async (authId, businessUnitToken) => {
		try {
			const axiosForJSON = axiosInstance('application/json');
			const res = await axiosForJSON.post(`${AppUrl.getLinkedUnits}/${authId}/linkedUnits`, {
				businessUnitToken
			}, {
				headers: {
					Authorization: `Bearer ${businessUnitToken}`
				}
			});
			setOrganizations(res.data.result);
		} catch (err) {
			setError(err.response?.data?.message || 'Failed to fetch organizations');
		}
	};

	const handleOrgSelection = async () => {
		if (!selectedOrg || !selectedBusinessUnit) {
			setError('Please select both organization and business unit');
			return;
		}

		setLoading(true);
		setError('');
		try {
			const axiosForJSON = axiosInstance('application/json');
			const res = await axiosForJSON.post(
				`${AppUrl.verifyBusinessUnitToken}/${authData.authId}/businessUnit/${selectedBusinessUnit.id}/verifyBusinessUnitToken`,
				{ businessUnitToken: authData.businessUnitToken }
			);

			if (res.data?.result?.accessToken) {
				// Store token in cookies and localStorage
				const token = res.data.result.accessToken;
				const tokenDecoded = jwtDecode(token);
				const tokenExpiry = new Date(tokenDecoded.exp * 1000);
				const secretKey = tokenDecoded?.secretKey
				// Set token in cookies
				Cookies.set("token", token, { expires: tokenExpiry });
			    sessionStorage.setItem("x-device-key", JSON.stringify(secretKey));
				
				// // Set token in localStorage
				// localStorage.setItem('token', token);
				
				// // Create user session object
				// const userDetails = {
				// 	userId: tokenDecoded.id,
				// 	businessUnit: selectedBusinessUnit,
				// 	permissions: tokenDecoded.permissions || {},
				// 	isSuperAdmin: tokenDecoded.isSuperAdmin || false
				// };
				
				// // Store user details in localStorage
				// localStorage.setItem('loginUser', JSON.stringify(userDetails));
				
				// // Navigate to home page
				// navigate('/home');
				const user = await getLoggedInUserDetailsByUserId({ userId: tokenDecoded?.id, token: token,secretKey:secretKey}) || {};
				setUserSession({
					token: token,
					isSuperAdmin: tokenDecoded.isSuperAdmin || false,
					userDetails: { ...user, permissions: tokenDecoded?.permissions}
				});
				
			    handleShowErrorAndWarning({ dispatch, type: "success", message: `Welcome ${handleLoggedInUser()?.name.split(" ")[0]}, Login Successful.`, showTime: 5000 })
				// Navigate to home page
				navigate('/home');
				// window.location.reload();
				
			}
		} catch (err) {
			setError(err.response?.data?.message || 'Verification failed');
		} finally {
			setLoading(false);
		}
	};

	return (
		<>
		<div className={Styles.main_container}>
			<section aria-label='carousel container' className={Styles.carousel_container}>
				<div aria-label='logo and heading container' className={Styles.logo_and_heading_container}>
					<header aria-label='logo and heading' className={Styles.logo_and_heading_element}>
						<img src={CLONOS_APP_LOGO} alt='logo' />
						<h3>Clonos</h3>
					</header>
					<span>{CLONOS_GLOBAL_VENDOR}</span>
				</div>
				<div aria-label='carousel image container' className={Styles.carousel_image_body}>

					<div className={Styles.carousel_image_container}>
						<img className={Styles.carousel_image} src={carouselData[carouselCurrentIndex - 1].image} alt={carouselData[carouselCurrentIndex - 1].heading} loading='lazy' />
					</div>

					<div className={Styles.carousel_image_heading_container}>
						<h3 className={Styles.carousel_image_heading}>{carouselData[carouselCurrentIndex - 1].heading}</h3>
						<p className={Styles.carousel_image_paragraph}>{carouselData[carouselCurrentIndex - 1].paragraph}</p>
					</div>
				</div>
				<footer className={Styles.carousel_footer}>
					<div className={Styles.carousel_image_indicator_container}>
						{
							carouselData?.map((element, index) => {
								return <span key={element.index} style={{ opacity: element?.index === carouselCurrentIndex ? 1 : 0.3 }} className={Styles.carousel_image_indicator_container_element}></span>
							})
						}
					</div>
				</footer>
			</section>
			<section aria-label='login fields container' className={Styles.login_fields_container}>
				<div className={Styles.login_fields_wrapper}>
					<div className={Styles.login_fields_body}>
						{!showSignup && !showOrgSelection ? (
							<>
								<header className={Styles.login_fields_header}>
									<h3>Welcome!</h3>
									<p>Please login to access your account.</p>
								</header>
								<ClonosInput
									isLabel={true}
									isMandatory={true}
									uniqueKey="email"
									type="email"
									label="User Email Id"
									areaLabel="email"
									placeholder="Enter Your Email Id"
									handleGetValues={lcHandleGetValues}
									handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
								/>
								<ClonosInput
									isLabel={true}
									isMandatory={true}
									uniqueKey="password"
									type="password"
									label="Password"
									areaLabel="passwork"
									placeholder="Enter Your Password"
									handleGetValues={lcHandleGetValues}
									handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
								/>
								<p className={Styles.forgot_password} onClick={()=> setForgetPasswordModal()}>Forgot Password?</p>
								{error && <p className={Styles.error_message}>{error}</p>}
								<div className={Styles.button_container}>
									<ClonosButton 
										variant="filled" 
										style={{ flex: 1 }} 
										loading={loading} 
										onClick={handleInitialLogin}
									>
										Login
									</ClonosButton>
									<ClonosButton 
										variant="text" 
										style={{ flex: 1 }} 
										onClick={() => setShowSignup(true)}
									>
										Sign Up
									</ClonosButton>
								</div>
							</>
						) : showOrgSelection ? (
							<div className={Styles.org_selection_container}>
								<h4>Select Organization and Business Unit</h4>
								{organizations.length > 1 ? (
									<div className={Styles.select_container}>
										<label>Organization</label>
										<select 
											value={selectedOrg?.id || ''} 
											onChange={(e) => {
												const org = organizations.find(o => o.organization.id === e.target.value);
												setSelectedOrg(org.organization);
												setSelectedBusinessUnit(null);
											}}
											className={Styles.select_input}
										>
											<option value="">Select Organization</option>
											{organizations.map(org => (
												<option key={org.organization.id} value={org.organization.id}>
													{org.organization.name}
												</option>
											))}
										</select>
									</div>
								) : null}
								<div className={Styles.select_container}>
									<label>Business Unit</label>
									<select 
										value={selectedBusinessUnit?.id || ''} 
										onChange={(e) => {
											const bu = organizations
												.find(o => o.organization.id === selectedOrg?.id)
												?.businessUnits.find(bu => bu.id === e.target.value);
											setSelectedBusinessUnit(bu);
										}}
										className={Styles.select_input}
									>
										<option value="">Select Business Unit</option>
										{organizations
											.find(o => o.organization.id === selectedOrg?.id)
											?.businessUnits.map(bu => (
												<option key={bu.id} value={bu.id}>
													{bu.name}
												</option>
											))}
									</select>
								</div>
								{error && <p className={Styles.error_message}>{error}</p>}
								<ClonosButton 
									variant="filled" 
									style={{ width: "100%", marginTop: 16 }} 
									loading={loading} 
									onClick={handleOrgSelection}
								>
									Continue
								</ClonosButton>
								<div style={{ textAlign: 'center', marginTop: 16 }}>
									<ClonosButton 
										variant="text" 
										style={{ width: '100%' }} 
										onClick={() => {
											setShowOrgSelection(false);
											setAuthData(null);
											setSelectedOrg(null);
											setSelectedBusinessUnit(null);
											setOrganizations([]);
										}}
									>
										Back to Login
									</ClonosButton>
								</div>
							</div>
						) : (
							<div className={Styles.signup_container}>
								<header className={Styles.login_fields_header}>
									<h3>Create Account</h3>
									<p>Please fill in the details to create your account.</p>
								</header>
								<div className={Styles.login_fields_body}>
									<ClonosInput
										isLabel={true}
										isMandatory={true}
										uniqueKey="email"
										type="email"
										label="User Email Id"
										areaLabel="email"
										placeholder="Enter Your Email Id"
										handleGetValues={handleSignupInput}
										handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
									/>
									<ClonosInput
										isLabel={true}
										isMandatory={true}
										uniqueKey="password"
										type="password"
										label="Password"
										areaLabel="password"
										placeholder="Enter Your Password"
										handleGetValues={handleSignupInput}
										handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
									/>
									<ClonosInput
										isLabel={true}
										isMandatory={true}
										uniqueKey="confirmPassword"
										type="password"
										label="Confirm Password"
										areaLabel="confirmPassword"
										placeholder="Confirm Your Password"
										handleGetValues={handleSignupInput}
										handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
									/>
									<div className={Styles.button_container}>
										<ClonosButton 
											variant="filled" 
											style={{ flex: 1 }} 
											loading={signupLoading} 
											onClick={handleSignup}
										>
											Sign Up
										</ClonosButton>
										<ClonosButton 
											variant="text" 
											style={{ flex: 1 }} 
											onClick={() => setShowSignup(false)}
										>
											Back to Login
										</ClonosButton>
									</div>
								</div>
							</div>
						)}
					</div>
				</div>
			</section>
		</div>
  
			<Modal isOpen={forgetPasswordModal} closeModalMethod={setForgetPasswordModal}>
		<div className={Styles.modal_content}>
			<header className={Styles.modal_header}>
			<span>Forget Password</span>
			<CloseIcon 
				className={Styles.close_icon} 
				onClick={() => setForgetPasswordModal(false)} 
			/>
			</header>

			<p className={Styles.modal_message}>
			 Please Contact Admin! 
			</p>
		</div>
		</Modal>




   
</>
	)
}

export default ClonosLogin