import { AlertTriangleFilled } from "../../../../assets/Clonos Common Indicators/Icon_Components/AlertTriangleFilled"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { WarningIcon } from "../../../../assets/Clonos Common Indicators/Icon_Components/WarningIcon"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "./WarningPopup.module.css"

export const WarningPopup = ({isOpen,closeMethod,title,message,name,id,proceedMethod}) => {

    return <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
            <div className={Styles.w_p_container}>
                <div className={Styles.w_p_header}>
                    <div className={Styles.w_p_h_text}>
                        <AlertTriangleFilled/>
                        <h4>{title}</h4>
                    </div>
                    <div className={Styles.w_p_close_icon}>
                        <CloseIcon onClick={() => closeMethod(false)}/>
                    </div>
                </div>
                <div className={Styles.w_p_section}>
                    <div className={Styles.w_p_message_wrapper}>
                        <p>{message}</p>
                        <div>
                            {name ? <h4>{name}</h4> : <></>}
                            {id ? <h4>{id}</h4> : <></>}
                        </div>
                    </div>
                    <div className={Styles.w_p_btns_wrapper}>
                        <div>
                            <ClonosButton onClick={() => closeMethod(false)} style={{border:"1px solid #E0606A",color:"#E0606A",padding:"0.8rem 2rem"}}>Cancel</ClonosButton>
                            <ClonosButton onClick={proceedMethod} style={{padding:"0.8rem 2rem"}}>Yes</ClonosButton>
                        </div>
                    </div>
                </div>
            </div>
    </Modal>
}