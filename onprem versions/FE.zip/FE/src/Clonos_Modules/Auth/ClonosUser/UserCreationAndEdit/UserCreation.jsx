import {  Card, Typography ,Button, Box, Modal} from "@mui/material";
import React, { useEffect, useState } from 'react'
import { globalHandleIsAllRequiredFieldAvailable, checkUserHasPermission, handleShowErrorAndWarning, debounce, modifyString, getUser } from '../../../../utils/clonosCommon'
import { UnAuthorizedModal } from '../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/UserCreationAndEdit/UserCreationAndEdit.module.css"
import ClonosInput from '../../../../components/CommonComponents/ClonosInput/ClonosInput'
import ClonosSelect from '../../../../components/CommonComponents/ClonosSelect/ClonosSelect'
import FileUploader from '../../../../components/CommonComponents/FileUploader/FileUploader'
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button'
import { checkIsEmployeeIdUnique, createUserMethod, getBusinessUnitDropdownData, getDepartmentDropdownData, getDesignationDropdownData, getSingleUserDetails, getTeamDropdownData, getUserTypeDropdownData, getUsersDropdownData, handleCheckUniqueFieldsOfUser, handleGetShiftDropdownData, handleShouldWarningModalOpen, saveUserAsDraftMethod } from '../../../../utils/UsersMethods/usersMethods'
import { useLocation, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import DynamicDropdown from '../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown'
import useToggler from '../../../../CustomHooks/TogglerHook'
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner'
import { fieldsNeedsToBeRestrictFromEdit } from '../../../../utils/AuthMethods/Constant'
import { EditUserWarningModal } from './Components/EditWarning/EditUserWarningModal'
import { UserPermissionAssignment } from '../Permissions/UserPermissionAssignement'
import { countriesCode } from '../../../../Constants/StaticData'
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_USERS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS } from '../../../../Constants/Constant'
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook'
import useFieldsChecker from '../../../../CustomHooks/FieldsValidatorHook'
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import ClonosNextConfirmationBox from "../../../../components/CommonComponents/ClonosNextConfirmationBox/ClonosNextConfirmationBox";
import { handleCheckUniqueFieldsMethod } from '../../../../utils/common-managers'
import CryptoJS from "crypto-js";
import { getOrganizations } from '../../../../Api/Admin/AdminApi'

const UserCreation = () => {

    const Navigate = useNavigate();
    const dispatch = useDispatch();
    const user = getUser();
    // const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_USERS);
    const moduleName = CLONOS_GLOBAL_MODULE_USERS;
    const [formData, setFormData] = useState({ countryCode: { "name": "(IN) +91", "id": "+91" } });
    const [isLoading, setIsLoading] = useToggler();
    const [shiftDropdownData,setShiftDropdownData] = useState([]);
    const [draftLoader, setDraftLoader] = useToggler();
    const [resetFields, setResetFields] = useState({});
    const [showConfirmationDialog, setShowConfirmationDialog] = useState(false)
    const [showPasswordDialog,setShowPasswordDialog]=useState(false)
    const [decryptPassword,setDecryptPassword]=useState('')
    const [isUniqueField, setIsUniqueField] = useState({ employeeId: false })
    const [createdUserDetails, setCreatedUserDetails] = useState({});
    const [teamDropdownData, setTeamDropdownData] = useState([]);
    const [userTypeDropData, setUserTypeDropdownData] = useState([]);
    const [resetFieldWarning, setResetFieldWarning] = useState(false);
    const [departmentDropData, setDepartmentDropdownData] = useState([]);
    const [designationDropData, setDesignationDropdownData] = useState([]);
    const [reportsToDropdownData, setReportsToDropdownData] = useState({ data: [] });
    const [searchedReportsToData,setSearchedReportsToData] = useState({});
    const [businessUnitDropData, setBusinessUnitDropdownData] = useState([]);
    const [showPermissionsManager, setShowPermissionsManager] = useState(false);
    const [reportsToPagination, setReportsToPagination] = useState({ page: 1, limit: 15 })
    const [editWarningState, setEditWarningState] = useState({ isValueSelected: false, value: "" });
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })
    const [organizationDropData, setOrganizationDropdownData] = useState([]);
    const [selectedOrganization, setSelectedOrganization] = useState(null);

    

 const decryptToken = (encryptedText, secretKey) => {
  try {
    if (!encryptedText || !secretKey) {
      throw new Error("Missing encrypted text or secret key");
    }

    // Ensure key is exactly 32 bytes
    const paddedKey = CryptoJS.enc.Utf8.parse(secretKey.padEnd(32, "0"));

    // Decode from Base64
    const encryptedData = CryptoJS.enc.Base64.parse(encryptedText);

    // Extract IV (first 16 bytes) and CipherText
    const iv = CryptoJS.lib.WordArray.create(encryptedData.words.slice(0, 4)); // IV is first 16 bytes
    const cipherText = CryptoJS.lib.WordArray.create(encryptedData.words.slice(4)); // Remaining = Ciphertext

    // Decrypt using AES-CBC
    const decrypted = CryptoJS.AES.decrypt(
      { ciphertext: cipherText },
      paddedKey,
      { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
    );

    const decryptedText = decrypted.toString(CryptoJS.enc.Utf8);
    return decryptedText || "Decryption failed!";
  } catch (error) {
    console.error("Decryption error:", error);
    return "Decryption error!";
  }
};

    const handleGetValues = (props) => {
        const { name, selectedOption, updatedValue, uniqueKey, type,files, businessUnitId } = props;
        if (type === "dynamicDropdown") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? { name: selectedOption[0]?.name, id: selectedOption[0].id } : null }
            })
        } else if (type === "select") {
            if (fieldsNeedsToBeRestrictFromEdit.includes(uniqueKey) && formData[uniqueKey]) {
                const oldValue = formData[uniqueKey];
                if (oldValue?.id !== updatedValue?.value && handleShouldWarningModalOpen({ uniqueKey, formData })) {
                    setResetFieldWarning(true)
                    setEditWarningState((prev) => ({ isValueSelected: true, value: props }))
                } else {
                    const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                    setFormData((prev) => {
                        return { ...prev, [uniqueKey]: valueSetter ? { name: updatedValue?.label, id: updatedValue.value } : null }
                    })
                }
            } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ? { name: updatedValue?.label, id: updatedValue.value } : null }
                })
            }
        } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email") {
            if (uniqueKey === "email" || uniqueKey === "employeeId") {
                if (updatedValue?.length) {
                    debouncedCheckUniquenessOfEmloyeeId({ fieldName: uniqueKey, fieldValue: updatedValue, businessUnitId: businessUnitId });
                }
            } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
                })
            }
        } else if(type === "file") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: files[0] })
                setFormData((prev) => {
                    return { ...prev, [uniqueKey]: files[0] }
                })
        }
    };

    const uniqueFieldHandler = ({ fieldName, fieldValue }) => {
        if (!formData?.businessUnit?.id && (fieldName === 'email' || fieldName === 'employeeId')) {
            primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
            primaryObject?.[fieldName]?.errorActivatorMethod(true);
            primaryObject?.[fieldName]?.errorSetterMethod(`Please select a business unit first.`);
            return;
        }

        handleCheckUniqueFieldsMethod({ 
            module: "users", 
            fieldName, 
            fieldValue, 
            businessUnit: formData?.businessUnit?.id 
        }).then((res) => {
            if (res === "unique") {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
                setFormData((prev) => {
                    return { ...prev, [fieldName]: valueSetter ? fieldValue : null }
                })
                setIsUniqueField((prev) => ({ ...prev, [fieldName]: false }))
            } else if (res === "not_unique") {
                primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
                primaryObject?.[fieldName]?.errorActivatorMethod(true);
                primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${modifyString(fieldName, "spacecase")}.`)
            }
        })
    }


    const debouncedCheckUniquenessOfEmloyeeId = debounce(uniqueFieldHandler, 500);

    const handleMoreData = (props) => {
        if (reportsToDropdownData?.totalPageCount > reportsToPagination?.page) {
            setReportsToPagination((prev) => {
            getUsersDropdownData({ 
                userRole: "", 
                setterMethod: setReportsToDropdownData, 
                dispatch, 
                filterPayload: { 
                    page: prev?.page + 1, 
                    limit: 15,
                    businessUnit: formData?.businessUnit?.id // Add businessUnit to the filter
                } 
            });
            return {...prev, page: prev?.page + 1}
            })
        }
    }

    const handleCreateUser = async (props) => {
        if (!globalHandleIsAllRequiredFieldAvailable({ data: formData, primaryObject })) return
        const response = await createUserMethod({ payload: formData, dispatch, Navigate, setIsLoading });
     
    
        if (response?.id) {
            handleShowErrorAndWarning({ dispatch, type: "success", message: "User Registered successfully.", showTime: "5000" })
            setCreatedUserDetails({ ...formData, ...response })
            setShowPermissionsManager(true);
        }


    }

    const handleFilterUsers = (props) => {
        const { uniqueKey, input } = props;
        if(input?.length) {
        getUsersDropdownData({ 
            userRole: "", 
            setterMethod: setSearchedReportsToData, 
            dispatch, 
            filterPayload: { 
                name: input,
                businessUnit: formData?.businessUnit?.id // Add businessUnit to the filter
            } 
        })
        } else {
            setSearchedReportsToData({})
        }
    }


    const handleChangeRestrictedValues = ({ action, field }) => {
        if (action === "save") {
            const { name, selectedOption, updatedValue, uniqueKey, type } = editWarningState?.value;
            if (type === "select") {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
                setFormData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ? { name: updatedValue?.label, id: updatedValue.value } : null }
                })
            }
        }
        setEditWarningState({ isValueSelected: false, value: "" })
        setResetFieldWarning(false)
    }

   
  const [shouldLoadUsers, setShouldLoadUsers] = useState(false);
   
    useEffect(() => {
    // Only load users if the flag is true
    if (shouldLoadUsers) {
        getUsersDropdownData({ userRole: "", setterMethod: setReportsToDropdownData, dispatch, filterPayload: reportsToPagination });
    }
    
    if (user?.isSuperAdmin) {
        getOrganizations().then(response => {
            if (response?.data?.result?.data) {
                setOrganizationDropdownData(response.data.result.data);
            }
        });
    } else {
        getBusinessUnitDropdownData({ userRole: "", setterMethod: setBusinessUnitDropdownData, dispatch });
    }
}, [shouldLoadUsers]);

    

    useEffect(() => {
        if (formData?.organization) {
            getBusinessUnitDropdownData({ 
                userRole: "", 
                setterMethod: setBusinessUnitDropdownData, 
                dispatch,
                organizationId: formData?.organization?.id 
            });
            let tempData = { ...formData }
            setResetFields((prev) => ({ 
                businessUnit: tempData?.businessUnit ? true : false,
                department: tempData?.department ? true : false, 
                userType: tempData?.userType ? true : false, 
                designation: tempData?.designation ? true : false, 
                team: tempData?.team ? true : false,
                shift: tempData?.shift ? true : false 
            }));
            delete formData.businessUnit
            delete formData.department
            delete formData.userType
            delete formData.designation
            delete formData.team
            delete formData.shift
            setFormData(formData)
        }
    }, [formData?.organization])

    useEffect(() => {
        if (formData?.businessUnit) {
            getDepartmentDropdownData({ 
                userRole: "", 
                setterMethod: setDepartmentDropdownData, 
                dispatch, 
                selectedBusinessUnit: formData?.businessUnit?.id 
            });
            handleGetShiftDropdownData({
                setterMethod: setShiftDropdownData,
                businessUnitId: formData?.businessUnit?.id,
                dispatch
            });
            getUsersDropdownData({ 
                userRole: "", 
                setterMethod: setReportsToDropdownData, 
                dispatch, 
                filterPayload: {
                    ...reportsToPagination,
                    businessUnit: formData?.businessUnit?.id
                }
            });
            let tempData = { ...formData }
            setResetFields((prev) => ({ 
                department: tempData?.department ? true : false, 
                userType: tempData?.userType ? true : false, 
                designation: tempData?.designation ? true : false, 
                team: tempData?.team ? true : false,
                shift: tempData?.shift ? true : false,
                reportsTo: tempData?.reportsTo ? true : false
            }));
            delete formData.department
            delete formData.userType
            delete formData.designation
            delete formData.team
            delete formData.shift
            delete formData.reportsTo
            setFormData(formData)
        }
    }, [formData?.businessUnit?.id])

    useEffect(() => {
        if (formData?.department?.name) {
            getUserTypeDropdownData({ userRole: "", setterMethod: setUserTypeDropdownData, dispatch, selectedBusinessUnit: formData?.businessUnit?.id, selectedDepartment: formData?.department?.id })
            getTeamDropdownData({ userRole: "", setterMethod: setTeamDropdownData, dispatch, selectedBusinessUnit: formData?.businessUnit?.id, selectedDepartment: formData?.department?.id })
            let tempData = { ...formData }
            setResetFields((prev) => ({ userType: tempData?.userType?.id ? true : false, designation: tempData?.designation ? true : false, team: tempData?.team ? true : false }));
            delete formData.userType
            delete formData.designation
            delete formData.team
            setFormData(formData)
        }
    }, [formData?.department])

    useEffect(() => {
        if (formData?.userType) {
            getDesignationDropdownData({ userRole: "", setterMethod: setDesignationDropdownData, dispatch, selectedBusinessUnit: formData?.businessUnit?.id, selectedDepartment: formData?.department?.id, selectedUserType: formData?.userType?.id })
            let tempData = { ...formData }
            setResetFields((prev) => ({ designation: tempData?.designation ? true : false }));
            delete formData.designation
            setFormData(formData)
        }
    }, [formData?.userType]);

    if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE })) {
        return (
            <>
                {
                    showPermissionsManager ? <UserPermissionAssignment userDetails={createdUserDetails} /> : <>
                        <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                            <div
                                aria-label='User creation and edit container'
                                className={Styles.main_container}
                            >
                                <section
                                    className={Styles.form_field_container}
                                >
                                    <div>
                                        <ClonosInput
                                            limit={50}
                                            type="text"
                                            tabIndex={1}
                                            isLabel={true}
                                            isMandatory={true}
                                            label="First Name"
                                            uniqueKey="firstName"
                                            areaLabel="First name"
                                            placeholder="First Name"
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please provide first name."}
                                            isSpecialCharacterAllow={true}
                                            onlyAllowTheseSpecialCharacters={["-", "_"]}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        />
                                        <ClonosInput
                                            limit={50}
                                            type="text"
                                            tabIndex={2}
                                            isLabel={true}
                                            isMandatory={true}
                                            label="Last Name"
                                            uniqueKey="lastName"
                                            areaLabel="Last name"
                                            placeholder="Last Name"
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please provide last name."}
                                            isSpecialCharacterAllow={true}
                                            onlyAllowTheseSpecialCharacters={["-", "_"]}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        />

                                        

                                        {user?.isSuperAdmin && (
                                            <ClonosSelect
                                                type="select"
                                                tabIndex={3}
                                                isLabel={true}
                                                isMandatory={true}
                                                placeholder="Select"
                                                label="Organization"
                                                uniqueKey="organization"
                                                areaLabel="Organization"
                                                handleGetValues={handleGetValues}
                                                errorMessage={"Please provide organization."}
                                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                options={organizationDropData?.map((org) => ({ 
                                                    label: org?.name, 
                                                    value: org?.id, 
                                                    isNeeded: true, 
                                                    isChecked: false 
                                                })) || []}
                                            />
                                        )}

                                        <ClonosSelect
                                            type="select"
                                            tabIndex={4}
                                            isLabel={true}
                                            isMandatory={true}
                                            placeholder="Select"
                                            label="Business Unit"
                                            uniqueKey="businessUnit"
                                            areaLabel="Business unit"
                                            disabled={user?.isSuperAdmin && !formData?.organization?.id}
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please provide business unit."}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            options={businessUnitDropData?.map((unit) => ({ 
                                                label: unit?.name, 
                                                value: unit?.id, 
                                                isNeeded: true, 
                                                isChecked: false 
                                            })) || []}
                                        />

                                        <ClonosSelect
                                            type="select"
                                            tabIndex={5}
                                            isLabel={true}
                                            isMandatory={true}
                                            label="Department"
                                            placeholder="Select"
                                            uniqueKey="department"
                                            areaLabel="Department"
                                            disabled={!formData?.businessUnit?.id}
                                            reset={resetFields?.department}
                                            // value={formData?.department?.name}
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please provide department."}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            noDataMessage={!departmentDropData?.length ? "No departments present for selected business unit." : ""}
                                            options={departmentDropData?.map((department) => ({ label: department?.name, value: department?.id, isNeeded: true })) || []}
                                        />
                                        <ClonosSelect
                                            type="select"
                                            tabIndex={6}
                                            isLabel={true}
                                            isMandatory={true}
                                            label="User Type"
                                            uniqueKey="userType"
                                            placeholder="Select"
                                            areaLabel="User type"
                                            reset={resetFields?.userType}
                                            value={formData?.userType?.name}
                                            handleGetValues={handleGetValues}
                                            disabled={!formData?.department?.id}
                                            errorMessage={"Please provide user type."}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            noDataMessage={!userTypeDropData?.length ? "No user types present for selected department." : ""}
                                            options={userTypeDropData?.map((type) => ({ label: type?.name, value: type?.id, isNeeded: true })) || []}
                                        />
                                        <ClonosSelect
                                            type="select"
                                            tabIndex={7}
                                            isLabel={true}
                                            isMandatory={true}
                                            placeholder="Select"
                                            label="Designation"
                                            uniqueKey="designation"
                                            areaLabel="Designation"
                                            reset={resetFields?.designation}
                                            value={formData?.designation?.name}
                                            handleGetValues={handleGetValues}
                                            disabled={!formData?.userType?.id}
                                            errorMessage="Please provide designation."
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            noDataMessage={!designationDropData?.length ? "No designations present for selected user type." : ""}
                                            options={designationDropData?.map((designation) => ({ label: designation?.name, value: designation?.id, isNeeded: true })) || []}
                                        />
                                        <ClonosSelect
                                            type="select"
                                            tabIndex={8}
                                            label="Team"
                                            isLabel={true}
                                            uniqueKey="team"
                                            areaLabel="Team"
                                            placeholder="Select"
                                            reset={resetFields?.team}
                                            handleGetValues={handleGetValues}
                                            disabled={!formData?.department?.id}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            noDataMessage={!teamDropdownData?.data?.length ? "No teams present for selected department." : ""}
                                            options={teamDropdownData?.data?.map((team) => ({ label: team?.name, value: team?.id, isNeeded: true })) || []}
                                        />
                                        <DynamicDropdown
                                            isUser={true}
                                            tabIndex={9}
                                            isLabel={true}
                                            isCheckbox={false}
                                            label="Report To"
                                            title="Report To"
                                            isActivator={true}
                                            isMandatory={!user?.isSuperAdmin}
                                            isSearchable={true}
                                            placeholder="Select"
                                            uniqueKey="reportsTo"
                                            areaLabel="Report to"
                                            populatedFields={["employeeId"]}
                                            handleMoreData={handleMoreData}
                                            handleGetValues={handleGetValues}
                                            heading={"Select from User Library"}
                                            errorMessage={"Please provide reports To."}
                                            handleDynamicSearch={handleFilterUsers}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            isDynamicLoad={reportsToDropdownData?.totalPageCount > reportsToPagination?.page}
    disabled={!formData?.businessUnit?.id} // Add this line to disable until business unit is selected
    reset={resetFields?.reportsTo} // Add this line for reset functionality
    data={searchedReportsToData?.currentPage ? searchedReportsToData?.data?.map((user) => ({ name: user?.name, id: user?.id, isNeeded: true, employeeId: user?.employeeId })) : reportsToDropdownData?.data?.map((user) => ({ name: user?.name, id: user?.id, isNeeded: true, employeeId: user?.employeeId })) || []}
                                        />
                                        <ClonosSelect
                                            type="select"
                                            tabIndex={10}
                                            isLabel={true}
                                            isMandatory={true}
                                            label="Shift"
                                            uniqueKey="shift"
                                            placeholder="Select"
                                            areaLabel="Shift"
                                            disabled={!formData?.businessUnit?.id}
                                            defaultValue={formData?.shift?.name}
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please provide shift."}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            options={shiftDropdownData?.map((shift) => ({ label: shift?.name, value: shift?.id, isNeeded: true })) || []}
                                        />
                                        <ClonosInput
                                            type="text"
                                            limit={320}
                                            tabIndex={11}
                                            isLabel={true}
                                            isMandatory={true}
                                            uniqueKey="employeeId"
                                            label="Employee ID"
                                            areaLabel="Employee ID"
                                            placeholder="Employee ID"
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please provide employee ID."}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            disabled={!formData?.businessUnit?.id}
                                        />
                                        <ClonosInput
                                            type="email"
                                            limit={320}
                                            tabIndex={12}
                                            isLabel={true}
                                            isMandatory={true}
                                            uniqueKey="email"
                                            label="Email Address"
                                            areaLabel="Email address"
                                            placeholder="abc@gmail.com"
                                            handleGetValues={handleGetValues}
                                            errorMessage={"Please provide email."}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                            disabled={!formData?.businessUnit?.id}
                                        />
                                        <div className={Styles.contact_num_wrapper}>
                                            <label>Contact Number <sup style={{ color: "red", fontSize: "0.8rem" }}>*</sup></label>
                                            <div className={Styles.contact_num_flex}>
                                                <div className={Styles.region_code_wrapper}>
                                                    <ClonosSelect
                                                        type="select"
                                                        tabIndex={13}
                                                        isLabel={false}
                                                        isMandatory={true}
                                                        position="top"
                                                        label="Contact Number"
                                                        uniqueKey="countryCode"
                                                        areaLabel="Country Code"
                                                        placeholder="Country Code"
                                                        defaultValue={formData?.countryCode?.name}
                                                        handleGetValues={handleGetValues}
                                                        errorMessage={"Please provide country code."}
                                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                        options={countriesCode?.map((country) => ({ label: `(${country?.shortCode}) ${country?.code}`, value: country?.code, isNeeded: true }))}
                                                    />
                                                </div>
                                                <div className={Styles.num_wrapper}>
                                                    <ClonosInput
                                                        limit={10}
                                                        type="number"
                                                        tabIndex={14}
                                                        isLabel={false}
                                                        isMandatory={true}
                                                        uniqueKey="contactNumber"
                                                        areaLabel="Contact number"
                                                        placeholder="Enter Mobile Number"
                                                        handleGetValues={handleGetValues}
                                                        errorMessage="Please provide valid contact number."
                                                        // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <FileUploader
                                            label="Upload Image"
                                            uniqueKey="image"
                                            acceptableFileTypes={[".png", ".jpg", ".jpeg"]}
                                            limit={1}
                                            tabIndex={15}
                                            fileSizeInMB={10}
                                            handleGetSelectedData={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        />
                                        <FileUploader
                                            label="E-Signature"
                                            tabIndex={16}
                                            uniqueKey="eSignatureImage"
                                            acceptableFileTypes={[".png", ".jpg", ".jpeg"]}
                                            limit={1}
                                            fileSizeInMB={10}
                                            handleGetSelectedData={handleGetValues}
                                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        />
                                    </div>
                                </section>
                                <footer
                                    className={Styles.footer}
                                >
                                    <ClonosButton tabIndex={17} onClick={() => setShowConfirmationDialog(true)}>Cancel</ClonosButton>
                                    <ClonosButton tabIndex={18} variant="filled" loading={isLoading} onClick={() => handleCreateUser({ data: formData, primaryObject })}>Save & Next</ClonosButton>
                                </footer>
                            </div>
                        </Card>
                        {resetFieldWarning ? <EditUserWarningModal isOpen={resetFieldWarning} closeMethod={setResetFieldWarning} field={editWarningState?.value?.uniqueKey} handleChangeRestrictedValues={handleChangeRestrictedValues} formData={formData} /> : <></>}
                        <ClonosConfirmationBox
                            isOpen={showConfirmationDialog}
                            closeModalMethod={setShowConfirmationDialog}
                            confirmingMethod={() => setShowConfirmationDialog(false)}
                            rejectingMethod={() => Navigate("/users")}
                            message={"Are you sure to cancel it ?"}
                            headerTitle={"Cancel"}
                        />
                    </>
                }
            </>
        )
    };
    <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default UserCreation
// saveUserAsDraftMethod({payload:formData,Navigate,dispatch,setIsLoading})