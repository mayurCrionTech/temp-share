import { render, fireEvent, waitFor } from '@testing-library/react';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import UserCreation from './UserCreation';
import { MemoryRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from '../../../../Store/Store';
import { getToken } from '../../../../utils/clonosCommon';



// const mock = new MockAdapter(axios);
// test("Render User Cration", () => {
//     render(
//         <Provider store={store}>
//             <MemoryRouter>
//                 <UserCreation />
//             </MemoryRouter>
//         </Provider>
//     );
// })

describe('FormComponent with real API', () => {
    const token = `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY1ZmJmYTJiYjAyMGIyNDA3MWM0NWU5ZCIsImlzU3VwZXJBZG1pbiI6ZmFsc2UsImJ1c2luZXNzVW5pdCI6eyJuYW1lIjoiTWFuZGFwZXRhIiwic2hvcnROYW1lIjoiTURQIiwiaWQiOiI2NWY0ODkyNjgyN2UyNjJkODJmMmIwZWMifSwicGVybWlzc2lvbiI6eyJhc3NldCI6eyJFZGl0Ijp0cnVlLCJ1cGRhdGUiOnRydWUsImRlbGV0ZSI6dHJ1ZX0sInRlYW1zIjp7ImRlbGV0ZSI6dHJ1ZSwiY3JlYXRlIjp0cnVlLCJ1cGRhdGUiOnRydWUsInJlYWQiOnRydWV9LCJhc3NldHMiOnsicmVhZCI6dHJ1ZSwiY3JlYXRlIjp0cnVlLCJkZWxldGUiOnRydWUsInVwZGF0ZSI6dHJ1ZSwiZGVjb21taXNzaW9uIjp0cnVlLCJyZXN0b3JlIjp0cnVlfSwiZG9jdW1lbnRzIjp7ImNyZWF0ZSI6dHJ1ZSwicmVhZCI6dHJ1ZSwidXBkYXRlIjp0cnVlLCJkZWxldGUiOnRydWV9LCJwbGFudDNEIjp7ImRlbGV0ZSI6dHJ1ZSwiY3JlYXRlIjp0cnVlLCJ1cGRhdGUiOnRydWUsInJlYWQiOnRydWV9LCJtYWludGVuYW5jZVBsYW5zIjp7InJlYWQiOnRydWUsImNyZWF0ZSI6dHJ1ZSwidXBkYXRlIjp0cnVlLCJkZWxldGUiOnRydWV9LCJ0YXNrTGlicmFyeSI6eyJkZWxldGUiOnRydWUsImNyZWF0ZSI6dHJ1ZSwicmVhZCI6dHJ1ZSwidXBkYXRlIjp0cnVlfSwid29ya09yZGVycyI6eyJkdWVEYXRlRXh0ZW5zaW9uIjp0cnVlLCJjcmVhdGUiOnRydWUsInJlYWQiOnRydWUsInVwZGF0ZSI6dHJ1ZSwiZGVsZXRlIjp0cnVlfSwiY2hlY2tsaXN0cyI6eyJjcmVhdGUiOnRydWUsInVwZGF0ZSI6dHJ1ZSwiZGVsZXRlIjp0cnVlLCJyZWFkIjp0cnVlfSwibG9ncyI6eyJjcmVhdGUiOnRydWUsInVwZGF0ZSI6dHJ1ZSwiZGVsZXRlIjp0cnVlLCJyZWFkIjp0cnVlfX0sImlhdCI6MTcxOTIwMzIzNSwiZXhwIjoxNzE5NDE5MjM1fQ.2rsa3T-15s0xLSsxGDBKZQEjoAjjpaPBmWFjmPuA95s`

    const postData = {
        firstName: 'Rathees',
        lastName: 'P',
        employeeId: 'CR300',
        businessUnit: '65f48926827e262d82f2b0ec',
        department: '65f48a79827e262d82f2b128',
        userType: '65f48a86827e262d82f2b12d',
        designation: '65f48a8d827e262d82f2b132',
        team: '65fbf454b020b24071c45d3a',
        reportsTo: '663a21b0b0d4e2f9e812fbe9',
        email: 'guru.prasad@criontech.com',
        countryCode: '+49',
        contactNumber: 9988776655,
    };
    it('Create an user', async () => {
        const { getByPlaceholderText, getByText } = render(
            <Provider store={store}>
                <MemoryRouter>
                    <UserCreation />
                </MemoryRouter>
            </Provider>
        );

        await waitFor(async () => {
            const response = await fetch(`http://20.204.179.207:3333/api/v1/auth/signup`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json', // Set the content type based on your API's requirements
                    // Add any other headers if needed
                    Authorization: token
                },
                body: JSON.stringify(postData)
            })
            const resolvedData = await response.json();
            
        }, 30000)
    })
    it('Validate did your created or not?', async () => {

        await waitFor(async () => {
            const response = await fetch(`http://20.204.179.207:3333/api/v1/users/?selectFields=email`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json', // Set the content type based on your API's requirements
                    // Add any other headers if needed
                    Authorization: token,
                },
            });
            const savedData = await response.json();
           
            // Verify the returned data contains the submitted data
            const foundEntry = savedData?.result?.data?.find(user => {
              
                if (user.email === 'guru.prashad@criontech.com') {
                    return user;
                }
            });
           
            expect({ email: foundEntry.email }).toMatchObject({ email: postData.email });
        });
    })
});