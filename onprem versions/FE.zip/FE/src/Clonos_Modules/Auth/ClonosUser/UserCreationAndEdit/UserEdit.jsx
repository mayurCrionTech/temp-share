import { Card } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { globalHandleIsAllRequiredFieldAvailable, checkUserHasPermission, debounce, modifyString } from '../../../../utils/clonosCommon'
import { UnAuthorizedModal } from '../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/UserCreationAndEdit/UserCreationAndEdit.module.css"
import ClonosInput from '../../../../components/CommonComponents/ClonosInput/ClonosInput'
import ClonosSelect from '../../../../components/CommonComponents/ClonosSelect/ClonosSelect'
import FileUploader from '../../../../components/CommonComponents/FileUploader/FileUploader'
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button'
import { createUserMethod, editUserMethod, getAllExistingUsersParticularDetail, getBusinessUnitDropdownData, getDepartmentDropdownData, getDesignationDropdownData, getSingleUserDetails, getTeamDropdownData, getUserTypeDropdownData, getUsersDropdownData, handleGetShiftDropdownData, handleShouldWarningModalOpen } from '../../../../utils/UsersMethods/usersMethods'
import { useLocation, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import DynamicDropdown from '../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown'
import useToggler from '../../../../CustomHooks/TogglerHook'
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner'
import { EditUserWarningModal } from './Components/EditWarning/EditUserWarningModal'
import { fieldsNeedsToBeRestrictFromEdit } from '../../../../utils/AuthMethods/Constant'
import { countriesCode } from '../../../../Constants/StaticData'
import { CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_USERS } from '../../../../Constants/Constant'
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook'
import useFieldsChecker from '../../../../CustomHooks/FieldsValidatorHook'
import { handleCheckUniqueFieldsMethod } from '../../../../utils/common-managers'

let primaryObject = {};

const UserEdit = () => {

    const Navigate = useNavigate();
    const dispatch = useDispatch();
    const Location = useLocation();
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_USERS);
    const [formData, setFormData] = useState({});
    const [isLoading, setIsLoading] = useToggler();
    const [changedData, setChangedData] = useState({});
    const [resetFields, setResetFields] = useState({});
    const [shiftDropdownData,setShiftDropdownData] = useState([])
    const [fetchUserLoading, setFetchUserLoading] = useToggler();
    const [teamDropdownData, setTeamDropdownData] = useState([]);
    const [reportsToPagination, setReportsToPagination] = useState({ page: 1, limit: 15 })
    const [userTypeDropData, setUserTypeDropdownData] = useState([]);
    const [resetFieldWarning, setResetFieldWarning] = useState(false);
    const [existingEmployeeIds, setExistingEmployeedIds] = useState([]);
    const [existingUsersEmails, setExistingUsersEmails] = useState([""]);
    const [departmentDropData, setDepartmentDropdownData] = useState([]);
    const [designationDropData, setDesignationDropdownData] = useState([]);
    const [reportsToDropdownData, setReportsToDropdownData] = useState({});
    const [businessUnitDropData, setBusinessUnitDropdownData] = useState([]);
    const [editWarningState, setEditWarningState] = useState({ isValueSelected: false, value: '' })
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false })


    const handleGetValues = (props) => {
        const { name, selectedOption, updatedValue, uniqueKey, type,files } = props;
      
        if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number" || type === "email") {
            // if (uniqueKey === "email") {
            //     if (updatedValue?.length) {
            //         debouncedCheckUniquenessOfEmloyeeId({fieldName:uniqueKey,fieldValue:updatedValue});
            //     }
            // } else {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setChangedData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
            })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
            })
            // }
        } else if (type === "dynamicDropdown") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
            setChangedData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? { name: selectedOption[0]?.name, id: selectedOption[0].id } : null }
            })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? { name: selectedOption[0]?.name, id: selectedOption[0].id } : null }
            })
        } else if (type === "select") {
            if (fieldsNeedsToBeRestrictFromEdit.includes(uniqueKey)) {
                const oldValue = changedData[uniqueKey] ? changedData[uniqueKey] : formData[uniqueKey];
                if ((oldValue?.id !== updatedValue?.value || !oldValue) && handleShouldWarningModalOpen({ uniqueKey, formData })) {
                    setResetFieldWarning(true)
                    setEditWarningState((prev) => ({ isValueSelected: true, value: props }))
                } else {
                    const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                    setChangedData((prev) => {
                        return { ...prev, [uniqueKey]: valueSetter ? { name: updatedValue?.label, id: updatedValue.value } : null }
                    })
                    setFormData((prev) => ({ ...prev, [uniqueKey]: { name: updatedValue?.label, id: updatedValue.value } }))
                }
            } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setChangedData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ? { name: updatedValue?.label, id: updatedValue.value } : null }
                })
                setFormData((prev) => ({ ...prev, [uniqueKey]: { name: updatedValue?.label, id: updatedValue.value } }))
            }
        } else if(type === "file") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: files[0] })
                setChangedData((prev) => {
                    return { ...prev, [uniqueKey]: files[0] }
                })
        } else if (type === "isEditable") {
            setChangedData((prev) => {
                return { ...prev, [uniqueKey]: null }
            })
        }
    };

    const handleMoreData = (props) => {
        if (reportsToDropdownData?.currentPage < reportsToDropdownData?.totalPageCount) {
            setReportsToPagination((prev) => {
                getUsersDropdownData({ userRole: "", setterMethod: setReportsToDropdownData, dispatch, filterPayload: { page: prev + 1, limit: 15 } });
                return prev + 1;
            })
        }
    }

    const uniqueFieldHandler = ({ fieldName, fieldValue }) => {
        handleCheckUniqueFieldsMethod({ module: "users", fieldName, fieldValue }).then((res) => {
            if (res === "unique") {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
                setFormData((prev) => {
                    return { ...prev, [fieldName]: valueSetter ? fieldValue : null }
                })
                // setIsUniqueField((prev) => ({ ...prev, [fieldName]: false }))
            } else if (res === "not_unique") {
                primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
                primaryObject?.[fieldName]?.errorActivatorMethod(true);
                primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${modifyString(fieldName, "spacecase")}.`)
            }
        })
    }

    const debouncedCheckUniquenessOfEmloyeeId = debounce(uniqueFieldHandler, 500);

    const handleChangeRestrictedValues = ({ action, field }) => {
        if (action === "save") {
            const { name, selectedOption, updatedValue, uniqueKey, type } = editWarningState?.value;
            if (type === "select") {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setChangedData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ? { name: updatedValue?.label, id: updatedValue.value } : null }
                })
                setFormData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ? { name: updatedValue?.label, id: updatedValue.value } : null }
                })
            }
        }
        setEditWarningState({ isValueSelected: false, value: "" })
        setResetFieldWarning(false)
    }


    const handleUploadedFile = (props) => {
        const { name, type, files, uniqueKey } = props;
      
        if (name === "a") {

        } else {
            setFormData((prev) => ({ ...prev, [uniqueKey]: files?.length ? files[0] : null }))
        }
    }


    const handleUpdateUser = () => {
        if (!globalHandleIsAllRequiredFieldAvailable({ data:formData, primaryObject })) {
            return;
        }
        else {
            editUserMethod({ payload: changedData, dispatch, userId: formData?.id, Navigate, setIsLoading })
        }

    }

    const getUserCountryCode = (countryCode) => {
        let temp = countriesCode?.filter((country) => country?.code === countryCode);
        if (temp?.length) {
            let { shortCode, code, name } = temp[0];
            return `(${shortCode}) ${code}`
        }
    }

    const handleFilterUsers = (props) => {
        const { uniqueKey, input } = props;
        getUsersDropdownData({ userRole: "", setterMethod: setReportsToDropdownData, dispatch, filterPayload: { name: input } })
    }


    useEffect(() => {
        // getTeamDropdownData({userRole:"",setterMethod:setTeamDropdownData,dispatch})
        getUsersDropdownData({ userRole: "", setterMethod: setReportsToDropdownData, dispatch, filterPayload: reportsToPagination })
        getBusinessUnitDropdownData({ userRole: "", setterMethod: setBusinessUnitDropdownData, dispatch });
        // getAllExistingUsersParticularDetail({particularField:"email",dispatch,setterMethod:setExistingUsersEmails});
        // getAllExistingUsersParticularDetail({particularField:"employeeId",dispatch,setterMethod:setExistingEmployeedIds})
        // getDepartmentDropdownData({userRole:"",setterMethod:setDepartmentDropdownData,dispatch,selectedBusinessUnit:""})
        // getUserTypeDropdownData({userRole:"",setterMethod:setUserTypeDropdownData,dispatch,selectedBusinessUnit:"",selectedDepartment:""})
        // getDesignationDropdownData({userRole:"",setterMethod:setDesignationDropdownData,dispatch,selectedBusinessUnit:"",selectedDepartment:"",selectedUserType:""});
        getSingleUserDetails({ dispatch, userId: Location?.state?.id, setterMethod: setFormData, setIsLoading: setFetchUserLoading });
    }, []);

    useEffect(() => {
        if (formData?.businessUnit) {
            getDepartmentDropdownData({ userRole: "", setterMethod: setDepartmentDropdownData, dispatch, selectedBusinessUnit: formData?.businessUnit?.id });
            handleGetShiftDropdownData({setterMethod:setShiftDropdownData})
            // let tempData = {...formData}
            // setResetFields((prev) => ({department:tempData?.department ? true  :  false,userType:tempData?.userType ? true : false,designation:tempData?.designation ? true : false,team:tempData?.team ? true : false}));
            // delete formData.department
            // delete formData.userType
            // delete formData.designation
            // delete formData.team
            // setFormData(formData)
        }
    }, [formData?.businessUnit?.id])

    useEffect(() => {
        if (formData?.department) {
            getUserTypeDropdownData({ userRole: "", setterMethod: setUserTypeDropdownData, dispatch, selectedBusinessUnit: formData?.businessUnit?.id, selectedDepartment: formData?.department?.id })
            getTeamDropdownData({ userRole: "", setterMethod: setTeamDropdownData, dispatch, selectedBusinessUnit: formData?.businessUnit?.id, selectedDepartment: formData?.department?.id })
            // let tempData = {...formData}
            // setResetFields((prev) => ({userType:tempData?.userType?.id ? true : false,designation:tempData?.designation ? true : false,team:tempData?.team ? true : false}));
            // delete formData.userType
            // delete formData.designation
            // delete formData.team
            // setFormData(formData)
        }
    }, [formData?.department])

    useEffect(() => {
        if (formData?.userType) {
            getDesignationDropdownData({ userRole: "", setterMethod: setDesignationDropdownData, dispatch, selectedBusinessUnit: formData?.businessUnit?.id, selectedDepartment: formData?.department?.id, selectedUserType: formData?.userType?.id })
            // let tempData = {...formData}
            // setResetFields((prev) => ({designation:tempData?.designation ? true : false}));
            // delete formData.designation
            // setFormData(formData)
        }
    }, [formData?.userType]);

    // useEffect(() => {
    //     if(changedData?.businessUnit){
    //         getDepartmentDropdownData({userRole:"",setterMethod:setDepartmentDropdownData,dispatch,selectedBusinessUnit:changedData?.businessUnit?.id});
    //         setResetFields((prev) => ({department:true,userType:true,designation:true}));
    //         delete formData.department
    //         delete formData.userType
    //         delete formData.designation
    //         setFormData(formData)
    //     }
    // },[changedData?.businessUnit])

    useEffect(() => {
        if (changedData?.department) {
            getUserTypeDropdownData({ userRole: "", setterMethod: setUserTypeDropdownData, dispatch, selectedBusinessUnit: changedData?.businessUnit?.id, selectedDepartment: changedData?.department?.id })
            getTeamDropdownData({ userRole: "", setterMethod: setTeamDropdownData, dispatch, selectedBusinessUnit: changedData?.businessUnit?.id, selectedDepartment: changedData?.department?.id })
            const tempData = { ...formData }
            setResetFields((prev) => ({ userType: tempData?.userType?.id ? true : false, designation: tempData?.designation ? true : false, team: tempData?.team ? true : false }));
            delete formData.userType
            delete formData.designation
            delete formData.team
            setFormData(formData)
        }
        // setResetFields((prev) => ({...prev,userType:true,designation:true}))
    }, [changedData?.department])

    useEffect(() => {
        if (changedData?.userType) {
            getDesignationDropdownData({ userRole: "", setterMethod: setDesignationDropdownData, dispatch, selectedBusinessUnit: changedData?.businessUnit?.id, selectedDepartment: changedData?.department?.id, selectedUserType: changedData?.userType?.id })
            let tempData = { ...formData }
            setResetFields((prev) => ({ designation: tempData?.designation ? true : false }));
            delete formData.designation
            setFormData(formData)
        }
    }, [changedData?.userType]);

    // useEffect(() => {
    //     Object.keys(primaryObject)?.length && globalHandleIsAllRequiredFieldAvailable({ data: formData, primaryObject })
    // }, [Object.keys(formData)?.length]);

    if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })) {
        return (
            <>
                {
                    (fetchUserLoading) ? <div className='center_wrapper'><ClonosSpinner /></div> : <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                        <div
                            aria-label='User creation and edit container'
                            className={Styles.main_container}
                        >
                            <section
                                className={Styles.form_field_container}
                            >
                                <div>
                                    <ClonosInput
                                        type="text"
                                        tabIndex={1}
                                        isLabel={true}
                                        isMandatory={true}
                                        label="First Name"
                                        uniqueKey="firstName"
                                        areaLabel="First name"
                                        placeholder="First Name"
                                        handleGetValues={handleGetValues}
                                        defaultValue={formData?.firstName}
                                        errorMessage={"Please provide first name."}
                                        isSpecialCharacterAllow={true}
                                        onlyAllowTheseSpecialCharacters={["-", "_"]}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                    <ClonosInput
                                        type="text"
                                        tabIndex={2}
                                        isLabel={true}
                                        isMandatory={true}
                                        label="Last Name"
                                        uniqueKey="lastName"
                                        areaLabel="Last name"
                                        placeholder="Last Name"
                                        handleGetValues={handleGetValues}
                                        errorMessage={"Please provide last name."}
                                        isSpecialCharacterAllow={true}
                                        onlyAllowTheseSpecialCharacters={["-", "_"]}
                                        defaultValue={formData?.lastName}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                    <ClonosInput
                                        type="text"
                                        tabIndex={3}
                                        isLabel={true}
                                        isMandatory={true}
                                        label="Employee ID"
                                        uniqueKey="employeeId"
                                        areaLabel="Employee ID"
                                        placeholder="Employee ID"
                                        disabled={true}
                                        handleGetValues={handleGetValues}
                                        isSpecialCharacterAllow={true}
                                        onlyAllowTheseSpecialCharacters={["-", "_"]}
                                        errorMessage={"Please provide employee id."}
                                        defaultValue={formData?.employeeId}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                    <ClonosSelect
                                        type="select"
                                        tabIndex={4}
                                        isLabel={true}
                                        isMandatory={true}
                                        placeholder="Select"
                                        label="Business Unit"
                                        uniqueKey="businessUnit"
                                        areaLabel="Business unit"
                                        disabled={true}
                                        handleGetValues={handleGetValues}
                                        errorMessage={"Please provide business unit."}
                                        defaultValue={formData?.businessUnit?.name}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        options={businessUnitDropData?.map((unit) => ({ label: unit?.name, value: unit?.id, isNeeded: true })) || []}
                                    />
                                    <ClonosSelect
                                        type="select"
                                        tabIndex={5}
                                        isLabel={true}
                                        isMandatory={true}
                                        label="Department"
                                        placeholder="Select"
                                        uniqueKey="department"
                                        areaLabel="Department"
                                        disabled={!formData?.businessUnit?.id}
                                        reset={resetFields?.department}
                                        handleGetValues={handleGetValues}
                                        errorMessage={"Please provide department."}
                                        defaultValue={formData?.department?.name}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        options={departmentDropData?.map((department) => ({ label: department?.name, value: department?.id, isNeeded: true })) || []}
                                    />
                                    <ClonosSelect
                                        type="select"
                                        tabIndex={6}
                                        isLabel={true}
                                        isMandatory={true}
                                        label="User Type"
                                        uniqueKey="userType"
                                        placeholder="Select"
                                        areaLabel="User type"
                                        reset={resetFields?.userType}
                                        handleGetValues={handleGetValues}
                                        disabled={!formData?.department?.id}
                                        errorMessage={"Please provide user type."}
                                        defaultValue={formData?.userType?.name}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        options={userTypeDropData?.map((type) => ({ label: type?.name, value: type?.id, isNeeded: true })) || []}
                                    />
                                    <ClonosSelect
                                        type="select"
                                        tabIndex={7}
                                        isLabel={true}
                                        placeholder="Select"
                                        label="Designation"
                                        isMandatory={true}
                                        uniqueKey="designation"
                                        areaLabel="Designation"
                                        reset={resetFields?.designation}
                                        handleGetValues={handleGetValues}
                                        disabled={!formData?.userType?.id}
                                        errorMessage={"Please provide designation."}
                                        defaultValue={formData?.designation?.name}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        options={designationDropData?.map((designation) => ({ label: designation?.name, value: designation?.id, isNeeded: true })) || []}
                                    />
                                    <ClonosSelect
                                        type="select"
                                        tabIndex={8}
                                        label="Team"
                                        isLabel={true}
                                        uniqueKey="team"
                                        areaLabel="Team"
                                        placeholder="Select"
                                        reset={resetFields?.team}
                                        handleGetValues={handleGetValues}
                                        disabled={!formData?.department?.id}
                                        defaultValue={formData?.team?.name}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        options={teamDropdownData.data?.map((team) => ({ label: team?.name, value: team?.id, isNeeded: true })) || []}
                                    />
                                    <DynamicDropdown
                                        isUser={true}
                                        tabIndex={9}
                                        isLabel={true}
                                        isCheckbox={false}
                                        label="Report To"
                                        title="Report To"
                                        isActivator={true}
                                        isMandatory={true}
                                        isSearchable={true}
                                        placeholder="Select"
                                        uniqueKey="reportsTo"
                                        areaLabel="Report to"
                                        handleMoreData={handleMoreData}
                                        handleGetValues={handleGetValues}
                                        heading={"Select from User Library"}
                                        handleDynamicSearch={handleFilterUsers}
                                        errorMessage={"Please provide reports To."}
                                        defaultValue={formData?.reportsTo ? [formData?.reportsTo] : []}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        data={reportsToDropdownData?.data?.map((user) => ({ name: user?.name, id: user?.id, isNeeded: true })) || []}
                                    />
                                    <ClonosSelect
                                        type="select"
                                        tabIndex={6}
                                        isLabel={true}
                                        isMandatory={true}
                                        label="Shift"
                                        uniqueKey="shift"
                                        placeholder="Select"
                                        areaLabel="Shift"
                                        disabled={!formData?.businessUnit?.id}
                                        defaultValue={formData?.shift?.name}
                                        handleGetValues={handleGetValues}
                                        errorMessage={"Please provide shift."}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                        options={shiftDropdownData?.map((shift) => ({ label: shift?.name, value: shift?.id, isNeeded: true })) || []}
                                    />
                                    <ClonosInput
                                        type="email"
                                        tabIndex={10}
                                        isLabel={true}
                                        isMandatory={true}
                                        uniqueKey="email"
                                        label="Email Address"
                                        areaLabel="Email address"
                                        placeholder="abc@gmail.com"
                                        handleGetValues={handleGetValues}
                                        errorMessage={"Please provide email."}
                                        defaultValue={formData?.email}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                    <div className={Styles.contact_num_wrapper}>
                                        <label>Contact Number <sup style={{ color: "red", fontSize: "0.8rem" }}>*</sup></label>
                                        <div className={Styles.contact_num_flex}>
                                            <div className={Styles.region_code_wrapper}>
                                                <ClonosSelect
                                                    type="select"
                                                    tabIndex={11}
                                                    isLabel={false}
                                                    isMandatory={true}
                                                    position="top"
                                                    uniqueKey="countryCode"
                                                    areaLabel="Country Code"
                                                    placeholder="Country Code"
                                                    handleGetValues={handleGetValues}
                                                    errorMessage={"Please provide country code."}
                                                    defaultValue={getUserCountryCode(formData?.countryCode)}
                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                    options={countriesCode?.map((country) => ({ label: `(${country?.shortCode}) ${country?.code}`, value: country?.code, isNeeded: true }))}
                                                />
                                            </div>
                                            <div className={Styles.num_wrapper}>
                                                <ClonosInput
                                                    limit={10}
                                                    type="number"
                                                    tabIndex={12}
                                                    isLabel={false}
                                                    isMandatory={true}
                                                    uniqueKey="contactNumber"
                                                    areaLabel="Contact number"
                                                    placeholder="Enter Mobile Number"
                                                    handleGetValues={handleGetValues}
                                                    errorMessage="Please provide valid contact number."
                                                    defaultValue={formData?.contactNumber}
                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                />
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div>
                                    <FileUploader
                                        label="Upload Image"
                                        uniqueKey="image"
                                        acceptableFileTypes={[".png", ".jpg", ".jpeg"]}
                                        limit={1}
                                        tabIndex={13}
                                        fileSizeInMB={10}
                                        handleGetSelectedData={handleGetValues}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                    <FileUploader
                                        label="E-Signature"
                                        tabIndex={14}
                                        uniqueKey="eSignature"
                                        acceptableFileTypes={[".png", ".jpg", ".jpeg"]}
                                        limit={1}
                                        fileSizeInMB={10}
                                        handleGetSelectedData={handleGetValues}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                </div>
                            </section>
                            <footer className={Styles.footer}>
                                <ClonosButton tabIndex={15} onClick={()=>Navigate(-1)}>Cancel</ClonosButton>
                                <ClonosButton tabIndex={16} variant="filled" loading={isLoading} onClick={handleUpdateUser}>Update</ClonosButton>
                            </footer>
                        </div>
                    </Card>
                }
                <EditUserWarningModal isOpen={resetFieldWarning} closeMethod={setResetFieldWarning} field={editWarningState?.value?.uniqueKey} handleChangeRestrictedValues={handleChangeRestrictedValues} formData={formData} />
            </>
        )
    };
    <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default UserEdit
