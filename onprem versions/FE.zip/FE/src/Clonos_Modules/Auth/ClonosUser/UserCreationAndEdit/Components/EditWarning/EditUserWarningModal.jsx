import { useEffect, useState } from "react"
import CloseIcon from "../../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { ClonosButton } from "../../../../../../components/CommonComponents/Button/Button"
import Modal from "../../../../../../components/CommonComponents/Modal/Modal"
import Styles from "./EditUserWarningModal.module.css"
export const EditUserWarningModal = ({isOpen,closeMethod,field,handleChangeRestrictedValues,formData}) => {
    const [message,setMessage] = useState("");

    const handleSaveChanges = (action) => {
        handleChangeRestrictedValues({action,field})
    }

    useEffect(() => {
        if(field === "businessUnit"){
            setMessage(`If you change BusinessUnit, you have to reassign ${formData?.department ? "Department" : ""} ${formData?.userType ? ", User Type" : ""} ${formData?.designation ? ", Designation," : ""} ${formData?.team ? ", Team" : ""}.`)
        } else if(field === "department"){
            setMessage(`If you change Department, you have to reassign ${formData?.userType ? ", User Type" : ""} ${formData?.designation ? ", Designation" : ""} ${formData?.team ? ", Team" : ""}.`)
        } else if(field === "userType"){
            setMessage(`If you change User Type, you have to reassign ${formData?.designation ? ", Designation" : ""}.`)
        }
    },[field])
 
    return <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
                <div className={Styles.e_w_container}>
                    <div className={Styles.e_w_header}>
                        <h4>Edit User Details</h4>
                        <CloseIcon onClick={() => {
                            closeMethod(false);
                            handleSaveChanges("close")
                        }}/>
                    </div>
                    <div className={Styles.e_w_section}>
                        <p>{message}</p>
                    </div>
                    <div className={Styles.e_w_footer}>
                        <ClonosButton style={{padding:"0.5rem 3rem"}} onClick={() => handleSaveChanges("save")}>OK</ClonosButton>
                    </div>
                </div>
    </Modal>
}