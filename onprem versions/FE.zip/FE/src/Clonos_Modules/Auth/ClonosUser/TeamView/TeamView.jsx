import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant"
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { deleteTeamsMethod, getAllTeamsListMethod } from "../../../../utils/UsersMethods/teamsMethods"
import DeleteIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/DeleteIcon"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import EditIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/EditIcon"
import { getFormatedDate, handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/TeamView/TeamView.module.css";
import CommonNavigator from "../../../../components/CommonComponents/Navigator/Navigator"
import Subbar from "../../../../components/CommonComponents/ClonosSubbar/Subbar"
import { teamsActions } from "../../../../Store/Reducers/ClonosTeamsReducer"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import { TeamEdit } from "../TeamCreateAndEdit/TeamEdit"
import { useEffect, useState } from "react"
import { useDispatch } from "react-redux"

export const TeamView = ({isOpen,closeMethod,data,handleGetErrorActivatorInformation,handlePrimaryObjectModifier,primaryObject,handleEditTeam}) => {
    const dispatch = useDispatch();
    const [teamDetails,setTeamDetails] = useState({});
    const [showConfirmationDialog,setShowConfirmationDialog] = useState(false);
    const [showEditTeamModal,setShowEditTeamModal] = useState(false);


    const handleDeleteTeams = async () => {
        const isDeleted = await deleteTeamsMethod({dispatch,payload:{teams:[teamDetails?.id]}});
        if(isDeleted){
            handleShowErrorAndWarning({dispatch,type:"success",message:"Team Deleted successfully.",showTime:"5000"});
            setShowConfirmationDialog(false);
            closeMethod(false);
            const fetchedTeams = await getAllTeamsListMethod({ dispatch });
            if (fetchedTeams?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            dispatch(teamsActions.getAllTeams(fetchedTeams?.result));
            } else {
            handleShowErrorAndWarning({ dispatch, type: "error", message: "Failed to fetch teams!", showTime: "5000",});
            }

        } else {
            handleShowErrorAndWarning({dispatch,type:"error",message:"Failed! Something went wrong.",showTime:"5000"})
        }
    }

    const handleEditTeamModal = () => {
        setShowEditTeamModal(true);
    }

    

    


    useEffect(() => {
        setTeamDetails(data)
    },[data])

    return (
    <>
        <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
            <div className={Styles.v_t_container}>
                <div className={Styles.v_t_sub_container}>
                    <div className={Styles.v_t_header}>
                        <h4>{teamDetails?.name}</h4>
                        <div className={Styles.v_t_header_icons}>
                            <EditIcon onClick={handleEditTeamModal} tooltipTitle={"Edit"} />
                            <DeleteIcon onClick={() => setShowConfirmationDialog(true)} tooltipTitle={"Delete"} />
                            <CloseIcon onClick={() => closeMethod(false)}/>
                        </div>
                    </div>
                    <div className={Styles.v_t_details}>
                        <div className={Styles.v_t_field_wrapper}>
                            <p className={Styles.v_t_field_name_wrapper}>Team Name</p>
                            <p className={Styles.v_t_field_value_wrapper}>{teamDetails?.name || "-"}</p>
                        </div>
                        <div className={Styles.v_t_field_wrapper}>
                            <p className={Styles.v_t_field_name_wrapper}>Department</p>
                            <p className={Styles.v_t_field_value_wrapper}>{teamDetails?.department?.name || "-"}</p>
                        </div>
                        <div className={Styles.v_t_field_wrapper}>
                            <p className={Styles.v_t_field_name_wrapper}>Created On</p>
                            <p className={Styles.v_t_field_value_wrapper}>{getFormatedDate(teamDetails?.createdAt) || "-"}</p>
                        </div>
                        <div className={Styles.v_t_field_wrapper}>
                            <p className={Styles.v_t_field_name_wrapper}>Team Members</p>
                            <p className={`${Styles.v_t_field_value_wrapper} ${Styles.v_t_members_wrapper}`}>
                                {
                                teamDetails?.users?.length ? teamDetails?.users?.map((member,index) => {
                                        return <span>{`${member?.name} ${index < teamDetails?.teamMembers?.length ? "," : "" }`}</span>
                                    }) : <span>No Users</span>
                                }
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </Modal>
        <TeamEdit isOpen={showEditTeamModal} closeMethod={setShowEditTeamModal} teamId={teamDetails?.id} primaryObject={primaryObject}  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} closePreviousModal={closeMethod} handlePrimaryObjectModifier={handlePrimaryObjectModifier} handleEditTeam={handleEditTeam}/>
        <ClonosConfirmationBox
            isOpen={showConfirmationDialog}
            headerTitle={"Delete Team"}
            message={"Are you sure you want to Delete?"}
            closeModalMethod={setShowConfirmationDialog}
            confirmingMethod={handleDeleteTeams}
        />
    </>)
}