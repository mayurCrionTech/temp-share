import { Card } from "@material-ui/core"
import Styles from "../../../../ModuleStyles/Auth/Permissions/UserPermissionAssignment.module.css"
import CommonNavigator from "../../../../components/CommonComponents/Navigator/Navigator"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import { PermissionsTable } from "../components/PermissionsTable"
import { useEffect, useState } from "react"
import { CLONOS_MODULE_PERMISSIONS } from "../../../../utils/AuthMethods/Constant"
import { getPermissionsOfDesignation, getSingleUserWithPermissions, handleAssetPermissions, handleAssetPermissionsColumns, handleAssignMultiplePermissionsToUsers, handleAssignPermissionToSingleUser, handleModuleBasePermissions, managePermissionsModulesLocally } from "../../../../utils/PermissionsMethods/PermissionsMethod"
import { useDispatch } from "react-redux"
import useToggler from "../../../../CustomHooks/TogglerHook"
import { useSelector } from "react-redux"
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant"
import { permissionsActions } from "../../../../Store/Reducers/ClonosPermissionsReducer"
import { handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import {useNavigate} from "react-router-dom"
import { WarningPopup } from "../WarningPopup/WarningPopup"

export const UserPermissionAssignment = ({userDetails}) => {
    const dispatch = useDispatch();
    const Navigate = useNavigate()
    const [submitLoader,setSubmitLoader] = useToggler();
    const [modulesLoader,setModulesLoader] = useToggler();
    const [useEffectUpdate,setUseEffectUpdate] = useToggler();
    const [permissionsLoader,setPermissionsLoader] = useToggler();
    const [defaultPermissions,setDefaultPermissions] = useState([])
    const [activeModuleTab,setActiveModuleTab] = useState("Assets");
    const [permissionsColumns,setPermissionsColumns] = useState([]);
    const [modulesNavigatorValues,setModulesNavigatorValues] = useState([])
    const [showConfirmationDialog,setShowConfirmationDialog] = useState(false);
    const {usersWithPermissions,changedPermissions} = useSelector(store => store.permissionsData);


    const handleChangeTab = (val) => {
        setActiveModuleTab(val)
    }

    const handleUpdatePermissions = async () => {
        const requestPayload = changedPermissions[userDetails?.userPermission]
        const isAssigned = await handleAssignPermissionToSingleUser({payload:requestPayload,dispatch,setSubmitLoader,userPermissionId:userDetails?.userPermission});
        if(isAssigned === true){
            handleShowErrorAndWarning({dispatch,message:"Permissions updated successfully.",showTime:"5000",type:"success"})
            // const res = await getSingleUserWithPermissions({dispatch,setIsLoading:setPermissionsLoader,id:userDetails?.id});
            // console.log(res,"res from khwab")
            // if(res?.data){
            //     alert("hey jack")
            //     const res_data = res?.data;
            //     dispatch(permissionsActions.getAllUsersWithPermissions([res_data]));
            // }
            dispatch(permissionsActions.getChangedPermissions([]));
            Navigate('/users')
        }
    }

    const handleRestoreDefault= () => {
        dispatch(permissionsActions.getAllUsersWithPermissions(defaultPermissions))
        dispatch(permissionsActions.getChangedPermissions({}));
        setUseEffectUpdate()
    }

    useEffect(() => {
        handleModuleBasePermissions({activeTab:activeModuleTab,setPermissionsColumns,permissionsType:'Users',modulesNavigatorValues,dispatch,setIsLoading:setPermissionsLoader,data:usersWithPermissions,changedPermissions,setUseEffectUpdate})
    },[activeModuleTab,modulesNavigatorValues?.length,useEffectUpdate]);

    useEffect(() => {
        (async () => {
            if(!modulesNavigatorValues?.length){
                const activeModules = await managePermissionsModulesLocally({dispatch,setActiveModuleTab,setIsLoading:setModulesLoader});
                setModulesNavigatorValues(activeModules)
            }
            const fetchedUser = await getSingleUserWithPermissions({dispatch,setIsLoading:setPermissionsLoader,id:userDetails?.id});
            if(fetchedUser){
                dispatch(permissionsActions.getAllUsersWithPermissions([{...fetchedUser}]));
                setDefaultPermissions([{...fetchedUser}])
                setUseEffectUpdate()
            }
        })()

        return () => {
            dispatch(permissionsActions.getAllUsersWithPermissions([]));
        }
    
    },[userDetails])

    return (
        <>
        <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem",height:"100%" }}>
            <div className={Styles.u_p_a_container}>
                <div className={Styles.u_p_a_header}>
                    <h4>User Roles Matrix</h4>
                    <p>Set Permission to users</p>
                </div>
                {
                    !userDetails?.id && !modulesNavigatorValues?.length && !modulesLoader ?
                    <div className={Styles.no_data_wrapper}>
                        <h4>Oops! No details found.</h4>    
                    </div>
                    :
                    <div>
                        <CommonNavigator isLoading={modulesLoader} values={modulesNavigatorValues} getSelectedValue={handleChangeTab} web={true} />
                        <div className={Styles.btn_wrapper}>
                            <ClonosButton onClick={handleRestoreDefault}>Restore Default</ClonosButton>
                        </div>
                        <div>
                            <PermissionsTable isLoading={(modulesLoader || permissionsLoader) && (!Object.keys(usersWithPermissions)?.length || !modulesNavigatorValues?.length)} columns={permissionsColumns} rows={usersWithPermissions} isMultiSelect={false} hideFooter={true}/>
                        </div>
                    </div>
                }
                <div className={Styles.u_p_a_btn_wrapper}>
                    <ClonosButton isDisabled={!userDetails?.id && !modulesNavigatorValues?.length && !modulesLoader} onClick={() => setShowConfirmationDialog(true)}>Cancel</ClonosButton>
                    <ClonosButton onClick={!userDetails?.id && !modulesNavigatorValues?.length && !modulesLoader ?() => Navigate("/users") :handleUpdatePermissions}>{!userDetails?.id && !modulesNavigatorValues?.length && !modulesLoader ? "Go To Users List" :"Save"}</ClonosButton>
                </div>
            </div>
        </Card>
        <WarningPopup
            title={"Cancel Edit"}
            message={"Do you confirm that you want to Cancel?"}
            proceedMethod={() => Navigate(-1)}
            isOpen={showConfirmationDialog}
            closeMethod={setShowConfirmationDialog}
        />
        </>
    )
}
