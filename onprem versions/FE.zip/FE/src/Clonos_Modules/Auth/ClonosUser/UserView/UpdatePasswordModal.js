import { useState } from "react"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/UserView/updatePasswordModal.module.css"
import { globalHandleIsAllRequiredFieldAvailable, handleEncryptionURLKeys, handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
import { handleGetValues } from "../../../../utils/ChecklistAndReportsMethods/CommonMethods"
import { doPutApiCall } from "../../../../utils/ClonosApi"
import AppUrl from "../../../../utils/AppUrl"
import { useDispatch } from "react-redux"



let primaryObject = {};

/*
date            qid / cr#         comments
15-apr-2026     CR0020            Improve weak policy enforcement by applying regex-based validation and returning appropriate error responses when validation fails.

*/
export const UpdatePasswordModal = ({isOpen,closeMethod,userData}) => {
    const [formData,setFormData] = useState({});
    const [lcValues,setLcValues]=useState({})
    const [showConfirmationBox,setShowConfirmationBox] = useState(false)
    const dispatch = useDispatch()
     const {
        handleGetErrorActivatorInformation,
        handlePrimaryObjectModifier,
      } = useFieldsChecker();

  const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@$!%?&])[A-Za-z0-9@$!%?&]{1,15}$/;
      
    const handleUpdatePassword = () => {
        closeMethod(false);
       
        doPutApiCall({url:AppUrl?.resetPassword,
                     payload:{
                     email:userData?.email,
                     password:handleEncryptionURLKeys({ needToEncrypt: formData?.newPassword1 }),
                     source: process.env.REACT_APP_CLONOS_LOGIN_SOURCE_KEY
                     }})
        .then((res)=>{
            setShowConfirmationBox(false)
        })
       
    }

 const handleSaveDetails = () => {
    if (!globalHandleIsAllRequiredFieldAvailable({ data: formData, primaryObject })) {
        return;
    } 
    
    // ✅ Password regex validation
    if (!passwordRegex.test(formData?.newPassword1)) {
          handleShowErrorAndWarning({ dispatch, type: "error",  message: "Password must contain 1 uppercase, 1 lowercase, 1 number, 1 special character and be max 15 characters", showTime: 5000 })
        return;
    }

    // ✅ Match check
    if (formData.newPassword1 === formData.newPassword2) {
        setShowConfirmationBox(true);
    } else {
        handleShowErrorAndWarning({
            dispatch,
            type: "error",
            message: "Passwords do not match",
            showTime: 5000
        });
    }
};


    // const handleSaveDetails = () => {
    //     if (!globalHandleIsAllRequiredFieldAvailable({ data:formData, primaryObject })) {
          
    //         return;
    //     } else {
    //         if(formData.newPassword1===formData.newPassword2){
    //             setShowConfirmationBox(true)
    //         }
    //         else{
    //             console.error("Password  does not match")
    //         }
    //     }
    // }

    return (
        <>
            <Modal isOpen={isOpen} closeModalMethod={closeMethod}stopOverlayCloser={true}>
            <div className={Styles.u_p_container}>
                    <div className={Styles.u_p_header_wrapper}>
                        <h4>User Name</h4>
                        <CloseIcon onClick={() => closeMethod(false)}/>
                    </div>
                    <div className={Styles.u_p_passwords_wrapper}>
                        <div>
                            <ClonosInput
                                type="password"
                                label="New Password"
                                isMandatory={true}
                                isLabel={true}
                                uniqueKey="newPassword1"
                                areaLabel="new_password1"
                                placeholder="Password"
                                handleGetValues={(props)=>handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                                errorMessage="Please provide password"
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            />
                            <ClonosInput
                                type="password"
                                label="Confirm New Password"
                                isMandatory={true}
                                isLabel={true}
                                uniqueKey="newPassword2"
                                areaLabel="new_password2"
                                placeholder="Password"
                                handleGetValues={(props)=>handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                                errorMessage="Please provide password"
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            />
                        </div>
                    </div>
                    <div className={Styles.u_p_confirm_wrapper}>
                        <div>
                            <span style={{cursor:"pointer"}} onClick={() => closeMethod(false)}>Cancel</span>
                            <span style={{cursor:"pointer"}} onClick={handleSaveDetails}>Ok</span>
                        </div>
                    </div>
            </div>
        </Modal>
        <ClonosConfirmationBox 
            isOpen={showConfirmationBox}
            closeModalMethod={setShowConfirmationBox}
            confirmingMethod={handleUpdatePassword}
            message="Are you sure you want to update ? "
            headerTitle="Update Password"
        />
        </>
    )
}