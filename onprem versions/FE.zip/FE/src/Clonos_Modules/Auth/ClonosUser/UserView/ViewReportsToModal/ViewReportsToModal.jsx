import { useEffect, useState } from "react"
import Modal from "../../../../../components/CommonComponents/Modal/Modal"
import useToggler from "../../../../../CustomHooks/TogglerHook";
import { useDispatch } from "react-redux";
import { getSingleUserDetails } from "../../../../../utils/UsersMethods/usersMethods";
import CloseIcon from "../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import ClonosTooltip from "../../../../../components/CommonComponents/ClonosTooltip/ClonosTooltip";
import Styles from "./viewReportsToModal.module.css";
import ClonosSpinner from "../../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";


export const ViewReportsToModal = ({userId,isOpen,closeMethod}) => {
    const [userDetails,setUserDetails] = useState({});
    const [isLoading,setIsLoading] = useToggler();
    const dispatch = useDispatch();

    useEffect(() => {
        if(isOpen){
            getSingleUserDetails({ userId, dispatch, setterMethod: setUserDetails, setIsLoading })
        }
    },[isOpen])
    return <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
    <div className={Styles.v_u_rep_to_container}>
      {
        isLoading ? <div className="center_wrapper"><ClonosSpinner/></div> : <>
            <div className={Styles.v_u_rep_to_header}>
          <div className={Styles.header_title_wrapper}>
            <h4>{userDetails?.name}</h4>
            <h4>{userDetails?.employeeId}</h4>
          </div>
          <div className={Styles.close_wrapper}>
            <CloseIcon onClick={() => closeMethod()}/>
          </div>
      </div>
      <div className={Styles.v_u_rep_to_section}>
          <div>
            <div className={Styles.v_u_rep_to_section_field_wrapper}>
              <h4>Email</h4>
              <ClonosTooltip content={userDetails?.email}><p>{userDetails?.email}</p></ClonosTooltip>
            </div>
            <div className={Styles.v_u_rep_to_section_field_wrapper}>
              <h4>Contact Number</h4>
              <ClonosTooltip content={`${userDetails?.countryCode} ${userDetails?.contactNumber}`}><p>{`${userDetails?.countryCode} ${userDetails?.contactNumber}`}</p></ClonosTooltip>
            </div>
          </div>
      </div>
        </>
      }
    </div>
  </Modal>
}