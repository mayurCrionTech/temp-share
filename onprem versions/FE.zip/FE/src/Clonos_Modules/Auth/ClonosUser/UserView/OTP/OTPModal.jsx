import { createRef, useEffect, useRef, useState } from "react";
import CloseIcon from "../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import ClonosInput from "../../../../../components/CommonComponents/ClonosInput/ClonosInput";
import Modal from "../../../../../components/CommonComponents/Modal/Modal";
import Styles from "./OTPModal.module.css";
import { globalHandleIsAllRequiredFieldAvailable } from "../../../../../utils/clonosCommon";

export const OTPModal = ({
  isOpen,
  closeMethod,
  setShowUpdatePasswordModal,
  otpLength,
}) => {
  const [otp, setOTP] = useState(new Array(otpLength).fill(""));
  const [activeInput, setActiveInput] = useState(0);
  const handleConfirmOTP = () => {
    closeMethod(false);
    setShowUpdatePasswordModal(true);
  };

  const handleChangeOTP = (e, i) => {
    let { value, nextSibling } = e.target;
  
    setOTP([...otp?.map((inp, index) => (index === i ? value : inp))]);
    if(value?.length && i < otpLength){
        setActiveInput(i+1)
    }
    // if (value?.length) {
    //   if (nextSibling) {
    //     nextSibling.focus();
    //   }
    // }
  };

  const handlePaste = (e) => {
    const clipboardData = e.clipboardData || window.clipboardData;
    const pastedData = clipboardData.getData("Text").split("");
    // Filter out non-numeric characters
    const filteredData = pastedData.filter(
      (char) => !isNaN(char) && char !== " "
    );
    let newOTP = filteredData.slice(0, otpLength)
    setOTP(newOTP);
    setActiveInput(newOTP?.length-1)
  };

  useEffect(() => {
    const inputElement = document.getElementById(`otp_input_${activeInput}`);
    if (inputElement) {
      inputElement.focus();
    }
  }, [activeInput]);

  return (
    <Modal
      isOpen={isOpen}
      closeModalMethod={closeMethod}
      stopOverlayCloser={true}
    >
      <div className={Styles.otp_container}>
        <div className={Styles.opt_header}>
          <div className={Styles.heading_wrapper}>
            <h4>OTP</h4>
            <p>Please enter the OTP sent to your E-mail</p>
          </div>
          <CloseIcon onClick={() => closeMethod(false)} />
        </div>
        <div className={Styles.otp_boxes_wrapper} onPaste={handlePaste}>
          {otp?.map((el, index) => {
    
            return (
              <input
                id={`otp_input_${index}`}
                autoFocus={activeInput === index ? true : false}
                value={otp[index]}
                maxLength={1}
                type="text"
                className={Styles.otp_input}
                onChange={(e) => handleChangeOTP(e, index)}
                // onFocus={(e) => e.target.select()}
              />
            );
          })}
        </div>
        <div className={Styles.otp_confirm_wrapper}>
          <div>
            <span onClick={() => closeMethod(false)}>Cancel</span>
            <span onClick={() => handleConfirmOTP()}>Ok</span>
          </div>
        </div>
      </div>
    </Modal>
  );
};
