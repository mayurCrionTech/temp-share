import CloseIcon from "../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { WarningIcon } from "../../../../../assets/Clonos Common Indicators/Icon_Components/WarningIcon"
import { ClonosButton } from "../../../../../components/CommonComponents/Button/Button"
import Modal from "../../../../../components/CommonComponents/Modal/Modal"
import Styles from "./ResetPasswordModal.module.css"

export const ResetPasswordModal = ({isOpen,closeMethod,setShowOTPModal,setShowUpdatePasswordModal}) => {

    // const handleSendOTP = () =>  {
    //     closeMethod(false)
    //     setShowOTPModal(true);
    // }
 
    const handleUpdatePassword=()=>{
        closeMethod(false)
        setShowUpdatePasswordModal(true)
    }

    return (
        <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
            <div className={Styles.r_p_container}>
                <div className={Styles.r_p_header}>
                    <div>
                        <div className={Styles.warning_icon}><WarningIcon/></div>
                        <p>Reset Password</p>
                    </div>
                    <div className={Styles.r_p_header_close}><CloseIcon onClick={() => closeMethod(false)}/></div>
                </div>
                <div className={Styles.r_p_content}>
                    <p>Do you confirm that you need to reset your password ?</p>
                </div>
                <div className={Styles.r_p_btns_wrapper}>
                    <div>
                        <ClonosButton style={{color:"#E0606A",border:"1px solid #E0606A",padding:"1rem 2rem"}}>Cancel</ClonosButton>
                        <ClonosButton variant="filled" style={{padding:"1rem 3rem"}} onClick={() => handleUpdatePassword()}>Yes</ClonosButton>
                    </div>
                </div>
            </div>
        </Modal>
    )
}