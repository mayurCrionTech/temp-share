import { useEffect, useState } from "react";
import Subbar from "../../../../components/CommonComponents/ClonosSubbar/Subbar";
import { getFormatedDate, handleLoggedInUser, handleShowErrorAndWarning, checkUserHasPermission } from "../../../../utils/clonosCommon";
import { UnAuthorizedModal } from "../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/UserView/userview.module.css";
import { Card, Tooltip } from "@material-ui/core";
import { UpdatePasswordModal } from "./UpdatePasswordModal";
import { useLocation, useNavigate } from "react-router-dom";
import { OTPModal } from "./OTP/OTPModal";
import { ResetPasswordModal } from "./ResetPasswordModal/ResetPasswordModal";
import { WarningPopup } from "../WarningPopup/WarningPopup";
import { deleteUsersMethod, getSingleUserDetails, handleDisableUserMethod, handleEnableUserMethod } from "../../../../utils/UsersMethods/usersMethods";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { useDispatch } from "react-redux";
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_USERS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS } from "../../../../Constants/Constant";
import useModuleNameProvider from "../../../../CustomHooks/ModuleNameProviderHook";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import ClonosTooltip from "../../../../components/CommonComponents/ClonosTooltip/ClonosTooltip";
import { ViewReportsToModal } from "./ViewReportsToModal/ViewReportsToModal";
import { ClonosToggleButton } from "../../../../components/CommonComponents/ClonosToggleButton/ClonosToggleButton";
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";

 /*
    date            qid / cr#         comments
    07-Apr-2026     #160             Broken Access Control - Permission Restriction FrontEnd
    */

     /*
    date            qid / cr#         comments
    08-Mar-2026     CR0031            Restricted unwanted  Show BU Screen
    */

const ViewUserDetails = () => {
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_USERS);
  const dispatch = useDispatch()
  const Navigate = useNavigate();
  const Location = useLocation();
  const loggedInUser = handleLoggedInUser();
  const [isLoading, setIsLoading] = useToggler();
  const [userStatusChangeLoader, setUserStatusChangeLoader] = useToggler();
  // const [showOTPModal, setShowOTPModal] = useState(false);
  const [showReportToDetails, setShowReportToDetails] = useState(false);
  const [showDeleteUserModal, setShowDeleteUserModal] = useState(false);
  const [showResetPasswordModal, setShowResetPasswordModal] = useState(false);
  const [showUpdatePasswordModal, setShowUpdatePasswordModal] = useState(false);
  const [userDetails, setUserDetails] = useState({});
  //CR0031
  const [confirmPopup, setConfirmPopup] = useState({          
    open: false,
    type: "", // "enable" | "disable"
  });

  // #160 
   const [isUnauthorized, setIsUnauthorized] = useState(false);

  const handleDeleteUser = async () => {
    const data = await deleteUsersMethod({ dispatch, payload: { users: [userDetails?.id] } });
    if (data?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
      handleShowErrorAndWarning({ dispatch, type: "success", message: "User Deleted successfully.", showTime: "5000" });
      Navigate("/users")
    } else {
      handleShowErrorAndWarning({ dispatch, type: "error", message: "Failed! something went wrong.", showTime: "5000" });
    }
  }

  const handleUserStatus = async (val) => {
    if (userDetails?.isEnabled) {
      const isDisabled = await handleDisableUserMethod({ userId: userDetails?.id, setIsLoading: setUserStatusChangeLoader });
      if (isDisabled) {
        getSingleUserDetails({ userId: Location?.state?.userId, dispatch, setterMethod: setUserDetails, setIsLoading })
        handleShowErrorAndWarning({ dispatch, message: "User disabled successfully.", type: "success", showTime: "5000" })
      } else {
        handleShowErrorAndWarning({ dispatch, message: "Failed to disable user!", type: "error", showTime: "5000" })
      }
    } else {
      const isEnabled = await handleEnableUserMethod({ userId: userDetails?.id, setIsLoading: setUserStatusChangeLoader });
      if (isEnabled) {
        getSingleUserDetails({ userId: Location?.state?.userId, dispatch, setterMethod: setUserDetails, setIsLoading })
        handleShowErrorAndWarning({ dispatch, message: "User enabled successfully.", type: "success", showTime: "5000" })
      } else {
        handleShowErrorAndWarning({ dispatch, message: "Failed to enable user!", type: "error", showTime: "5000" })
      }
    }
  }

  useEffect(() => {
     // #160 
     if (!Location?.state) {
        setIsUnauthorized(true);
        return;
    }
    getSingleUserDetails({ userId: Location?.state?.userId, dispatch, setterMethod: setUserDetails, setIsLoading })
  }, [Location?.state?.userId]);

    // #160 
   if (isUnauthorized) {
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
    }
  // #160 
  if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ }))
    return (
      <>
        {Object.keys(userDetails ||{})?.length > 0 ? (
          <>
            <Subbar
              // isCreatedOn={true}
              // isDelete={loggedInUser?.userId !== userDetails?.id && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE })}
              // isDeleteMethod={() => setShowDeleteUserModal(true)}
              isEditMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => Navigate("/edit-user", { state: { id: userDetails?.id } }) : false}
              isHollow={true}
              subbarData={userDetails}
              staticElements={[
                { key: "Created On :", value: getFormatedDate(userDetails?.createdAt) },
                { key: "Last Active On :", value: getFormatedDate(userDetails?.updatedAt) },
              ]}
              htmlElements={[
                loggedInUser?.userId === userDetails?.id ? <div>
                  <ClonosButton onClick={() => setShowResetPasswordModal(true)}>Update Password</ClonosButton>
                </div> : <></>, 
                (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE })) ? <ClonosButton loading={userStatusChangeLoader}  
               //CR0031
                onClick={() =>
                  setConfirmPopup({
                    open: true,
                    type: userDetails?.isEnabled ? "disable" : "enable",
                  })
                }
                >{userDetails?.isEnabled ? "Disable User": "Enable User"}</ClonosButton>: <></>
              ]}
            />
            <Card style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
              {
                isLoading ? <ClonosSpinner /> : <div className={Styles.v_u_details_wrapper}>
                  <div className={Styles.v_u_details_left}>
                    <h4 className={Styles.v_u_details_header}>User Details</h4>
                    <div className={Styles.v_u_details_fields}>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Name</label>
                        <p>{userDetails?.name || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Employee ID</label>
                        <p>{userDetails?.employeeId || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>User Type</label>
                        <p>{userDetails?.userType?.name || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Business Unit</label>
                        <p>{userDetails?.businessUnit?.name || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Shift</label>
                        <p>{userDetails?.shift?.name || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Department</label>
                        <p>{userDetails?.department?.name || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Designation</label>
                        <p>{userDetails?.designation?.name || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Team</label>
                        <p>{userDetails?.team?.name || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Email</label>
                        <p>{userDetails?.email || "-"}</p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Contact Number</label>
                        <p>{(userDetails?.countryCode && userDetails?.contactNumber) ? `${userDetails?.countryCode} ${userDetails?.contactNumber}` : "-"} </p>
                      </div>
                      <div className={Styles.v_u_details_fieldItem}>
                        <label>Reporting To</label>
                        <p className={userDetails?.reportsTo?.name ? "ele_link" : ""} onClick={() => userDetails?.reportsTo?.name && setShowReportToDetails(true)}>{userDetails?.reportsTo?.name || "-"}</p>
                      </div>
                    </div>
                  </div>
                  <div className={Styles.v_u_details_right}>
                    {userDetails?.image?.url && <div>
                      <h4 className={Styles.v_u_details_header}>User Image</h4>
                      <div className={Styles.v_u_details_profile_wrapper}>
                        <div>
                          <img src={userDetails?.image?.url} />
                        </div>
                      </div>
                    </div>}
                    {userDetails?.eSignature?.url && <div>
                      <h4 className={Styles.v_u_details_header}>E-Signature</h4>
                      <div className={Styles.v_u_details_signature_wrapper}>
                        <div>
                          <img src={userDetails?.eSignature?.url} />
                        </div>
                        <Tooltip title={"fileName.png"}>
                          <p>fileName.png</p>
                        </Tooltip>
                      </div>
                    </div>}
                  </div>
                </div>
              }
            </Card>
          </>
        ) : (
          <>
            <div className="center_wrapper">
              <h3>No User Details Found!</h3>
            </div>
          </>
        )}
        <ResetPasswordModal
          isOpen={showResetPasswordModal}
          closeMethod={setShowResetPasswordModal}
          setShowUpdatePasswordModal={setShowUpdatePasswordModal}
        />
        {/* <OTPModal
          isOpen={showOTPModal}
          closeMethod={setShowOTPModal}
          setShowUpdatePasswordModal={setShowUpdatePasswordModal}
          otpLength={6}
        /> */}
        <UpdatePasswordModal
          isOpen={showUpdatePasswordModal}
          closeMethod={setShowUpdatePasswordModal}
          userData={userDetails}
        />
        <WarningPopup
          isOpen={showDeleteUserModal}
          closeMethod={setShowDeleteUserModal}
          proceedMethod={handleDeleteUser}
          title={"Delete User"}
          message={"Do you confirm that you want to Delete this User ?"}
          name={userDetails?.name}
          id={userDetails?.employeeId}
        />
        <ViewReportsToModal isOpen={showReportToDetails} closeMethod={setShowReportToDetails} userId={userDetails?.reportsTo?.id} />
         {/* //CR0031 */}
              <ClonosConfirmationBox
          isOpen={confirmPopup.open}
          confirmingMethod={async () => {
            await handleUserStatus(); // API call
            setConfirmPopup({ open: false, type: "" });
          }}
          closeModalMethod={() =>
            setConfirmPopup({ open: false, type: "" })
          }
          headerTitle={
            confirmPopup.type === "disable" ? "Disable User" : "Enable User"
          }
           rejectingMethod={() => {}}
          message={
            confirmPopup.type === "disable"
              ? "Are you sure you want to disable this user?"
              : "Are you sure you want to enable this user?"
          }
        />
      </>
    );
   // #160 
  return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
};

export default ViewUserDetails;
