import { useEffect, useState } from "react";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import {
  generateSkeletonColumns,
  globalHandleIsAllRequiredFieldAvailable,
  handleLoggedInUser,
  handleShowErrorAndWarning,
  hasPermission,
  setSerialNumber,
} from "../../../../utils/clonosCommon";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { Tooltip } from "@material-ui/core";
import { TeamView } from "../TeamView/TeamView";
import {
    createTeamMethod,
  deleteTeamsMethod,
  editTeamMethod,
  getAllTeamsListMethod,
} from "../../../../utils/UsersMethods/teamsMethods";
import { useDispatch } from "react-redux";
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import {
    CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS,
  CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS,
  CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS,
  CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS,
} from "../../../../Constants/Constant";
import { TeamEdit } from "../TeamCreateAndEdit/TeamEdit";
import { useSelector } from "react-redux";
import { teamsActions } from "../../../../Store/Reducers/ClonosTeamsReducer";
import { getUsersList } from "../../../../utils/UsersMethods/usersMethods";
import { userActions } from "../../../../Store/Reducers/ClonosUserReducer";

let primaryObject = {};

export const TeamList = () => {
  const dispatch = useDispatch();
  const user = handleLoggedInUser();
  const { allTeams } = useSelector((store) => store.teamsData);
  const [isLoading, setIsLoading] = useToggler();
  const [selectedRows, setSelectedRows] = useState([]);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, limit: 15 });
  const [selectedTeamDetails, setSelectedTeamDetails] = useState({});
  const [showTeamDetailsModal, setShowTeamDetailsModal] = useState(false);
  const [showEditTeamModal, setShowEditTeamModal] = useState(false);
  const columnsForTeams = [
    {
      field: "index",
      headerName: "SI.NO",
      width: 100,
      hideable: false
    },
    {
      field: "name",
      headerName: "Team Name",
      flex: 1,
      renderCell: (param) => {
        return (
          <Tooltip title={param?.row?.name}>
            <p
              onClick={() => {
                setSelectedTeamDetails(param?.row);
                setShowTeamDetailsModal(true);
              }}
              className="clonos_datagrid_link"
            >
              {param?.row?.name || "-"}
            </p>
          </Tooltip>
        );
      },
    },
    {
      field: "businessUnit",
      headerName: "Business Unit",
      flex: 1,
      renderCell: (param) => {
        return (
          <Tooltip title={param?.row?.businessUnit?.name}>
            <p>{param?.row?.businessUnit?.name || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "department",
      headerName: "Department",
      flex: 1,
      renderCell: (param) => {
        return (
          <Tooltip title={param?.row?.department?.name}>
            <p>{param?.row?.department?.name || "-"}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "teamMembers",
      headerName: "Team Members",
      flex: 1,
      renderCell: (param) => {
        return (
          <Tooltip title={param?.row?.users?.length}>
            <p>{param?.row?.users?.length || "0"}</p>
          </Tooltip>
        );
      },
    },
  ];


  const handleDeleteTeams = async () => {
    const isDeleted = await deleteTeamsMethod({ dispatch, payload: { teams: selectedRows },});
    if (isDeleted === true) {
      handleShowErrorAndWarning({ dispatch, type: "success", message: "Teams Deleted Successfully.",showTime: "5000",});
      const teams = await getAllTeamsListMethod({ dispatch, setIsLoading });
      if(teams?.data){
        dispatch(teamsActions.getAllTeams(teams));
      }
        setShowConfirmationDialog(false);
        setSelectedRows([]);
    } else {
      handleShowErrorAndWarning({dispatch, type: "error",message: "Failed!. Somethinf went wrong.",showTime: "5000", });
    }
  };



  // TO SAVE UPDATED TEAMS DETAILS
  const handleEditTeam = async ({changedData,teamId,closeMethod,closePreviousModal,}) => {
    if(changedData?.appendUsers || changedData?.removeUsers || changedData?.name){   // To restrict API call on no changes
      const isTeamEdited = await editTeamMethod({dispatch,teamId,payload: changedData,setIsLoading,});
      if (isTeamEdited === true) {
        handleShowErrorAndWarning({dispatch,type: "success",message: "Team updated successfully.",showTime: "5000",});
        closeMethod(false);
        if (closePreviousModal) closePreviousModal(false);
        const teams = await getAllTeamsListMethod({ dispatch });
        if(teams?.data?.length)dispatch(teamsActions.getAllTeams(teams));
        // const users = await getUsersList({dispatch,pagination:{limit:15,page:1}});
        // dispatch(userActions.getAllUsers(users))
        // if(users?.data?.length){
        // } else {
        //     handleShowErrorAndWarning({dispatch,type:"error",message:"Failed to fetch users!",showTime:"5000"})
        // }
        closeMethod(false);
      } 
    }
  };


  

  useEffect(() => {
    (async () => {
      const data = await getAllTeamsListMethod({ dispatch, setIsLoading });
      if (data?.data?.length) dispatch(teamsActions.getAllTeams(data));
    })();
  }, []);

  return (
    <>
      <div
        style={{ height: "90%", width: "60%", margin: "auto", padding: "1rem" }}
      >
        <ClonosDataGrid
          uniqueIdField="id"
          loading={isLoading}
          columns={ columnsForTeams}
          pageLimit={pagination.limit}
          totalCount={allTeams?.totalDataCount}
          handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows) }
          onPageChange={(e) => setPagination({ page: e.page + 1, limit: e.pageSize })}
          checkboxSelection={ !hasPermission("/delete-team") || hasPermission("/edit-team")}
          isEditMethod={!hasPermission("/edit-team") ? () => setShowEditTeamModal(true) : false}
          isDeleteMethod={ !hasPermission("/delete-team") ? () => setShowConfirmationDialog(true) : false}
          rows={allTeams?.data?.length ? setSerialNumber(allTeams?.data,pagination?.page,pagination?.limit) : []}
        />
      </div>
      {showTeamDetailsModal ? (
        <TeamView isOpen={showTeamDetailsModal} closeMethod={setShowTeamDetailsModal} data={selectedTeamDetails} handleEditTeam={handleEditTeam} />
      ) : (
        <></>
      )}
      {showEditTeamModal ? (
        <TeamEdit isOpen={showEditTeamModal} closeMethod={setShowEditTeamModal} teamId={selectedTeamDetails?.id ? selectedTeamDetails?.id : selectedRows[0]} handleEditTeam={handleEditTeam}/>
      ) : (
        <></>
      )}
      <ClonosConfirmationBox isOpen={showConfirmationDialog} headerTitle={"Delete Team"}  message={"Are you sure you want to Delete?"} closeModalMethod={setShowConfirmationDialog} confirmingMethod={handleDeleteTeams}/>
    </>
  );
};
