import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant"
import { debounce, globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning, modifyString } from "../../../../utils/clonosCommon"
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/TeamCreateAndEdit/TeamCreateAndEdit.module.css"
import { getDepartmentDropdownData, getUsersDropdownData } from "../../../../utils/UsersMethods/usersMethods"
import DynamicDropdown from "../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown"
import { createTeamMethod, getAllTeamsListMethod } from "../../../../utils/UsersMethods/teamsMethods"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import { teamsActions } from "../../../../Store/Reducers/ClonosTeamsReducer"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import useToggler from "../../../../CustomHooks/TogglerHook"
import { useEffect, useState } from "react"
import { useDispatch } from "react-redux"
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
import { message } from "antd"
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { handleCheckUniqueFieldsMethod } from "../../../../utils/common-managers"

export const TeamCreate = ({ isOpen, closeMethod, mode, handleCreateTeamMethod }) => {
    const dispatch = useDispatch();
    const [formData, setFormData] = useState({});
    const [isLoading, setIsLoading] = useToggler();
    const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
    const [departmentDropdownData, setDepartmentDropdownData] = useState([]);
    const [teamMembersDropdownData, setTeamMembersDropdownData] = useState({});
    const [teamMembersPagination, setTeamMembersPagination] = useState({ limit: 15, page: 1 })
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })

    const handleGetValues = (val) => {
        const { type, uniqueKey, updatedValue, selectedOption } = val;
        if (type === "text") {
            if (uniqueKey === "name") {
                if (updatedValue?.length) {
                    debouncedCheckUniquenessOfEmloyeeId({ fieldName: uniqueKey, fieldValue: updatedValue });
                }
            } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => ({ ...prev, [uniqueKey]: updatedValue }))
            }

        } else if (type === "dynamicDropdown") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
            setFormData((prev) => ({ ...prev, [uniqueKey]: selectedOption }))
        } else if (type === "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => ({ ...prev, [uniqueKey]: { name: updatedValue?.label, id: updatedValue?.value } }))
        }
    }


    const uniqueFieldHandler = ({ fieldName, fieldValue }) => {
        handleCheckUniqueFieldsMethod({ module: "teams", fieldName, fieldValue }).then((res) => {
            if (res === "unique") {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
                setFormData((prev) => {
                    return { ...prev, [fieldName]: valueSetter ? fieldValue : null }
                })
                // setIsUniqueField((prev) => ({ ...prev, employeeId: false }))
            } else if (res === "not_unique") {
                primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
                primaryObject?.[fieldName]?.errorActivatorMethod(true);
                primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${modifyString(fieldName, "spacecase")}.`)
            }
        })
    }


    const debouncedCheckUniquenessOfEmloyeeId = debounce(uniqueFieldHandler, 2000);



    const handleMoreData = () => {
        if (teamMembersDropdownData?.currentPage < teamMembersDropdownData?.totalPageCount) {
            setTeamMembersPagination((prev) => {
                getUsersDropdownData({ userRole: "", setterMethod: setTeamMembersDropdownData, dispatch, filterPayload: { departments: formData?.department?.id, withoutTeam: true, page: prev + 1, limit: 15 } });
                return prev + 1
            })
        }
    }

    const handleCreateTeam = () => {
        if (handleSubmit()) {
            handleCreateTeamMethod({ formData, closeMethod, setIsLoading, setFormData })
        } else {
            handleShowErrorAndWarning({ dispatch, message: "Please provide all required fields.", type: "error", showTime: "5000" })
        }
    }

    useEffect(() => {
        getDepartmentDropdownData({ dispatch, setterMethod: setDepartmentDropdownData })
    }, []);

    useEffect(() => {
        if (formData?.department?.id) {
            getUsersDropdownData({ dispatch, setterMethod: setTeamMembersDropdownData, filterPayload: { departments: formData?.department?.id, withoutTeam: true } })
        }
    }, [formData?.department])
    return (
        <>
            <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
                <div className={Styles.c_e_team_container}>
                    <div className={Styles.c_e_team_header}>
                        <h4>Create New Team</h4>
                        <CloseIcon onClick={() => closeMethod(false)} />
                    </div>
                    <div className={Styles.c_e_team_section}>
                        <ClonosInput
                            tabIndex={1}
                            type={"text"}
                            isLabel={true}
                            isMandatory={true}
                            uniqueKey={"name"}
                            label={"Team Name"}
                            areaLabel={"team_name"}
                            placeholder={"Team Name"}
                            isSpecialCharacterAllow={true}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide team name."}
                            onlyAllowTheseSpecialCharacters={["-", "-"]}
                            defaultValue={mode === "edit" && formData?.name}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                        <ClonosSelect
                            tabIndex={2}
                            type="select"
                            isLabel={true}
                            label="Department"
                            isMandatory={true}
                            placeholder="Select"
                            uniqueKey="department"
                            areaLabel="Department"
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide department."}
                            defaultValue={mode === "edit" && formData?.department?.name}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            options={departmentDropdownData?.map((department) => ({ label: department?.name, value: department?.id, isNeeded: true }))}
                        />

                        <DynamicDropdown
                            tabIndex={4}
                            isUser={true}
                            isLabel={true}
                            isActivator={true}
                            isMandatory={true}
                            isCheckbox={true}
                            isSearchable={true}
                            uniqueKey={"users"}
                            placeholder="Select"
                            title="Team Members"
                            label={"Team Members"}
                            labelActivator={"Team Members"}
                            handleMoreData={handleMoreData}
                            handleGetValues={handleGetValues}
                            disabled={!formData?.department?.id}
                            heading={"Select from User Library"}
                            errorMessage={"Please provide team members."}
                            noDataMessage={"No users found for selected department"}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            data={teamMembersDropdownData?.data?.map((teamMember) => ({ ...teamMember, isNeeded: true }))}
                        />

                    </div>
                    <div className={Styles.c_e_team_confirm_wrapper}>
                        <div>
                            <ClonosButton onClick={() => closeMethod(false)}>Cancel</ClonosButton>
                            <ClonosButton loading={isLoading} onClick={handleCreateTeam}>Create</ClonosButton>
                        </div>
                    </div>
                </div>
            </Modal>
            {/* <ClonosConfirmationBox
                isOpen={showConfirmationDialog}
                closeModalMethod={() => setShowConfirmationDialog(false)}
                confirmingMethod={() => closeMethod(false)}
                rejectingMethod={() => setShowConfirmationDialog(false)}
                message={"Are you sure to cancel it ?"}
                headerTitle={"Cancel"}
            /> */}
        </>
    )
}