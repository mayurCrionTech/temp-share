import { useEffect, useState } from "react"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect"
import DynamicDropdown from "../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/TeamCreateAndEdit/TeamCreateAndEdit.module.css"
import { handleGetUsersDropdownData } from "../../../../utils/WorkOrderMethods/WorkOrderMethods";
import { globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import { getDepartmentDropdownData, getUsersDropdownData } from "../../../../utils/UsersMethods/usersMethods"
import { useDispatch } from "react-redux"
import { createTeamMethod, editTeamMethod, getAllTeamsListMethod, getSigleTeamDetailsMethod } from "../../../../utils/UsersMethods/teamsMethods"
import useToggler from "../../../../CustomHooks/TogglerHook"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner"
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant"
import { teamsActions } from "../../../../Store/Reducers/ClonosTeamsReducer"
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"

export const TeamEdit = ({ isOpen, closeMethod, teamId, closePreviousModal, handleEditTeam }) => {
    const dispatch = useDispatch();
    const [isLoading, setIsLoading] = useToggler();
    const [fetchTeamLoading, setFetchTeamLoading] = useToggler()
    const [formData, setFormData] = useState({});
    const [lcServerResponse, setLcServerResponse] = useState({})
    const [changedData, setChangedData] = useState({})
    const [departmentDropdownData, setDepartmentDropdownData] = useState([]);
    const [teamMembersDropdownData, setTeamMembersDropdownData] = useState({});
    const [teamMembersPagination, setTeamMembersPagination] = useState({ limit: 15, page: 1 })
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })

    const handleGetValues = (val) => {
        const { name, type, uniqueKey, updatedValue, selectedOption, deselectedOptions, removedItem } = val;
        if (type === "text") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setChangedData((prev) => ({ ...prev, [uniqueKey]: updatedValue }))
        } else if (type === "dynamicDropdown") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
            const existingUsersIds = formData?.users?.length ? formData?.users?.map((user) => user?.id) : [];
            const newAddedUsers = [];
            selectedOption?.forEach((user) => {
                if (!existingUsersIds?.includes(user?.id)) {
                    newAddedUsers.push(user?.id)
                }
            });
            setChangedData((prev) => ({ ...prev, appendUsers: newAddedUsers, removeUsers: deselectedOptions }))
        } else if (type === "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setChangedData((prev) => ({ ...prev, [uniqueKey]: { name: updatedValue?.label, id: updatedValue?.value } }))
        }
    }

    const handleMoreData = () => {
        if (teamMembersDropdownData?.currentPage < teamMembersDropdownData?.totalPageCount) {
            setTeamMembersPagination((prev) => {
                getUsersDropdownData({ userRole: "", setterMethod: setTeamMembersDropdownData, dispatch, filterPayload: { departments: formData?.department?.id, withoutTeam: true, page: prev + 1, limit: 15 } });
                return prev + 1
            })
        }
    }

    const handleUpdateTeam = async () => {
        // if(!globalHandleIsAllRequiredFieldAvailable({primaryObject }) || (changedData?.name === "" )){  // this function will check for all mandatory fields.
        //     return 
        // } else {
        //    const res = await editTeamMethod({dispatch,teamId,payload:changedData,setIsLoading});
        //    if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
        //         handleShowErrorAndWarning({dispatch,type:"success",message:"Team updated successfully.",showTime:"5000"});
        //         closeMethod(false);
        //         if(closePreviousModal) closePreviousModal(false)
        //         const data1 = await  getAllTeamsListMethod({dispatch});
        //         if(data1?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
        //             dispatch(teamsActions.getAllTeams(data1?.result));
        //         } else {
        //             handleShowErrorAndWarning({dispatch,type:"error",message:"Failed to fetch teams!",showTime:"5000"})
        //         }
        //         closeMethod(false)
        //     } else {
        //         handleShowErrorAndWarning({dispatch,type:"error",message:"Failed!, something went wrong..",showTime:"5000"});
        //     }
        // }
        if (!handleSubmit()) {
            return
        } else {
            handleEditTeam({ changedData, teamId, closeMethod, closePreviousModal })
        }
    }


    useEffect(() => {
        getDepartmentDropdownData({ dispatch, setterMethod: setDepartmentDropdownData })
    }, []);

    useEffect(() => {
        if (teamId) {
            getSigleTeamDetailsMethod({ dispatch, teamId, setterMethod: setFormData, setIsLoading: setFetchTeamLoading })
        }
    }, [teamId])

    useEffect(() => {
        if (formData?.department?.id) {
            getUsersDropdownData({ dispatch, setterMethod: setTeamMembersDropdownData, filterPayload: { departments: changedData?.department ? changedData?.department?.id : formData?.department?.id, withoutTeam: true}, formData, isModify: true });  // IF YOU WANT TO MODIFY SERVER RESPONSE WITH SOME EXISTING DATA
        }
    }, [changedData?.department?.id, formData])

    
    return (
        <>
            {
                fetchTeamLoading ? <div className="center_wrapper">
                    <ClonosSpinner />
                </div>
                    : <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
                        <div className={Styles.c_e_team_container}>
                            <div className={Styles.c_e_team_header}>
                                <h4>Edit Team</h4>
                                <CloseIcon onClick={() => closeMethod(false)} />
                            </div>
                            <div className={Styles.c_e_team_section}>
                                <ClonosInput
                                    tabIndex={1}
                                    isLabel={true}
                                    label={"Team Name"}
                                    isMandatory={true}
                                    uniqueKey={"name"}
                                    type={"text"}
                                    areaLabel={"team_name"}
                                    placeholder={"Team Name"}
                                    handleGetValues={handleGetValues}
                                    errorMessage={"Please provide team name."}
                                    defaultValue={formData?.name}
                                    isSpecialCharacterAllow={true}
                                    onlyAllowTheseSpecialCharacters={["-", "-"]}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />
                                <ClonosSelect
                                    tabIndex={2}
                                    type="select"
                                    label="Department"
                                    isLabel={true}
                                    isMandatory={true}
                                    uniqueKey="department"
                                    areaLabel="Department"
                                    placeholder="Select"
                                    options={departmentDropdownData?.map((department) => ({ label: department?.name, value: department?.id, isNeeded: true, disabled: true }))}
                                    defaultValue={formData?.department?.name}
                                    handleGetValues={handleGetValues}
                                    errorMessage={"Please provide department."}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />
                                {/* <DynamicDropdown
                            isLabel={true}
                            tabIndex={3}
                            title="Team Owner"
                            labelActivator={"Team Owner 1"}
                            label={"Team Owner"}
                            heading={"Select from User Library"}
                            isActivator={true}
                            isMandatory={true}
                            uniqueKey={"teamOwner"}
                            data={teamOwnersData?.map((teamOwner) => ({...teamOwner,isNeeded:true}))}
                            placeholder="Select"
                            isUser={true}
                            errorMessage={"Please provide team owner."}
                            defaultValue={mode === "edit" && formData?.teamOwner?.name}
                            handleMoreData={handleMoreData}
                            isCheckbox={false}
                            handleGetValues={handleGetValues}
                            isSearchable={true}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        /> */}

                                <DynamicDropdown
                                    isLabel={true}
                                    tabIndex={4}
                                    title="Team Members"
                                    labelActivator={"Team Members"}
                                    label={"Team Members"}
                                    heading={"Select from User Library"}
                                    isActivator={true}
                                    isMandatory={true}
                                    uniqueKey={"teamMembers"}
                                    data={teamMembersDropdownData?.data?.map((teamMember) => ({ ...teamMember, isNeeded: true }))}
                                    placeholder="Select"
                                    isUser={true}
                                    errorMessage={"Please provide team members."}
                                    defaultValue={formData?.users}
                                    handleMoreData={handleMoreData}
                                    isCheckbox={true}
                                    handleGetValues={handleGetValues}
                                    isSearchable={true}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />

                            </div>
                            <div className={Styles.c_e_team_confirm_wrapper}>
                                <div>
                                    <ClonosButton onClick={() => closeMethod(false)}>Cancel</ClonosButton>
                                    <ClonosButton loading={isLoading} onClick={handleUpdateTeam}>Update</ClonosButton>
                                </div>
                            </div>
                        </div>
                    </Modal>
            }
        </>
    )
}