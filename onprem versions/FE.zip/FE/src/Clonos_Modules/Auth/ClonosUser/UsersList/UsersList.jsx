import ClonosGridNav from "../../../../utils/ClonosGridNav";
import { AllUsersCountSVG, ActiveUsersCountSVG } from "../../../../assets/UsersSVGComponents/AllUsersSVG";
import Styles from "../../../../ModuleStyles/Auth/ClonosUser/UsersList/UsersList.module.css"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import { Card, Tooltip } from "@mui/material";
import CommonNavigator from "../../../../components/CommonComponents/Navigator/Navigator";
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { useEffect, useRef, useState } from "react";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { globalHandleIsAllRequiredFieldAvailable, handleLoggedInUser, handleShowErrorAndWarning, checkUserHasPermission, generateSkeletonColumns, setSerialNumber } from "../../../../utils/clonosCommon";
import { UnAuthorizedModal } from "../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { useNavigate } from "react-router";
import { TeamCreate } from "../TeamCreateAndEdit/TeamCreate";
import { TeamList } from "../TeamList/TeamList";
import { deleteUsersMethod, getUsersCounts, getUsersList } from "../../../../utils/UsersMethods/usersMethods";
import { useDispatch } from "react-redux";
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_USERS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant";
import { useSelector } from "react-redux";
import { teamsActions } from "../../../../Store/Reducers/ClonosTeamsReducer";
import { userActions } from "../../../../Store/Reducers/ClonosUserReducer";
import { createTeamMethod, getAllTeamsListMethod } from "../../../../utils/UsersMethods/teamsMethods";
import useModuleNameProvider from "../../../../CustomHooks/ModuleNameProviderHook";
import { WarningPopup } from "../WarningPopup/WarningPopup";

let primaryObject = {};
const navigatorValues = [{ value: "Users List", status: true,visibility:true }, { value: "Team List", status: false,visibility:true}];
const UsersList = () => {
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_USERS);
    const Navigate = useNavigate();
    const dispatch = useDispatch();
    const loggedInUser = handleLoggedInUser();
    const [usersCounts, setUsersCounts] = useState({})
    const [isLoading, setIsLoading] = useToggler();
    const [navLoader,setNavLoader] = useToggler();
    const [selectedRows, setSelectedRows] = useState([]);
    const [activeTab, setActiveTab] = useState("Users List");
    const [showTeamModal, setShowTeamModal] = useState(false);
    const [pagination, setPagination] = useState({ page: 1, limit: 15 });
    const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
    const [usersData, setUsersData] = useState({})
    const columnsForUsers = [
        {
            field: "index",
            headerName: "SI.NO",
            width: 50,
            hideable: false
        },
        {
            field: "name",
            headerName: "USER NAME",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.name}>
                    <p onClick={() => Navigate(`/profile/${param?.row?.name}`, { state: { userId: param?.row?.id } })} className="clonos_datagrid_link">{param?.row?.name}</p>
                </Tooltip>
            }
        },
        {
            field: "employeeId",
            headerName: "EMPLOYEE ID",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.employeeId}>
                    <p>{param?.row?.employeeId}</p>
                </Tooltip>
            }
        },
        {
            field: "email",
            headerName: "EMAIL",
            //  flex: 1,
            width:250,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.email}>
                    <p>{param?.row?.email}</p>
                </Tooltip>
            }
        },
        {
            field: "contactNumber",
            headerName: "PHONE NUMBER",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.contactNumber}>
                    <p>{param?.row?.countryCode}{" "}{param?.row?.contactNumber}</p>
                </Tooltip>
            }
        },
        {
            field: "department",
            headerName: "DEPARTMENT",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.department?.name}>
                    <p>{param?.row?.department?.name}</p>
                </Tooltip>
            }
        },
        {
            field: "businessUnit",
            headerName: "BUSINESS UNIT",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.businessUnit?.name}>
                    <p>{param?.row?.businessUnit?.name}</p>
                </Tooltip>
            }
        },
        {
            field: "designation",
            headerName: "DESIGNATION",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.designation?.name}>
                    <p>{param?.row?.designation?.name}</p>
                </Tooltip>
            }
        },
        {
            field: "team",
            headerName: "TEAM",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.team?.name}>
                    <p>{param?.row?.team?.name || "-"}</p>
                </Tooltip>
            }
        }
    ]



    const handleChangeTab = (props) => {
        setActiveTab(props)
    }

    const handleEditUser = () => {
        Navigate("/edit-user", { state: { id: selectedRows[0] } })
    }

    const handleGetErrorActivatorInformation = (props) => {
        primaryObject = { ...primaryObject, [props.uniqueKey]: props }
    }

    const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
        if (response === null || response?.length === 0 || response === "") {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": false } }
            return false
        } else {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": true } }
            return true
        }
    }

    const handleCreateTeam = async ({ formData, setIsLoading, setFormData, closeMethod }) => {
        const data = await createTeamMethod({ dispatch, payload: formData, setIsLoading, closeMethod });
            if (data?.id) {
                handleShowErrorAndWarning({ dispatch, type: "success", message: "Team created successfully.", showTime: "5000" });
                const data1 = await getAllTeamsListMethod({ dispatch });
                if(data1?.data?.length) dispatch(teamsActions.getAllTeams(data1?.result))
                closeMethod(false);
                setFormData({});
            }
    }

    const handleDeleteUser = async () => {
        let res = await deleteUsersMethod({ payload: { users: selectedRows }, dispatch });
        if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
            handleShowErrorAndWarning({ dispatch, type: "success", message: "User Deleted successfully.", showTime: "5000" });
            setShowConfirmationDialog(false)

            const usersData = await getUsersList({ dispatch, pagination: { page: 1, limit: 15 }, setIsLoading });
            if (usersData?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                dispatch(userActions.getAllUsers(usersData?.result))
            }
        } else {
            handleShowErrorAndWarning({ dispatch, type: "error", message: "Something went wrong!", showTime: "5000" })
        }
    }


    useEffect(() => {
        getUsersList({dispatch,pagination,setterMethod:setUsersData,setIsLoading,}) 
        getUsersCounts({ dispatch, setterMethod: setUsersCounts,setLoading:setNavLoader })
    }, [pagination])

    if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_READ }))
        return (
            <>
                <ClonosGridNav isLoading={navLoader} items={[
                    {
                        icon: AllUsersCountSVG,
                        iconBg: '#E7EFFF',
                        title: 'Total Users',
                        count: usersCounts?.totalUsers
                    },
                    {
                        icon: ActiveUsersCountSVG,
                        iconBg: '#EBFAEC',
                        title: 'Active Users',
                        count: usersCounts?.enabledUsers
                    },
                ]}>
                    <div className={Styles.usr_nav_right}>
                        {checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? <div><ClonosButton onClick={() => setShowTeamModal(true)}>Create New Team</ClonosButton></div> : <></>}
                        {checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ? <div><ClonosButton onClick={() => Navigate("/create-user")} variant={"filled"}>Create New User</ClonosButton></div> : <></>}
                    </div>
                </ClonosGridNav>
                <Card style={{ margin: "0rem 1rem 1rem 1rem", height: "100%" }}>
                    <div style={{ height: "10%" }}>
                        <CommonNavigator values={navigatorValues} getSelectedValue={handleChangeTab} web={true} />
                    </div>
                    {
                        activeTab === "Users List" ?
                            <div style={{ height: "90%", padding: "1rem" }}>
                                <ClonosDataGrid
                                    rows={setSerialNumber(usersData?.data || [],pagination?.page,pagination?.limit)}
                                    columns={columnsForUsers}
                                    isEditMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE}) ? handleEditUser : false}
                                    isDeleteMethod={false}     //{checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && !selectedRows?.includes(loggedInUser?.userId) ? () => setShowConfirmationDialog(true) : false}
                                    uniqueIdField="id"
                                    onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                                    loading={isLoading}
                                    totalCount={usersData?.totalDataCount}
                                    pageLimit={pagination.limit}
                                    checkboxSelection={false}  //{hasPermission("/delete-user") && hasPermission("/edit-user")}
                                    handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                                />
                            </div>
                            :
                            <TeamList />
                    }
                </Card>
                {
                    showTeamModal ? <TeamCreate isOpen={showTeamModal} closeMethod={setShowTeamModal} primaryObject={primaryObject} handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} handlePrimaryObjectModifier={handlePrimaryObjectModifier} handleCreateTeamMethod={handleCreateTeam} /> : <></>
                }
                <WarningPopup
                    // id={}
                    // name={}
                    title={"Delete Users"}
                    message={"Do you confirm that you want to Delete?"}
                    proceedMethod={handleDeleteUser}
                    isOpen={showConfirmationDialog}
                    closeMethod={setShowConfirmationDialog}
                />
            </>
        )

    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default UsersList