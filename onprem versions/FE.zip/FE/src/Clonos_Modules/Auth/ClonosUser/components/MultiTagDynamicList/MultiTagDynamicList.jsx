import { useEffect, useState } from "react";
import { SearchIcon } from "../../../../../assets/Clonos Common Indicators/Icon_Components/SearchIcon";
import CommonNavigator from "../../../../../components/CommonComponents/Navigator/Navigator";
import Styles from "./MultiTagDynamicList.module.css";
import ClonosSpinner from "../../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { debounce } from "../../../../../utils/clonosCommon";

/**
 * @params {Array} data - An array containing the items to be displayed in the list.
 * @params {string} activeTab - Indicates the currently active tab ('Users', 'Designations', or 'Permissions').
 * @params {string} activePermissionsTab - Indicates the active tab within permissions ('Designations Permissions' or 'Users Permissions').
 * @params {boolean} isLoading - Indicates whether data is currently being loaded.
 * @params {boolean} isUser - Boolean flag indicating whether the list represents users.
 * @params {function} getSelectedTagValue - A function to handle the selected tag value.
 * @params {function} getSelectedUsersOrDesignations - A function to handle selected users or designations.
 * @params {object} selectedPermissions - An object containing selected permissions.
 * @params {object} selectedUsersOrDesignations - An object containing selected users or designations.
 */

export const MultiTagDynamicList = ({data,activeTab,activePermissionsTab,isLoading,isUser,getSelectedTagValue,getSelectedUsersOrDesignations,selectedPermissions,selectedUsersOrDesignations,handleSearch}) => {
    const [selectedValues,setSelectedValues] = useState({});
    const [navigatorValues] = useState([
      { value: activePermissionsTab === "Designations Permissions" ? "Designations" : "Users", status: true,visibility:true },
      { value: "Permissions", status: false,visibility:true },
    ])


    const handleCheckboxChange = (e,item) => {
        e.stopPropagation();
      if(!selectedValues[item?.id]){
        setSelectedValues((prev) => ({...prev,[item?.id]:{...item,checked:true}}));
      } else {
        delete selectedValues[item?.id]
        setSelectedValues({...selectedValues})
      }
    }

    const handleDebounceMethod = debounce((val) => {
      handleSearch({activeTab,value:val})
    },500)

    const handleInputChange = (e) => {
      const {value} = e.target
      handleDebounceMethod(value)
    }
    
    useEffect(() => {
      Object.keys(selectedValues)?.length && getSelectedUsersOrDesignations(selectedValues);
    },[selectedValues])


    useEffect(() => {
      // setSelectedValues({})
      return (
        setSelectedValues((activeTab === "Users" || activeTab === "Designations") ? selectedUsersOrDesignations : activeTab === "Permissions" ? selectedPermissions : {})
      )
    },[activeTab])

  return (
    <div className={Styles.m_d_container}>
      <div className={Styles.navigator_wrapper}>
        <CommonNavigator values={navigatorValues} getSelectedValue={(val) => getSelectedTagValue && getSelectedTagValue(val)}  web={true}/>
      </div>
      <div className={Styles.m_d_searchBar}>
         <SearchIcon color="#8CA1C4" size={"20px"}/>
         <input onChange={handleInputChange} placeholder="search"/>
      </div>
      <div className={Styles.m_d_list}>
         {
            data?.length ? data?.map((item) => {
              const isSelected = (activeTab === "Users" || activeTab === "Designations") ? selectedUsersOrDesignations[item?.id] ? true : false: activeTab === "Permissions" ? selectedPermissions[item?.id] ? true : false:false;
              return <div className={Styles.m_d_list_item} key={item.id}>
              <input
                type="checkbox"
                id={item.id}
                style={{width:"15px",height:"15px",border:"1.5px solid black",cursor:"pointer"}}
                checked={isSelected}
                onChange={e => handleCheckboxChange(e,item)}
              />
              <label style={{cursor:"pointer"}} htmlFor={item.id} onClick={(e) => e.stopPropagation()}>
                <span className={Styles.label_span_1}>{item?.name}</span><br />
                {isUser ? <span className={Styles.label_span_2}>{item?.employeeId}</span> : <></>}
              </label>
            </div>
            }) : isLoading ? <div className="center_wrapper"><ClonosSpinner/></div> :  <h4 style={{textAlign:"center"}}>No Results found!</h4>
         }
      </div>
    </div>
  );
};
