import { useEffect, useState } from "react"
import ClonosDataGrid from "../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { generateSkeletonColumns } from "../../../../utils/clonosCommon";

export const PermissionsTable = ({rows,isLoading,columns,modulePermissions,isMultiSelect,loading}) => {
    const [showLoading,setShowLoading] = useState(false);
    const skeletonFields = [ 
		{id:1,headerName:"Name",width:50,hideable: false,disableColumnFilter: true},
		{id:2,headerName:"Permission 1",hideable: false,disableColumnFilter: true},
		{id:3,headerName:"Permission 2",hideable: false,disableColumnFilter: true},
		{id:4,headerName:"Permission 3",hideable: false,disableColumnFilter: true},
		{id:5,headerName:"Permission 4",hideable: false,disableColumnFilter: true},
	]
    return (
        <div style={{height:isMultiSelect ? "400px" : "110px",width:"70%",margin:"auto",background:"#FFF"}}>
            {
                isLoading ? <div className="center_wrapper">
                    <ClonosSpinner/>
                </div> 
                : <ClonosDataGrid
                    rows={rows}
                    columns={isLoading ? generateSkeletonColumns(skeletonFields) : columns}
                    uniqueIdField={"id"}
                    hideFooter={!isMultiSelect}
                    checkboxSelection={false}
                />
            }
        </div>
    )
}