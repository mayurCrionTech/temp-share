import { useEffect, useState } from "react"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import { MultiTagDynamicList } from "../components/MultiTagDynamicList/MultiTagDynamicList"
import Styles from "./MultiplePermissionsManager.module.css"
import { getUsersDropdownData } from "../../../../utils/UsersMethods/usersMethods"
import { useDispatch } from "react-redux"
import { IoIosClose } from "react-icons/io"
import { CLONOS_MODULE_PERMISSIONS } from "../../../../utils/AuthMethods/Constant"
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant"
import { getAllDesignationsWithPermissions, getPermissionsOfActiveModule, getUsersWithPermissions, handleAssignMultiplePermissionsToDesignations, handleAssignMultiplePermissionsToUsers, handleCommonMultiplePermissionsMethod } from "../../../../utils/PermissionsMethods/PermissionsMethod"
import useToggler from "../../../../CustomHooks/TogglerHook"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import { handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import { permissionsActions } from "../../../../Store/Reducers/ClonosPermissionsReducer";


export const MultiplePermissionsManager = ({isOpen,closeMethod,isUser,activeModuleTab,activePermissionsTab,modulesNavigatorValues}) => {
    const dispatch = useDispatch();
    const [data,setData] = useState([]);
    const [isLoading,setIsLoading] = useToggler();
    const [submitLoader,setSubmitLoader] = useToggler();
    const [modulePermissions,setModulePermissions] = useState([])
    const [pagination,setPagination] = useState({limit:15,page:1});
    const [selectedPermissions,setSelectedPermissions] = useState({})
    const [selectedUsersOrDesignations,setSelectedUsersOrDesignations] = useState({});
    const [activeTab,setActiveTab] = useState(activePermissionsTab === "Users List" ? "Users" : activePermissionsTab === "Designations Permissions" ? "Designations" : "");

    const handleDeselectUsersOrDesignations = (id) => {
       delete selectedUsersOrDesignations[id];
       setSelectedUsersOrDesignations({...selectedUsersOrDesignations})
    }

    const handleDeselectPermissions = (id) => {
        delete selectedPermissions[id];
       setSelectedPermissions({...selectedPermissions})
    }

    const handleSelectedValues = (val) => {
        if(activeTab === "Users" || activeTab === "Designations"){
            setSelectedUsersOrDesignations(val)
        } else if(activeTab === "Permissions"){
            setSelectedPermissions(val)
        }
    }

    const handleModuleBasePermissionsMethod = async ({activeModuleId,filterPayload}) => {
        const fetchedPermissions = activeModuleId ? await getPermissionsOfActiveModule({dispatch,moduleId: activeModuleId,setIsLoading,filterPayload:filterPayload ? filterPayload: {}}) : null;
        if (fetchedPermissions?.length) {
            const modifiedPermissions = fetchedPermissions?.map((permission) => {
            const permissionName = permission?.name;
            // Split the string into words
            const words = permissionName?.split(/(?=[A-Z])/);

            // Capitalize the first letter of each word and join them with a space
            let result = words.map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
            return { ...permission, name: result };
            });
            setData({data:modifiedPermissions})
        }
    }

    const handleGetDesignationsMethod = async ({filterPayload}) => {
        const fetchedDesignations = await getAllDesignationsWithPermissions({dispatch,setIsLoading,filterPayload});
        if(fetchedDesignations?.data){
            setData(fetchedDesignations);
        }
    }

    

    const handleSearch = (val) => {
        if(val?.activeTab === "Users"){
            getUsersDropdownData({ userRole: "", setterMethod: setData, dispatch, filterPayload: {...pagination,name:val?.value} })
        } else if(val?.activeTab === "Permissions"){
            const filteredModule = modulesNavigatorValues?.filter((module) => module?.value === activeModuleTab);
            const activeModuleId = filteredModule[0]?.id;
            handleModuleBasePermissionsMethod({activeModuleId,filterPayload:{name:val?.value}})
        } else if(val?.activeTab === "Designations"){
            handleGetDesignationsMethod({filterPayload:{...pagination,name:val?.value}})
        }
    }

    const handleUpdatePermissions = () => {
        handleCommonMultiplePermissionsMethod({dispatch,selectedPermissions,selectedUsersOrDesignations,activePermissionsTab,activeModuleTab,setSubmitLoader,setFetchUserOrDesignationLoader:setIsLoading,closeMethod})
    }
    
    useEffect(() => {
        setActiveTab(activePermissionsTab === "Users List" ? "Users" : activePermissionsTab === "Designations Permissions" ? "Designations" : "")
    },[activePermissionsTab])

    useEffect(() => {
        (async () => {
            if(activeTab === "Users"){
                const fetchedUsers = await getUsersWithPermissions({dispatch,setIsLoading,filterPayload:pagination});
                if(fetchedUsers?.data?.length) setData(fetchedUsers)
            } else if(activeTab === "Permissions"){
                const filteredModule = modulesNavigatorValues?.filter((module) => module?.value === activeModuleTab);
                const activeModuleId = filteredModule[0]?.id;
                handleModuleBasePermissionsMethod({activeModuleId})
            } else if(activeTab === "Designations"){
                handleGetDesignationsMethod({filterPayload:pagination})
            }
        })()
    },[activeTab]);


    // useEffect(() => {
    //     if(!isOpen){
    //         setActiveTab(activePermissionsTab === "Users List" ? "Users" : activePermissionsTab === "Designations Permissions" ? "Designations" : "");
    //         setData({})
    //     }
    //     return () => {
    //         setSelectedPermissions({});
    //         setSelectedUsersOrDesignations({});
    //     }
    // },[isOpen])
    return (
        <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
            <div className={Styles.m_p_m_container}>
                <div className={Styles.m_p_m_section}>
                    <div className={Styles.m_p_m_section_left}>
                        <MultiTagDynamicList  data={data?.data} activePermissionsTab={activePermissionsTab} activeTab={activeTab} isLoading={isLoading} getSelectedTagValue={(val) => setActiveTab(val)} getSelectedUsersOrDesignations={(val) => handleSelectedValues(val)} isUser={activeTab === "Users"} selectedPermissions={selectedPermissions} selectedUsersOrDesignations={selectedUsersOrDesignations} handleSearch={handleSearch}/>
                    </div>
                    <div className={Styles.m_p_m_section_right}>
                        <div className={Styles.s_r_users}>
                            <>
                             <h4>{activePermissionsTab === "Users List" ? "Users" : activePermissionsTab === "Designations Permissions" ? "Designations" : ""}</h4>
                             {
                            Object?.keys(selectedUsersOrDesignations)?.map((user) => {
                                return <div className={Styles.s_r_user_tab}>
                                    <div>
                                       <h5>{selectedUsersOrDesignations[user]?.name}</h5>
                                       {activePermissionsTab === "Users List" ? <p>{selectedUsersOrDesignations[user]?.employeeId}</p> : <></>}
                                    </div>
                                    <span onClick={() => handleDeselectUsersOrDesignations(user)}><IoIosClose fontSize={"20px"}/></span>
                                </div>
                            })
                           }
                            </>
                        </div>
                        <div className={Styles.s_r_permissions}>
                        <>
                             <h4>Permissions</h4>
                             {
                            Object?.keys(selectedPermissions)?.map((permission) => {
                                return <div className={Styles.s_r_user_tab}>
                                    <div>
                                       <h5>{selectedPermissions[permission]?.name}</h5>
                                    </div>
                                    <span onClick={() => handleDeselectPermissions(permission)}><IoIosClose fontSize={"20px"}/></span>
                                </div>
                            })
                           }
                            </>
                        </div>
                    </div>
                </div>
                <div className={Styles.m_p_m_footer}>
                    <ClonosButton onClick={() => closeMethod(false)}>Cancel</ClonosButton>
                    <ClonosButton isLoading={submitLoader} style={{background:"#06337E",color:"#FFF"}} onClick={handleUpdatePermissions}>Update Permissions</ClonosButton>
                </div>
                <div className={Styles.m_p_m_close_wrapper} onClick={() => closeMethod(false)}><CloseIcon/></div>
            </div>
        </Modal>
    )
}