import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import Styles from "../../ModuleStyles/Documents/DocumentsList.module.css"
import { useNavigate } from 'react-router'
import { hasPermission, commonPageState, setSerialNumber, handleShowErrorAndWarning, getToken, getFormatedDate, checkUserHasPermission } from '../../utils/clonosCommon'
import No_image_available from "../../assets/images/No_image_available.png"
import { TotalDocuments, DocumentsAttachedToAsset, PendingWorkOrderDocs } from '../../assets/svg/TotalDocuments'
import { Card } from '@mui/material'
import { doGetApiCall, doPutApiCall } from '../../utils/ClonosApi'
import AppUrl from '../../utils/AppUrl'
import useToggler from '../../CustomHooks/TogglerHook'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_DOCUMENTS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from '../../Constants/Constant'
import ClonosGridNav from '../../utils/ClonosGridNav'
import Modal from '../../components/CommonComponents/Modal/Modal'
import { ClonosButton } from '../../components/CommonComponents/Button/Button'
import ClonosDataGrid from '../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import configs from '../../config'
import DownloadIcon from '../../assets/Clonos Common Indicators/Icon_Components/DownloadIcon'
import CloseIcon from '../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import ClonosConfirmationBox from '../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { UnAuthorizedModal } from '../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
import useModuleNameProvider from '../../CustomHooks/ModuleNameProviderHook'

let selectedDoc = {};

const DocumentsList = () => {
    // Local States 
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_DOCUMENTS);
    const [selectedRows, setSelectedRows] = useState([]);
    const [pagination, setPagination] = useState(commonPageState);
    const [totalCount, setTotalCount] = useState(0);
    const [isLoading, setIsLoading] = useToggler();
    const [refreshApi, setRefreshApi] = useToggler();
    const [documents, setDocuments] = useState([]);
    const [isModal, setIsModal] = useState(false);
    const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            width: "50",
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            field: "documentNumber",
            headerName: "DOCUMENT NUMBER",
            disableColumnFilter: true,
            flex: 1,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.documentNumber || "-"
        },
        {
            field: "documentTitle",
            headerName: "DOCUMENT NAME",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.documentTitle || "-"
        },
        {
            field: "asset",
            headerName: "ASSET NAME",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.asset?.name || "-"
        },
        {
            field: "documentType",
            headerName: "DOCUMENT TYPE",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.documentType?.name || "-"
        },
        {
            field: "approvalStatus",
            headerName: "STATUS",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.approvalStatus?.name || "-"
        },
        {
            field: "revisionNumber",
            headerName: "REVISION NUMBER",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            valueGetter: (params) => params?.row?.revisionNumber
        },
        {
            field: "fileName",
            headerName: "VIEW DOCUMENT",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
            renderCell: (params) => {
                return <p style={{ textDecoration: "underline", color: "#3F51B5", cursor: "pointer" }} onClick={() => {
                    const item = params?.row;
                    if (item?.fileName && item?.path && (item?.extension === "jpg" || item?.extension === "jpeg" || item?.extension === "png")) {
                        selectedDoc = params?.row;
                        setIsModal(true);
                    }
                    else if (item?.extension === "pdf" || item?.extension === "doc" || item?.extension === "xls" || item?.extension === "ppt") {
                        // window.open(`${configs.url}?docId=${item?.docId}&token=${getToken()}`);
                        window.open(item?.path, "_blank");
                    } else {
                        handleShowErrorAndWarning({ dispatch, type: "error", message: `Document not uploaded properly!`, showTime: 5000 })
                    }
                }}>{params?.row?.originalName || "-"}</p>
            }
        }
    ];

    // Handler Area

    /**
     * 'handleDeleteDocuments' function will use for delete the multiple or single documents.
     * @param {Object} props - this props will cotainer the selectedRows array 
     * @param {Array} props.selectedRows - Selected rows
     */
    const handleDeleteDocuments = (props) => {
        if (props?.selectedRows?.length > 0) {
            doPutApiCall(AppUrl?.deleteMultipleDocuments, { ["docIds"]: (props?.selectedRows || []) }).then(res => {
                if (res.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
                    handleShowErrorAndWarning({ type: 'success', message: `${props?.selectedRows?.length > 1 ? "Documents" : "Document"} has been deleted.`, showTime: 5000, dispatch });
                } else {
                    handleShowErrorAndWarning({ type: 'error', message: `Something went wrong while deleting the ${props?.selectedRows?.length > 1 ? "Documents" : "Document"}!`, showTime: 5000, dispatch });
                };
            }).finally(() => {
                setRefreshApi();
                setShowConfirmationDailog(false)
            });
        };
    };

    const handleEditDocument = (props) => {
        navigate("/edit-document", { state: { selectedDoc: (documents || []).filter((item) => item?.docId === props?.docId)[0] } });
    };

    const handleDownloadDocument = (docId) => {
        doGetApiCall(`/documents/download/${docId}`).then(res => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                const linkElement = document.createElement('a');
                linkElement.style.display = 'none';
                linkElement.href = res?.data?.downloadUrl;
                linkElement.setAttribute("download", selectedDoc?.originalName);
                document.body.appendChild(linkElement);
                linkElement.click();
                document.body.removeChild(linkElement);
            } else {
                handleShowErrorAndWarning({ type: "error", message: "Something went wrong!", showTime: 5000, dispatch });
            };
        });
    };


    useEffect(() => {
        setIsLoading();
        setDocuments([]);
        doGetApiCall(AppUrl.getDocuments, pagination)
            .then(res => {
                setDocuments(setSerialNumber(res?.data?.result?.data || [], pagination.page, pagination.limit));
                setTotalCount(res?.data?.result?.totalDataCount || res?.data?.result?.documents?.length || 0)
            })
            .finally(setIsLoading);
    }, [pagination, refreshApi]);
    if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_READ}))
    return <>
        <ClonosGridNav items={[
            {
                icon: TotalDocuments,
                iconBg: '#E7EFFF',
                title: 'Total Documents',
                count: 100
            },
            {
                icon: DocumentsAttachedToAsset,
                iconBg: '#EBFAEC',
                title: 'Documents attached to Assets',
                count: 100
            },
            {
                icon: PendingWorkOrderDocs,
                iconBg: '#F7E9BF',
                title: 'Pending Work Order',
                count: 100
            }
        ]}>
            <div className="d-fl-al-cen">
                {hasPermission('/create-document') ? <ClonosButton onClick={() => navigate("/create-document")} variant={"filled"}>Upload Document</ClonosButton> : <></>}
            </div>
        </ClonosGridNav>
        <Card variant="outlined" style={{ flex: 1, margin: "0rem 1rem 1rem 1rem", padding: "2.5rem 2rem", borderRadius: "0rem 0rem 1rem 1rem", overflow: "auto" }}>
            <ClonosDataGrid
                handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                rows={documents}
                columns={columns}
                uniqueIdField={"docId"}
                totalCount={totalCount}
                pageLimit={pagination.limit}
                isDeleteMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE}) ? () => setShowConfirmationDailog(true) : false}
                isEditMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE}) ? () => handleEditDocument({ docId: selectedRows[0] }) : false}
                onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                isLoading={isLoading}
            />
        </Card>

        <Modal isOpen={isModal} closeModalMethod={setIsModal}>
            <div
                className={Styles.dl_document_view}
            >
                <header className={Styles.dl_document_view_c1}>
                    <div className={Styles.dl_DVC1_left}>
                        <div className={Styles.dl_DVC1_document_name}>
                            <span>{selectedDoc?.documentTitle}</span>
                        </div>
                        <div className={Styles.dl_DVC1_details}>
                            <div>
                                <span>Uploaded On:</span>
                                <span>{selectedDoc?.createdDate ? getFormatedDate(selectedDoc?.createdDate) : "NULL"}</span>
                            </div>
                            <div>
                                <span>Uploaded By:</span>
                                <span>{selectedDoc?.uploadedBy?.name ? selectedDoc?.uploadedBy?.name : "NULL"}</span>
                            </div>
                        </div>
                    </div>
                    <div className={Styles.dl_DVC1_right}>
                        <div>
                            <DownloadIcon onClick={() => handleDownloadDocument(selectedDoc?.docId)} />
                            <CloseIcon onClick={() => setIsModal(false)} />
                        </div>
                    </div>
                </header>
                <section className={Styles.dl_document_view_c2}>
                    <div className={Styles.dl_document_view_body}>
                        <img src={selectedDoc?.path ? selectedDoc?.path : No_image_available} alt='Document Image' loading='lazy' />
                    </div>
                </section>
            </div >
        </Modal >

        <ClonosConfirmationBox
            isOpen={showConfirmationDailog}
            confirmingMethod={() => {
                handleDeleteDocuments({ selectedRows: selectedRows });
            }}
            closeModalMethod={setShowConfirmationDailog}
            headerTitle="Delete Document."
            message={`Are you sure that you want to delete ${selectedRows?.length > 1 ? " these documents" : "this Document"}?`}
        />
    </>

    return <UnAuthorizedModal type="NOT_AUTHORIZED"/>
}

export default DocumentsList