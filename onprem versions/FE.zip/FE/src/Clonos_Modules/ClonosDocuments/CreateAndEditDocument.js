import Styles from "../../ModuleStyles/Documents/documents.module.css";
import { memo, useEffect, useState } from "react";
import {
} from "../../Api/Asset/assetApi";
import {
	checkUserHasPermission,
	commonPageState,
	getUser,
	globalHandleIsAllRequiredFieldAvailable,
	globalHandleLoadMoreData,
	handleShowErrorAndWarning,
	hasPermission,
} from "../../utils/clonosCommon";
import { useDispatch } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { Card } from "@mui/material";
import { DownloadingOutlined } from "@mui/icons-material";
import AppUrl from "../../utils/AppUrl";
import { doGetApiCall, doPostMultipartApiCall, doPutApiCall, doPutMultipartApiCall } from "../../utils/ClonosApi";
import useToggler from "../../CustomHooks/TogglerHook";
import { handleGetValuesOfMaintenanceTaskMethod } from "../../utils/ScheduleMaintenanceMethods/ScheduleMaintenanceMethods";
import ClonosInput from "../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosSelect from "../../components/CommonComponents/ClonosSelect/ClonosSelect";
import DynamicDropdown from "../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import FileUploader from "../../components/CommonComponents/FileUploader/FileUploader";
import { UnAuthorizedModal } from "../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { ClonosButton } from "../../components/CommonComponents/Button/Button";
import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_DOCUMENTS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS } from "../../Constants/Constant";
import useModuleNameProvider from "../../CustomHooks/ModuleNameProviderHook";

let primaryObject = {};
const CreateAndEditDocument = ({ mode = 'create' }) => {
	const dispatch = useDispatch();
	const fileTypes = [
		"doc",
		"docx",
		"pdf",
		"csv",
		"fbx",
		"png",
		"jpg",
		"cad",
		"dwg",
	];
	const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_DOCUMENTS)
	const [functionalAreaDropdown, setFunctionalAreaDropdown] = useState([]);
	const [documentTypesDropdown, setDocumentTypeDropdown] = useState([]);
	const [statusDropdown, setStatusDropdown] = useState([]);
	const [assetsDropdown, setAssetsDropdown] = useState([]);
	const [formData, setFormData] = useState({});
	const [changedData, setChangedData] = useState({});
	const Navigate = useNavigate();
	const Location = useLocation();
	const [lcLoadings, setLcLoadings] = useState({ createDocumentLoading: false, cancelLoading: false }); // This state will hold all the loading status of the an app.
	const { createDocumentLoading, cancelLoading } = lcLoadings;
	const [lcValues, setLcValues] = useState({});
	const { singleDocumentServerResponse, needToDeleteUploadedDocuments } = lcValues;
	const [loadingFlag, setLoadingFlag] = useState(false);

	const [isLocalLoading, setIsLocalLoading] = useToggler() // Custom Hook which returns boolean value (initial value : "false")
	const [cancelDocumentAlert, setCancelDocumentAlert] = useState(false);


	// Handler Area 
	const handleUploadDocument = (data) => {
		let isAvailable = globalHandleIsAllRequiredFieldAvailable({ primaryObject });
		if (!isAvailable) return;

		if (mode === "create") {
			createDocument({ dispatch, setFormData, Navigate, mode, data });
		} else {
			createDocument({ dispatch, setFormData, Navigate, mode, data, docId: singleDocumentServerResponse?.docId });
		}
	}

	const createDocument = ({ dispatch, setFormData, Navigate, mode, data, docId }) => {
		setLcLoadings(prev => {
			return { ...prev, ["createDocumentLoading"]: true }
		});
		const user = getUser();
		const payload = new FormData();
		if (data?.documentTitle)
			payload.append("documentTitle", data?.documentTitle);
		if (data?.documentNumber)
			payload.append("documentNumber", data?.documentNumber);
		if (data?.asset)
			payload.append("asset", JSON.stringify([data?.asset]));
		if (data?.status?.value || data?.approvalStatus?.value)
			payload.append("status", JSON.stringify([data?.status?.value || data?.approvalStatus?.value]));
		if (data?.documentType?.value)
			payload.append("documentType", JSON.stringify([data?.documentType?.value]));
		if (data?.revisionNumber)
			payload.append("revisionNumber", data?.revisionNumber)
		if (data?.file0?.length > 0) {
			payload.append("file0", data.file0?.[0]);
			payload.append("noOfFiles", "1");
			payload.append("uploadedBy", user?.userId)
		}
		let apiPromise = null;
		if (mode === 'edit') {
			apiPromise = doPutMultipartApiCall(`${AppUrl.editDocument}/${docId}`, payload);
		}
		else {
			apiPromise = doPostMultipartApiCall(AppUrl.createDocument, payload);
		};

		apiPromise.then((res) => {
			if (res.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
				if (mode === "edit") {
					handleShowErrorAndWarning({
						dispatch,
						showTime: 5000,
						message: "Document Edited Successfully",
						type: "success",
					});
				} else {
					handleShowErrorAndWarning({
						dispatch,
						showTime: 5000,
						message: "Document Created Successfully",
						type: "success",
					});
				}
			} else {
				handleShowErrorAndWarning({
					dispatch,
					showTime: 5000,
					message: "Something went wrong!",
					type: "error",
				});
			}
		}).finally(() => {
			setLcLoadings(prev => {
				return { ...prev, ["createDocumentLoading"]: false }
			});
			Navigate("/documents");
			setFormData({});
		});
	};

	const handleFileUpload = (props) => {
		const { uniqueKey, files, type, selectedOption, name } = props;
		if (files) {
			handlePrimaryObjectModifier({ uniqueKey, response: files });
		}
		else {
			handlePrimaryObjectModifier({ uniqueKey, response: null });
		};
		if (mode === "edit") {
			if (name === 'needToDeleteDocuments') {
				setLcValues(prev => {
					return { ...prev, ["singleDocumentServerResponse"]: { ...prev["singleDocumentServerResponse"], path: null }, ["needToDeleteUploadedDocuments"]: selectedOption }
				})
			} else {
				setFormData(prev => ({
					...prev,
					[uniqueKey]: files
				}))
			}
		}
		else {
			setFormData(prev => ({
				...prev,
				[uniqueKey]: files
			}))
		};
	};


	const handleGetValues = (props) => {
		const { name, selectedOption, updatedValue, uniqueKey, type } = props;

		if (type === "dynamicDropdown") {
			const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
			setFormData((prev) => {
				return { ...prev, [uniqueKey]: valueSetter ? selectedOption[0]?.id : null }
			})
		}
		else if (type === "select") {
			const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
			setFormData((prev) => {
				return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
			})
		}

		else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
			const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
			setFormData((prev) => {
				return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
			})
		}

		else if (mode === "edit") {
			// setChangedData((prev) => ({
			// 	...prev,
			// 	[name]: { name: selectedOption[0]?.name, id: selectedOption[0]?.id },
			// }))
		}
		else {
			setFormData((prev) => {
				return { ...prev, [uniqueKey]: updatedValue }
			});
		}

	};

	const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
		if (response === null || response === "" || response === false) {
			primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": false } }
			return false
		}
		else {
			primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": true } }
			return true
		}
	}

	const handleGetErrorActivatorInformation = (props) => {
		primaryObject = { ...primaryObject, [props.uniqueKey]: props };
	}

	const handleMoreData = (props) => {
		if (assetsDropdown?.currentPage === assetsDropdown?.totalPageCount) return;
		const optionalParams = { page: assetsDropdown?.currentPage + 1, limit: 15 };
		globalHandleLoadMoreData({ url: AppUrl.getAssetForDropdown, loadingFlag, setLoadingFlag, method: "get", optionalParams }).then((res) => {
			setAssetsDropdown((prev) => {
				let currentResponse = res?.data?.result;
				let updateState = { ...(currentResponse || {}), ["data"]: [...(prev?.data || []), ...(currentResponse?.data || [])] }
				let newSet = new Set();
				updateState.data = (updateState?.data || []).filter(element => {
					if (!newSet.has(element?.id)) {
						newSet.add(element?.id);
						return element
					}
				});
				return updateState
			})
		})
	};


	/**
	 * 'handleDeleteDocuments' function will use for delete the multiple or single documents.
	 * @param {Object} props - this props will cotainer the selectedRows array 
	 * @param {Array} props.selectedRows - Selected rows
	 */
	const handleDeleteDocuments = (props) => {
		if (props?.selectedRows?.length > 0) {
			doPutApiCall(AppUrl?.deleteMultipleDocuments, { ["docIds"]: (props?.selectedRows || []) }).then(res => {
				if (res.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
					handleShowErrorAndWarning({ type: 'success', message: `${props?.selectedRows?.length > 1 ? "Documents" : "Document"} has been deleted.`, showTime: 5000, dispatch });
				} else {
					handleShowErrorAndWarning({ type: 'error', message: `Something went wrong while deleting the ${props?.selectedRows?.length > 1 ? "Documents" : "Document"}!`, showTime: 5000, dispatch });
				};
			});
		};
	};

	useEffect(() => {
		setIsLocalLoading();
		Promise.all([
			doGetApiCall(AppUrl.getDocumentApprovalStatus),
			doGetApiCall(AppUrl.getDocumentFunctionArea),
			doGetApiCall(AppUrl.getDocumentType),
			doGetApiCall(AppUrl.getAssetForDropdown, commonPageState),
		])
			.then(res => {
				setStatusDropdown(res[0]?.data?.result || []);
				setFunctionalAreaDropdown(res[1]?.data?.result || []);
				setDocumentTypeDropdown(res[2]?.data?.result || []);
				setAssetsDropdown(res[3]?.data?.result || []);
			})
			.finally(setIsLocalLoading);

		return () => {
			setLcLoadings(prev => {
				return { ...prev, ["cancelLoading"]: false }
			});
		};
	}, []);

	useEffect(() => {
	}, [primaryObject]);


	useEffect(() => {
		if (mode === 'edit') {
			setLcValues({ ...lcValues, ["singleDocumentServerResponse"]: { ...Location?.state?.selectedDoc, ["path"]: Location?.state?.selectedDoc?.docId } || {} });
		}
		return () => {
			primaryObject = {};
		}
	}, [mode])




	if (checkUserHasPermission({moduleName,action:mode === "create" ? CLONOS_GLOBAL_ACTION_CREATE : mode === "edit" ? CLONOS_GLOBAL_ACTION_UPDATE:""})) {
		return <> 
			<Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: '1rem' }}>
				<section className={Styles.main_container}>
					<div className={Styles.fields_container}>
						<div className={Styles.documentsLeftContainer}>
							<ClonosInput
								type={"text"}
								uniqueKey={"documentTitle"}
								isLabel={true}
								label={"Document Name"}
								placeholder="Document Title"
								defaultValue={mode === "edit" ? singleDocumentServerResponse?.documentTitle : undefined}
								isMandatory={true}
								errorMessage={"Document title is required. Please fill."}
								handleGetValues={(value) => handleGetValues(value)}
								handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
							/>
							<ClonosInput
								type={"number"}
								isLabel={true}
								label={"Document Number"}
								placeholder="Document Number"
								uniqueKey="documentNumber"
								defaultValue={mode === "edit" ? singleDocumentServerResponse?.documentNumber : undefined}
								isMandatory={true}
								errorMessage={"Document number is required. Please fill."}
								handleGetValues={(value) => handleGetValues(value)}
								handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
							/>
							<ClonosInput
								type={"number"}
								isLabel={true}
								label={"Revision Number"}
								placeholder="Revision Number"
								uniqueKey="revisionNumber"
								defaultValue={mode === "edit" ? singleDocumentServerResponse?.revisionNumber : undefined}
								isMandatory={true}
								errorMessage={"Revision number is required. Please fill."}
								handleGetValues={(value) => handleGetValues(value)}
								handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
							/>
							<ClonosSelect
								type="select"
								placeholder="Select"
								label={"Document Type"}
								isLabel={true}
								uniqueKey="documentType"
								defaultValue={mode === "edit" ? singleDocumentServerResponse?.documentType?.name : undefined}
								isMandatory={true}
								options={documentTypesDropdown?.map((opt) => ({
									label: opt?.name,
									value: opt?.id,
									isNeeded: true,
								}))}
								errorMessage={"Document type is Required!."}
								icon={DownloadingOutlined}
								handleGetValues={handleGetValues}
								handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
							/>
							<DynamicDropdown
								label={"Asset"}
								isLabel={true}
								heading={"Select from Asset Library"}
								placeholder={"Search"}
								isSearchable={true}
								type="dynamicDropdown"
								isDynamicLoad={!loadingFlag}
								data={assetsDropdown?.data}
								isActivator={true}
								isMandatory={true}
								handleMoreData={handleMoreData}
								handleGetValues={handleGetValues}
								defaultValue={mode === "edit" ? [singleDocumentServerResponse?.asset] : undefined}
								uniqueKey="asset"
								handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
							/>
							<ClonosSelect
								type="select"
								placeholder="Select"
								label={"Status"}
								isLabel={true}
								uniqueKey="status"
								position="top"
								defaultValue={mode === "edit" ? singleDocumentServerResponse?.approvalStatus?.name : undefined}
								isMandatory={true}
								options={statusDropdown?.map((opt) => ({
									label: opt?.name,
									value: opt?.id,
									isNeeded: true,
								}))}
								errorMessage={"Status is Required!."}
								icon={DownloadingOutlined}
								handleGetValues={handleGetValues}
								handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
							/>
						</div>
						<div className={Styles.documentsRightContainer}>
							<FileUploader
								label={"Documents"}
								uniqueKey="file0"
								typeOfRecord={"Images"}
								name={"file0"}
								title="file0"
								isMandatory={true}
								limit={1}
								fileSizeInMB={10}
								acceptableFileTypes={[".jpg", ".jpeg", ".png", ".pdf", ".doc", ".xls", ".ppt"]}
								defaultValue={mode === "edit" ? singleDocumentServerResponse?.path ? [{ docId: singleDocumentServerResponse?.docId, name: singleDocumentServerResponse?.originalName }] : [] : undefined}
								handleGetSelectedData={handleFileUpload}
								handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
							/>
						</div>
					</div>

					<footer className={Styles.buttonsContainer}>
						<ClonosButton
							loading={cancelLoading}
							variant="outlined"
							onClick={() => {
								setCancelDocumentAlert(true);
							}}
						>
							Cancel
						</ClonosButton>
						<ClonosButton
							loading={createDocumentLoading}
							variant="filled"
							onClick={() => handleUploadDocument(formData)}
						>
							{mode === "edit" ? "Save" : "Submit"}
						</ClonosButton>
					</footer>
				</section>
			</Card>
			<ClonosConfirmationBox
				isOpen={cancelDocumentAlert}
				confirmingMethod={() => {
					setCancelDocumentAlert(false)
					setFormData({});
					Navigate(-1);
				}}
				closeModalMethod={setCancelDocumentAlert}
				headerTitle="Document Creation."
				message="Do you confirm that you want to cancel the document creation?"
			/>
		</>
	};
	return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
};

export default memo(CreateAndEditDocument);
