import { useState } from "react"
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import ClonosTextarea from "../../../components/CommonComponents/ClonosTextarea/ClonosTextarea"
import Modal from "../../../components/CommonComponents/Modal/Modal"
import Styles from "./add-comment-to-revise.module.css"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook"
export const AddCommentToRevise = ({isOpen,closeMethod,getComment}) => {
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false})

    const [comment,setComment] = useState("");
    const handleGetValues = (props) => {
        const {uniqueKey,updatedValue} = props;
        handlePrimaryObjectModifier({uniqueKey,response:updatedValue});
        setComment(updatedValue);
    }

    const handleSendForRevision = () => {
        if(!handleSubmit()) return 
        getComment(comment)
    }



    return <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
        <div className={Styles.container}>
            <div className={Styles.header}>
                <h4>Report Revision</h4>
                <CloseIcon onClick={() => closeMethod()}/>
            </div>
            <div className={Styles.section}>
                {/* <label>Reason <sup>*</sup></label> */}
                <ClonosTextarea 
                    isLabel={true}
                    label={"Reason"}
                    uniqueKey={"comment"}
                    isMandatory={true}
                    handleGetValues={handleGetValues}
                    errorMessage={"Please add a comment."}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                ></ClonosTextarea>
            </div>
            <div className={Styles.footer}>
                <div className={Styles.btn_wrapper}>
                    <ClonosButton onClick={closeMethod}>Cancel</ClonosButton>
                    <ClonosButton variant={"filled"} onClick={handleSendForRevision}>Send for Revision</ClonosButton>
                </div>
            </div>
        </div>
    </Modal>
}