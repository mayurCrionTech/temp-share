import { useEffect, useState } from "react"
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput"
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect"
import DynamicDropdown from "../../../components/CommonComponents/DynamicDropdown/DynamicDropdown"
import Modal from "../../../components/CommonComponents/Modal/Modal"
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook"
import Styles from './generate-report.module.css'
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { handleGenerateReport, handleGetReportModuleBaseData, handleGetReportsFormats, handleGetReportsModules, handleGetReportValues } from "./generate-report-managers"
import { setSerialNumber } from "../../../utils/clonosCommon"
import { useDispatch } from "react-redux"
import ClonosDocumentViewer from "../../../components/CommonComponents/document-viewer/ClonosDocumentViewer"
import useToggler from "../../../CustomHooks/TogglerHook"
import { doGetApiCall } from "../../../utils/ClonosApi"


/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/
export const GenerateReportModal = ({ isOpen, closeMethod, moduleToGenerateReport }) => {
    const dispatch = useDispatch();
    const [formData, setFormData] = useState({});
    const [moduleBaseData, setModuleBaseData] = useState({});
    const [searchedData,setSearchedData] = useState({});
    const [pagination, setPagination] = useState({ page: 1, limit: 15 });
    const [showReport, setShowReport] = useToggler();
    const [lcModuleBaseData,setLcModuleBaseData] = useState({})
    const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
    const [staticDropdowns, setStaticDropdowns] = useState({ modules: [], formats: [] });
    const [loadings, setLoadings] = useState({
        generateReportLoading: false
    })
    const [generatedReport, setGeneratedReport] = useState({})
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "assetSpare" })
     const [loadingDropdowns, setLoadingDropdowns] = useState({});
   const [staticDropdownData,setStaticDropdownData]=useState({})

    const fetchStaticDropdownByCode = async (code) => {
  if (staticDropdownData[code] || loadingDropdowns[code]) return;

  setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

  try {
    const res = await doGetApiCall({url:`dropdowns/${code}`});
       
    setStaticDropdownData(prev => ({
      ...prev,
      [code]: res?.data?.result?.options
    }));
  } finally {
    setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
  }
};

    const handleSearchModuleEntity = (props) => {
        if (moduleToGenerateReport || formData?.moduleName) {
            const { uniqueKey, input } = props;
            if(input?.length) {
                handleGetReportModuleBaseData({ setterMethod: setSearchedData, moduleName: moduleToGenerateReport || formData?.moduleName, filterPayload: { entityName: input } });
            } else {
                setSearchedData({})
            }
        }
    }

    const handleMoreData = () => {
        if (pagination?.page < moduleBaseData?.totalPageCount) {
            setPagination((prev) => {
                handleGetReportModuleBaseData({ setterMethod: setModuleBaseData, moduleName: moduleToGenerateReport|| formData?.moduleName, filterPayload: { page: prev?.page + 1, limit: 15 } });
                return { ...prev, page: prev?.page + 1 }
            })
        }
    }

    useEffect(() => {
        handleGetReportsModules({ setterMethod: (val) => setStaticDropdowns(prev => ({ ...prev, modules: val })) });
        handleGetReportsFormats({ setterMethod: (val) => setStaticDropdowns(prev => ({ ...prev, formats: val })) });
    }, []);

    useEffect(() => {
        if (isOpen && moduleToGenerateReport || formData?.moduleName) {
            handleGetReportModuleBaseData({ setterMethod: setModuleBaseData,setLcModuleBaseData, moduleName: moduleToGenerateReport || formData?.moduleName, pagination });
        }

        return () => {
            setModuleBaseData({});
            setSearchedData({});
        }
    }, [formData?.moduleName])

    return (
        <>
            <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
                <div className={Styles.container}>
                    <div className={Styles.header}>
                        <h4>Generate Report</h4>
                        <CloseIcon onClick={() => closeMethod(false)} />
                    </div>
                    <div className={Styles.section}>
                        {!moduleToGenerateReport ? <ClonosSelect
                            isLabel={true}
                            type={"select"}
                            label={"Module"}
                            isMandatory={true}
                            areaLabel="Module"
                            placeholder="Select"
                            uniqueKey={"moduleName"}
                            errorMessage={"Please select module."}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            options={staticDropdowns?.modules?.map((module) => ({ label: module, value: module, isNeeded: true })) || []}
                            handleGetValues={(propsVal) => handleGetReportValues({ propsVal, handlePrimaryObjectModifier, setFormData })}
                        /> : <></>}
                        <DynamicDropdown
                            tabIndex={9}
                            isLabel={true}
                            isCheckbox={false}
                            isActivator={true}
                            isMandatory={true}
                            isSearchable={true}
                            isDynamicLoad={pagination?.page < moduleBaseData?.totalPageCount}
                            placeholder="Select"
                            uniqueKey="moduleEntity"
                            areaLabel="Module Entity"
                            label={moduleToGenerateReport || formData?.moduleName || "Name"}
                            title={moduleToGenerateReport || formData?.moduleName || "Name"}
                            handleMoreData={handleMoreData}
                            populatedFields={["checklistNumber"]}
                            heading={moduleToGenerateReport || formData?.moduleName || "Module"}
                            errorMessage={`Please select ${moduleToGenerateReport || formData?.moduleName || "Name"}.`}
                            handleDynamicSearch={handleSearchModuleEntity}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            handleGetValues={(propsVal) => handleGetReportValues({ propsVal, handlePrimaryObjectModifier, setFormData })}
                            data={searchedData?.currentPage ? searchedData?.data : moduleBaseData?.data}
                        />
                        <div className={Styles.dates_wrapper}>
                            <ClonosInput
                                isLabel={true}
                                isMandatory={true}
                                type="datetime-local"
                                // placeholder="Select"
                                isMinimum={false}
                                label="Start Date & Time"
                                areaLabel="Start Date & Time"
                                uniqueKey={"startDateAndTime"}
                                errorMessage={"Please provide start date & time."}
                                // min={formData?.moduleEntity?.startDateAndTime?.split(".")?.[0]}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                handleGetValues={(propsVal) => handleGetReportValues({ propsVal, handlePrimaryObjectModifier, setFormData })}
                            />
                            <ClonosInput
                                isLabel={true}
                                isMandatory={true}
                                type="datetime-local"
                                disabled={!formData?.startDateAndTime}
                                label="End Date & Time"
                                // placeholder="Select"
                                areaLabel="End Date & Time"
                                uniqueKey={"endDateAndTime"}
                                errorMessage={"Please provide end date & time."}
                                min={formData?.startDateAndTime}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                handleGetValues={(propsVal) => handleGetReportValues({ propsVal, handlePrimaryObjectModifier, setFormData })}
                            />
                        </div>
                        <div className={Styles.dates_wrapper}>
                            <ClonosSelect
                                isLabel={true}
                                type={"select"}
                                label={"Format"}
                                areaLabel="Format"
                                isMandatory={true}
                                placeholder="Select"
                                uniqueKey={"format"}
                                errorMessage={"Please select format."}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                // options={staticDropdowns?.formats?.map((format) => ({ label: format, value: format, isNeeded: true })) || []}
                                //  options={[{ label: "Pdf", value: "pdf", isNeeded: true },{ label: "Excel", value: "excel", isNeeded: true }]}
                                // options={
                                //     formData?.moduleName === "workorders"
                                //     ? [{ label: "Pdf", value: "pdf", isNeeded: true }]
                                //     : [
                                //         { label: "Pdf", value: "pdf", isNeeded: true },
                                //         { label: "Excel", value: "excel", isNeeded: true }
                                //         ]
                                // }
                                options={
                                    staticDropdownData?.format
                                        ?.filter((opt) =>
                                            formData?.moduleName === "Workorders"
                                                ? opt?.value?.toLowerCase() === "pdf"
                                                : ["pdf", "excel"].includes(opt?.value?.toLowerCase())
                                        )
                                        ?.map((opt) => ({
                                            label: opt?.value,
                                            value: opt?._id,
                                            isNeeded: true
                                        }))
                                }
                                 //options={staticDropdownData?.format?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))}
                                onOpen={() => fetchStaticDropdownByCode("format")}
                                handleGetValues={(propsVal) => handleGetReportValues({ propsVal, handlePrimaryObjectModifier, setFormData })}
                            />
                            <ClonosSelect
                                isLabel={true}
                                type={"select"}
                                label={"Report Type"}
                                areaLabel="Report Type"
                                // isMandatory={true}
                                isMandatory={formData?.format === "Excel" ? false : true }
                                placeholder="Select"
                                uniqueKey={"reportType"}
                                defaultValue={formData?.format== "Excel" ? "Select" : null}
                                errorMessage={"Please select report type."}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                // options={[{ label: "Portrait", value: "reportType", isNeeded: true },{ label: "Landscape", value: "reportType", isNeeded: true }]}
                                // options={
                                //     formData?.moduleName ==="workorders"? 
                                //     [{ label: "Portrait", value: "reportType", isNeeded: true }]
                                //     :
                                //     [
                                //       { label: "Portrait", value: "reportType", isNeeded: true },{ label: "Landscape", value: "reportType", isNeeded: true }
                                //     ]
                                // }
                                  options={
                                     staticDropdownData?.reportType
                                        ?.filter((opt) =>
                                            formData?.moduleName === "Workorders"
                                                ? opt?.value?.toLowerCase() === "portrait"
                                                : ["portrait", "landscape"].includes(opt?.value?.toLowerCase())
                                        )
                                        ?.map((opt) => ({
                                            label: opt?.value,
                                            value: opt?._id,
                                            isNeeded: true
                                        }))
                                }
                                handleGetValues={(propsVal) => handleGetReportValues({ propsVal, handlePrimaryObjectModifier, setFormData })}
                                  onOpen={() => fetchStaticDropdownByCode("reportType")}
                                disabled={formData?.format== "Excel" ? true: false}
                                
                            />
                        </div>
                    </div>
                    <div className={Styles.footer}>
                        <div>
                            <ClonosButton onClick={() => setShowConfirmationDialog(true)}>Cancel</ClonosButton>
                            <ClonosButton
                                loading={loadings.generateReportLoading}
                                variant="filled"
                                onClick={() => handleGenerateReport({ dispatch, handleSubmit, formData: { ...formData, moduleName: moduleToGenerateReport || formData?.moduleName }, setIsLoading: () => setLoadings(prev => ({ ...prev, generateReportLoading: !prev?.generateReportLoading })), closeModalMethod: closeMethod, setGeneratedReport, setShowReport })}
                            >
                                Generate Report
                            </ClonosButton>
                        </div>
                    </div>
                </div>
            </Modal>
            <ClonosConfirmationBox
                isOpen={showConfirmationDialog}
                closeModalMethod={setShowConfirmationDialog}
                confirmingMethod={() => {
                    closeMethod(false);
                    setShowConfirmationDialog(false);
                }}
                rejectingMethod={() => setShowConfirmationDialog(false)}
                message={"Are you sure to cancel ?"}
                headerTitle={"Cancel"}
            />
            {showReport ? <ClonosDocumentViewer file={generatedReport} isOpen={showReport} closeMethod={setShowReport} /> : <></>}
        </>
    )


}