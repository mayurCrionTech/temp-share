import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_BAD_REQUEST_ERROR, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant"
import AppUrl from "../../../utils/AppUrl"
import { doGetApiCall, doPostApiCall } from "../../../utils/ClonosApi"
import { handleServerDateInConfiguredTimeZone, handleShowErrorAndWarning } from "../../../utils/clonosCommon";

export const handleGetReportValues = ({ propsVal, handlePrimaryObjectModifier, setFormData }) => {
    const { type, uniqueKey, updatedValue, selectedOption } = propsVal;
    if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
        setFormData((prev) => {
            return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
        })
    } else if (type === "select") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
        setFormData((prev) => {
            return { ...prev, [uniqueKey]: valueSetter ? updatedValue?.label : null }
        })
    } else if (type === "dynamicDropdown") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
        setFormData((prev) => {
            return { ...prev, [uniqueKey]: valueSetter ? { ...selectedOption[0], name: selectedOption[0]?.name, id: selectedOption[0]._id } : null }
        })
    }
}

export const handleGetReportsModules = ({ setterMethod, setIsLoading }) => {
    setIsLoading && setIsLoading()
    doGetApiCall({ url: AppUrl.getReportsModules })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                setterMethod(res?.data?.result)
            }
        })
        .catch(err => console.error(err))
        .finally(() => setIsLoading && setIsLoading())
}

export const handleGetReportsFormats = ({ setterMethod, setIsLoading }) => {
    setIsLoading && setIsLoading()
    doGetApiCall({ url: AppUrl.getReportsFormats })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                setterMethod(res?.data?.result)
            }
        })
        .catch(err => console.error(err))
        .finally(() => setIsLoading && setIsLoading())
}

export const handleGetReportModuleBaseData = ({ setterMethod,setLcModuleBaseData, setIsLoading, moduleName, pagination,filterPayload }) => {
    setIsLoading && setIsLoading();
    const url = "/reports/module-data"
    doGetApiCall({ url, params: { page: pagination?.page, limit: pagination?.limit, module: moduleName,...filterPayload } })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                setterMethod((prev) => {
                    if(filterPayload?.entityName) {
                        return res?.data?.result
                    } else {
                        const prevData = prev?.data?.length ? [...prev?.data] : [];
                        if (prevData?.length) {
                            const uniqueEntitiesObject = prevData.reduce((acc, entity) => {
                                if (!acc[entity?.name]) {
                                    acc[entity?.name] = entity;
                                }
                                return acc;
                            }, {});

                            const newEntities = res?.data?.result?.data?.filter(entity => !uniqueEntitiesObject[entity?.name]);

                            return {
                                ...res?.data?.result,
                                data: [...prevData, ...newEntities]
                            };
                        } else {
                            return res?.data?.result;
                        }
                    }
                })
            }
        })
        .catch(err => console.error(err))
        .finally(() => setIsLoading && setIsLoading())
}


// export const handleGenerateReport = ({ dispatch,handleSubmit, formData, setIsLoading, closeModalMethod,setGeneratedReport,setShowReport }) => {
//     if (!handleSubmit()) {
//         return
//     }
//     setIsLoading && setIsLoading();
//     const requestPayload = {
//         moduleName: formData?.moduleName.toLowerCase(),
//         moduleEntityId: formData?.moduleEntity?.id,
//         startDateAndTime: formData?.startDateAndTime ? handleServerDateInConfiguredTimeZone({dateString:formData?.startDateAndTime}) :"",
//         endDateAndTime:  formData?.endDateAndTime ? handleServerDateInConfiguredTimeZone({dateString:formData?.endDateAndTime}) :"",
//         format: formData?.format,
//         type:formData?.reportType.toLowerCase()
//     };
//     doPostApiCall({ url: AppUrl.generateReport, payload: requestPayload })
//         .then((res) => {
//             if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
//                 // window.open(res?.data?.result?.url, "_blank");
//                 const url = res?.data?.result?.url;
//                 const filename = url?.substring(url?.lastIndexOf('/') + 1, url?.indexOf('?'));
//                 setGeneratedReport({url,contentType:"application/pdf",name:filename});
//                 setShowReport && setShowReport();
//                 // closeModalMethod && closeModalMethod();
//             } else {
//                 handleShowErrorAndWarning({dispatch,message:"No Reports Found!",type:"error",showTime:"5000"})
//             }
//         })
//         .catch(err => {
//             console.error(err)
//         })
//         .finally(() => setIsLoading && setIsLoading())
// }


export const handleGenerateReport = ({ dispatch, handleSubmit, formData, setIsLoading, closeModalMethod, setGeneratedReport, setShowReport }) => {
    if (!handleSubmit()) {
        return
    }
   
    setIsLoading && setIsLoading();
   
    const requestPayload = {
        moduleName: formData?.moduleName.toLowerCase(),
        moduleEntityId: formData?.moduleEntity?.id,
        startDateAndTime: formData?.startDateAndTime ? handleServerDateInConfiguredTimeZone({dateString:formData?.startDateAndTime}) :"",
        endDateAndTime:  formData?.endDateAndTime ? handleServerDateInConfiguredTimeZone({dateString:formData?.endDateAndTime}) :"",
        format: formData?.format,
        type: formData?.format === "Excel" ? "Landscape" : formData?.reportType.toLowerCase()
    };
    
    doPostApiCall({ url: AppUrl.generateReport, payload: requestPayload })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                const url = res?.data?.result?.url;
                const filename = url?.substring(url?.lastIndexOf('/') + 1, url?.indexOf('?') !== -1 ? url?.indexOf('?') : url.length);
                
                // Determine content type based on format
                let contentType;
                let fileExtension;
                
                if (formData?.format === 'Excel') {
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    fileExtension = "xlsx";
                } else {
                    contentType = "application/pdf";
                    fileExtension = "pdf";
                }

                if (formData?.format === 'Excel') {
                    // For Excel -> force download only
                    const link = document.createElement("a");
                    link.href = url;
                    link.setAttribute("download", filename);
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                } else {
                    // For PDF -> open viewer
                    setGeneratedReport({
                        url,
                        contentType,
                        name: filename,
                        extension: fileExtension,
                        format: formData?.format
                    });
                    setShowReport && setShowReport();
                }

                
                // setGeneratedReport({
                //     url,
                //     contentType,
                //     name: filename,
                //     extension: fileExtension,
                //     format: formData?.format
                // });
                
                // setShowReport && setShowReport();
            } else {
                handleShowErrorAndWarning({
                    dispatch,
                    message: "No Reports Found!",
                    type: "error",
                    showTime: "5000"
                })
            }
        })
        .catch(err => {
            console.error(err)
            handleShowErrorAndWarning({
                dispatch,
                message: "Error generating report!",
                type: "error",
                showTime: "5000"
            })
        })
        .finally(() => setIsLoading && setIsLoading())
}