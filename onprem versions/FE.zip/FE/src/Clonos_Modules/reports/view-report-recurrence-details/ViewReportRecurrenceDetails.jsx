import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import Modal from "../../../components/CommonComponents/Modal/Modal"
import { getFormatAMPM, getFormatedDate, getFormattedTime, modifyString } from "../../../utils/clonosCommon"
import Styles from './view-report-recurrence-details.module.css'

export const ViewRecurrenceDetails = ({isOpen,closeMethod,data}) => {
    const getFormattedDateAndTime = (dateStr) => {
        if(!dateStr) return "-"
        const date = getFormatedDate(dateStr);
        const time = getFormatAMPM(dateStr);
        return date && time ? `${date} ${time}` : "-"
    }

    return <Modal isOpen={isOpen} closeModalMethod={() => closeMethod()}>
        <div className={Styles.container}>
             <div className={Styles.header}>
                <h4>Recurrence</h4>
                <CloseIcon onClick={() => closeMethod()}/>
             </div>
             <div className={Styles.section}>
                <div className={Styles.section_left}>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>Start Date & Time</h4>
                        <p className={Styles.field_val_}>{getFormattedDateAndTime(data?.startDateAndTime)}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>Recurrence</h4>
                        <p className={Styles.field_val_}>{`Every ${data?.scheduledReportDetails?.frequency} ${data?.scheduledReportDetails?.timePeriod}`}</p>
                    </div>
                    {/* {
                        data?.assignees?.map((user) => {
                            return <div className={Styles.field_wrapper}>
                            <h4 className={Styles.field_name}>User Name</h4>
                            <p className={Styles.field_val_}>{user}</p>
                        </div>
                        })
                    } */}
                    
                <div className={Styles.field_wrapper}>
                    <h4 className={Styles.field_name}>User Name</h4>
                    <p className={Styles.field_val_}>
                        {data?.assignees?.join(", ")}
                    </p>
                </div>

                </div>
                <div className={Styles.section_right}>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>End Date & Time</h4>
                        <p className={Styles.field_val_}>{getFormattedDateAndTime(data?.endDateAndTime)}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>Repeat On</h4>
                        <p className={Styles.field_val_}>{data?.scheduledReportDetails?.recurrOn ? modifyString(modifyString(data?.scheduledReportDetails?.recurrOn,"spacecase"),"capitalize") : "-"}</p>
                    </div>
                </div>
             </div>
        </div>
    </Modal>
}
