import { useLocation, useNavigate } from "react-router-dom";
import Subbar from "../../../components/CommonComponents/ClonosSubbar/Subbar"
import { CLONOS_ENCRYPT_PASSWORD_SECRET_KEY, CLONOS_GLOBAL_ACTION_DOWNLOAD, CLONOS_GLOBAL_COLOUR_FADE_WHITE, CLONOS_GLOBAL_MODULE_REPORTS } from "../../../Constants/Constant";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import { checkUserHasPermission, decryptToken, getFormatedDate, handleShowErrorAndWarning } from "../../../utils/clonosCommon"
import Styles from "./view-report-details.module.css"
import { useEffect, useState } from "react";
import  CommentIcon  from "../../../assets/Clonos Common Indicators/Icon_Components/CommentICon";
import DownloadIcon from "../../../assets/Clonos Common Indicators/Icon_Components/DownloadIcon";
import { Card } from "@mui/material";
import useToggler from "../../../CustomHooks/TogglerHook";
import { ImagePreviewModal } from "../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal";
import { QuickUserPreview } from "../../../components/CommonComponents/QuickUserPreview/QuickUserPreview";
import { ViewRecurrenceDetails } from "../view-report-recurrence-details/ViewReportRecurrenceDetails";
import { handleChangeReportStatus, handleGetReportHistory, handleGetSingleReportDetails, handleRegenerateReport } from "../managers/report-manager";
import REPORT_FILE_ICON from "../../../resources/images/file-green-icon.png"
import ClonosDocumentViewer from "../../../components/CommonComponents/document-viewer/ClonosDocumentViewer";
import { NotesPreview } from "./NotesPreview";
import { handleGetMultipleFiles } from "../../../utils/common-managers";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import {ClonosButton} from "../../../components/CommonComponents/Button/Button"
import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData";
import { AddCommentToRevise } from "../add-comment-to-revise/AddCommentToRevise";
import { ReportComments } from "../report-comments/ReportComments";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { useDispatch } from "react-redux";

/*
    date            qid / cr#         comments
    07-Apr-2026     -#160             Broken Access Control - Permission Restriction FrontEnd
    */
const ViewReportRecurrenceDetails = () => {
  const dispatch = useDispatch();
  const [reportHistory,setReportHistory] = useState({});
  const [reportDetails,setReportDetails] = useState({});
  const [images,setImages] = useState([]);
  const Navigate = useNavigate();  
  const location = useLocation();
  const [isStatusUpdated,setIsStatusUpdated] = useState();
  const [isLoading,setIsLoading] = useToggler();
  //#160 
    const [isUnauthorized, setIsUnauthorized] = useState(false);
  const [lcStates,setLcStates] = useState({
    showImagePreviewModal:false,
    isDescriptionExpanded:false,
    showApproverModal:false,
    showRecurrenceDetails:false,
    reportToPreview:null,
    showNotePreview:false,
    showReviseCommentBox:false,
    showViewCommentsModal:false,
    reviseLoader:false,
    historyLoader:false,
    approveLoader:false,
    fetchImagesLoader:false,
  })
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_REPORTS);

  const handleImagesPreview = () => {
    reportDetails?.images?.length && handleGetMultipleFiles({fileIds:reportDetails?.images,setterMethod:setImages,setIsLoading:() => setLcStates(prev => ({...prev,fetchImagesLoader:!prev.fetchImagesLoader}))});
    setLcStates(prev => ({...prev,showImagePreviewModal:!prev.showImagePreviewModal}))
  }

  const regenerateReport = () => {
    handleRegenerateReport({dispatch,reportId:location?.state?.reportId,setIsLoading,next:() => {
      handleShowErrorAndWarning({dispatch,type:"success",message:"Report regenerated successfully.",showTime:"5000"})
      handleGetSingleReportDetails({setterMethod:setReportDetails,setIsLoading,reportId:location?.state?.reportId})
    }})
  }

  const handleApprove = ({payload,setIsLoading}) => {
    handleChangeReportStatus({
      reportId:reportDetails?.id,
      payload,
      setIsLoading,
      next:() => {
        // handleGetSingleReportDetails({setterMethod:setReportDetails,setIsLoading,reportId:reportDetails?.id});
        handleShowErrorAndWarning({dispatch,type:"success",message:"Report approved successfully.",showTime:"5000"})
        setIsStatusUpdated(true);
      }
    })
  }


  const handleSendForRevision = (comment) => {
    handleChangeReportStatus({
      reportId:reportDetails?.id,
      payload:{status:"revised",comment},
      setIsLoading,
      next:() => {
        setLcStates(prev => ({...prev,showReviseCommentBox:false}))
        handleShowErrorAndWarning({dispatch,type:"success",message:"Report revised successfully.",showTime:"5000"})
        // handleGetSingleReportDetails({setterMethod:setReportDetails,setIsLoading,reportId:reportDetails?.id})
        setIsStatusUpdated(true);
      }
    })
  }

  
  useEffect(() => {
    //#160 
       if (!location?.state) {
        setIsUnauthorized(true);
        return;
     }
    handleGetSingleReportDetails({setterMethod:setReportDetails,setIsLoading,reportId:location?.state?.reportId})
    handleGetReportHistory({setterMethod:setReportHistory,setIsLoading:setLcStates(prev => ({...prev,historyLoader:!prev.historyLoader})),reportId:location?.state?.reportId})
  },[])

  useEffect(() => {
         if (!location?.state) {
        setIsUnauthorized(true);
        return;
     }
    if(isStatusUpdated){
      handleGetSingleReportDetails({setterMethod:setReportDetails,setIsLoading,reportId:location?.state?.reportId})
      handleGetReportHistory({setterMethod:setReportHistory,setIsLoading:setLcStates(prev => ({...prev,historyLoader:!prev.historyLoader})),reportId:location?.state?.reportId})
    }
  },[isStatusUpdated])
//#160 
  if (isUnauthorized) {
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
    }


    if(checkUserHasPermission({moduleName:"reports",action:"read"}))
    return (
      <>
        <Subbar
          isDownload={checkUserHasPermission({
            moduleName,
            action: CLONOS_GLOBAL_ACTION_DOWNLOAD,
          })}
          //   isEditMethod={() => Navigate("/edit-user", { state: { id: userDetails?.id } })}
          isHollow={true}
          isStatus={true}
          subbarData={{ status: reportDetails?.status }}
          staticElements={[
            {
              key: "Last Updated On :",
              value: reportDetails?.lastUpdatedOn
                ? reportDetails?.lastUpdatedOn
                : "-",
            },
            {
              key: "Last Updated By :",
              value: reportDetails?.lastUpdatedBy || "-",
            },
          ]}
          htmlElements={[
            <CommentIcon
              onClick={() =>
                setLcStates((prev) => ({
                  ...prev,
                  showViewCommentsModal: true,
                }))
              }
              tooltipTitle="Comments"
            />,
          ]}
        />
        <Card
          style={{
            flex: 1,
            margin: "1rem",
            borderRadius: "1rem",
            background: CLONOS_GLOBAL_COLOUR_FADE_WHITE,
            overflowY: "scroll",
          }}
        >
          {isLoading ? (
            <div className="center_wrapper">
              <ClonosSpinner />
            </div>
          ) : (
            <>
              <div className={Styles.v_report_title}>
                <h4>{reportDetails?.fileDetails?.name}</h4>
                <div className={Styles.btn_wrapper}>
                  {reportDetails?.status === "revised" &&
                    !checkUserHasPermission({
                      moduleName: "reports",
                      action: "regenerateReport",
                    }) ? (
                      <ClonosButton
                        onClick={regenerateReport}
                        isDisabled={reportDetails?.status !== "revised"}
                      >
                        Regenerate Report
                      </ClonosButton>
                    ) : <></>}
                  {reportDetails?.status === "pendingForApproval" &&
                    checkUserHasPermission({
                      moduleName: "reports",
                      action: "revise",
                    }) && (
                      <ClonosButton
                        isDisabled={reportDetails?.status === "revised"}
                        onClick={() =>
                          setLcStates((prev) => ({
                            ...prev,
                            showReviseCommentBox: true,
                          }))
                        }
                      >
                        Revise
                      </ClonosButton>
                    )}
                  {reportDetails?.status === "pendingForApproval" &&
                    checkUserHasPermission({
                      moduleName: "reports",
                      action: "approve",
                    }) && (
                      <ClonosButton
                        onClick={() =>
                          handleApprove({
                            payload: { status: "completed" },
                            setIsLoading: () =>
                              setLcStates((prev) => ({
                                ...prev,
                                approveLoader: !prev.approveLoader,
                              })),
                          })
                        }
                        variant="filled"
                      >
                        Approve
                      </ClonosButton>
                    )}
                </div>
              </div>
              <div className={Styles.v_report_details}>
                <div className={Styles.v_report_gen_details}>
                  <div className={Styles.gen_details_left}>
                    <div className={Styles.field_wrapper}>
                      <h4>Document Number</h4>
                      <p>{reportDetails?.documentNumber || "-"}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Name</h4>
                      <p>{reportDetails?.name || "-"}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      {/* <h4>Checklist Number</h4> */}
                       <h4>Log Number</h4>
                      <p>{reportDetails?.logNumber || "-"}</p>
                      {/* <p>{reportDetails?.moduleEntityNumber || "-"}</p> */}
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Description</h4>
                      {
                        reportDetails?.description?.length > 100 ? <p>
                        {reportDetails?.description
                          ? lcStates.isDescriptionExpanded
                            ? reportDetails?.description
                            : `${reportDetails?.description?.slice(0, 100)}...`
                          : "-"}
                        <span
                          onClick={() =>
                            setLcStates((prev) => ({
                              ...prev,
                              isDescriptionExpanded:
                                !prev.isDescriptionExpanded,
                            }))
                          }
                          className={Styles.read_more_span}
                        >{` Read ${
                          lcStates.isDescriptionExpanded ? "Less" : "More"
                        }`}</span>
                      </p> : <p>{reportDetails?.description}</p>
                      }
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Department</h4>
                      <p>
                        {reportDetails?.departments?.length
                          ? reportDetails?.departments?.join(",")
                          : "-"}
                      </p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Team</h4>
                      <p>
                        {reportDetails?.teams?.length
                          ? reportDetails?.teams?.join(",")
                          : "-"}
                      </p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Assigned User</h4>
                      <p>
                        {reportDetails?.assignees?.length
                          ? reportDetails?.assignees?.join(", ")
                          : "-"}
                      </p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Scheduled User</h4>
                      <p>{reportDetails?.scheduler || "-"}</p>
                    </div>
                  </div>
                  <div className={Styles.gen_details_right}>
                    <div className={Styles.field_wrapper}>
                      <h4>Frequency</h4>
                      <p>{reportDetails?.frequency || ""}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Asset</h4>
                      <p>{reportDetails?.asset || "-"}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Scheduled Time</h4>
                      <p>{reportDetails?.scheduledTime || "-"}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Created On</h4>
                      <p>{reportDetails?.createdOn || "-"}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Last Updated On</h4>
                      <p>{reportDetails?.lastUpdatedOn || "-"}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Recurrence</h4>
                      <p
                        className={"ele_link"}
                        onClick={() =>
                          setLcStates((prev) => ({
                            ...prev,
                            showRecurrenceDetails: true,
                          }))
                        }
                      >
                        {reportDetails?.isRecurrence ? "Yes" : "No"}
                      </p>
                    </div>
                    <div className={Styles.field_wrapper}>
                      <h4>Approver</h4>
                      <p
                        className={"ele_link"}
                        onClick={() =>
                          setLcStates((prev) => ({
                            ...prev,
                            showApproverModal: true,
                          }))
                        }
                      >
                        {reportDetails?.approver?.name || "-"}
                      </p>
                    </div>
                  </div>
                </div>
                <div className={Styles.v_report_media}>
                  <div>
                    {images?.length ? <span
                      onClick={handleImagesPreview}
                      style={{ cursor: "pointer" }}
                    >
                      View Image
                    </span> : <></>}
                    {reportDetails?.note?.length > 0 && <span
                      style={{ cursor: "pointer" }}
                      onClick={() =>
                        setLcStates((prev) => ({
                          ...prev,
                          showNotePreview: !prev.showNotePreview,
                        }))
                      }
                    >
                      View Notes
                    </span>}
                  </div>
                </div>
                {reportDetails?.status === "pendingForApproval" ||
                reportDetails?.status === "completed" ? (
                  <div className={Styles.v_r_pdf}>
                    <ReportPDFSingleListItem
                      onClickMethod={() =>
                        setLcStates((prev) => ({
                          ...prev,
                          reportToPreview: {...(reportDetails?.fileDetails || {})},
                        }))
                      }
                      reportDetails={reportDetails}
                    />
                  </div>
                ) : (
                  <></>
                )}
              </div>
              <div className={Styles.v_report_history_details}>
                <div className={Styles.history_wrapper}>
                  <label>History</label>
                  {reportHistory?.data?.length > 0 ? (
                    <div className={Styles.h_r_container}>
                      {reportHistory?.data?.map((report, index) => {
                        return (
                          <ReportPDFSingleListItem
                            onClickMethod={() =>
                              setLcStates((prev) => ({
                                ...prev,
                                reportToPreview: report,
                              }))
                            }
                            reportDetails={report}
                            key={index}
                          />
                        );
                      })}
                    </div>
                  ) : (
                    <> <p> No History Available </p></>
                  )}
                </div>
              </div>
            </>
          )}
        </Card>
        <ImagePreviewModal
          loading={lcStates.fetchImagesLoader}
          images={images}
          open={lcStates.showImagePreviewModal}
          closeModalMethod={() =>
            setLcStates((prev) => ({ ...prev, showImagePreviewModal: false }))
          }
          uploadedBy={"Haresh Solanki"}
        />
        <NotesPreview
          note={reportDetails?.note}
          isOpen={lcStates.showNotePreview}
          closeMethod={() =>
            setLcStates((prev) => ({
              ...prev,
              showNotePreview: !prev.showNotePreview,
            }))
          }
        />
        {lcStates.showApproverModal ? (
          <QuickUserPreview
            userId={reportDetails?.approver?.id}
            isOpen={lcStates.showApproverModal}
            closeMethod={() =>
              setLcStates((prev) => ({ ...prev, showApproverModal: false }))
            }
          />
        ) : (
          <></>
        )}
        {lcStates.showRecurrenceDetails ? (
          <ViewRecurrenceDetails
            data={reportDetails}
            isOpen={lcStates.showRecurrenceDetails}
            closeMethod={() =>
              setLcStates((prev) => ({ ...prev, showRecurrenceDetails: false }))
            }
          />
        ) : (
          <></>
        )}
        {lcStates.reportToPreview ? (
          <ClonosDocumentViewer
            file={lcStates?.reportToPreview}
            isOpen={lcStates?.reportToPreview?.url ? true : false}
            closeMethod={() =>
              setLcStates((prev) => ({ ...prev, reportToPreview: null }))
            }
          />
        ) : (
          <></>
        )}
        {lcStates.showReviseCommentBox ? (
          <AddCommentToRevise
            isOpen={lcStates.showReviseCommentBox}
            getComment={handleSendForRevision}
            closeMethod={() =>
              setLcStates((prev) => ({
                ...prev,
                showReviseCommentBox: !prev.showReviseCommentBox,
              }))
            }
          />
        ) : (
          <></>
        )}
        {lcStates.showViewCommentsModal ? (
          <ReportComments
            reportId={reportDetails?.id}
            isOpen={lcStates.showViewCommentsModal}
            closeMethod={() =>
              setLcStates((prev) => ({
                ...prev,
                showViewCommentsModal: !prev.showViewCommentsModal,
              }))
            }
          />
        ) : (
          <></>
        )}
      </>
    );

    return <UnAuthorizedModal type={"NOT_AUTHORIZED"}/>
}

export default ViewReportRecurrenceDetails


const ReportPDFSingleListItem = ({onClickMethod,reportDetails,key}) => {
  return <div key={key} className={Styles.v_r_file_container} onClick={onClickMethod}>
  <div className={Styles.v_r_file_left}>
      <img width={"24px"} height={"24px"} src={REPORT_FILE_ICON}/>
      <h4>{reportDetails?.fileDetails?.name || reportDetails?.name}</h4> 
  </div>
  <div style={{...statusStyleStaticData[reportDetails?.status],padding:"0.5rem",borderRadius:"6px",fontWeight:"400"}}>{reportDetails?.status  ? statusStaticData[reportDetails?.status] : "Revised"}</div>
</div>
  
}