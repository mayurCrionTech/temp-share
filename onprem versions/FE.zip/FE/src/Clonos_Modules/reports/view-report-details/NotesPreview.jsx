import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import Modal from "../../../components/CommonComponents/Modal/Modal"
import Styles from "./view-report-details.module.css"
export const NotesPreview = ({isOpen,closeMethod,note}) => {
    return <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
        <div className={Styles.n_v_container} >
            <div className={Styles.n_v_header}>
                <h4>Notes</h4>
                <CloseIcon onClick={() => closeMethod()}/>
            </div>
            <div className={Styles.n_v_text_wrapper}>
                <p>{note}</p>
            </div>
        </div>
    </Modal>
}