import { useEffect, useRef, useState } from "react";
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import Styles from "./report-comments.module.css";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { handleAddNewComment, handleGetReportComments } from "./report-comments-manager";
import { getFormatAMPM, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import ClonosTextarea from "../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";
import { useDispatch } from "react-redux";

export const ReportComments = ({ isOpen, closeMethod, reportId }) => {
  const dispatch = useDispatch()
  const [comments, setComments] = useState({});
  const [pagination, setPagination] = useState({ page: 1, limit: 15 });
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false})
  const [lcStates, setLcStates] = useState({
    fetchCommentsLoader: false,
    addCommentLoader: false,
    showAddComment:false,
    newComment:""
  });



  const handleScroll = (e) => {
    const { scrollTop, clientHeight, scrollHeight } = e.currentTarget;
   
    if (scrollTop + clientHeight >= scrollHeight && !lcStates.fetchCommentsLoader) {
      if (comments?.totalPageCount > pagination?.page) {
        setPagination((prev) => {
          let temp = { ...prev, page: prev?.page + 1 };
          handleGetReportComments({
            reportId,
            setterMethod: setComments,
            pagination,
            setIsLoading: () =>setLcStates((prev) => ({...prev,fetchCommentsLoader: !prev.fetchCommentsLoader})),
          });
          return temp;
        });
      }
    }
  };

  const handleAddComment = () => {
    if(!handleSubmit()) return 
    handleAddNewComment({
      payload:{comment:lcStates?.newComment || ""},
      reportId,
      next:() => {
        setLcStates(prev => ({...prev,showAddComment:false}));
        handleShowErrorAndWarning({dispatch,type:"success",message:"Comment added successfully.",showTime:"5000"})
        handleGetReportComments({
          reportId,
          setterMethod: setComments,
          pagination,
          setIsLoading: () => setLcStates((prev) => ({...prev,fetchCommentsLoader: !prev.fetchCommentsLoader})),
        });
      },
      setIsLoading:() => setLcStates(prev => ({...prev,addCommentLoader:!prev.addCommentLoader}))})
  }

  const handleGetValues = (props) => {
    const {uniqueKey,updatedValue} = props;
    handlePrimaryObjectModifier({uniqueKey,response:updatedValue})
    setLcStates(prev => ({...prev,newComment:updatedValue}))
  }

  useEffect(() => {
    handleGetReportComments({
      reportId,
      setterMethod: setComments,
      pagination,
      setIsLoading: () => setLcStates((prev) => ({...prev,fetchCommentsLoader: !prev.fetchCommentsLoader})),
    });
  }, []);



  return (
    <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
      
        {lcStates?.showAddComment ? (
          <>
          <div className={Styles.a_c_container}>
            <div className={Styles.a_c_header}>
                <h4>Add Comments</h4>
                <CloseIcon onClick={() => closeMethod()} />
            </div>
            <div className={Styles.a_c_section}>
                <ClonosTextarea 
                    isLabel={true}
                    label={"Reason"}
                    uniqueKey={"comment"}
                    isMandatory={true}
                    handleGetValues={handleGetValues}
                    errorMessage={"Please add a comment."}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                ></ClonosTextarea>
                <div className={Styles.btn_wrapper}>
                    <div>
                        <ClonosButton >Cancel</ClonosButton>
                        <ClonosButton loading={lcStates.addCommentLoader} variant={"filled"} onClick={handleAddComment}>Add Comment</ClonosButton>
                    </div>
                </div>
            </div>
            </div>
          </>
        ) : (
          <>
          <div className={Styles.container}>
            <div className={Styles.header}>
              <h4>Comments</h4>
              <div className={Styles.h_right}>
                <ClonosButton onClick={() => setLcStates(prev => ({...prev,showAddComment:true}))}>+ Add Comments</ClonosButton>
                <CloseIcon onClick={() => closeMethod()} />
              </div>
            </div>
            <div onScroll={handleScroll} className={Styles.section}>
              {comments?.data?.length === 0 ? (
                <div className="center_wrapper">
                  <h4>No Comments</h4>
                </div>
              ) : lcStates?.fetchCommentsLoader ? (
                <div className="center_wrapper"><ClonosSpinner /></div>
              ) : (
                <div className={Styles.comments_wrapper}>
                  {comments?.data?.map((comment) => {
                    const time = comment?.addedAt ? getFormatAMPM(comment?.addedAt) : "";
                    const [firstName, lastName] = comment?.name ? comment?.name?.split(" ") : [];
                    const nameInitials = firstName[0] + (lastName ? lastName[0] : "");
                      
                    return (
                      <div className={Styles.cmt_wrapper}>
                        <div className={Styles.user_warpper}>
                          <div className={Styles.profile_wrapper}>
                            {comment?.profilePhoto ? (
                              <img src={comment?.profilePhoto} />
                            ) : (
                              <h4>{nameInitials}</h4>
                            )}
                          </div>
                          <div className={Styles.name_wrapper}>
                            <h4>{comment?.name}</h4>
                            <p>{time}</p>
                          </div>
                        </div>
                        <div className={Styles.cmt_text}>
                          <p>{comment?.comment}</p>
                        </div>
                        <div className={Styles.cmt_breaker}></div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
          </>
        )}
    </Modal>
  );
};
