import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant"
import { doGetApiCall, doPatchApiCall } from "../../../utils/ClonosApi"

export const handleGetReportComments = ({reportId,setterMethod,setIsLoading,pagination}) => {
    setIsLoading()
    doGetApiCall({url:`/reports/comments/${reportId}`,params:pagination})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .catch(err => console.error(err))
    .finally(setIsLoading) 
}

export const handleAddNewComment = ({payload,next,reportId,setIsLoading}) => {
    setIsLoading()
    doPatchApiCall({url:`/reports/comments/${reportId}`,payload})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
            next && next();
        }
    })
    .catch(err => console.error(err))
    .finally(setIsLoading)
}