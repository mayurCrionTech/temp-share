import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import { doGetApiCall, doPatchApiCall } from "../../../utils/ClonosApi";
import { getFormatAMPM, getFormatedDate, handleClientDateInConfiguredTimeZone, handleShowErrorAndWarning } from "../../../utils/clonosCommon";



export const getModulesEnumsList = ({setterMethod}) => {
    doGetApiCall({}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result?.data)
        }
    }).catch((err) => {
        console.error(err)
    })
}


export const getFormatEnumsList = ({setterMethod}) => {
    doGetApiCall({}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result?.data)
        }
    }).catch((err) => {
        console.error(err)
    })
}

export const getAllChecklistsMethod = ({setterMethod,filterPayload}) => {
    doGetApiCall({url:"",params:{...filterPayload}}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result?.data)
        }
    }).catch((err) => {
        console.error(err)
    })
}


export const getAllLogsMethod = ({setterMethod,filterPayload}) => {
    doGetApiCall({url:"",params:{...filterPayload}}).then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result?.data)
        }
    }).catch((err) => {
        console.error(err)
    })
}


export const handleGetSingleReportDetails = ({setterMethod,setIsLoading,reportId}) => {
    const url = `/reports/${reportId}`
    setIsLoading();
    doGetApiCall({url})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            const data = res?.data?.result;
            const possibleFrequencies = {
                day:"Daily",
                week:"Weekly",
                month:"Monthly",
                year:"Yearly"
            }
            const {moduleEntityDetails,fileDetails,reportDetails,entityStruture} = data;
            const {_id,documentNumber,logNumber,name,moduleEntityNumber,description,departments,teams,assignees,approverName,approverId,isRecurrence,asset,recurrenceDetails,scheduledReportDetails,createdBy,updatedBy,createdAt,updatedAt,startDateAndTime,endDateAndTime} = moduleEntityDetails;
            const modifiedData = {};

            const getRequiredDateAndTimeFormat = (date) => {
                return `${getFormatedDate(date)} ${getFormatAMPM(date)}`
            }
            modifiedData.id=reportDetails?.reportId
            modifiedData.documentNumber = documentNumber
            modifiedData.name = name;
            modifiedData.checklistNumber = moduleEntityNumber;
            modifiedData.logNumber = logNumber;
            modifiedData.description = description;
            modifiedData.departments = departments;
            modifiedData.teams = teams;
            modifiedData.assignees = assignees;
            modifiedData.frequency = possibleFrequencies[scheduledReportDetails?.timePeriod];
            modifiedData.asset = asset;
            modifiedData.status = reportDetails?.reportStatus;
            modifiedData.scheduler = createdBy
            modifiedData.scheduledTime = reportDetails?.reportCreatedAt ? getRequiredDateAndTimeFormat(handleClientDateInConfiguredTimeZone({dateString:reportDetails?.reportCreatedAt})) : "-"
            modifiedData.createdOn = createdAt ? getFormatedDate(createdAt) : "-"
            modifiedData.lastUpdatedOn = updatedAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:updatedAt})) : "-"
            modifiedData.isRecurrence = isRecurrence
            modifiedData.lastUpdatedBy = updatedBy;
            modifiedData.approver = {name:approverName,id:approverId}
            modifiedData.fileDetails = {...fileDetails,type:fileDetails?.contentType}
            modifiedData.images = entityStruture?.images || [];
            modifiedData.note = entityStruture?.note || " ";
            modifiedData.startDateAndTime = handleClientDateInConfiguredTimeZone({dateString:startDateAndTime});
            modifiedData.endDateAndTime = handleClientDateInConfiguredTimeZone({dateString:endDateAndTime});
            modifiedData.scheduledReportDetails = scheduledReportDetails
            setterMethod(modifiedData);
        }
  
    })
    .catch((err) => console.error(err))
    .finally(() => {
        setIsLoading()
    })
}


export const handleChangeReportStatus = ({reportId,setIsLoading,payload,next}) => {
    setIsLoading();
    doPatchApiCall({url:`/reports/${reportId}`,payload})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
            next && next()
        }
    })
    .catch((err) => {
        console.error(err)
    })
    .finally(() => {
        setIsLoading();
    })
}


export const handleGetReportHistory = ({setterMethod,setIsLoading,reportId}) => {
    doGetApiCall({url:`/reports/${reportId}/history`})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
        }
    })
    .catch((err) => {
        console.error(err)
    })
    .finally(() => {
        setIsLoading();
    })
}

export const handleRegenerateReport = ({dispatch,reportId,setIsLoading,next}) => {
    setIsLoading();
    doPatchApiCall({url:`/reports/${reportId}/regenerate`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            next && next()
        } else {
            handleShowErrorAndWarning({dispatch,message:res?.response?.errorInfo || "Failed to regenerate report!",type:"error",showTime:"5000"})
        }
    })
    .finally(setIsLoading) 
}