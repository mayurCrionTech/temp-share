import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant"
import AppUrl from "../../../utils/AppUrl"
import { doGetApiCall } from "../../../utils/ClonosApi"

export const handleGetReportsList = ({setterMethod,setIsLoading,pagination}) => {
    setIsLoading();
    doGetApiCall({url:AppUrl.getReportsList,params:pagination})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            
            const data = res?.data?.result;
            const tableFormatData = data?.data?.map((report) => {
                return {
                    id:report?.reportDetails?._id,
                    reportNumber:report?.reportDetails?.reportNumber,
                    reportName:report?.reportDetails?.reportName,
                    moduleName:report?.reportDetails?.moduleName,
                    moduleEntityName:report?.moduleEntityDetails?.name,
                    moduleEntityNumber:report?.moduleEntityDetails?.moduleEntityNumber,
                    status:report?.reportDetails?.status,
                    asset:report?.moduleEntityDetails?.asset,
                    departments:report?.moduleEntityDetails?.departments,
                    assignees:report?.moduleEntityDetails?.assignees
                }
            });
            setterMethod({...res?.data?.result,tableFormatData});
        }
    })
    .catch((err) => console.error(err))
    .finally(() => setIsLoading())
}

export const handleGetReportStatusCounts = ({setterMethod,setIsLoading}) => {
    setIsLoading();
    doGetApiCall({url:AppUrl.getReportStatusCounts})
    .then((res) => {
        
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result);
        }
    })
    .catch(err => console.error(err))
    .finally(() => setIsLoading())
}