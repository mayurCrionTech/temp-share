import { useState } from "react"
import ClonosGridNav from "../../../utils/ClonosGridNav"
import useToggler from "../../../CustomHooks/TogglerHook"
import { checkUserHasPermission, setSerialNumber } from "../../../utils/clonosCommon"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_COLOUR_TERTAIRY_GREEN, CLONOS_GLOBAL_COLOUR_TERTAIRY_YELLOW, CLONOS_GLOBAL_HOVER_COLOUR_SKY_LIGHT } from "../../../Constants/Constant"
import Styles from "./reports-list.module.css"
import { ApprovedReportsIcon, PendingForApprovalReportsIcon, TotalReportsIcon } from "../../../assets/Reports/SVGComponents"
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook"
import { Card } from "@mui/material"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { GenerateReportModal } from "../generate-report/GenerateReport"
const ReportsList = () => {
    const [data,setData] = useState({
        data : [{id:1,}]
    });
    const moduleName = useModuleNameProvider();
    const [navLoader,setNavLoader] = useToggler();
    const [selectedRows,setSelectedRows] = useState([]);
    const [pagination,setPagination] = useState({page:1,limit:15});
    const [fetchReportsLoader,setFetchReportsLoader] = useToggler();
    const [showGenerateReportModal,setShowGenerateReportModal] = useState(false);
    const COLUMNS = [
        {
            field: "index",
            headerName: "SI.NO",
            width: 100,
            hideable: false
        },
        {
            field: "id",
            headerName: "REPORT ID",
            flex:1,
            hideable: false
        },
        {
            field: "name",
            headerName: "REPORT NAME",
            flex:1,
            hideable: false
        },
        {
            field: "createdOn",
            headerName: "CREATED ON",
            flex:1,
            hideable: false
        },
        {
            field: "scheduledDate",
            headerName: "SCHEDULED DATE",
            flex:1,
            hideable: false
        },
        {
            field: "startDate",
            headerName: "START DATE",
            flex:1,
            hideable: false
        },
        {
            field: "endDate",
            headerName: "END DATE",
            flex:1,
            hideable: false
        },
        {
            field: "frequency",
            headerName: "FREQUENCY",
            flex:1,
            hideable: false
        },
        {
            field: "status",
            headerName: "STATUS",
            flex:1,
            hideable: false
        },
        {
            field: "url",
            headerName: "DOWNLOAD",
            flex:1,
            hideable: false
        },
    ]
    return (
        <>
                <ClonosGridNav isLoading={navLoader} items={[
                    {
                        icon: TotalReportsIcon,
                        iconBg: CLONOS_GLOBAL_HOVER_COLOUR_SKY_LIGHT,
                        title: 'Total Reports',
                        count: 0
                    },
                    {
                        icon: ApprovedReportsIcon,
                        iconBg: CLONOS_GLOBAL_COLOUR_TERTAIRY_GREEN,
                        title: 'Approved Reports',
                        count: 0
                    },
                    {
                        icon: PendingForApprovalReportsIcon,
                        iconBg: CLONOS_GLOBAL_COLOUR_TERTAIRY_YELLOW,
                        title: 'Reports Pending for Approval',
                        count: 0
                    },
                ]}>
                    <div className={Styles.rpt_nav_right}>
                        {!checkUserHasPermission({ moduleName: 'team', action: CLONOS_GLOBAL_ACTION_CREATE }) ? <div><ClonosButton onClick={() => setShowGenerateReportModal(true)} variant="filled" >Generate Report</ClonosButton></div> : <></>}
                    </div>
                </ClonosGridNav>
                <Card style={{ margin: "0rem 1rem 1rem 1rem", height: "100%",background:"#FAFAFA" }}>
                    <ClonosDataGrid
                        totalCount={15}
                        columns={COLUMNS}
                        uniqueIdField="id"
                        pageLimit={pagination.limit}
                        loading={fetchReportsLoader}
                        handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                        onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                        rows={setSerialNumber(data?.data || [],pagination?.page,pagination?.limit)}
                        checkboxSelection={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE })}
                    />
                </Card>
                {
                    showGenerateReportModal ? <GenerateReportModal isOpen={showGenerateReportModal} closeMethod={setShowGenerateReportModal}/> : <></>
                }
        </>
    )
}

export default ReportsList