// import { useCallback, useEffect, useState } from "react"
// import ClonosGridNav from "../../../utils/ClonosGridNav"
// import useToggler from "../../../CustomHooks/TogglerHook"
// import { checkUserHasPermission, commonPageState, setSerialNumber } from "../../../utils/clonosCommon"
// import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
// import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_COLOUR_TERTAIRY_GREEN, CLONOS_GLOBAL_COLOUR_TERTAIRY_YELLOW, CLONOS_GLOBAL_HOVER_COLOUR_SKY_LIGHT } from "../../../Constants/Constant"
// import Styles from "./reports-list.module.css"
// import { ApprovedReportsIcon, PendingForApprovalReportsIcon, TotalReportsIcon } from "../../../assets/Reports/SVGComponents"
// import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook"
// import { Card } from "@mui/material"
// import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
// import { GenerateReportModal } from "../generate-report/GenerateReport"
// import { handleGetReportsList, handleGetReportStatusCounts } from "./reports-list-managers"
// import { useNavigate } from "react-router-dom"
// import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData"
// import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"


// const ReportsListManagerScreen = () => {
//     const Navigate = useNavigate();
//     const [reports,setReports] = useState({});
//     const [reportStatusCount,setReportStatusCount] = useState({})
//     const moduleName = useModuleNameProvider();
//     const [navLoader,setNavLoader] = useToggler();
//     const [dataFetchLoader,setDataFetchLoader] = useToggler();
//     const [selectedRows,setSelectedRows] = useState([]);
//     const [pagination,setPagination] = useState(commonPageState);
//     const [fetchReportsLoader,setFetchReportsLoader] = useToggler();
//     const [showGenerateReportModal,setShowGenerateReportModal] = useState(false);
    

   
     
     
//     const COLUMNS = [
//         {
//             field: "index",
//             headerName: "SI.NO",
//             width: 100,
//             hideable: false
//         },
//         {
//             field: "reportNumber",
//             headerName: "REPORT NUMBER",
//             width: 200,
//             hideable: false,
//             renderCell : (param) => {
//                 return <p className="clonos_datagrid_link" onClick={() => Navigate("/view-report-details",{state:{reportId:param?.row?.id}})}>{param?.row?.reportNumber || "-"}</p>
//             }
//         },
//         {
//             field: "reportName",
//             headerName: "REPORT NAME",
//             width: 220,
//             hideable: false,
//             renderCell : (param) => {
//                 return <p>{param?.row?.reportName || "-"}</p>
//             }
//         },
//         {
//             field: "moduleName",
//             headerName: "MODULE NAME",
//             width: 200,
//             hideable: false,
//             resizable:false,
//             renderCell : (param) => {
//                 return <p>{param?.row?.moduleName || "-"}</p>
//             }
//         },
//         {
//             field: "moduleEntityNumber",
//             headerName: "MODULE NUMBER",
//             width: 200,
//             hideable: false,
//             renderCell : (param) => {
//                 return <p>{param?.row?.moduleEntityNumber || "-"}</p>
//             }
//         },
//         {
//             field: "status",
//             headerName: "STATUS",
//             width: 200,
//             hideable: false,
//             align: 'center',
// 			headerAlign: 'center',
//             renderCell : (param) => {
//                 return <p style={{ background: statusStyleStaticData[param?.row?.status]?.backgroundColor, color: statusStyleStaticData[param?.row?.status]?.color, padding: "0.4rem 1rem", borderRadius: "6px" }}>{param?.row?.status ? statusStaticData[param?.row?.status] : "-"}</p>
//             }
//         },
//         {
//             field: "asset",
//             headerName: "ASSET",
//             width: 220,
//             hideable: false
//         },
//         {
//             field: "departments",
//             headerName: "DEPARTMENTS",
//             width: 300,
//             hideable: false,
//             renderCell : (param) => {
//                 const departmentsToShow = param?.row?.departments?.length > 2 ? param?.row?.departments.slice(0,2) : param?.row?.departments?.length ? param?.row?.departments : [];
//                 const moreCount = param?.row?.departments?.length > 2 ? param?.row?.departments?.length - 2 : 0;
//                 return <div>
//                     <span>{departmentsToShow?.join(",")}</span>
//                     {moreCount ? <span>{`, +${moreCount} more`}</span> : <></>} 
//                 </div>
//             }
//         },
//         {
//             field: "assignees",
//             headerName: "ASSIGNED USERS",
//             hideable: false,
//             width: 300,
//             renderCell : (param) => {
//                 const assigneesToShow = param?.row?.assignees?.length > 2 ? param?.row?.assignees.slice(0,2) : param?.row?.assignees?.length ? param?.row?.assignees : [];
//                 const moreCount = param?.row?.assignees?.length > 2 ? param?.row?.assignees?.length - 2 : 0;
//                 return <div className="">
//                     <span>{assigneesToShow?.join(",")}</span>
//                     {moreCount ? <span>{`,+${moreCount} more`}</span> : <></>} 
//                 </div>
//             }
//         },
//     ]


       

//     useEffect(() => {
//         handleGetReportStatusCounts({setterMethod:setReportStatusCount,setIsLoading:setNavLoader})
//     },[])

//     useEffect(() => {
//         handleGetReportsList({setterMethod:setReports,setIsLoading:setFetchReportsLoader,pagination});
//     },[pagination])

//     if(checkUserHasPermission({moduleName:"reports",action:"read"}))
//     return (
//         <>
//                 <ClonosGridNav isLoading={navLoader} items={[
//                     {
//                         icon: TotalReportsIcon,
//                         iconBg: CLONOS_GLOBAL_HOVER_COLOUR_SKY_LIGHT,
//                         title: 'Total Reports',
//                         count: reportStatusCount?.total || 0
//                     },
//                     {
//                         icon: ApprovedReportsIcon,
//                         iconBg: CLONOS_GLOBAL_COLOUR_TERTAIRY_GREEN,
//                         title: 'Approved Reports',
//                         count: reportStatusCount?.completed || 0
//                     },
//                     {
//                         icon: PendingForApprovalReportsIcon,
//                         iconBg: CLONOS_GLOBAL_COLOUR_TERTAIRY_YELLOW,
//                         title: 'Reports Pending for Approval',
//                         count: reportStatusCount?.pendingForApproval || 0
//                     },
//                 ]}>
//                     <div className={Styles.rpt_nav_right}>
//                         {checkUserHasPermission({ moduleName: 'reports', action: CLONOS_GLOBAL_ACTION_CREATE }) ? <div><ClonosButton onClick={() => setShowGenerateReportModal(true)} variant="filled" >Generate Report</ClonosButton></div> : <></>}
//                     </div>
//                 </ClonosGridNav>
//                 <Card style={{ margin: "0rem 1rem 1rem 1rem", height: "100%",background:"#FAFAFA" }}>
//                     <div className={Styles.data_grid_wrapper}>
//                     <ClonosDataGrid
//                         totalCount={reports?.totalDataCount}
//                         columns={COLUMNS}
//                         uniqueIdField="id"
//                         pageLimit={pagination.limit}
//                         // loading={fetchReportsLoader}
//                         autoHeight
//                         disableColumnResize={false}
//                         handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
//                         onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
//                         rows={setSerialNumber(reports?.tableFormatData || [],pagination?.page,pagination?.limit)}
//                         // checkboxSelection={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE })}
//                         checkboxSelection={false}
                         
                        
//                     />
//                     </div>
//                 </Card>
//                 {
//                     showGenerateReportModal ? <GenerateReportModal isOpen={showGenerateReportModal} closeMethod={setShowGenerateReportModal}/> : <></>
//                 }
//         </>
//     )

//     return <UnAuthorizedModal type={"NOT_AUTHORIZED"}/>
// }

// export default ReportsListManagerScreen



/*
date            qid / cr#         comments
13-mar-2026     CR0002            Enable single column filter on the fields visible on these screens

*/



import { useCallback, useEffect, useState } from "react"
import ClonosGridNav from "../../../utils/ClonosGridNav"
import useToggler from "../../../CustomHooks/TogglerHook"
import { checkUserHasPermission, commonPageState, setSerialNumber } from "../../../utils/clonosCommon"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_COLOUR_TERTAIRY_GREEN, CLONOS_GLOBAL_COLOUR_TERTAIRY_YELLOW, CLONOS_GLOBAL_HOVER_COLOUR_SKY_LIGHT } from "../../../Constants/Constant"
import Styles from "./reports-list.module.css"
import { ApprovedReportsIcon, PendingForApprovalReportsIcon, TotalReportsIcon } from "../../../assets/Reports/SVGComponents"
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook"
import { Card } from "@mui/material"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { GenerateReportModal } from "../generate-report/GenerateReport"
import { handleGetReportsList, handleGetReportStatusCounts } from "./reports-list-managers"
import { useNavigate } from "react-router-dom"
import { statusStaticData, statusStyleStaticData } from "../../../Constants/StaticData"
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"



const convertMuiFilterModelToApiParams = (filterModel) => {
    if (!filterModel?.items?.length) return {};

    const params = {};

    filterModel.items.forEach(({ field, value }) => {
        // Skip empty values
        if (value === undefined || value === null || value === "") return;

        switch (field) {
            case "reportNumber":
                params.reportNumber = value;
                break;

            case "reportName":
                params.reportName = value;
                break;

            case "moduleName":
                params.moduleName = value;
                break;

            case "moduleEntityNumber":
                params.moduleEntityNumber = value;
                break;

            case "status":
                params.status = Array.isArray(value) ? value.join(",") : value;
                break;

            case "asset":
                params.asset = value;
                break;

            case "departments":
                params.departments = Array.isArray(value) ? value.join(",") : value;
                break;

            case "assignees":
                params.assignees = Array.isArray(value) ? value.join(",") : value;
                break;

            default:
                params[field] = value;
        }
    });

    return params;
};


const ReportsListManagerScreen = () => {
    const Navigate = useNavigate();
    const [reports,setReports] = useState({});
    const [reportStatusCount,setReportStatusCount] = useState({})
    const moduleName = useModuleNameProvider();
    const [navLoader,setNavLoader] = useToggler();
    const [dataFetchLoader,setDataFetchLoader] = useToggler();
    const [selectedRows,setSelectedRows] = useState([]);
    const [pagination,setPagination] = useState(commonPageState);
    const [fetchReportsLoader,setFetchReportsLoader] = useToggler();
    const [showGenerateReportModal,setShowGenerateReportModal] = useState(false);
     // ── NEW: holds the converted filter params from MUI filterModel ──
           const [filterParams, setFilterParams] = useState({});


   
     
     
    const COLUMNS = [
        {
            field: "index",
            headerName: "SI.NO",
            width: 100,
            disableColumnFilter: true,
            filterable:false,
            hideable: false
        },
        {
            field: "reportNumber",
            headerName: "REPORT NUMBER",
            width: 200,
            hideable: false,
            renderCell : (param) => {
                return <p className="clonos_datagrid_link" onClick={() => Navigate("/view-report-details",{state:{reportId:param?.row?.id}})}>{param?.row?.reportNumber || "-"}</p>
            }
        },
        {
            field: "reportName",
            headerName: "REPORT NAME",
            width: 220,
            hideable: false,
            renderCell : (param) => {
                return <p>{param?.row?.reportName || "-"}</p>
            }
        },
        {
            field: "moduleName",
            headerName: "MODULE NAME",
            width: 200,
            hideable: false,
            resizable:false,
            renderCell : (param) => {
                return <p>{param?.row?.moduleName || "-"}</p>
            }
        },
        {
            field: "moduleEntityNumber",
            headerName: "MODULE NUMBER",
            width: 200,
            hideable: false,
            renderCell : (param) => {
                return <p>{param?.row?.moduleEntityNumber || "-"}</p>
            }
        },
        {
            field: "status",
            headerName: "STATUS",
            width: 200,
            hideable: false,
            align: 'center',
			headerAlign: 'center',
             type: 'singleSelect',
             valueOptions: ['Pending for Approval', 'completed'],  // adjust to match your backend enum
            renderCell : (param) => {
                return <p style={{ background: statusStyleStaticData[param?.row?.status]?.backgroundColor, color: statusStyleStaticData[param?.row?.status]?.color, padding: "0.4rem 1rem", borderRadius: "6px" }}>{param?.row?.status ? statusStaticData[param?.row?.status] : "-"}</p>
            }
        },
        {
            field: "asset",
            headerName: "ASSET",
            width: 220,
            hideable: false
        },
        {
            field: "departments",
            headerName: "DEPARTMENTS",
            width: 300,
            hideable: false,
            renderCell : (param) => {
                const departmentsToShow = param?.row?.departments?.length > 2 ? param?.row?.departments.slice(0,2) : param?.row?.departments?.length ? param?.row?.departments : [];
                const moreCount = param?.row?.departments?.length > 2 ? param?.row?.departments?.length - 2 : 0;
                return <div>
                    <span>{departmentsToShow?.join(",")}</span>
                    {moreCount ? <span>{`, +${moreCount} more`}</span> : <></>} 
                </div>
            }
        },
        {
            field: "assignees",
            headerName: "ASSIGNED USERS",
            hideable: false,
            width: 300,
            renderCell : (param) => {
                const assigneesToShow = param?.row?.assignees?.length > 2 ? param?.row?.assignees.slice(0,2) : param?.row?.assignees?.length ? param?.row?.assignees : [];
                const moreCount = param?.row?.assignees?.length > 2 ? param?.row?.assignees?.length - 2 : 0;
                return <div className="">
                    <span>{assigneesToShow?.join(",")}</span>
                    {moreCount ? <span>{`,+${moreCount} more`}</span> : <></>} 
                </div>
            }
        },
    ]


       // ── NEW: called by ClonosDataGrid whenever the user changes a filter ──
        const handleFilterModelChange = useCallback((muiFilterModel) => {
            const converted = convertMuiFilterModelToApiParams(muiFilterModel);
            setFilterParams(converted);
            // Reset to page 1 when filters change
            setPagination((prev) => ({ ...prev, page: 1 }));
        }, []);
     

    useEffect(() => {
        handleGetReportStatusCounts({setterMethod:setReportStatusCount,setIsLoading:setNavLoader})
    },[])

    useEffect(() => {
        handleGetReportsList({setterMethod:setReports,setIsLoading:setFetchReportsLoader,pagination:{...pagination,...filterParams}});
    },[pagination])

    if(checkUserHasPermission({moduleName:"reports",action:"read"}))
    return (
        <>
                <ClonosGridNav isLoading={navLoader} items={[
                    {
                        icon: TotalReportsIcon,
                        iconBg: CLONOS_GLOBAL_HOVER_COLOUR_SKY_LIGHT,
                        title: 'Total Reports',
                        count: reportStatusCount?.total || 0
                    },
                    {
                        icon: ApprovedReportsIcon,
                        iconBg: CLONOS_GLOBAL_COLOUR_TERTAIRY_GREEN,
                        title: 'Approved Reports',
                        count: reportStatusCount?.completed || 0
                    },
                    {
                        icon: PendingForApprovalReportsIcon,
                        iconBg: CLONOS_GLOBAL_COLOUR_TERTAIRY_YELLOW,
                        title: 'Reports Pending for Approval',
                        count: reportStatusCount?.pendingForApproval || 0
                    },
                ]}>
                    <div className={Styles.rpt_nav_right}>
                        {checkUserHasPermission({ moduleName: 'reports', action: CLONOS_GLOBAL_ACTION_CREATE }) ? <div><ClonosButton onClick={() => setShowGenerateReportModal(true)} variant="filled" >Generate Report</ClonosButton></div> : <></>}
                    </div>
                </ClonosGridNav>
                <Card style={{ margin: "0rem 1rem 1rem 1rem", height: "100%",background:"#FAFAFA" }}>
                    <div className={Styles.data_grid_wrapper}>
                    <ClonosDataGrid
                        totalCount={reports?.totalDataCount}
                        columns={COLUMNS}
                        uniqueIdField="id"
                        pageLimit={pagination.limit}
                        // loading={fetchReportsLoader}
                        autoHeight
                        disableColumnResize={false}
                        handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                        onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                        rows={setSerialNumber(reports?.tableFormatData || [],pagination?.page,pagination?.limit)}
                        // checkboxSelection={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE })}
                        checkboxSelection={false}
                         // ── NEW: wire up server-side filter ──
                    filterMode="server"
                    handleFilterModelChange={handleFilterModelChange}
                    toolbar={true}   // shows the GridToolbar so users can open the filter panel
                        
                    />
                    </div>
                </Card>
                {
                    showGenerateReportModal ? <GenerateReportModal isOpen={showGenerateReportModal} closeMethod={setShowGenerateReportModal}/> : <></>
                }
        </>
    )

    return <UnAuthorizedModal type={"NOT_AUTHORIZED"}/>
}

export default ReportsListManagerScreen



