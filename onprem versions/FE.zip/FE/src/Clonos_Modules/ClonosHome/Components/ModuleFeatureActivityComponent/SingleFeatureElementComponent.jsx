import React from 'react'
import { globalStatus } from '../../../../utils/AssetsMethods/constants'
import { RightArrow } from '../../../../assets/svg/Icons'
import Styles from "./ModuleFeatureActivityComponenent.module.css"
import { statusStaticData, statusStyleStaticData } from '../../../../Constants/StaticData'



/**
 * Functional component for rendering a single feature element.
 * 
 * @param {Object} props - Component props
 * @param {string} props.key - React key for list rendering (Note: Use a different prop name, as 'key' is a reserved word in React)
 * @param {string} props.id - Unique identifier of the element
 * @param {number} props.tabIndex - Tab index for accessibility
 * @param {string} props.ariaLabel - Aria label for accessibility
 * @param {string} props.elementName - Name of the element
 * @param {string} props.elementNumber - Number of the element
 * @param {string} props.status - Status of the element
 * @param {Function} props.handleGetId - Function to handle getting ID
 * @param {string} props.uniqueKey - Unique key for identifying the component
 * @returns {JSX.Element} - JSX element representing the SingleFeatureElementComponent
 */

const SingleFeatureElementComponent = React.memo(({ key, id, tabIndex, ariaLabel, elementName, elementNumber, status, handleGetId, uniqueKey }) => {
    // globalStatus
    return (
        <section
            key={key}
            tabIndex={tabIndex}
            aria-label={ariaLabel}
            className={Styles.single_feature_element}
        >
            <div className={Styles.element_info} aria-label='Element informaiton'>
                <span>{elementName}</span>
                <span>{elementNumber}</span>
            </div>
            <div className={Styles.status} style={statusStyleStaticData[status]}>
                <span >{statusStaticData[status]}</span>
            </div>
            <div className={Styles.action} onClick={() => handleGetId({ id, name: elementName, uniqueKey })}>
                <RightArrow />
            </div>
        </section >
    )
});

export default SingleFeatureElementComponent