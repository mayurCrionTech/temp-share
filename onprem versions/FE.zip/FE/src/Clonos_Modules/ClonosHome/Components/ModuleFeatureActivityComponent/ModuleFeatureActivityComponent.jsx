import React, { useEffect } from 'react'
import Styles from "./ModuleFeatureActivityComponenent.module.css"
import SingleFeatureElementComponent from './SingleFeatureElementComponent'
import { useNavigate } from 'react-router-dom'
import { globalOnScrollEnd } from '../../../../utils/clonosCommon'
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner'
// import { AllChecklists, Checks, PendingForApproval } from '../../../../assets/UIUX/icons/Checklist/Checklist'

import { PendingForApproval, Checks, AllChecklists } from "../../../../assets/UIUX/icons/Checklist/Checklist"
/**
 * Functional component for rendering module feature activities.
 * 
 * @param {Object} props - Component props
 * @param {number} props.tabIndex - Tab index for accessibility
 * @param {string} props.ariaLabel - Aria label for accessibility
 * @param {string} props.moduleFaetureName - Name of the module feature
 * @param {string} props.viewAll - Route to view all activities
 * @param {string} props.uniqueKey - Unique key for identifying the component
 * @param {Function} props.handleGetId - Function to handle getting ID
 * @param {Array} props.data - Array of data representing activities
 * @param {boolean} props.handleDataLoadOnScroll - Flag indicating whether to handle data loading on scroll
 * @param {boolean} props.isDynamicLoad - Flag indicating whether dynamic loading is enabled
 * @param {boolean} props.loading - Flag indicating whether data is loading
 * @returns {JSX.Element} - JSX element representing the ModuleFeatureActivityComponent
 */
const ModuleFeatureActivityComponent = React.memo(({ tabIndex, ariaLabel, moduleFaetureName, viewAll, uniqueKey, handleGetId, data, handleDataLoadOnScroll = false, isDynamicLoad, loading }) => {
    const navigate = useNavigate();

    /**
     * Function to navigate to the "View All" page for the module feature.
     */
    const handleGoToTargetedRoute = () => {
        navigate(viewAll);
    }

    return (
        <div
            tabIndex={tabIndex}
            aria-label={ariaLabel}
            className={Styles.main_container}
        >
            <header className={Styles.header}>
                <h4 className={Styles.feature_module_heading}>{moduleFaetureName}</h4>
                <span
                    aria-label={`Navigate to see all ${moduleFaetureName} page`}
                    className={Styles.view_all}
                    onClick={handleGoToTargetedRoute}
                >View All</span>
            </header>
            <div
                id={uniqueKey}
                aria-label={`${moduleFaetureName} all activities`}
                className={Styles.activities_container}
                onScroll={() => isDynamicLoad && globalOnScrollEnd(handleDataLoadOnScroll, uniqueKey)}
            >
                {/* {
                    (data || []).length ? (data || []).map((element, index) => {
                        return <SingleFeatureElementComponent
                            key={element?.id}
                            tabIndex={tabIndex + index + 1}
                            ariaLabel={element?.name}
                            elementName={element?.name}
                            elementNumber={element?.number}
                            status={element?.status}
                            handleGetId={handleGetId}
                            id={element?.id}
                            uniqueKey={uniqueKey}
                        />
                    }) :
                        <div className={Styles.no_data_found_container}>
                            <span>All looks good!!! No pending task available.</span>
                            <span>No {moduleFaetureName} Updates.</span>
                        </div>
                } */}
                {
                (() => {
                    let items = [];

                    if (moduleFaetureName === "Work Orders") {
                    items = [
                        { icon: AllChecklists, iconBg: '#E7EFFF', title: 'Total Work Orders', count: data?.totalWorkOrders || 0 },
                        { icon: Checks, iconBg: '#EBFAEC', title: 'Completed Work Orders', count: data?.completedWorkOrders || 0 },
                        { icon: PendingForApproval, iconBg: '#F7E9BF', title: 'Drafted Work Orders', count: data?.draftWorkOrders || 0 },
                    ];
                    } else if (moduleFaetureName === "Logs" ) {
                    items = [
                        { icon: AllChecklists, iconBg: '#E7EFFF', title: 'Total Logs', count: data?.logStatuses?.total || 0 },
                        { icon: Checks, iconBg: '#EBFAEC', title: 'Completed Logs', count: data?.logStatuses?.completed || 0 },
                        { icon: PendingForApproval, iconBg: '#F7E9BF', title: 'Log Entries Pending for Approval', count: data?.logStatuses?.pendingForApproval || 0 },
                    ];
                    }

                    return items.length ? (
                    <SummaryTiles items={items} />
                    ) : (
                    <div className={Styles.no_data_found_container}>
                        <span>All looks good!!! No pending task available.</span>
                    </div>
                    );
                })()
                }


                {
                    loading && <div className={Styles.loading_container} > <ClonosSpinner /></div>
                }
            </div>
        </div >
    )
})

export default ModuleFeatureActivityComponent



const SummaryTiles = ({ items }) => {
  if (!items || !items.length) return null;

  return (
    <div className={Styles.tiles_container}>
      {items.map((item, index) => (
        <div key={index} className={Styles.tile}>
          {/* Icon on the left */}
          <div
            className={Styles.icon_wrapper}
            style={{ backgroundColor: item.iconBg }}
          >
            <item.icon style={{ width: "28px", height: "28px" }} />
          </div>

          {/* Title + Count on the right */}
          <div className={Styles.tile_content}>
            <div className={Styles.tile_title}>{item.title}</div>
            <div className={Styles.tile_count}>{item.count}</div>
          </div>
        </div>
      ))}
    </div>
  );
};


