import React from 'react'
import Styles from "./UpdatesComponent.module.css"
import SingleUpdateComponent from './SingleUpdateComponent';
import { globalOnScrollEnd, handleMoreData } from '../../../../utils/clonosCommon';
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner';
import AppUrl from '../../../../utils/AppUrl';


/**
 * Functional component for rendering updates.
 * 
 * @param {Object} props - Component props
 * @param {string} props.ariaLabel - Aria label for accessibility
 * @param {number} props.tabIndex - Tab index for accessibility
 * @param {Array} props.data - Array of data representing updates
 * @param {string} props.uniqueKey - Unique key for identifying the component
 * @param {boolean} props.isDynamicLoad - Flag indicating whether dynamic loading is enabled
 * @param {Function} props.handleDataLoadOnScroll - Function to handle data loading on scroll
 * @param {boolean} props.loading - Flag indicating whether data is loading
 * @param {Object} props.dataDetails - Details about the data
 * @param {boolean} props.loadingFlag - Flag indicating loading state
 * @returns {JSX.Element} - JSX element representing the UpdatesComponent
 */

const UpdatesComponent = React.memo(({ ariaLabel, tabIndex, data, uniqueKey, isDynamicLoad, handleDataLoadOnScroll, loading, dataDetails, loadingFlag }) => {

    return (
        <div
            className={Styles.main_container}
            tabIndex={tabIndex}
            aria-label={ariaLabel}
        >
            <header
                className={Styles.header}
            >
                <h4>Updates</h4>
            </header>
            <section
                id={uniqueKey}
                className={Styles.single_update_container}
                onScroll={() => {
                    isDynamicLoad && globalOnScrollEnd(handleDataLoadOnScroll, uniqueKey)
                }}
            >
                {
                    (data || []).length ? (data || []).map((element, index) => {
                        return <SingleUpdateComponent
                            tabIndex={index}
                            ariaLabel={element?.logName}
                            logName={element?.logName}
                            nameOfItem={element?.name}
                            date={element?.createdDate}
                            totalRecords={(data || []).length - 1}
                        />
                    }) :
                        <div className={Styles.no_data_found_container}>
                            <span>No Updates.</span>
                        </div>
                }
                {
                    loading && <div className={Styles.loading_container} > <ClonosSpinner /></div>
                }
            </section>
        </div>
    )
});

export default UpdatesComponent



