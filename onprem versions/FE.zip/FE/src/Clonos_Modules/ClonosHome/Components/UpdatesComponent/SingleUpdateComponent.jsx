import React, { useEffect, useState } from 'react'
import Styles from "./UpdatesComponent.module.css"
import { getDayMonthYear } from '../../../../utils/clonosCommon';

/**
 * Functional component for rendering a single update item.
 * 
 * @param {Object} props - Component props
 * @param {number} props.tabIndex - Tab index for accessibility
 * @param {string} props.ariaLabel - Aria label for accessibility
 * @param {string} props.logName - Log name of the update
 * @param {string} props.nameOfItem - Name of the item
 * @param {string} props.date - Date of the update
 * @param {number} props.totalRecords - Total number of records
 * @returns {JSX.Element} - JSX element representing the SingleUpdateComponent
 */

const SingleUpdateComponent = React.memo(({ tabIndex, ariaLabel, logName, nameOfItem, date, totalRecords }) => {
    const [lcDate, setDate] = useState({});


    useEffect(() => {
        setDate(getDayMonthYear(date));
    }, [])
    return (
        <div
            className={Styles.single_update_element_container}
            tabIndex={tabIndex}
            ariaLabel={ariaLabel}
        >
            <div className={Styles.date_main_container}>
                <p style={tabIndex === 0 ? { backgroundColor: "#FFF" } : {}}></p>
                <div className={Styles.date_container}>
                    <span>{lcDate?.hours}:{lcDate?.minutes}</span>
                </div>
                <p style={totalRecords === tabIndex ? { backgroundColor: "#FFF" } : {}}></p>
            </div>
            <div className={Styles.updates_info}>
                <span>{logName ? logName : "Not Mentioned"}</span>
                <bdi>{nameOfItem ? nameOfItem : "Not Mentioned"}</bdi>
            </div>
        </div>
    )
});

export default SingleUpdateComponent;