import React from 'react'
import Styles from "./ModuleShortcutComponent.module.css"
import { Add } from '../../../../assets/svg/Add'
import { useNavigate } from 'react-router-dom'
import { CLONOS_GLOBAL_DISABLED_COLOUR_BACKGROUND_DARK, CLONOS_GLOBAL_DISABLED_COLOUR_BACKGROUND_LIGHT, CLONOS_GLOBAL_DISABLED_COLOUR_TEXT_LIGHT } from '../../../../Constants/Constant'
import { Tooltip } from '@mui/material'
import COMMON_EYE_ICON from "../../../../assets/UIUX/icons/Common_Icon/COMMON_EYE_ICON.svg"
/**
 * ModuleShortcutComponent
 * 
 * A memoized component representing a module shortcut.
 * 
 * @param {string} moduleFeatureName - The name of the module feature.
 * @param {string} icon - The icon for the module feature.
 * @param {string} route - The route to navigate to when clicked.
 * @param {number} tabIndex - The tab index for accessibility.
 * @param {string} ariaLabel - The ARIA label for accessibility.
 * @param {string} message - The message to display.
 * @param {string} key - The unique key for React rendering.
 * @param {boolean} isVisible - Determines if the component is visible.
 * @param {boolean} disabled - Determines if the component is disabled.
 * 
 * @returns {JSX.Element} A memoized ModuleShortcutComponent.
 */
const ModuleShortcutComponent = React.memo(({ moduleFeatureName, icon: Icon, listRoute, route, tabIndex, ariaLabel, message, key, isVisible, disabled }) => {
    const navigate = useNavigate();
    /**
     * handleGoToTargetRoute
     * 
     * Handles navigation to the target route.
     */
    const handleGoToTargetRoute = (target) => {
        navigate(target);
    };

    return isVisible && (
        <div
            onClick={() => {
                handleGoToTargetRoute(listRoute)
            }}
            key={key}
            tabIndex={tabIndex}
            aria-label={ariaLabel}
            className={Styles.main_container}
            //style={disabled ? { background: CLONOS_GLOBAL_DISABLED_COLOUR_BACKGROUND_LIGHT, pointerEvents: "none", userSelect: "none", color: CLONOS_GLOBAL_DISABLED_COLOUR_BACKGROUND_DARK } : {}}
        >
            <h4>{moduleFeatureName}</h4>
            <Icon size={100} />
            <div
                onClick={(e) => {
                     if (disabled) return;
                    e.stopPropagation();
                    handleGoToTargetRoute(route);
                }}
                className={Styles.action_container}
            >
                {/* <Add color={disabled && CLONOS_GLOBAL_DISABLED_COLOUR_TEXT_LIGHT} /> */}
                {/* <Tooltip title={`Create new ${moduleFeatureName}`}>
                    <span style={disabled ? { color: CLONOS_GLOBAL_DISABLED_COLOUR_TEXT_LIGHT } : {}}>{message ? message : `Create new ${moduleFeatureName}`}</span>
                </Tooltip> */}
                
               <Tooltip title={disabled ? `View ${moduleFeatureName}` : `Create new ${moduleFeatureName}`}>
                    <div className={Styles.action_content}>
                        {disabled ? (
                            <img src={COMMON_EYE_ICON} alt="Eye Icon" loading="lazy" style={{ width: 16, height: 16 }} />
                        ) : (
                            <Add />
                        )}
                        <span>
                            {disabled ? `View ${moduleFeatureName}` : message ? message : `Create new ${moduleFeatureName}`}
                        </span>
                    </div>
                </Tooltip>

            </div>
        </div>
    )
})

export default ModuleShortcutComponent