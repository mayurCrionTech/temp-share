import { Card } from '@mui/material'
import React, { Suspense, useEffect, useRef, useState } from 'react'
import { checkUserHasPermission, handleMoreData, hasPermission } from '../../utils/clonosCommon'
import { UnAuthorizedModal } from '../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
import { HomeModuleFeaturesStaticData } from '../../Constants/StaticData'
import Styles from "../../ModuleStyles/ClonosHome/Home.module.css"
import ClonosSkeletonLoading from '../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading'
import { doGetApiCall } from '../../utils/ClonosApi'
import AppUrl from '../../utils/AppUrl'
import useToggler from '../../CustomHooks/TogglerHook'
import { useNavigate } from 'react-router-dom'
import useModuleNameProvider from '../../CustomHooks/ModuleNameProviderHook'
import { CLONOS_GLOBAL_ACTION_READ } from '../../Constants/Constant'
import { handleGetWorkOrdersCounts } from '../work-orders/work-order-manager'
import { handleGetLogStatus } from '../../utils/LogAndReportsMethods/LogMethods'
import { useDispatch } from 'react-redux'
 // #160 
import Cookies from 'js-cookie';

// Lazy-loaded components
const ModuleShortcutComponent = React.lazy(() => import('./Components/ModuleShortcutComponent/ModuleShortcutComponent'));
const ModuleFeatureActivityComponent = React.lazy(() => import('./Components/ModuleFeatureActivityComponent/ModuleFeatureActivityComponent'));
const UpdatesComponent = React.lazy(() => import('./Components/UpdatesComponent/UpdatesComponent'));

const ClonosHome = () => {
    const containerRef = useRef(null); // Create a ref for the container element
    const dispatch =useDispatch()
    const [workOrders, setWorkOrders] = useState(null);
    const [checklists, setChecklists] = useState(null);
    const [logs, setLogs] = useState(null);
    const [updates, setUpdates] = useState(null);
    const [toggler, setToggler] = useToggler();
    const [Loading,setLoading] = useToggler();
    const navigate = useNavigate();
    const [loadingFlag, setLoadingFlag] = useState(false);
    const [activeLoadingComponent, setActiveLoadingComponent] = useState("");
    const moduleName = useModuleNameProvider();

    // Function to handle navigation based on the clicked item
    const handleGetId = (props) => {
        const { uniqueKey, id, name, number } = props;
        switch (uniqueKey) {
            case 'workOrders':
                navigate(`/view-work-order/${name}`, { state: { workOrderId: id, workOrderNumber: number } });
                break;
            case 'checklists':
                navigate(`/view-checklist/${props?.name}`, { state: { id } });
                break;
            case 'logs':
                navigate(`/view-log/${props?.name}`, { state: { id } });
                break;
            default:
                break;
        }
    };

    // Function to handle loading more work orders data on scroll
    const handleLoadMoreWorkOrdersDataOnScroll = () => {
        setActiveLoadingComponent("workOrders");
        handleMoreData({ state: workOrders, stateMethod: setWorkOrders, limit: 15, loadingFlag, setLoadingFlag, url: `${AppUrl.home}?moduleName=workorder` });
    }

    // Function to handle loading more checklists data on scroll
    const handleLoadMoreChecklistsDataOnScroll = () => {
        setActiveLoadingComponent("checklists");
        handleMoreData({ state: workOrders, stateMethod: setChecklists, limit: 15, loadingFlag, setLoadingFlag, url: `${AppUrl.home}?moduleName=checklist` });
    }

    // Function to handle loading more logs data on scroll
    const handleLoadMoreLogsDataOnScroll = () => {
        setActiveLoadingComponent("logs");
        handleMoreData({ state: workOrders, stateMethod: setLogs, limit: 15, loadingFlag, setLoadingFlag, url: `${AppUrl.home}?moduleName=log` });
    }

    // Function to handle loading more updates data on scroll
    const handleLoadMoreUpdatesDataOnScroll = () => {
        setActiveLoadingComponent("updates");
        handleMoreData({ state: updates, stateMethod: setUpdates, limit: 15, loadingFlag, setLoadingFlag, url: `${AppUrl.home}?moduleName=updates` });
    }

 // #160 
useEffect(() => {
    const token = Cookies.get('token');

    if (!token) {
        navigate('/');
    }
}, [navigate]);

    // Fetch data on initial render
    useEffect(() => {
        // setToggler();
        false && Promise.all([
            doGetApiCall(`${AppUrl.home}?moduleName=workorder`, { page: 1, limit: 15 }),
            doGetApiCall(`${AppUrl.home}?moduleName=checklist`, { page: 1, limit: 15 }),
            doGetApiCall(`${AppUrl.home}?moduleName=log`, { page: 1, limit: 15 }),
            doGetApiCall(`${AppUrl.home}?moduleName=updates`, { page: 1, limit: 15 }),
        ]).then(res => {
            setWorkOrders(res[0]?.data?.result);
            setChecklists(res[1]?.data?.result);
            setLogs(res[2]?.data?.result);
            setUpdates(res[3]?.data?.result);
        }).finally(setToggler);
    }, []);

    //temporary purpose in cards

    useEffect(()=>{
         handleGetWorkOrdersCounts({setterMethod:setWorkOrders,setIsLoading:setLoading})
         handleGetLogStatus({ dispatch, responseSetterMethod: setLogs })
    },[])


    // Render the home content if user has permission
  
        return (
            <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem", padding: "2.5rem 2rem" }}>
                <main className={Styles.main_container}>
                    <section
                        className={Styles.module_features_container}
                        aria-label='Module feature name container'
                    >
                        {
                            HomeModuleFeaturesStaticData?.map((item, index) => {
                                return <Suspense fallback={<ClonosSkeletonLoading variant='rounded' height='11.625rem' width='11.625rem' />}>
                                    <ModuleShortcutComponent
                                        key={index}
                                        tabIndex={index + 1}
                                        ariaLabel={item.moduleFeatureName}
                                        moduleFeatureName={item.moduleFeatureName}
                                        icon={item.icon}
                                        route={item.route[0]}
                                        listRoute={item?.route[1]}
                                        disabled={item.disabled}
                                        isVisible={item?.isVisible}
                                        IconComp={item.icon}
                                    />
                                </Suspense>
                            })
                        }
                    </section>
                    <section
                        className={Styles.activity_main_container}
                        id='activity_main_container'
                        ref={containerRef}
                    >
                        {checkUserHasPermission({ moduleName: "workOrders", action: CLONOS_GLOBAL_ACTION_READ }) && <Suspense fallback={<ClonosSkeletonLoading variant='rounded' height='27rem' width='23.9375rem' />}>
                            <ModuleFeatureActivityComponent
                                tabIndex={2}
                                ariaLabel={"Feature module activity container"}
                                uniqueKey={'workOrders'}
                                moduleFaetureName={"Work Orders"}
                                data={workOrders || []}
                                handleGetId={handleGetId}
                                viewAll='/work-orders'
                                handleDataLoadOnScroll={() => handleLoadMoreWorkOrdersDataOnScroll("workOrders")}
                                isDynamicLoad={workOrders?.currentPage === workOrders?.totalPageCount ? false : true || !loadingFlag}
                                loading={activeLoadingComponent === "workOrders" && loadingFlag || toggler}
                            />
                        </Suspense>}

                        {/* {checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_READ }) && <Suspense fallback={<ClonosSkeletonLoading variant='rounded' height='27rem' width='23.9375rem' />}>
                            <ModuleFeatureActivityComponent
                                tabIndex={3}
                                ariaLabel={"Feature module activity container"}
                                uniqueKey={'checklists'}
                                moduleFaetureName={"Pending Checklists"}
                                data={checklists?.data || []}
                                handleGetId={handleGetId}
                                viewAll='/checklists'
                                handleDataLoadOnScroll={() => handleLoadMoreChecklistsDataOnScroll("checklists")}
                                isDynamicLoad={checklists?.currentPage === checklists?.totalPageCount ? false : true || !loadingFlag}
                                loading={activeLoadingComponent === "checklists" && loadingFlag || toggler}
                            />
                        </Suspense>} */}

                        {checkUserHasPermission({ moduleName: "logs", action: CLONOS_GLOBAL_ACTION_READ }) && <Suspense fallback={<ClonosSkeletonLoading variant='rounded' height='27rem' width='23.9375rem' />}>
                            <ModuleFeatureActivityComponent
                                tabIndex={4}
                                ariaLabel={"Feature module activity container"}
                                uniqueKey={'logs'}
                                moduleFaetureName={"Logs"}
                                data={logs || []}
                                handleGetId={handleGetId}
                                viewAll='/logs'
                                handleDataLoadOnScroll={() => handleLoadMoreLogsDataOnScroll("logs")}
                                isDynamicLoad={logs?.currentPage === logs?.totalPageCount ? false : true || !loadingFlag}
                                loading={activeLoadingComponent === "logs" && loadingFlag || toggler}
                            />
                        </Suspense>}

                        {checkUserHasPermission({ moduleName: "notifications", action: CLONOS_GLOBAL_ACTION_READ }) && <Suspense fallback={<ClonosSkeletonLoading variant='rounded' height='42.5625rem' width='21.0625rem' />}>
                            <UpdatesComponent
                                data={updates?.data || []}
                                tabIndex={5}
                                uniqueKey="updates"
                                isDynamicLoad={true}
                                handleDataLoadOnScroll={() => handleLoadMoreUpdatesDataOnScroll("updates")}
                                loading={activeLoadingComponent === "updates" && loadingFlag || toggler}
                            />
                        </Suspense>}
                    </section>
                </main>
            </Card>

        )
    
    
}

export default React.memo(ClonosHome)



