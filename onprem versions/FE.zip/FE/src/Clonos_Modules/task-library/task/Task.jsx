import { memo } from "react";
import { useDispatch } from "react-redux";
import Styles from "./task.module.css";
import { useNavigate, useLocation } from "react-router";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosTextarea from "../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import TASK_CREATION_REMOVEROW from "../../../assets/UIUX/icons/Checklist/circle-minus.svg";
import {
  CreateTaskMethod,
  editTaskMethod,
} from "../../../utils/TasksLibraryMethods/TasksLibrarymethods";
import { useEffect } from "react";
import { handleGetStaticDropdownValues } from "../../../utils/DropdownsMethods/DropdownsMethods";
import {
  checkUserHasPermission,
    generateUniqueId,
  handleShowErrorAndWarning,
  restrictSpecialCharacters,
} from "../../../utils/clonosCommon";
import ClonosConfirmationDialog from "../../../components/Dialogs/ClonosConfirmationDialog";
import { getSingleTask } from "../../../Api/TasksLibrary/tasksLibraryAPI";
import { validateForm } from "../../../utils/AssetsMethods/AssetRegister";
import { Card, Grid } from "@material-ui/core";
import { handleGetValuesOfMaintenanceTaskMethod } from "../../../utils/ScheduleMaintenanceMethods/ScheduleMaintenanceMethods";
import useToggler from "../../../CustomHooks/TogglerHook";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook";
import { handleGetAssetCategories } from "../../ClonosAssets/general-details/general-details-managers";
import { handleCheckUniquenessOfSubTasks, handleCreateTask, handleGetFilledValuesOfTasks, handleGetSingleTask, handleUpdateTask } from "./task-manager";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_TASK_LIBRARY } from "../../../Constants/Constant";
import { doGetApiCall } from "../../../utils/ClonosApi";


/*
date            qid / cr#         comments
24-mar-2026     CR0001            Apply filter on drop down

*/
const Task = ({ mode }) => {
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const Location = useLocation();
  const [isSaveLoading,setIsSaveLoading] = useToggler();
  const [isFetchLoading,setIsFetchLoading] = useToggler();
  const [formData, setFormData] = useState({});
  const [serverData,setServerData] = useState({});
  const [showConfirmationDailog,setShowConfirmationDailog] = useState(false)
  const [assetCategories,setAssetCategories] = useState([])
  const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit} = useFieldsChecker({ isIndexKey: false,hookUniqueKey:"task-library"})

  const [loadingDropdowns, setLoadingDropdowns] = useState({});
   const [staticDropdownData,setStaticDropdownData]=useState({})

     const fetchStaticDropdownByCode = async (code) => {
  if (staticDropdownData[code] || loadingDropdowns[code]) return;

  setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

  try {
    const res = await doGetApiCall({url:`dropdowns/${code}`});
       
    setStaticDropdownData(prev => ({
      ...prev,
      [code]: res?.data?.result?.options
    }));
  } finally {
    setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
  }
};
 const handleGetValues = (props) => {
    handleGetFilledValuesOfTasks({mode,fieldProps:props,setFormData,serverData,handlePrimaryObjectModifier,primaryObject,formData})
 }

 console.log(formData,"formData")
 const handleAddTasks = () => {
    const auxTasks = formData?.tasks?.length ? formData?.tasks  : [];
    const newTask = {description:"",key:generateUniqueId(4)}
    setFormData(prev => ({...prev,tasks:[...auxTasks,newTask]}))
 }
 const handleRemoveTask = (taskToRemove) => {
    let tasksToDelete = formData?.tasksToDelete || [];
    if(taskToRemove?.id){
      tasksToDelete.push(taskToRemove?.id)
    } 
    const remainigTasks = formData?.tasks?.filter(task => task?.key !== taskToRemove?.key);
    setFormData(prev => ({...prev,tasks:remainigTasks,tasksToDelete}))
 }
 const handleChangeSubTask = (props) => {
    const {uniqueKey,updatedValue,taskToModify} = props;
    handlePrimaryObjectModifier({uniqueKey,response:updatedValue})
    const modifiedTasks = formData?.tasks?.map(task => {
        if(taskToModify?.id && taskToModify?.id === task?.id){
            return {...task,description:updatedValue,isEdited:true}
        } else if(taskToModify.key && taskToModify.key === task.key){
            return {...task,description:updatedValue}
        } else {
            return task
        }
    })
    setFormData(prev => ({...prev,tasks:modifiedTasks}))
 }
 const handleSaveTasks = () => {
    if(!handleSubmit()) return
    
        const emptyTask = formData?.tasks?.findIndex(t => !t.description?.trim());
          if (emptyTask !== -1) {
              handleShowErrorAndWarning({
                  dispatch,
                  message: `Please fill the description for Task: ${emptyTask + 1}.`,
                  type: "error",
                  showTime: "5000"
               });
              return;
          }

//     // Extra check for tasks before saving
// const emptyTasks = formData?.tasks?.filter(t => !t.description?.trim());

// if (emptyTasks?.length) {
//   const taskNumbers = emptyTasks.map((_, index) => index + 1).join(', ');
//   handleShowErrorAndWarning({
//     dispatch,
//     message: `Please fill the description for Task${emptyTasks.length > 1 ? 's' : ''}: ${taskNumbers}.`,
//     type: "error",
//     showTime: "5000"
//   });
//   return;
// }

    const next = () => {
        Navigate("/tasks-library");
        handleShowErrorAndWarning({dispatch,message:`Task ${mode === "edit" ? "updated" :"created"} successfully.`,type:"success",showTime:"5000"})
    }
    if(!handleCheckUniquenessOfSubTasks(formData?.tasks,dispatch)) return
    if(mode === "edit"){
        handleUpdateTask({taskId:serverData?.id,payload:formData,setIsLoading:setIsSaveLoading,next})
    } else {
        handleCreateTask({payload:formData,setIsLoading:setIsSaveLoading,next})
    }
 }

 useEffect(() => {
    // handleGetAssetCategories({setterMethod:setAssetCategories});
    if(mode === "edit"){
        handleGetSingleTask({setterMethod:setServerData,altSetterMethod:setFormData,setIsLoading:setIsFetchLoading,taskId:Location?.state?.id})
    }
 },[])


  if (checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_TASK_LIBRARY, action: CLONOS_GLOBAL_ACTION_CREATE })){
     return (
    <>
      <Card variant="outlined" className={Styles.task_creation_container}>
        <div className={Styles.task_creation_sub_container}>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <div style={{ padding: "0rem 2rem" }}>
                <div>
                  <ClonosInput
                    isMandatory={true}
                    isLabel={true}
                    label={"Task Name"}
                    defaultValue={serverData?.name}
                    type="text"
                    handleGetValues={(value) => handleGetValues(value)}
                    placeholder="Name"
                    uniqueKey="name"
                    errorMessage={"Task Name is required!."}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  />
                </div>
              </div>
            </Grid>
            <Grid item xs={6}>
              <div style={{ padding: "0rem 2rem" }}>
                {/* <ClonosLabel>Description</ClonosLabel> */}
                <ClonosTextarea
                  isLabel={true}
                  label={"Description"}
                  className={Styles.task_creation_form_field_text_area}
                  defaultValue={mode === "edit" ? serverData?.description : ""}
                  row={3}
                  type="text"
                  limit='1000'
                  uniqueKey="description"
                  placeholder="Description"
                  handleGetValues={(value) => handleGetValues(value)}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  
                />
              </div>
            </Grid>
            <Grid item xs={6}>
              <div style={{ padding: "0rem 2rem" }}>
                <ClonosSelect
                  isLabel={true}
                  label="Asset Category"
                  type={"select"}
                  // options={assetCategories?.map((category) => ({
                  //   label: category?.name,
                  //   value: category?.id,
                  //   isNeeded: true,
                  // }))}
                  uniqueKey="assetCategory"
                  defaultValue={serverData?.assetCategory?.value}
                  placeholder="Select"
                  isMandatory={true}
                  handleGetValues={handleGetValues}
                  errorMessage={"Asset Category is required!."}
                   options={staticDropdownData?.assetCategory?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
                    onOpen={() => fetchStaticDropdownByCode("assetCategory")} 
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                />
              </div>
            </Grid>
          </Grid>

          <Card className="card_wrapper"  style={{ margin: "2rem 2rem 0rem 2rem", flex: 1 }}>
            <div className={Styles.task_count_controller}>
              <ClonosButton variant="teritary" onClick={handleAddTasks}>
                {"+ Add Task"}
              </ClonosButton>
            </div>
            <div className={Styles.task_list_wrapper}>
              {formData?.tasks?.length > 0 ? (
                formData?.tasks?.map((task, index) => {
                  return (
                    <div
                      className={Styles.singe_task_item}
                      key={task?.id || task?.key}
                    >
                      <div className={Styles.task_content_wrapper}>
                        <p>{`Task-${index + 1}`}</p>
                        <ClonosInput
                          defaultValue={task?.description}
                          handleGetValues={(val) => handleChangeSubTask({...val,taskToModify:task})}
                          placeholder="Enter Task..."
                          uniqueKey={`task-${index+1}`}
                          inputStyle={{color: task.description ? "black" : "#8CA1C4",}}
                          wrapperClassName={Styles.input_wrapper}
                          wrapperStyle={{ border: "none" }}
                          maxLength={"250"}
                          // isMandatory={true}
                          // errorMessage={"Task Name is required!."}
                          //  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                      </div>
                      <div onClick={() => handleRemoveTask(task)}>
                        <img
                          src={TASK_CREATION_REMOVEROW}
                          className="c-pointer"
                        />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className={Styles.empty_list}>
                      <h2> Add Tasks to Create.</h2>
                </div>
              )}
            </div>
          </Card>

          <div className={Styles.btn_controller}>
            <ClonosButton
              variant="outlined"
              onClick={() =>
                Object.keys(formData)?.length
                  ? setShowConfirmationDailog(true)
                  : Navigate(-1)
              }
            >
              Cancel
            </ClonosButton>
            <ClonosButton
              className={"ml-half"}
              variant={"filled"}
              onClick={handleSaveTasks}
			  loading={isSaveLoading}
            >
              {mode === "edit" ? "Update" : "Create"}
            </ClonosButton>
          </div>
        </div>
        {/* </div> */}
		<ClonosConfirmationBox
			isOpen={showConfirmationDailog}
			closeModalMethod={setShowConfirmationDailog}
			confirmingMethod={() => {Navigate(-1)}}
			headerTitle="Cancel"
			message="Are you sure you want to cancel?"
		/>
      </Card>
    </>
  );
  }
return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
};

export default memo(Task);
