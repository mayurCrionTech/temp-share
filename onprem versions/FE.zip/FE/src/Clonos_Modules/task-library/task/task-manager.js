import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant";
import AppUrl from "../../../utils/AppUrl";
import { doDeleteApiCall, doGetApiCall, doPostApiCall, doPutApiCall } from "../../../utils/ClonosApi";
import { debounce, generateUniqueId, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import { handleCheckUniqueFieldsMethod } from "../../../utils/common-managers";

//  TO CHECK THE UNIQUNESS OF FIELD
const uniqueFieldHandler = ({ module, mode, fieldName, fieldValue, primaryObject, handlePrimaryObjectModifier, setFormData, setChangedData }) => {
    handleCheckUniqueFieldsMethod({ module, fieldName, fieldValue }).then((res) => {
        if (res === "unique") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
            setFormData((prev) => {
                return { ...prev, [fieldName]: fieldValue }
            })
        } else if (res === "not_unique") {
            primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
            primaryObject?.[fieldName]?.errorActivatorMethod(true);
            primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${fieldName}.`)
        }
    })
}


const debouncedCheckUniquenessOfFields = debounce(uniqueFieldHandler, 500);


export const handleGetFilledValuesOfTasks = ({mode,fieldProps,setFormData,serverData,handlePrimaryObjectModifier,formData,primaryObject}) => {
    const {type,uniqueKey,updatedValue} = fieldProps;
    if(type === "text"){
        if(uniqueKey === "name") {
            if(mode !== "edit") {
                debouncedCheckUniquenessOfFields({module:"tasks",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData})
            } else {
                updatedValue !== serverData?.name && debouncedCheckUniquenessOfFields({module:"tasks",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData})
            }
        } else {
            handlePrimaryObjectModifier({uniqueKey,response:updatedValue})
            setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
        }
    } else if(type === "select"){
        handlePrimaryObjectModifier({uniqueKey,response:updatedValue})
        setFormData(prev => ({...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}}))
    }
}


export const handleCreateTask = ({payload,setIsLoading,next}) => {
    const requetPayload = handleModifyRequestPayload(payload,"create");
    setIsLoading && setIsLoading();
    doPostApiCall({url:AppUrl.createTask,payload:requetPayload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
            next && next()
        }
    })
    .finally(() => setIsLoading && setIsLoading())
}


export const handleUpdateTask = ({taskId,payload,setIsLoading,next}) => {
    const requetPayload = handleModifyRequestPayload(payload,"edit");
    setIsLoading && setIsLoading();
    doPutApiCall({url:`/tasks/${taskId}`,payload:requetPayload})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            next && next()
        }
    })
    .finally(() => setIsLoading && setIsLoading())
}

export const handleModifyRequestPayload = (payload,mode) => {
    const requetPayload = {};
    if(payload?.name) requetPayload.name = payload.name;
    if(payload?.description) requetPayload.description = payload.description;
    // if(payload?.assetCategory) requetPayload.assetCategory = payload?.assetCategory?.name;
    if(payload?.assetCategory) requetPayload.assetCategory = payload?.assetCategory?.id;
    if(mode === "create"){
        if(payload?.tasks?.length){
            requetPayload.tasks = payload?.tasks?.map((task,index) => ({description:task?.description,order:index+1}))
        }
    } else {
        const tasksToBeAdded = [];
        const tasksToBeEdited = [];
        if(payload?.tasks?.map((task,index) => {
            if(task?.isEdited){
                tasksToBeEdited.push({id:task?.id,description:task?.description,order:task?.order})
            } else {
                if(task?.key && !task?.id){
                    tasksToBeAdded.push({description:task?.description,order:index+1})
                }
            }
        }))
        if(tasksToBeAdded?.length)requetPayload.tasksToBeAdded = tasksToBeAdded;
        if(tasksToBeEdited?.length)requetPayload.tasksToBeEdited = tasksToBeEdited;
        if(payload?.tasksToDelete?.length) requetPayload.tasksDeleted = payload?.tasksToDelete
    }
    return requetPayload
}


export const handleCheckUniquenessOfSubTasks = (tasks,dispatch) => {
    let auxObj = {};
    let isAllUnique = true;
    tasks?.map(task => {
        if(!auxObj[task?.description]){
            auxObj[task?.description] = 1;
        } else {
            auxObj[task?.description] = auxObj[task?.description] + 1;
            isAllUnique = false;
            handleShowErrorAndWarning({dispatch,message:"Duplicate sub tasks found!",type:"error",showTime:"5000"});
        }
    })
    return isAllUnique
}

export const handleGetSingleTask = ({setterMethod,altSetterMethod,setIsLoading,taskId}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:`/tasks/${taskId}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const data = res?.data?.result;
            // data.tasks = data?.tasks?.map(task => ({...task,key:generateUniqueId(4)}))
            
            // only sort for formData
            const sortedTasks = data?.tasks
            ?.map(task => ({ ...task, key: generateUniqueId(4) }))
            ?.sort((a, b) => a.order - b.order);

            setterMethod(data);
            altSetterMethod({tasks:sortedTasks })
        }
    })
    .finally(() => {
        setIsLoading && setIsLoading()
    })
}


export const handleDeleteTasks = ({payload,next,setIsLoading}) => {
    setIsLoading();
    doDeleteApiCall({url:AppUrl.deleteTask,payload:{taskLibrariesToDelete:payload}})
    .then(res =>{
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
            next && next()
        }
    })  
    .finally(setIsLoading)
}