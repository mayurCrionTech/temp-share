// import { memo } from "react";
// import { useDispatch } from "react-redux";
// import { useNavigate } from "react-router";
// import ClonosDataGrid from "../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
// import { useEffect } from "react";
// import { useState } from "react";
// import {
//   checkUserHasPermission,
//   commonPageState,
//   getToken,
//   handleLoginExpiry,
//   handleShowErrorAndWarning,
//   hasPermission,
//   setSerialNumber,
// } from "../../utils/clonosCommon";
// import ClonosConfirmationDialog from "../../components/Dialogs/ClonosConfirmationDialog";
// import { ClonosButton } from "../../components/CommonComponents/Button/Button";
// import { Task, TotalTasks } from "../../assets/svg/Task";
// import { Card } from "@material-ui/core";
// import ClonosGridNav from "../../utils/ClonosGridNav";
// import { doGetApiCall, doPutApiCall } from "../../utils/ClonosApi";
// import AppUrl from "../../utils/AppUrl";
// import useToggler from "../../CustomHooks/TogglerHook";
// import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
// import useModuleNameProvider from "../../CustomHooks/ModuleNameProviderHook";
// import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE } from "../../Constants/Constant";
// import { handleDeleteTasks } from "./task/task-manager";

// const TasksList = () => {
//   const dispatch = useDispatch();
//   const Navigate = useNavigate();
//   const [tasksList, setTasksList] = useState([]);
//   const [selectedRows, setSelectedRows] = useState([]);
//   const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
//   const [pagination, setPagination] = useState(commonPageState);
//   const [totalCount, setTotalCount] = useState(0);
//   const [isLoading, setIsLoading] = useToggler();
//   const [isDeleteLoading, setIsDeleteLoading] = useToggler();
//   const [refreshApi, setRefreshApi] = useToggler();

//   const columns = [
//     {
//       field: "index",
//       headerName: "SI.NO",
//       width: 100,
//     },
//     {
//       field: "number",
//       headerName: "TASK ID",
//       width: 300,
//       renderCell: (param) => {
//         return (
//           <p
//             className="c-pointer"
//             onClick={() =>
//               Navigate(`/view-task/${param?.row?.name}`, { state: { id: param?.row?.id } })
//             }
//             style={{ textDecoration: "underline", color: "#0A5FFF" }}
//           >
//             {param?.row?.number}
//           </p>
//         );
//       },
//     },
//     {
//       field: "name",
//       headerName: "TASK NAME",
//       width: 500,
//     },
//     {
//       field: "assetCategory",
//       headerName: "ASSET CATEGORY",
//       // flex:1,
//       width: 200,
//       renderCell: (param) => {
//         return <p>{param?.row?.assetCategory?.name || "-"}</p>;
//       },
//     },
//   ];

//   const handleDelete = () => {
//     handleDeleteTasks({payload:selectedRows,setIsLoading:setIsDeleteLoading,next:() => {
//         handleShowErrorAndWarning({dispatch,message:"Tasks deleted successfully.",type:"success",showTime:"5000"});
//         setRefreshApi();
//         setShowConfirmationDailog(false)
//     }})
//   };

//   useEffect(() => {
//     setIsLoading();
//     setTasksList([]);
//     doGetApiCall({url:AppUrl.getTaskList, params:pagination})
//       .then((res) => {
//         setTasksList(
//           setSerialNumber(
//             res?.data?.result?.data || [],
//             pagination.page,
//             pagination.limit
//           )
//         );
//         setTotalCount(
//           res?.data?.result?.totalDataCount ||
//           res?.data?.result?.data?.length ||
//           0
//         );
//       })
//       .finally(setIsLoading);
//   }, [pagination, refreshApi]);
//   if(checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_READ}))
//   return (
//     <>
//       <ClonosGridNav
//         items={[
//           {
//             icon: TotalTasks,
//             iconBg: "#E7EFFF",
//             title: "Total Tasks",
//             count: totalCount,
//           },
//         ]}
//       >
//         <div className="d-fl-al-cen">
//           {checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_CREATE}) ? (
//             <ClonosButton
//               onClick={() => Navigate("/create-task")}
//               variant={"filled"}
//             >
//               Create Task
//             </ClonosButton>
//           ) : (
//             <></>
//           )}
//         </div>
//       </ClonosGridNav>

//       <Card
//         variant="outlined"
//         style={{
//           flex: 1,
//           marginRight: "1rem",
//           marginLeft: "1rem",
//           padding: "1rem",
//         }}
//       >
//         <ClonosDataGrid
//           handleGetSelectedRowsMethod={(val) =>
//             setSelectedRows(val?.selectedRows)
//           }
//           rows={tasksList}
//           columns={columns}
//           uniqueIdField={"id"}
//           totalCount={totalCount}
//           pageLimit={pagination.limit}
//           isEditMethod={
//             checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_UPDATE})
//               ? () => Navigate("/edit-task", { state: { id: selectedRows[0] } })
//               : false
//           }
//           isDeleteMethod={
//             checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_DELETE})
//               ? () => setShowConfirmationDailog(true)
//               : false
//           }
//           onPageChange={(e) =>
//             setPagination({ page: e.page + 1, limit: e.pageSize })
//           }
//           isLoading={isLoading}
//         />
//       </Card>
//       <ClonosConfirmationBox
//         isOpen={showConfirmationDailog}
//         loading={isDeleteLoading}
//         headerTitle={"Delete Task"}
//         message={"Are you sure you want to Delete?"}
//         closeModalMethod={setShowConfirmationDailog}
//         confirmingMethod={handleDelete}
//       />
//     </>
//   );
// };

// export default memo(TasksList);

/*
date            qid / cr#         comments
12-mar-2026     CR0002            Enable single column filter on the fields visible on these screens

*/

/*
    date            qid / cr#         comments
    07-Apr-2026     -#160             Broken Access Control - Permission Restriction FrontEnd
    */

import { memo, useCallback } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import ClonosDataGrid from "../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid";
import { useEffect } from "react";
import { useState } from "react";
import {
  checkUserHasPermission,
  commonPageState,
  getToken,
  handleLoginExpiry,
  handleShowErrorAndWarning,
  hasPermission,
  setSerialNumber,
} from "../../utils/clonosCommon";
import ClonosConfirmationDialog from "../../components/Dialogs/ClonosConfirmationDialog";
import { ClonosButton } from "../../components/CommonComponents/Button/Button";
import { Task, TotalTasks } from "../../assets/svg/Task";
import { Card } from "@material-ui/core";
import ClonosGridNav from "../../utils/ClonosGridNav";
import { doGetApiCall, doPutApiCall } from "../../utils/ClonosApi";
import AppUrl from "../../utils/AppUrl";
import useToggler from "../../CustomHooks/TogglerHook";
import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import useModuleNameProvider from "../../CustomHooks/ModuleNameProviderHook";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_TASK_LIBRARY } from "../../Constants/Constant";
import { handleDeleteTasks } from "./task/task-manager";
//#160 
import { UnAuthorizedModal } from "../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";

const convertMuiFilterModelToApiParams = (filterModel) => {
    if (!filterModel?.items?.length) return {};

    const params = {};

    filterModel.items.forEach(({ field, operator, value }) => {
        // Skip empty values
        if (value === undefined || value === null || value === '') return;

        switch (field) {
            case 'name':
                params.name = value;
                break;

            case 'number':
                params.number = value;
                break;

            case 'assetCategory':
                // MUI might send a single value; backend expects comma-separated for $in
                params.assetCategory =  value;
                break;

        
            default:
                // For any unmapped field, pass it as-is
                params[field] = value;
        }
    });

    return params;
};

const TasksList = () => {
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const [tasksList, setTasksList] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
  const [pagination, setPagination] = useState(commonPageState);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useToggler();
  const [isDeleteLoading, setIsDeleteLoading] = useToggler();
  const [refreshApi, setRefreshApi] = useToggler();
  const moduleName = useModuleNameProvider();
     // ── NEW: holds the converted filter params from MUI filterModel ──
      const [filterParams, setFilterParams] = useState({});

  const columns = [
    {
      field: "index",
      headerName: "SI.NO",
      width: 100,
      disableColumnFilter: true,
            filterable: false, 
    },
    {
      field: "number",
      headerName: "TASK ID",
      width: 300,
      renderCell: (param) => {
        return (
          <p
            className="c-pointer"
            onClick={() =>
              Navigate(`/view-task/${param?.row?.name}`, { state: { id: param?.row?.id } })
            }
            style={{ textDecoration: "underline", color: "#0A5FFF" }}
          >
            {param?.row?.number}
          </p>
        );
      },
    },
    {
      field: "name",
      headerName: "TASK NAME",
      width: 500,
    },
    {
      field: "assetCategory",
      headerName: "ASSET CATEGORY",
      // flex:1,
      width: 200,
      renderCell: (param) => {
        return <p>{param?.row?.assetCategory?.name || "-"}</p>;
      },
    },
  ];

  const handleDelete = () => {
    handleDeleteTasks({payload:selectedRows,setIsLoading:setIsDeleteLoading,next:() => {
        handleShowErrorAndWarning({dispatch,message:"Tasks deleted successfully.",type:"success",showTime:"5000"});
        setRefreshApi();
        setShowConfirmationDailog(false)
    }})
  };


      // ── NEW: called by ClonosDataGrid whenever the user changes a filter ──
      const handleFilterModelChange = useCallback((muiFilterModel) => {
          const converted = convertMuiFilterModelToApiParams(muiFilterModel);
          setFilterParams(converted);
          // Reset to page 1 when filters change
          setPagination((prev) => ({ ...prev, page: 1 }));
      }, []);

  useEffect(() => {
    setIsLoading();
    setTasksList([]);
    doGetApiCall({url:AppUrl.getTaskList, params:{...pagination,...filterParams}})
      .then((res) => {
        setTasksList(
          setSerialNumber(
            res?.data?.result?.data || [],
            pagination.page,
            pagination.limit
          )
        );
        setTotalCount(
          res?.data?.result?.totalDataCount ||
          res?.data?.result?.data?.length ||
          0
        );
      })
      .finally(setIsLoading);
  }, [pagination, refreshApi]);
  if(checkUserHasPermission({moduleName:moduleName,action:CLONOS_GLOBAL_ACTION_READ})){
  return (
    <>
      <ClonosGridNav
        items={[
          {
            icon: TotalTasks,
            iconBg: "#E7EFFF",
            title: "Total Tasks",
            count: totalCount,
          },
        ]}
      >
        <div className="d-fl-al-cen">
          {checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_CREATE}) ? (
            <ClonosButton
              onClick={() => Navigate("/create-task")}
              variant={"filled"}
            >
              Create Task
            </ClonosButton>
          ) : (
            <></>
          )}
        </div>
      </ClonosGridNav>

      <Card
        variant="outlined"
        style={{
          flex: 1,
          marginRight: "1rem",
          marginLeft: "1rem",
          padding: "1rem",
        }}
      >
        <ClonosDataGrid
          handleGetSelectedRowsMethod={(val) =>
            setSelectedRows(val?.selectedRows)
          }
          rows={tasksList}
          columns={columns}
          uniqueIdField={"id"}
          totalCount={totalCount}
          pageLimit={pagination.limit}
          isEditMethod={
            checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_UPDATE})
              ? () => Navigate("/edit-task", { state: { id: selectedRows[0] } })
              : false
          }
          isDeleteMethod={
            checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_DELETE})
              ? () => setShowConfirmationDailog(true)
              : false
          }
          onPageChange={(e) =>
            setPagination({ page: e.page + 1, limit: e.pageSize })
          }
          isLoading={isLoading}
           // ── NEW: wire up server-side filter ──
          filterMode="server"
          handleFilterModelChange={handleFilterModelChange}
          toolbar={true}   // shows the GridToolbar so users can open the filter panel
        />
      </Card>
      <ClonosConfirmationBox
        isOpen={showConfirmationDailog}
        loading={isDeleteLoading}
        headerTitle={"Delete Task"}
        message={"Are you sure you want to Delete?"}
        closeModalMethod={setShowConfirmationDailog}
        confirmingMethod={handleDelete}
      />
    </>
  );
}
//#160 
 return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
};

export default memo(TasksList);
