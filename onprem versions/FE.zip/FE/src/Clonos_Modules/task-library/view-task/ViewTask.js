import { useLocation, useNavigate } from "react-router"
import Styles from "./view-task.module.css"
import { Card } from "@material-ui/core";
import { useEffect, useMemo, useState } from "react";
import { doGetApiCall } from "../../../utils/ClonosApi";
import { checkUserHasPermission, getFormatedDate, handleClientDateInConfiguredTimeZone, handleShowErrorAndWarning, hasPermission } from "../../../utils/clonosCommon";
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE } from "../../../Constants/Constant";
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook";
import Subbar from "../../../components/CommonComponents/ClonosSubbar/Subbar";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { handleDeleteTasks } from "../task/task-manager";
import { useDispatch } from "react-redux";
import useToggler from "../../../CustomHooks/TogglerHook";
/*
    date            qid / cr#         comments
    07-Apr-2026     -#160             Broken Access Control - Permission Restriction FrontEnd
    */
const ViewTask = () => {
    const dispatch = useDispatch()
    const Navigate = useNavigate();
    const moduleName = useModuleNameProvider();
    const Location = useLocation();
    const [taskDetails,setTaskDetails] = useState({});
    const [isDeleteLoading,setIsDeleteLoading] = useToggler()
    const [showConfirmationDailog,setShowConfirmationDailog] = useState(false)
    const [isLoading,setIsLoading] = useState(false)
    const generalDetails = [{label:"Task Name",key:"name"},{label:"Task Id",key:"number"},{label:"Description",key:"description"},{label:"Asset Category",key:"assetCategory"}]
    //#160 
    const [isUnauthorized, setIsUnauthorized] = useState(false);
    const handleDelete = () => {
        handleDeleteTasks({payload:[taskDetails?.id],setIsLoading:setIsDeleteLoading,next:() => {
            handleShowErrorAndWarning({dispatch,message:"Tasks deleted successfully.",type:"success",showTime:"5000"});
            setShowConfirmationDailog(false);
            Navigate("/tasks-library")
        }})
    }
    
  const sortedTasks = useMemo(() => {
  return taskDetails?.tasks
    ?.slice()
    .sort((a, b) => a.order - b.order) || [];
}, [taskDetails?.tasks]);

    useEffect(() => {
        //#160 
         if (!Location?.state) {
        setIsUnauthorized(true);
        return;
    }
        setIsLoading(true);
        doGetApiCall({url:`/tasks/${Location?.state?.id}`}).then((res) => {
            let data = res?.data?.result;
            data.createdAt = handleClientDateInConfiguredTimeZone({dateString:data?.createdAt,parseType:"string"})
            data.updatedAt = handleClientDateInConfiguredTimeZone({dateString:data?.updatedAt,parseType:"string"})
            setTaskDetails(res?.data?.result || {})
        }).finally(() => setIsLoading(false))
    },[])

    //#160 
   if (isUnauthorized) {
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
    }

    if(checkUserHasPermission({moduleName:moduleName,action:CLONOS_GLOBAL_ACTION_READ}))
    return <>
        <Subbar
            isEditMethod={checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_UPDATE}) ? () => Navigate("/edit-task",{state:{id:taskDetails?.id}}) : false}
            isDeleteMethod={checkUserHasPermission({moduleName:"taskLibrary",action:CLONOS_GLOBAL_ACTION_DELETE}) ? () =>  setShowConfirmationDailog(true)  : false}
            staticElements={[{key:"Created On : ",value:getFormatedDate(taskDetails?.createdAt)},{key:"Last updated On : ",value:getFormatedDate(taskDetails?.updatedAt)},{key:"Last updated by : ",value:taskDetails?.updatedBy?.name}]}
        />
        <Card variant="outlined" style={{ flex: 1, margin: "1rem"}}>
            {
                Object.keys(taskDetails)?.length > 0 ? <div className={Styles.view_task_container}>
                <div className={Styles.view_task_sub_container}>
                    <div className={Styles.view_task_gen_details}>
                        {
                            generalDetails?.map((field) => {
                                return <div className={Styles.field_item}>
                                    <p className={Styles.field_item_label}>{field?.label}</p>
                                    <p className={Styles.field_item_value}>{field.key === "assetCategory" && taskDetails["assetCategory"] ? taskDetails[field?.key]?.name : taskDetails[field?.key]}</p>
                                </div>
                            })
                        }
                    </div>
                    <div className={Styles.view_task_list}>
                        {/* {
                            taskDetails?.tasks?.map((task,index) => {
                                return  <div className={Styles.view_task_list_item}>
                                    <span>{`Task ${index+1} - `}</span>
                                    <p>{task?.description}</p>
                                </div>
                            })
                        } */}
                        {
                            sortedTasks.map((task) => (
                                <div key={task.id} className={Styles.view_task_list_item}>
                                <span>{`Task ${task.order} - `}</span>   {/* use order directly */}
                                <p>{task.description}</p>
                                </div>
                            ))
                        }
                    </div>
                </div>
            </div> : <div className={Styles.error}>
                {isLoading ? <ClonosSpinner/> : <h2 >Oops! Looks like Something went wrong.</h2>}
            </div>
            }
        </Card>
        <ClonosConfirmationBox
            isOpen={showConfirmationDailog}
            loading={isDeleteLoading}
            headerTitle={"Delete Task"}
            message={"Are you sure you want to Delete?"}
            closeModalMethod={setShowConfirmationDailog}
            confirmingMethod={handleDelete}
        />
    </>

    return <UnAuthorizedModal type={"NOT_AUTHORIZED"}/>
}

export default ViewTask