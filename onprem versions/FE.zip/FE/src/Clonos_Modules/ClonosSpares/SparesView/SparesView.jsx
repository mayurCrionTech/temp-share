import React, { useEffect, useRef,useState } from 'react'
import Subbar from '../../../components/CommonComponents/ClonosSubbar/Subbar'
import { Card } from '@material-ui/core'
import Styles from './sparesview.module.css'
import { doGetApiCall, doPatchApiCall } from '../../../utils/ClonosApi'
import AppUrl from '../../../utils/AppUrl'
import { useLocation, useNavigate } from 'react-router-dom'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS, CLONOS_GLOBAL_STATUS_APPROVED, CLONOS_GLOBAL_STATUS_DRAFT, CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL, CLONOS_GLOBAL_STATUS_RESUBMIT, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant'
// import NOIMAGE from "../../../assets/images/No_image_available.png";
import NOIMAGE from '../../../assets/images/No_image_available.png'
import { ImagePreviewModal } from '../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal'
import {Tooltip} from '@material-ui/core'
import { checkUserHasPermission, handleClientDateInConfiguredTimeZone, handleLoggedInUser, handleShowErrorAndWarning } from '../../../utils/clonosCommon'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import useToggler from '../../../CustomHooks/TogglerHook'
import { useDispatch } from 'react-redux'
import { handleDeleteSpares } from '../SparesManager/spares-manager'
import ClonosConfirmationBox from '../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import useModuleNameProvider from '../../../CustomHooks/ModuleNameProviderHook'
import { UnAuthorizedModal } from '../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
/*
    date            qid / cr#         comments
    07-Apr-2026     #160             Broken Access Control - Permission Restriction FrontEnd
    */
function SparesView() {
  const dispatch=useDispatch()
  const LOCATION =useLocation()
  const navigate = useNavigate()
  const [spareViewDetails,setSpareViewDetails]=useState([])
  const [activeImage, setActiveImage] = useState(0);
  const [showImagePreviewModal, setShowImagePreviewModal] = useState(false);
  const [refreshApi, setRefreshApi] = useToggler();
   //#160 
   const [isUnauthorized, setIsUnauthorized] = useState(false);
  
  const [lcLoaderAndFlags,setLcLoadersAndFlags]=useState({
        deleteSpareAlert:false,
        deleteLoading:false
  })
  const moduleName = useModuleNameProvider();
  const user= handleLoggedInUser();
  const isOperator = user?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR;
  
  const handleGoToSpareEdit=()=>{
          navigate(`/edit-spare`, { state: { "mode": "edit", "spareId": LOCATION?.state?.spareId} })
  }
 
  const handleImagePreview = (activeImageIndex) => {
    setActiveImage(activeImageIndex);
    setShowImagePreviewModal(true);
  }


  useEffect(()=>{
     //#160 
       if (!LOCATION?.state) {
        setIsUnauthorized(true);
        return;
     }
    if(LOCATION?.state?.spareId){    
    let url =`/spares/${LOCATION?.state?.spareId}`
    doGetApiCall({url}).then((res)=>{
        
         if(res.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setSpareViewDetails(res?.data?.result)
         }
  })
}
  },[refreshApi,LOCATION?.state?.spareId])



   
  const handleSpareApproveStatus =()=>{
    const url =`spares/${LOCATION?.state?.spareId}/approve` 
  
    // setRefreshApi()
    doPatchApiCall({url}).then((res)=>{
      
          
            setRefreshApi()
            handleShowErrorAndWarning({dispatch,type: "success", message: `Spare Approve Sucessfully`, showTime: 5000 })
       
    })
  }

   const handleSpareRejectStatus =()=>{
    const url =`spares/${LOCATION?.state?.spareId}/reject` 
    doPatchApiCall({url}).then((res)=>{
        
          setRefreshApi()
          handleShowErrorAndWarning({dispatch,type:'success', message:"Spare reject Sucessfully",showTime:"5000" })
         
        //   handleShowErrorAndWarning({message:"Add Quanity Sucessfully",type:"success",showTime:"5000"})
    })
  }

//   const isEditable = (
//   (spareViewDetails?.approver?.name !== user.name &&
//     spareViewDetails?.status === CLONOS_GLOBAL_STATUS_APPROVED) ||
//   (spareViewDetails?.status === CLONOS_GLOBAL_STATUS_RESUBMIT &&
//     LOCATION?.state?.spareId &&
//     spareViewDetails?.approver?.name !== user.name) || (spareViewDetails?.status === CLONOS_GLOBAL_STATUS_DRAFT)
// );
  //#160 
 if (isUnauthorized) {
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
    }
    
 if (checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
  return (
  <>
    <Subbar
        isStatus={true}
        isEditMethod={spareViewDetails?.status !== CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleGoToSpareEdit : null}
        isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setLcLoadersAndFlags(prev => ({...prev, deleteSpareAlert:!prev.deleteSpareAlert})) : false}
        //isEditMethod={spareViewDetails?.approver?.name !== user.name  && spareViewDetails?.status === CLONOS_GLOBAL_STATUS_APPROVED || spareViewDetails?.status === CLONOS_GLOBAL_STATUS_RESUBMIT && LOCATION?.state?.spareId ? handleGoToSpareEdit : null}
        // isDeleteMethod={spareViewDetails?.approver?.name === user.name && LOCATION?.state?.spareId || spareViewDetails?.status === CLONOS_GLOBAL_STATUS_DRAFT? () => setLcLoadersAndFlags(prev => ({...prev, deleteSpareAlert:!prev.deleteSpareAlert})) : false}
        subbarData={{ status: spareViewDetails?.status }}
        staticElements={
            [
                { "key": "Created On:", value: handleClientDateInConfiguredTimeZone({ dateString: spareViewDetails?.createdAt, parseType: "object" })?.clientView } ,
                { "key": "Last Updated On:", value: handleClientDateInConfiguredTimeZone({ dateString: spareViewDetails?.updatedAt, parseType: "object" })?.clientView },
            ]
        }
        // isEditMethod={(checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) && LOCATION?.state?.logId) ? lcHandleGoToLogEdit : null}
        // isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? lcHandleDelete : null}
        // isDownloadMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DOWNLOAD }) ? () => setIsDownloadModal(true) : null}
        // subbarData={{ status: spareViewDetails?.status }}
        // staticElements={
        //     [
        //         { "key": "Last Updated On:", value: handleClientDateInConfiguredTimeZone({ dateString: entryDetails?.logEntry?.updatedAt, parseType: "object" })?.clientView },
        //         { "key": "Last Updated By:", value: lcChecklistData?.updatedBy ? lcChecklistData?.updatedBy : "-" },
        //     ]
        // }
    
    />
       <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem",overflow: "auto", }}>
          <div className={Styles?.sparesViewContainer}>
            <section className={Styles?.section1}>
              
                   
                  <div>
                       <h4> General Details</h4>
                       <table>
                            <tr>
                                <td>Spare Name: </td>
                                <td>{spareViewDetails?.name}{spareViewDetails?.specification}</td>
                            </tr>
                            <tr>
                                <td>Description: </td>
                                <td style={{textAlign:"justify"}}>{spareViewDetails?.description}</td>
                            </tr>
                            <tr>
                                <td>Part Number:</td>
                                <td>{spareViewDetails?.partNumber}</td>
                            </tr>
                            <tr>
                                <td>Quantity:</td>
                                <td>{spareViewDetails?.quantity}</td>
                            </tr>
                            <tr>
                                <td>Category:</td>
                                <td>{spareViewDetails?.category}</td>
                            </tr>
                            <tr>
                                <td>Unit of Measure:</td>
                                <td>{spareViewDetails?.units}</td>
                            </tr>
                            <tr>
                                <td>Approver:</td>
                                <td>{spareViewDetails?.approver?.name}</td>
                            </tr>
                            {/* <tr>
                                <td>Assets:</td>
                                <td>{spareViewDetails?.}</td>
                            </tr> */}
                        </table>
                  </div>

                  <div>
                     <h4>Stock Details</h4>
                     <table>
                            <tr>
                                <td>Minimum Quantity Required : </td>
                                <td>{spareViewDetails?.minimumRequiredQuantity} </td>
                            </tr>
                            <tr>
                                <td>Recommended Quantity Required: </td>
                                <td>{spareViewDetails?.recommendedQuantity}</td>
                            </tr>
                            <tr>
                                <td>Cost:</td>
                                <td>{spareViewDetails?.cost}</td>
                            </tr>
                            <tr>
                                <td>Unit of Cost:</td>
                                <td>{spareViewDetails?.costUnits}</td>
                            </tr>
                            <tr>
                                <td>Expiry Date:</td>
                                <td>{handleClientDateInConfiguredTimeZone({ dateString: spareViewDetails?.expiryDate, parseType: "object" })?.clientView }
                                </td>
                            </tr>
                        
                        </table>
                  </div>

                  <div>
                    <h4>Supplier Details</h4>
                    <table>
                    <tr>
                        <td>Supplier Name: </td>
                        <td>{spareViewDetails?.supplierDetails?.name} </td>
                        </tr>
                        <tr>
                            <td>Vendor Code: </td>
                            <td>{spareViewDetails?.supplierDetails?.vendorCode}</td>
                        </tr>
                        <tr>
                            <td>Contact Number:</td>
                            <td>{spareViewDetails?.supplierDetails?.contactNumber}</td>
                        </tr>
                        <tr>
                            <td>Email Id:</td>
                            <td>{spareViewDetails?.supplierDetails?.email}</td>
                        </tr>
                        </table>
                  </div>
        
            </section>
           
            <section className={Styles?.section2}>
                    <h4>Spare Image</h4> 
                 <div className={Styles.spareImageSection}>
                      
                    <div
                        onClick={() => spareViewDetails?.images?.length && handleImagePreview(0)}
                        className={Styles.spareMainImageWrapper}
                    >
                        <img
                        src={spareViewDetails?.images?.length > 0 ? spareViewDetails?.images[0]?.url : NOIMAGE}
                        alt="Main Spare"
                        />

                        {spareViewDetails?.images?.[0] && (
                        <Tooltip
                        title={`${spareViewDetails.images[0].name}.${spareViewDetails.images[0].extension}`}
                        >
                        <p style={{textAlign:"center" }}>{`${spareViewDetails.images[0].name}.${spareViewDetails.images[0].extension}`}</p>
                        </Tooltip>
                    )}
                        
                    </div>

                    <div className={Styles.spareImageGallery}>
                        {spareViewDetails?.images?.slice(1, 3)?.map((img, index) => (
                        <div key={index} className={Styles.spareImageItem}>
                            <div
                            onClick={() => handleImagePreview(index + 1)}
                            className={Styles.spareImagePreviewWrapper}
                            >
                            <img src={img?.url || NOIMAGE} alt={`Spare ${index + 1}`} />
                            </div>
                            <Tooltip title={`${img?.name}.${img?.extension}`}>
                            <p style={{textAlign:"center"}}>{`${img?.name}.${img?.extension}`}</p>
                            </Tooltip>
                        </div>
                        ))}
                        {spareViewDetails?.images?.length > 3 && (
                        <div className={Styles.spareImageItem}>
                            <div className={Styles.viewAllButtonBox} onClick={() => handleImagePreview(0)}>
                            <p className={Styles.viewAllLink}>View All</p>
                            </div>
                        </div>
                        )}
                    </div>

                 </div>

                     <ImagePreviewModal
                         activeImageIndex={activeImage}
                         open={showImagePreviewModal}
                         closeModalMethod={setShowImagePreviewModal}
                         images={spareViewDetails?.images}
                         
                       />

                   
                
            </section>

             
          </div>
                <footer className={Styles.checklist_gen_details_footer}>
                        <div style={{display:"flex", flexWrap:"wrap", justifyContent:'space-between' }}>
                          {!isOperator && spareViewDetails?.approver?.name === user?.name  && spareViewDetails?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL ?( 
                            <>
                              <ClonosButton
                        
                                // isDisabled={formData?.name ? false : true}
                                // loading={lcValues?.savingLogsGeneralDetailsAsDraftLoading}
                                onClick={() => {
                                  handleSpareApproveStatus()
                                }}
                                variant="filled"
                                style={{
                                  border: "1px solid #06337E",
                                  fontSize: "16px",
                                  padding: "0.5rem 1rem",
                                  width:"220px"
                                }}
                              >Approve
                              </ClonosButton>
              
                              <ClonosButton
                                // loading={lcValues?.checklistGeneralDetailsLoading}
                                // isDisabled={!isUnique}
                                variant="outlined"
                                onClick={() => {
                                  handleSpareRejectStatus()
                                }}
                                style={{ fontSize: "16px", padding: "0.5rem 1rem", width:"220px"  }}
                              >
                                Reject
                              </ClonosButton>
                            </>
                          ):
                          (<></>)
                             
                          }
                        
                        </div>
                      </footer >
                  </Card>

                       <ClonosConfirmationBox
                             isOpen={lcLoaderAndFlags.deleteSpareAlert}
                             confirmingMethod={() => {
                                 handleDeleteSpares({payload:[spareViewDetails?.id],setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,deleteLoading:!prev.deleteLoading})),next:() => {
                                     handleShowErrorAndWarning({dispatch,message:"Spares deleted successfully!",type:"success",showTime:"5000"})
                                     navigate("/spares")
                                 } })
                                setLcLoadersAndFlags((prev)=>({...prev, deleteSpareAlert : !prev.deleteSpareAlert}))
                             }}
                             loading={lcLoaderAndFlags?.deleteLoading}
                             closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,deleteSpareAlert:!prev.deleteSpareAlert}))}
                             headerTitle="Delete Spare"
                             message="Are you sure, You want to delete this Spares?"
                         />

  </>
  )

 }
  return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
  
}

export default SparesView