import React,{useEffect} from 'react'
import Styles from './CreateSpares.module.css'
import ClonosInput from '../../../components/CommonComponents/ClonosInput/ClonosInput'
import ClonosTextarea from '../../../components/CommonComponents/ClonosTextarea/ClonosTextarea'
import ClonosSelect from '../../../components/CommonComponents/ClonosSelect/ClonosSelect'
import DynamicDropdown from '../../../components/CommonComponents/DynamicDropdown/DynamicDropdown'
import ClonosRadioAndCheckbox from '../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox'
import FileUploader from '../../../components/CommonComponents/FileUploader/FileUploader'
import ClonosConfirmationBox from '../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import { useState } from 'react'
// import { handleGetValues } from '../../../utils/ChecklistAndReportsMethods/CommonMethods'
import useFieldsChecker from '../../../CustomHooks/FieldsValidatorHook'
import { Card } from '@mui/material'
import { handleDraftSpares, handleGetFilledValuesOfSpares,handleGetSingleSpare,handleUpdateSpare } from '../SparesManager/spares-manager'
import { useDispatch } from 'react-redux'
import { useLocation, useNavigate } from 'react-router-dom'
import { handleCreateSpares } from '../SparesManager/spares-manager'
import { handleLoggedInUser, handleShowErrorAndWarning ,getToken, handleClientDateInConfiguredTimeZone, checkUserHasPermission} from '../../../utils/clonosCommon'
import { handleGetValues } from '../../../utils/ChecklistAndReportsMethods/CommonMethods'
import AppUrl from '../../../utils/AppUrl'
import { doGetApiCall } from '../../../utils/ClonosApi'
import useDebounce from '../../../CustomHooks/DebounceHook'
import { axiosInstance } from '../../../Api/AxioClient'
import { UnAuthorizedModal } from '../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal'
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_SPARES } from '../../../Constants/Constant'

/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/
function CreateSpares({mode}) {
    const dispatch=useDispatch()
    const navigate=useNavigate()
    const LOCATION =useLocation()
    const [formData, setFormData] = useState({ isSupplierDetails: false, });
    const [approversDropdowndata,setApproversDropdownData]=useState([]);
     const spareNameUniqueness = useDebounce(formData?.name, 500);
     const [isUnique, setIsUnique] = useState(false);
     const [serverResponse,setServerResponse]=useState({})
      const fullName = serverResponse?.name || '';
      const [name = '', specification = ''] = fullName.split(' - ');
    const [loadingDropdowns, setLoadingDropdowns] = useState({});
   const [staticDropdownData,setStaticDropdownData]=useState({})
     const [lcValues, setLcValues] = useState(
        {
          "isChangesMade": false,
          mode,
          approvers:[],
        }
      );
      
      const [loadersAndFlags,setLoadersAndFlags] = useState({
             saveSparesLoading: false,
             editSpareLoading:false,
             showDraftSpareAlert:false,
             showCancelSpareAlert:false,
             draftSpareLoading:false
          })

      const {
          handleGetErrorActivatorInformation,
          handlePrimaryObjectModifier,
          handleSubmit,
          handleGetUpdatedPrimaryObject,
          handleRemoveField,
          primaryObject
        } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "spareDetails" });

    


       
      const handleGetValues = (props) => {
             handleGetFilledValuesOfSpares({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier,formData})
         }

  

       const handleDynamicSearch = (response, type) => {
        const searchInput = response?.input?.toLowerCase() || "";
        let filteredUsers = [];

        if (type === "approver") {
          filteredUsers = approversDropdowndata.filter(user =>
            user.name?.toLowerCase().includes(searchInput)
          );

          setLcValues((prev) => ({
            ...prev,
            approvers: searchInput === "" ? approversDropdowndata : filteredUsers
          }));
        }
      };


  const handleSubmitSpares =()=>{
         if(!handleSubmit()) return
            const next = () => {
                navigate("/spares");
                handleShowErrorAndWarning({dispatch,message:`spares ${mode === "created"? "created" : "updated"} successfully.`,type:"success",showTime:"5000"})
            }
           if(mode === "edit"){
               handleUpdateSpare({payload:formData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveSparesLoading:!prev.saveSparesLoading})),next,spareId:LOCATION?.state?.spareId})
           }else{
                handleCreateSpares({payload:formData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveSparesLoading:!prev.saveSparesLoading})),next})
           }
           
          
  }

  const fetchStaticDropdownByCode = async (code) => {
  if (staticDropdownData[code] || loadingDropdowns[code]) return;

  setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

  try {
    const res = await doGetApiCall({url:`dropdowns/${code}`});
       
    setStaticDropdownData(prev => ({
      ...prev,
      [code]: res?.data?.result?.options
    }));
  } finally {
    setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
  }
};


          useEffect(()=>{
                // GET USER
              doGetApiCall({
               url:AppUrl?.getAllUsers,params:{
                 selectFields:"name"
               }
             }).then((res)=>{
                 const allUsers = res?.data?.result?.data || [];
                //  const loggedInUserDetails = handleLoggedInUser();
         
                //  const filteredUsers = allUsers.filter(user => user?.name !== loggedInUserDetails?.name);
         
                 setApproversDropdownData(allUsers); // if you want all users in approver dropdown
                 
           })
         
         },[])
    
        
         
     useEffect(()=>{
      if(mode== "edit"){
          handleGetSingleSpare({setterMethod:setServerResponse,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,editSpareLoading :!prev.editSpareLoading})),spareId:LOCATION?.state?.spareId})     
      }
  },[mode])      
    

   if (checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_SPARES, action: CLONOS_GLOBAL_ACTION_CREATE })){
     return (
   <>
  
     <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem", overflowY: "auto" }}>
    <div  className={Styles.main_container}>
         <header className={Styles.spares_gen_details_header}>
           General Details
        </header>
        <section className={Styles.split}>
         <div>
            <ClonosInput
                tabIndex={1}
                label="Spare Name"
                isLabel={true}
                placeholder="Spare Name"
                isMandatory={true}
                type="text"
                limit='50'
                uniqueKey="name"
                defaultValue={name}
                 handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
             />
               <ClonosTextarea
                tabIndex={2}
                label="Description"
                isLabel={true}
                placeholder="Description"
                isMandatory={false}
                type="text"
                limit="500"
                uniqueKey="description"
                defaultValue={serverResponse?.description}
                 handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
              <ClonosInput
                tabIndex={3}
                label="Specification"
                isLabel={true}
                placeholder="Specification"
                isMandatory={true}
                type="text"
                limit='30'
                uniqueKey="specification"
                defaultValue={specification}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
             />
             <ClonosInput
                tabIndex={4}
                label="Part Number"
                isLabel={true}
                placeholder="Part Number"
                isMandatory={false}
                type="text"
                limit='20'
                uniqueKey="partNumber"
                defaultValue={serverResponse?.partNumber}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
             />
             <ClonosInput
                tabIndex={5}
                label="Category"
                isLabel={true}
                placeholder="Category"
                isMandatory={false}
                type="text"
                limit='10'
                uniqueKey="category"
                isSpecialCharacterAllow={false}
                isAlphabeticOnlyAllow={true}
                defaultValue={serverResponse?.category}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
             />
             <div className={Styles.quantity_units_selector_container}>
              <ClonosInput
                tabIndex={6}
                label="Quantity"
                isLabel={true}
                placeholder="Quantity"
                isMandatory={true}
                type="number"
                limit='8'
                uniqueKey="quantity"
                defaultValue={serverResponse?.quantity}
                 handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
              <ClonosSelect
                    tabIndex={7}
                    type="select"
                    label="Units"
                    isMandatory={true}
                    isLabel={true}
                    uniqueKey="units"
                    placeholder="Select"
                    defaultValue={serverResponse?.units}
                    options={[{ label: "mm", value: "units", isNeeded: true },{ label: "Litres", value: "units", isNeeded: true },{ label: "No's", value: "units", isNeeded: true }]}
                    // options={staticDropdownData?.quantityUnits?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
                    // onOpen={() => fetchStaticDropdownByCode("quantityUnits")} 
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  />
             </div>

            <DynamicDropdown
                tabIndex={8}
                uniqueKey={"approver"}
                placeholder={"Search"}
                isSearchable={true}
                isCheckbox={false}
                label="Approver"
                isActivator={true}
                isMandatory={true}
                isDynamicLoad={false}
                data={lcValues.approvers.length ? lcValues.approvers : approversDropdowndata}
                // data={approversDropdowndata}
                // handleMoreData={handleMoreData}
                heading={"Select from Users Library"}
                handleDynamicSearch={(response) => handleDynamicSearch(response, "approver")}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                defaultValue={serverResponse?.approver ? [serverResponse.approver] :""}
                // defaultValue={mode === "edit" && generalDetails?.approvers?.length ? generalDetails?.approvers.map(user => ({ id:user?._id , name: user?.name })) : null}
                  handleGetValues={handleGetValues}
                />
                <header className={Styles.spares_gen_details_header}>
                Stock Details
                </header>

                <ClonosInput
                tabIndex={9}
                label="Minimum quantity required"
                isLabel={true}
                placeholder="Minimum quantity required"
                isMandatory={true}
                type="number"
                limit='8'
                uniqueKey="minimumRequiredQuantity"
                isSpare={true}
                defaultValue={serverResponse?.minimumRequiredQuantity}
                 handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />

              <div className={Styles.cost_units_selector_container}>
                 <ClonosInput
                tabIndex={10}
                label="Cost"
                isLabel={true}
                placeholder="Cost"
                isMandatory={false}
                type="number"
                limit='8'
                uniqueKey="cost"
                defaultValue={serverResponse?.cost}
                 handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
              <ClonosSelect
                    tabIndex={11}
                    type="select"
                    label="Units"
                    isMandatory={false}
                    isLabel={true}
                    uniqueKey="costUnits"
                    placeholder="Select"
                    // options={[{ label: "INR", value: "unitOfCost", isNeeded: true }]}
                    options={staticDropdownData?.costUnits?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
                    onOpen={() => fetchStaticDropdownByCode("costUnits")} 
                     handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    defaultValue={serverResponse?.unitOfCost}
                  />
             </div>
                <ClonosInput
                    tabIndex={12}
                    label="Expiry Date"
                    isLabel={true}
                    isMinimum={true}
                    placeholder="Expiry Date"
                    isMandatory={false}
                    type="datetime-local"
                //  disabled={(mode === "edit" && generalDetails?.logStatus !== "draft") ? true : false}
                    min={true}
                    uniqueKey="expiryDate"
                 defaultValue={mode === "edit" && (() => {
                   const parsedString = handleClientDateInConfiguredTimeZone({ dateString: serverResponse?.expiryDate, parseType: "object" });
                   return `${parsedString?.year}-${parsedString?.month}-${parsedString?.day}T${parsedString?.hour}:${parsedString?.minute}`
                 })()}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                     handleGetValues={handleGetValues}
                />
                <ClonosRadioAndCheckbox
                name="generationMode"
                uniqueKey="isSupplierDetails"
                isLabel={true}
                label="Supplier Details"
                type="checkbox"
                isChecked={formData?.isSupplierDetails || serverResponse?.isSupplierDetails}
                //   disabled={(mode === "edit" && generalDetails?.logStatus !== "draft") ? true : false}
                 handleGetValues={handleGetValues}
                />
            
              {(formData?.isSupplierDetails || serverResponse?.isSupplierDetails) && <div className={Styles.supplier_details_container}>
                        <div className={`${Styles.split_common}`} >
                        <ClonosInput
                        tabIndex={13}
                        label="Supplier Name"
                        isLabel={true}
                        placeholder="Supplier Name"
                        isMandatory={false}
                        type="text"
                        limit='50'
                        uniqueKey="supplierName"
                        isAlphaSpecialOnlyAllow={true}
                        defaultValue={serverResponse?.supplierDetails?.name}
                         handleGetValues={handleGetValues}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                    <ClonosInput
                        tabIndex={14}
                        label="Vendor Code"
                        isLabel={true}
                        placeholder="Vendor Code"
                        isMandatory={false}
                        type="text"
                        limit='50'
                        uniqueKey="vendorCode"
                        
                        defaultValue={serverResponse?.supplierDetails?.vendorCode}
                         handleGetValues={handleGetValues}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                    </div>
                    <div className={`${Styles.split_common}`}>
                        <ClonosInput
                        tabIndex={15}
                        label="Email"
                        isLabel={true}
                        placeholder="Email"
                        isMandatory={false}
                        type="text"
                        limit='50'
                        uniqueKey="email"
                        
                        defaultValue={serverResponse?.supplierDetails?.email}
                        handleGetValues={handleGetValues}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                        <ClonosInput
                        tabIndex={16}
                        label="Contact Number"
                        isLabel={true}
                        placeholder="Contact Number"
                        isMandatory={false}
                        type="number"
                        limit='10'
                        uniqueKey="contactNumber"
                        
                        defaultValue={serverResponse?.supplierDetails?.contactNumber}
                         handleGetValues={handleGetValues}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                    
                    </div>
                    
                
                
                        
                    </div>
                } 

         </div>
         <div>
            {/* <FileUploader
                tabIndex={12}
                label="Spare Images"
                uniqueKey="Images"
                typeOfRecord={"Files"}
                title="Documents"
                isMandatory={false}
                limit={10}
                fileSizeInMB={10}
                acceptableFileTypes={[".jpg", ".jpeg", ".pdf", ".docs"]}
                // handleGetSelectedData={handleGetValues}
                // defaultValue={serverResponse?.documents}
            /> */}
            <FileUploader
              limit={5}
              tabIndex={17}
              fileSizeInMB={5}
              isMandatory={false}
              title={"images"}
              uniqueKey="images"
              label={"Spare Image"}
              typeOfRecord={"images"}
              acceptableFileTypes={[".jpg", ".png", ".jpeg"]}
              handleGetSelectedData={handleGetValues}
               defaultValue={serverResponse?.images?.length ? serverResponse?.images : []}
            />
         </div>
          
         
        </section>
        <footer className={Styles.spares_gen_details_footer}>
                  <div>
                    <ClonosButton
                            variant="outlined"
                            onClick={() => setLoadersAndFlags(prev => ({...prev,showCancelSpareAlert:true}))}>Cancel</ClonosButton>
                      
                      {mode === "create" && <ClonosButton  variant="outlined" onClick={() => setLoadersAndFlags(prev => ({...prev,showDraftSpareAlert:true}))}>Save as Draft</ClonosButton>}       
                      <ClonosButton
                            loading={loadersAndFlags?.saveSparesLoading}
                            variant="filled"
                            onClick={handleSubmitSpares}
                        > 
                        {mode === "edit" ? "Update" : "Submit"}
                        </ClonosButton>
                    
                  </div>
                </footer >

    </div>
   
   </Card>

      <ClonosConfirmationBox
            isOpen={loadersAndFlags?.showDraftSpareAlert}
            confirmingMethod={() => {  
                const next = () => {
                      setLoadersAndFlags(prev => ({...prev,showDraftSpareAlert:false}));
                      navigate('/spares')
                };
                
              handleDraftSpares({dispatch,payload:formData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,draftSpareLoading:!prev.draftSpareLoading})),next})
            }}
            loading={loadersAndFlags?.draftWorkOrderLoading}
            closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showDraftSpareAlert:false}))}
            headerTitle="Draft Spare"
            message="Are you sure, You want to draft this Spare ?"
      />
      <ClonosConfirmationBox
            isOpen={loadersAndFlags.showCancelSpareAlert}
            confirmingMethod={() => {
                  setLoadersAndFlags(prev => ({...prev,showCancelSpareAlert:false}));
                  navigate(-1)
            }}
            closeModalMethod={() => setLoadersAndFlags(prev => ({...prev,showCancelSpareAlert:false}))}
            headerTitle="Spare Creation."
            message="Do you confirm that you are want to cancel the Spare creation?"
      />
   </>
  )
   }
 return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default CreateSpares



                         