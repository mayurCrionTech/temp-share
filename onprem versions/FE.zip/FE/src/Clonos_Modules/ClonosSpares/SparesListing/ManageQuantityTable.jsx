import React, { useState,useEffect } from 'react'
import { Card } from '@material-ui/core'
import ClonosDataGrid from '../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { doGetApiCall, doPatchApiCall } from '../../../utils/ClonosApi'
import AppUrl from '../../../utils/AppUrl'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import useToggler from '../../../CustomHooks/TogglerHook'
import useModuleNameProvider from '../../../CustomHooks/ModuleNameProviderHook'
import { checkUserHasPermission, commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone, handleLoggedInUser, handleShowErrorAndWarning } from '../../../utils/clonosCommon'
import { handleGetAllQuantities } from '../SparesManager/spares-manager'
import { setSerialNumber } from '../../../utils/clonosCommon'
import { statusStyleStaticData, statusStaticData } from '../../../Constants/StaticData'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import AddQuantityModal from './AddQuantityModal'
import { handleGetAllSpares } from '../SparesManager/spares-manager'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant'

function ManageQuantityTable({searchedResult}) {
      const dispatch = useDispatch();
      const navigate = useNavigate();
      const [isLoading, setIsLoading] = useToggler(); 
      const [manageQuanity,setManageQuanity] = useState({});
      const [pagination, setPagination] = useState(commonPageState);
      const [selectedRows, setSelectedRows] = useState([]);
      const [selectedRow, setSelectedRow] = useState(null);
      const [refreshApi, setRefreshApi] = useToggler();
      const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
      const [workOrderStatuses, setWorkOrderStatuses] = useState({});
      const [refreshStatusCount, setRefreshStatusCount] = useToggler();
      const moduleName = useModuleNameProvider();
      const [showAddQuantityModal, setShowAddQuantityModal]=useState(false)
      
      const user = handleLoggedInUser()
    
      const isOperator = user?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR;
      
   const columns = [
          {
              field: "index",
              headerName: "SI.No",
              // flex: 1,
              width: 70,
              disableColumnFilter: true,
              headerClassName: "datadrid_common_header",
          },
          {
              field: "spare",
              headerName: "SPARE NAME",
              // width: 150,
              flex: 1,
              headerAlign:"center",
              //  align:"center",
              disableColumnFilter: true,
              headerClassName: "datadrid_common_header",
              // filterPanelClassName: "datadrid_common_header",
               renderCell: (params) => {
            
                return <p onClick={() => handleGotManageQtyView(params?.row?.spare?.id, params?.row?.spare?.name, (params?.row?.spare?.id || params?.row?.spare?.name))} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.spare?.name || "-"}</p>
              }
          },
          {
              field: "quantity",
              headerName: "QUANTITY",
              // width: 150,
              flex: 1,
               headerAlign:"center",
               align:"center",
              disableColumnFilter: true,
              headerClassName: "datadrid_common_header",
              // renderCell: (params) => {
              //     return <p onClick={() => handleGotoWOV(params?.row?.id, params?.row?.name, (params?.row?.name || params?.row?.id))} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>
              // }
          },
          {
              field: "units",
              headerName: "UNITS",
              width: 100,
               headerAlign:"center",
    align:"center",
              // flex: 1,
              disableColumnFilter: true,
              headerClassName: "datadrid_common_header",
              // valueGetter: (params) => params?.row?.endAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params?.row?.endAt,parseType:"string"})) : "-"
          },
          {
              field: "expiryDate",
              headerName: "EXPIRY DATE",
              // width: 100,
              flex: 1,
               headerAlign:"center",
               align:"center",
              disableColumnFilter: true,
              headerClassName: "datadrid_common_header",
              valueGetter: (params) => params?.row?.expiryDate ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params?.row?.expiryDate,parseType:"string"})) : "-"
          },
          {
              field: "status",
              headerName: "STATUS",
              // width: 250,
              flex: 1,
               headerAlign:"center",
               align:"center",
              disableColumnFilter: true,
              headerClassName: "datadrid_common_header",
              // valueGetter: (params) => params?.row?.status || "-"
              renderCell: (params) => {
                  return <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{params?.row?.status ? statusStaticData[params?.row?.status] : "-"}</p>
              }
          },
        //   {
        //   field: "action",
        //   headerName: "ACTION",
        //   flex: 1,
        //   disableColumnFilter: true,
        //   headerClassName: "datadrid_common_header",
        //   renderCell: (params) => {
        //     const row = params.row; 
        //     console.log(row,"quantity")     
        //     const isPending = row?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL;
        //     const isResubmit = row?.status === "resubmit";
        //     const rowId=params?.row?.id
  
        //     if (isPending) {
        //       return (
        //         <>
        //           <ClonosButton
        //             onClick={() => handleSpareApproveQuantity(rowId)}
        //             variant="filled"
        //             style={{
        //               border: "1px solid #06337E",
        //               fontSize: "16px",
        //               padding: "0.5rem 1rem",
        //               width: "100%",
        //               marginRight: "0.5rem",
        //             }}
        //           >
        //             Approve
        //           </ClonosButton>
        //           &nbsp; &nbsp;
        //           <ClonosButton
        //             onClick={() => handleSpareRejectQuantity(rowId)}
        //             variant="outlined"
        //             style={{
        //               fontSize: "16px",
        //               padding: "0.5rem 1rem",
        //               width: "100%",
        //             }}
        //           >
        //             Reject
        //           </ClonosButton>
        //         </>
        //       );
        //     }

        //     if (isResubmit) {
        //       return (
        //         <ClonosButton
        //           variant="filled"
        //           onClick={() => {
        //             setSelectedRow(row);
        //             setShowAddQuantityModal(true);
        //           }}
        //           style={{
        //             fontSize: "16px",
        //             padding: "0.5rem 1rem",
        //           }}
        //         >
        //           Edit
        //         </ClonosButton>
        //       );
        //     }

        //     return null;
        //   },
        // }
      ]
       
      if(!isOperator){
        columns.push({
          field: "action",
          headerName: "ACTION",
          flex: 1.5,
          disableColumnFilter: true,
          headerClassName: "datadrid_common_header",
           headerAlign:"center",
           align:"center",
          renderCell: (params) => {
            const row = params.row; 
            
            const isPending = row?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL;
            const isResubmit = row?.status === "resubmit";
            const rowId=params?.row?.id
            const isApprover = user?.name === row?.spare?.approver?.name
            
            if (isApprover && isPending) {
              return (
                <>
                  <ClonosButton
                    onClick={() => handleSpareApproveQuantity(rowId)}
                    variant="filled"
                    style={{
                      border: "1px solid #06337E",
                      fontSize: "16px",
                      padding: "0.5rem 1rem",
                      width: "120px",
                      marginRight: "0.5rem",
                      height: "32px",
                    }}
                  >
                    Approve
                  </ClonosButton>
                  &nbsp; &nbsp;
                  <ClonosButton
                    onClick={() => handleSpareRejectQuantity(rowId)}
                    variant="outlined"
                    style={{
                      border: "1px solid #06337E",
                      fontSize: "16px",
                      padding: "0.5rem 1rem",
                      width: "120px",
                      marginRight: "0.5rem",
                      height: "32px",
                    }}
                  >
                    Reject
                  </ClonosButton>
                </>
              );
            }

            if (!isApprover && isResubmit) {
              return (
                <ClonosButton
                  variant="filled"
                  onClick={() => {
                    setSelectedRow(row);
                    setShowAddQuantityModal(true);
                  }}
                  style={{
                      border: "1px solid #06337E",
                      fontSize: "16px",
                      padding: "0.5rem 1rem",
                      width: "130px",
                      marginRight: "0.5rem",
                      height: "32px",
                    }}
                >
                  Edit
                </ClonosButton>
              );
            }

            return '-';
          },
        })
      }
   
         const handleGotManageQtyView = (spareId, spareName, spareNameOrId) => {
        navigate(`/view-spare/${spareNameOrId}`, { state: { spareId, spareName } })
    }
      
     const handleSpareApproveQuantity =(quantityId)=>{
          const url = `/spares/quantities/${quantityId}/approve`
           doPatchApiCall({url}).then((res)=>{
       
              setRefreshApi()
              handleShowErrorAndWarning({dispatch,type: "success", message: `Spare approved successfully`, showTime: 5000 })
           })
     }
     
     const handleSpareRejectQuantity=(quantityId)=>{
            const url = `/spares/quantities/${quantityId}/reject`
           doPatchApiCall({url}).then((res)=>{
            
              setRefreshApi()

              handleShowErrorAndWarning({dispatch,type: "success", message: `Spare rejected successfully`, showTime: 5000 })
           })
     }

       useEffect(() => {
              handleGetAllQuantities({setterMethod:setManageQuanity,setIsLoading,pagination})
          },[pagination?.page,pagination?.limit,refreshApi])

  
  return (
   <>
      <div style={{ padding: "1rem 1rem", height: "90%" }}>
        <ClonosDataGrid
          rows={setSerialNumber(searchedResult ? searchedResult?.data : manageQuanity?.data,pagination?.page,pagination?.limit)}
          columns={columns}
          // isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
          // isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
          uniqueIdField="id"
          onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          isLoading={isLoading}
           totalCount={searchedResult ? searchedResult?.totalDataCount  : manageQuanity?.totalDataCount}
          pageLimit={pagination.limit}
          // checkboxSelection={isOperator? false : true}
           checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
          handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
        />
      </div>

        {
          showAddQuantityModal && <AddQuantityModal  mode={"edit"} setRefreshApi={setRefreshApi} data={selectedRow} isOpen={showAddQuantityModal} closeMethod={setShowAddQuantityModal}/>
        }
   </>
  )
}

export default ManageQuantityTable