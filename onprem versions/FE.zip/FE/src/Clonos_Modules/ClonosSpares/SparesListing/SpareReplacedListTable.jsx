import React, { useState,useEffect } from 'react'
import { Card } from '@material-ui/core'
import ClonosDataGrid from '../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { doGetApiCall, doPatchApiCall } from '../../../utils/ClonosApi'
import AppUrl from '../../../utils/AppUrl'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import useToggler from '../../../CustomHooks/TogglerHook'
import useModuleNameProvider from '../../../CustomHooks/ModuleNameProviderHook'
import { checkUserHasPermission, commonPageState, handleLoggedInUser, handleShowErrorAndWarning } from '../../../utils/clonosCommon'
import { handleGetAllRequestedList, handleGetAllSpares,handleGetAllReplacedList } from '../SparesManager/spares-manager'
import { setSerialNumber } from '../../../utils/clonosCommon'
import { statusStyleStaticData, statusStaticData } from '../../../Constants/StaticData'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant'
import EditSpareReplacedModal from './EditSpareReplacedModal'

function SpareReplacedListTable({searchedResult}) {

   const dispatch = useDispatch();
             const navigate = useNavigate();
             const [isLoading, setIsLoading] = useToggler(); 
             const [replacedSpareList,setReplacedSpareList] = useState({});
             const [pagination, setPagination] = useState(commonPageState);
             const [selectedRows, setSelectedRows] = useState([]);
             const [selectedRow, setSelectedRow] = useState(null);
             const [refreshApi, setRefreshApi] = useToggler();
             const [showEditSpareReplacedlistModal,setShowEditSpareReplacedlistModal]=useToggler()
             const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
             const [workOrderStatuses, setWorkOrderStatuses] = useState({});
             const [refreshStatusCount, setRefreshStatusCount] = useToggler();
             const moduleName = useModuleNameProvider();
            
             const user = handleLoggedInUser()
             const isOperator = user?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR;
            


                 const columns = [
               {
                 field: "index",
                 headerName: "SI.No",
                 width: 70,
                 disableColumnFilter: true,
                 headerClassName: "datadrid_common_header",
               },
               {
                 field: "spareName",
                 headerName: "SPARE NAME",
                //  width: 240,
                 headerAlign: "center",
                 flex:1.5,
                 disableColumnFilter: true,
                 headerClassName: "datadrid_common_header",
                 renderCell: (params) => {
                  const row = params?.row;
                  const name = row?.spare?.name?.trim() ?? '';
                  const specification = row?.spare?.specification?.trim() ?? '';
                  return (
                     <p
           
                        onClick={() => handleGotoSpareView(row?.spare?.id, name, name)}
                        style={{
                          textDecoration: "underline",
                          color: "#3f51b5",
                          cursor: "pointer",
                          margin: 0,
                          whiteSpace: "nowrap", // Optional: Prevent wrapping
                        }}
                      >
                        {name}
                      </p>
                  );
                }

               },
               {
                 field: "replacedQuantity",
                 headerName: "REPLACED QUANTITY",
                 flex:1,
                //  width: 180,
                  headerAlign: "center",
                 align: "center",
                 disableColumnFilter: true,
                 headerClassName: "datadrid_common_header",
               },
               
             
               // ✅ Conditionally add ACTION column for non-Operator users
               ...(!isOperator
                 ? [
                     {
                       field: "action",
                       headerName: "ACTION",
                       flex: 1.5,
                       disableColumnFilter: true,
                       headerAlign: "center",
                       align: "center",
                       headerClassName: "datadrid_common_header",
                       headerAlign: "center",
                       align: "center",
                       renderCell: (params) => {
                         const row = params.row;
                         
                        //  const isPending =
                        //    row?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL;
                         // const isResubmit = row?.status === "resubmit";
                         const rowId = row?.id;
             
                           return (
                            
                             <ClonosButton
                               variant="filled"
                               onClick={() => {
                                 setSelectedRow(row);
                                 setShowEditSpareReplacedlistModal(true);

                               }}
                               style={{
                                  border: "1px solid #06337E",
                                  fontSize: "16px",
                                  padding: "0.5rem 1rem",
                                  width: "120px",
                                  marginRight: "0.5rem",
                                  height: "32px",
                                }}
                             >
                               Edit
                             </ClonosButton>
                           );
                         
             
                         return null;
                       },
                     },
                   ]
                 : []),
             ];
  


  const handleGotoSpareView = (spareId, spareName, spareNameOrId) => {
        navigate(`/view-spare/${spareNameOrId}`, { state: { spareId, spareName } })
    }


   useEffect(()=>{
       handleGetAllReplacedList({setterMethod:setReplacedSpareList,setIsLoading,pagination})
   },[refreshApi,pagination?.page, pagination?.limit])

  return (
     <>
      <div style={{ padding: "1rem 1rem", height: "90%" }}>
        <ClonosDataGrid
          rows={setSerialNumber(searchedResult ? searchedResult?.data : replacedSpareList?.data,pagination?.page,pagination?.limit)}
          columns={columns}
  //           isEditMethod={selectedRowData &&
  // selectedRowData.approver?.name !== user?.name &&
  // selectedRowData.status === CLONOS_GLOBAL_STATUS_APPROVED
  //   ? handleGoToSpareEdit
  //   : null}
          // isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
          // isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
          uniqueIdField="id"
          onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          isLoading={isLoading}
          totalCount={searchedResult ? searchedResult?.totalDataCount  : replacedSpareList?.totalDataCount}
          pageLimit={pagination.limit}
          //checkboxSelection={isOperator? false : true}
          checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
          handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
        />
      </div>

        {
          showEditSpareReplacedlistModal && <EditSpareReplacedModal  data={selectedRow} isOpen={showEditSpareReplacedlistModal} closeMethod={setShowEditSpareReplacedlistModal} setRefreshApi={setRefreshApi}/>
        }
   </>
  )
}

export default SpareReplacedListTable