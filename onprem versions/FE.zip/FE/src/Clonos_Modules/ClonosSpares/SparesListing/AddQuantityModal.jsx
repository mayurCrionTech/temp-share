import React, { useState } from 'react'
import Modal from '../../../components/CommonComponents/Modal/Modal'
import Styles from './add-quantity-modal.module.css'
import CloseIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import ClonosInput from '../../../components/CommonComponents/ClonosInput/ClonosInput'
import ClonosSelect from '../../../components/CommonComponents/ClonosSelect/ClonosSelect'
import useFieldsChecker from '../../../CustomHooks/FieldsValidatorHook'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import ClonosConfirmationBox from '../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { handleGetFilledValuesOfSpares, handleUpdateQuantity } from '../SparesManager/spares-manager'
import { handleAddQuantity } from '../SparesManager/spares-manager'
import { handleClientDateInConfiguredTimeZone } from '../../../utils/clonosCommon'
import useToggler from '../../../CustomHooks/TogglerHook'
import { useDispatch } from 'react-redux'
import { doGetApiCall } from '../../../utils/ClonosApi'

/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/

function AddQuantityModal({ data,isOpen, closeMethod ,mode, setRefreshApi }) {

    const [showConfirmationDialog,setShowConfirmationDialog]=useState(false)
    const [formData, setFormData] = useState({});
    const [isLoading,setIsLoading]= useState(false)
    const dispatch =useDispatch()
     const [loadingDropdowns, setLoadingDropdowns] = useState({});
   const [staticDropdownData,setStaticDropdownData]=useState({});
  
     const {
          handleGetErrorActivatorInformation,
          handlePrimaryObjectModifier,
          handleSubmit,
          handleGetUpdatedPrimaryObject,
          handleRemoveField,
          primaryObject
        } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "addQuantity" });

   const handleGetValues = (props) => {
       handleGetFilledValuesOfSpares({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier,formData})
  }
  const handleQuantity = ()=>{
         if(mode=="edit"){
              handleUpdateQuantity({dispatch,handleSubmit,setRefreshApi, formData, setIsLoading: () => setIsLoading(prev => !prev ), closeMethod ,quantityId: data?.id ,spareId:data?.spare?.id})
         }else{
              handleAddQuantity({dispatch, handleSubmit, formData,setRefreshApi, setIsLoading: () => setIsLoading(prev => !prev ), closeMethod ,spareId: data?.id, units:data?.units})
         }
  }

  console.log(formData,"formData")
    const fetchStaticDropdownByCode = async (code) => {
  if (staticDropdownData[code] || loadingDropdowns[code]) return;

  setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

  try {
    const res = await doGetApiCall({url:`dropdowns/${code}`});
       
    setStaticDropdownData(prev => ({
      ...prev,
      [code]: res?.data?.result?.options
    }));
  } finally {
    setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
  }
};

  return (
   <>
     <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
                  <div className={Styles.container}>
                      <div className={Styles.header}>
                          <h4> {mode=="edit"? `Edit` : `Add`} Quantity </h4>
                          <CloseIcon onClick={() => closeMethod(false)} />
                      </div>
                      <div className={Styles.section}>
                          <div style={{ display: "flex", justifyContent: "space-between", flexWrap:"wrap" }}>
                            <h6>
                                Spare Name: <span className={Styles?.text}>{mode=="edit" ? data?.spare?.name : data?.name}</span>
                            </h6>
                            <h6>
                                Present Quantity: <span className={Styles?.text}>{data?.quantity}</span>
                            </h6>
                            </div>

                          <div className={Styles.quantity_units_selector_container}>
                                    <ClonosInput
                                      label="Quantity"
                                      isLabel={true}
                                      placeholder="Quantity"
                                      isMandatory={true}
                                      type="number"
                                      limit='8'
                                      uniqueKey="quantity"
                                      defaultValue={mode=="edit" && data?.quantity}
                                        handleGetValues={handleGetValues}
                                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                    <ClonosSelect
                                    type="select"
                                    label="Units"
                                    isMandatory={true}
                                    isLabel={true}
                                    uniqueKey="units"
                                    disabled={true}
                                    placeholder="Select"
                                    options={[{ label: "mm", value: "units", isNeeded: true },{ label: "Litres", value: "units", isNeeded: true },{ label: "No's", value: "units", isNeeded: true }]}
                                    handleGetValues={handleGetValues}
                                    defaultValue={data?.units}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />          
                               </div>
                               <div className={Styles.cost_units_selector_container}>
                                <ClonosInput
                                    label="Cost"
                                    isLabel={true}
                                    placeholder="Cost"
                                    isMandatory={false}
                                    type="number"
                                    limit='8'
                                    uniqueKey="cost"
                                    defaultValue={mode=="edit" && data?.cost}
                                    handleGetValues={handleGetValues}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />
                                <ClonosSelect
                                        
                                        type="select"
                                        label="Units"
                                        isMandatory={false}
                                        isLabel={true}
                                        uniqueKey="costUnits"
                                        placeholder="Select"
                                        // options={[{ label: "INR", value: "unitOfCost", isNeeded: true }]}
                                        options={staticDropdownData?.costUnits?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))||[]}
                                        onOpen={() => fetchStaticDropdownByCode("costUnits")} 
                                        // disabled={true}
                                        handleGetValues={handleGetValues}
                                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                               </div>
                          <ClonosInput
                                             
                                label="Expiry Date"
                                isLabel={true}
                                isMinimum={true}
                                placeholder="Expiry Date"
                                isMandatory={false}
                                type="datetime-local"
                            //  disabled={(mode === "edit" && generalDetails?.logStatus !== "draft") ? true : false}
                                min={true}
                                uniqueKey="expiryDate"
                             defaultValue={mode === "edit" && (() => {
                               const parsedString = handleClientDateInConfiguredTimeZone({ dateString: data?.expiryDate, parseType: "object" });
                               return `${parsedString?.year}-${parsedString?.month}-${parsedString?.day}T${parsedString?.hour}:${parsedString?.minute}`
                             })()}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                 handleGetValues={handleGetValues}
                            />
                      </div>
                      
                      <div className={Styles.footer}>
                          <div>
                              <ClonosButton onClick={() => setShowConfirmationDialog(true)}>Cancel</ClonosButton>
                              <ClonosButton
                                  // loading={loadings.generateReportLoading}
                                  variant="filled"
                                //   onClick={() => handleAddQuantity({ handleSubmit, formData, setIsLoading: () => setIsLoading(prev => (!prev)), closeMethod ,spareId: data?.id})}
                                onClick={handleQuantity}
                              >
                                 {mode=="edit"? `Update`: `Add`} Quantity
                              </ClonosButton>
                          </div>
                      </div>
                  </div>
                 </Modal>
                 
                 <ClonosConfirmationBox
                     isOpen={showConfirmationDialog}
                     closeModalMethod={setShowConfirmationDialog}
                     confirmingMethod={() => {
                         closeMethod(false);
                         setShowConfirmationDialog(false);
                     }}
                     rejectingMethod={() => setShowConfirmationDialog(false)}
                     message={"Are you sure to cancel ?"}
                     headerTitle={"Cancel"}
                 />
   </>
  )
}

export default AddQuantityModal