import React, { useState,useEffect } from 'react'
import { Card } from '@material-ui/core'
import ClonosDataGrid from '../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { doGetApiCall, doPatchApiCall } from '../../../utils/ClonosApi'
import AppUrl from '../../../utils/AppUrl'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import useToggler from '../../../CustomHooks/TogglerHook'
import useModuleNameProvider from '../../../CustomHooks/ModuleNameProviderHook'
import { checkUserHasPermission, commonPageState, handleLoggedInUser, handleShowErrorAndWarning } from '../../../utils/clonosCommon'
import { handleGetAllRequestedList, handleGetAllSpares } from '../SparesManager/spares-manager'
import { setSerialNumber } from '../../../utils/clonosCommon'
import { statusStyleStaticData, statusStaticData } from '../../../Constants/StaticData'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant'


function SpareRequestListTable({searchedResult}) {
  
      const dispatch = useDispatch();
           const navigate = useNavigate();
           const [isLoading, setIsLoading] = useToggler(); 
           const [requestedSpareList,setRequestedSpareList] = useState({});
           const [pagination, setPagination] = useState(commonPageState);
           const [selectedRows, setSelectedRows] = useState([]);
           const [selectedRow, setSelectedRow] = useState(null);
           const [refreshApi, setRefreshApi] = useToggler();
           const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
           const [workOrderStatuses, setWorkOrderStatuses] = useState({});
           const [refreshStatusCount, setRefreshStatusCount] = useToggler();
           const moduleName = useModuleNameProvider();
          
           const user = handleLoggedInUser()
            const isOperator = user?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR;
          

    //  const columns = [
    //         {
    //             field: "index",
    //             headerName: "SI.No",
    //             // flex: 1,
    //             width: 70,
    //             disableColumnFilter: true,
    //             headerClassName: "datadrid_common_header",
    //         },
    //         {
    //             field: "spareName",
    //             headerName: "SPARE NAME",
    //             width: 240,
    //             // flex: 1,
    //             disableColumnFilter: true,
    //             headerClassName: "datadrid_common_header",
    //             // filterPanelClassName: "datadrid_common_header",
    //             //  renderCell: (params) => {
    //             //   console.log(params,"params")
    //             //   return <p onClick={() => handleGotManageQtyView(params?.row?.spare?.id, params?.row?.spare?.name, (params?.row?.spare?.id || params?.row?.spare?.name))} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.spare?.name || "-"}</p>
    //             // }
    //         },
    //         {
    //             field: "requestedQuantity",
    //             headerName: "REQUESTED QUANTITY",
    //             width: 180,
    //             // flex: 1,
    //             align:"center",
    //             disableColumnFilter: true,
    //             headerClassName: "datadrid_common_header",
    //             // renderCell: (params) => {
    //             //     return <p onClick={() => handleGotoWOV(params?.row?.id, params?.row?.name, (params?.row?.name || params?.row?.id))} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>
    //             // }
    //         },
            
    //         {
    //             field: "status",
    //             headerName: "STATUS",
    //             // width: 230,
    //             flex: 1,
    //             disableColumnFilter: true,
    //             headerAlign:"center",
    //             align:"center",
    //             headerClassName: "datadrid_common_header",
    //             // valueGetter: (params) => params?.row?.status || "-"
    //             renderCell: (params) => {
    //                 return <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{params?.row?.status ? statusStaticData[params?.row?.status] : "-"}</p>
    //             }
    //         },
    //        if(CLONOS_GLOBAL_USER_TYPE_OPERATOR !== user?.userType?.name){
    //           {
    //         field: "action",
    //         headerName: "ACTION",
    //         flex: 1,
    //         disableColumnFilter: true,
    //         headerAlign:"center",
    //         align:"center",
    //         headerClassName: "datadrid_common_header",
    //         renderCell: (params) => {
    //           const row = params.row; 
    //           console.log(row,"quantity")     
    //           const isPending = row?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL;
    //           console.log(isPending,"statuscheck")
    //           const isResubmit = row?.status === "resubmit";
    //           const rowId=params?.row?.id
             

    //           if (isPending) {
    //             return (
    //               <>
    //                 <ClonosButton
    //                   // onClick={() => handleSpareApproveQuantity(rowId)}
    //                   variant="filled"
    //                   style={{
    //                     border: "1px solid #06337E",
    //                     fontSize: "16px",
    //                     padding: "0.5rem 1rem",
    //                     width: "130px",
    //                     marginRight: "0.5rem",
    //                     height:"32px"
    //                   }}
    //                 >
    //                   Approve
    //                 </ClonosButton>
    //                 &nbsp; &nbsp;
    //                 <ClonosButton
    //                   // onClick={() => handleSpareRejectQuantity(rowId)}
    //                   variant="outlined"
    //                   style={{
    //                     fontSize: "16px",
    //                     padding: "0.5rem 1rem",
    //                     width: "130px",
    //                     height:"32px"
    //                   }}
    //                 >
    //                   Reject
    //                 </ClonosButton>
    //               </>
    //             );
    //           }
  
    //           if (isResubmit) {
    //             return (
    //               <ClonosButton
    //                 variant="filled"
    //                 onClick={() => {
    //                   setSelectedRow(row);
    //                   // setShowAddQuantityModal(true);
    //                 }}
    //                 style={{
    //                   fontSize: "16px",
    //                   padding: "0.5rem 1rem",
    //                    width: "130px",
    //                    height:"32px"
    //                 }}
    //               >
    //                 Edit
    //               </ClonosButton>
    //             );
    //           }
  
    //           return null;
    //         },
    //       }
    //        }
            
    //     ]
   
    

    const columns = [
  {
    field: "index",
    headerName: "SI.No",
    width: 70,
    disableColumnFilter: true,
    headerClassName: "datadrid_common_header",
  },
  {
    field: "spareName",
    headerName: "SPARE NAME",
    flex:1.5,
    headerAlign: "center",
    disableColumnFilter: true,
    headerClassName: "datadrid_common_header",
     renderCell: (params) => {
      const row = params?.row;
      const name = row?.spare?.name?.trim() ?? '';
      return (
        <p
           
          onClick={() => handleGotoSpareView(row?.spare?.id, name, name)}
          style={{
            textDecoration: "underline",
            color: "#3f51b5",
            cursor: "pointer",
            margin: 0,
            whiteSpace: "nowrap", // Optional: Prevent wrapping
          }}
        >
          {name}
        </p>
      );
    }
  },
  {
    field: "requestedQuantity",
    headerName: "REQUESTED QUANTITY",
    // width: 180,
    flex:1,
    headerAlign: "center",
    align: "center",
    disableColumnFilter: true,
    headerClassName: "datadrid_common_header",
  },
  {
    field: "status",
    headerName: "STATUS",
    flex: 1.5,
    disableColumnFilter: true,
    headerAlign: "center",
    align: "center",
    headerClassName: "datadrid_common_header",
    renderCell: (params) => {
      return (
        <p
          style={{
            ...statusStyleStaticData[params?.row?.status],
            padding: "0.25rem 0.5rem",
            borderRadius: "0.25rem",
            cursor: "default",
          }}
        >
          {params?.row?.status ? statusStaticData[params?.row?.status] : "-"}
        </p>
      );
    },
  },

  // ✅ Conditionally add ACTION column for non-Operator users
  ...(!isOperator
    ? [
        {
          field: "action",
          headerName: "ACTION",
          flex: 1.5,
          disableColumnFilter: true,
          headerAlign: "center",
          align: "center",
          headerClassName: "datadrid_common_header",
          renderCell: (params) => {
            const row = params.row;
         
            const isPending =
              row?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL;
            // const isResubmit = row?.status === "resubmit";
            const rowId = row?.id;
            const isApprover = user?.name === row?.spare?.approver?.name
            if (isApprover && isPending) {
              return (
                <>
                  <ClonosButton
                    onClick={() => handleSpareRequestApprove(rowId)}
                    variant="filled"
                    style={{
                      border: "1px solid #06337E",
                      fontSize: "16px",
                      padding: "0.5rem 1rem",
                      width: "120px",
                      marginRight: "0.5rem",
                      height: "32px",
                    }}
                  >
                    Approve
                  </ClonosButton>
                  &nbsp;&nbsp;
                  <ClonosButton
                    onClick={() => handleSpareRequestReject(rowId)}
                    variant="outlined"
                    style={{
                      fontSize: "16px",
                      padding: "0.5rem 1rem",
                      width: "110px",
                      height: "32px",
                    }}
                  >
                    Reject
                  </ClonosButton>
                </>
              );
            }

            // if (isResubmit) {
            //   return (
            //     <ClonosButton
            //       variant="filled"
            //       onClick={() => {
            //         setSelectedRow(row);
            //         // setShowAddQuantityModal(true);
            //       }}
            //       style={{
            //         fontSize: "16px",
            //         padding: "0.5rem 1rem",
            //         width: "130px",
            //         height: "32px",
            //       }}
            //     >
            //       Edit
            //     </ClonosButton>
            //   );
            // }

            return '-';
          },
        },
      ]
    : []),
];


const handleGotoSpareView = (spareId, spareName, spareNameOrId) => {
        navigate(`/view-spare/${spareNameOrId}`, { state: { spareId, spareName } })
    }


   const handleSpareRequestApprove =(spareRequestedId)=>{

            const url = `/spares/spareRequested/${spareRequestedId}/approve`
             doPatchApiCall({url}).then((res)=>{
          
                setRefreshApi()
                handleShowErrorAndWarning({dispatch,type: "success", message: `Spare request approved successfully`, showTime: 5000 })
             })
       }
       
       const handleSpareRequestReject=(spareRequestedId)=>{
 
              const url = `/spares/spareRequested/${spareRequestedId}/reject`
             doPatchApiCall({url}).then((res)=>{
            
                setRefreshApi()
  
                handleShowErrorAndWarning({dispatch,type: "success", message: `Spare request rejected successfully`, showTime: 5000 })
             })
       }



   useEffect(()=>{
      handleGetAllRequestedList({setterMethod:setRequestedSpareList,setIsLoading,pagination})
   },[refreshApi,pagination?.page, pagination?.limit])
   
  

  return (
        <>
      <div style={{ padding: "1rem 1rem", height: "90%" }}>
        <ClonosDataGrid
          rows={setSerialNumber(searchedResult ? searchedResult?.data : requestedSpareList?.data,pagination?.page,pagination?.limit)}
          columns={columns}
  //           isEditMethod={selectedRowData &&
  // selectedRowData.approver?.name !== user?.name &&
  // selectedRowData.status === CLONOS_GLOBAL_STATUS_APPROVED
  //   ? handleGoToSpareEdit
  //   : null}
          // isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
          // isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
          uniqueIdField="id"
          onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          isLoading={isLoading}
          totalCount={searchedResult ? searchedResult?.totalDataCount  : requestedSpareList?.totalDataCount}
          pageLimit={pagination.limit}
          //checkboxSelection={isOperator? false : true}
          checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
          handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
        />
      </div>

        {/* {
          showAddQuantityModal && <AddQuantityModal  data={selectedRow} isOpen={showAddQuantityModal} closeMethod={setShowAddQuantityModal} />
        } */}
   </>
  )
}

export default SpareRequestListTable