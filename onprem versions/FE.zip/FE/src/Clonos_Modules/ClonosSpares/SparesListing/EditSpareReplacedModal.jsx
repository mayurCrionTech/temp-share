import React, { useState } from 'react'
import Modal from '../../../components/CommonComponents/Modal/Modal'
import Styles from './edit-spare-replaced.module.css'
import CloseIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import ClonosInput from '../../../components/CommonComponents/ClonosInput/ClonosInput'
import ClonosSelect from '../../../components/CommonComponents/ClonosSelect/ClonosSelect'
import useFieldsChecker from '../../../CustomHooks/FieldsValidatorHook'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import ClonosConfirmationBox from '../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { handleGetFilledValuesOfSpares, handleUpdateQuantity,handleEditReplacedSpare } from '../SparesManager/spares-manager'
import { handleAddQuantity } from '../SparesManager/spares-manager'
import { handleClientDateInConfiguredTimeZone, handleShowErrorAndWarning } from '../../../utils/clonosCommon'
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';
import { fontGrid } from '@mui/material/styles/cssUtils'
import { useDispatch } from 'react-redux'

function EditSpareReplacedModal({ data,isOpen, closeMethod, setRefreshApi }) {
    const [showConfirmationDialog,setShowConfirmationDialog]=useState(false)
    const [formData, setFormData] = useState({quantity:data?.replacedQuantity});
    const [isLoading,setIsLoading]= useState(false)
    const dispatch =useDispatch()
  
     const {
          handleGetErrorActivatorInformation,
          handlePrimaryObjectModifier,
          handleSubmit,
          handleGetUpdatedPrimaryObject,
          handleRemoveField,
          primaryObject
        } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "addQuantity" });

   const handleGetValues = (props) => {
       handleGetFilledValuesOfSpares({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier,formData})
  }


  const handleSave =()=>{
        if(formData?.quantity > data?.replacedQuantity){
          return  handleShowErrorAndWarning({dispatch,message:"Return Quantity Can't be greater than Available Replaced Quantity",type:"error",showTime:"5000"})
        }
        handleEditReplacedSpare({dispatch, handleSubmit, formData,setRefreshApi, setIsLoading: () => setIsLoading(prev => !prev ), closeMethod ,spareReplacedId: data?.id})
  }

  return (
   <>
     <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
                  <div className={Styles.container}>
                      {/* <div className={Styles.header}>
                          <h4> Enter the Return Quantity  </h4>
                          <CloseIcon onClick={() => closeMethod(false)} />
                      </div> */}
                       <div className={Styles.header}>
                        <h4 style={{ display: 'flex', alignItems: 'center' }}>
                          Enter the Return Quantity
                          <span
                            data-tooltip-id="return-quantity-tooltip"
                            data-tooltip-content="Fill in the quantity of spare parts you want to return"
                          >
                            <InfoOutlinedIcon
                              style={{
                                fontSize: 24,
                                cursor: 'pointer',
                                marginTop: 15,
                                marginLeft: 8,
                                color: '#06337E'
                              }}
                            />
                          </span>
                          <Tooltip id="return-quantity-tooltip" place="bottom" effect="solid" 
                          style={{
                          backgroundColor: '#E6EBF2',      // dark gray
                          color: '#06337E',                // white text
                          fontSize: 12,
                          fontFamily: 'Segoe UI, sans-serif',
                          borderRadius: '6px',
                          padding: '6px 10px',
                          maxWidth: '250px',
                          lineHeight: 1.4,
                          boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
                        }}/>
                        </h4>
                        <CloseIcon onClick={() => closeMethod(false)} style={{ cursor: 'pointer' }} />
                      </div>

                      <div className={Styles.section}>
                        

                          {/* <div className={Styles.quantity_units_selector_container}>
                                    <ClonosInput
                                      label="QUANTITY"
                                      isLabel={true}
                                      placeholder="value"
                                      isMandatory={true}
                                      type="number"
                                      limit='8'
                                      uniqueKey="quantity"
                                      defaultValue={data?.replacedQuantity}
                                        handleGetValues={handleGetValues}
                                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                    
                               </div>
                                */}
 {/* <Tooltip title="Fill in the quantity of spare parts you want to return." arrow placement="top"> */}
                            <div className={Styles.avlqty}>
                              <span> 
                                 <span className={Styles.heading}>Available Requested Quantity:&nbsp;</span> {data?.spareRequested?.requestedQuantity - data?.replacedQuantity}
                              </span> 
                            </div>
                           <div className={Styles.quantity_units_selector_container}>
                                    <ClonosInput
                                      label="QUANTITY"
                                      isLabel={true}
                                      placeholder="value"
                                      isMandatory={true}
                                      type="number"
                                      limit="8"
                                      uniqueKey="quantity"
                                      defaultValue={data?.replacedQuantity}
                                      handleGetValues={handleGetValues}
                                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                              </div>     
                       
                      </div>
                      
                      <div className={Styles.footer}>
                          <div>
                              <ClonosButton onClick={() => setShowConfirmationDialog(true)}>Cancel</ClonosButton>
                              <ClonosButton
                                  // loading={loadings.generateReportLoading}
                                  variant="filled"
                                //   onClick={() => handleAddQuantity({ handleSubmit, formData, setIsLoading: () => setIsLoading(prev => (!prev)), closeMethod ,spareId: data?.id})}
                                onClick={handleSave}
                              >
                                 Save
                              </ClonosButton>
                          </div>
                      </div>
                  </div>
                 </Modal>
                 
                 <ClonosConfirmationBox
                     isOpen={showConfirmationDialog}
                     closeModalMethod={setShowConfirmationDialog}
                     confirmingMethod={() => {
                         closeMethod(false);
                         setShowConfirmationDialog(false);
                     }}
                     rejectingMethod={() => setShowConfirmationDialog(false)}
                     message={"Are you sure to cancel ?"}
                     headerTitle={"Cancel"}
                 />
   </>
  )
}

export default EditSpareReplacedModal