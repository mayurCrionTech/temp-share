import React, { useState,useEffect } from 'react'
import { Card } from '@material-ui/core'
import ClonosDataGrid from '../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { doGetApiCall } from '../../../utils/ClonosApi'
import AppUrl from '../../../utils/AppUrl'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import useToggler from '../../../CustomHooks/TogglerHook'
import useModuleNameProvider from '../../../CustomHooks/ModuleNameProviderHook'
import { checkUserHasPermission, commonPageState, handleLoggedInUser, handleShowErrorAndWarning } from '../../../utils/clonosCommon'
import { handleDeleteSpares, handleGetAllSpares } from '../SparesManager/spares-manager'
import { setSerialNumber } from '../../../utils/clonosCommon'
import { statusStyleStaticData, statusStaticData } from '../../../Constants/StaticData'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button'
import AddQuantityModal from './AddQuantityModal'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_STATUS_APPROVED, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant'
import ClonosConfirmationBox from '../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'

function SparesListingTable({searchedResult}) {
    
      const dispatch = useDispatch();
      const navigate = useNavigate();
      const [isLoading, setIsLoading] = useToggler(); 
      const [deleteLoading, setDeleteLoading] = useToggler();
      const [spares,setSpares] = useState({});
      const [pagination, setPagination] = useState(commonPageState);
      const [selectedRows, setSelectedRows] = useState([]);
      const [selectedRow, setSelectedRow] = useState(null);
      const [refreshApi, setRefreshApi] = useToggler();
      const [deleteWorkOrderAlert, setDeleteWorkOrderAlert] = useState(false);
      const [workOrderStatuses, setWorkOrderStatuses] = useState({});
      const [refreshStatusCount, setRefreshStatusCount] = useToggler();
      const moduleName = useModuleNameProvider();
      const [showAddQuantityModal, setShowAddQuantityModal]=useState(false)
    
      const [lcLoaderAndFlags,setLcLoadersAndFlags]=useState({
              deleteSpareAlert:false,
              deleteLoading:false
      })

      let user = handleLoggedInUser()
     
      const isOperator = user?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR;
  //  const columns = [
  //         {
  //             field: "index",
  //             headerName: "SI.No",
  //             // flex: 1,
  //             width: 70,
  //             disableColumnFilter: true,
  //             headerClassName: "datadrid_common_header",
  //         },
  //         {
  //         field: "name",
  //         headerName: "SPARE NAME",
  //         flex: 1.3,
  //         disableColumnFilter: true,
  //         headerClassName: "datadrid_common_header",
  //         renderCell: (params) => {
  //           const name = params?.row?.name || "-";
  //           const spec = params?.row?.specification || "";
  //           const combined = `${name}${spec}`;
            
  //           return (
  //             <p
  //               onClick={() =>
  //                 handleGotoSpareView(params?.row?.id, name, name)
  //               }
  //               style={{
  //                 textDecoration: "underline",
  //                 color: "#3f51b5",
  //                 cursor: "pointer",
  //               }}
  //             >
  //               {combined}
  //             </p>
  //           );
  //         },
  //       },
  //         {
  //             field: "quantity",
  //             headerName: "QUANTITY",
  //             width: 150,
  //             // flex: 1,
  //             disableColumnFilter: true,
  //             headerClassName: "datadrid_common_header",
  //             // renderCell: (params) => {
  //             //     return <p onClick={() => handleGotoWOV(params?.row?.id, params?.row?.name, (params?.row?.name || params?.row?.id))} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>
  //             // }
  //         },
  //         {
  //             field: "units",
  //             headerName: "UNITS",
  //             width: 100,
  //             // flex: 1,
  //             disableColumnFilter: true,
  //             headerClassName: "datadrid_common_header",
  //             // valueGetter: (params) => params?.row?.endAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params?.row?.endAt,parseType:"string"})) : "-"
  //         },
  //         {
  //             field: "minimumRequiredQuantity",
  //             headerName: "MINIMUM QUANTITY",
  //             width: 200,
  //             // flex: 1,
  //             disableColumnFilter: true,
  //             headerClassName: "datadrid_common_header",
              
  //         },
  //         {
  //             field: "status",
  //             headerName: "STATUS",
  //             // width: 250,
  //             flex: 1,
  //             disableColumnFilter: true,
  //             headerClassName: "datadrid_common_header",
  //             // valueGetter: (params) => params?.row?.status || "-"
  //             renderCell: (params) => {
  //                 return <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{params?.row?.status ? statusStaticData[params?.row?.status] : "-"}</p>
  //             }
  //         },
         
  //         {
  //             field: "action",
  //             headerName: "ACTION",
  //             // width: 150,
  //             flex: 1,
  //             disableColumnFilter: true,
  //             headerClassName: "datadrid_common_header",
  //             renderCell: (params) => (
  //                params?.row?.status === "approved"  && params?.row?.approver.name !== user?.name &&<ClonosButton
  //                 variant="filled"
  //                 onClick={() => {
  //                   setSelectedRow(params.row);  
  //                   setShowAddQuantityModal(true)
  //                  }
  //                 } // optional: pass row data
  //               >
  //                 Add Quantity
  //               </ClonosButton>
  //             ),
  //           }

  //     ]

//   const columns = [
//   {
//     field: "index",
//     headerName: "SI.No",
//     width: 70,
//     headerClassName: "datadrid_common_header",
//     cellClassName: "datagrid_common_cell",
//   },
//   {
//     field: "name",
//     headerName: "SPARE NAME",
//     flex: 1.5, // Give more space to long text
//     headerClassName: "datadrid_common_header",
//     cellClassName: "datagrid_common_cell",
//     renderCell: (params) => {
//       const name = params?.row?.name || "-";
//       return (
//         <p
//           onClick={() => handleGotoSpareView(params?.row?.id, name, name)}
//           style={{
//             textDecoration: "underline",
//             color: "#3f51b5",
//             cursor: "pointer",
//             margin: 0,
//             whiteSpace: "nowrap", // Optional: Prevent wrapping
//           }}
//         >
//           {name}
//         </p>
//       );
//     },
//   },
//   {
//     field: "quantity",
//     headerName: "QUANTITY",
//     width: 150,
//     headerAlign:"center",
//     align:"center",
//     headerClassName: "datadrid_common_header",
//     cellClassName: "datagrid_common_cell",
//      valueGetter: (params) => params?.row?.quantity || "-"
//   },
//   {
//     field: "units",
//     headerName: "UNITS",
//     width: 120,
//     headerAlign:"center",
//     align:"center",
//     headerClassName: "datadrid_common_header",
//     cellClassName: "datagrid_common_cell",
//      valueGetter: (params) => params?.row?.units || "-"
//   },
//   {
//     field: "minimumRequiredQuantity",
//     headerName: "MINIMUM QUANTITY",
//     width: 160,
//     headerClassName: "datadrid_common_header",
//     align:"center",
//     valueGetter: (params) => params?.row?.minimumRequiredQuantity || "-"
    
//   },
//   {
//     field: "status",
//     headerName: "STATUS",
//     flex: 1.5,
//     headerAlign:"center",
//     align:"center",
//     headerClassName: "datadrid_common_header",
//     cellClassName: "datagrid_common_cell",
//     renderCell: (params) => (
//       <p
//         style={{
//           ...statusStyleStaticData[params?.row?.status],
//           padding: "0.25rem 0.5rem",
//           borderRadius: "0.25rem",
//           margin: 0,
//           cursor: "default",
//         }}
//       >
//         {params?.row?.status ? statusStaticData[params?.row?.status] : "-"}
//       </p>
//     ),
//   },
//   {
//     field: "action",
//     headerName: "ACTION",
//     flex: 1,
//     headerClassName: "datadrid_common_header",
//     cellClassName: "datagrid_common_cell",
//     headerAlign:"center",
//     align:"center",
//     renderCell: (params) =>
//   (params?.row?.status === "approved") &&
//   params?.row?.approver?.name !== user?.name ? (
//     <ClonosButton
//       variant="filled"
//       onClick={() => {
//         setSelectedRow(params.row);
//         setShowAddQuantityModal(true);
//       }}
//       style={{
//         border: "1px solid #06337E",
//         fontSize: "16px",
//         padding: "0.5rem 1rem",
//         width: "130px",
//         marginRight: "0.5rem",
//         height: "32px",
//       }}
//     >
//       Add Quantity
//     </ClonosButton>
//    ) : null,

//   },
// ];
    
const columns = [ 
  {
    field: "index",
    headerName: "SI.No",
    width: 70,
    disableColumnFilter: true,
    filterable: false, 
    headerClassName: "datadrid_common_header",
    cellClassName: "datagrid_common_cell",
  },
  {
    field: "name",
    headerName: "SPARE NAME",
    flex: 1.5,
    headerClassName: "datadrid_common_header",
    cellClassName: "datagrid_common_cell",
    headerAlign:"center",
    renderCell: (params) => {
      const name = params?.row?.name || "-";
      return (
        <p
          onClick={() => handleGotoSpareView(params?.row?.id, name, name)}
          style={{
            textDecoration: "underline",
            color: "#3f51b5",
            cursor: "pointer",
            margin: 0,
            whiteSpace: "nowrap",
          }}
        >
          {name}
        </p>
      );
    },
  },
  {
    field: "quantity",
    headerName: "QUANTITY",
    // width: 150,
     flex:1,
    headerAlign:"center",
    align:"center",
    headerClassName: "datadrid_common_header",
    cellClassName: "datagrid_common_cell",
    valueGetter: (params) => params?.row?.quantity || "-"
  },
  {
    field: "units",
    headerName: "UNITS",
    // width: 120,
    flex:1,
    headerAlign:"center",
    align:"center",
    headerClassName: "datadrid_common_header",
    cellClassName: "datagrid_common_cell",
    valueGetter: (params) => params?.row?.units || "-"
  },
  {
    field: "minimumRequiredQuantity",
    headerName: "MINIMUM QUANTITY",
    // width: 160
     flex:1,
    headerClassName: "datadrid_common_header",
    align:"center",
    valueGetter: (params) => params?.row?.minimumRequiredQuantity || "-"
  },
  {
    field: "status",
    headerName: "STATUS",
    flex: 1.5,
    headerAlign:"center",
    align:"center",
    headerClassName: "datadrid_common_header",
    cellClassName: "datagrid_common_cell",
    renderCell: (params) => (
      <p
        style={{
          ...statusStyleStaticData[params?.row?.status],
          padding: "0.25rem 0.5rem",
          borderRadius: "0.25rem",
          margin: 0,
          cursor: "default",
        }}
      >
        {params?.row?.status ? statusStaticData[params?.row?.status] : "-"}
      </p>
    ),
  },

  // ✅ Conditionally add ACTION column for non-Operator users
  ...(!isOperator
    ? [
        {
          field: "action",
          headerName: "ACTION",
          flex: 1.5,
          headerClassName: "datadrid_common_header",
          cellClassName: "datagrid_common_cell",
          headerAlign: "center",
          align: "center",
          renderCell: (params) =>
            (params?.row?.status === "approved")? <ClonosButton
                variant="filled"
                onClick={() => {
                  setSelectedRow(params.row);
                  setShowAddQuantityModal(true);
                }}
                style={{
                  border: "1px solid #06337E",
                  fontSize: "16px",
                  padding: "0.5rem 1rem",
                  width: "130px",
                  marginRight: "0.5rem",
                  height: "32px",
                }}
              >
                Add Quantity
              </ClonosButton>
              : '-'
        },
      ]
    : []),
];


    const handleGoToSpareEdit=()=>{
          navigate(`/edit-spare`, { state: { "mode": "edit", "spareId": selectedRows[0]} })
  }

         const handleGotoSpareView = (spareId, spareName, spareNameOrId) => {
        navigate(`/view-spare/${spareNameOrId}`, { state: { spareId, spareName } })
    }

       useEffect(() => {
              handleGetAllSpares({setterMethod:setSpares,setIsLoading,pagination})
          },[pagination?.page,pagination?.limit])

      
      //  const selectedRowData = spares?.data?.find(row => row.id === selectedRows);

  return (
   <>
      <div style={{ padding: "1rem 1rem", height: "90%" }}>
        <ClonosDataGrid
          rows={setSerialNumber(searchedResult? searchedResult?.data : spares?.data,pagination?.page,pagination?.limit)}
          columns={columns}
          //           isEditMethod={selectedRowData &&
          // selectedRowData.approver?.name !== user?.name &&
          // selectedRowData.status === CLONOS_GLOBAL_STATUS_APPROVED
          //   ? handleGoToSpareEdit
          //   : null}
          isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleGoToSpareEdit : false}
          //isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setLcLoadersAndFlags(prev => ({...prev, deleteSpareAlert:!prev.deleteSpareAlert})) : false}
          uniqueIdField="id"
          onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          isLoading={isLoading}
          totalCount={searchedResult ? searchedResult?.totalDataCount  : spares?.totalDataCount}
          pageLimit={pagination.limit}
          //  checkboxSelection={isOperator? false : true}
        
         checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
          handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
        />
      </div>

        {
          showAddQuantityModal && <AddQuantityModal  data={selectedRow} isOpen={showAddQuantityModal} closeMethod={setShowAddQuantityModal} />
        }


        {/* <ClonosConfirmationBox
          isOpen={lcLoaderAndFlags.deleteSpareAlert}
          confirmingMethod={() => {
              handleDeleteSpares({payload:[selectedRows[0]],setIsLoading:() => setLcLoadersAndFlags(prev => ({...prev,deleteLoading:!prev.deleteLoading})),next:() => {
                  handleShowErrorAndWarning({dispatch,message:"Spares deleted successfully!",type:"success",showTime:"5000"})
                  navigate("/spares")
              } })
            setLcLoadersAndFlags((prev)=>({...prev, deleteSpareAlert : !prev.deleteSpareAlert}))
          }}
          loading={lcLoaderAndFlags?.deleteLoading}
          closeModalMethod={() => setLcLoadersAndFlags(prev => ({...prev,deleteSpareAlert:!prev.deleteSpareAlert}))}
          headerTitle="Delete Spare"
          message="Are you sure, You want to delete this Spares?"
       /> */}
   </>
  )
}

export default SparesListingTable