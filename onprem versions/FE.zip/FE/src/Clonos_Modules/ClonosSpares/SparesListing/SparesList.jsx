import React, { useEffect, useState } from 'react'
import ClonosGridNav from '../../../utils/ClonosGridNav'
import useToggler from '../../../CustomHooks/TogglerHook';
import {Spares} from '../../../assets/UIUX/icons/Checklist/Checklist'
import { ClonosButton } from '../../../components/CommonComponents/Button/Button';
import {makeStyles, styled } from '@material-ui/core/styles';
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';
import { useNavigate } from 'react-router-dom';
import { Card } from '@material-ui/core'
import ClonosDataGrid from '../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_MODULE_SPARES, CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../Constants/Constant';
import CommonNavigator from '../../../components/CommonComponents/Navigator/Navigator';
import { checkUserHasPermission, handleLoggedInUser } from '../../../utils/clonosCommon';
import { CLONOS_GLOBAL_ACTION_FILL_ENTRY,CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY } from '../../../Constants/Constant';
import SparesListingTable from './SparesListingTable';
import ManageQuantityTable from './ManageQuantityTable';
import SpareRequestListTable from './SpareRequestListTable';
import SpareReplacedListTable from './SpareReplacedListTable';
import { doGetApiCall } from '../../../utils/ClonosApi';
import AppUrl from '../../../utils/AppUrl';
import SearchBar from '../SpareSearch/SearchBar';
import useModuleNameProvider from '../../../CustomHooks/ModuleNameProviderHook';
import { UnAuthorizedModal } from '../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal';


let user = handleLoggedInUser()

let navigatorValues = [
    {
        value: "Spares",
        status: true,
        visibility: true,
        uniqueKey: CLONOS_GLOBAL_MODULE_SPARES
    },
    {
        value: "Manage Quantity",
        status: false,
        visibility: true,
        uniqueKey:  "manageQuantity"
    },
      {
        value: "Spare Request List",
        status: false,
        visibility: true,
        uniqueKey:  "spareRequestList"
    },
      {
        value: "Spare Replaced List",
        status: false,
        visibility: true,
        uniqueKey:  "spareReplacedList"
    },
];




   function SparesList() {
    const [toggleBetweenSparesTab, setToggleBetweenSparesTab] = useState(CLONOS_GLOBAL_MODULE_SPARES);
    const [overUtilizedSpareCounts,setOverUtilizedSpareCounts]=useState('')
    const [searchedResult,setSearchedResult]=useState({})
     const [navLoading,setNavLoading] = useToggler();
     const navigate = useNavigate()
     // Local Handlers
    const handleTogglebetweenSparesTab = (props, uniqueKey) => {
        setToggleBetweenSparesTab(uniqueKey);
    };
    const moduleName = useModuleNameProvider();
  
     let user = handleLoggedInUser()

         
     const isOperator = user?.userType?.name === CLONOS_GLOBAL_USER_TYPE_OPERATOR;



useEffect(()=>{
    doGetApiCall({url:AppUrl?.getOverutilizedSpareCounts}).then((res)=>setOverUtilizedSpareCounts(res?.data?.result?.overUtilised))
},[overUtilizedSpareCounts])

    if (checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_READ })) {
        
 return (
   <>
     {(!URL?.unity && !URL?.AR && !URL?.VR) && <ClonosGridNav isLoading={navLoading} items={[
                {
                    icon: Spares,
                    iconBg: '#EBFAF8',
                    title: 'OverUtilized Spare',
                    count:  overUtilizedSpareCounts,
                },
                
            ]}>
                {/* <div className="d-fl-al-cen">
                    {checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_CREATE }) ?
                        <ClonosButton onClick={() => navigate("/create-work-order")} variant={"filled"}>Create Work Order</ClonosButton> : <></>}
                </div> */}
                 
                 <SearchBar toggleBetweenSparesTab={toggleBetweenSparesTab} setSearchedResult={setSearchedResult}/>
              {checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_CREATE })&& <div className='d-fl-al-cen'>
                        <ClonosButton onClick={() => navigate("/create-spare")} variant={"filled"}>Create Spares</ClonosButton>
                </div>
              
              } 
               
            </ClonosGridNav>
            }
    
            <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto" }}>
                     <CommonNavigator web={true} values={navigatorValues} getSelectedValue={handleTogglebetweenSparesTab} />
                     
                    {toggleBetweenSparesTab === "spares" && (
                        <SparesListingTable searchedResult={searchedResult}/>
                    )}

                    {toggleBetweenSparesTab === "manageQuantity" && (
                        <ManageQuantityTable
                        searchedResult={searchedResult}
                        // tableData={quantityData}
                        // totalCount={totalCount}
                        // pageLimit={pagination.limit}
                        // setPagination={setPagination}
                        // isLoading={isLoading}
                        // setRefreshApi={setRefreshApi}
                        // setRefreshStatusCount={setRefreshStatusCount}
                        />
                    )}

                    {toggleBetweenSparesTab === "spareRequestList" && (
                        <SpareRequestListTable
                        searchedResult={searchedResult}
                        // tableData={requestListData}
                        // totalCount={totalCount}
                        // pageLimit={pagination.limit}
                        // setPagination={setPagination}
                        // isLoading={isLoading}
                        // setRefreshApi={setRefreshApi}
                        // setRefreshStatusCount={setRefreshStatusCount}
                        />
                    )}

                    {toggleBetweenSparesTab === "spareReplacedList" && (
                        <SpareReplacedListTable
                        searchedResult={searchedResult}
                        // tableData={replacedListData}
                        // totalCount={totalCount}
                        // pageLimit={pagination.limit}
                        // setPagination={setPagination}
                        // isLoading={isLoading}
                        // setRefreshApi={setRefreshApi}
                        // setRefreshStatusCount={setRefreshStatusCount}
                        />
                    )}

                    </Card>
   </>
  )
    }

 return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
  
}


export default SparesList
