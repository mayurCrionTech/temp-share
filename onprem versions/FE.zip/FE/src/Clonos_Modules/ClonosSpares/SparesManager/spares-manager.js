import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../Constants/Constant"
import AppUrl from "../../../utils/AppUrl"
import { doDeleteApiCall, doGetApiCall, doPatchApiCall, doPostApiCall, doPutApiCall } from "../../../utils/ClonosApi"
import {debounce, generateUniqueId, getFormatedDate, getYYYYMMDD_Format, handleClientDateInConfiguredTimeZone, handleServerDateInConfiguredTimeZone, handleShowErrorAndWarning } from "../../../utils/clonosCommon"
import { handleCheckUniqueFieldsMethod } from "../../../utils/common-managers"

// export const handleGetWorkOrderPriorities = ({setterMethod}) => {
//     doGetApiCall({url:AppUrl.getWorkOrderConstants})
//     .then(res => {
//         if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
//             const data = res?.data?.result;
//             setterMethod(data?.priority)
//         }
//     })
// }

//  TO CHECK THE UNIQUNESS OF FIELD
const uniqueFieldHandler = ({ module, mode, fieldName,updatedValue,fieldValue, primaryObject, handlePrimaryObjectModifier, setFormData, setChangedData }) => {
    handleCheckUniqueFieldsMethod({ module, fieldName, fieldValue,updatedValue }).then((res) => {
        if (res === "unique") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
            setFormData((prev) => {
                return { ...prev, [fieldName]: updatedValue }
            })
            if (mode === "edit") setChangedData((prev) => ({ ...prev, [fieldName]: fieldValue }))
        } else if (res === "not_unique") {
            primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
            primaryObject?.[fieldName]?.errorActivatorMethod(true);
            primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${fieldName}.`)
        }
    })
}


const debouncedCheckUniquenessOfFields = debounce(uniqueFieldHandler, 500);

export const handleGetFilledValuesOfSpares = ({fieldProps,primaryObject,setFormData,handlePrimaryObjectModifier,mode,setChangedData,serverResponse,formData}) => {
    const {type,uniqueKey,updatedValue,selectedOption,files} = fieldProps;
    if (type === "dynamicDropdown") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
        setFormData((prev) => ({ ...prev, [uniqueKey]: selectedOption?.map(opt => ({name:opt?.name,id:opt?.id}))}))
    } else if (type === "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => ({...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}}))
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
            // if(uniqueKey === "name" ) {
                
            //     if(mode !== "edit") {
            //         debouncedCheckUniquenessOfFields({module:"spares",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData,setChangedData})
            //     } else {
            //         updatedValue !== serverResponse?.name && debouncedCheckUniquenessOfFields({module:"spares",mode,fieldName:uniqueKey,fieldValue:updatedValue,primaryObject,handlePrimaryObjectModifier,setFormData,setChangedData})
            //     }
            // } else {
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
               
                setFormData((prev) => ({...prev,[uniqueKey]:updatedValue}))
                if (uniqueKey === "specification") {
                const name = formData?.name
                const combinedValue = `${name?.trim() || ""}${updatedValue?.trim() || ""}`; // or use any separator like "-" or "::"

                debouncedCheckUniquenessOfFields({
                    module: "spares",
                    mode,
                    fieldName: uniqueKey,
                    fieldValue: combinedValue,
                    primaryObject,
                    handlePrimaryObjectModifier,
                    setFormData,
                    setChangedData,
                    updatedValue
                });
            }

            // }
    } else if (type === "file") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
        setFormData((prev) => ({ ...prev, [uniqueKey] : files }))
    } else if (type === "checkbox"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    }  
}

/*
date            qid / cr#         comments
21-mar-2026     CR0001            Apply filter on drop down

*/


const handleModifyRequestPayload = (payload,mode) => {

    
    const requestPayload = {};
    if(payload?.name) requestPayload.name = payload.name;
    if(payload?.description) requestPayload.description = payload.description;
    if(payload?.specification) requestPayload.specification = payload.specification
    if(payload?.partNumber) requestPayload.partNumber = payload.partNumber
    if(payload?.category) requestPayload.category = payload.category
    if(payload?.quantity) requestPayload.quantity = Number(payload.quantity)
    if(payload?.units) requestPayload.units = payload.units.name
    // if(payload?.units) requestPayload.unitsId = payload.units.id
    if(payload?.approver) (requestPayload.approver = payload?.approver[0]?.id);
    if(payload?.minimumRequiredQuantity) requestPayload.minimumRequiredQuantity = Number(payload.minimumRequiredQuantity)
    if(payload?.cost) requestPayload.cost = Number(payload.cost) 
    if(payload?.costUnits) requestPayload.costUnits = payload.costUnits?.name
    if(payload?.costUnits) requestPayload.costUnitsId = payload.costUnits?.id      
    if(payload?.expiryDate) requestPayload.expiryDate = handleServerDateInConfiguredTimeZone({dateString:payload?.expiryDate});
      requestPayload.isSupplierDetails = payload.isSupplierDetails
    if (payload?.isSupplierDetails) {
    requestPayload.supplierDetails = {};
    if (payload?.supplierName) requestPayload.supplierDetails.name = payload.supplierName;
    if (payload?.vendorCode) requestPayload.supplierDetails.vendorCode = payload.vendorCode;
    if (payload?.email) requestPayload.supplierDetails.email = payload.email;
    if (payload?.contactNumber) requestPayload.supplierDetails.contactNumber = payload.contactNumber;
}

    // if (
    //     payload?.supplierName ||
    //     payload?.vendorCode ||
    //     payload?.email ||
    //     payload?.contactNumber
    // ) {
    //     requestPayload.supplierDetails = {};
    //     if (payload?.supplierName) requestPayload.supplierDetails.name = payload.supplierName;
    //     if (payload?.vendorCode) requestPayload.supplierDetails.vendorCode = payload.vendorCode;
    //     if (payload?.email) requestPayload.supplierDetails.email = payload.email;
    //     if (payload?.contactNumber) requestPayload.supplierDetails.contactNumber = payload.contactNumber;
    // }
     if(payload?.images) (requestPayload.images = (payload?.images || []).map(image => image?.id))
      

    return requestPayload
}



export const handleCreateSpares = ({payload,setIsLoading,next}) => {
    setIsLoading()
    const requestPayload = handleModifyRequestPayload(payload,"create");
    
    doPostApiCall({url:AppUrl.createSpare,payload:requestPayload})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
            next && next(res?.data?.result?.id);
        }
    })
    .finally(() => setIsLoading())
}

export const handleUpdateSpare =({payload,setIsLoading,next,spareId})=>{
    
     setIsLoading()
     const requestPayload = handleModifyRequestPayload(payload,"edit");
     doPatchApiCall({url:`spares/${spareId}`,payload:requestPayload})
     .then((res)=>{
       if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
           next && next(res?.data?.result?.id);
       }
     })
     .finally(()=>setIsLoading())
}

export const handleGetAllSpares = ({setterMethod,setIsLoading,pagination}) => {
    setIsLoading()
    doGetApiCall({url:AppUrl.getAllSparesList,params:pagination})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

export const handleGetSingleSpare =({setterMethod,setIsLoading,spareId})=>{
      setIsLoading()
      let url = `spares/${spareId}`
     doGetApiCall({url})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

export const handleGetAllQuantities = ({setterMethod,setIsLoading,pagination}) => {
    setIsLoading()
    doGetApiCall({url:AppUrl.getAllManageQuanityDetails,params:pagination})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

export const handleAddQuantity = ({dispatch,spareId,handleSubmit,setRefreshApi, formData, setIsLoading, closeMethod ,units}) => {
    if (!handleSubmit()) {
        return
    }
    setIsLoading && setIsLoading();
    
    const requestPayload = {
          spareId:spareId,
          quantity:Number(formData?.quantity),
          units: formData?.units?.name ?? units,
          cost:Number(formData?.cost),
          costUnits:formData?.costUnits?.name,
          costUnitsId:formData?.costUnits?.id,
        //   unitOfCost:formData?.unitOfCost?.name,
          expiryDate: formData?.expiryDate ? handleServerDateInConfiguredTimeZone({dateString:formData?.expiryDate}) :"",  
          
    };
    
    doPostApiCall({ url: AppUrl.addSpareQuanity, payload: requestPayload })
        .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS) {
               
                closeMethod()
                handleShowErrorAndWarning({dispatch,message:"Quantity added successfully",type:"success",showTime:"5000"})
                setRefreshApi()
               

               
            } else {
                handleShowErrorAndWarning({dispatch,message:"Failed to add quantity",type:"error",showTime:"5000"})
            }
        })
        .catch(err => {
            console.error(err)
        })
        .finally(() => setIsLoading && setIsLoading())
}

export const handleUpdateQuantity = ({dispatch,spareId, quantityId,handleSubmit, setRefreshApi,formData, setIsLoading, closeMethod }) => {
    if (!handleSubmit()) {
        return
    }
    setIsLoading && setIsLoading();
   
    const requestPayload = {
          spare:spareId,
          quantity:Number(formData?.quantity),
          units:formData?.units?.name,
          cost:Number(formData?.cost),
          expiryDate: formData?.expiryDate ? handleServerDateInConfiguredTimeZone({dateString:formData?.expiryDate}) :"",  
          
    };
    
     doPatchApiCall({url:`spares/quantities/${quantityId}`,payload:requestPayload})
         .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
               
                closeMethod()
                setRefreshApi()
                handleShowErrorAndWarning({dispatch,message:"Quantity updated successfully",type:"success",showTime:"5000"})

               
            } else {
                handleShowErrorAndWarning({dispatch,message:"Failed to update quantity",type:"error",showTime:"5000"})
            }
        })
        .catch(err => {
            console.error(err)
        })
        .finally(() => setIsLoading && setIsLoading())
}


export const handleDeleteSpares = ({payload,setIsLoading,next}) => {
    setIsLoading()
    doDeleteApiCall({url:AppUrl.deleteSpares,payload:{spareIds:payload}})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
            next && next()
        }
    })
    .finally(setIsLoading)
}


export const handleGetAllRequestedList =({setIsLoading,setterMethod,pagination})=>{
   setIsLoading()
   doGetApiCall({url:AppUrl?.getSpareRequestedList, params:pagination})
   .then(res => {
  
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}


export const handleGetAllReplacedList =({setIsLoading,setterMethod,pagination})=>{
   setIsLoading()
   doGetApiCall({url:AppUrl?.getSpareReplacedList, params:pagination})
   .then(res => {
   
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            setterMethod(res?.data?.result)
        }
    })
    .finally(setIsLoading)
}

export const handleEditReplacedSpare =({dispatch, spareReplacedId,handleSubmit,setRefreshApi, formData, setIsLoading, closeMethod })=>{
    if (!handleSubmit()) {
        return
    }
    setIsLoading && setIsLoading();
   
    const requestPayload = {
          quantityToReturn:Number(formData?.quantity),
    };
    doPatchApiCall({url:`/spares/spareReplaced/${spareReplacedId}/return`,payload:requestPayload})
    .then((res) => {
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS) {
               
                closeMethod()
                setRefreshApi()
                handleShowErrorAndWarning({dispatch,message:"Spare returned successfully",type:"success",showTime:"5000"})
            } 
        })
        .catch(err => {
            console.error(err)
        })
        .finally(() => setIsLoading && setIsLoading())

}


export const handleDraftSpares = ({dispatch,payload,setIsLoading,next}) => {
    const requestPayload = handleModifyRequestPayload(payload,"create")
    setIsLoading && setIsLoading();
    doPostApiCall({url:AppUrl.createSpare,payload:requestPayload,queryParams:{isDraft:true}})
    .then((res) => {
        next && next()
        handleShowErrorAndWarning({dispatch,type:"success",message:"Spares drafted successfully",showTime:"5000"})
    })
    .finally(() => {
        setIsLoading && setIsLoading();
    })
}














