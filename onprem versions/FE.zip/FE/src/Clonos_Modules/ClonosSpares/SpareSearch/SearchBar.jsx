import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';
import AppUrl from '../../../utils/AppUrl';
import { doGetApiCall } from '../../../utils/ClonosApi';
import { commonPageState } from '../../../utils/clonosCommon';

const useStyles = makeStyles((theme) => ({
  searchContainer: {
    width: '100%',
    maxWidth: '65%',
    margin: '0 auto',
    padding: theme.spacing(3, 0),
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: '#fff',
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    padding: '4px 12px',
    border: '1px solid  #06337E',
    borderRadius: '8px',
  },
  searchIcon: {
    marginRight: theme.spacing(1),
    color: '#888',
  },
  inputRoot: {
    color: '#000',
    flex: 1,
  },
  inputInput: {
    padding: theme.spacing(1, 0),
  },
}));

const SearchBar = ({toggleBetweenSparesTab,setSearchedResult}) => {
  const classes = useStyles();
  const [searchQuery, setSearchQuery] = useState('');
  const [pagination, setPagination] = useState(commonPageState);
  const [debouncedQuery, setDebouncedQuery] = useState('');

  const URL_MAP = {
  spares: AppUrl?.getAllSparesList,
  manageQuantity: AppUrl?.getAllManageQuanityDetails,
  spareRequestList: AppUrl?.getSpareRequestedList,
  spareReplacedList: AppUrl?.getSpareReplacedList,
};

  // Debounce input to prevent rapid API calls
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 500); // 500ms delay

    return () => clearTimeout(handler);
  }, [searchQuery]);

  // Call API when debounced query updates
  useEffect(() => {
  if (debouncedQuery?.trim()?.length > 0) {
    const url = URL_MAP[toggleBetweenSparesTab];

    if (url) {
      doGetApiCall({ url, params: { ...pagination, name: debouncedQuery } })
        .then((res) => {
          setSearchedResult(res?.data?.result);
        })
        .catch((err) => {
          console.error('Search API error:', err);
        });
    }
  } else {
    setSearchedResult(null); // clear search result
  }
}, [debouncedQuery, toggleBetweenSparesTab]);

  return (
    <div className={classes.searchContainer}>
      <div className={classes.search}>
        <SearchIcon className={classes.searchIcon} />
        <InputBase
          placeholder="Search…"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          classes={{
            root: classes.inputRoot,
            input: classes.inputInput,
          }}
          inputProps={{ 'aria-label': 'search' }}
        />
      </div>
    </div>
  );
};

export default SearchBar;
