// import { useEffect, useState } from "react"
// import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
// import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
// import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
// import { ClonosInputWithSelect } from "../../../../components/CommonComponents/ClonosInputWithSelect/ClonosInputWithSelect"
// import Modal from "../../../../components/CommonComponents/Modal/Modal"
// import Styles from "./upload-spare-modal.module.css"
// import { v4 as uuidv4 } from 'uuid';
// import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
// import { globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
// import { useDispatch } from "react-redux"
// import useToggler from "../../../../CustomHooks/TogglerHook"
// import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner"
// import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect"
// import { getSingleSpareDetails, handleGetAssets, handleGetFilledValuesOfSpare, handleCreateSpareHelper, handleCheckUniquenessOfSpare } from "../../managers/spares-manager"
// import DynamicDropdown from "../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown"


// export const UploadSpareModal = ({isOpen,closeMethod,getFilledValue,selectedSpare,saveLoader,spareId,mode,isLinkAssetRequired=false,lcSpares}) => {
//     const dispatch = useDispatch();
//     const [assetsPaination,setAssetsPaginations] = useState({page:1,limit:15});
//     const [fetchLoader,setFetchLoader] = useToggler();
//     const [assetsDetails,setAssetsDetails] = useState({});
//     const [formData,setFormData] = useState({});
//     const {isClear,primaryObject,handleGetErrorActivatorInformation,handlePrimaryObjectModifier,handleSubmit,handleRemoveField,activeHookInstances,} = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "spares" })
    
//     const handleGetValues = (props) => {
//         // handleGetFilledValuesOfSpare({componentProps:val,disableSave,setDisableSave,primaryObject,handlePrimaryObjectModifier,setChangedData,setFormData,mode,lcServerResponse,lcSpares,formData})
//         handleGetFilledValuesOfSpare({componentProps:props,setFormData,primaryObject,handlePrimaryObjectModifier,formData,mode})
//     }
        

//     const handleSave = () => { 
//         if(!handleSubmit()) return 
//         if(formData?.isDuplicate) {
//             primaryObject.name = { ...primaryObject?.name, value: false };
//             primaryObject?.name?.errorActivatorMethod(true);
//             primaryObject?.name?.errorSetterMethod(`Already exists, please provide different Spare Name.`)
//             return
//         }
//         getFilledValue(formData)
//     }


//     const handleSearchAssets = (props) => {
//         const {uniqueKey,input} = props;
//     }
    
//     const handleMoreData = () => {

//     }


//     useEffect(() => {
//         if(spareId && mode === "edit"){
//             getSingleSpareDetails({spareId,setterMethod:setFormData,setIsLoading:setFetchLoader});
//         }
//     },[spareId]);
    
//     useEffect(() => {
//         handleGetAssets({setterMethod:setAssetsDetails,pagination:assetsPaination});
//     },[])
    
//     return <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
//         <div className={Styles.spare_modal_container}>
//             {
//                 fetchLoader ? <div style={{height:"40vh"}} className="center_wrapper">
//                     <ClonosSpinner/>
//                 </div> : 
//                 (mode === "edit" && !Object?.keys({formData})?.length ) ? <div style={{height:"40vh"}} className="center_wrapper">
//                     <h4>No details found</h4>
//                 </div> : <>
//                 <div className={Styles.spare_modal_header}>
//                 <h4>{mode === "edit" ? "Update Spare" : "Spare Upload"}</h4>
//                 <CloseIcon onClick={() => closeMethod(false)}/>
//             </div>
//             <div className={Styles.spare_modal_section}>
//                     {isLinkAssetRequired ? <DynamicDropdown
//                         isLabel={true}
//                         label="Asset"
//                         title="Asset"
//                         uniqueKey="asset"
//                         areaLabel="Asset"
//                         isCheckbox={false}
//                         isActivator={true}
//                         isMandatory={false}
//                         isSearchable={true}
//                         placeholder="Select"
//                         populatedFields={["number"]}
//                         handleMoreData={handleMoreData}
//                         handleGetValues={handleGetValues}
//                         heading={"Select from Asset Library"}
//                         handleDynamicSearch={handleSearchAssets}
//                         // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                         data={assetsDetails?.data?.map(asset => ({name:asset?.generalDetails?.name,id:asset?.id,number:asset?.generalDetails?.number,isNeeded:true})) || []}
//                     /> : <></>}
//                 <div className={Styles.spare_modal_flex_box}>
//                     <div>
//                         <ClonosInput
//                             limit={50}
//                             type="text"
//                             tabIndex={1}
//                             isLabel={true}
//                             isMandatory={true}
//                             label="Spare Name"
//                             uniqueKey="name"
//                             areaLabel="Spare Name"
//                             placeholder="Spare Name"
//                             isSpecialCharacterAllow={true}
//                             handleGetValues={handleGetValues}
//                             errorMessage={"Please provide spare name."}
//                             handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                             defaultValue={formData?.name}
//                         />
//                     </div>
//                     <div className={Styles.cycle_freq}>
//                         <label>Quantity <sup>*</sup></label>
//                         <div className={Styles.inp_sel_wrapper}>
//                         <div className={Styles.input_wrapper}>
//                         <ClonosInput
//                             limit={8}
//                             tabIndex={1}
//                             type="number"
//                             isLabel={false}
//                             placeholder="1234"
//                             isMandatory={true}
//                             areaLabel="Quantity"
//                             uniqueKey="quantity_value"
//                             handleGetValues={handleGetValues}
//                             errorMessage={"Fill this field!."}
//                             handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                             defaultValue={formData?.quantity?.value}
//                         />
//                         </div>
//                         <div className={Styles.select_wrapper}>
//                             <ClonosSelect
//                                 type={"select"}
//                                 isMandatory={true}
//                                 placeholder={"select"}
//                                 handleGetValues={handleGetValues}
//                                 errorMessage={"Fill this field!"}
//                                 uniqueKey={"quantity_type"}
//                                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                                 options={[{label:"mm",isNeeded:true},{label:"Litres",isNeeded:true},{label:"No's",isNeeded:true}]}
//                                 defaultValue={formData?.quantity?.type}
//                             />
//                         </div>
//                     </div>
//                     </div>
//                 </div>
//                 <div className={Styles.spare_modal_flex_box}>
//                     <div className={Styles.cycle_freq}>
//                         <label>Cycle Frequency</label>
//                         <div className={Styles.inp_sel_wrapper}>
//                         <div className={Styles.input_wrapper}>
//                             <ClonosInput
//                                 limit={8}
//                                 isLabel={false}
//                                 isMandatory={false}
//                                 uniqueKey={"cycleFrequency_value"}
//                                 type={"number"}
//                                 placeholder={"1234"}
//                                 handleGetValues={handleGetValues}
//                                 // errorMessage={"Fill this field!"}
//                                 defaultValue={formData?.cycleFrequency?.value}
//                                 // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                             />
//                         </div>
//                         <div className={Styles.select_wrapper}>
//                             {/* <ClonosSelect
//                                 type={"select"}
//                                 isMandatory={true}
//                                 uniqueKey={"cycleFrequency_type"}
//                                 handleGetValues={handleGetValues}
//                                 errorMessage={"Fill this field!"}
//                                 defaultValue={!selectedSpare ? lcServerResponse?.cycleFrequency?.type : selectedSpare?.cycleFrequency?.type}
//                                 placeholder={"select"}
//                                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                                 options={[{label:"Cycle",isNeeded:true}]}
//                             /> */}
//                             <ClonosInput
//                                 disabled={true}
//                                 isLabel={false}
//                                 defaultValue={"Cycle"}
//                             />
//                         </div>
//                     </div>
//                     </div>
//                     <div className={Styles.cycle_freq}>
//                         <label>Replacement Frequency </label>
//                         <div className={Styles.inp_sel_wrapper}>
//                         <div className={Styles.input_wrapper}>
//                             <ClonosInput
//                                 limit={8}
//                                 isLabel={false}
//                                 isMandatory={false}
//                                 uniqueKey={"replacementFrequency_value"}
//                                 type={"number"}
//                                 placeholder={"1234"}
//                                 handleGetValues={handleGetValues}
//                                 // errorMessage={"Fill this field!"}
//                                 defaultValue={formData?.replacementFrequency?.value}
//                                 // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                             />
//                         </div>
//                         <div className={Styles.select_wrapper}>
//                             <ClonosSelect
//                                 type={"select"}
//                                 isMandatory={false}
//                                 placeholder={"select"}
//                                 handleGetValues={handleGetValues}
//                                 errorMessage={"Fill this field!"}
//                                 uniqueKey={"replacementFrequency_type"}
//                                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                                 options={[{label:"Months",isNeeded:true},{label:"Years",isNeeded:true}]}
//                                 defaultValue={formData?.replacementFrequency?.type}
//                             />
//                         </div>
//                     </div>
//                     </div>
//                 </div>
//                 <ClonosInput
//                         // limit={8}
//                         isLabel={true}
//                         label={"Minimum Requirement"}
//                         isMandatory={false}
//                         uniqueKey={"minimumRequirement"}
//                         type={"number"}
//                         placeholder={"1234"}
//                         handleGetValues={handleGetValues}
//                         // errorMessage={"Fill this field!"}
//                         defaultValue={formData?.minimumRequirement}
//                         // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />
//                 <div className={Styles.btns_wrapper}>
//                     <ClonosButton style={{padding:"0.8rem 3rem"}} onClick={() => closeMethod(false)}>Cancle</ClonosButton>
//                     <ClonosButton loading={saveLoader} style={{padding:"0.8rem 3rem"}} onClick={handleSave} variant="filled">Save</ClonosButton>
//                 </div>
//             </div>
//                 </>
//             }
//         </div>
//     </Modal>
// }



import { useEffect, useState } from "react"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button"
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput"
import { ClonosInputWithSelect } from "../../../../components/CommonComponents/ClonosInputWithSelect/ClonosInputWithSelect"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import Styles from "./upload-spare-modal.module.css"
import { v4 as uuidv4 } from 'uuid';
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook"
import { commonPageState, globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../../utils/clonosCommon"
import { useDispatch } from "react-redux"
import useToggler from "../../../../CustomHooks/TogglerHook"
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner"
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect"
import { getSingleSpareDetails, handleGetAssets, handleGetFilledValuesOfSpare, handleCreateSpareHelper, handleCheckUniquenessOfSpare, handleGetSpares } from "../../managers/spares-manager"
import DynamicDropdown from "../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown"
import { useLocation } from "react-router-dom"
import { doGetApiCall } from "../../../../utils/ClonosApi"


export const UploadSpareModal = ({isOpen,closeMethod,getFilledValue,assetId,selectedSpare,saveLoader,spareId,mode,isLinkAssetRequired=false,lcSpares}) => {
    const dispatch = useDispatch();
    const [assetsPaination,setAssetsPaginations] = useState({page:1,limit:15});
    const [sparesPagination,setSparesPaginations] = useState(commonPageState);
    const [fetchLoader,setFetchLoader] = useToggler();
    const [hasSearched, setHasSearched] = useState(false);
    const [quantityUnit,setQuantityUnit]=useState('')
    const [assetsDetails,setAssetsDetails] = useState({});
    const [sparesDetails,setSparesDetails] = useState({});
    const [searchedSpare,setSearchedSpare]=useState({})
    const [formData,setFormData] = useState({});
    const {isClear,primaryObject,handleGetErrorActivatorInformation,handlePrimaryObjectModifier,handleSubmit,handleRemoveField,activeHookInstances,} = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "spares" })
    const [loadingDropdowns, setLoadingDropdowns] = useState({});
   const [staticDropdownData,setStaticDropdownData]=useState({})
    const handleGetValues = (props) => {
        // handleGetFilledValuesOfSpare({componentProps:val,disableSave,setDisableSave,primaryObject,handlePrimaryObjectModifier,setChangedData,setFormData,mode,lcServerResponse,lcSpares,formData})
        handleGetFilledValuesOfSpare({componentProps:props,setFormData,primaryObject,handlePrimaryObjectModifier,formData,mode})

        // Get selected spare name
        const selectedSpareRequestId = props?.updatedValue?.[0]?.id;
        
       
         
        if(props?.updatedValue === null){
            setQuantityUnit(''); // reset to empty string
          return; // Exit early to avoid further execution
        }
    
     
    

        if (selectedSpareRequestId) {
            const matchedPart = formattedDropdownData?.find(
            (spare) => spare?.id === selectedSpareRequestId
            );

            setQuantityUnit(matchedPart?.units);
        } 
    }
        

    const handleSave = () => { 
        if(!handleSubmit()) return 
        if(formData?.isDuplicate) {
            primaryObject.name = { ...primaryObject?.name, value: false };
            primaryObject?.name?.errorActivatorMethod(true);
            primaryObject?.name?.errorSetterMethod(`Already exists, please provide different Spare Name.`)
            return
        }
        getFilledValue(formData)
    }


    const handleSearchSpareName = (props) => {
        const {uniqueKey,input} = props;
        
         if(input.length){
             handleGetSpares({setterMethod:setSearchedSpare, filterPayload: {
                limit: sparesPagination.limit || 15,
                page: 1, // Reset page to 1 for search
                name: input
            }
        })
         }else {
            setSearchedSpare({})
      }
    }
    
    const handleMoreData = () => {
        if(sparesDetails?.totalPageCount > sparesPagination?.page){
            setSparesPaginations(prev =>{
                handleGetSpares({setterMethod:setSparesDetails,filterPayload:{limit:prev?.limit,page:prev?.page + 1}})
                return {...prev,page:prev?.page+1}
            })
        }
    }

    const fetchStaticDropdownByCode = async (code) => {
  if (staticDropdownData[code] || loadingDropdowns[code]) return;

  setLoadingDropdowns(prev => ({ ...prev, [code]: true }));

  try {
    const res = await doGetApiCall({url:`dropdowns/${code}`});
       
    setStaticDropdownData(prev => ({
      ...prev,
      [code]: res?.data?.result?.options
    }));
  } finally {
    setLoadingDropdowns(prev => ({ ...prev, [code]: false }));
  }
};


console.log(formData,"formData")
    useEffect(()=>{
       if(spareId && mode =="edit"){
           setFetchLoader()
           setFormData(selectedSpare)
           setFetchLoader()
       }
    },[spareId])

    // useEffect(() => {
    //     if(spareId && mode === "edit"){
    //         getSingleSpareDetails({spareId,setterMethod:setFormData,setIsLoading:setFetchLoader});
    //     }
    // },[spareId]);
    
    useEffect(() => {
        handleGetSpares({dispatch,setterMethod:setSparesDetails,filterPayload:sparesPagination});
        handleGetAssets({setterMethod:setAssetsDetails,pagination:assetsPaination});
    },[sparesPagination?.page , sparesPagination?.limit])

  

      const spareData = searchedSpare?.data? searchedSpare.data : sparesDetails?.data || [];

      const formattedDropdownData = spareData.map(spare => ({
        name: spare?.name,
        id: spare?.id,
        units:spare?.units,
        isNeeded: true
      }));

    return (
    <>
          <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
            <div className={Styles.spare_modal_container}>
                {fetchLoader ? (
                <div style={{ height: "40vh" }} className="center_wrapper">
                    <ClonosSpinner />
                </div>
                ) : mode === "edit" && !Object.keys(formData)?.length ? (
                <div style={{ height: "40vh" }} className="center_wrapper">
                    <h4>No details found</h4>
                </div>
                ) : (
                <>
                    <div className={Styles.spare_modal_header}>
                    <h4>{mode === "edit" ? "Update Spare" : "Spare Upload"}</h4>
                    <CloseIcon onClick={() => closeMethod(false)} />
                    </div>
                    <div className={Styles.spare_modal_section}>
                    <div className={Styles.spare_modal_flex_box}>
                        {/* Spare Name Dropdown */}
                        <div className={Styles.cycle_freq}>
                        <label>
                            Spare Name <sup>*</sup>
                        </label>
                        <div className={Styles.inp_sel_wrapper}>
                            <div className={Styles.input_wrapper}>
                            <DynamicDropdown
                                isLabel={false}
                                label={"Spare Name"}
                                uniqueKey="name"
                                title={"Spare name"}
                                areaLabel="SpareName"
                                isCheckbox={false}
                                isActivator={true}
                                isMandatory={true}
                                isSearchable={true}
                                placeholder={"search"}
                                populatedFields={["number"]}
                                heading={"Select from Spares Library"}
                                isDynamicLoad={true}
                                handleMoreData={handleMoreData}
                                handleGetValues={handleGetValues}
                                // noDataMessage="No Spares Found"
                                handleDynamicSearch={handleSearchSpareName}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                data={formattedDropdownData || []}
                                defaultValue={
                                formData?.spare
                                    ? [{ name: formData.spare.name,id: formData.spare.id,  isNeeded: true }]
                                    : ""
                                }
                            />
                            {/* <DynamicDropdown
                                    uniqueKey={"name"}
                                    placeholder={"Search"}
                                    isSearchable={true}
                                    isCheckbox={true}
                                    isActivator={true}
                                     label="Email Notification Recipients"
                                    // isMandatory={true}
                                    isDynamicLoad={false}
                                    // data={lcValues.emailNotificationRecipients.length ? lcValues.emailNotificationRecipients : formData.criticalNotificationRecipients?.length ? emailNotificationRecipientsDropdowndataFiltered : emailNotificationRecipientsDropdowndata}
                                    // data={emailNotificationRecipientsDropdowndata}
                                    // handleMoreData={handleMoreData}
                                    heading={"Select from Users Library"}
                                    // handleDynamicSearch={(response) => handleDynamicSearch(response, "emailNotificationRecipients")}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    // defaultValue={mode === "edit" && generalDetails?.emailNotificationRecipients?.length ? generalDetails?.emailNotificationRecipients.map(user => ({id:user?._id , name: user?.name })) : null}
                                    // handleGetValues={(props) =>{handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
                                    // }}
                                /> */}
                            </div>
                        </div>
                        </div>

                        {/* Minimum Spare Quantity + Type */}
                        <div className={Styles.cycle_freq}>
                        <label>
                            Minimum Required Quantity <sup>*</sup>
                        </label>
                        <div className={Styles.inp_sel_wrapper}>
                            <div className={Styles.input_wrapper}>
                            <ClonosInput
                                limit={8}
                                tabIndex={1}
                                type="number"
                                isLabel={false}
                                placeholder="1234"
                                isMandatory={true}
                                areaLabel="Mimimum Required Quantity"
                                uniqueKey="minimumRequiredQuantity"
                                handleGetValues={handleGetValues}
                                errorMessage={"Fill this field!."}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                defaultValue={formData?.minimumRequiredQuantity}
                            />
                            </div>
                            <div className={Styles.select_wrapper}>
                            <ClonosSelect
                                type={"select"}
                                isMandatory={false}
                                placeholder={"Unit"}
                                handleGetValues={handleGetValues}
                                errorMessage={"Fill this field!"}
                                uniqueKey="unit_type"
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                // options={[{ label: "mm", value: "units", isNeeded: true },{ label: "Litres", value: "units", isNeeded: true },{ label: "No's", value: "units", isNeeded: true }]}
                                options={[{label:"mm",isNeeded:true},{label:"Litres",isNeeded:true},{label:"No's",isNeeded:true}]}
                                defaultValue={mode=="edit"? formData?.unit : quantityUnit}
                                disabled={true}
                            />
                            </div>
                        </div>
                        </div>
                    </div>

                    {/* Cycle & Replacement Frequency */}
                    <div className={Styles.spare_modal_flex_box}>
                        <div className={Styles.cycle_freq}>
                        <label>Cycle Frequency</label> 
                        <div className={Styles.inp_sel_wrapper}>
                            <div className={Styles.input_wrapper}>
                            <ClonosInput
                                limit={8}
                                isLabel={false}
                                isMandatory={false}
                                uniqueKey={"cycleFrequency"}
                                type={"number"}
                                placeholder={"1234"}
                                handleGetValues={handleGetValues}
                                defaultValue={formData?.cycleFrequency?.value}
                            />
                            </div>
                            
                            <div className={Styles.select_wrapper}>
                             <ClonosSelect
                                type={"select"}
                                isMandatory={false}
                                placeholder={"Select"}
                                handleGetValues={handleGetValues}
                                errorMessage={"Fill this field!"}
                                uniqueKey="cycleFrequencyType_type"
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                // options={[{ label: "mm", value: "units", isNeeded: true },{ label: "Litres", value: "units", isNeeded: true },{ label: "No's", value: "units", isNeeded: true }]}
                                options={[{label:"cycle",isNeeded:true}]}
                                //options={staticDropdownData?.cycleFrequency?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true }))|| []}
                                // onOpen={() => fetchStaticDropdownByCode("cycleFrequency")}
                                defaultValue={formData?.cycleFrequency?.type}
                            />
                            </div>
                        </div>
                        </div>

                        <div className={Styles.cycle_freq}>
                        <label>Replacement Frequency</label>
                        <div className={Styles.inp_sel_wrapper}>
                            <div className={Styles.input_wrapper}>
                            <ClonosInput
                                limit={2}
                                isLabel={false}
                                isMandatory={false}
                                uniqueKey={"replacementFrequency"}
                                type={"number"}
                                placeholder={"1234"}
                                handleGetValues={handleGetValues}
                                defaultValue={formData?.replacementFrequency?.value}
                            />
                            </div>
                            <div className={Styles.select_wrapper}>
                            <ClonosSelect
                                type={"select"}
                                isMandatory={false}
                                placeholder={"Select"}
                                handleGetValues={handleGetValues}
                                errorMessage={"Fill this field!"}
                                uniqueKey="replacementFrequencyType_type"
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                //options={[{label:"weeks",isNeeded:true},{label:"months",isNeeded:true},{label:"years",isNeeded:true}]}
                                 options={[{ label: "weeks", value: "replacementFrequencyType", isNeeded: true },{ label: "months", value: "replacementFrequencyType", isNeeded: true },{ label: "year", value: "replacementFrequencyType", isNeeded: true }]}
                                // options={staticDropdownData?.replacementFrequency?.map((opt) => ({ label: opt?.value,value:opt?._id ,isNeeded: true })) || []}
                                //onOpen={() => fetchStaticDropdownByCode("replacementFrequency")}
                                defaultValue={formData?.replacementFrequency?.type}
                            />
                            </div>
                        </div>
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className={Styles.btns_wrapper}>
                        <ClonosButton style={{ padding: "0.8rem 3rem" }} onClick={() => closeMethod(false)}>
                        Cancel
                        </ClonosButton>
                        <ClonosButton
                        loading={saveLoader}
                        style={{ padding: "0.8rem 3rem" }}
                        onClick={handleSave}
                        variant="filled"
                        >
                         {mode=="edit"? "Update" : "Link"}
                        </ClonosButton>
                    </div>
                    </div>
                </>
                )}
            </div>
            </Modal>


    </>
    )
}