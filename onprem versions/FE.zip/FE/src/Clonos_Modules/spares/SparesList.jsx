import { useEffect, useState } from "react"
import { ActiveAssetsIcon } from "../../assets/AssetsSVGComponents/ActiveAsssets"
import { AssetsUnderMaintenanceIcon } from "../../assets/AssetsSVGComponents/AssetUnderMaintenance"
import { TotalAssetsIcon } from "../../assets/AssetsSVGComponents/TotalAssets"
import { checkUserHasPermission, generateSkeletonColumns, handleShowErrorAndWarning, setSerialNumber } from "../../utils/clonosCommon"
import { CLONOS_GLOBAL_ACTION_CREATE } from "../../Constants/Constant"
import ClonosSkeletonLoading from "../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading"
import { ClonosButton } from "../../components/CommonComponents/Button/Button"
import ClonosGridNav from "../../utils/ClonosGridNav"
import { Card } from "@material-ui/core"
import ClonosDataGrid from "../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { UploadSpareModal } from "./components/upload-spare-modal/UploadSpareModal"
import { getAllSparesList, getSparesCounts, handleCreateSingleSpareMethod, handleDeleteSpareMethod, handleEditSpareMethod } from "./managers/spares-manager"
import useToggler from "../../CustomHooks/TogglerHook"
import { useDispatch } from "react-redux"
import Modal from "../../components/CommonComponents/Modal/Modal"
import Styles from "./style/spares.module.css"
import EditIcon from "../../assets/Clonos Common Indicators/Icon_Components/EditIcon"
import DeleteIcon from "../../assets/Clonos Common Indicators/Icon_Components/DeleteIcon"
import CloseIcon from "../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import ClonosTooltip from "../../components/CommonComponents/ClonosTooltip/ClonosTooltip"
import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"


const SparesList = () => {
	const dispatch = useDispatch();
	const [data,setData] = useState({});
	const [selectedSpare,setSelectedSpare] = useState({})
	const [selectedRows,setSelectedRows] = useState([]);
    const [navCounts,setNavCounts] = useState({});
	const [showConfirmationBox,setShowConfirmationBox] = useState(false)
	const [loaderAndModalStates,setLoaderAndModalStates] = useState({
		navCountsLoader:false,
		sparesLoader:false,
		showCreateSpareModal:false,
		showEditSpareModal:false,
		showViewSpareModal:false,
		createSpareLoader:false,
		editSpareLoader:false,
		deleteSpareLoader:false
	});
	const [pagination,setPagination] = useState({page:1,limit:15})
	const columns = [
		{
			field:"index",
			headerName:"SI.NO",
			width:100,
		},
		{
			field:"name",
			headerName:"SPARE NAME",
			flex:1,
			renderCell:(param) => {
				return <p onClick={() => {
					setLoaderAndModalStates((prev) => ({...prev,showViewSpareModal: true}));
					setSelectedSpare(param?.row)
				}} className="clonos_datagrid_link">{param?.row?.name}</p>
			}
		},
		{
			field:"quantity",
			headerName:"QUANTITY",
			flex:1,
		},
		// {
		// 	field:"cycleFrequency",
		// 	headerName:"CYCLE FREQUENCY",
		// 	flex:1,
		// 	renderCell:(param) => {
		// 		console.log(param,"param")
		// 		return <p>{param?.row?.cycleFrequency ? `${param?.row?.cycleFrequency?.count} ${param?.row?.cycleFrequency?.period}` : "-"}</p>
		// 	}
		// },
		{
			field:"replacementFrequency",
			headerName:"REPLACEMENT FREQUENCY",
			flex:1,
			renderCell:(param) => {
				const cycleFrequencyToShow = param?.row?.cycleFrequency ? `${param?.row?.cycleFrequency?.count} ${param?.row?.cycleFrequency?.period?.toUpperCase()}` :"" ;
				const replacementFrequencyToShow = param?.row?.replacementFrequency ? `${param?.row?.replacementFrequency?.count} ${param?.row?.replacementFrequency?.period?.toUpperCase()}` :"";
				let finalStringToShow = "";
				if(cycleFrequencyToShow && replacementFrequencyToShow) {
					finalStringToShow = `${cycleFrequencyToShow} | ${replacementFrequencyToShow}`
				} else if(cycleFrequencyToShow || !replacementFrequencyToShow){
					finalStringToShow = `${cycleFrequencyToShow}`
				} else if(!cycleFrequencyToShow || replacementFrequencyToShow){
					finalStringToShow = `${replacementFrequencyToShow}`
				} else {
					finalStringToShow = "-"
				}
				
				return <p>{finalStringToShow}</p>
			}
		},
	]

	const handleCreateSpare = async (val) => {
		try {
			const res = await handleCreateSingleSpareMethod({dispatch,payload:val,setIsLoading:() => setLoaderAndModalStates(prev => ({...prev,createSpareLoader:!prev.createSpareLoader}))});
			if(res?.ids?.length){
				handleShowErrorAndWarning({dispatch,type:"success",message:"Spare created successfully.",showTime:"5000"})
				setLoaderAndModalStates((prev) => ({...prev,showCreateSpareModal:false}))
				getAllSparesList({setterMethod:setData,setIsLoading:setLoaderAndModalStates,page:1,limit:15})
			}
		} catch (error) {
			console.log(error,"error123");
		}
	}

	const handleEditSpare = async (changedValue) => {
		try{
			const response = await handleEditSpareMethod({dispatch,payload:changedValue,setIsLoading:() => setLoaderAndModalStates(prev => ({...prev,editSpareLoader:!prev.editSpareLoader}))});
			if(response){
				handleShowErrorAndWarning({dispatch,type:"success",message:"Spare updated successfully.",showTime:"5000"});
				setLoaderAndModalStates((prev) => ({...prev,showEditSpareModal:false,showViewSpareModal:false}));
				getAllSparesList({setterMethod:setData,setIsLoading:() => setLoaderAndModalStates(prev => ({...prev,sparesLoader:!prev?.sparesLoader})) ,page:1,limit:15});
				setSelectedRows([])
			}
		} catch(err) {
			console.error(err)
		} 
	} 

	const handleDeleteSpare = async () => {
		try {
			const sparesToDelete = selectedSpare?.id ? [selectedSpare?.id] : selectedRows;
			const response = await handleDeleteSpareMethod({payload:{spares:sparesToDelete},setIsLoading:() => setLoaderAndModalStates((prev) =>({...prev,deleteSpareLoader:!prev?.deleteSpareLoader}))});
			if(response){
				handleShowErrorAndWarning({dispatch,type:"success",message:"Spare deleted successfully.",showTime:"5000"});
				setLoaderAndModalStates((prev) => ({...prev,showViewSpareModal:false}));
				setShowConfirmationBox(false);
				setSelectedSpare({})
				getAllSparesList({setterMethod:setData,setIsLoading:() => setLoaderAndModalStates(prev => ({...prev,sparesLoader:!prev?.sparesLoader})) ,page:1,limit:15});
			}
		} catch (error) {
			console.error(error)
		}
	}

	useEffect(() => {
		getSparesCounts({setterMethod:setNavCounts,setIsLoading:() => setLoaderAndModalStates(prev => ({...prev,navCountsLoader:!prev?.navCountsLoader}))});
	},[data?.data?.length])

	useEffect(() => {
		getAllSparesList({setterMethod:setData,setIsLoading:() => setLoaderAndModalStates(prev => ({...prev,sparesLoader:!prev?.sparesLoader})),page:pagination?.page,limit:pagination?.limit})
	},[pagination])

	// useEffect(() => {
	// 	if(!loaderAndModalStates?.showEditSpareModal && !loaderAndModalStates?.showViewSpareModal){
	// 		setSelectedSpare({})
	// 	}
	// },[loaderAndModalStates?.showEditSpareModal,loaderAndModalStates?.showViewSpareModal])
	

    return (
        <>
            <ClonosGridNav isLoading={loaderAndModalStates?.navCountsLoader} items={[
					{
						icon: TotalAssetsIcon,
						iconBg: '#E7EFFF',
						title: 'Total Spares',
						count: data?.totalDataCount || 0,
					},
					// {
					// 	icon: ActiveAssetsIcon,
					// 	iconBg: '#EBFAEC',
					// 	title: 'Active Assets',
					// 	count: navCounts?.activeAssets || 0
					// },
				]}>
					<div className="d-fl-al-cen">
						{checkUserHasPermission({moduleName:"assets",action:CLONOS_GLOBAL_ACTION_CREATE}) ?  <ClonosButton className="ml-half" variant={"filled"} onClick={() => setLoaderAndModalStates((prev) => ({...prev,showCreateSpareModal:true}))} >Create New Spare</ClonosButton> : <></>}
					</div>
            </ClonosGridNav>
			<Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", padding: "2rem 1rem",overflowY:"scroll" }}>
				<div className={Styles.sp_datagrid_wrapper}>
				<ClonosDataGrid
					columns={columns}
					uniqueIdField={"id"}
					pageLimit={pagination.limit}
					totalCount={data?.totalDataCount}
					loading={loaderAndModalStates?.sparesLoader}
					isDeleteMethod={() => setShowConfirmationBox(true)}
					handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
					rows={setSerialNumber(data?.data || [],pagination?.page,pagination?.limit)}
					onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
					isEditMethod={() => setLoaderAndModalStates((prev) => ({...prev,showEditSpareModal:true}))}
				/>
				</div>
			</Card>
			{loaderAndModalStates?.showCreateSpareModal ? <UploadSpareModal closeMethod={setLoaderAndModalStates}	loading={loaderAndModalStates.createSpareLoader}	getFilledValue={handleCreateSpare}	isOpen={loaderAndModalStates?.showCreateSpareModal}/> : <></>}
			{loaderAndModalStates?.showViewSpareModal ? <ViewSpareModal isOpen={loaderAndModalStates?.showViewSpareModal} closeMethod={setLoaderAndModalStates} selectedSpare={selectedSpare} setShowConfirmationBox={setShowConfirmationBox}/>  : <></>}
			{loaderAndModalStates?.showEditSpareModal ? <UploadSpareModal	mode={"edit"}	spareId={selectedRows[0] || selectedSpare?.id}	closeMethod={() => setLoaderAndModalStates((prev) => ({...prev,showEditSpareModal:!prev.showEditSpareModal}))}	loading={loaderAndModalStates.editSpareLoader}	getFilledValue={handleEditSpare}	isOpen={loaderAndModalStates?.showEditSpareModal}/> : <></>}
			<ClonosConfirmationBox loading={loaderAndModalStates?.deleteSpareLoader} isOpen={showConfirmationBox}  message={`Do you confirm that you need to delete ${selectedRows?.length > 1 ? "these spares" : "this spare"} ?`} headerTitle={"Delete Spare"} confirmingMethod={handleDeleteSpare} closeModalMethod={setShowConfirmationBox} rejectingMethod={setShowConfirmationBox}/>
        </>
    )
}

export default SparesList


const ViewSpareModal = ({isOpen,closeMethod,selectedSpare,setShowConfirmationBox}) => {
	const fields = [{label:"Spare Name",key:"name"},{label:"Quantity",key:"quantity"},{label:"Cycle Frequency",key:"cycleFrequency"},{label:"Replacement Frequency",key:"replacementFrequency"}]
	
	return <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
		<div className={Styles.v_s_container}>
			{Object?.keys(selectedSpare)?.length ? <>
				<div className={Styles.v_s_header}>
				<h4>Spare View</h4>
				<div className={Styles.v_s_icon_wrapper}>
					<EditIcon onClick={() => closeMethod((prev) => ({...prev,showEditSpareModal:true}))}/>
					<DeleteIcon onClick={() => setShowConfirmationBox(true)}/>
					<CloseIcon onClick={() => closeMethod((prev) => ({...prev,showViewSpareModal:false}))}/>
				</div>
			</div>
			<div className={Styles.v_s_section}>
				<div >
					{
						fields?.map((field,index) => {
							let  {count,period} = selectedSpare?.[field?.key];
							return <div key={index} className={Styles.field_wrapper}>
								<h4>{field?.label}</h4>
								{
									field?.key === "name" || field?.key === "quantity" 
									? <p className={Styles.field_val}>{selectedSpare[field.key]}</p> 
									: <p className={Styles.field_val}>{count && period ? `${count} ${period}` : "-"}</p>
								}
							</div>
						})
					}
				</div>
			</div>
			</> : <div style={{display:"flex",justifyContent:"center",alignItems:"center",height:"400px"}}>
					<h4>No Data Found!</h4>
				</div>}
		</div>
	</Modal>
}



