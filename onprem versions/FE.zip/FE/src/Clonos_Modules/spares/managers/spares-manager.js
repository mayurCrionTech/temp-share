import { message } from "antd";
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_UNAUTHORIZED_ERROR } from "../../../Constants/Constant";

import AppUrl from "../../../utils/AppUrl"
import { doDeleteApiCall, doGetApiCall, doPatchApiCall, doPostApiCall, doPutApiCal, doPutApiCall } from "../../../utils/ClonosApi";
import { debounce, handleShowErrorAndWarning, modifyString } from "../../../utils/clonosCommon";
import { handleCheckUniqueFieldsMethod } from "../../../utils/common-managers";


export const handleCheckUniquenessOfSpare = ({primaryObject,fieldValue,setFormData,handlePrimaryObjectModifier,uniqueKey}) => {
    handleCheckUniqueFieldsMethod({ module:"spares", fieldName:"name", fieldValue}).then((res) => {
    
        if (res === "not_unique") {
            setFormData(prev => ({...prev,isDuplicate:true}))
            primaryObject.name = { ...primaryObject?.name, value: false };
            primaryObject?.name?.errorActivatorMethod(true);
            primaryObject?.name?.errorSetterMethod(`Already exists, please provide different Spare Name.`)
        } else {
            setFormData(prev => ({...prev,isDuplicate:false}))
            handlePrimaryObjectModifier({uniqueKey,response:fieldValue})
            setFormData(prev => ({...prev,name:fieldValue}))
        }
    })
}

export const debouncedCheckUniquenessOfSpare = debounce(handleCheckUniquenessOfSpare,500)


export const isSpareExistsLocally = ({fieldName,fieldValue,lcSpares,spareDetail}) => {
    for(let i = 0;i < lcSpares?.length;i++) {
        if(lcSpares[i]?.[fieldName] === fieldValue && spareDetail?.id !== lcSpares[i]?.id) {
            return true;
        } 
    }
    return false
}


export const handleGetFilledValuesOfSpare = ({componentProps,mode,setFormData,primaryObject,handlePrimaryObjectModifier,formData}) => {
    let {type,uniqueKey,updatedValue,selectedOption} = componentProps;
           console.log(updatedValue,"updatedvalue")
        const [mainKey,subKey] = uniqueKey.split("_");        // return [value,type]
        if (type === "select") {
            handlePrimaryObjectModifier({uniqueKey,response: updatedValue});
           
            // setFormData((prev) => ({ ...prev, [mainKey]:{...prev[mainKey],[subKey]:updatedValue?.label} }));
               setFormData((prev) => ({ ...prev,[mainKey]: { ...prev[mainKey], [subKey]: {name: updatedValue?.label,id: updatedValue?.value}}}));
        } else if (type === "text" || type === "number") {
            handlePrimaryObjectModifier({uniqueKey,response: updatedValue, });
            if(subKey === "value"){
                updatedValue = Number(updatedValue)
                if(mainKey === "cycleFrequency"){
                    setFormData((prev) => ({ ...prev, [mainKey]:{value : updatedValue,type :"Cycle"} }));
                } else {
                    setFormData((prev) => ({ ...prev, [mainKey]:{...prev[mainKey],[subKey]:updatedValue} }));
                }
            } else {
                if(uniqueKey === "name") {
                    if(mode === "edit" && formData?.serverName !== updatedValue) {
                        debouncedCheckUniquenessOfSpare({primaryObject,formData,setFormData,fieldValue:updatedValue,handlePrimaryObjectModifier,uniqueKey})
                    } else if(mode === "create"){
                        debouncedCheckUniquenessOfSpare({primaryObject,formData,setFormData,fieldValue:updatedValue,handlePrimaryObjectModifier,uniqueKey})
                    } else {
                        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
                    }
                } else {
                    setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
                }
            }
        }
         else if (type === "dynamicDropdown") {
            handlePrimaryObjectModifier({ uniqueKey, response: selectedOption });
         
            if (Array.isArray(selectedOption) && selectedOption.length > 0) {
                setFormData((prev) => ({
                ...prev,
                [uniqueKey]: {
                    name: selectedOption[0].name,
                    id: selectedOption[0].id,
                    ...(selectedOption[0].units !== undefined && { units: selectedOption[0].units })
                }
                }));
            } else {
                // If nothing is selected, clear the value or leave unchanged
                setFormData((prev) => ({
                ...prev,
                [uniqueKey]: null   // or {}
                }));
            }
            }

    }




export const handleGetSparesStaticDropdownEnums = ({dispatch}) => {
    doGetApiCall({url:"/spares/dropdown"})
    .then((res) => res)
    .catch((err) => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
} 

// export const handleCreateSingleSpareMethod = async ({dispatch,payload,setIsLoading,next}) => {
//         console.log(payload,"payload")
//         setIsLoading();
//         const {name,assetId,quantity,cycleFrequency,replacementFrequency,minimumRequirement} = payload;
//         const requestPayload = {};
//         requestPayload.name = name;
//         requestPayload.quantity = quantity;
//         if(assetId) requestPayload.assetId = assetId;
//         if(cycleFrequency && Object?.keys(cycleFrequency||{})?.length >= 2) requestPayload.cycleFrequency = cycleFrequency;
//         if(replacementFrequency && Object?.keys(replacementFrequency||{})?.length >= 2) requestPayload.replacementFrequency = replacementFrequency;
//         requestPayload.minimumRequirement = minimumRequirement || 0;
//         doPostApiCall({url:AppUrl.createSpare,payload:{spares:[requestPayload]}})
//         .then((response) => {
//             if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
//                 next && next()
//             } else {
//                 handleShowErrorAndWarning({dispatch,type:"error",message:response?.response?.data?.errorInfo || response?.response?.data?.message,showTime:"5000"})
//             }
//         })
//         .catch(err => console.log(err))
//         .finally(() => setIsLoading())
// }
export const handleCreateSingleSpareMethod = async ({dispatch,payload,setIsLoading,next}) => {
      
        setIsLoading();
        const {name,assetId,cycleFrequency,replacementFrequency,replacementFrequencyType,minimumRequiredQuantity,unit,cycleFrequencyType} = payload;
        const requestPayload = {};
        requestPayload.spareId =name?.id 
        requestPayload.name = name?.name;
        // if(assetId) requestPayload.assetId = assetId;
       // if(cycleFrequency && Object?.keys(cycleFrequency||{})?.length >= 2) requestPayload.cycleFrequency = Number(cycleFrequency);
        // if (cycleFrequency && cycleFrequencyType?.type) {
        //     requestPayload.cycleFrequency = {
        //         value: Number(cycleFrequency),
        //         type: cycleFrequencyType.type
        //     };
        // }
        // if (replacementFrequency && replacementFrequencyType?.type) {
        //     requestPayload.replacementFrequency = {
        //         value: Number(replacementFrequency),
        //         type: replacementFrequencyType.type
        //     };
        // }
          if (cycleFrequency && cycleFrequencyType?.type) {
            requestPayload.cycleFrequency = {
                value: Number(cycleFrequency),
                 id:cycleFrequencyType?.type?.id,
                type: cycleFrequencyType.type?.name
            };
        }
        if (replacementFrequency && replacementFrequencyType?.type) {
            requestPayload.replacementFrequency = {
                value: Number(replacementFrequency),
                id:replacementFrequencyType?.type?.id,
                type: replacementFrequencyType.type?.name
            };
        }

        requestPayload.minimumRequiredQuantity = Number(minimumRequiredQuantity) 
       
        requestPayload.unit = name?.units
        
        doPostApiCall({url:`assets/${assetId}/spares`,payload:requestPayload})
        .then((response) => {
            if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
                next && next()
            } else {
                handleShowErrorAndWarning({dispatch,type:"error",message:response?.response?.data?.errorInfo || response?.response?.data?.message,showTime:"5000"})
            }
        })
        .catch(err => console.log(err))
        .finally(() => setIsLoading())
}


export const getSingleSpareDetails = async ({dispatch,setterMethod,spareId,setIsLoading,altSetterMethod}) => {
    setIsLoading();
    const url = `${AppUrl?.getSingleSpare}/${spareId}`;
    const filterPayload = {
        selectFields:"name,quantity,cycleFrequency,replacementFrequency,minimumRequirement",
    }
    doGetApiCall({url,params:filterPayload}).then((res) => {
        const data = res?.data?.result;
        setterMethod({...data,serverName:data?.name});
        altSetterMethod && altSetterMethod(res?.data?.result)
    }).catch(err => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
    .finally(() => {
        setIsLoading()
    })
}


export const handleDeleteSpareMethod = ({dispatch,payload,assetId,setIsLoading,next}) => {
        setIsLoading && setIsLoading()
       

        doDeleteApiCall({url:`assets/${assetId}/spares`, payload:payload})
         .then((response) => {
            if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
                next && next()
            } else {
                handleShowErrorAndWarning({dispatch,type:"error",message:response?.response?.data?.errorInfo || response?.response?.data?.message,showTime:"5000"})

            }
        })
        .catch((err) => {
            handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
        }).finally(() => {
            setIsLoading && setIsLoading()
        })
        // doPutApiCall({url:AppUrl.deleteSpares,payload})
        // .then((response) => {
        //     if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
        //         next && next()
        //     } else {
        //         handleShowErrorAndWarning({dispatch,type:"error",message:response?.response?.data?.errorInfo || response?.response?.data?.message,showTime:"5000"})

        //     }
        // })
        // .catch((err) => {
        //     handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
        // }).finally(() => {
        //     setIsLoading && setIsLoading()
        // })
}

// export const handleDeleteSpareMethod = ({dispatch,payload,setIsLoading,next}) => {
//         setIsLoading && setIsLoading()
//         doPutApiCall({url:AppUrl.deleteSpares,payload})
//         .then((response) => {
//             if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
//                 next && next()
//             } else {
//                 handleShowErrorAndWarning({dispatch,type:"error",message:response?.response?.data?.errorInfo || response?.response?.data?.message,showTime:"5000"})

//             }
//         })
//         .catch((err) => {
//             handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
//         }).finally(() => {
//             setIsLoading && setIsLoading()
//         })
// }

// export const handleEditSpareMethod = async ({dispatch,assetId,payload,setIsLoading,next}) => {
//         setIsLoading();
//         const requestPayload = {id:payload?.id,assetId};
//         console.log(payload,"paylaod from edit")
//         const {name,quantity,cycleFrequency,replacementFrequency,minimumRequirement} = payload;
//         if(payload?.name) requestPayload.name = name;
//         if(payload?.quantity) requestPayload.quantity = quantity;
//         if(cycleFrequency && Object?.keys(cycleFrequency||{})?.length >= 2) requestPayload.cycleFrequency = cycleFrequency;
//         if(replacementFrequency && Object?.keys(replacementFrequency||{})?.length >= 2) requestPayload.replacementFrequency = replacementFrequency;
//         if(payload?.minimumRequirement) requestPayload.minimumRequirement = minimumRequirement
//         doPutApiCall({url:AppUrl.editSpare,payload:{spares:[requestPayload]}})
//         .then((response) => {
//             if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
//                 next && next();
//             } else {
//                 handleShowErrorAndWarning({dispatch,type:"error",message:response?.response?.data?.errorInfo || response?.response?.data?.message,showTime:"5000"})

//             }
//         })
//         .catch(err => {
//             console.log(err,"errrrerere")
//             // handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
//         })
//         .finally(() => {
//             setIsLoading();
//         })
// }
export const handleEditSpareMethod = async ({dispatch,spareId,assetId,payload,setIsLoading,next}) => {
        setIsLoading();
        const requestPayload={}
        const {name,cycleFrequency,replacementFrequency,replacementFrequencyType,cycleFrequencyType,minimumRequiredQuantity,unit} = payload;
        if(payload?.name?.id) requestPayload.spareId = name.id
        if(payload?.name?.name) requestPayload.name = name.name
       // if(cycleFrequency && Object?.keys(cycleFrequency||{})?.length >= 2) requestPayload.cycleFrequency = Number(cycleFrequency);
        //if(replacementFrequency && Object?.keys(replacementFrequency||{})?.length >= 2) requestPayload.replacementFrequency = Number(replacementFrequency);
        //  if (cycleFrequency && cycleFrequencyType?.type) {
        //     requestPayload.cycleFrequency = {
        //         value: Number(cycleFrequency),
        //         type: cycleFrequencyType.type
        //     };
        // }
        // if (replacementFrequency && replacementFrequencyType?.type) {
        //     requestPayload.replacementFrequency = {
        //         value: Number(replacementFrequency),
        //         type: replacementFrequencyType.type
        //     };
        // }
          if (cycleFrequency && cycleFrequencyType?.type) {
            requestPayload.cycleFrequency = {
                value: Number(cycleFrequency),
                 id:cycleFrequencyType?.type?.id,
                type: cycleFrequencyType.type?.name
            };
        }
        if (replacementFrequency && replacementFrequencyType?.type) {
            requestPayload.replacementFrequency = {
                value: Number(replacementFrequency),
                id:replacementFrequencyType?.type?.id,
                type: replacementFrequencyType.type?.name
            };
        }
        if(payload?.minimumRequiredQuantity) requestPayload.minimumRequiredQuantity = Number(minimumRequiredQuantity)
        if(payload?.unit)  requestPayload.unit = unit?.type

        doPatchApiCall({url:`assets/${assetId}/spares/${spareId}`,payload:requestPayload})
        .then((response) => {
            if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
                next && next();
            } else {
                handleShowErrorAndWarning({dispatch,type:"error",message:response?.response?.data?.errorInfo || response?.response?.data?.message,showTime:"5000"})

            }
        })
        .catch(err => {
            console.log(err,"errrrerere")
            // handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
        })
        .finally(() => {
            setIsLoading();
        })
}
export const getSparesCounts = ({setterMethod,setIsLoading}) => {
    setIsLoading()
    doGetApiCall({url:AppUrl.getSparesCount}).then((res) => {
        setterMethod(res?.data?.result)
    }).finally(() => {
        setIsLoading()
    })
    
}

export const getAllSparesList = ({dispatch,setterMethod,setIsLoading,page,limit}) => {
    setIsLoading();
    const filterPayload = {
        selectFields:"name,quantity,cycleFrequency,replacementFrequency",
    }
    doGetApiCall({url:AppUrl.getAllSpares,params:{page,limit,...filterPayload,sort:"createdAt",order:"desc"}}).then((res) => {
        setterMethod(res?.data?.result)
    }).catch(err => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
    .finally(() => {
        setIsLoading();
    })
}

export const handleGetSparesList = ({dispatch,assetId,setterMethod,setIsLoading,pagination})=>{
    setIsLoading && setIsLoading(true)
    doGetApiCall({url:`assets/${assetId}/spares`,params:pagination})
    .then((res)=>{
       
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        }
    })
    .catch(err => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
    .finally(() => {
        setIsLoading();
    })
}
export const handleGetAssets = ({dispatch,setterMethod,setIsLoading,pagination}) => {
    setIsLoading && setIsLoading(true)
    doGetApiCall({url:AppUrl.getAssets,params:pagination})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            setterMethod(res?.data?.result)
        } else {
            throw new Error("Failed to fetch assets!")
        }
    })
    .catch((err) => {
        handleShowErrorAndWarning({dispatch,type:"error",message:err?.response?.data?.errorInfo || err?.response?.data?.message,showTime:"5000"})
    })
    .finally(() => setIsLoading && setIsLoading(false))
}


export const handleGetSpares = ({ setterMethod, setIsLoading, filterPayload }) => {
    setIsLoading && setIsLoading(true);

    doGetApiCall({ url: AppUrl?.getAllAssetSpares, params: { ...(filterPayload || {}) } })
        .then((res) => {
           
            if (res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
                const data = {
                    ...(res?.data?.result || {}),
                    data: res?.data?.result?.data?.map(spare => ({
                        id: spare?.id,
                        name: `${spare?.name?.trim() ?? ''}${spare?.specification?.trim() ?? ''}`.trim(),
                        units:spare?.units
                    }))
                };

                setterMethod((prev) => {
                    // If it's a search, replace the data
                    if (filterPayload?.name) {
                        return data;
                    } else {
                        const prevData = prev?.data?.length ? [...prev?.data] : [];

                        if (prevData?.length) {
                            const uniqueSpareMap = prevData.reduce((acc, spare) => {
                                if (!acc[spare?.name]) {
                                    acc[spare?.name] = spare;
                                }
                                return acc;
                            }, {});

                            const newSpares = data?.data?.filter(spare => !uniqueSpareMap[spare?.name]);

                            return {
                                ...data,
                                data: [...prevData, ...newSpares]
                            };
                        } else {
                            return data;
                        }
                    }
                });
            }
        })
        .finally(() => {
            setIsLoading && setIsLoading(false);
        });
};


export const handleCreateSpareHelper = ({formData,primaryObject,setIsLoading,closeMethod}) => {
    // handleCreateSingleSpareMethod
}



export const handleGetChangedFielsOfSpare = ({lcSpare,serverSpare}) => {
    const requestPayload = {};
    const fields = ["name","unit","cycleFrequency","cycleFrequencyType","replacementFrequencyType","replacementFrequency","minimumRequiredQuantity"]
    fields.forEach((field) => {
        if(typeof serverSpare[field] === "object") {
            if(lcSpare[field].type !== serverSpare[field].type || lcSpare[field].value !== serverSpare[field].value){
                requestPayload[field] = lcSpare[field]
            }
        } else {
            if(lcSpare[field] !== serverSpare[field]){
                requestPayload[field] = lcSpare[field]
            }
        }
    })
    return requestPayload
}