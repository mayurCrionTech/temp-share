// All Imports 

// Style Imports 
import Styles from "./CreateChecklistGeneralDetails.module.css";

// Default Hooks 
import React from 'react'
import { useEffect } from "react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";

// Constants Imports 
import { daysStaticData } from "../../../../Constants/StaticData";
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_LOGS, CLONOS_GLOBAL_SPECIFIC_DAY_SATURDAY, CLONOS_GLOBAL_SPECIFIC_DAY_SUNDAY, CLONOS_GLOBAL_TIME_PERIOD_DAY, CLONOS_GLOBAL_TIME_PERIOD_HOUR, CLONOS_GLOBAL_TIME_PERIOD_MONTH, CLONOS_GLOBAL_TIME_PERIOD_WEEK, CLONOS_GLOBAL_TIME_PERIOD_YEAR } from "../../../../Constants/Constant";

// Methods Imports
import {
  handleEditChecklistGeneralDetails,
  handleSaveChecklistGeneralDetails,
  handleGetSingleLog,
  handleIsReadyForUserSpecificCustomization,
} from "../../../../utils/LogAndReportsMethods/LogMethods";
import AppUrl from "../../../../utils/AppUrl";
import { doGetApiCall, doPostApiCall } from "../../../../utils/ClonosApi";
import { checkUserHasPermission, commonPageState, convertISTtoUTC, dateModifierAndParser, getDayMonthYear, getToken, handleClientDateInConfiguredTimeZone, handleLoggedInUser, handleRemoveDuplicatesFromAnArray, handleServerDateInConfiguredTimeZone, handleShowErrorAndWarning, modifyString, parseISOTimeString, timeDifference } from "../../../../utils/clonosCommon";
// Custom Hook Imports 
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";

// Local Components Imports 
import RecurrenceCustomization from "../../Components/FrequencyBasedRecurrenceCustomization/RecurrenceCustomization";
import ClonosSpecifyFromAndTo from "../../Components/ClonosSpecifyFromAndTo/ClonosSpecifyFromAndTo";
import UserSpecificCustomization from "../../Components/UserSpecificCustomization/UserSpecificCustomization";

// General Components Imports
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import DynamicDropdown from "../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import ClonosSelect from "../../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosInput from "../../../../components/CommonComponents/ClonosInput/ClonosInput";
import ClonosTextarea from "../../../../components/CommonComponents/ClonosTextarea/ClonosTextarea";
import { ClonosToggleButton } from "../../../../components/CommonComponents/ClonosToggleButton/ClonosToggleButton";
import ClonosRadioAndCheckbox from "../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";

// MUI Imports 
import { Card } from "@mui/material";
import { handleGetValues } from "../../../../utils/ChecklistAndReportsMethods/CommonMethods";
import useMultiPagination from "../../../../CustomHooks/MultiPaginationHook";
import useDebounce from "../../../../CustomHooks/DebounceHook";
import { axiosInstance } from "../../../../Api/AxioClient";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { UnAuthorizedModal } from "../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";


const CreateChecklistGeneralDetails = ({ mode }) => {
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const [formData, setFormData] = useState({ isRecurrence: false, });
  const [teamDropdownData, setTeamDropdownData] = useState([]);
  const [frequencyDropdownData, setFrequencyDropdownData] = useState([]);
  const [departmentDropdownData, setDepartmentDropdownData] = useState([]);
  const [usersDropdownData, setUsersDropdownData] = useState([]);
  const [approversDropdowndata,setApproversDropdownData]=useState([])
  const [emailNotificationRecipientsDropdowndata,setemailNotificationRecipientsDropdownData]=useState([])
  const [criticalNotificationRecipientsDropdowndata,setcriticalNotificationRecipientsDropdownData]=useState([])
  const [emailNotificationRecipientsDropdowndataFiltered, setemailNotificationRecipientsDropdowndataFiltered] = useState([]);
  const [criticalNotificationRecipientsDropdowndataFiltered, setcriticalNotificationRecipientsDropdowndataFiltered] = useState([]);

  
  const LOCATION = useLocation();
  const { state } = LOCATION;
  const [lcValues, setLcValues] = useState(
    {
      "editGeneralDetailsLoading": false,
      "checklistGeneralDetailsLoading": false,
      "savingLogsGeneralDetailsAsDraftLoading": false,
      "isChangesMade": false,
      mode,
      assetSearchedData: [],
      approverUsers: [],
      assignees:[],
      approvers:[],
      emailNotificationRecipients:[],
      criticalNotificationRecipients:[],
    }
  );
  const [serverResponse, setServerResponse] = useState({
    generalDetails: {},
    assets: {},
    departments: {},
    teams: {},
    assignees: {},
  });

  const [cancelOrGoBackAlert, setCancelOrGoBackAlert] = useState(false);
  const [saveAsDraftLogAlert, setSaveAsDraftLogAlert] = useState(false);
  const [searchAndFilters, setSearchAndFilters] = useState({ assetSearchAndFilterDataRequest: {}})
  const { assetSearchAndFilterDataRequest } = searchAndFilters;
  const [uniqueRecurrenceCombinations, setUniqueRecurrenceCombinations] = useState({});
  const { generalDetails, assets } = serverResponse;
  const { approver } = searchAndFilters; // field search and filter.
  const {
    handleGetErrorActivatorInformation,
    handlePrimaryObjectModifier,
    handleSubmit,
    handleGetUpdatedPrimaryObject,
    handleRemoveField
  } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "generalDetails" });

  const { handleSetPage, handleSetLimit, paginations } = useMultiPagination({
    asset: commonPageState,
  });
  const checklistNameUniqueness = useDebounce(formData?.name, 500);
  const checklistDocumentNumberUniqueness = useDebounce(formData?.documentNumber, 500);
  const [isUnique, setIsUnique] = useState(false);
 
  // To get the teams based on departments 
  const handleGetTeams = (departments) => {
    doGetApiCall({ url: AppUrl.getTeams, params: {selectFields: "name", departments } }).then((res) => {
      setTeamDropdownData(res?.data?.result?.data);
    });
  };
   
  const handleGetUsers = ({ departments }) => {
    return doGetApiCall({ url: AppUrl.getAllUsers, params: { selectFields: "name", departments } })
      .then((res) => {
        
        setUsersDropdownData(res?.data?.result?.data);
        setLcValues((prev) => ({
          ...prev,
          assignees: res?.data?.result?.data  // Initially set assignees as the full list
        }));
  
      });
  };
  
  
  // This function will redirect to edit template page.
  const handleGoToEditTemplate = () => {
    Navigate(`/edit-log-template/${formData?.name ? formData?.name : generalDetails?.name}`, { state: { logId: state?.logId,logName:formData?.name ? formData?.name : generalDetails?.name, structureId: generalDetails?.structureId } });
  };

  const handleGetAssets = ({ page, limit = 15, name }) => {
    return doGetApiCall({ url: AppUrl.getAssets, params: { page, limit, name } }).then((res) => {
   
      return { ...res?.data?.result, data: (res?.data?.result?.data || []).map(item => ({ id: item?.id, name: item?.generalDetails?.name })) };
    });
  };

  const handleLoadMoreData = ({ uniqueKey }) => {
   
    let pagination = paginations[uniqueKey];

    switch (uniqueKey) {
      case "asset": {
        if (assets.totalPageCount === pagination?.page) return;
        let updatedPage = null;
        if (pagination?.limit * pagination?.page === assets.data?.length) {
          updatedPage = pagination?.page + 1
        } else {
          updatedPage = pagination?.page
        }
       
        handleGetAssets({ page: updatedPage }).then(assetDataResponse => {
          
          const updatedAssets = handleRemoveDuplicatesFromAnArray({ data: [...assetDataResponse?.data, ...assets.data] })
          
          setServerResponse(prev => (
            {
              ...prev,
              ["assets"]: { ...assetDataResponse, data: updatedAssets }
            }));
        });
        handleSetPage({ page: updatedPage, key: uniqueKey });
      }
    }
  };

  // USE EFFECTS

  useEffect(()=>{
       // GET USER
     doGetApiCall({
      url:AppUrl?.getAllUsers,params:{
        selectFields:"name"
      }
    }).then((res)=>{
        const allUsers = res?.data?.result?.data || [];
        const loggedInUserDetails = handleLoggedInUser();

        const filteredUsers = allUsers.filter(user => user?.name !== loggedInUserDetails?.name);

        setApproversDropdownData(allUsers); // if you want all users in approver dropdown
        setemailNotificationRecipientsDropdownData(filteredUsers); // exclude logged-in user
        setcriticalNotificationRecipientsDropdownData(filteredUsers); // exclude logged-in user
  })

},[])

    useEffect(() => {

      const selectedEmailUsers = formData?.emailNotificationRecipients || [];
      const selectedCriticalUsers = formData?.criticalNotificationRecipients || [];

      // Exclude selected critical users from Email Notification dropdown
      const filteredEmailRecipients = emailNotificationRecipientsDropdowndata.filter(
        user => !selectedCriticalUsers.some(selected => (selected._id || selected.id) === user.id)
      );

      // Exclude selected email users from Critical Notification dropdown
      const filteredCriticalRecipients = criticalNotificationRecipientsDropdowndata.filter(
        user => !selectedEmailUsers.some(selected => (selected._id || selected.id) === user.id)
      );

      setemailNotificationRecipientsDropdowndataFiltered(filteredEmailRecipients);
      setcriticalNotificationRecipientsDropdowndataFiltered(filteredCriticalRecipients);
  }, [
    formData.emailNotificationRecipients,
    formData.criticalNotificationRecipients,
    emailNotificationRecipientsDropdowndata,
    criticalNotificationRecipientsDropdowndata
  ]);

  
  useEffect(() => {
    if (mode === "edit") {
      handleGetSingleLog(
        {
          responseSetterMethod: setServerResponse,
          logId: LOCATION?.state?.logId,
          lcStateSetterMethod: setLcValues,
        }
      )
    }
    
    // GET TIME PERIODS
    doGetApiCall({ url: AppUrl?.getTimePeriods }).then(timePeriodsResponse => {
     
      setFrequencyDropdownData(timePeriodsResponse?.data?.result?.map((item, index) => ({ name: modifyString(item, "capitalize"), id: `tp_${index + 1}` })))
    })

    // GET ASSETS 
    handleGetAssets({ page: 1, limit: 15 }).then(assetData => {
      setServerResponse(prev => (
        {
          ...prev,
          ["assets"]: assetData
        }));
    });

    // Department Dropdown Data
    doGetApiCall({ url: AppUrl.getDepartments, params: { businessUnit: handleLoggedInUser()?.businessUnit?.id, selectFields: "name" } }).then((res) => {
      setDepartmentDropdownData(res?.data?.result?.data)
    });

    doGetApiCall({
      url: AppUrl.getAllUsers, params: {
        populateFields: "designation,userType,reportsTo",
        selectFields: "designation,userType,reportsTo,name",
      }
    }).then(res => {
      const manipulatedUsersData = (res?.data?.result?.data || []).map((item) => {
        return { ...item, designation: item?.designation?.name }
      });
      setLcValues({ ...lcValues, approverUsers: manipulatedUsersData });
    });

  }, [mode]);

  useEffect(() => {

    if (mode === "edit") {
      if (Object.keys(serverResponse?.generalDetails).length) {
        setLcValues(prev => {// Here we are segregating the ISO 8601 date and time format into year, month, day, time, hour, minute, second
          const lcStartDate = getDayMonthYear(generalDetails?.startDateAndTime)
          const lcEndDate = getDayMonthYear(generalDetails?.endDateAndTime)
          return { ...prev, ["formatedStartDateServerResponse"]: lcStartDate, ['formatedEndDateServerResponse']: lcEndDate, isRecurrence: generalDetails?.isRecurrence }
        })
      }
      
      let details = serverResponse?.generalDetails

      setFormData(prev => ({
        ...prev,
        emailNotificationRecipients: details.emailNotificationRecipients || [],
        criticalNotificationRecipients: details.criticalNotificationRecipients || [],
      }));

    }
  }, [serverResponse?.generalDetails])
  

  useEffect(() => {
    formData.departments && handleGetUsers();
  }, [approver]);


  useEffect(() => {
    if (searchAndFilters?.assetSearchAndFilterDataRequest?.input === "") {
      setLcValues(prev => ({
        ...prev,
        assetSearchedData: []
      }));
    } else if (searchAndFilters?.assetSearchAndFilterDataRequest?.input) {
      handleGetAssets({ name: searchAndFilters?.assetSearchAndFilterDataRequest?.input })
        .then((assetData) => {
     
          setLcValues(prev => ({
            ...prev,
            assetSearchedData: assetData?.data ?? [],
          }));
        });
    }
  }, [searchAndFilters?.assetSearchAndFilterDataRequest]);
  

  const handleDynamicSearch = (response, type) => {
    
    const searchInput = response?.input?.toLowerCase() || "";
    
    let filteredUsers = [];
    
    if (type === "assignees") {
      // Filter assignees using the usersDropdownData
      filteredUsers = usersDropdownData.filter(user =>
        user.name?.toLowerCase().includes(searchInput)
      );
    } else if (type === "approvers") {
      // Filter approvers using the approversDropdownData
      filteredUsers = approversDropdowndata.filter(user =>
        user.name?.toLowerCase().includes(searchInput)
      );
    } else if (type === "emailNotificationRecipients") {
      // Filter emailNotificationRecipients using the emailNotificationRecipientsDropdownData
      filteredUsers = emailNotificationRecipientsDropdowndataFiltered.filter(user =>
        user.name?.toLowerCase().includes(searchInput)
      );
    }else if (type === "criticalNotificationRecipients") {
      // Filter emailNotificationRecipients using the emailNotificationRecipientsDropdownData
      filteredUsers = criticalNotificationRecipientsDropdowndataFiltered.filter(user =>
        user.name?.toLowerCase().includes(searchInput)
      );
    }
    
    // Update the lcValues state based on the type of dropdown
    setLcValues((prev) => {
      if (type === "assignees") {
        return {
          ...prev,
          assignees: searchInput === "" ? usersDropdownData : filteredUsers
        };
      } else if (type === "approvers") {
        return {
          ...prev,
          approvers: searchInput === "" ? approversDropdowndata : filteredUsers
        };
      } else if (type === "emailNotificationRecipients") {
        return {
          ...prev,
          emailNotificationRecipients: searchInput === "" ? emailNotificationRecipientsDropdowndataFiltered : filteredUsers
        };
      }
      else if (type === "criticalNotificationRecipients") {
        return {
          ...prev,
          criticalNotificationRecipients: searchInput === "" ? criticalNotificationRecipientsDropdowndataFiltered : filteredUsers
        };
      }
      return prev;
    });
  };
  
  // CHECKING THE UNIQUENESS OF THE FIELDS FROM THE SERVER

  const handleCheckUniquenessOfFields = ({ fieldName, input = "", message }) => {

    const lcInput = input?.trim();

    if (!lcInput) return;
    if (lcInput === generalDetails?.name || lcInput === generalDetails?.documentNumber) {
      setIsUnique(true);
      return;
    };

    const fieldsControllers = handleGetUpdatedPrimaryObject()?.[fieldName];
    axiosInstance().post(AppUrl?.logFieldUniqueness, { [fieldName]: lcInput }, {
      headers: {
        Authorization: `Bearer ${getToken()}`
      }
    }).then(uniquenessCheckerResponse => {
      fieldsControllers?.errorActivatorMethod(false);
      setIsUnique(true);
    }).catch(err => {
      setIsUnique(false);
      handleShowErrorAndWarning({ type: "error", dispatch, message: err?.response?.data?.message, showTime: 5000 })
      fieldsControllers?.errorSetterMethod(message);
      fieldsControllers?.errorActivatorMethod(true);
    });
  };

  useEffect(() => {
    handleCheckUniquenessOfFields({ fieldName: "name", input: checklistNameUniqueness, message: "Log name already exist." });
  }, [checklistNameUniqueness]);

  useEffect(() => {
    handleCheckUniquenessOfFields({ fieldName: "documentNumber", input: checklistDocumentNumberUniqueness, message: "Document number already exist." });
  }, [checklistDocumentNumberUniqueness]);

 if (checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_LOGS, action: CLONOS_GLOBAL_ACTION_CREATE })){
      return (
    <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem", overflowY: "auto" }}>

      <div
        className={Styles.main_container}
        aria-label="Parent container for general details">
        <header className={Styles.checklist_gen_details_header}>
          General Details
        </header>
        <section
          className={Styles.split}>
          <div>
            <ClonosInput
              tabIndex={1}
              label="Name"
              isLabel={true}
              placeholder="Name"
              isMandatory={true}
              type="text"
              limit='50'
              isDebounce={true}
              uniqueKey="name"
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              defaultValue={state?.mode === "edit" && generalDetails?.name}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <ClonosTextarea
              tabIndex={2}
              label="Description"
              isLabel={true}
              placeholder="Description"
              isMandatory={false}
              type="text"
              limit="1000"
              uniqueKey="description"
              defaultValue={state?.mode === "edit" && generalDetails?.description}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <ClonosInput
              tabIndex={3}
              label="Document Number"
              isLabel={true}
              placeholder="Document Number"
              isMandatory={false}
              type="text"
              uniqueKey="documentNumber"
              defaultValue={state?.mode === "edit" && generalDetails?.documentNumber}
              isSpecialCharacterAllow={true}
              onlyAllowTheseSpecialCharacters={["/"]}
              limit="20"
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <DynamicDropdown
              tabIndex={4}
              label="Asset"
              title={"Asset"}
              uniqueKey={"asset"}
              heading={"Select from Asset Library"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={false}
              isDynamicLoad={assets.totalPageCount === paginations["asset"]?.page ? false : true}
              data={lcValues?.assetSearchedData?.length ? lcValues?.assetSearchedData : assets?.data}
              isActivator={true}
              isMandatory={true}
              defaultValue={mode === "edit" && generalDetails?.asset? [{ name: generalDetails?.asset }] : null}
              disabled={(mode === "edit" && generalDetails?.logStatus !== "draft") ? true : false}
              handleDynamicSearch={(props) => {
              
                // handleGetAssets({ name: props?.input });
                setSearchAndFilters({ ...searchAndFilters, ["assetSearchAndFilterDataRequest"]: { input: props?.input } });
              }}
              handleMoreData={(props) => handleLoadMoreData({ uniqueKey: props?.uniqueKey })}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />

            <DynamicDropdown
              tabIndex={5}
              title={"Departments"}
              label="Departments"
              uniqueKey={"departments"}
              heading={"Select from Departments"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={true}
              isDynamicLoad={false}
              data={departmentDropdownData}
              // data={departmentDropdownData}
              isActivator={true}
              isMandatory={true}
              // defaultValue={mode === "edit" && generalDetails?.departments?.length ? [{ name: generalDetails?.departments?.[0] }] : null}
               defaultValue={mode === "edit" && generalDetails?.departmentObject?.length ? generalDetails?.departmentObject.map(dept => ({id:dept?._id , name: dept?.name })) : null}
              // handleMoreData={() => { }}
              handleGetValues={(props) => {
                handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues });
                const departments = props?.updatedValue?.map(item => item.id).join(",");
                const fieldsControllers = handleGetUpdatedPrimaryObject();
                fieldsControllers["assignees"]?.resetMethod();
                fieldsControllers["teams"]?.resetMethod();
                handleGetTeams(departments);
                handleGetUsers({ departments });
              }}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              stopOverlayCloser={true}
            />

            <DynamicDropdown
              tabIndex={6}
              handleGetErrorMethods={() => { }}
              title={"Teams"}
              uniqueKey={"teams"}
              label="Teams"
              heading={"Select from Team Library"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={false}
              isDynamicLoad={false}
              data={teamDropdownData}
              isActivator={true}
              disabled={formData?.departments ? false : true}
              defaultValue={mode === "edit" && generalDetails?.teams?.length ? [{ name: generalDetails?.teams?.[0]}] : null}
              // handleMoreData={() => { }}
              handleGetValues={(props) => {
              
                handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues });
                const teams = props?.updatedValue?.map(item => item.id).join(",");
                handleGetUsers({ teams });
              }}
              // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />
            
            <DynamicDropdown
              tabIndex={7}
              uniqueKey={"assignees"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={true}
              label="Assignees"
              isActivator={true}
              isMandatory={true}
              isDynamicLoad={false}
              data={lcValues.assignees.length ? lcValues.assignees : usersDropdownData}
              // handleMoreData={handleMoreData}
              disabled={formData?.departments ? false : true}
              populatedFields={["designation"]}
              heading={"Select from Users Library"}
              handleDynamicSearch={(response) => handleDynamicSearch(response, "assignees")}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              defaultValue={mode === "edit" && generalDetails?.assigneeObject?.length ? generalDetails?.assigneeObject.map(user => ({id:user?._id , name: user?.name })) : null}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
               stopOverlayCloser={true}
            />
            <DynamicDropdown
              tabIndex={8}
              uniqueKey={"approvers"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={true}
              label="Approvers"
              isActivator={true}
              // isMandatory={false}
              isDynamicLoad={false}
              data={lcValues.approvers.length ? lcValues.approvers : approversDropdowndata}
              // data={approversDropdowndata}
              // handleMoreData={handleMoreData}
              heading={"Select from Users Library"}
              handleDynamicSearch={(response) => handleDynamicSearch(response, "approvers")}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              defaultValue={mode === "edit" && generalDetails?.approvers?.length ? generalDetails?.approvers.map(user => ({ id:user?._id , name: user?.name })) : null}
              handleGetValues={(props) =>{handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
              // handleGetapprovesUsers();
            }}
             stopOverlayCloser={true}
            />
            <DynamicDropdown
              tabIndex={9}
              uniqueKey={"emailNotificationRecipients"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={true}
              label="Email Notification Recipients"
              isActivator={true}
              // isMandatory={true}
              isDynamicLoad={false}
              data={lcValues.emailNotificationRecipients.length ? lcValues.emailNotificationRecipients : formData.criticalNotificationRecipients?.length ? emailNotificationRecipientsDropdowndataFiltered : emailNotificationRecipientsDropdowndata}
              // data={emailNotificationRecipientsDropdowndata}
              // handleMoreData={handleMoreData}
              heading={"Select from Users Library"}
              handleDynamicSearch={(response) => handleDynamicSearch(response, "emailNotificationRecipients")}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              defaultValue={mode === "edit" && generalDetails?.emailNotificationRecipients?.length ? generalDetails?.emailNotificationRecipients.map(user => ({id:user?._id , name: user?.name })) : null}
              handleGetValues={(props) =>{handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
            }}
            stopOverlayCloser={true}
            />

            <DynamicDropdown
              tabIndex={10}
              uniqueKey={"criticalNotificationRecipients"}
              placeholder={"Search"}
              isSearchable={true}
              isCheckbox={true}
              label="Critical Notification Recipients"
              isActivator={true}
              // isMandatory={true}
              isDynamicLoad={false}
              data={lcValues.criticalNotificationRecipients.length ? lcValues.criticalNotificationRecipients :formData.emailNotificationRecipients?.length ? criticalNotificationRecipientsDropdowndataFiltered : criticalNotificationRecipientsDropdowndata}
              heading={"Select from Users Library"}
              handleDynamicSearch={(response) => handleDynamicSearch(response, "criticalNotificationRecipients")}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              defaultValue={mode === "edit" && generalDetails?.criticalNotificationRecipients?.length ? generalDetails?.criticalNotificationRecipients.map(user => ({id:user?._id , name: user?.name })) : null}
              handleGetValues={(props) =>{handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
            }}
             stopOverlayCloser={true}
            />

            <div
              area-aria-label="to get value for end date"
              className={`${Styles.split_common}`}
            >
              <ClonosInput
                tabIndex={11}
                label="Start Date"
                isLabel={true}
                isMinimum={true}
                placeholder="Start Date"
                isMandatory={true}
                type="datetime-local"
                disabled={(mode === "edit" && generalDetails?.logStatus !== "draft") ? true : false}
                min={true}
                uniqueKey="startDate"
                defaultValue={mode === "edit" && (() => {
                  const parsedString = handleClientDateInConfiguredTimeZone({ dateString: generalDetails?.startDateAndTime, parseType: "object" });
                  return `${parsedString?.year}-${parsedString?.month}-${parsedString?.day}T${parsedString?.hour}:${parsedString?.minute}`
                })()}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                handleGetValues={(props) => {
                  const localProps = { ...props, updatedValue: props?.updatedValue };
                  handleGetValues({ ...localProps, handlePrimaryObjectModifier, setFormData, formData, setLcValues });
                }}
              />

              <ClonosInput
                tabIndex={12}
                label="End Date"
                isLabel={true}
                placeholder="End Date"
                isMandatory={true}
                isMinimum={true}
                type="datetime-local"
                uniqueKey="endDate"
                defaultValue={mode === "edit" && (() => {
                  const parsedString = handleClientDateInConfiguredTimeZone({ dateString: generalDetails?.endDateAndTime, parseType: "object" });
                 
                  return `${parsedString?.year}-${parsedString?.month}-${parsedString?.day}T${parsedString?.hour}:${parsedString?.minute}`
                })()}
                // disabled={(mode === "edit" && generalDetails?.logStatus !== "draft") ? true : formData?.startDate?.length > 0 ? false : true}
                min={formData?.startDate}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                handleGetValues={(props) => {
                  const localProps = { ...props, updatedValue: props?.updatedValue };
                  handleGetValues({ ...localProps, handlePrimaryObjectModifier, setFormData, formData, setLcValues });
                }}
              />
            </div>

            <ClonosRadioAndCheckbox
              name="generationMode"
              uniqueKey="isRecurrence"
              isLabel={true}
              label="Recurrence"
              type="checkbox"
              // isChecked={generalDetails?.isRecurrence}
              isChecked={formData?.isRecurrence}
              disabled={(mode === "edit" && generalDetails?.logStatus !== "draft") ? true : false}
              handleGetValues={(props) => {
              
                // debugger
                if (!props?.updatedValue) {
                  handleRemoveField(["timePeriod", "recurOn", "inEach"]);
                }
                handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
              }}
            />

            {(formData?.isRecurrence || formData?.isStaticGeneration) && <div
              className={Styles.recurrence_container}
            >
              <div
                aria-label="Frequency selection container"
                className={`${Styles.split_common}`}
              >
                <ClonosInput
                  tabIndex={13}
                  label="Every"
                  isLabel={true}
                  placeholder="1"
                  isMandatory={true}
                  type="number"
                  limit='2'
                  uniqueKey="inEach"
                  // defaultValue={state?.mode === "edit" && generalDetails?.name}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={(props) => {

                    handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues });

                  }}
                />
                <ClonosSelect
                  tabIndex={14}
                  type="select"
                  label="Frequency"
                  isMandatory={true}
                  isLabel={true}
                  uniqueKey="timePeriod"
                  placeholder="Select"
                  options={frequencyDropdownData?.map((type) => ({
                    label: `${type?.name}${Number(formData?.inEach) > 1 ? "(s)" : ""}`,
                    value: type.name,
                    isNeeded: true,
                    isChecked: false
                  }))}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                />

              </div>
              {
                formData?.isRecurrence && <RecurrenceCustomization
                  formData={formData}
                  timePeriod={formData?.timePeriod}
                  type="basedOnTimePeriodRecurrence"
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                />
              }

              <ClonosRadioAndCheckbox
                uniqueKey="isUserSpecificCustomization"
                isLabel={true}
                label="User Specific Customization"
                type="checkbox"
                isMandatory={formData?.assignees?.length > 1 ? true : false}
                handleGetValues={(props) => {
                  if (!props?.updatedValue) {
                    const keysNeedToDeleteFromPrimaryObject = (formData?.assignees || []).map(item => item?.id + "Shift_0")
                    handleRemoveField(keysNeedToDeleteFromPrimaryObject);
                  };
                  handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues });
                }}
                disabled={
                  (handleIsReadyForUserSpecificCustomization({ startDate: formData?.startDate, endDate: formData?.endDate, assigneesLength: formData?.assignees?.length }) && formData?.isRecurrence && formData?.assignees?.length && formData?.timePeriod && ((
                    formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_HOUR ||
                    formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_DAY ||
                    formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_WEEK ||
                    formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_MONTH ||
                    formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_YEAR) ?
                    (
                      formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.recurOn ||
                      formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.occursOnSpecificWeekDay ||
                      formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.specificDays ||
                      formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.weekDays ||
                      formData?.timePeriod === CLONOS_GLOBAL_TIME_PERIOD_YEAR
                    ) ? true :
                      false : false)) ? false : true}
              />

              {/* {
                formData?.isUserSpecificCustomization && <div
                  aria-label="user specific customization container"
                  className={Styles.user_specific_customization_container}
                >
                  {
                    (formData?.assignees || []).map((assignee) => {
                      return <UserSpecificCustomization
                        formData={formData}
                        assignee={assignee}
                        timePeriod={formData?.timePeriod}
                        handleGetValues={(props) => {
                          console.log('formData:', formData)
                          handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })
                        }}
                        needToDisable={daysStaticData?.filter((item) => {
                          const value = formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.recurOn?.value;
                          if (value === "onlyOnWeekdays" && [CLONOS_GLOBAL_SPECIFIC_DAY_SATURDAY, CLONOS_GLOBAL_SPECIFIC_DAY_SUNDAY].indexOf(item.uniqueKey) > -1) {
                            return item.uniqueKey;
                          }
                          else if (value === "custom" && formData?.basedOnTimePeriodRecurrence) {
                            const selectedDays = formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.occursOnSpecificWeekDay?.map(lc => lc.uniqueKey)
                            if (selectedDays?.indexOf(item.uniqueKey) < 0) {
                              return item.uniqueKey;
                            }
                          }

                        })?.map(lcItem => lcItem?.uniqueKey) || []}
                        needToDisableSpecificDays={formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.weekDays?.map(item => item.specificDay) || []}
                        needToDisableSpecificNumbering={formData?.basedOnTimePeriodRecurrence?.[formData?.timePeriod]?.weekDays?.map(item => item.whichWeek) || []}
                        handleUniqueRecurrenceCombinations={setUniqueRecurrenceCombinations}
                      />
                    })
                  }
                </div>
              } */}
            </div>
            }
          </div>
          <div>
            <ClonosToggleButton
              label="Schedule Report"
              labelPosition="right"
              type="toggle"
              uniqueKey="isScheduleReport"
              disabled={mode === "edit" ? true : false}
              // disabled={true}
              handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
            />
            {
              formData?.isScheduleReport && <>
                <ClonosSpecifyFromAndTo
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  isMandatory={true}
                  heading="Schedule Time"
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                  type="time" uniqueKey="scheduleTime"
                />
                <DynamicDropdown
                  isActivator={true}
                  label="Approver"
                  isMandatory={true}
                  isSearchable={true}
                  heading="Select from User Library"
                  uniqueKey="approver"
                  data={lcValues?.approverUsers}
                  populatedFields={["designation"]}
                  isDynamicLoad={false}
                  // handleDynamicSearch={(response) => {
                  //   setSearchAndFilters({ ...searchAndFilters, [response?.uniqueKey]: response?.input })
                  // }}
                  handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                />
                <div className={Styles.recurrence_frequence_selector_container}>
                  <ClonosInput
                    tabIndex={15}
                    label="Every"
                    isLabel={true}
                    placeholder="1"
                    isMandatory={false}
                    type="number"
                    limit='2'
                    uniqueKey="scheduleReportInEach"
                    // defaultValue={state?.mode === "edit" && generalDetails?.name}
                    handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  />
                  <ClonosSelect
                    tabIndex={16}
                    type="select"
                    label="Frequency"
                    isMandatory={true}
                    isLabel={false}
                    uniqueKey="scheduleReportTimePeriod"
                    placeholder="Select"
                    options={frequencyDropdownData?.map((type) => ({
                      label: `${type?.name}${Number(formData?.inEach) > 1 ? "(s)" : ""}`,
                      value: type.name,
                      isNeeded: (type?.name === "Hour" || type?.name === "Year") ? false : true
                    }))}
                    handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  />
                </div>
                {
                  formData?.scheduleReportTimePeriod && <RecurrenceCustomization
                    timePeriod={formData?.scheduleReportTimePeriod}
                    formData={formData}
                    handleGetValues={(props) => handleGetValues({ ...props, handlePrimaryObjectModifier, setFormData, formData, setLcValues })}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    type="basedOnScheduleReportTimePeriodRecurrence"
                  />
                }
              </>
            }
          </div>
        </section >
        <footer className={Styles.checklist_gen_details_footer}>
          <div>
            {
              mode !== "edit" && <>
                <ClonosButton
                  isDisabled={formData?.name ? false : true}
                  loading={lcValues?.savingLogsGeneralDetailsAsDraftLoading}
                  onClick={() => {
                    setSaveAsDraftLogAlert(true)
                  }}
                  style={{
                    color: "#06337E",
                    border: "1px solid #06337E",
                    fontSize: "16px",
                    padding: "0.5rem 1rem",
                  }}
                >Save as Draft
                </ClonosButton>

                <ClonosButton
                  loading={lcValues?.checklistGeneralDetailsLoading}
                  isDisabled={!isUnique}
                  variant="filled"
                  onClick={() => {
                    if (!formData?.isScheduleReport) handleRemoveField(["approver", "scheduleReportInEach", "scheduleReportTimePeriod", "scheduleTime", "isOccurOnTheseWeekDays"])
                    if (!handleSubmit()) return;
                    handleSaveChecklistGeneralDetails({ payload: formData, dispatch, Navigate, isDraft: false, responseSetterMethod: setLcValues });
                  }}
                  style={{ fontSize: "16px", padding: "0.5rem 1rem" }}
                >
                  Continue
                </ClonosButton>
              </>
            }
            {
              mode === "edit" && <>
                <ClonosButton
                  onClick={() => {
                    handleEditChecklistGeneralDetails({
                      dispatch,
                      payload: formData,
                      logId: generalDetails?._id,
                      lcStateSetterMethod: setLcValues,
                      logStatus: generalDetails?.logStatus,
                    })
                    Navigate(-1);
                  }}
                  loading={lcValues?.savingLogsGeneralDetailsAsDraftLoading}
                >Save and Exit</ClonosButton>

                <ClonosButton
                  variant="filled"
                  loading={lcValues?.editGeneralDetailsLoading}
                  isDisabled={(!isUnique && (checklistNameUniqueness || checklistDocumentNumberUniqueness)) ? true : false}
                  onClick={() => {
                    if (!handleSubmit()) return;
                    if (generalDetails?.logStatus === "draft") {
                      handleEditChecklistGeneralDetails({
                        dispatch,
                        payload: formData,
                        logId: generalDetails?._id,
                        lcStateSetterMethod: setLcValues,
                        logStatus: generalDetails?.logStatus,
                        Navigate,
                      });
                    } else {
                      handleEditChecklistGeneralDetails({ dispatch, payload: formData, logId: generalDetails?._id, lcStateSetterMethod: setLcValues })
                      handleGoToEditTemplate()
                    }
                  }}
                >Continue</ClonosButton>
              </>
            }
          </div>
        </footer >
      </div >

      <ClonosConfirmationBox
        isOpen={cancelOrGoBackAlert}
        confirmingMethod={() => {
          Navigate(`/view-checklist/${generalDetails?.name}`, { state: { entryId: state?.entryId, checklistId: state?.checklistId } });
          setCancelOrGoBackAlert(false);
        }}
        closeModalMethod={setCancelOrGoBackAlert}
        headerTitle="Edit Checklist"
        message="Are you sure, You don't want to edit this checklist general details?"
      />

      <ClonosConfirmationBox
        isOpen={saveAsDraftLogAlert}
        confirmingMethod={() => {
          handleSaveChecklistGeneralDetails({ payload: formData, dispatch, Navigate, isDraft: true, responseSetterMethod: setLcValues });
          setSaveAsDraftLogAlert(false)
        }}
        closeModalMethod={() => setSaveAsDraftLogAlert(false)}
        headerTitle="Draft Checklist"
        message="Are you sure, You want to draft this log?"
      />
    </Card>
  );
  }

 return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
};


export default React.memo(CreateChecklistGeneralDetails)