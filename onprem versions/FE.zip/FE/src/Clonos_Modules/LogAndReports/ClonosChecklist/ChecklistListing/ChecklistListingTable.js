// import React, { useState } from 'react'
// import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
// import { checkUserHasPermission, getFormatedDate, handleClientDateInConfiguredTimeZone, handleShowErrorAndWarning, modifyString } from '../../../../utils/clonosCommon'
// import { useNavigate } from 'react-router-dom'
// import { handleDeleteChecklist } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods'
// import { useDispatch } from 'react-redux'
// import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
// import { statusStaticData, statusStyleStaticData, timePeriodsStaticData } from "../../../../Constants/StaticData"
// import { Tooltip } from '@mui/material'
// import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook'
// import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE } from '../../../../Constants/Constant'
// import { handleDeleteLog } from '../../../../utils/LogAndReportsMethods/LogMethods'
// import useToggler from '../../../../CustomHooks/TogglerHook'

// const ChecklistListingTable = ({ tableData,handleFilterModelChange, lcDataSetterMethod, totalCount, pageLimit, setPagination, isLoading, setRefreshApi, setRefreshStatusCount }) => {

//     const [selectedRows, setSelectedRows] = useState([]);
//     const navigate = useNavigate();
//     const dispatch = useDispatch();
//     const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
//     const moduleName = useModuleNameProvider()
//      const [lcValues, setLcValues] = useState({
//             deleteLoading: false,
//         }); 
  
//     const columns = [
//         {
//             field: "index",
//             headerName: "SI.NO",
//             // flex: 1,
//             width: 60,
//             headerClassName: "datadrid_common_header",
//             filterPanelClassName: "ast_column_filterPanel",
//         },
//         {
//             field: "logNumber",
//             headerName: "LOG NUMBER",
//             width: 100,
//             // flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             filterPanelClassName: "ast_column_filterPanel",
//             valueGetter: (params) => params?.row?.logNumber || "-"
//         },
//         {
//             field: "name",
//             headerName: "LOG NAME",
//             // width: 200,
//             width: "300",
//             // flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             renderCell: (params) => {
//                 return <div
//                     style={{ display: "flex", gap: "0.30rem", alignItems: "center" }}
//                 > <p onClick={() => {
//                     if (params?.row?.logStatus === "draft") {
//                         navigate(`/view-log/${params?.row?.name}`,
//                             { state: { logId: params?.row?._id, name: params?.row?.name, logStatus: params?.row?.logStatus } }
//                         );
//                     } else {
//                         handleGotoRecurredLosListing({ _id: params?.row?._id, name: params?.row?.name });
//                     }
//                 }} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>
//                     {params?.row?.logStatus === "draft" && <span
//                         style={{ ...statusStyleStaticData[params?.row?.logStatus], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
//                         {statusStaticData[params?.row?.logStatus]}
//                     </span>}
//                 </div>
//             }
//         },
//         {
//             field: "documentNumber",
//             headerName: "DOCUMENT NUMBER",
//             width: "200",
//             // flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             valueGetter: (params) => params?.row?.documentNumber || "-"
//         },
//         // {
//         //     field: "isRecurrence",
//         //     headerName: "RECURRING",
//         //     // width:"200",
//         //     width: 100,
//         //     // flex: 1,
//         //     disableColumnFilter: true,
//         //     headerClassName: "datadrid_common_header",
//         //     valueGetter: (params) => params?.row?.isRecurrence ? "Yes" : "No"
//         // },
//         {
//             field: "timePeriod",
//             headerName: "FREQUENCY",
//             // width:"200",
//             width: 100,
//             // flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             valueGetter: (params) => params?.row?.timePeriod ? timePeriodsStaticData[modifyString(params?.row?.timePeriod, "capitalize")] : "No"
//         },
//         {
//             field: "templateStatuses",
//             headerName: "STATUS",
//             width: 400,
//             // flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             headerAlign: "center",
//             renderCell: (params) => {
//                 const data = params?.row?.templateStatuses;
            
//                 if (data?.length === 0) {
//                     return <div style={{ width: "100%", textAlign: "center" }}>
//                         -
//                     </div>
//                 }
//                 let priorityList = [0, 0, 0, 0, 0, 0];
//                 (data || []).forEach((item) => {
//                     if (item.status === "pendingForApproval") {
//                         priorityList[0] = item;
//                     }
//                     else if (item.status === "overdue") {
//                         priorityList[1] = item;
//                     }
//                     else if (item.status === "scheduled") {
//                         priorityList[2] = item;
//                     }
//                     else if (item.status === "revised") {
//                         priorityList[3] = item;
//                     }
//                     else if (item.status === "completed") {
//                         priorityList[4] = item;
//                     }
//                     else if (item.status === "inProgress") {
//                         priorityList[5] = item;
//                     };
//                 })
//                 priorityList = priorityList.filter(item => item !== 0);
             
//                 return <div style={{ gap: "0.75rem", display: "flex", justifyContent: "center", width: "100%" }}>
//                     {
//                         (priorityList || []).map((item, index) => {
//                             if (index > 1) return ""
//                             return <span
//                                 style={{ ...statusStyleStaticData[item.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
//                                 {`${statusStaticData[item.status]} ${item.count > 1 ? `(${item.count})` : ""}`}
//                             </span>
//                         })
//                     }
//                 </div>
//             }
//         },
//         {
//             field: "asset",
//             headerName: "ASSET",
//             width: 200,
//             // flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             valueGetter: (params) => params?.row?.asset || "-"
//         },
//         {
//             field: "departments",
//             headerName: "DEPARTMENTS",
//             width: 200,
//             // flex: 1,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             renderCell: (params) => {
//                 const data = params?.row?.departments;
//                 return data?.length === 0 ? <span>Not Mentioned</span> :
//                     <div style={{ gap: "0.50rem", display: "flex", }}>
//                         {data?.length === 1 && <span>{data[0]}</span>}
//                         {data?.length === 2 && <>
//                             <span>{data[0]},</span>
//                             <span>{data[1]}</span>
//                         </>}

//                         {data?.length > 2 && <Tooltip title={data.slice(2).join(", ")}>
//                             +{data.slice(2).length}more
//                         </Tooltip>}
//                     </div>
//             }
//         },
//         // {
//         //     field: "assignedUsers",
//         //     headerName: "ASSIGNED USERS",
//         //     width: 220,
//         //     disableColumnFilter: true,
//         //     headerClassName: "datadrid_common_header",
//         //     renderCell: (params) => {
//         //         const data = params?.row?.assignees;
//         //         return <div style={{ gap: "0.50rem", display: "flex", }}>
//         //             {data?.length === 0 && <span>-</span>}
//         //             {data?.length === 2 ? <>
//         //                 <span>{data[0]},</span>
//         //                 <span>{data[1]},</span>
//         //             </> : <>
//         //                 <span>{data[0]}</span>
//         //             </>}
//         //             {data?.length > 1 && <span>{data[0]},</span>}
//         //             {data?.length > 1 && <span>{data[1]},</span>}
//         //             {data?.length > 2 && <Tooltip title={data.slice(2).join(", ")}>
//         //                 +{data.slice(2).length}more
//         //             </Tooltip>}
//         //         </div>
//         //     }
//         // },
//         // {
//         //     field: "approvers",
//         //     headerName: "Approvers",
//         //     width: 220,
//         //     disableColumnFilter: true,
//         //     headerClassName: "datadrid_common_header",
//         //     renderCell:(params)=>{
//         //          console.log("approvers", params.row)

//         //     }
//         // },
//         // {
//         //     field: "receipts",
//         //     headerName: "Receipts",
//         //     width: 220,
//         //     disableColumnFilter: true,
//         //     headerClassName: "datadrid_common_header",
//         //     renderCell:(params)=>{
//         //          console.log("receipts", params.row)
//         //     }
//         // },
//         {
//             field: "createdAt",
//             headerName: "CREATED ON",
//             width: 100,
//             disableColumnFilter: true,
//             headerClassName: "datadrid_common_header",
//             valueGetter: (params) => params?.row?.createdAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "object" })?.clientView : "-"
//         },
//         // {
//         //     field: "updatedAt",
//         //     headerName: "LAST UPDATED ON",
//         //     width: 150,
//         //     disableColumnFilter: true,
//         //     headerClassName: "datadrid_common_header",
//         //     valueGetter: (params) => params?.row?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.updatedAt, parseType: "object" })?.clientView : "-"
//         // }
//     ]

//     /**
//      * "handleGetSelectedRowsMethod" help to get all the selected rows from the ClonosDataGrid Component.
//      * @param {Object} props  
//      * @property {Array} props.selectedRows This will contain the the selected rows IDs
//      */
//     const handleGetSelectedRowsMethod = (props) => {
//         setSelectedRows(props.selectedRows)
//     }

//     /**
//      * "handleGoToRecurredChecklistListing" function help to redirect user from checklist to checklist view
//      * @param {Object} props Contain the ID of of the checklist that we awant to view. 
//      */
//     const handleGotoRecurredLosListing = (props) => {
   
//         navigate(`/log-entries`, { state: { _id: props?._id, name: props?.name } })
//     }

//     /**
//      * "handleGoToEditChecklist" function helps to redirect to edit checklist page.
//      */
//     const handleGoToEditChecklist = () => {
//         navigate("/edit-log-generaldetails", { state: { "mode": "edit", "logId": selectedRows[0] } });

//     }




//     return (
//         <>
//             <div style={{ padding: "2rem 2rem", height: "90%" }}>
//                 <ClonosDataGrid
//                     rows={tableData}
//                     columns={columns}
//                     rowCount={tableData?.length}
//                     pageLimit={pageLimit}
//                     totalCount={totalCount}
//                     uniqueIdField={"_id"}
//                     isDeleteMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowConfirmationDailog(true) : false}
//                     handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
//                     isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => handleGoToEditChecklist() : false}
//                     onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
//                     checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
//                     loading={isLoading}
//                     // ── NEW: wire up server-side filter ──
//                     filterMode="server"
//                     handleFilterModelChange={handleFilterModelChange}
//                     toolbar={true}   // shows the GridToolbar so users can open the filter panel
//                 />
//             </div>
//             <ClonosConfirmationBox
//                 isOpen={showConfirmationDailog}
//                loading={lcValues?.deleteLoading}
//                confirmingMethod={async () => {
//                     await handleDeleteLog({
//                     payload: selectedRows,
//                     setIsLoading: () =>
//                         setLcValues(prev => ({...prev,deleteLoading:!prev.deleteLoading})),
//                         next: () => {

//                             setRefreshApi()
//                             setShowConfirmationDailog(false)
//                             handleShowErrorAndWarning({
//                             dispatch,
//                             message: "Log deleted successfully!",
//                             type: "success",
//                             showTime: "5000"
//                             });
                            
//                         }
//                     });
//                 }}
//                 closeModalMethod={()=>setShowConfirmationDailog(false)}
//                  headerTitle="Delete Log"
//                 message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this Log" : "these Logs"}?`}
//             />



//  {/* <ClonosConfirmationBox
//                 isOpen={showDeleteModal}
//                 confirmingMethod={async () => {
//                     await handleDeleteLog({
//                     payload: [LOCATION?.state?._id],
//                     setIsLoading: () =>
//                         setLcValues(prev => ({...prev,deleteLoading:!prev.deleteLoading})),
//                         next: () => {
//                             handleShowErrorAndWarning({
//                             dispatch,
//                             message: "Log deleted successfully!",
//                             type: "success",
//                             showTime: "5000"
//                             });
//                             navigate("/logs");
//                         }
//                     });
//                 }}
//                 loading={lcValues?.deleteLoading}
//                 closeModalMethod={() => setShowDeleteModal()}
//                 headerTitle="Delete Log"
//                 message="Are you sure, You want to delete this Log?"
//                 /> */}
//         </>
//     )
// }

// export default React.memo(ChecklistListingTable)

/*
date            qid / cr#         comments
11-mar-2026     CR0002            Enable single column filter on the fields visible on these screens

*/

import React, { useCallback, useEffect, useState } from 'react'
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid'
import { checkUserHasPermission, commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone, handleLoggedInUser, handleShowErrorAndWarning, modifyString } from '../../../../utils/clonosCommon'
import { useNavigate } from 'react-router-dom'
import { handleDeleteChecklist } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods'
import { useDispatch } from 'react-redux'
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import { statusStaticData, statusStyleStaticData, timePeriodsStaticData } from "../../../../Constants/StaticData"
import { Tooltip } from '@mui/material'
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE } from '../../../../Constants/Constant'
import { handleDeleteLog, handleGetLogs } from '../../../../utils/LogAndReportsMethods/LogMethods'
import useToggler from '../../../../CustomHooks/TogglerHook'



const convertMuiFilterModelToApiParams = (filterModel) => {
    console.log(filterModel,"filtermodel")
    if (!filterModel?.items?.length) return {};

    const params = {};

    filterModel.items.forEach(({ field, operator, value }) => {
        // Skip empty values
        if (value === undefined || value === null || value === '') return;

        switch (field) {
            case 'name':
                params.name = value;
                break;

            case 'number':
                params.number = value;
                break;

            case 'logNumber':
                params.logNumber = value;
                break;

            case 'documentNumber':
                params.documentNumber = value;
                break;

            case 'status':
                // MUI might send a single value; backend expects comma-separated for $in
                params.status = Array.isArray(value) ? value.join(',') : value;
                break;

            case 'priority':
                params.priority = value;
                break;

            case 'asset':
                params.asset = value;
                break;

            case 'timePeriod':
                params.timePeriod = value;
                break;

            default:
                // For any unmapped field, pass it as-is
                params[field] = value;
        }
    });

    return params;
};

const ChecklistListingTable = ({ tableData, lcDataSetterMethod, totalCount, pageLimit, setPagination, isLoading, setRefreshApi, setRefreshStatusCount }) => {

    const [selectedRows, setSelectedRows] = useState([]);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
    const moduleName = useModuleNameProvider()
      // ── NEW: holds the converted filter params from MUI filterModel ──
            const [filterParams, setFilterParams] = useState({});
              const [filterpagination, setFilterPagination] = useState(commonPageState);
                
                const [filterLoading, setFilterLoading] = useToggler();
                const [filteredLogs,setfilteredLogs]=useState([])
                const [filteredTotalcount,setTotalFilteredCount]=useState(0)
     const [lcValues, setLcValues] = useState({
            deleteLoading: false,
        }); 
            let user = handleLoggedInUser()
            
             const departments= user?.department?.id
  

             console.log(filteredLogs,"filteredLogs")
    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            // flex: 1,
            width: 60,
            disableColumnFilter: true,
            filterable: false, 
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            field: "logNumber",
            headerName: "LOG NUMBER",
            width: 100,
            // flex: 1,
            // disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.logNumber || "-"
        },
        {
            field: "name",
            headerName: "LOG NAME",
            // width: 200,
            width: "300",
            // flex: 1,
            // disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            renderCell: (params) => {
                return <div
                    style={{ display: "flex", gap: "0.30rem", alignItems: "center" }}
                > <p onClick={() => {
                    if (params?.row?.logStatus === "draft") {
                        navigate(`/view-log/${params?.row?.name}`,
                            { state: { logId: params?.row?._id, name: params?.row?.name, logStatus: params?.row?.logStatus } }
                        );
                    } else {
                        handleGotoRecurredLosListing({ _id: params?.row?._id, name: params?.row?.name });
                    }
                }} style={{ textDecoration: "underline", color: "#3f51b5", cursor: "pointer" }}>{params?.row?.name ? params?.row?.name : "-"}</p>
                    {params?.row?.logStatus === "draft" && <span
                        style={{ ...statusStyleStaticData[params?.row?.logStatus], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                        {statusStaticData[params?.row?.logStatus]}
                    </span>}
                </div>
            }
        },
        {
            field: "documentNumber",
            headerName: "DOCUMENT NUMBER",
            width: "200",
            // flex: 1,
            // disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.documentNumber || "-"
        },
        // {
        //     field: "isRecurrence",
        //     headerName: "RECURRING",
        //     // width:"200",
        //     width: 100,
        //     // flex: 1,
        //     disableColumnFilter: true,
        //     headerClassName: "datadrid_common_header",
        //     valueGetter: (params) => params?.row?.isRecurrence ? "Yes" : "No"
        // },
        {
            field: "timePeriod",
            headerName: "FREQUENCY",
            // width:"200",
            width: 100,
            // flex: 1,
            // disableColumnFilter: true,
            //  disableColumnFilter: true,
            // filterable: false, 
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.timePeriod ? timePeriodsStaticData[modifyString(params?.row?.timePeriod, "capitalize")] : "No"
        },
        {
            field: "templateStatuses",
            headerName: "STATUS",
            width: 400,
            // flex: 1,
            // disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            headerAlign: "center",
            renderCell: (params) => {
                const data = params?.row?.templateStatuses;
            
                if (data?.length === 0) {
                    return <div style={{ width: "100%", textAlign: "center" }}>
                        -
                    </div>
                }
                let priorityList = [0, 0, 0, 0, 0, 0];
                (data || []).forEach((item) => {
                    if (item.status === "pendingForApproval") {
                        priorityList[0] = item;
                    }
                    else if (item.status === "overdue") {
                        priorityList[1] = item;
                    }
                    else if (item.status === "scheduled") {
                        priorityList[2] = item;
                    }
                    else if (item.status === "revised") {
                        priorityList[3] = item;
                    }
                    else if (item.status === "completed") {
                        priorityList[4] = item;
                    }
                    else if (item.status === "inProgress") {
                        priorityList[5] = item;
                    };
                })
                priorityList = priorityList.filter(item => item !== 0);
             
                return <div style={{ gap: "0.75rem", display: "flex", justifyContent: "center", width: "100%" }}>
                    {
                        (priorityList || []).map((item, index) => {
                            if (index > 1) return ""
                            return <span
                                style={{ ...statusStyleStaticData[item.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                                {`${statusStaticData[item.status]} ${item.count > 1 ? `(${item.count})` : ""}`}
                            </span>
                        })
                    }
                </div>
            }
        },
        {
            field: "asset",
            headerName: "ASSET",
            width: 200,
            // flex: 1,
            // disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.asset || "-"
        },
        {
            field: "departments",
            headerName: "DEPARTMENTS",
            width: 200,
            // flex: 1,
            // disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            renderCell: (params) => {
                const data = params?.row?.departments;
                return data?.length === 0 ? <span>Not Mentioned</span> :
                    <div style={{ gap: "0.50rem", display: "flex", }}>
                        {data?.length === 1 && <span>{data[0]}</span>}
                        {data?.length === 2 && <>
                            <span>{data[0]},</span>
                            <span>{data[1]}</span>
                        </>}

                        {data?.length > 2 && <Tooltip title={data.slice(2).join(", ")}>
                            +{data.slice(2).length}more
                        </Tooltip>}
                    </div>
            }
        },
        // {
        //     field: "assignedUsers",
        //     headerName: "ASSIGNED USERS",
        //     width: 220,
        //     disableColumnFilter: true,
        //     headerClassName: "datadrid_common_header",
        //     renderCell: (params) => {
        //         const data = params?.row?.assignees;
        //         return <div style={{ gap: "0.50rem", display: "flex", }}>
        //             {data?.length === 0 && <span>-</span>}
        //             {data?.length === 2 ? <>
        //                 <span>{data[0]},</span>
        //                 <span>{data[1]},</span>
        //             </> : <>
        //                 <span>{data[0]}</span>
        //             </>}
        //             {data?.length > 1 && <span>{data[0]},</span>}
        //             {data?.length > 1 && <span>{data[1]},</span>}
        //             {data?.length > 2 && <Tooltip title={data.slice(2).join(", ")}>
        //                 +{data.slice(2).length}more
        //             </Tooltip>}
        //         </div>
        //     }
        // },
        // {
        //     field: "approvers",
        //     headerName: "Approvers",
        //     width: 220,
        //     disableColumnFilter: true,
        //     headerClassName: "datadrid_common_header",
        //     renderCell:(params)=>{
        //          console.log("approvers", params.row)

        //     }
        // },
        // {
        //     field: "receipts",
        //     headerName: "Receipts",
        //     width: 220,
        //     disableColumnFilter: true,
        //     headerClassName: "datadrid_common_header",
        //     renderCell:(params)=>{
        //          console.log("receipts", params.row)
        //     }
        // },
        {
            field: "createdAt",
            headerName: "CREATED ON",
            width: 100,
            // disableColumnFilter: true,
             type: "date",
            valueGetter: (params) => params?.value ? new Date(params.value) : null,
            headerClassName: "datadrid_common_header",
            renderCell: (params) => params?.row?.createdAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "object" })?.clientView : "-"
        },
        // {
        //     field: "updatedAt",
        //     headerName: "LAST UPDATED ON",
        //     width: 150,
        //     disableColumnFilter: true,
        //     headerClassName: "datadrid_common_header",
        //     valueGetter: (params) => params?.row?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.updatedAt, parseType: "object" })?.clientView : "-"
        // }
    ]

    /**
     * "handleGetSelectedRowsMethod" help to get all the selected rows from the ClonosDataGrid Component.
     * @param {Object} props  
     * @property {Array} props.selectedRows This will contain the the selected rows IDs
     */
    const handleGetSelectedRowsMethod = (props) => {
        setSelectedRows(props.selectedRows)
    }

    /**
     * "handleGoToRecurredChecklistListing" function help to redirect user from checklist to checklist view
     * @param {Object} props Contain the ID of of the checklist that we awant to view. 
     */
    const handleGotoRecurredLosListing = (props) => {
   
        navigate(`/log-entries`, { state: { _id: props?._id, name: props?.name } })
    }

    /**
     * "handleGoToEditChecklist" function helps to redirect to edit checklist page.
     */
    const handleGoToEditChecklist = () => {
        navigate("/edit-log-generaldetails", { state: { "mode": "edit", "logId": selectedRows[0] } });

    }
  // ── NEW: called by ClonosDataGrid whenever the user changes a filter ──
    const handleFilterModelChange = useCallback((muiFilterModel) => {
        const converted = convertMuiFilterModelToApiParams(muiFilterModel);
        setFilterParams(converted);
        // Reset to page 1 when filters change
        setFilterPagination((prev) => ({ ...prev, page: 1 }));
    }, []);

      // Re-fetch when page/limit OR filterParams change
        useEffect(() => {
            handleGetLogs({
                dispatch,
                responseSetterMethod: setfilteredLogs,
                 loadingSetter:setFilterLoading,
                payload: {...filterpagination,departments,...filterParams},
                totalRecordSetter: setTotalFilteredCount,
                        
            });
        }, [filterpagination?.page, filterpagination?.limit, filterParams]);

 
    return (
        <>
            <div style={{ padding: "2rem 2rem", height: "90%" }}>
                {
                    filteredLogs?.length > 0 ? <ClonosDataGrid
                    rows={filteredLogs}
                    columns={columns}
                    rowCount={filteredLogs?.length}
                    pageLimit={filterpagination?.limit}
                    totalCount={filteredTotalcount }
                    uniqueIdField={"_id"}
                    isDeleteMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowConfirmationDailog(true) : false}
                    handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
                    isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => handleGoToEditChecklist() : false}
                    onPageChange={e => setFilterPagination({ page: e.page + 1, limit: e.pageSize })}
                    checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
                    loading={isLoading}
                    // ── NEW: wire up server-side filter ──
                    filterMode="server"
                    handleFilterModelChange={handleFilterModelChange}
                    toolbar={true}   // shows the GridToolbar so users can open the filter panel
                />
                :
                <ClonosDataGrid
                    rows={tableData}
                    columns={columns}
                    rowCount={tableData?.length}
                    pageLimit={pageLimit}
                    totalCount={totalCount}
                    uniqueIdField={"_id"}
                    isDeleteMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowConfirmationDailog(true) : false}
                    handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
                    isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => handleGoToEditChecklist() : false}
                    onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                    checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
                    loading={isLoading}
                    // ── NEW: wire up server-side filter ──
                    filterMode="server"
                    handleFilterModelChange={handleFilterModelChange}
                    toolbar={true}   // shows the GridToolbar so users can open the filter panel
                />
                }
                
            </div>
            <ClonosConfirmationBox
                isOpen={showConfirmationDailog}
               loading={lcValues?.deleteLoading}
               confirmingMethod={async () => {
                    await handleDeleteLog({
                    payload: selectedRows,
                    setIsLoading: () =>
                        setLcValues(prev => ({...prev,deleteLoading:!prev.deleteLoading})),
                        next: () => {

                            setRefreshApi()
                            setShowConfirmationDailog(false)
                            handleShowErrorAndWarning({
                            dispatch,
                            message: "Log deleted successfully!",
                            type: "success",
                            showTime: "5000"
                            });
                            
                        }
                    });
                }}
                closeModalMethod={()=>setShowConfirmationDailog(false)}
                 headerTitle="Delete Log"
                message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? "this Log" : "these Logs"}?`}
            />



 {/* <ClonosConfirmationBox
                isOpen={showDeleteModal}
                confirmingMethod={async () => {
                    await handleDeleteLog({
                    payload: [LOCATION?.state?._id],
                    setIsLoading: () =>
                        setLcValues(prev => ({...prev,deleteLoading:!prev.deleteLoading})),
                        next: () => {
                            handleShowErrorAndWarning({
                            dispatch,
                            message: "Log deleted successfully!",
                            type: "success",
                            showTime: "5000"
                            });
                            navigate("/logs");
                        }
                    });
                }}
                loading={lcValues?.deleteLoading}
                closeModalMethod={() => setShowDeleteModal()}
                headerTitle="Delete Log"
                message="Are you sure, You want to delete this Log?"
                /> */}
        </>
    )
}

export default React.memo(ChecklistListingTable)


