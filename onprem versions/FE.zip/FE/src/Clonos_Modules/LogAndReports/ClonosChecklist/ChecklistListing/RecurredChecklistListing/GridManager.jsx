import React, { useEffect, useState } from 'react'
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_UPDATE } from '../../../../../Constants/Constant'
import { checkUserHasPermission, handleShowErrorAndWarning } from '../../../../../utils/clonosCommon'
import ClonosDataGrid from '../../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import ClonosConfirmationBox from '../../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import { handleApproveFilledEntry } from '../../../../../utils/LogAndReportsMethods/LogMethods';
import ClonosAlertBox from '../../../../../components/CommonComponents/ClonosAlertBox/ClonosAlertBox';

const GridManager = (
  {
    rows, columns,
    pagination,
    setPagination,
    uniqueIdField,
    moduleName,
    initialRender,
    isLoading,
    deleteLoading,
    handleDelete,
    handleEdit,
    totalDataCount,
    label,
    dispatch,
    setRefreshApi
  }
) => {
  const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
  const [lcLoadersAndFlags,setLcLoadersAndFlags] = useState({
    approveFilledEntryLoading:false
  })
  const [selectedRows, setSelectedRows] = useState([]);



  const handleGetSelectedRowsMethod = (props) => {
    setSelectedRows(props.selectedRows)
  }

  const isApprovalPossible = () => {
    for(let i = 0;i < rows?.length;i++){
        if(selectedRows?.includes(rows[i]?._id)){
          if(rows[i]?.status !== "pendingForApproval"){
            return false
          }
        }
    }
    return true
  }

  useEffect(() => {
    return () => {
      initialRender.current = initialRender.current + 2
    }
  },[])

  return (
    <>
    <div style={{
      padding: rows?.length > 10 ? "1rem 2rem" : "1rem 2rem",
      // padding: rows?.length > 10 ? "2.5rem 2rem" : "1rem 2rem",
      height: "100%",
      // marginTop: rows?.length > 10 ? "3rem" : "1rem",
    }}>
        <ClonosDataGrid
          rows={rows}
          columns={columns}
          rowCount={rows?.length}
          pageLimit={pagination?.limit}
          totalCount={totalDataCount}
          uniqueIdField={uniqueIdField}
          isDeleteMethod={() => checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? setShowConfirmationDailog(true) : false}
          handleGetSelectedRowsMethod={handleGetSelectedRowsMethod}
          isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? () => handleEdit({ moduleName, label, updatedValue: selectedRows }) : false}
          onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
          checkboxSelection={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) && checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE })}
          loading={isLoading}
          isApproveMethod= {isApprovalPossible() ? () => handleApproveFilledEntry({ lcStateSetterMethod: setLcLoadersAndFlags, dispatch, entryIds: selectedRows, handleRefresh: setRefreshApi }) : false}
          noRowsOverlayMessage="Entries not present yet, To see the template, Please check versions."
        />
      </div>
      
      {/* This pop up is working in feature */}
      {/* <ClonosConfirmationBox
        isOpen={showConfirmationDailog}
        loading={deleteLoading}
        confirmingMethod={() => {
          handleDelete && handleDelete({ moduleName, label, updatedValue: selectedRows });
          setShowConfirmationDailog()
        }}
        closeModalMethod={setShowConfirmationDailog}
        headerTitle={`Delete ${label}.`}
        message={`Are you sure that you want to delete ${selectedRows?.length === 1 ? `this ${label}` : `these ${label}s`}?`}
      /> */}

      <ClonosAlertBox 
        isOpen={showConfirmationDailog} 
        closeModalMethod={() => setShowConfirmationDailog()}
        headerTitle="Delete" 
        message="This feature is under development." 
      />

    </>
  )
}

export default GridManager