import React, { useEffect, useRef, useState } from 'react'
import Subbar from '../../../../../components/CommonComponents/ClonosSubbar/Subbar'
import { handleDeleteLog, handleGetRecurredChecklistEntries, handleGetSingleLog, handleGetTemplateVersions, handleGetVersionTemplateDataSets } from '../../../../../utils/LogAndReportsMethods/LogMethods'
import { useLocation, useNavigate } from 'react-router-dom'
import { checkUserHasPermission, commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone, handleShowErrorAndWarning } from '../../../../../utils/clonosCommon'
import useModuleNameProvider from '../../../../../CustomHooks/ModuleNameProviderHook'
import useToggler from '../../../../../CustomHooks/TogglerHook'
import { doPatchApiCall, doPostApiCall } from '../../../../../utils/ClonosApi'
import CommonNavigator from '../../../../../components/CommonComponents/Navigator/Navigator'
import { ClonosToggleButton } from '../../../../../components/CommonComponents/ClonosToggleButton/ClonosToggleButton'
import GridManager from './GridManager'
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_DOWNLOAD, CLONOS_GLOBAL_ACTION_FILL_ENTRY, CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_COLOUR_BLUE_HOVER, CLONOS_GLOBAL_MODULE_CHECKLISTS, CLONOS_GLOBAL_MODULE_LOGS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS } from '../../../../../Constants/Constant'
import { Card } from '@mui/material'
import Styles from "./RecurredChecklistListing.module.css"
import { statusStaticData, statusStyleStaticData } from '../../../../../Constants/StaticData'
import Modal from '../../../../../components/CommonComponents/Modal/Modal'
import CloseIcon from '../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import { TemplatePreview } from '../../../ClonosTemplate/Components/TemplatePreview/TemplatePreview'
import ClonosSpinner from '../../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner'
import EditIcon from '../../../../../assets/Clonos Common Indicators/Icon_Components/EditIcon'
import { useDispatch } from 'react-redux'
import { handleChange } from '../../../../../utils/WorkOrderMethods/WorkOrderMethods'
import ClonosTextarea from '../../../../../components/CommonComponents/ClonosTextarea/ClonosTextarea'
import { ClonosButton } from '../../../../../components/CommonComponents/Button/Button'
import ClonosConfirmationBox from '../../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox'
import AppUrl from '../../../../../utils/AppUrl'
import ClonosAlertBox from '../../../../../components/CommonComponents/ClonosAlertBox/ClonosAlertBox'


const navigatorKeyEntries = "logEntris";
const navigatorKeyVersions = "versions";
const navigatorKeyReports = "reports";

let navigatorValues = [
    {
        value: "Logs Entries",
        status: true,
        uniqueKey: navigatorKeyEntries,
        disabled: false,
        visibility: (checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_LOGS, action: CLONOS_GLOBAL_ACTION_READ }) || checkUserHasPermission({ moduleName: "checklists", action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })) ? true : false
    },
    {
        value: "Versions",
        status: false,
        uniqueKey: navigatorKeyVersions,
        disabled: false,
        visibility: checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_LOGS, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) ? true : false
    },
    {
        value: "Reports",
        status: false,
        uniqueKey: navigatorKeyReports,
        disabled: false,
        visibility: checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_LOGS, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) ? true : false
    },

];

const RecurredChecklistListing = () => {
    const LOCATION = useLocation();
    const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
    const dispatch = useDispatch()
    const navigate = useNavigate();
    const moduleName = useModuleNameProvider();
    const initialRender = useRef(0);
    const [serverResponse, setServerResponse] = useState(
        {
            generalDetails: {},
            recurredChecklistEntries: [],
            templateVersions: [],
            versionTemplateDetails: {}
        }); // It will contain all the server response in form of key value pair.

    const [lcValues, setLcValues] = useState({
        generalDetailsLoading: false,
        activeTab: navigatorKeyEntries,
        entriesLoading: false,
        versionsLoading: false,
        deleteLoading: false,
        versionTemplatePreviewLoading: false,
        manipulatedDataForVersionTemplatePreview: []
    }); // It will contain all the local values and data.

    const [refreshApi, setRefreshApi] = useToggler(); // When we need to load the component.
    const [pagination, setPagination] = useState(commonPageState);
    const [isVersionTemplateModal, setIsVersionTemplateModal] = useState(false); // Modal opener and closer state 
    const [showReasonModal, setShowReasonModal] = useState(false);
    const [pendingPauseState, setPendingPauseState] = useState(null); // true for pause, false for resume
    const [reason, setReason] = useState("");
    const [showDeleteModal,setShowDeleteModal]=useToggler()
    // State Destructure
    const {
        generalDetailsLoading,
        activeTab,
        entriesLoading,
        deleteLoading,
        totalDataCount,
        versionsLoading,
        activePreviewVersionTemplate,
        versionTemplatePreviewLoading,
        manipulatedDataForVersionTemplatePreview
    } = lcValues;

    const {
        generalDetails,
        recurredChecklistEntries,
        templateVersions,
        versionTemplateDetails
    } = serverResponse;




   

    const entriesColumns = [
        {
            field: "index",
            headerName: "SI.NO",
            // flex: 1,
            width: 60,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            // field: "recurringId",
            field: "entryNumber",
            headerName: "RECURRING ID",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            // valueGetter: (params) => params?.row?.entryNumber || "-"
            // valueGetter: (params) => params?.row?.recurringId || "-"
            renderCell: (params) => {
                return <p
                    onClick={() => handleGotoViewChecklistEntry({ entryId: params?.row?._id, name: LOCATION?.state?.name, logId: LOCATION.state._id })}
                    style={{ textDecoration: "underline", color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER, cursor: "pointer" }}>
                    {params?.row?.entryNumber || "-"}
                </p>
            }
        },
        {
            field: "entryCreatedAt",
            headerName: "DATE / TIME",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.entryCreatedAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.entryCreatedAt, parseType: "object" })?.clientView : "-"
        },
        {
            field: "status",
            headerName: "STATUS",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            // valueGetter: (params) => params?.row?.status || "-"
            renderCell: (params) => {
                return <p style={{ ...statusStyleStaticData[params?.row?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>{params?.row?.status ? statusStaticData[params?.row?.status] : "-"}</p>
            }
        },
        {
            field: "updatedBy",
            headerName: "UPDATED BY",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.updatedBy || "-"
        },

    ]


    const versionsColumns = [
        {
            field: "index",
            headerName: "SI.NO",
            // flex: 1,
            width: 60,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
        },
        {
            field: "templateId",
            headerName: "TEMPLATE ID",
            flex: 1,
            // width: 60,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            // valueGetter: (params) => params?.row?.templateId || "-"
            renderCell: (params) => {
                return <p
                    onClick={() => {
                        setLcValues(prev => {
                            if (prev?.activePreviewVersionTemplate?.versionId !== params?.row?._id) {
                                return { ...prev, activePreviewVersionTemplate: { version: params?.row?.version, versionId: params?.row?._id, isActive: false } }
                            } else {
                                return { ...prev, activePreviewVersionTemplate: { version: params?.row?.version, versionId: params?.row?._id, isActive: true } }
                            };
                        })
                        setIsVersionTemplateModal(true);
                    }}
                    style={{ textDecoration: "underline", color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER, cursor: "pointer" }}>
                    {params?.row?.version || "-"}
                </p>
            }
        },
        {
            field: "createdAt",
            headerName: "DATE",
            // width: 100,
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            filterPanelClassName: "ast_column_filterPanel",
            valueGetter: (params) => params?.row?.createdAt ? handleClientDateInConfiguredTimeZone({ dateString: params?.row?.createdAt, parseType: "object" })?.clientView : "-"
        }
    ]


    // To get recurred checklist entries;
    useEffect(() => {
        handleGetSingleLog({ responseSetterMethod: setServerResponse, lcStateSetterMethod: setLcValues, logId: LOCATION?.state?._id })
    }, [refreshApi]);

    // To manage the grid manager with different tabs 
    useEffect(() => {
        handleGridManagerData(activeTab);
        initialRender.current = initialRender.current + 1;
    }, [pagination.page,pagination.limit, refreshApi,LOCATION?.state?._id]);
    
    useEffect(() => {
        if(initialRender.current !== 1){  // This condition is for restrict API call just after above done on first render.
            if(pagination.page === commonPageState.page && pagination.limit === commonPageState.limit){
                handleGridManagerData({ activeTab, pagination: commonPageState });
            } else {
                setPagination(commonPageState)
            }
        }
    }, [activeTab]);

    // Get Version Template DataSets
    useEffect(() => {
        if (lcValues?.activePreviewVersionTemplate && !lcValues?.activePreviewVersionTemplate?.isActive) {
            handleGetVersionTemplateDataSets({
                responseSetterMethod: setServerResponse,
                lcStateSetterMethod: setLcValues,
                templateId: lcValues?.activePreviewVersionTemplate?.versionId,
            });
        }
    }, [isVersionTemplateModal])


    const handleToggle = (_, uniqueKey) => {
        setLcValues(prev => ({ ...prev, ['activeTab']: uniqueKey }))
    };

    const handleDelete = (props) => {
         setShowDeleteModal()
        
    };

    const handleEdit = (props) => {
        navigate("/edit-log-generaldetails", { state: { "mode": "edit", entryId: LOCATION?.state?.entryId, "logId": LOCATION?.state?._id } });
    };

    const handleGridManagerData = (props) => {
        if ((props.activeTab || activeTab) === navigatorKeyEntries) {
            handleGetRecurredChecklistEntries(
                {
                    responseSetterMethod: setServerResponse,
                    lcStateSetterMethod: setLcValues,
                    logId: LOCATION?.state?._id,
                    pagination: props?.pagination ? props?.pagination : pagination
                }
            )
        }
        else if ((props.activeTab || activeTab) === navigatorKeyVersions) {
            handleGetTemplateVersions(
                {
                    responseSetterMethod: setServerResponse,
                    lcStateSetterMethod: setLcValues,
                    logId: LOCATION?.state?._id,
                    pagination: props?.pagination ? props?.pagination : pagination
                }
            )
        }
    }

    const handleGotoViewChecklistEntry = (props) => {
        navigate(`/view-log/${props?.name}`, { state: { entryId: props?.entryId, logId: props.logId } })
    }


    const handleEditTemplate = () => {
        navigate("/edit-log-generaldetails", { state: { "mode": "edit", "logId": LOCATION?.state?._id } });
    }
    
    const handleChange = (e) => {
        
        const isPaused = e.updatedValue;
      
        setPendingPauseState(isPaused);  // store whether it's pause or resume
        if (isPaused) {
            // Only show modal if user is pausing
            setShowReasonModal(true);
            
        } else {
            // Directly resume without modal
            handleAddComment(false); // Call resume action immediately
            setPendingPauseState(null); // reset temp state
        }
    };

    const handleGetValues = (props) => {
        const { uniqueKey, updatedValue } = props;
        setReason(updatedValue); // update local reason state
    };
    
    // const handleAddComment = (isPause = pendingPauseState) => {
    //     const logId = LOCATION?.state?._id;
    //     if (!logId) {
    //         return;
    //     }
    
    //     const apiUrl = isPause ? `/logs/${logId}/pause` : `/logs/${logId}/resume`;
    //     const payload = isPause ? { logId, reason } : { logId }; // Don't send empty reason on resume
    //       // Update toggle UI immediately
    //        setPendingPauseState(isPause);
    //     doPatchApiCall({ url: apiUrl, payload })
    //         .then((res) => {    
    //             setRefreshApi();
    //             setShowReasonModal(false); // close the modal
    //         })
    //         .catch((err) => console.error("API Error:", err));

    //     // setRefreshApi()    
    // };
    
    const handleAddComment = (isPause = pendingPauseState) => {
    const logId = LOCATION?.state?._id;
    if (!logId) return;

    const apiUrl = isPause ? `/logs/${logId}/pause` : `/logs/${logId}/resume`;
    const payload = isPause ? { logId, reason } : { logId };

    // 1️⃣ Optimistic UI update
    setServerResponse(prev => ({
        ...prev,
        generalDetails: { ...prev.generalDetails, isPaused: isPause }
    }));

    // 2️⃣ Close modal & reset pending state
    setShowReasonModal(false);
    setPendingPauseState(null);

    // 3️⃣ Fire API call
    doPatchApiCall({ url: apiUrl, payload })
        .then(res => {
            // Optional: refresh component if you want to ensure server sync
            // setRefreshApi();
        })
        .catch(err => {
            console.error("API Error:", err);
            // If API fails, revert the optimistic change
            setServerResponse(prev => ({
                ...prev,
                generalDetails: { ...prev.generalDetails, isPaused: !isPause }
            }));
            handleShowErrorAndWarning({
                dispatch,
                type: "error",
                message: "Failed to update Pause/Resume!"
            });
        });
};


    const handleCancel = () => {
        setShowReasonModal(false);
        setPendingPauseState(null);
        
    };
    const handleCreateEntry = () => {
        setShowConfirmationDialog(true);
    };
    const createEntry=async()=>{
        const response=await doPostApiCall({
            url:`${AppUrl.createLogEntry}/${LOCATION?.state?._id}/create-entry`
        })

        if(response.status===CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
            setRefreshApi();            
        }
    }
   

    return (
        <>
            <Subbar
                isStatus={true}
                isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEdit : null}
                isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? handleDelete : null}
                isDownloadMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DOWNLOAD }) ? null : null}
                subbarData={{ status: generalDetails?.logStatus }}
                staticElements={
                    [
                        { "key": "Last Updated On:", value: handleClientDateInConfiguredTimeZone({ dateString: generalDetails?.updatedAt, parseType: "object" })?.clientView },
                        { "key": "Last Updated By:", value: generalDetails?.updatedBy ? generalDetails?.updatedBy : "-" },
                    ]
                }
            />
            <Card
                variant="outlined"
                style={{
                    flex: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    overflowY: "auto",
                    height: "100%",
                    margin: "1rem",
                    borderRadius: "1rem"
                }}
            >
              <CommonNavigator web={true} values={navigatorValues} getSelectedValue={handleToggle} />
                <div style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    alignItems: "center",
                    padding: "2px",
                    position: "relative",
                    bottom: 50,         // small lift (instead of 58)
                    marginLeft: "auto", // 👈 pushes it to the right edge
                    marginRight:"50px"
                }}>
                  
                {/* {
                   checkUserHasPermission({moduleName:CLONOS_GLOBAL_MODULE_LOGS, action:CLONOS_GLOBAL_ACTION_UPDATE }) ? <ClonosToggleButton
                   label={generalDetails?.isPaused ? `Pause` : `Resume`}
                   labelPosition="left"
                   type="toggle"
                   uniqueKey="Pause/Resume"
                   handleGetValues={handleChange}
                   checked={generalDetails?.isPaused}
                /> :  serverResponse?.generalDetails?.endDateAndTime && new Date(serverResponse?.generalDetails?.endDateAndTime).getTime() > Date.now() && checkUserHasPermission({moduleName:CLONOS_GLOBAL_MODULE_LOGS, action:CLONOS_GLOBAL_ACTION_FILL_ENTRY })&&!generalDetails?.isRecurrence?<ClonosButton onClick={handleCreateEntry} >Create Entry</ClonosButton>:null
                } */}
            {
                checkUserHasPermission({ moduleName: CLONOS_GLOBAL_MODULE_LOGS, action: CLONOS_GLOBAL_ACTION_UPDATE}) ? (
                    <div className={Styles.toggleContainer}>
                    <span className={`${Styles['toggle-label']} ${!generalDetails?.isPaused ? Styles.active : Styles.inactive}`}>Resume</span>
                    <ClonosToggleButton
                        type="toggle"
                        uniqueKey="Pause/Resume"
                        handleGetValues={handleChange}
                        // checked={generalDetails?.isPaused}   // true = running
                        checked={pendingPauseState !== null ? pendingPauseState : generalDetails?.isPaused}
                    />
                    <span className={`${Styles['toggle-label']} ${ generalDetails?.isPaused ? Styles.active : Styles.inactive }`}>Pause</span>
                    </div>
                ) : (
                    serverResponse?.generalDetails?.endDateAndTime && new Date(serverResponse?.generalDetails?.endDateAndTime).getTime() > Date.now() && checkUserHasPermission({moduleName:CLONOS_GLOBAL_MODULE_LOGS, action:CLONOS_GLOBAL_ACTION_FILL_ENTRY })&&!generalDetails?.isRecurrence?<ClonosButton onClick={handleCreateEntry} >Create Entry</ClonosButton>:null
                )
            }



              {/* Reason modal     */}

                <Modal isOpen={showReasonModal} closeModalMethod={handleCancel} stopOverlayCloser={true}>
                    <div className={Styles.a_c_container}>
                        <div className={Styles.a_c_header}>
                        <h4>Add Comments</h4>
                        <CloseIcon onClick={handleCancel} />
                        </div>

                        <div className={Styles.a_c_section}>
                        <ClonosTextarea 
                            isLabel={true}
                            label={"Reason"}
                            uniqueKey={"reason"}
                            isMandatory={true}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please add a Reason."}
                        />
                        <div className={Styles.btn_wrapper}>
                            <ClonosButton onClick={handleCancel}>Cancel</ClonosButton>
                            <ClonosButton variant={"filled"} onClick={handleAddComment}>
                            Submit
                            </ClonosButton>
                        </div>
                        </div>
                    </div>
                    </Modal>


            </div>
                {((recurredChecklistEntries?.length && navigatorKeyEntries === activeTab) || 
                (templateVersions?.length && navigatorKeyVersions === activeTab)) ? (
                    <GridManager
                        rows={activeTab === navigatorKeyEntries ? recurredChecklistEntries : activeTab === navigatorKeyVersions ? templateVersions : []}
                        columns={activeTab === navigatorKeyEntries ? entriesColumns : activeTab === navigatorKeyVersions ? versionsColumns : []}
                        pagination={pagination}
                        setPagination={setPagination}
                        uniqueIdField={"_id"}
                        initialRender={initialRender}
                        moduleName={moduleName}
                        isLoading={entriesLoading || versionsLoading}
                        deleteLoading={deleteLoading}
                        // handleDelete={handleDelete}
                        handleEdit={handleEdit}
                        totalDataCount={totalDataCount}
                        // label={"Checklist Entries"}
                        label={"Log Entries"}
                        dispatch={dispatch}
                        setRefreshApi={setRefreshApi}
                    />
                ) : activeTab === navigatorKeyReports ? (
                    <div className={Styles.no_grid_data}>
                        <span>Please contact admin!</span>
                    </div>
                    ):(
                    <div className={Styles.no_grid_data}>
                        <span>{!recurredChecklistEntries && "Entry is not yet scheduled. To view the template, please check the versions."}</span>
                    </div>
                )}
            </Card>
            <Modal isOpen={isVersionTemplateModal} closeModalMethod={setIsVersionTemplateModal} >
                <div className={Styles.imported_template_Preview_container}>
                    <header className={Styles.itpc_header}>
                        <span>{lcValues?.activePreviewVersionTemplate?.version}</span>
                        <div className={Styles.split}>
                            <EditIcon onClick={() => handleEditTemplate()} />
                            <CloseIcon onClick={() => setIsVersionTemplateModal(false)} />
                        </div>
                    </header>
                    {
                        versionTemplatePreviewLoading ? <ClonosSpinner /> : <>
                            <TemplatePreview
                                attributes={manipulatedDataForVersionTemplatePreview}
                                isEdit={false}
                            />
                        </>
                    }
                </div>
            </Modal>
            <ClonosConfirmationBox
                isOpen={showConfirmationDialog}
                closeModalMethod={setShowConfirmationDialog}
                confirmingMethod={async () => {
                    await createEntry();
                    await setShowConfirmationDialog(false);
                }}
                rejectingMethod={() => setShowConfirmationDialog(false)}
                message={"Do you want to create a new entry ?"}
                headerTitle={"New Entry"}
            />
            
            {/* show delte Alert box */}
             {/* <ClonosAlertBox 
                isOpen={showDeleteModal} 
                closeModalMethod={() => setShowDeleteModal()}
                headerTitle="Delete" 
                message="This feature is under development." 
            /> */}


             <ClonosConfirmationBox
                isOpen={showDeleteModal}
                confirmingMethod={async () => {
                    await handleDeleteLog({
                    payload: [LOCATION?.state?._id],
                    setIsLoading: () =>
                        setLcValues(prev => ({...prev,deleteLoading:!prev.deleteLoading})),
                        next: () => {
                            handleShowErrorAndWarning({
                            dispatch,
                            message: "Log deleted successfully!",
                            type: "success",
                            showTime: "5000"
                            });
                            navigate("/logs");
                        }
                    });
                }}
                loading={lcValues?.deleteLoading}
                closeModalMethod={() => setShowDeleteModal()}
                headerTitle="Delete Log"
                message="Are you sure, You want to delete this Log?"
                />

        </>
    )
}

export default RecurredChecklistListing
