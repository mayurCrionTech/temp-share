import React, { useState } from 'react'
import Styles from "./ChecklistView.module.css"
import { useLocation, useNavigate } from 'react-router-dom';
import { exportChecklistInformaiton, handleApproveFilledEntry, handleApproveTheValidateRequest, handleChangeChecklistStatus, handleCreateValidateRequests, handleDeleteChecklist, handleDeleteLog, handleEditChecklist, handleFillingEntry, handleGetChecklistEntry, handleGetSingleChecklist, handleGetSingleChecklistDetaSets, handleGetSingleLog, handleGetValidateRequests, handleInprogressFilledEntry, handleUpdateFilledEntry } from '../../../../utils/LogAndReportsMethods/LogMethods';
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { checkUserHasPermission, commonPageState, generateUniqueId, getDayMonthYear, getFormatedDate, getToken, handleClientDateInConfiguredTimeZone, handleGetENVVariables, handleLoggedInUser, handleRedirectAfterEvent, handleShowErrorAndWarning, modifyString, parseISOTimeString, setSerialNumber } from '../../../../utils/clonosCommon';
import { useRef } from 'react';
import { Card } from '@mui/material';
import Modal from '../../../../components/CommonComponents/Modal/Modal';
import ClonosExportOptions from '../../../../components/CommonComponents/ClonosExportOptions/ClonosExportOptions';
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button';
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import COMMON_EYE_ICON from "../../../../assets/UIUX/icons/Common_Icon/COMMON_EYE_ICON.svg"
import { IoDocumentTextOutline } from "react-icons/io5";
import ClonosConfirmationBox from '../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import Subbar from '../../../../components/CommonComponents/ClonosSubbar/Subbar';
import useToggler from '../../../../CustomHooks/TogglerHook';
import { CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_DOWNLOAD, CLONOS_GLOBAL_ACTION_FILL_ENTRY, CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_COLOUR_BLUE_HOVER, CLONOS_GLOBAL_STATUS_COMPLETED, CLONOS_GLOBAL_STATUS_DRAFT, CLONOS_GLOBAL_STATUS_IN_PROGRESS, CLONOS_GLOBAL_STATUS_OVERDUE, CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL, CLONOS_GLOBAL_STATUS_REVISED, CLONOS_GLOBAL_STATUS_SCHEDULED, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT, CLONOS_GLOBAL_USER_TYPE_ENGINEER, CLONOS_GLOBAL_USER_TYPE_MANAGER } from '../../../../Constants/Constant';
import { ImagePreviewModal } from '../../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal';
import { TemplatePreview } from '../../ClonosTemplate/Components/TemplatePreview/TemplatePreview';
import CloseIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon';
import useModuleNameProvider from '../../../../CustomHooks/ModuleNameProviderHook';
import ClonosReadMoreReadLess from '../../../../components/CommonComponents/ClonosReadMoreAndLess/ClonosReadMoreAndLess';
import { statusStaticData, statusStyleStaticData } from '../../../../Constants/StaticData';
import { doGetApiCall, doPostApiCall } from '../../../../utils/ClonosApi';
import AppUrl from '../../../../utils/AppUrl';
import ClonosDocumentViewer from '../../../../components/CommonComponents/document-viewer/ClonosDocumentViewer';
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner';
import { MediaBlackStaticIcon } from '../../../../resources/icons/static/MediaBlackStaticICon';
import { MediaBlueStaticIcon } from '../../../../resources/icons/static/MediaBlueStaticIcon';
import FileUploader from '../../../../components/CommonComponents/FileUploader/FileUploader';
import { ViewReportRecurranceDetailsModal } from './ViewReportRecurranceDetailsModal';
import ClonosAlertBox from '../../../../components/CommonComponents/ClonosAlertBox/ClonosAlertBox';
//#160 
import { UnAuthorizedModal } from '../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal';
/*
    date            qid / cr#         comments
    07-Apr-2026     -#160             Broken Access Control - Permission Restriction FrontEnd
    */
const ChecklistView = () => {
    // Local States
    const LOCATION = useLocation();

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const moduleName = useModuleNameProvider();
    const generalDetailsRef = useRef(null)
    const [lcIntervals, setLcIntervals] = useState({});
    const [isDownloadModal, setIsDownloadModal] = useState(false);
    const [pagination, setPagination] = useState(commonPageState);
    const [isPreviewTemplateModal, setIsPreviewTemplateModal] = useState(false);
    const [needToExportFileDetails, setNeedToExportFileDetails] = useState({});
    const [allAreasThatNeedsToExportAsPDFState, setAllAreasThatNeedsToExportAsPDFState] = useState([]);
    const [isEditEntry, setIsEditEntry] = useToggler();
    const [loadedImages, setLoadedImages] = useState([]); 
    const [selectedRowId, setSelectedRowId] = useState({});
    const [loadImagesLoading, setLoadImagesLoading] = useState(false); 
    const [isLoading, setIsLoading] = useState(false);
    const [isHovered, setIsHovered] = useState(false);
    const [formData,setFormData] = useState({});
    const [lcValues, setLcValues] = useState({
        validateLoading: false,
        approveLoading: false,
        reviseLoading: false,
        validateRequestServerResponse: null,
        checklistEntryDetailsLoading: false,
        manipulatedDataForTemplatePreview: [],
        updatedFilledEntryLoading: false,
        approveFilledEntryLoading: false,
        inprogressFillingEntriesLoading:false,
        showRecurrenceDetails:false,
        deleteLoading:false

    });

    

    const [serverResponse, setServerResponse] = useState({
        entryDetails: {},
        lcChecklistData: {}
    });

    const [confirmationDialogStates, setConfirmationDialogStates] = useState(
        {
            checklistDeleteState: false,
        }
    );

    const [isValidateConfirmationModal, setIsValidateConfirmationModal] = useState(false);
    const [isNotePreviewModal, setIsNotePreviewModal] = useState(false);
    const [refreshApi, setRefreshApi] = useToggler();
    const [isImagePreviewModal, setIsImagePreviewModal] = useToggler();
    const [isReportPreviewModal, setIsReportPreviewModal] = useState(null);
    //#160 
    const [isUnauthorized, setIsUnauthorized] = useState(false);

    const {
        validateRequestServerResponse,
        images,
        checklistEntryDetailsLoading,
        manipulatedDataForTemplatePreview,
        updatedFilledEntryLoading,
        approveFilledEntryLoading,
        inprogressFillingEntriesLoading
    } = lcValues;

    const { entryDetails, lcChecklistData } = serverResponse;
    
   
    const columns = [
        {
            field: "index",
            headerName: "SI.NO",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.index || "-"
        },
        {
            field: "asset",
            headerName: "Asset",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.asset || "-",
        },
        {
            field: "fieldName",
            headerName: "Field Name",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => params?.row?.fieldName || "-",
        },
        {
            field: "fieldValue",
            headerName: "Value",
            // width:"200",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            valueGetter: (params) => {

                const row = params.row;
                
                                if (row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT || row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE || row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) {
                  //return row?.fieldValue !== undefined && row?.fieldValue !== null && row?.fieldValue !== "" ? row.fieldValue : "-";
                   if (row?.fieldValue !== undefined && row?.fieldValue !== null && row?.fieldValue !== "") {
                        if (
                            row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER && row?.isFormula && !isNaN(row.fieldValue) ) {
                            return Number(row.fieldValue).toFixed(2); // ✅ only when isFormula true
                        }
                        return row.fieldValue; // ✅ normal case
                }
                return "-";
                //      if (row?.fieldValue !== undefined && row?.fieldValue !== null && row?.fieldValue !== "") {
                //     if (row?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER && !isNaN(row.fieldValue)) {
                //         return Number(row.fieldValue).toFixed(2); // ✅ fixed to 2 decimals
                //     }
                //     return row.fieldValue;
                // }
                // return "-";
                } else {
                    const filteredData = row?.fieldValue?.filter(item => item?.isActive);
                    const data = filteredData?.map(item => item?.optionValue);
                    return data?.length ? data?.join(" | ") : "-"
                }
            }
        },
      
        {
            field: "uploadImage",
            headerName: "Upload",
            flex: 1,
            disableColumnFilter: true,
            headerClassName: "datadrid_common_header",
            renderCell: (params) => {
              const row = params.row;
              const rowId = row.id;
              
              const hasImages =
                entryDetails?.logEntry?.data?.find((item) => item._id === rowId)?.images?.length > 0 ||
                formData?.images?.[rowId]?.length > 0;
          
              return (
                <div
                  style={{
                    color: hasImages ? "#0A5FFF" : "#000",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px"
                  }}
                  onClick={() => handleImageClick(rowId)} // pass rowId here
                >
                  {hasImages ? (
                    <>
                      <MediaBlueStaticIcon />
                      View Images
                    </>
                  ) : (
                    <>
                      <MediaBlackStaticIcon />
                      Add Images
                    </>
                  )}
                </div>
              );
            }
          }
          
    ];

     const handleUploadImages = (files) => {
        const logId = LOCATION?.state?.logId;
        const entryId = LOCATION?.state?.entryId;
        const fieldId = selectedRowId;
      
        if (!logId || !entryId || !fieldId) {
          console.error("Missing required IDs: logId, entryId, or fieldId.");
          return;
        }
      
        const url = `logs/${logId}/entries/${entryId}/fields/${fieldId}/images`;
      
        // Prepare the FormData object to send files
        const formData = new FormData();
      
        // Append each file to the FormData object
        files.forEach((file) => {
          formData.append("files", file); // Make sure "files" is the correct field name
        });
      
        // Make the API request
        doPostApiCall({
          url,
          payload: formData, // FormData should be sent as the payload
          headers: {
            "Content-Type": "multipart/form-data", // Ensure Content-Type is set correctly
          },
          isFormData: true, // You might need to tell your API handler that FormData is being sent
        })
          .then((res) => {
            console.log("Upload successful", res);
         
          })
          .catch((err) => {
            console.error("Upload failed", err);
          });
      };
      
      const handleImageClick = async (rowId) => {
        
        setSelectedRowId(rowId);
        setLoadImagesLoading(true);

        const logId = LOCATION?.state?.logId;
        const entryId = LOCATION?.state?.entryId;
        const url = `/logs/${logId}/entries/${entryId}/fields/${rowId}/images`;
  
        try {
          const res = await doGetApiCall({ url });
          const images = res?.data?.result?.data || [];
          setLoadedImages(images);
        } catch (err) {
          console.error("Failed to load images", err);
          setLoadedImages([]);
       
        } finally {
          setLoadImagesLoading(false);
          setIsImagePreviewModal(true);
        }
      };
    

    const handleGetDetails = (props) => {
        setNeedToExportFileDetails(props)
    };

    const handleExportFile = () => {
        exportChecklistInformaiton(
            {
                fileName: needToExportFileDetails?.fileName,
                type: needToExportFileDetails?.format,
                pdfData: allAreasThatNeedsToExportAsPDFState,
                pageType: needToExportFileDetails?.pageType,
                xlsxData: lcChecklistData
            })
        setIsDownloadModal(false)
    };


    const lcHandleGoToLogEdit = () => {
        navigate("/edit-log-generaldetails", { state: { "mode": "edit", entryId: LOCATION?.state?.entryId, "logId": LOCATION?.state?.logId } });
    };

    const lcHandleDelete = () => {
        setConfirmationDialogStates({ ...confirmationDialogStates, ["checklistDeleteState"]: true });
    };
    

    // const handleGetUpdatedDataSets = (attributes, handleLoader) => {
    //     console.log(attributes,"attributeres")
    //     attributes = attributes?.map(attribute => {
    //         if (
    //             (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
    //                 attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
    //                 attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN) && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })
    //         ) {
    //             return { index: attribute?.index, fieldValue: attribute?.fieldValue?.filter(item => item?.isActive).map(item => item?._id), type: attribute?.type };
    //         } else {
    //             return { index: attribute?.index, fieldValue: attribute?.fieldValue, type: attribute?.type };
    //         }
    //     });
    //     if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) {
    //         handleUpdateFilledEntry({
    //             lcStateSetterMethod: setLcValues,
    //             entryId: LOCATION?.state?.entryId,
    //             payload: { data: attributes },
    //             handleRefresh: setRefreshApi,
    //             handleFinallyExecutors: { setIsEditEntry, handleLoader },
    //             dispatch
    //         });
    //     } else if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })) {
    //         handleFillingEntry({
    //             lcStateSetterMethod: setLcValues,
    //             entryId: LOCATION?.state?.entryId,
    //             payload: { data: attributes },
    //             handleRefresh: setRefreshApi,
    //             handleFinallyExecutors: { setIsEditEntry, handleLoader },
    //             dispatch
    //         });
    //     };
    // };



const handleGetUpdatedDataSets = (updatedAttributes, handleLoader) => {
   

    const payload = { data: updatedAttributes };

    if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) {
        handleUpdateFilledEntry({
            lcStateSetterMethod: setLcValues,
            entryId: LOCATION?.state?.entryId,
            payload,
            handleRefresh: setRefreshApi,
            handleFinallyExecutors: { setIsEditEntry, handleLoader },
            dispatch
        });
    } else if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })) {
        handleFillingEntry({
            lcStateSetterMethod: setLcValues,
            entryId: LOCATION?.state?.entryId,
            payload,
            handleRefresh: setRefreshApi,
            handleFinallyExecutors: { setIsEditEntry, handleLoader },
            dispatch
        });
    } 
};

const handleGetInprogressDataSets = (attributes, handleLoader) => {
    

    const payload = {
        data: attributes.map(attr => ({
            index: attr.index,
            fieldValue: attr.fieldValue,
            type: attr.type
        }))
    };

    handleInprogressFilledEntry({
        lcStateSetterMethod: setLcValues,
        entryId: LOCATION?.state?.entryId,
        payload,
        handleRefresh: setRefreshApi,
        handleFinallyExecutors: { setIsEditEntry, handleLoader },
        dispatch
    });
};


  const handleGotoAssetView = ( assetId, assetName) => {
    
        navigate(`/view-asset/${assetName}`, { state: {id: assetId, name: assetName } })
    }

    useEffect(() => {
  //  If user directly enters URL → state is null
  //#160 
    if (!LOCATION?.state) {
        setIsUnauthorized(true);
        return;
    }

        if (LOCATION?.state?.logStatus !== "draft" && LOCATION?.state?.logStatus !== "scheduled") {
            handleGetChecklistEntry({
                responseSetterMethod: setServerResponse,
                entryId: LOCATION?.state?.entryId,
                lcStateSetterMethod: setLcValues,
            });
        } else {
            handleGetSingleLog({ responseSetterMethod: setServerResponse, lcStateSetterMethod: setLcValues, logId: LOCATION.state?.logId })
        }
    }, [refreshApi, LOCATION?.state?.entryId]);

  
    useEffect(() => {
      
        setServerResponse(prev => ({ ...prev, ["lcChecklistData"]: serverResponse?.generalDetails }));
    }, [serverResponse?.generalDetails])

   
    
    const handleSingleReport= ()=>{
        const logId = LOCATION?.state?.logId
        const entryId= LOCATION?.state?.entryId
        setIsLoading(true); // Show spinner before API call
        doPostApiCall({url:`/logs/${logId}/entries/${entryId}/create-report`, payload: { logId, entryId }})
        .then((res)=>{
            const fileData = res?.data?.result;
            if (fileData && fileData.url) {
                const urlParts = fileData.url.split(".");
                const extension = urlParts[urlParts.length - 1].split("?")[0];  // Extract extension safely
                setIsReportPreviewModal({
                    ...fileData,
                    contentType: "application/pdf",  // Manually set if missing
                    extension: extension.toLowerCase(), // Dynamically set extension
                });
            } else {
                console.warn("Invalid file data received:", fileData);
                setIsReportPreviewModal(null);
            }
       
        })
        .catch((err)=>console.log(err.message))
        .finally(() => setIsLoading(false)); // Hide spinner after API call  
    }

    const formatTimePeriod = (timePeriod) => {
    if (!timePeriod) return "";

    const lower = timePeriod.toLowerCase();

    switch (lower) {
        case "day":
        return "Daily";
        case "week":
        return "Weekly";
        case "month":
        return "Monthly";
        case "year":
        return "Yearly";
        case "hour":
        return "Hourly";
        default:
        // fallback (just add "ly")
        return `${modifyString(timePeriod, "capitalize")}ly`;
    }
    };


 //#160 
   if (isUnauthorized) {
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />;
    }

    return (
        <>
            <Subbar
                isStatus={true}
                isEditMethod={(checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) && LOCATION?.state?.logId) ? lcHandleGoToLogEdit : null}
                isDeleteMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? lcHandleDelete : null}
                isDownloadMethod={checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_DOWNLOAD }) ? () => setIsDownloadModal(true) : null}
                subbarData={{ status: entryDetails?.logEntry?.status }}
                staticElements={
                    [
                        { "key": "Last Updated On:", value: handleClientDateInConfiguredTimeZone({ dateString: entryDetails?.logEntry?.updatedAt, parseType: "object" })?.clientView },
                         { "key": "Last Updated By:", value: entryDetails?.logEntry?.updatedBy ?? "-" },
                        // { "key": "Last Updated By:", value: lcChecklistData?.updatedBy ? lcChecklistData?.updatedBy : "-" },
                    ]
                }
                htmlElements={[
                    <div style={{ display: manipulatedDataForTemplatePreview?.length > 0 ? "flex" : "none" }} key={generateUniqueId(2)} onClick={() => setIsPreviewTemplateModal(true)}>
                        <img src={COMMON_EYE_ICON} alt='Eye Icon' loading='lazy' />
                        <span style={{
                            color: "#0A5FFF",
                            fontFamily: "Roboto",
                            fontSize: "1rem",
                            fontStyle: "normal",
                            fontWeight: "600",
                            lineHeight: "normal"
                        }}>Preview</span>
                    </div>,
                  <div 
                      onClick={handleSingleReport}
                      onMouseEnter={() => setIsHovered(true)}
                      onMouseLeave={() => setIsHovered(false)}
                  >
                      <IoDocumentTextOutline size={24} color={isHovered ? "#0A5FFF" : "#1C1C1C"} />
                      <span style={{
                          color: isHovered ? "#0A5FFF" : "#06337E",
                          fontFamily: "Roboto",
                          fontSize: "1rem",
                          fontStyle: "normal",
                          fontWeight: "600",
                          lineHeight: "normal",
                          marginLeft: "5px"
                      }}>
                          Report
                      </span>
                  </div>           
                ]}
            />
            <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
                <div className={Styles.template_and_general_detail_container}>
                    <div className={Styles.sub_header} aria-label='Sub Header'>
                        <span aria-label='Checklist Title'>{lcChecklistData?.name}</span>
                        <div className={Styles.validate_container} aria-label='Validate the checklist data sets contianer'>
                            {
                                handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER && validateRequestServerResponse?.length > 0 && <>

                                    <ClonosButton loading={lcValues?.reviseLoading} isDisabled={lcValues?.reviseLoading || lcChecklistData?.status === "revised" ? true : false} variant="outlined" onClick={() => {
                                        setLcValues(prev => {
                                            return { ...prev, "reviseLoading": true }
                                        })
                                        handleChangeChecklistStatus({ checklistId: lcChecklistData?.id, dispatch, payload: { status: "revised", isGetResponse: true }, setRefreshApi, responseSetterMethod: setLcValues })
                                        // setRefreshApi()
                                    }}>Revise</ClonosButton>
                                    <ClonosButton
                                        loading={lcValues?.validateLoading || lcValues?.approveLoading}
                                        isDisabled={lcValues?.validateLoading || lcValues?.approveLoading}
                                        onClick={() => setIsValidateConfirmationModal(true)}
                                        variant="filled"
                                    >APPROVE</ClonosButton>
                                </>
                            }
                            {
                                handleLoggedInUser()?.role_id !== CLONOS_GLOBAL_USER_TYPE_MANAGER && handleLoggedInUser().role_id === CLONOS_GLOBAL_USER_TYPE_ENGINEER && lcChecklistData?.status !== "completed" &&
                                <>
                                    {

                                        lcChecklistData?.isManagerApprovalRequired === false && <ClonosButton loading={lcValues?.reviseLoading} isDisabled={lcValues?.reviseLoading || lcChecklistData?.status === "revised" ? true : false} variant="outlined" onClick={() => {
                                            setLcValues(prev => {
                                                return { ...prev, "reviseLoading": true }
                                            })
                                            handleChangeChecklistStatus({ checklistId: lcChecklistData?.id, dispatch, payload: { status: "revised", isGetResponse: true }, setRefreshApi, responseSetterMethod: setLcValues })
                                            // setRefreshApi()
                                        }}>Revise</ClonosButton>
                                    }
                                    <ClonosButton
                                        loading={lcValues?.validateLoading || lcValues?.approveLoading}
                                        isDisabled={lcValues?.validateLoading || validateRequestServerResponse?.length > 0 && true}
                                        onClick={() => {
                                            if (lcChecklistData?.isManagerApprovalRequired === false) {
                                                handleChangeChecklistStatus({ checklistId: lcChecklistData?.id, dispatch, payload: { status: "completed", isGetResponse: true }, setRefreshApi })
                                            }
                                            else {
                                                setIsValidateConfirmationModal(true)
                                            }
                                        }}
                                        variant="filled"
                                    >{lcChecklistData?.isManagerApprovalRequired ? "Validate" : "Approve"}</ClonosButton>
                                </>
                            }
                            {
                                (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) &&
                                    entryDetails?.logEntry?.status !== CLONOS_GLOBAL_STATUS_SCHEDULED &&
                                    entryDetails?.logEntry?.status !== CLONOS_GLOBAL_STATUS_REVISED &&
                                    lcChecklistData?.logStatus !== CLONOS_GLOBAL_STATUS_DRAFT
                                ) && <ClonosButton
                                    onClick={setIsEditEntry}
                                >{isEditEntry ? "Cancel" : "Edit Data"}</ClonosButton>
                            }
                            {
                                (entryDetails?.logEntry?.status === CLONOS_GLOBAL_STATUS_PENDING_FOR_APPROVAL && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) && <ClonosButton
                                    variant="filled"
                                    isDisabled={isEditEntry}
                                    onClick={() => handleApproveFilledEntry({ lcStateSetterMethod: setLcValues, dispatch, entryIds: [LOCATION?.state?.entryId], handleRefresh: setRefreshApi })}
                                    loading={approveFilledEntryLoading}
                                >
                                    Approve
                                </ClonosButton>
                            }
                        </div>
                    </div>
                    {checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY }) && <div className={Styles.checklist_view_general_details_container}>
                        <section aria-label='General details' className={Styles.checklist_view_general_details} >
                            <div className={Styles.checklist_view_general_details_child_container} ref={generalDetailsRef}>
                                <table>
                                    <tr>
                                        <td>Document Number</td>
                                        <td>{lcChecklistData?.documentNumber ? lcChecklistData?.documentNumber : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Name</td>
                                        <td>{lcChecklistData?.name ? lcChecklistData?.name : "Not Mentioned"} <span
                                            style={{ ...statusStyleStaticData[lcChecklistData?.logStatus], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                                            {`${statusStaticData[lcChecklistData?.logStatus]}`}
                                        </span></td>
                                    </tr>
                                    <tr>
                                        <td>Description</td>
                                        <ClonosReadMoreReadLess text={lcChecklistData?.description ? lcChecklistData?.description : "Not Mentioned"} maxLength={100} />
                                    </tr>
                                    <tr>
                                        <td>{lcChecklistData?.departments?.length > 1 ? "Departments" : "Department"}</td>
                                        <td>{lcChecklistData?.departments?.length ? lcChecklistData?.departments?.map(item => {
                                            return <span>{lcChecklistData?.departments?.length > 1 ? `${item}, ` : item}</span>
                                        }) : "Not Mentioned"}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>{`Assigned ${lcChecklistData?.assignees?.length > 1 ? "Users" : "User"}`}</td>
                                        <td>{lcChecklistData?.assignees?.length ? lcChecklistData?.assignees?.map((item,index) => {
                                            return <span key={index}>{item?.name || item} {index !== lcChecklistData?.assignees?.length - 1 ? ", " : ""}</span>
                                        }) : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>{lcChecklistData?.approvers?.length > 1 ? "Approvers" : "Approver"}</td>
                                        <td>{lcChecklistData?.approvers?.length ? lcChecklistData?.approvers?.map((item,index) => {
                                            return <span key={index}> {item?.name || item} {index !== lcChecklistData?.approvers?.length - 1 ? ", " : ""}</span>
                                        }) : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>{lcChecklistData?.teams?.length > 1 ? "Teams" : "Team"}</td>
                                        <td>{lcChecklistData?.teams?.length ? lcChecklistData?.teams?.map((item,index) => {
                                            return <span key={index}>{item} {index !== lcChecklistData?.teams?.length - 1 ? ", " : ""}</span>
                                        }) : "Not Mentioned"}</td>
                                    </tr>
                                    
                                </table>
                                <table>
                                    <tr>
                                        <td>Frequency</td>
                                        {/* <td>{lcChecklistData?.recurrenceDetails?.timePeriod ? `${modifyString(lcChecklistData?.recurrenceDetails?.timePeriod, "capitalize")}ly ${lcChecklistData?.recurrenceDetails?.frequency && `(Every ${lcChecklistData?.recurrenceDetails?.frequency})`}` : "Not Mentioned"}</td> */}
                                        <td>
                                    {lcChecklistData?.recurrenceDetails?.timePeriod
                                        ? `${formatTimePeriod(lcChecklistData?.recurrenceDetails?.timePeriod)} ${
                                            lcChecklistData?.recurrenceDetails?.frequency &&
                                            `(Every ${lcChecklistData?.recurrenceDetails?.frequency})`
                                        }`
                                        : "Not Mentioned"}
                                    </td>

                                    </tr>
                                    <tr>
                                    <td>Asset</td>
                                    <td
                                        style={{
                                        color: lcChecklistData?.asset?.name ? CLONOS_GLOBAL_COLOUR_BLUE_HOVER : "inherit",
                                        cursor: lcChecklistData?.asset?.name ? "pointer" : "default"
                                        }}
                                        onClick={() => {
                                           if (lcChecklistData?.asset?.id && lcChecklistData?.asset?.name) {
                                                handleGotoAssetView(lcChecklistData.asset.id, lcChecklistData.asset.name);
                                           }
                                        }}
                                    >
                                        {lcChecklistData?.asset?.name || "Not Mentioned"}
                                    </td>
                                    </tr>

                                    <tr>
                                        <td>Scheduled Time</td>
                                        <td>{(() => {
                                            const parsedISOTimeString = handleClientDateInConfiguredTimeZone({ dateString: entryDetails?.logEntry?.entryCreatedAt, parseType: "object" })
                                           
                                            if (!parsedISOTimeString) return "-"
                                            return `${parsedISOTimeString?.clientView}`
                                            // return `${parsedISOTimeString?.clientView} ${parsedISOTimeString?.time}`
                                        })()}</td>
                                    </tr>
                                    <tr>
                                        <td>Created On</td>
                                        <td>{lcChecklistData?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: lcChecklistData?.createdAt, parseType: "object" }).clientView : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>{lcChecklistData?.emailNotificationRecipients?.length > 1 ? "Email Notification Recipients" : "Email Notification Recipient"}</td>
                                        <td>{lcChecklistData?.emailNotificationRecipients?.length ? lcChecklistData?.emailNotificationRecipients?.map((item,index) => {
                                             return <span key={index}>{item?.name || item} {index !== lcChecklistData?.emailNotificationRecipients?.length - 1 ? ", " : ""}</span>   }) : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Last Updated On</td>
                                        <td>{entryDetails?.logEntry?.updatedAt ? handleClientDateInConfiguredTimeZone({ dateString: entryDetails?.logEntry?.updatedAt, parseType: "object" })?.clientView : "Not Mentioned"}</td>
                                    </tr>
                                    <tr>
                                        <td>Recurrence</td>
                                        <td style={{ color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER, cursor:"pointer"}} onClick={() =>setLcValues((prev) => ({...prev,showRecurrenceDetails: true})) }>{lcChecklistData?.isRecurrence ? "Yes" : "No"}</td>
                                    </tr>
                                   
                                </table>
                            </div>
                        </section>
                    </div>}
                    <div className={Styles.checklist_view_template_container}>
                        <div className={Styles.template_heading_contianer}>
                            {entryDetails?.image?.length ? <span onClick={setIsImagePreviewModal}>View Images</span> : <></>}
                            {entryDetails?.note?.length ? <span onClick={() => setIsNotePreviewModal(true)}>View Notes</span> :<></>}
                        </div>
                        <div className={Styles.checklist_view_template_table__container}>
                            {
                            
                            ((isEditEntry && checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) || (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY }) && (entryDetails?.logEntry?.status === CLONOS_GLOBAL_STATUS_SCHEDULED || entryDetails?.logEntry?.status === CLONOS_GLOBAL_STATUS_OVERDUE || entryDetails?.logEntry?.status === CLONOS_GLOBAL_STATUS_IN_PROGRESS))) ? <TemplatePreview
                                // isEdit={(entryDetails?.logEntry?.status === CLONOS_GLOBAL_STATUS_COMPLETED || checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) ? false : true}
                                isEdit={(entryDetails?.logEntry?.status === CLONOS_GLOBAL_STATUS_COMPLETED && !checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY })) ? false : true}
                                loading={updatedFilledEntryLoading}
                                attributes={manipulatedDataForTemplatePreview}
                                isFormula={serverResponse?.entryDetails?.logEntry?.data}
                                handleGetUpdatedDataSets={handleGetUpdatedDataSets}
                                handleGetInprogressDataSets={handleGetInprogressDataSets}
                            /> : manipulatedDataForTemplatePreview?.length > 0 ? <ClonosDataGrid
                                rows={manipulatedDataForTemplatePreview ? manipulatedDataForTemplatePreview : []}
                                columns={columns}
                                pageLimit={pagination.limit}
                                isEdit={false}
                                isDelete={false}
                                uniqueIdField="id"
                                paginationMode="client" 
                                loading={checklistEntryDetailsLoading}
                                checkboxSelection={false}
                            /> : <div style={{ height: "200px", width: "100%", display: 'flex', justifyContent: "center", alignItems: "center" }}>
                                <span style={{ fontSize: "1.25rem", fontWeight: "500" }}>No template added yet.</span></div>
                        }
                        </div>

                        
                    </div>

                </div>
            </Card >

            <Modal isOpen={isDownloadModal} closeModalMethod={setIsDownloadModal}>
                <ClonosExportOptions handleGetDetails={handleGetDetails} handleExportFile={handleExportFile} formats={["pdf", "xlsx"]} />
            </Modal>

            <Modal isOpen={isPreviewTemplateModal} closeModalMethod={setIsPreviewTemplateModal}>
                <div className={Styles.preview_container}>
                    <TemplatePreview
                        attributes={manipulatedDataForTemplatePreview}
                        isEdit={false}
                    />
                </div>
            </Modal>

            <Modal
                isOpen={isNotePreviewModal}
                closeModalMethod={setIsNotePreviewModal}
            >
                <div aria-label='view note'
                    className={Styles.view_note}>
                    <header className={Styles.vn_header}>
                        <span>Note</span>
                        <CloseIcon onClick={() => setIsNotePreviewModal(false)} />
                    </header>
                    <p>{entryDetails?.note}</p>
                </div>
            </Modal>

            <ClonosConfirmationBox // Approval request and request handler confirmation box.
                isOpen={isValidateConfirmationModal}
                confirmingMethod={() => {
                    if (handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER) {
                        handleApproveTheValidateRequest({ dispatch, checklistId: lcChecklistData?.id, requestId: validateRequestServerResponse[0]?.requestId, responseSetterMethod: setLcValues, uniqueKey: "approveLoading", payload: { status: "completed" }, setRefreshApi })
                    } else {
                        handleCreateValidateRequests({ dispatch, checklistId: lcChecklistData?.id, responseSetterMethod: setLcValues, uniqueKey: "validateLoading" })
                        setRefreshApi()
                    }
                    setIsValidateConfirmationModal(false)
                }}
                closeModalMethod={setIsValidateConfirmationModal}
                headerTitle="Sending for approval."
                message={handleLoggedInUser()?.role_id === CLONOS_GLOBAL_USER_TYPE_MANAGER ? "Are you sure, that you are approving this data entry?" : "Do you confirm that you are sending this checklist for further approval?"}
            />

         {/* delete log function  */}
            {/* <ClonosConfirmationBox // Checklist delete confirmation box.
                isOpen={confirmationDialogStates?.checklistDeleteState}
                confirmingMethod={async () => {
                    try {
                        const response = await handleDeleteChecklist({ dispatch, selectedRows: [lcChecklistData.id], isLocalUpdate: false }); // here it will return the response and based on the status we are restructing the user to redirect to the next page like if the status is note

                        if (response && (response.status === 200 || response.status === 201)) {
                            let interval = handleRedirectAfterEvent({ targetRoute: "/logs", timeout: 1000, navigate });
                            setLcIntervals({ ...lcIntervals, "deleteChecklist": interval });
                        }
                    } catch (error) {
                        console.error('Error during checklist deletion:', error);
                    } finally {
                        setConfirmationDialogStates({ ...confirmationDialogStates, ["checklistDeleteState"]: false });
                    }
                }}
                closeModalMethod={() => setConfirmationDialogStates({ ...confirmationDialogStates, ["checklistDeleteState"]: false })}
                headerTitle="Delete Log"
                message="Are you sure, You want to delete this log?"
            /> */}

            {/* <ClonosAlertBox 
                isOpen={confirmationDialogStates?.checklistDeleteState} 
                closeModalMethod={() => setConfirmationDialogStates({ ...confirmationDialogStates, ["checklistDeleteState"]: false })}
                headerTitle="Delete" 
                message="This feature is under development." 
                /> */}
                <ClonosConfirmationBox
                               isOpen={confirmationDialogStates.checklistDeleteState}
                               confirmingMethod={async () => {
                                   await handleDeleteLog({
                                   payload: [LOCATION?.state?.logId],
                                   setIsLoading: () =>
                                       setLcValues(prev => ({...prev,deleteLoading:!prev.deleteLoading})),
                                       next: () => {
                                           handleShowErrorAndWarning({
                                           dispatch,
                                           message: "Log deleted successfully!",
                                           type: "success",
                                           showTime: "5000"
                                           });
                                           navigate("/logs");
                                       }
                                   });
                               }}
                               loading={lcValues?.deleteLoading}
                               closeModalMethod={() => setConfirmationDialogStates(prev=>({...prev,checklistDeleteState: !prev.checklistDeleteState}))}
                               headerTitle="Delete Log"
                               message="Are you sure, You want to delete this Log?"
                               />

              <ImagePreviewModal 
                images={loadedImages} 
                loading={loadImagesLoading} 
                open={isImagePreviewModal}
                closeModalMethod={setIsImagePreviewModal}
                uploadOption={true}
                handleUploadImages={handleUploadImages}
                getUploadedDetails={(val) => {
                    // Update local state
                    setFormData(prev => ({
                    ...prev,
                    images: {
                        ...prev.images,
                        [selectedRowId]: val?.files
                    }
                    }));
                }}
                />

          {isLoading ? (
             <div style={{
                position: "fixed",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                zIndex: 1000
             }}>
                <ClonosSpinner />
             </div>
        ) : isReportPreviewModal && isReportPreviewModal?.url ? (
            <ClonosDocumentViewer
                file={isReportPreviewModal}
                isOpen={true}
                closeMethod={() => setIsReportPreviewModal(null)}
            />
        ) : null}


       {lcValues.showRecurrenceDetails ? (
          <ViewReportRecurranceDetailsModal
            data={serverResponse?.entryDetails?.logDetails}
            isOpen={lcValues.showRecurrenceDetails}
            closeMethod={() =>
              setLcValues((prev) => ({ ...prev, showRecurrenceDetails: false }))
            }
          />
        ) : (
          <></>
        )}


        </>
    );
};

export default React.memo(ChecklistView)