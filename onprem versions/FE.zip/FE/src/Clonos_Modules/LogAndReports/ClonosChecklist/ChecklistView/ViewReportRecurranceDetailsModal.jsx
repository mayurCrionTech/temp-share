import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import { getFormatAMPM, getFormatedDate, getFormattedTime, modifyString } from "../../../../utils/clonosCommon"
import Styles from './view-report-recurrance-details-modal.module.css'

export const ViewReportRecurranceDetailsModal = ({isOpen,closeMethod,data}) => {
    const getFormattedDateAndTime = (dateStr) => {
        if(!dateStr) return "-"
        const date = getFormatedDate(dateStr);
        const time = getFormatAMPM(dateStr);
        return date && time ? `${date} ${time}` : "-"
    }
 
    return <Modal isOpen={isOpen} closeModalMethod={() => closeMethod()}>
        <div className={Styles.container}>
             <div className={Styles.header}>
                <h4>Recurrence</h4>
                <CloseIcon onClick={() => closeMethod()}/>
             </div>
             <div className={Styles.section}>
                <div className={Styles.section_left}>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>Start Date & Time</h4>
                        <p className={Styles.field_val_}>{getFormattedDateAndTime(data?.startDateAndTime)}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>Recurrence</h4>
                        {/* <p className={Styles.field_val_}>{`Every ${data?.recurrenceDetails?.frequency} ${data?.recurrenceDetails?.timePeriod}`}</p> */}
                         {data?.recurrenceDetails?.frequency && data?.recurrenceDetails?.timePeriod
                            ? `Every ${data.recurrenceDetails.frequency} ${data.recurrenceDetails.timePeriod}`
                            : "-"}
                    </div>
                    {/* {
                        data?.assignees?.map((user) => {
                            return <div className={Styles.field_wrapper}>
                            <h4 className={Styles.field_name}>User Name</h4>
                            <p className={Styles.field_val_}>{user}</p>
                        </div>
                        })
                    } */}

                     <div className={Styles.field_wrapper}>
                    <h4 className={Styles.field_name}>User Name</h4>
                    <p className={Styles.field_val_}>
                        {data?.assignees?.join(", ")}
                    </p>
                    </div>
                   
                </div>
                <div className={Styles.section_right}>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>End Date & Time</h4>
                        <p className={Styles.field_val_}>{getFormattedDateAndTime(data?.endDateAndTime)}</p>
                    </div>
                    <div className={Styles.field_wrapper}>
                        <h4 className={Styles.field_name}>Repeat On</h4>
                        <p className={Styles.field_val_}>{data?.recurrenceDetails?.recurrOn ? modifyString(modifyString(data?.recurrenceDetails?.recurrOn,"spacecase"),"capitalize") : "-"}</p>
                    </div>
                </div>
             </div>
        </div>
    </Modal>
}
