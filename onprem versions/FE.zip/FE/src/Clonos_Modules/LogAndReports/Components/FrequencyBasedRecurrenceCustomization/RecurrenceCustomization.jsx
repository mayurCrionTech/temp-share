import React, { useEffect, useRef, useState } from 'react'
import Styles from "./RecurrenceCustomization.module.css"
import ClonosSelect from '../../../../components/CommonComponents/ClonosSelect/ClonosSelect'
import ClonosDaySelector from '../ClonosDaySelector/ClonosDaySelector'
import ClonosRadioAndCheckbox from '../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox'
import { convertISTToCustomFormat, getCurrentWeekOfMonth, getFormatedDate } from '../../../../utils/clonosCommon'
import MonthRecurrenceCustomization from '../MonthRecurrenceCustomization/MonthRecurrenceCustomization'
import { daysStaticData } from '../../../../Constants/StaticData'
import { CLONOS_GLOBAL_TIME_PERIOD_WEEK } from '../../../../Constants/Constant'
import Modal from '../../../../components/CommonComponents/Modal/Modal'
import useToggler from '../../../../CustomHooks/TogglerHook'
import CloseIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import { StaticDatePicker } from '@mui/x-date-pickers/StaticDatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs from 'dayjs';
import ClonosInput from '../../../../components/CommonComponents/ClonosInput/ClonosInput'
import useFieldsChecker from '../../../../CustomHooks/FieldsValidatorHook'


const RecurrenceCustomization = ({ timePeriod, handleGetValues, handleGetErrorActivatorInformation, formData, type }) => {
   
    const [customDateAlert, setCustomDateAlert] = useToggler();
    const [lcValues, setLcValues] = useState({});
    const { handleRemoveField } = useFieldsChecker({ isChildren: true });

    const [options, setOptions] = useState([])

    

    const lcHangleGetValues = (props) => {
        handleGetValues({ ...props, ["componentsName"]: type, timePeriod });
    }

    useEffect(() => {
        setOptions([
            {
                label: `Monthly on the ${getCurrentWeekOfMonth().charAt(0).toUpperCase() + getCurrentWeekOfMonth().substring(1)} ${daysStaticData?.map(item => item.value)[new Date().getDay() - 1]}`,
                value: `monthlyWeekday_${timePeriod?.toLowerCase()}_${getCurrentWeekOfMonth()}_${daysStaticData?.map(item => item.uniqueKey)[(new Date().getDay()) - 1]}`,
                disabled: false,
                uniqueKey: 1
            },
            {
                label: `Monthly on Day ${formData?.startDate ? formData?.startDate?.split("T")[0]?.split("-")[2] : new Date().getDate()}`,
                value: `monthlyDay_monthly_${formData?.startDate ? formData?.startDate?.split("T")[0]?.split("-")[2] : new Date().getDate()}`,
                disabled: false,
                uniqueKey: 2
            },
            {
                label: `Custom`,
                value: "custom",
                fn: setCustomDateAlert,
                uniqueKey: 3
            },
        ])
    }, [timePeriod, formData?.startDate])

    useEffect(() => {
        if (lcValues?.custom) {
            setOptions(prev => {
                return prev?.map(item => {
                  
                    if (item.value === "custom") {
                        return {
                            ...item, "label": `Custom ${lcValues?.custom ? `(${getFormatedDate(lcValues?.custom)})` : ""}`,
                        }
                    }
                    else {
                        return item
                    }
                })
            })
        }
    }, [lcValues])

    useEffect(() => {
        if (timePeriod) {
            const keysNeedToDelete = {
                Hour: ["occursOnSpecificWeekDay"],
                Day: ["occursOnSpecificWeekDay"],
                Week: ["recurOn"],
                Month: ["recurOn"],
            };
            handleRemoveField(keysNeedToDelete[timePeriod]);
        }
    }, [timePeriod]);
  
    return (
        <>
            {(timePeriod === "Hour" || timePeriod === "Day") && <div className={Styles.time_period_hourAndDay_container} >
                <ClonosSelect
                    tabIndex={12}
                    type="select"
                    label="Recur On:"
                    isMandatory={true}
                    isLabel={true}
                    uniqueKey="recurOn"
                    placeholder="Select"
                    options={
                        [{ label: "All Days", value: "allDays" },
                        { label: "Only on Weekdays", value: "onlyOnWeekDays" },
                        { label: "Custom", value: "custom" }].map((type) => ({
                            label: type?.label,
                            value: type.value,
                            isNeeded: type?.value === "custom" ? false : true //Removed custom option of kaleshwari project
                        }))}
                    handleGetValues={lcHangleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                />
            </div>
            }
            {
                timePeriod === CLONOS_GLOBAL_TIME_PERIOD_WEEK && <ClonosRadioAndCheckbox
                    isLabel={true}
                    type="checkbox"
                    label="Custom - Occur on These Week Days"
                    uniqueKey="isOccurOnTheseWeekDays"
                    handleGetValues={(props) => {
                        if (!props?.updatedValue) {
                            handleRemoveField(["occursOnSpecificWeekDay"]);
                        }
                        handleGetValues(props)
                    }}
                />
            }
            {
                (
                    formData?.[type]?.Hour?.recurOn?.value === "custom" ||
                    formData?.[type]?.Day?.recurOn?.value === "custom" ||
                    (timePeriod === "Week" && formData?.isOccurOnTheseWeekDays)
                ) && <ClonosDaySelector
                    uniqueKey="occursOnSpecificWeekDay"
                    label={timePeriod === CLONOS_GLOBAL_TIME_PERIOD_WEEK ? null : "Custom On"}
                    type={"customDay"}
                    handleGetValues={lcHangleGetValues}
                    isMandatory={true}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                />
            }
            {
                timePeriod === "Month" && <div className={Styles.time_period_month}>
                    {
                        // <ClonosSelect
                        //     optionType="radio"
                        //     type="select"
                        //     label="Specific Days"
                        //     isMandatory={false}
                        //     isLabel={true}
                        //     uniqueKey="dynamicDays"
                        //     placeholder="Select"
                        //     options={
                        //         options.map((type) => ({
                        //             label: type?.label,
                        //             value: type.value,
                        //             disabled: type?.disabled,
                        //             isNeeded: true,
                        //             fn: type?.fn ? type.fn : null,
                        //             uniqueKey: type.uniqueKey,
                        //             isChecked: false
                        //         }))}
                        //     handleGetValues={lcHangleGetValues}
                        //     handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        // />
                        <ClonosInput
                            readOnly={true}
                            defaultValue={`Monthly on Day ${formData?.startDate ? formData?.startDate?.split("T")[0]?.split("-")[2] : new Date().getDate()}`}
                            value={`Monthly on Day ${formData?.startDate ? formData?.startDate?.split("T")[0]?.split("-")[2] : new Date().getDate()}`}
                        />
                    }
                </div>
            }
            <Modal
                closeModalMethod={setCustomDateAlert}
                isOpen={customDateAlert}>
                <div
                    className={Styles.custom_date_selector}
                >
                    <header className={Styles.cds_header}>
                        <span aria-label='spacer'></span>
                        <span>Custom Date Selector</span>
                        <CloseIcon onClick={setCustomDateAlert} />
                    </header>
                    <section>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <StaticDatePicker
                                defaultValue={dayjs(new Date()) ? dayjs(new Date()) : ""}
                                onChange={prop => console.log("propsText", prop)}
                                minDate={dayjs(formData?.startDate)}
                                maxDate={dayjs(formData?.endDate ? formData?.endDate : null)}
                                onAccept={(props) => {
                                    const formatedDate = convertISTToCustomFormat(props.$d);
                                    lcHangleGetValues({ uniqueKey: "custom", updatedValue: formatedDate })
                                    setLcValues({ ...lcValues, "custom": formatedDate })
                                    setCustomDateAlert();
                                }}
                            />
                        </LocalizationProvider>
                    </section>
                    <footer></footer>
                </div>
            </Modal>
        </>
    )
}

export default RecurrenceCustomization