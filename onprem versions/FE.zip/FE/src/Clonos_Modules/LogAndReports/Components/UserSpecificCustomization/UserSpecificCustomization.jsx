import React, { useState } from 'react'
import Styles from "./UserSpecificCustomization.module.css"
import { Tooltip } from '@mui/material'
import MonthRecurrenceCustomization from '../MonthRecurrenceCustomization/MonthRecurrenceCustomization'
import { calculateDateDifference, handleShowErrorAndWarning, modifyString } from '../../../../utils/clonosCommon'
import ClonosInput from '../../../../components/CommonComponents/ClonosInput/ClonosInput'
import HourDayWeekRecurrenceCustomization from '../HourDayWeekRecurrenceCustomization/HourDayWeekRecurrenceCustomization'
import { handleKeyGenerator } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods'

const UserSpecificCustomization = (
    { assignee,
        formData,
        timePeriod,
        handleGetValues,
        needToDisable,
        handleUniqueRecurrenceCombinations,
        handleGetErrorActivatorInformation,
    }
) => {

    const handleCreateUniqueKey = (errorHandlers, currentKey) => {
       
        let flag = true
        if (timePeriod === "Hour" || timePeriod === "Day" || timePeriod === "Week" || timePeriod === "Month") {
            handleUniqueRecurrenceCombinations(uniqueKeyCombinations => {
                // Unique Combination check
             
                if (uniqueKeyCombinations?.[currentKey] === undefined) {
                    return { ...uniqueKeyCombinations, [currentKey]: 0 }
                } else {
                    let lcUniqueRecurrenceCombinations = []
                    Object.values(formData?.userSpecificCustomization)?.map(lcKey => {
                        const element = lcKey[timePeriod + "Recurrence"];
                       
                        lcUniqueRecurrenceCombinations.push(...element);
                    })
                    lcUniqueRecurrenceCombinations?.forEach(element => {
                        let lcKey = "";
                        if (element?.shiftTiming) {
                            lcKey = handleKeyGenerator({ shiftTiming: element.shiftTiming })
                        }
                      
                        if (lcKey + assignee?.id === currentKey) {
                            errorHandlers && errorHandlers.errorSetterMethod("Please use different combination!")
                            errorHandlers && errorHandlers.errorActivatorMethod(true);
                            errorHandlers && errorHandlers.resetMethod();
                            flag = false
                        };
                    });
                    return uniqueKeyCombinations;
                };
            });
        }
        return flag;
    }


    const lcHandleGetValues = (props) => {
   
        if (!handleCreateUniqueKey(props?.errorHandlers, props?.currentKey)) return
        handleGetValues({ ...props, ["userId"]: assignee?.id });
    };
    return (
        <>
            <div key={assignee.id} aria-label="selected assignee container" className={Styles.main_container}>
                <div aria-label="user details container" className={Styles.user_details_container}>
                    <label>User Name</label>
                    <div aria-label="user details" className={Styles.user_details}>
                        <h6 className={Styles.user_name} aria-label="user name">{assignee.name}</h6>
                        <div className={`${Styles.user_id_split_container}`}>
                            <span className={Styles.user_user_id_label}>User Id</span>
                            <Tooltip title={assignee?.id || ""}>
                                <span aria-label="user id" className={Styles.user_id}>{assignee.id}</span>
                            </Tooltip>
                        </div>
                    </div>
                </div>
                {
                    (timePeriod === "Hour" || timePeriod === "Day" || timePeriod === "Week" || timePeriod === "Month") && <HourDayWeekRecurrenceCustomization
                        timePeriod={timePeriod}
                        userId={assignee?.id}
                        handleGetValues={lcHandleGetValues}
                        type="userSpecificCustomization"
                        needToDisable={needToDisable || []}
                        formData={formData}

                    />
                }
                {
                    formData?.basedOnTimePeriodRecurrence?.[timePeriod]?.isSpecificDays && <ClonosInput
                        disabled={true}
                        value={formData?.basedOnTimePeriodRecurrence?.[timePeriod]?.specificDays?.split("_")?.map(((item, index) => {
                            if (index === 0) {
                                return modifyString(item, "pascal") + "ly" + " on";
                            }
                            else {
                                return modifyString(item, "pascal");
                            }
                        })).join(" ")}
                    />
                }
                {
                    timePeriod === "Year" && <div className={Styles.years}>
                        <MonthRecurrenceCustomization
                            isLabel={false}
                            uniqueKey="year"
                            isNumbering={true}
                            timePeriod={timePeriod}
                            type="userSpecificCustomization"
                            handleGetValues={lcHandleGetValues}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                            numberingLength={calculateDateDifference(formData?.startDate, formData?.endDate)?.years}
                        />
                    </div>
                }

            </div>

        </>
    )
}

export default UserSpecificCustomization