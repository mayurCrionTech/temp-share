import React, { useEffect, useState } from 'react';
import Styles from "./ClonosDaySelector.module.css";
import { generateUniqueId } from '../../../../utils/clonosCommon';
import { CLONOS_GLOBAL_COLOUR_BLUE, CLONOS_GLOBAL_COLOUR_RED, CLONOS_GLOBAL_COLOUR_WHITE, CLONOS_GLOBAL_DISABLED_COLOUR_BACKGROUND_DARK, CLONOS_GLOBAL_DISABLED_COLOUR_BACKGROUND_LIGHT, CLONOS_GLOBAL_ERROR_HANDLING_SIZE, CLONOS_GLOBAL_SPECIFIC_DAY_FRIDAY, CLONOS_GLOBAL_SPECIFIC_DAY_MONDAY, CLONOS_GLOBAL_SPECIFIC_DAY_SATURDAY, CLONOS_GLOBAL_SPECIFIC_DAY_SUNDAY, CLONOS_GLOBAL_SPECIFIC_DAY_THURSDAY, CLONOS_GLOBAL_SPECIFIC_DAY_TUESDAY, CLONOS_GLOBAL_SPECIFIC_DAY_WEDNESDAY } from '../../../../Constants/Constant';
import { ErrorSVGCom } from '../../../../assets/svg/ErrorHandling';

/**
 * A reusable component for selecting days of the week.
 * @param {Object} props - Component props
 * @param {string} props.label - The label for the day selector
 * @param {Object} props.labelStyle - Additional styles for the label
 * @param {boolean} props.isMandatory - Flag to indicate if the field is mandatory
 * @param {string} props.uniqueKey - Unique identifier for the component
 * @param {string} props.type - Type of the day selector
 * @param {string[]} props.defaultValue - Default selected days
 * @param {array[]} props.needToDisable - For disable some days
 * @param {Function} props.handleGetValues - Function to handle selected values
 * @param {Function} props.handleGetErrorActivatorInformation - Function to handle error activation information
 * @returns {JSX.Element} Day selector component
 */
const ClonosDaySelector = ({
    label,
    labelStyle,
    isMandatory,
    uniqueKey,
    multiSelect = true,
    type,
    defaultValue,
    needToDisable,
    indexUniqueKey,
    handleGetValues,
    handleGetErrorActivatorInformation
}) => {
    // State to manage static days data
    const [staticDaysData, setStaticDaysData] = useState({
        monday: { "name": "M", "isActive": false, uniqueKey: CLONOS_GLOBAL_SPECIFIC_DAY_MONDAY },
        tuesday: { "name": "T", "isActive": false, uniqueKey: CLONOS_GLOBAL_SPECIFIC_DAY_TUESDAY },
        wednesday: { "name": "W", "isActive": false, uniqueKey: CLONOS_GLOBAL_SPECIFIC_DAY_WEDNESDAY },
        thursday: { "name": "T", "isActive": false, uniqueKey: CLONOS_GLOBAL_SPECIFIC_DAY_THURSDAY },
        friday: { "name": "F", "isActive": false, uniqueKey: CLONOS_GLOBAL_SPECIFIC_DAY_FRIDAY },
        saturday: { "name": "S", "isActive": false, uniqueKey: CLONOS_GLOBAL_SPECIFIC_DAY_SATURDAY },
        sunday: { "name": "S", "isActive": false, uniqueKey: CLONOS_GLOBAL_SPECIFIC_DAY_SUNDAY }
    });

    

    // State to manage error message
    const [lcErrorMessage, setLcErrorMessage] = useState(`Please fill ${label ? label.toLowerCase() : "this"} field!`);
    const [showErrorMessage, setShowErrorMessage] = useState(false);
    const [lcValue, setLcValue] = useState([]);


    // Effect to handle default values and error activation
    useEffect(() => {
        if (defaultValue) {
            const lcStaticDaysData = { ...staticDaysData };
            defaultValue.forEach(item => {
                lcStaticDaysData[item] = { ...staticDaysData[item], ["isActive"]: true };
            });
            setStaticDaysData(lcStaticDaysData);
        }

        if (needToDisable) {
            const lcStaticDaysData = { ...staticDaysData };
            for (const key in lcStaticDaysData) {
                const element = lcStaticDaysData[key];
                lcStaticDaysData[key] = { ...element, ["disabled"]: needToDisable.indexOf(key) > -1 ? true : false }
            }
           
            setStaticDaysData(lcStaticDaysData);
        }

        handleGetErrorActivatorInformation && isMandatory && handleGetErrorActivatorInformation(
            {
                uniqueKey,
                indexUniqueKey,
                value: Array.isArray(defaultValue) && defaultValue.length > 0,
                type,
                errorActivatorMethod: setShowErrorMessage,
                errorSetterMethod: setLcErrorMessage
            });
    }, [defaultValue, needToDisable?.length]);

    // Function to handle day selection change
    const handleChange = (key) => {
        setStaticDaysData(prev => {
            let updatedValue = { ...prev, [key]: { ...prev[key], "isActive": !prev[key].isActive } };

            let selectedDays = [];
            for (const lcKey in updatedValue) {
                const element = updatedValue[lcKey];
                if (element.isActive) {
                    selectedDays.push(element);
                }
                if (!multiSelect && lcKey !== key) {
                    updatedValue[lcKey].isActive = false;
                }
            }
            setLcValue(selectedDays);
            setShowErrorMessage(!selectedDays.length);
            handleGetValues && handleGetValues({ type, uniqueKey,indexUniqueKey, updatedValue: selectedDays });
            return updatedValue;
        });
    };

    return (
        <div className={Styles.main_container}>
            {label && <label style={{ ...(labelStyle || {}) }}>{label} {isMandatory && <sup className={Styles.clonos_input_isMandatory}>*</sup>}</label>}
            <div className={Styles.day_container}>
                {Object.keys(staticDaysData).map(key => {
                    const item = staticDaysData[key];
                    return (
                        <div
                            style={item.isActive ? { background: CLONOS_GLOBAL_COLOUR_BLUE, color: CLONOS_GLOBAL_COLOUR_WHITE } : { ...item?.disabled ? { backgroundColor: CLONOS_GLOBAL_DISABLED_COLOUR_BACKGROUND_LIGHT, pointerEvents: "none" } : {} }}
                            onClick={() => handleChange(item.uniqueKey)}
                            className={Styles.day_item}
                            key={generateUniqueId(5)}>
                            <span>{item.name}</span>
                        </div>
                    );
                })}
            </div>
            {showErrorMessage && !lcValue.length && <span style={{ color: CLONOS_GLOBAL_COLOUR_RED }} className={Styles.error_container}><ErrorSVGCom size={CLONOS_GLOBAL_ERROR_HANDLING_SIZE} color={CLONOS_GLOBAL_COLOUR_RED} /> {lcErrorMessage}</span>}
        </div>
    );
};

export default ClonosDaySelector;
