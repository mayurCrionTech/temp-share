
import React, { useEffect, useState } from 'react'
import { CLONOS_GLOBAL_COLOUR_BLUE_HOVER } from '../../../../Constants/Constant'
import Styles from "./MonthRecurrenceCustomization.module.css"
import ClonosSelect from '../../../../components/CommonComponents/ClonosSelect/ClonosSelect';
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button';
import CloseIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon';
import { generateUniqueId, hasItem } from '../../../../utils/clonosCommon';
import useFieldsChecker from '../../../../CustomHooks/FieldsValidatorHook';


const lcNumberingStatic = {
    1: "first",
    2: "second",
    3: "third",
    4: "fourth",
    5: "fifth",
    6: "sixth",
    7: "seventh",
    8: "eighth",
    9: "nineth",
    10: "tenth",
}


const MonthRecurrenceCustomization = ({
    uniqueKey = "",
    timePeriod,
    type,
    handleGetValues,
    isNumbering,
    isSpecificDay,
    numberingLength,
    needToDisableSpecificDays,
    needToDisableSpecificNumbering,
    isLabel }) => {



    const [lcValue, setLcValue] = useState([{ id: generateUniqueId(5) }]);

    const [lcNumbering, setLcNumbering] = useState([]);
    const {
        isClear,
        primaryObject,
        handleGetErrorActivatorInformation,
        handlePrimaryObjectModifier,
        handleSubmit,
        handleRemoveField
    } = useFieldsChecker({ isIndexKey: true, hookUniqueKey: uniqueKey });


    const lcHandleGetValues = (props, index) => {
  
        setLcValue(prev => {
            let elementInstance = { ...prev[index] };
          
            elementInstance[props.uniqueKey] = props?.updatedValue?.value;
    

            const updatedState = (prev || []).map((item, lc_index) => {
                if (lc_index === index) {
                    return elementInstance;
                }
                return item;
            });

    
            handlePrimaryObjectModifier({ response: updatedState, indexUniqueKey: props.indexUniqueKey });
            handleGetValues({ uniqueKey: uniqueKey ? uniqueKey : props.uniqueKey, updatedValue: updatedState, type });
            return updatedState;
        })
    }

    useEffect(() => {
        if (numberingLength) {
            const numberingState = (new Array((numberingLength || 0)).fill(0)).map((_, index) => {
                return {
                    label: lcNumberingStatic[index + 1].charAt(0).toUpperCase() + lcNumberingStatic[index + 1].substring(1),
                    value: lcNumberingStatic[index + 1]
                }
            });
            setLcNumbering(numberingState);
        }
    }, [numberingLength])

    return (
        <>
            <div className={Styles.month_container} aria-label='month container'>
                <div
                    className={Styles.items_container}
                    aria-label='items_container'
                >
                    {
                        (lcValue || []).map((item, index) => {
                            return <div
                                key={item.id}
                                className={Styles.split_common}
                            >
                                {isNumbering && <ClonosSelect
                                    type="select"
                                    label="Choose Week"
                                    isMandatory={true}
                                    isLabel={isLabel}
                                    timePeriod={timePeriod}
                                    uniqueKey={`which${(timePeriod === "Hour" || timePeriod === "Day" || timePeriod === "Week" || timePeriod === "Month") ? "Week" : "Year"}`}
                                    indexUniqueKey={`${uniqueKey}Which${(timePeriod === "Hour" || timePeriod === "Day" || timePeriod === "Week" || timePeriod === "Month") ? "Week" : "Year"}_${index}`}
                                    placeholder="Select"
                                    options={
                                        (numberingLength ? lcNumbering : [
                                            { label: "First", value: "first", disabled: needToDisableSpecificNumbering?.length ? !hasItem(needToDisableSpecificNumbering, 'first') : false },
                                            { label: "Second", value: "second", disabled: needToDisableSpecificNumbering?.length ? !hasItem(needToDisableSpecificNumbering, 'second') : false },
                                            { label: "Third", value: "third", disabled: needToDisableSpecificNumbering?.length ? !hasItem(needToDisableSpecificNumbering, 'third') : false },
                                            { label: "Fourth", value: "fourth", disabled: needToDisableSpecificNumbering?.length ? !hasItem(needToDisableSpecificNumbering, 'fourth') : false },
                                            { label: "Fifth", value: "fifth", disabled: needToDisableSpecificNumbering?.length ? !hasItem(needToDisableSpecificNumbering, 'fifth') : false },]).map((type) => ({
                                                label: type?.label,
                                                value: type?.value,
                                                isNeeded: true,
                                                disabled: type?.disabled
                                            }))}
                                    handleGetValues={(props) => lcHandleGetValues(props, index)}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />}
                                {isSpecificDay && <ClonosSelect
                                    type="select"
                                    label="Choose Day"
                                    isMandatory={true}
                                    isLabel={isLabel}
                                    uniqueKey="specificDay"
                                    indexUniqueKey={`${uniqueKey}SpecificDay_${index}`}
                                    placeholder="Select"
                                    options={
                                        [{ label: "Monday", value: "monday", disabled: needToDisableSpecificDays?.length ? !hasItem(needToDisableSpecificDays, 'monday') : false },
                                        { label: "Tuesday", value: "tuesday", disabled: needToDisableSpecificDays?.length ? !hasItem(needToDisableSpecificDays, 'tuesday') : false },
                                        { label: "Wednesday", value: "wednesday", disabled: needToDisableSpecificDays?.length ? !hasItem(needToDisableSpecificDays, 'wednesday') : false },
                                        { label: "Thusday", value: "thusday", disabled: needToDisableSpecificDays?.length ? !hasItem(needToDisableSpecificDays, 'thusday') : false },
                                        { label: "Friday", value: "friday", disabled: needToDisableSpecificDays?.length ? !hasItem(needToDisableSpecificDays, 'friday') : false },
                                        { label: "Saturday", value: "saturday", disabled: needToDisableSpecificDays?.length ? !hasItem(needToDisableSpecificDays, 'saturday') : false },
                                        { label: "Sunday", value: "sunday", disabled: needToDisableSpecificDays?.length ? !hasItem(needToDisableSpecificDays, 'sunday') : false }].map((type) => ({
                                            label: type?.label,
                                            value: type.value,
                                            isNeeded: true,
                                            disabled: type?.disabled
                                        }))}
                                    handleGetValues={(props) => lcHandleGetValues(props, index)}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />}
                                {
                                    lcValue?.length > 1 && <ClonosButton style={{ border: "none" }}><CloseIcon onClick={() => {
                                        setLcValue(prev => {
                                            if (lcValue.length === 1) return prev;
                                            return (prev || []).filter((_, cl_index) => cl_index !== index)
                                        });
                                        handleRemoveField([`specificDay_${index}`, `which${(timePeriod === "Hour" || timePeriod === "Day" || timePeriod === "Week" || timePeriod === "Month") ? "Week" : "Year"}_${index}`])
                                    }} /></ClonosButton>
                                }
                            </div>
                        })
                    }
                </div>
                <ClonosButton
                    onClick={() => setLcValue([...lcValue, { id: generateUniqueId(5) }])}
                    style={{ border: "none", color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER, width: "fit-content" }}
                > + Add Recurrence</ClonosButton>
            </div>
        </>
    )
}

export default MonthRecurrenceCustomization