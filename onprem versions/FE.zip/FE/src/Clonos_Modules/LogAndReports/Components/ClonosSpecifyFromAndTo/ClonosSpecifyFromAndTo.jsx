import React, { useCallback, useEffect, useState } from 'react'
import Styles from "./ClonosSpecifyFromAndTo.module.css"
import useToggler from '../../../../CustomHooks/TogglerHook';
import { CLONOS_GLOBAL_COLOUR_BLUE, CLONOS_GLOBAL_COLOUR_RED, CLONOS_GLOBAL_COLOUR_WHITE, CLONOS_GLOBAL_ERROR_HANDLING_SIZE } from '../../../../Constants/Constant';
import { ErrorSVGCom } from '../../../../assets/svg/ErrorHandling';
import { handleShowErrorAndWarning } from '../../../../utils/clonosCommon';
import { useDispatch } from 'react-redux';


const activeCSS = {
    backgroundColor: "transparant",
    color: CLONOS_GLOBAL_COLOUR_WHITE,
    pointerEvents: "none",
}

/**
 * A component that allows the user to specify a time range with hours, minutes, and period (AM/PM).
 *
 * @param {Object} props - The component props.
 * @param {string} props.heading - The heading text for the component.
 * @param {string} props.uniqueKey - A unique key to identify the component instance.
 * @param {Function} props.handleGetValues - A callback function to handle the updated time values.
 * @param {string} props.type - The type of the component.
 * @param {boolean} props.isMandatory - Indicates whether the component is mandatory or not.
 * @param {string} props.errorMessage - The error message to display when the component is mandatory and no value is provided.
 * @param {Object} props.defaultValue - The default value for the component.
 * @param {Function} props.handleGetErrorActivatorInformation - A callback function to handle error activator information.
 *
 * @returns {JSX.Element} The rendered component.
 */

const ClonosSpecifyFromAndTo = ({
    heading,
    uniqueKey,
    handleGetValues,
    type,
    isMandatory,
    errorMessage,
    defaultValue,
    minuteMin,
    minuteMax,
    hourMin,
    hourMax,
    handleGetErrorActivatorInformation
}) => {
    const [lcValue, setLcValue] = useState({});
 
    const [showErrorMessage, setShowErrorMessage] = useState(false);
    const [lcErrorMessage, setLcErrorMessage] = useState(errorMessage);
    const [latestEvent, setLatestEvent] = useState(null);
    const dispatch = useDispatch();

   



    const lcHandleGetValues = (e) => {
        if (isMandatory && e?.target?.value.trim() === '') {
            setLcErrorMessage(errorMessage || `Please fill ${heading ? heading?.toLowerCase() : "this"} field!`)
            setLcValue(prev => {
                const updatedValue = { ...prev, [e.target.name]: "" }
                handleGetValues && handleGetValues({ uniqueKey, updatedValue, type });
                return updatedValue;
            })
            setShowErrorMessage(true);
        } else {
            setShowErrorMessage(false);
            const value = e.target.value;
            let flag = true;

            if (hourMin || hourMax || minuteMax || minuteMin) {
                let min = e.target.name === "hour" ? hourMin === "00" ? 0 : hourMin : minuteMin === "00" ? 0 : minuteMin;
                let max = e.target.name === "hour" ? hourMax === "00" ? 0 : hourMax : minuteMax === "00" ? 0 : minuteMax;
                if (Number(value) < min || Number(value) > max) {
                    handleShowErrorAndWarning({
                        dispatch,
                        type: "warning",
                        showTime: 5000,
                        message: `Please enter a valid ${e.target.name === "hour" ? "hour" : "minute"} between ${min} and ${max}.`
                    })

                    setLcValue(prev => {
                        const updatedValue = { ...prev, [e.target.name]: "" }
                        handleGetValues && handleGetValues({ uniqueKey, updatedValue, type });
                        return updatedValue;
                    })
                    flag = false;
                }
            }
            if ((Number(value) > 23 && e.target.name === "hour") || (Number(value) > 59 && e.target.name === "minute")) {
                setLcValue(prev => {
                    const updatedValue = { ...prev, [e.target.name]: "" }
                    handleGetValues && handleGetValues({ uniqueKey, updatedValue, type });
                    return updatedValue;
                })
                flag = false;
            }
            if (flag) {
                setLcValue(prev => {
                    const updatedValue = e.target.name === "minute" ? { ...prev, [e.target.name]: value } :
                        {
                            ...prev, ["hour"]: value.length === 1 ? 0 + value : value,
                            ["minute"]: lcValue?.minute ? lcValue?.minute?.length === 1 ? 0 + lcValue?.minute : lcValue?.minute : "00"
                        };
                    
                    const localUpdatedValue = { ...prev, [e.target.name]: value }
                    handleGetValues && handleGetValues({ uniqueKey, updatedValue, type });
                    return localUpdatedValue;
                })
            }
        }

    }


    // Create a debounced version of lcHandleGetValues
    const debouncedHandleGetValues = debounce((event, flag) => {
        lcHandleGetValues(event, flag);
    }, 500);

    // Immediate update for input value
    const handleChange = (event) => {
        const { name, value } = event.target;
        setLcValue((prevValue) => ({
            ...prevValue,
            [name]: value
        }));

        // Store the latest event
        setLatestEvent(event);
    };

    // Effect to call the debounced function with the latest event
    useEffect(() => {
        if (latestEvent) {
            debouncedHandleGetValues(latestEvent, true);
        }
    }, [latestEvent]);


    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            const context = this;
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(context, args), wait);
        };
    }



    useEffect(() => {
        if (isMandatory) {
            if (!defaultValue) {
                setLcErrorMessage(errorMessage || `Please fill ${heading ? heading?.toLowerCase() : "this"} field!`)
            };
        };
        handleGetErrorActivatorInformation && isMandatory && handleGetErrorActivatorInformation(
            {
                uniqueKey,
                value: (typeof (defaultValue) === "string" || typeof (defaultValue) === "number" || typeof (defaultValue) === "boolean" || (Array.isArray(defaultValue) === "array" || defaultValue?.length > 0)) ? true : false,
                type,
                errorActivatorMethod: setShowErrorMessage,
                errorSetterMethod: setLcErrorMessage
            }
        )
    }, [])


    return (
        <div aria-label='Time container' className={Styles.main_container}>
            {heading && (
                <label >
                    {heading} {isMandatory && <sup className="isMandatory_common">*</sup>}
                </label>
            )}
            <div className={Styles.body}>
                <div className={Styles.time_setter}>
                    <input
                        value={lcValue?.hour}
                        tabIndex={1}
                        name="hour"
                        type='number'
                        placeholder='00'
                        max="24"
                        // onChange={(e) => debouncedHandleGetValues(e, true)}
                        onChange={handleChange}
                        onBlur={(e) => {
                            isMandatory && lcHandleGetValues(e);
                        }}
                        onKeyDown={(e) => {
                            if (e.keyCode === 9) {
                                const secondInput = document.getElementById('minutes')
                                secondInput.focus();
                                e.preventDefault();
                            }
                        }}
                    />
                    <span>:</span>
                    <input
                        id='minutes'
                        tabIndex={2}
                        value={lcValue?.minute}
                        name='minute'
                        type='number'
                        placeholder='00'
                        max="60"
                        // onChange={(e) => debouncedHandleGetValues(e, true)}
                        onChange={handleChange}
                    />
                </div>
                {/* <div
                    aria-level="period"
                    className={Styles.period}
                >
                    <div onClick={() => {
                        lcHandleGetValues(null, false, "AM");
                        setToggler();
                    }} className={Styles.period_item} style={toggler ? activeCSS : {}}>AM</div>
                    <div onClick={() => {
                        lcHandleGetValues(null, false, "PM");
                        setToggler();
                    }} className={Styles.period_item} style={!toggler ? activeCSS : {}}>PM</div>
                    <div className={Styles.switcher} style={toggler ? {} : { left: "3.375rem" }}></div>
                </div> */}
            </div>
            {showErrorMessage && <span style={{ color: CLONOS_GLOBAL_COLOUR_RED }} className="error_message_container">
                <ErrorSVGCom size={CLONOS_GLOBAL_ERROR_HANDLING_SIZE} color={CLONOS_GLOBAL_COLOUR_RED} /> {lcErrorMessage}
            </span>}
        </div>
    )
}

export default ClonosSpecifyFromAndTo