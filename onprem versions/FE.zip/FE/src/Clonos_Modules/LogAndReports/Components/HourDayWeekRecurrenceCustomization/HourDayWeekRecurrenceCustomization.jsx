import React, { useEffect, useState } from 'react'
import useFieldsChecker from '../../../../CustomHooks/FieldsValidatorHook';
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button';
import { CLONOS_GLOBAL_COLOUR_BLUE_HOVER } from '../../../../Constants/Constant';
import { generateUniqueId, getFormatedDate } from '../../../../utils/clonosCommon';
import ChildStyles from "./HourDayWeekRecurrenceCustomization.module.css"
import ClonosSelect from '../../../../components/CommonComponents/ClonosSelect/ClonosSelect';
import ClonosDaySelector from '../ClonosDaySelector/ClonosDaySelector';
import { shiftsStaticData } from '../../../../Constants/StaticData';
import CloseIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon';
import RemoveIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/RemoveIcon';
import Modal from '../../../../components/CommonComponents/Modal/Modal';
import useToggler from '../../../../CustomHooks/TogglerHook';
import ClonosSpecifyFromAndTo from '../ClonosSpecifyFromAndTo/ClonosSpecifyFromAndTo';
import { handleKeyGenerator } from '../../../../utils/ChecklistAndReportsMethods/ChecklistMethods';

const HourDayWeekRecurrenceCustomization = ({
    type,
    uniqueKey = "",
    timePeriod,
    needToDisable,
    handleGetValues,
    userId,
    formData
}) => {

    const [lcOptions, setLcOptions] = useState([{ id: generateUniqueId(5) }]);
  
    const [customRangeModal, setCustomRangeModal] = useToggler();
    const [lcValues, setLcValues] = useState({});
 
    const [lcShifts, setLcShifts] = useState({
        1: [...shiftsStaticData?.map((item, index) => {
            return { ...item, "uniqueKey": index + 1 }
        }), { uniqueKey: shiftsStaticData.length + 1, label: "Custom", type: "custom", fn: setCustomRangeModal }]
    });


    const {
        handleGetErrorActivatorInformation,
        handlePrimaryObjectModifier,
        primaryObject,
        handleRemoveField,
        handleGetUpdatedPrimaryObject
    } = useFieldsChecker({ isIndexKey: true, hookUniqueKey: uniqueKey, isChildren: true });


    const lcHandleGetValues = (props, index) => {
    
        setLcValues({ ...lcValues, ["clickedIndex"]: index + 1, errorHandlers: primaryObject[props.indexUniqueKey] })
        setLcOptions(prev => {
            let elementInstance = { ...prev[index] };
            if (Array.isArray(props.updatedValue)) {
                elementInstance[props.uniqueKey] = props?.updatedValue?.map(item => item.uniqueKey);
            } else {
                elementInstance[props.uniqueKey] = { label: props?.updatedValue?.label, value: props?.updatedValue?.value };
            };
          
            let key = "";
            const updatedState = (prev || []).map((item, lc_index) => {
                if (lc_index === index) {
                    if ((props?.updatedValue) || (item?.shiftTiming && props?.updatedValue?.length) || (item?.shiftTiming)) {
                        key = handleKeyGenerator({ shiftTiming: elementInstance?.shiftTiming })
                    }
               
                    return elementInstance;
                }
                return item;
            });
        

            handlePrimaryObjectModifier({ response: updatedState, indexUniqueKey: props?.indexUniqueKey });
            (props?.updatedValue?.value !== "custom" && handleGetValues) && handleGetValues(
                {
                    uniqueKey: timePeriod + "Recurrence",
                    updatedValue: updatedState,
                    type,
                    errorHandlers: handleGetUpdatedPrimaryObject()[props?.indexUniqueKey],
                    currentKey: key + userId
                }
            );
            return updatedState;
        })
    };


    const handleGetCustomRange = () => {
        handleGetValues(
            {
                updatedValue: { from: lcValues?.from ? lcValues?.from : null, to: lcValues?.to ? lcValues?.to : null },
                uniqueKey: "customTiming", ["userId"]: userId
            }
        );
    };

    const handleUpdatedOptions = (index) => {
        if (Object.keys(lcValues).length) {
            setLcShifts(prev => {
                const updatedState = prev[index].map(item => {
                    if (item.type === "custom") {
                        return {
                            ...item,
                            label: `Custom ${lcValues?.from?.updatedValue?.hour}:${lcValues?.from?.updatedValue?.minute} to ${lcValues?.to?.updatedValue?.hour}:${lcValues?.to?.updatedValue?.minute}`,
                        };
                    }
                    else {
                        return item;
                    }
                });
            
                return { ...prev, [index]: updatedState }
            })
            let key = "";
            const updatedState = (lcOptions || []).map((item, lc_index) => {
                if (lc_index + 1 === lcValues?.clickedIndex) {
                    const fromHour = lcValues?.from?.updatedValue?.hour;
                    const fromMinute = lcValues?.from?.updatedValue?.minute;
                    const toHour = lcValues?.to?.updatedValue?.hour;
                    const toMinute = lcValues?.to?.updatedValue?.minute;
                    const shiftTiming = {
                        label: `Custom ${fromHour}:${fromMinute} to ${toHour}:${toMinute}`,
                        value: `${fromHour}:${fromMinute}to${toHour}:${toMinute}`
                    };

                  
                    if (item?.occursOnSpecificWeekDay?.length) {
                        key = handleKeyGenerator({ occursOnSpecificWeekDay: item.occursOnSpecificWeekDay, shiftTiming })
                    
                    };
                    return {
                        ...item, shiftTiming
                    };
                }
                return item;
            });
      
            handleGetValues && handleGetValues(
                {
                    uniqueKey: timePeriod + "Recurrence",
                    updatedValue: updatedState,
                    type,
                    errorHandlers: lcValues?.errorHandlers,
                    currentKey: key
                }
            );
            setLcValues({});
        }
        setCustomRangeModal();
    }

    return (
        <>
            <div className={ChildStyles.main_container}>
                <div className={ChildStyles.recurred_container}>
                    {(lcOptions || []).map((item, index) => {
                        return <div key={item.id} className={ChildStyles.days_and_range_container}>
                            <div style={{ flexDirection: "row" }} className={ChildStyles.day_and_shift_container}>
                                {(timePeriod !== "Month" && false) && <ClonosDaySelector
                                    label={`Recrrence - ${timePeriod ? timePeriod : "Please select frequency"}`}
                                    uniqueKey='occursOnSpecificWeekDay'
                                    indexUniqueKey={`${userId}SpecificDay_${index}`}
                                    needToDisable={needToDisable || []}
                                    type="userSpecificCustomization"
                                    isMandatory={true}
                                    handleGetValues={(props) => lcHandleGetValues(props, index)}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />}
                                {(timePeriod === "Month" && false) && <div className={ChildStyles.month_label_container}>
                                    <label>
                                        Recrrence - {timePeriod ? timePeriod : "Please select frequency"} <sup className={ChildStyles.mandatory}>*</sup>
                                    </label>
                                    <div className={ChildStyles.month_static_label}>
                                        <span>{
                                            formData?.basedOnTimePeriodRecurrence?.[timePeriod]?.specificDays?.split("_").length > 1 ?
                                                formData?.basedOnTimePeriodRecurrence?.[timePeriod]?.specificDays?.split("_")?.slice(1)?.map((item, index) => {
                                                   
                                                    if (index === 0) {
                                                        return "Monthly on";
                                                    } else {
                                                        return item[0].toUpperCase() + item?.substring(1);
                                                    };
                                                }).join(" ") : getFormatedDate(formData?.basedOnTimePeriodRecurrence?.[timePeriod]?.specificDays)}</span>
                                    </div>
                                </div>
                                }
                                <ClonosSelect
                                    // optionType="radio"
                                    type="select"
                                    label="Shift Timing"
                                    isMandatory={true}
                                    isLabel={true}
                                    uniqueKey="shiftTiming"
                                    placeholder="Select"
                                    indexUniqueKey={`${userId}Shift_${index}`}
                                    options={
                                        lcShifts[index + 1]?.map((type) => ({
                                            label: type?.label,
                                            value: type?.from ? `${type.from}to${type.to}` : "custom",
                                            isNeeded: true,
                                            fn: type?.fn ? type?.fn : null,
                                            uniqueKey: type?.uniqueKey,
                                        }))}
                                    handleGetValues={(props) => lcHandleGetValues(props, index)}
                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                />
                            </div>
                            {
                                lcOptions?.length > 1 && <ClonosButton style={{ border: "none" }}><RemoveIcon onClick={() => {
                                    setLcOptions(prev => {
                                        if (lcOptions.length === 1) return prev;
                                        return (prev || []).filter((_, cl_index) => cl_index !== index)
                                    });
                                    handleRemoveField([`${userId}SpecificDay_${index}`, `${userId}Shift_${index}`])
                                }} /></ClonosButton>
                            }
                        </div>
                    })}
                </div>
                {false && <ClonosButton
                    onClick={() => {
                        setLcOptions([...lcOptions, { id: generateUniqueId(5) }]);
                        setLcShifts({
                            ...lcShifts, [Object.keys(lcShifts).length + 1]: [...shiftsStaticData?.map((item, index) => {
                                return { ...item, "uniqueKey": index + 1 }
                            }), { uniqueKey: shiftsStaticData.length + 1, label: "Custom", type: "custom", fn: setCustomRangeModal }]
                        })
                    }}

                    style={{ border: "none", color: CLONOS_GLOBAL_COLOUR_BLUE_HOVER, width: "fit-content" }}
                > + Add Recurrence</ClonosButton>}
            </div>
            <Modal
                closeModalMethod={() => {
                    setCustomRangeModal();
                    setLcValues({});
                }}
                isOpen={customRangeModal}
            >
                <div className={ChildStyles.custom_range_main_container}>
                    <header className={ChildStyles.cr_header}>
                        <span></span>
                        <span>Custom Timing</span>
                        <CloseIcon onClick={setCustomRangeModal} />
                    </header>
                    <section className={ChildStyles.cr_body}>
                        <div className={`${ChildStyles.from_to}`}>
                            <ClonosSpecifyFromAndTo
                                heading="From"
                                uniqueKey="from"
                                type="userSpecificCustomization"
                                isMandatory={true}
                                handleGetValues={props => setLcValues({ ...lcValues, [props?.uniqueKey]: props })}
                                minuteMin={formData?.from?.minute ? formData?.from?.minute : null}
                                minuteMax={formData?.to?.minute ? formData?.to?.minute : null}
                                hourMin={formData?.from?.hour ? formData?.from?.hour : null}
                                hourMax={formData?.to?.hour ? formData?.to?.hour : null}
                            />
                            <ClonosSpecifyFromAndTo
                                heading="To"
                                uniqueKey="to"
                                isMandatory={true}
                                type="userSpecificCustomization"
                                handleGetValues={props => setLcValues({ ...lcValues, [props?.uniqueKey]: props })}
                                minuteMin={lcValues?.from?.updatedValue?.hour === lcValues?.to?.updatedValue?.hour ? lcValues?.from?.updatedValue?.minute : 0}
                                minuteMax={59}
                                hourMin={lcValues?.from?.updatedValue?.hour ? lcValues?.from?.updatedValue?.hour : null}
                                hourMax={23}
                            />
                        </div>
                    </section>
                    <footer className={ChildStyles.cr_footer}>
                        <ClonosButton style={{ color: "red", borderColor: "red" }} onClick={() => setCustomRangeModal()}>Cencel</ClonosButton>
                        <ClonosButton isDisabled={(lcValues?.from?.updatedValue?.hour?.length > 0 && lcValues?.to?.updatedValue?.hour?.length > 0) ? false : true} onClick={() => {
                            handleUpdatedOptions(lcValues?.clickedIndex)
                        }}>Confirm</ClonosButton>
                    </footer>
                </div>
            </Modal>
        </>
    )
}

export default HourDayWeekRecurrenceCustomization