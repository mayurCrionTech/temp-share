import { useState, memo } from "react";
import Styles from "./TemplateCreation.module.css";
import PREVIEWICON from "../../../../assets/UIUX/icons/Checklist/eye-preview.svg";
import { ClonosButton } from "../../../../components/CommonComponents/Button/Button";
import { useSelector } from "react-redux";
import PLUSICON from "../../../../assets/UIUX/icons/Checklist/white-plus.svg";
import EXPANDDOWN from "../../../../assets/UIUX/icons/Checklist/caret-down.svg";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import {
  commonPageState,
  getFormatedDate,
  globalManipulateTemplatePreviewData,
  globalOnScrollEnd,
  handleShowErrorAndWarning,
} from "../../../../utils/clonosCommon";
import { v4 as uuidv4 } from "uuid";
import { LogsAndReportsAction } from "../../../../Store/Reducers/ClonosLogsReducer";
import Modal from "../../../../components/CommonComponents/Modal/Modal";
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import { handleCheckTemplateEditedOrNot, handleGetChecklistStructure, handleGetTemplateVersions, handleGetVersionTemplateDataSets, handleSaveChecklistDataSetsMethod, handleUpdateChecklistDataSets, handleUpdateGeneralTemplate } from "../../../../utils/LogAndReportsMethods/LogMethods";
import { useLocation, useNavigate } from "react-router-dom";
import { UnAuthorizedModal } from "../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import { Card } from "@material-ui/core";
import { Search, SingleCheck } from "../../../../assets/UIUX/icons/Checklist/Checklist";
import { doGetApiCall, doPostApiCall } from "../../../../utils/ClonosApi";
import AppUrl from "../../../../utils/AppUrl";
import useToggler from "../../../../CustomHooks/TogglerHook";
import ClonosSpinner from "../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import useDebounce from "../../../../CustomHooks/DebounceHook";
import ClonosConfirmationBox from "../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import BackIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/BackIcon";
import TemplateAttributesTable from "../Components/TemplateAttributesTable/TemplateAttributesTable";
import useImagesLoaded from "../../../../CustomHooks/ImageLoaderHook";
import ClonosSkeletonLoading from "../../../../components/CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
import { TemplateRowActions } from "../Components/TemplateAttributesTable/TemplateRowActions";
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";
import { SaveAsTemplate } from "../Components/SaveAsTemplate/SaveAsTemplate";
import { TemplatePreview } from "../Components/TemplatePreview/TemplatePreview";
import { TemplateAttributesImporter } from "../Components/TemplateAttributeImporter/TemplateAttributesImporter";
import { commonActions } from "../../../../Store/Reducers/CommonReducer";
import { CLONOS_GLOBAL_APP_ENVIRONMENT, CLONOS_GLOBAL_CHECKLIST_TEMPLATE_ATTRIBUTES_LIMIT, CLONOS_GLOBAL_LOG_TEMPLATE_ATTRIBUTES_LIMIT, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_BAD_REQUEST_ERROR, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG } from "../../../../Constants/Constant";
import { FormulaBuilderModal } from "../Components/form-builder/FormulaBuilderModal";
import { useStepContext } from "@mui/material";


// let primaryObject = {};
const TemplateCreation = ({ mode }) => {
 
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const LOCATION = useLocation();
  const { state } = LOCATION;
  
  const [showAttributes, setShowAttributes] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [showSaveTemplateModal, setShowSaveTemplateModal] = useState(false);
  const [uploadedAttributesFiles, setUploadedAttributesFiles] = useState([]);
  const { templateInfo, logTemplateAttributes, logGeneralDetailsCreationDetails, useTemplateInformation } = useSelector(
    (store) => store.logsAndReportsData
  );
  const [serverLogTemplateAttributes,setServerLogTemplateAttributes] = useState([]);
  
  const [lcValues, setLcValues] = useState({
    checklistCreationLoading: false,
    isSaveAsTemplate: useTemplateInformation?.useTemplate,
    savedTemplateServerResponse: [],
    totalTemplates: null,
    getTemplateDataSetsLoading: false,
    manipulatedDataForAttributesPreview: [],
    saveAsTemplateLoading: false,
    searchTemplate: "",
    checklistStructureDetails: {},
    updatedTemplateLoading: false,
    generalTemplateLoading: false,
    showFormulaBuilderModal:false,
    importedTemplates: [] // <-- keep track of order
  });
  const { savedTemplateServerResponse, totalTemplates, getTemplateDataSetsLoading, manipulatedDataForAttributesPreview, checklistStructureDetails, updatedTemplateLoading, generalTemplateLoading ,tempTemplate} = lcValues;
  
  // console.log(savedTemplateServerResponse,"savedTemplateServerResponse")
  const [IsImportTemplateFromLibraryModal, setIsImportTemplateFromLibraryModal] = useState(false);
  const [pagination, setPagination] = useState(commonPageState);
  const [isLoading, setIsLoading] = useToggler();
  const [refreshApi, setRefreshApi] = useToggler();
  const [isImportedTemplatePreviewModal, setIsImportedTemplatePreviewModal] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const delay = 500; // Set your desired debounce delay
  const debouncedValue = useDebounce(inputValue, delay);
  const [cancelChecklistTemplateCreationAlert, setCancelChecklistTemplateCreationAlert] = useState(false);
  const [localAttributes, setLocalAttributes] = useState([])
  

  const {
    handleGetErrorActivatorInformation,
    handlePrimaryObjectModifier,
    primaryObject,
    handleSubmit,
    handleRemoveField
  } = useFieldsChecker();

  // Handler Area
  const getSelectedAttributeValue = (props) => {
    
    const { attributeName, type } = props;

    let tempAttribute = {
      id: uuidv4(),
      asset: null,
      attributeName: attributeName ? attributeName : null,
      fieldName: "",
      fieldValue: "",
      type: type ? type : null,
      isMandatory:true,
      isSetpoints: false,
      setPoints: {
        minLimit: null,
        criticalMinLimit:null,
        safeOperatingLow: null,
        bestBatchLow: null,
        bestBatchHigh: null,
        safeOperatingHigh: null,
        criticalMaxLimit:null,
        maxLimit: null
      }
    };


    if (type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE || type === "dropdown" || type === "checkboxes") {
      tempAttribute.fieldValue = [
        { optionId: uuidv4(), optionValue: "", isActive: false },
        { optionId: uuidv4(), optionValue: "", isActive: false },
      ]
    }
    if (type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) {
      tempAttribute.tagMode = "normal"; // "normal" | "saveToTag"
      tempAttribute.tagId = null;
      tempAttribute.tagName = null;
    }
    if (useTemplateInformation?.useTemplate) {
      dispatch(LogsAndReportsAction?.setUseTemplateInformation({ useTemplate: false, templateId: useTemplateInformation?.templateId }))
      setLcValues(prev => {
        return { ...prev, ["isSaveAsTemplate"]: false, manipulatedDataForAttributesPreview: [] }
      })
    }
    else {
      setLcValues(prev => {
        return { ...prev, ["isSaveAsTemplate"]: false, manipulatedDataForAttributesPreview: [] };
      });
    };


    const attributes = [
      ...logTemplateAttributes,
      tempAttribute,
    ];


    setLocalAttributes(attributes);
    dispatch(
      LogsAndReportsAction.setSelectedAttributesToolkitState(attributes)
    );
  };

  // "Normal" mode -> plain number field (no tagId). "Log to Tag" mode -> logtotag field with its tagId.
  const buildLogTemplateDataSets = (attributes) => {
    return attributes?.map((item, index) => {
      const base = { ...item, index: index + 1, asset: item?.asset?.id || item?.asset?.assetId };
      if (item?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) {
        if (item?.tagMode === "saveToTag" && item?.tagId) {
          base.type = CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG;
          base.tagId = item.tagId;
        } else {
          base.type = "number";
          delete base.tagId;
        }
        delete base.tagMode;
        delete base.tagName;
      }
      return base;
    });
  };

  const getUploadedAttributesFiles = (value) => {
    setUploadedAttributesFiles(value)
  }

  const handleImportTemplateFromLibrary = () => {
    setIsImportTemplateFromLibraryModal(false)
  }

  // const handleGetTemplateDataSets = (id, isPreview) => {
  //   setLcValues(prev => {
  //     return { ...prev, ["getTemplateDataSetsLoading"]: true }
  //   })
  //   doGetApiCall({ url: `${AppUrl.getLogTemplateDetails}${id}` })
  //     .then(response => {
  //       console.log('responsedata:', response)
  //       setLcValues(prev => {
            
  //         let data = globalManipulateTemplatePreviewData({ data: response?.data?.result?.dataSets });
  //         console.log('dataaaaaa:', data)
  //         setLocalAttributes(data);
  //         if (!isPreview) {
  //           dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(data));
  //           setIsImportTemplateFromLibraryModal(false);
  //         }
  //         return { ...prev, ["manipulatedDataForAttributesPreview"]: data };
          
  //       });
  //     }).finally(() => {
  //       setLcValues(prev => {
  //         return { ...prev, ["getTemplateDataSetsLoading"]: false };
  //       });
  //     });
  // };


// 👉 Helper function to merge + dedupe attributes
const mergeAttributes = (prevAttrs = [], newAttrs = []) => {
  const merged = [...prevAttrs, ...newAttrs];
  // dedupe by `id` (change `id` if your field is different)
  return Array.from(new Map(merged.map(item => [item.id, item])).values());
};

const handleGetTemplateDataSets = (id, isPreview) => {
  setLcValues(prev => ({ ...prev, getTemplateDataSetsLoading: true }));

  doGetApiCall({ url: `${AppUrl.getLogTemplateDetails}${id}` })
    .then(response => {
      const newRawData = response?.data?.result?.dataSets || [];

      // Process new dataset
      const newProcessedData = globalManipulateTemplatePreviewData({ data: newRawData });

      if (!isPreview) {
        // ✅ Direct Import (merge + dedupe)
        setLocalAttributes(prevAttrs => {
          const updated = mergeAttributes(prevAttrs, newProcessedData);
          dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(updated));
          return updated;
        });
        setIsImportTemplateFromLibraryModal(false);
      } else {
        // ✅ Preview (replace, not accumulate)
        setLcValues(prev => ({
          ...prev,
          manipulatedDataForAttributesPreview: newProcessedData,
        }));
      }
    })
    .finally(() => {
      setLcValues(prev => ({ ...prev, getTemplateDataSetsLoading: false }));
    });
};


  const handleChange = (event) => {
    setInputValue(event?.target?.value);
  };

  /**
   * Fetches and updates the template data from the API.
   * 
   * This function handles both paginated and non-paginated requests for fetching template data. 
   * It sets the loading state to true, makes the API call, processes the response, 
   * and updates the state accordingly. If the API call fails, it displays an error message.
   * 
   * @param {boolean} isPagination - A flag indicating whether the request should include pagination parameters.
   * 
   * @returns {void}
   */
  const handleGetSaveAsTemplates = (isPagination) => {
    setIsLoading(true);
    doGetApiCall({
      url: AppUrl?.getLogSaveAsTemplates,
      params: isPagination ? { page: pagination?.page, limit: pagination?.limit } : { templateName: debouncedValue }
    })
      .then(response => {
        const result = {
          data: response?.data?.result?.data,
          status: response?.status,
          totalDataCount: response?.data?.result?.totalDataCount,
        }

        if (response.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
          setLcValues((prev) => {
            if (!result?.data || !Array.isArray(result.data)) {
              console.error('Invalid or missing data in the API response.');
              return prev;
            }
            if (isPagination) {
              let hasMap = {};
              result.data.forEach(item => (hasMap[item?._id] = 1));

              const filteredData = (savedTemplateServerResponse || []).filter(item => !hasMap[item._id]);

              return {
                ...prev,
                savedTemplateServerResponse: [...(filteredData || []), ...result.data],
                totalTemplates: result?.totalDataCount
              };
            } else {
              return {
                ...prev,
                savedTemplateServerResponse: result.data,
                totalTemplates: result?.totalDataCount
              };
            }
          });
        }
        else if (response.response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_BAD_REQUEST_ERROR) {
          handleShowErrorAndWarning({
            dispatch,
            type: "error",
            message: `${response?.response?.data?.errorInfo}.`,
            showTime: 5000
          })
        }
      }).finally(() => {
        setIsLoading(false);
      })
  }


  const handleDeleteKeyFromPrimaryObject = (key) => {
    if (primaryObject[key]) {
      delete primaryObject[key]
    }
  }

  const handleIsAnyFieldUpdate = () => {
    setLcValues(prev => {
      if (manipulatedDataForAttributesPreview?.length > 0) {
        return { ...prev, ["isSaveAsTemplate"]: false, manipulatedDataForAttributesPreview: [] };
      } else {
        return { ...prev, ["isSaveAsTemplate"]: false }
      }
    });
  }


  useEffect(() => {
    if (manipulatedDataForAttributesPreview?.length > 0) {
      for (let key in primaryObject) {
        primaryObject[key].value = true
      };
    };
  }, [manipulatedDataForAttributesPreview?.length]);

  useEffect(() => {
    handleGetSaveAsTemplates(true)
  }, [pagination, refreshApi]);

  // Access the debouncedValue for your logic
  useEffect(() => {
    if (debouncedValue?.length > 0) {
      handleGetSaveAsTemplates(false)
    } else {
      setPagination(prev => {
        return { ...prev, page: 1 }
      })
      setRefreshApi()
    }
  }, [debouncedValue]);

  useEffect(() => {
    globalOnScrollEnd(() => {
      const lcPage = Math.ceil(totalTemplates / pagination?.limit)
      setPagination(prev => {
        if (lcPage !== prev?.page) {
          return { ...prev, page: prev?.page + 1 }
        }
        return prev
      })

    }, "temp1");

  }, [IsImportTemplateFromLibraryModal, refreshApi,]);

  useEffect(() => {
    if (useTemplateInformation?.useTemplate) {
      handleGetTemplateDataSets(useTemplateInformation?.templateId)
    }
    
    if (mode === "edit") {
      if (LOCATION?.state?.isGeneralTemplate) {
        handleGetTemplateDataSets(LOCATION?.state?.generalTemplateId, false);
      } else {
        handleGetChecklistStructure(
          {
            serverResponseSetter:setServerLogTemplateAttributes,
            responseSetterMethod: setLcValues,
            lcStateSetterMethod: setLcValues,
            structureId: LOCATION?.state?.structureId,
            dispatch,
            setLocalAttributes
          }
        )
      }
    }
    return () => {
      dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState([]))
      // primaryObject = {}
    }

  }, []);

   const handleGetValues = (props) => {
      
    
      if (props?.componentName === "addImageAndNotes") {
        dispatch(LogsAndReportsAction.setTemplateInfoToolkitState(props?.updatedValue));
      } else if (props?.isTyping) {
        setLocalAttributes(props?.updatedValue);
      } else if (props?.dataSets?.length > 0) {
        
        const updatedAttributes = logTemplateAttributes.map((attribute) => {
          const matchingDataSet = props.dataSets.find(
            (ds) => String(ds._id) === String(attribute.id)
          );
    
          if (matchingDataSet) {
            return {
              ...attribute,
              upperBound: matchingDataSet.upperBound,
              lowerBound: matchingDataSet.lowerBound,
              criticalLowerBound: matchingDataSet.criticalLowerBound,
              criticalUpperBound: matchingDataSet.criticalUpperBound,
              isSetpoints: true,
            };
          }
    
          return attribute;
        });
    
        dispatch(
          LogsAndReportsAction.setSelectedAttributesToolkitState(updatedAttributes)
        );
    
        return updatedAttributes;
      } else {
        console.warn("dataSets not found or empty in handleGetValues");
      }
  };
  

  const handleRemoveAttribute = (attribute) => {
    setLocalAttributes(prev => {
    
      const updatedAttributes = prev?.filter((att) => {
        if (att?.id !== attribute?.id) {
          return true;
        } else {
          // Handle specific cases where the attribute needs additional processing
      
          let needToDelete = [];
          if (
            attribute?.attributeName === "Multiple Choice" ||
            attribute?.attributeName === "Dropdown" ||
            attribute?.attributeName === "Checkboxes"
          ) {
            if (attribute?.fieldValue?.length > 0) {
              attribute?.fieldValue?.forEach((item) => {
                needToDelete.push(item?.optionId);
              });
            };
          };
          needToDelete.push(attribute?.id)
          handleRemoveField(needToDelete);
          return false;
        }
      });
     
      dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(updatedAttributes));
      return updatedAttributes
    })
  };


  return (
    <>
      <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem", overflowY: "auto" }}>
        <div aria-label='template main contianer'
          className={Styles.main_container}
        >
          <header aria-label="template top navigation" className={Styles.nav}>

            <div aria-label="import template from template library container">
              <ClonosButton style={{ color: "#0A5FFF", border: "0.5px solid #0A5FFF" }}
                onClick={() => setIsImportTemplateFromLibraryModal(true)}
              >Import From Library</ClonosButton>
              {
                logTemplateAttributes?.length > 0 && <div onClick={() => setShowPreviewModal(true)} className={Styles.preview_btn_box}>
                  <img src={PREVIEWICON} />
                  <p>Preview</p>
                </div>
              }
            </div>

            <div aria-label="action control container">
              {CLONOS_GLOBAL_APP_ENVIRONMENT === "development" && <TemplateRowActions
                isImage={true}
                isNote={true}
                isDeselect={false}
                uniqueKey="addImageAndNotes"
                handleGetValues={handleGetValues}
              />}
              <div aria-label="save as template container">
                {
                  lcValues?.isSaveAsTemplate ? <div className={Styles.saved_template_container}> <SingleCheck /> <span>Saved as Template</span></div> :
                    <ClonosButton
                      loading={lcValues?.saveAsTemplateLoading}
                      onClick={() => setShowSaveTemplateModal(true)} style={{ color: "#06337E" }}
                      isDisabled={logTemplateAttributes?.length > 0 ? false : true}
                    >
                      Save as Template
                    </ClonosButton>
                }
              </div>

              <TemplateAttributesImporter ariaLabel="template attribute importer"
                getSelectedValue={(val) => {
                  if (logTemplateAttributes.length === CLONOS_GLOBAL_LOG_TEMPLATE_ATTRIBUTES_LIMIT) {
                    handleShowErrorAndWarning({ dispatch, type: "warning", message: `You can only add up to ${CLONOS_GLOBAL_LOG_TEMPLATE_ATTRIBUTES_LIMIT} attributes in one template.`, showTime: 5000 });
                    return;
                  }
                  getSelectedAttributeValue(val);
                }}
                disabled={logTemplateAttributes.length === CLONOS_GLOBAL_LOG_TEMPLATE_ATTRIBUTES_LIMIT ? true : false}

              />

            </div>

          </header>

          <TemplateAttributesTable
            handleGetValues={handleGetValues}
            attributes={logTemplateAttributes}
            uploadedAttributesFiles={uploadedAttributesFiles}
            getUploadedAttributesFiles={(value) => getUploadedAttributesFiles(value)}
            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            handlePrimaryObjectModifier={handlePrimaryObjectModifier}
            handleDeleteKeyFromPrimaryObject={handleDeleteKeyFromPrimaryObject}
            handleIsAnyFieldUpdate={handleIsAnyFieldUpdate}
            handleRemoveAttribute={handleRemoveAttribute}
            isEdit={mode === "edit" ? true : false}
          />

          <footer aria-label="component action container"
            className={Styles.btn_controller}>
            <div className={Styles.btns_container}>
              <ClonosButton variant="outlined" onClick={() => {
                setCancelChecklistTemplateCreationAlert(true)
              }}>Cancel</ClonosButton>


              {
                mode === "edit" ?
                  <ClonosButton
                    loading={updatedTemplateLoading}
                    variant="filled"
                    onClick={() => {
                      if (!handleSubmit()) return;
                      if (LOCATION?.state?.isGeneralTemplate) {
                        handleUpdateGeneralTemplate({
                          lcStateSetterMethod: setLcValues,
                          originalAttributes:serverLogTemplateAttributes,
                          generalTemplateId: LOCATION?.state?.generalTemplateId,
                          payload: {
                            dataSets: buildLogTemplateDataSets(logTemplateAttributes), name: LOCATION?.state?.templateName,
                            images: templateInfo?.uploadedFiles ? templateInfo?.uploadedFiles?.map(item => item?.id) : [],
                            note: templateInfo?.noteDetails ? templateInfo?.noteDetails : "",
                          },
                          dispatch,
                          Navigate
                        })
                      } else {
                        if(!handleCheckTemplateEditedOrNot({originalData:serverLogTemplateAttributes,updatedData:logTemplateAttributes})){
                          Navigate("/logs");
                          return
                        }
                        handleUpdateChecklistDataSets({
                          structureId: LOCATION?.state?.structureId,
                          logDetails:LOCATION?.state,
                          payload: {
                            images: templateInfo?.uploadedFiles ? templateInfo?.uploadedFiles?.map(item => item?.id) : [],
                            note: templateInfo?.noteDetails ? templateInfo?.noteDetails : "",
                            dataSets: buildLogTemplateDataSets(logTemplateAttributes),
                          },
                          dispatch,
                          Navigate,
                          responseSetterMethod: setLcValues
                        });
                      };
                    }}
                  >Update Template</ClonosButton> :

                  <ClonosButton
                    variant="filled"
                    loading={lcValues?.checklistCreationLoading}
                    isDisabled={logTemplateAttributes?.length > 0 ? false : true}
                    onClick={() => {
                      if (!handleSubmit()) return;
                      handleSaveChecklistDataSetsMethod(
                        {
                          logId: logGeneralDetailsCreationDetails?.id,
                          logName:logGeneralDetailsCreationDetails?.name,
                          payload: {
                            images: templateInfo?.uploadedFiles ? templateInfo?.uploadedFiles?.map(item => item?.id) : [],
                            note: templateInfo?.noteDetails ? templateInfo?.noteDetails : "",
                            dataSets: buildLogTemplateDataSets(logTemplateAttributes),
                          },
                          dispatch,
                          Navigate,
                          isGeneralTemplate: false,
                          responseSetterMethod: setLcValues
                        })
                    }}
                  >Create Log</ClonosButton>
              }
            </div>
          </footer>

        </div >
      </Card >
      <Modal isOpen={showPreviewModal} closeModalMethod={setShowPreviewModal}>
        <div className={Styles.preview_modal_sub_container}>
          <div className={Styles.preview_modal_header}>
            <h4>{state?.generalDetails?.name}</h4>
            <div><CloseIcon onClick={() => setShowPreviewModal(false)} /></div>
          </div>
          <div aria-label="General Details" className={Styles.general_details_container}>
            <p>{state?.generalDetails?.description}</p>
          </div>
          <div className={Styles.preview_modal_content_container}>
            <TemplatePreview
              isEdit={false}
              attributes={logTemplateAttributes}
            />
          </div>
        </div>
      </Modal>


      {/* Import template from the template library modal */}
      <Modal
        isOpen={IsImportTemplateFromLibraryModal}
        closeModalMethod={setIsImportTemplateFromLibraryModal}
        stopOverlayCloser={true}
      >
        <div className={Styles.import_from_library}>
          <header>
            <span>Import from template library</span>
            <CloseIcon onClick={() => setIsImportTemplateFromLibraryModal(false)} tooltipTitle={"Close"} />
          </header>
          <section className={Styles.import_from_library_body}>
            <div className={Styles.import_from_library_search}>
              <Search onClick={() => setIsImportTemplateFromLibraryModal(false)} />
              <input placeholder="Search" onChange={e => handleChange(e)} />
            </div>
            <div id="temp1" className={Styles.import_from_library_items_container}>
              {
                savedTemplateServerResponse?.map((item) => {
                  return <div key={item.id} className={Styles.import_from_library_body_item}>
                    <div onClick={() => {
                      handleGetTemplateDataSets(item._id, false)
                      primaryObject = {};
                      setLcValues(prev => {
                        return { ...prev, ["isSaveAsTemplate"]: false, activeTemplateDetails: { name: item?.templateName } };
                      });
                      setIsImportTemplateFromLibraryModal(false);
                    }}>
                      <span>{item?.templateName}</span>
                      <span>{getFormatedDate(item.createdAt)}</span>
                    </div>
                    <span onClick={() => {
                      setIsImportedTemplatePreviewModal(true);
                      setLcValues(prev => {
                        return { ...prev, ["activeTemplateDetails"]: { name: item?.templateName } };
                      });
                      handleGetTemplateDataSets(item._id, true);
                    }}>Preview</span>
                  </div>
                })
              }
              <div style={{ display: 'flex', justifyContent: 'center', width: "100%" }}>
                {isLoading && <ClonosSpinner />}
              </div>
            </div>
          </section>
          <footer>
            <span onClick={() => setIsImportTemplateFromLibraryModal(false)}>Cancel</span>
            <span onClick={handleImportTemplateFromLibrary}>Ok</span>
          </footer>
        </div>
      </Modal>

      <Modal isOpen={isImportedTemplatePreviewModal} closeModalMethod={setIsImportedTemplatePreviewModal} >
        <div className={Styles.imported_template_Preview_container}>
          <header>
            <div>
              <BackIcon tooltipTitle="Back" onClick={() => setIsImportedTemplatePreviewModal(false)} />
              <span>{lcValues?.activeTemplateDetails?.name}</span>
            </div>
            <CloseIcon tooltipTitle="Close" onClick={() => setIsImportedTemplatePreviewModal(false)} />
          </header>
          {
            getTemplateDataSetsLoading ? <ClonosSpinner /> :
              <TemplatePreview
                isEdit={false}
                attributes={manipulatedDataForAttributesPreview}
                // handleUseTemplate={() => {
                //   dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(manipulatedDataForAttributesPreview));
                //   setIsImportedTemplatePreviewModal(false);
                //   setIsImportTemplateFromLibraryModal(false);
                // }}
              //   handleUseTemplate={() => {
              //   // ✅ Merge previewed data with existing attributes
              //   setLocalAttributes(prevAttrs => {
              //     const updated = [...prevAttrs, ...manipulatedDataForAttributesPreview];
              //     dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(updated));
              //     return updated;
              //   });

              //   // Close modals
              //   setIsImportedTemplatePreviewModal(false);
              //   setIsImportTemplateFromLibraryModal(false);
              // }}

              handleUseTemplate={() => {
              // ✅ Merge preview data into main attributes
              setLocalAttributes(prevAttrs => {
                const updated = mergeAttributes(prevAttrs, manipulatedDataForAttributesPreview);
                dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(updated));
                return updated;
              });

              // Close modals
              setIsImportedTemplatePreviewModal(false);
              setIsImportTemplateFromLibraryModal(false);
            }}

              />
          }
        </div>
      </Modal>

      <ClonosConfirmationBox
        isOpen={cancelChecklistTemplateCreationAlert}
        confirmingMethod={() => {
          LogsAndReportsAction.setSelectedAttributesToolkitState([]);
          LogsAndReportsAction.setUseTemplateInformation({ useTemplate: false, templateId: null })
          Navigate("/logs")
        }}
        closeModalMethod={setCancelChecklistTemplateCreationAlert}
        headerTitle="Template Creation"
        message="Are you sure, You don't want to create log template?"
      />

      <SaveAsTemplate
        open={showSaveTemplateModal}
        closeMethod={setShowSaveTemplateModal}
        responseSetterMethod={setLcValues}
        loading={lcValues?.saveAsTemplateLoading}
        refreshApi={setRefreshApi}
      />

    </>
  );
  // return <UnAuthorizedModal />
};

export default memo(TemplateCreation);
