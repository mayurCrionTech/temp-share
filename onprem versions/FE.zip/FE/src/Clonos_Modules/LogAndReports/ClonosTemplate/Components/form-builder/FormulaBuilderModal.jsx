import { useEffect, useState } from "react"
import CloseIcon from "../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import { ClonosButton } from "../../../../../components/CommonComponents/Button/Button"
import ClonosTextarea from "../../../../../components/CommonComponents/ClonosTextarea/ClonosTextarea"
import Modal from "../../../../../components/CommonComponents/Modal/Modal"
import Styles from "./formula-builder-modal.module.css"
import useDebounce from "../../../../../CustomHooks/DebounceHook"
import ClonosRadioAndCheckbox from "../../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox"
import DynamicDropdown from "../../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown"

export const FormulaBuilderModal = ({isOpen,closeMethod}) => {
    const handleChange = (e) => {
        
    }   

    return <Modal isOpen={isOpen} closeModalMethod={closeMethod} stopOverlayCloser={true}>
            <div className={Styles.container}>
                <header className={Styles.header}>
                    <h4>Formula Builder</h4>
                    <div className={Styles.close_wrapper}>
                        <CloseIcon size={"24px"} onClick={closeMethod}/>
                    </div>
                </header>
                <section className={Styles.section}>
                    <ClonosTextarea
                        label={"Formula Builder"}
                        isLabel={true}
                        inputStyle={{border:"none"}}
                        isMandatory={true}
                    ></ClonosTextarea>
                    {/* <ClonosRadioAndCheckbox
                        name="formulaBuilder"
                        uniqueKey="isRefferenceRequired"
                        isLabel={true}
                        label="Refer other log"
                        type="checkbox"
                        disabled={false}
                        handleGetValues={(props) => {
                          console.log("props", props)
                        }}
                    /> */}
                    <DynamicDropdown
                        isLabel={true}
                        label="Select field from current log"
                        title={"Select field from current log"}
                        uniqueKey={"asset"}
                        heading={"Choose Field"}
                        placeholder={"Search"}
                        isSearchable={true}
                        isCheckbox={false}
                        isDynamicLoad={true}
                        data={[]}
                        isActivator={true}
                        isMandatory={true}
                        defaultValue={""}
                        handleDynamicSearch={() => {}}
                        handleMoreData={() => {}}
                        handleGetValues={() => {}}
                        handleGetErrorActivatorInformation={() => {}}
                    />
                </section>
                <footer className={Styles.footer}>
                    <ClonosButton variant={"filled"}>Add Formula</ClonosButton>
                </footer>
            </div>
    </Modal>
}