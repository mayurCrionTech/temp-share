import Styles from "./TemplatePreview.module.css";
import TEMPLATE_PREVIEW_ADDIMAGE from "../../../../../assets/UIUX/icons/Checklist/add-image.svg";
import TEMPLATE_PREVIEW_VIEWIMAGE from "../../../../../assets/UIUX/icons/Checklist/view-image.svg";
import TEMPLATE_PREVIEW_ADDNOTE from "../../../../../assets/UIUX/icons/Checklist/add-note.svg";
import TEMPLATE_PREVIEW_VIEWNOTE from "../../../../../assets/UIUX/icons/Checklist/view-note.svg";
import { useEffect, useState } from "react";
import ClonosSelect from "../../../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosInput from "../../../../../components/CommonComponents/ClonosInput/ClonosInput";
import { CLONOS_GLOBAL_ACTION_FILL_ENTRY,CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT } from "../../../../../Constants/Constant";
import { ClonosButton } from "../../../../../components/CommonComponents/Button/Button";
import { checkUserHasPermission, handleClientDateInConfiguredTimeZone, handleServerDateInConfiguredTimeZone, handleShowErrorAndWarning } from "../../../../../utils/clonosCommon";
import useModuleNameProvider from "../../../../../CustomHooks/ModuleNameProviderHook";
import useFieldsChecker from "../../../../../CustomHooks/FieldsValidatorHook";
import useToggler from "../../../../../CustomHooks/TogglerHook";
import { useDispatch } from "react-redux";



export const TemplatePreview = ({ attributes = [], isEdit, handleUseTemplate, handleGetUpdatedDataSets,handleGetInprogressDataSets ,loading ,isFormula}) => {
    
    const  dispatch = useDispatch()
    const [lcAttributes, setLcAttributes] = useState({});
    const [lcUpdatedAttributes, setLcUpdatedAttributes] = useState([]);
    const [originalAttributes,setOriginalAttributes]=useState([])
   
    const moduleName = useModuleNameProvider();
    const {
        handleGetErrorActivatorInformation,
        handleGetUpdatedPrimaryObject
    } = useFieldsChecker();
    const [fillingEntriesLoadings, setFillingEntriesLoadings] = useToggler();
    const [inprogressFillingEntriesLoading, setInprogressFillingEntriesLoading]=useToggler();
   

    // dispatch(ChecklistAndReportsAction.setSelectedAttributesToolkitState(data));


    // useEffect(() => {
    //     const newAttributesStructure = {};
    //     attributes?.forEach(attribute => {
    //         newAttributesStructure[attribute?.id] = attribute;
    //     });
    //     setLcAttributes(newAttributesStructure);
    //     setLcUpdatedAttributes(attributes)
    // }, [attributes]);

useEffect(() => {
    const newAttributesStructure = {};
    attributes?.forEach(attribute => {
        newAttributesStructure[attribute?.id] = {
            ...attribute,
            initialFieldValue: attribute.fieldValue, // Store initial
        };
    });
    setLcAttributes(newAttributesStructure);
    setLcUpdatedAttributes(attributes);
}, [attributes]);


    const waitForElementReference = (getElementReferenceMethod, retries = 10, delay = 100) => {
        return new Promise((resolve, reject) => {
            const attemptFetch = async (attempt) => {
                const elementReference = getElementReferenceMethod && getElementReferenceMethod()?.current?.value;
                if ((elementReference !== undefined && elementReference !== null && elementReference !== '') || attempt >= retries) {
                    resolve(elementReference);
                } else {
                    setTimeout(() => attemptFetch(attempt + 1), delay);
                }
            };
            attemptFetch(0);
        });
    };

    // const handleManipulateDataSetsStructure = async () => {
    //     const primaryObjectElements = handleGetUpdatedPrimaryObject();
    //     console.log('primaryObjectElements:', primaryObjectElements)
    //     const attributesLocalData = [];
    //     setFillingEntriesLoadings();
    //     for (const key in lcAttributes) {
    //         const attribute = lcAttributes[key];
    //         if (
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
    //         ) {
    //             if (!attribute?.fieldValue?.length) {
    //                 let previousFilledValues = await waitForElementReference(
    //                     primaryObjectElements[key]?.getElementReferenceMethod
    //                 );
    //                  if (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER) {
    //                    if (previousFilledValues === undefined || previousFilledValues === null || previousFilledValues === "")  {
    //                         previousFilledValues = null; // or null, based on how you handle empty inputs
    //                     } else {
    //                         previousFilledValues = Number(previousFilledValues);
    //                     }
    //                 }

    //                     console.log(previousFilledValues,"previousFilledValues")
    //                 attributesLocalData.push({ ...attribute, ["fieldValue"]: previousFilledValues });
    //             } else {
    //                 attributesLocalData.push(attribute);
    //             }
    //         } else {
    //             attributesLocalData.push(attribute);
    //         }
    //     }
    //     handleGetUpdatedDataSets(attributesLocalData, setFillingEntriesLoadings);
    //     // setFillingEntriesLoadings();
    // };


//     const handleManipulateDataSetsStructure = async () => {
//     const primaryObjectElements = handleGetUpdatedPrimaryObject();
//     const updatedAttributes = [];
//     const missingMandatoryFields = [];

//     setFillingEntriesLoadings();

//     for (const key in lcAttributes) {
//         const attribute = lcAttributes[key];
//         let newValue = attribute?.fieldValue;

//         // Get new value if needed
//         if (
//             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
//             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
//             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
//         ) {
//             if (newValue === undefined || newValue === "") {
//                 newValue = await waitForElementReference(
//                     primaryObjectElements[key]?.getElementReferenceMethod
//                 );
//             }

//             // Validation for mandatory
//             if (attribute?.isMandatory && (newValue === undefined || newValue === "" || newValue === null)) {
//                 missingMandatoryFields.push(attribute?.fieldName || `Field ${key}`);
//                 continue;
//             }

//             if (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER) {
//                 newValue = (newValue === "" || newValue === undefined || newValue === null)
//                     ? null
//                     : Number(newValue);
//             }

//             const hasChanged = attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
//                 ? Number(newValue ?? 0) !== Number(attribute?.initialFieldValue ?? 0)
//                 : (newValue ?? "") !== (attribute?.initialFieldValue ?? "");

//             if (hasChanged) {
//                 updatedAttributes.push({
//                     index: attribute.index,
//                     fieldValue: newValue,
//                     type: attribute.type
//                 });
//             }
//         }

//         // MULTI / CHECKBOX / DROPDOWN
//         else if (
//             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
//             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
//             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN
//         ) {
//             const currentValues = Array.isArray(attribute?.fieldValue) ? attribute.fieldValue : [];
//             const selected = currentValues.filter(item => item?.isActive !== false);
//             const selectedIds = selected.map(item => item?._id).sort();

//             const initialValues = Array.isArray(attribute?.initialFieldValue) ? attribute.initialFieldValue : [];
//             const initialIds = initialValues.filter(item => item?.isActive !== false).map(item => item?._id).sort();

//             // Mandatory validation
//             if (attribute?.isMandatory && selected.length === 0) {
//                 missingMandatoryFields.push(attribute?.fieldName || `Field ${key}`);
//                 continue;
//             }

//             const hasChanged = JSON.stringify(selectedIds) !== JSON.stringify(initialIds);

//             if (hasChanged) {
//                 updatedAttributes.push({
//                     index: attribute.index,
//                     fieldValue: selectedIds,
//                     type: attribute.type
//                 });
//             }
//         }
//     }

//     //  Stop submission if any mandatory fields are missing
//         if (missingMandatoryFields.length > 0) {
//          const fieldList = missingMandatoryFields.join(", ") || 'Some mandatory fields are missing';

//         handleShowErrorAndWarning({
//             dispatch,
//             type: "error",
//             message: `Please fill all mandatory fields: ${fieldList}`,
//             showTime: 5000,
//         });
//         setFillingEntriesLoadings();
//         return;
//     }
//       handleGetUpdatedDataSets(updatedAttributes, setFillingEntriesLoadings());
//   }
     
  const handleSubmitManipulateDataSetsStructure = async () => {
    const primaryObjectElements = handleGetUpdatedPrimaryObject();
    const updatedAttributes = [];
    const missingMandatoryFields = [];

    setFillingEntriesLoadings();

    const attributeTasks = Object.entries(lcAttributes).map(async ([key, attribute]) => {
        let newValue = attribute?.fieldValue;

        // TEXT / DATE / NUMBER / LOG_TO_TAG
        if (
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG
        ) {
            if (newValue === undefined || newValue === "") {
                newValue = await waitForElementReference(
                    primaryObjectElements[key]?.getElementReferenceMethod
                );
            }

            const isFieldMandatory = attribute?.isFormula ? false : attribute?.isMandatory;

            if (isFieldMandatory && (newValue === undefined || newValue === "" || newValue === null)) {
                return { type: "missing", fieldName: attribute?.fieldName || `Field ${key}` };
            }

            // Number-type fields (incl. logtotag) must be sent as a real number, never a string
            if (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) {
                if (newValue === "" || newValue === undefined || newValue === null) {
                    return null; // don't send empty number fields at all
                } else if (!isNaN(newValue)) {
                    newValue = Number(newValue);
                }
            }

            // If empty or null → skip
            if (newValue === undefined || newValue === null || newValue === "") {
                return null;
            }

            // Compare with initial value (no coercion!)
            const hasChanged = newValue !== attribute?.initialFieldValue;

            if (hasChanged) {
                return {
                    type: "update",
                    index: attribute.index,
                    fieldValue: newValue,
                    dataType: attribute.type
                };
            }
        }

        // MULTI / CHECKBOX / DROPDOWN
        else if (
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN
        ) {
            const currentValues = Array.isArray(attribute?.fieldValue) ? attribute.fieldValue : [];
          
            const selected = currentValues.filter(item => item?.isActive !== false);
            const selectedIds = selected.map(item => item?._id).sort();

            const initialValues = Array.isArray(attribute?.initialFieldValue) ? attribute.initialFieldValue : [];
            const initialIds = initialValues.filter(item => item?.isActive !== false).map(item => item?._id).sort();

            // Mandatory validation
            if (attribute?.isMandatory && selected.length === 0) {
                return { type: "missing", fieldName: attribute?.fieldName || `Field ${key}` };
            }

            const hasChanged = JSON.stringify(selectedIds) !== JSON.stringify(initialIds);

            if (hasChanged) {
                return {
                    type: "update",
                    index: attribute.index,
                    fieldValue: selectedIds,
                    dataType: attribute.type
                };
            }

            return null
        }
 



        return null;
    });

    // Execute all tasks in parallel
    const results = await Promise.all(attributeTasks);

    // Process results
    for (const result of results) {
        if (!result) continue;

        if (result.type === "missing") {
            missingMandatoryFields.push(result.fieldName);
        } else if (result.type === "update") {
            updatedAttributes.push({
                index: result.index,
                fieldValue: result.fieldValue,
                type: result.dataType
            });
        }
    }

    // Stop submission if mandatory fields are missing
    if (missingMandatoryFields.length > 0) {
        const fieldList = missingMandatoryFields.join(", ") || 'Some mandatory fields are missing';

        handleShowErrorAndWarning({
            dispatch,
            type: "error",
            message: `Please fill all mandatory fields: ${fieldList}`,
            showTime: 5000,
        });

        setFillingEntriesLoadings();
        return;
    }

    // Submit updated data
    // handleGetUpdatedDataSets(updatedAttributes, setFillingEntriesLoadings());
    //updated code  loader call like this
     handleGetUpdatedDataSets(updatedAttributes, setFillingEntriesLoadings);
};


  const handleUpdateManipulateDataSetsStructure = async () => {
    const primaryObjectElements = handleGetUpdatedPrimaryObject();
    const updatedAttributes = [];
    const missingMandatoryFields = [];

    setFillingEntriesLoadings();

    const attributeTasks = Object.entries(lcAttributes).map(async ([key, attribute]) => {
        let newValue = attribute?.fieldValue;

        // TEXT / DATE / NUMBER / LOG_TO_TAG
        if (
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG
        ) {
            if (newValue === undefined || newValue === "") {
                newValue = await waitForElementReference(
                    primaryObjectElements[key]?.getElementReferenceMethod
                );
            }

            const isFieldMandatory = attribute?.isFormula ? false : attribute?.isMandatory;

            if (isFieldMandatory && (newValue === undefined || newValue === "" || newValue === null)) {
                return { type: "missing", fieldName: attribute?.fieldName || `Field ${key}` };
            }

            if (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) {
                if (newValue === "" || newValue === undefined || newValue === null) {
                    return null;
                } else if (!isNaN(newValue)) {
                    newValue = Number(newValue);
                }
            }

            if (newValue === undefined || newValue === null || newValue === "") {
                return null;
            }

            const hasChanged = newValue !== attribute?.initialFieldValue;

            if (hasChanged) {
                return {
                    type: "update",
                    index: attribute.index,
                    fieldValue: newValue,
                    dataType: attribute.type
                };
            }
        }

        // MULTI / CHECKBOX / DROPDOWN
        // else if (
        //     attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
        //     attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
        //     attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN
        // ) {
        //     const currentValues = Array.isArray(attribute?.fieldValue) ? attribute.fieldValue : [];
        //       console.log(currentValues,"currentValues")
        //     const selected = currentValues.filter(item => item?.isActive !== false);
        //     const selectedIds = selected.map(item => item?._id).sort();

        //     const initialValues = Array.isArray(attribute?.initialFieldValue) ? attribute.initialFieldValue : [];
        //     const initialIds = initialValues.filter(item => item?.isActive !== false).map(item => item?._id).sort();

        //     // Mandatory validation
        //     if (attribute?.isMandatory && selected.length === 0) {
        //         return { type: "missing", fieldName: attribute?.fieldName || `Field ${key}` };
        //     }

        //     const hasChanged = JSON.stringify(selectedIds) !== JSON.stringify(initialIds);

        //     if (hasChanged) {
        //         return {
        //             type: "update",
        //             index: attribute.index,
        //             fieldValue: selectedIds,
        //             dataType: attribute.type
        //         };
        //     }
        // }
        else if (
        attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
        attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
        attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN
        ) {
            const currentValues = Array.isArray(attribute?.fieldValue) ? attribute.fieldValue : [];
            

            // Prepare full current values (include true/false)
            const allCurrentValues = currentValues.map(item => ({
                id: item?._id,
                isActive: !!item?.isActive // force boolean
            }));

            const initialValues = Array.isArray(attribute?.initialFieldValue) ? attribute.initialFieldValue : [];
            const allInitialValues = initialValues.map(item => ({
                id: item?._id,
                isActive: !!item?.isActive
            }));

            // Mandatory validation (must have at least one true)
            const hasActive = allCurrentValues.some(item => item.isActive);
            if (attribute?.isMandatory && !hasActive) {
                return { type: "missing", fieldName: attribute?.fieldName || `Field ${key}` };
            }

            // 🔍 Compare current vs initial to detect change
            const hasChanged = JSON.stringify(allCurrentValues) !== JSON.stringify(allInitialValues);

            // ✅ Send only if something changed
            if (hasChanged) {
                return {
                    type: "update",
                    index: attribute.index,
                    fieldValue: allCurrentValues, // includes both true & false
                    dataType: attribute.type
                };
            }

            // ⛔ If nothing changed, skip this field entirely
            return null;
        }



        return null;
    });

    // Execute all tasks in parallel
    const results = await Promise.all(attributeTasks);

    // Process results
    for (const result of results) {
        if (!result) continue;

        if (result.type === "missing") {
            missingMandatoryFields.push(result.fieldName);
        } else if (result.type === "update") {
            updatedAttributes.push({
                index: result.index,
                fieldValue: result.fieldValue,
                type: result.dataType
            });
        }
    }

    // Stop submission if mandatory fields are missing
    if (missingMandatoryFields.length > 0) {
        const fieldList = missingMandatoryFields.join(", ") || 'Some mandatory fields are missing';

        handleShowErrorAndWarning({
            dispatch,
            type: "error",
            message: `Please fill all mandatory fields: ${fieldList}`,
            showTime: 5000,
        });

        setFillingEntriesLoadings();
        return;
    }

    // Submit updated data
    // handleGetUpdatedDataSets(updatedAttributes, setFillingEntriesLoadings());
    //updated code  loader call like this
      handleGetUpdatedDataSets(updatedAttributes, setFillingEntriesLoadings);
};

   
    //    const handleInProgressDataSetsStructure = async () => {
    //     const primaryObjectElements = handleGetUpdatedPrimaryObject();
    //     console.log('primaryObjectElements:', primaryObjectElements)
    //     const attributesLocalData = [];
    //     setInprogressFillingEntriesLoading();
    //     for (const key in lcAttributes) {
    //         const attribute = lcAttributes[key];
    //         if (
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
    //         ) {
    //             if (!attribute?.fieldValue?.length) {
    //                 let previousFilledValues = await waitForElementReference(
    //                     primaryObjectElements[key]?.getElementReferenceMethod
    //                 );
    //                  if (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER) {
    //                    if (previousFilledValues === undefined || previousFilledValues === null || previousFilledValues === "")  {
    //                         previousFilledValues = null; // or null, based on how you handle empty inputs
    //                     } else {
    //                         previousFilledValues = Number(previousFilledValues);
    //                     }
    //                 }

    //                     console.log(previousFilledValues,"previousFilledValues")
    //                 attributesLocalData.push({ ...attribute, ["fieldValue"]: previousFilledValues });
    //             } else {
    //                 attributesLocalData.push(attribute);
    //             }
    //         } else {
    //             attributesLocalData.push(attribute);
    //         }
    //     }
    //     handleGetInprogressDataSets(attributesLocalData, setInprogressFillingEntriesLoading)
    //     // setFillingEntriesLoadings();
    // };



    // const handleInProgressDataSetsStructure = async () => {
    //     const primaryObjectElements = handleGetUpdatedPrimaryObject();
    //     const updatedAttributes = [];

    //     setInprogressFillingEntriesLoading();
    //     console.log(lcAttributes, "lcAttributes");

    //     for (const key in lcAttributes) {
    //         const attribute = lcAttributes[key];
    //         let newValue = attribute?.fieldValue;

    //         // TEXT / DATE / NUMBER
    //         if (
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
    //         ) {
    //             // Get latest value if empty
    //             if (newValue === undefined || newValue === "") {
    //                 newValue = await waitForElementReference(
    //                     primaryObjectElements[key]?.getElementReferenceMethod
    //                 );
    //             }

    //             if (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER) {
    //                 newValue = (newValue === "" || newValue === undefined || newValue === null)
    //                     ? null
    //                     : Number(newValue);
    //             }

    //             const hasChanged = attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
    //                 ? Number(newValue ?? 0) !== Number(attribute?.initialFieldValue ?? 0)
    //                 : (newValue ?? "") !== (attribute?.initialFieldValue ?? "");

    //             if (hasChanged) {
    //                 updatedAttributes.push({
    //                     index: attribute.index,
    //                     fieldValue: newValue,
    //                     type: attribute.type
    //                 });
    //             }
    //         }

    //         // MULTI / CHECKBOXES / DROPDOWN
    //         else if (
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
    //             attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN
    //         ) {
    //             const currentValues = Array.isArray(attribute?.fieldValue) ? attribute.fieldValue : [];
    //             const initialValues = Array.isArray(attribute?.initialFieldValue) ? attribute.initialFieldValue : [];

    //             const currentIds = currentValues
    //                 .filter(item => item?.isActive !== false)
    //                 .map(item => item?._id)
    //                 .sort();

    //             const initialIds = initialValues
    //                 .filter(item => item?.isActive !== false) 
    //                 .map(item => item?._id)
    //                 .sort();

    //             const hasChanged = JSON.stringify(currentIds) !== JSON.stringify(initialIds);

    //             if (hasChanged) {
    //                 updatedAttributes.push({
    //                     index: attribute.index,
    //                     fieldValue: currentIds,
    //                     type: attribute.type
    //                 });
    //             }
    //         }
    //     }

    //     //  Only send updated fields
    //     handleGetInprogressDataSets(updatedAttributes, setInprogressFillingEntriesLoading);
    // };
    const handleInProgressDataSetsStructure = async () => {
    const primaryObjectElements = handleGetUpdatedPrimaryObject();
    const updatedAttributes = [];

    setInprogressFillingEntriesLoading();
    

    // Prepare an array of async tasks for all attributes
    const attributeTasks = Object.entries(lcAttributes).map(async ([key, attribute]) => {
        let newValue = attribute?.fieldValue;

        // TEXT / DATE / NUMBER / LOG_TO_TAG
        if (
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG
        ) {
            // If value is empty, fetch it using the element reference
            if (newValue === undefined || newValue === "") {
                newValue = await waitForElementReference(
                    primaryObjectElements[key]?.getElementReferenceMethod
                );
            }

          
            if (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) {                if (newValue === "" || newValue === undefined || newValue === null) {
                    return null; // ⬅️ don't send empty number fields at all
                } else if (!isNaN(newValue)) {
                    newValue = Number(newValue);
                }
            }

            // 🚀 FIX: If empty or null → skip
            if (newValue === undefined || newValue === null || newValue === "") {
                return null;
            }

            // Compare with initial value (no coercion!)
            const hasChanged = newValue !== attribute?.initialFieldValue;

            if (hasChanged) {
                return {
                    index: attribute.index,
                    fieldValue: newValue,
                    type: attribute.type
                };
            }
        }

        // MULTI / CHECKBOXES / DROPDOWN
        else if (
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
            attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN
        ) {
            const currentValues = Array.isArray(attribute?.fieldValue) ? attribute.fieldValue : [];
            const initialValues = Array.isArray(attribute?.initialFieldValue) ? attribute.initialFieldValue : [];

            const currentIds = currentValues
                .filter(item => item?.isActive !== false)
                .map(item => item?._id)
                .sort();

            const initialIds = initialValues
                .filter(item => item?.isActive !== false)
                .map(item => item?._id)
                .sort();

            const hasChanged = JSON.stringify(currentIds) !== JSON.stringify(initialIds);

            if (hasChanged) {
                return {
                    index: attribute.index,
                    fieldValue: currentIds,
                    type: attribute.type
                };
            }
        }

        return null; // unchanged or unsupported
    });

    // Run all tasks in parallel
    const results = await Promise.all(attributeTasks);

    // Collect only the changed attributes
    for (const attr of results) {
        if (attr) {
            updatedAttributes.push(attr);
        }
    }

    // Send updated attributes only
    handleGetInprogressDataSets(updatedAttributes, setInprogressFillingEntriesLoading);
};



        const shouldDisableInProgressButton = () => {
        let filledCount = 0;
        let totalCount = 0;

        for (const key in lcAttributes) {
            const attr = lcAttributes[key];
            totalCount++;

            // TEXT / DATE / NUMBER / LOG_TO_TAG
            if (
                attr?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
                attr?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
                attr?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER ||
                attr?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG
            ) {
                const value = attr?.fieldValue;

                const isEmpty =
                    value === undefined ||
                    value === null ||
                    value === "";

                if (!isEmpty) {
                    filledCount++;
                }
            }

            // CHECKBOXES / MULTI / DROPDOWN
            else if (
                attr?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES ||
                attr?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE ||
                attr?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN
            ) {
                const currentIds = (attr?.fieldValue || [])
                    .filter(item => item?.isActive !== false)
                    .map(item => item?._id);

                if (currentIds.length > 0) {
                    filledCount++;
                }
            }
        }

        const remaining = totalCount - filledCount;

        //  Disable if only 0
        return remaining < 1;
    };
   

    const isManagerEditing = isEdit && checkUserHasPermission({
    moduleName,
    action: CLONOS_GLOBAL_ACTION_FILL_UPDATE_ENTRY,
    });
   
    const shouldDisableField = (isFilled, isManagerEditing, isFormulaFlag) => {
    const isFormula = isFormulaFlag === true; // only an explicit true means it's a formula field

        // ✅ Formula fields always disabled
        if (isFormula) {
            return true;
        }

        // ✅ Non-formula fields disabled only if filled and not manager editing
        if (!isManagerEditing && isFilled) {
            return true;
        }

        // Otherwise enabled
        return false;
     };


    // const shouldDisableField = (isFilled, isManagerEditing, isFormulaFlag) => {
    // console.log("DISABLE CHECK:", { isFilled, isManagerEditing, isFormulaFlag });

    // const isFormula = isFormulaFlag !== false;
    // const filled =  isFilled;

    // return (!isManagerEditing && filled) || (isFormula && !isManagerEditing);
    // };

    const handleChange = ({ type, attribute, props, index }) => {
       
        let { updatedValue } = props;
     
        const { optionValue } = attribute;
      
        let targetedAttribute = { ...lcAttributes[attribute?.id] };
       

        if (
            type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT ||
            type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER ||
            type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE ||
            type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG
        ) {
            if (type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE) {
                targetedAttribute.fieldValue = handleServerDateInConfiguredTimeZone({ dateString: updatedValue });
            }
            if (type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) {
                updatedValue = updatedValue === "" ? null : Number(updatedValue);
            }
            targetedAttribute.fieldValue = updatedValue;
        }
        else if (type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE) {
            targetedAttribute.fieldValue = targetedAttribute?.fieldValue?.map(attribute => {
                if (attribute?.optionId === props?.target?.value) {
                    return { ...attribute, isActive: true };
                }
                else {
                    return { ...attribute, isActive: false };
                }
            });
        }
        else if (type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN) {
            targetedAttribute.fieldValue = targetedAttribute?.fieldValue?.map(attribute => {
                if (attribute?.optionId === updatedValue?.value) {
                    return { ...attribute, isActive: true }
                }
                else {
                    return { ...attribute, isActive: false }
                }
            });

        }
        else if (type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES) {
           
            targetedAttribute.fieldValue = targetedAttribute?.fieldValue?.map(attribute => {
                if (attribute?.optionId === props?.target?.value && props?.target?.checked) {
                    return { ...attribute, isActive: true };
                }
                else if (attribute?.optionId === props?.target?.value && props?.target?.checked === false) {
                    return { ...attribute, isActive: false };
                }
                return attribute;
            });
        }
       
        setLcAttributes(prev => {
            const updatedState = { ...prev, [attribute?.id]: targetedAttribute };
            setLcUpdatedAttributes(Object.values(updatedState));
            return updatedState;
        });

    }

    return (
        <>
            <div className={Styles.ct_preview_container}>
                {lcUpdatedAttributes?.length || false ? (
                    lcUpdatedAttributes?.map((attribute, index) => {
                        return (
                            <div className={Styles.ct_preview_attribute_container}>
                                <div className={Styles.ct_preview_field_label_container}>
                                    <h4 className={Styles.ct_preview_field_label}>
                                        {attribute?.fieldName || "Untitled Field"} {attribute?.isMandatory && <sup className={Styles.clonos_select_isMandatory}>*</sup>}
                                    </h4>
                                </div>
                                <div className={Styles.ct_preview_attribute_value_contanier}>
                                    {
                                        (attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_TEXT || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) &&
                                        <div className={Styles.ct_preview_attribute_value_left}>
                                            <ClonosInput
                                                limit={(attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) ? 20 : 500}
                                                label={attribute?.fieldName || "Untitled Field"}
                                                uniqueKey={attribute?.id}
                                                // isLabel={true}
                                                isMinimum={false}
                                                // disabled={!isEdit || isFormula?.[index]?.isFormula !== false || isFormula?.[index]?.isFilled !== false}
                                                
                                                 disabled={shouldDisableField(
                                                    isFormula?.[index]?.isFilled,
                                                    isManagerEditing,
                                                    isFormula?.[index]?.isFormula
                                                )}

                                                // defaultValue={attribute?.fieldValue}
                                                // value={attribute?.fieldValue}
                                                defaultValue={
                                                    attribute?.isFormula && attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
                                                        ? (attribute?.fieldValue !== undefined && attribute?.fieldValue !== null && attribute?.fieldValue !== ""
                                                            ? Number(attribute.fieldValue).toFixed(2)
                                                            : "")
                                                        : attribute?.fieldValue
                                                }
                                                value={
                                                    attribute?.isFormula && attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER
                                                        ? (attribute?.fieldValue !== undefined && attribute?.fieldValue !== null && attribute?.fieldValue !== ""
                                                            ? Number(attribute.fieldValue).toFixed(2)
                                                            : "")
                                                        : attribute?.fieldValue
                                                }

                                                
                                                handleGetValues={(props) => handleChange({ props, attribute, index, type: props?.type })}
                                                type={attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG ? CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER : attribute?.type}
                                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                // isMandatory={isEdit ? true : false}
                                                // isMandatory={attribute?.isMandatory}
                                                isMandatory={attribute?.isFormula ? false : attribute?.isMandatory}
                                                

                                            />
                                        </div>
                                    }
                                    {
                                        attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DROPDOWN && <div className={Styles.ct_preview_attribute_value_left}>
                                            <ClonosSelect
                                                type="select"
                                                // isLabel={true}
                                                label={attribute?.fieldName || "Untitled Field"}
                                                uniqueKey="priority"
                                                placeholder="Select"
                                                defaultValue={attribute?.fieldValue?.filter(item => item?.isActive)?.[0]?.optionValue}
                                                // disabled={!isEdit || isFormula?.[index]?.isFormula !== false}
                                                disabled={shouldDisableField(
                                                    isFormula?.[index]?.isFilled,
                                                    isManagerEditing,
                                                    isFormula?.[index]?.isFormula
                                                )}
                                                                   
                                                options={attribute?.fieldValue?.map((type) => ({
                                                    value: type?.optionId,
                                                    label: type?.optionValue,
                                                    isNeeded: true,
                                                    disabled: isEdit ? false : true
                                                }))}
                                                handleGetValues={(props) => handleChange({ props, attribute, index, type: attribute?.type })}
                                                // isMandatory={isEdit ? true : false}
                                                isMandatory={attribute?.isMandatory}
                                                // isMandatory={attribute?.isFormula ? false : attribute?.isMandatory}
                                            />
                                        </div>
                                    }
                                    {
                                        attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE && <div className={Styles.ct_preview_attribute_value_left}>
                                            {
                                                attribute?.fieldValue?.map((opt) => {
                                                    return <div className={Styles.ct_preview_multichoice_options_container}>
                                                        {opt?.optionValue &&
                                                            <div className={Styles.ct_preview_attribute_option}>
                                                                <input
                                                                    value={opt?.optionId}
                                                                    onChange={(e) => handleChange({ props: e, attribute, index, type: attribute?.type })}
                                                                    // disabled={!isEdit || isFormula?.[index]?.isFormula !== false}
                                                                   
                                                                    disabled={shouldDisableField(
                                                                        isFormula?.[index]?.isFilled,
                                                                        isManagerEditing,
                                                                        isFormula?.[index]?.isFormula
                                                                    )}

                                                                    defaultChecked={attribute?.choosedValue?.includes(opt?.optionValue)}
                                                                    name={`multiChoise${index}`}
                                                                    type="radio"
                                                                    checked={opt?.isActive ? true : false}
                                                                    isMandatory={attribute?.isMandatory}
                                                                    // isMandatory={attribute?.isFormula ? false : attribute?.isMandatory}
                                                                />
                                                                <label>{opt?.optionValue}</label>
                                                            </div>
                                                        }
                                                    </div>
                                                })
                                            }
                                        </div>
                                    }
                                    {
                                        attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_CHECKBOXES && <div className={Styles.ct_preview_attribute_value_left}>
                                            {
                                                attribute?.fieldValue?.map((opt) => {
                                                    return <div className={Styles.ct_preview_checkboxes_option}>
                                                        {opt?.optionValue && <div className={Styles.ct_preview_attribute_option}>
                                                            <input
                                                                value={opt?.optionId}
                                                                onChange={(e) => handleChange({ props: e, attribute, index, type: attribute?.type })}
                                                                // disabled={!isEdit || isFormula?.[index]?.isFormula !== false}
                                                                disabled={shouldDisableField(
                                                                    isFormula?.[index]?.isFilled,
                                                                    isManagerEditing,
                                                                    isFormula?.[index]?.isFormula
                                                                )}
                                                                defaultChecked={attribute?.choosedValue?.includes(opt?.optionId)}
                                                                name="multichoice"
                                                                type="checkbox"
                                                                checked={opt?.isActive ? true : false}
                                                                isMandatory={attribute?.isMandatory}
                                                                // isMandatory={attribute?.isFormula ? false : attribute?.isMandatory}
                                                            />
                                                            <label>{opt?.optionValue}</label>
                                                        </div>}
                                                    </div>
                                                })
                                            }
                                        </div>
                                    }
                                </div>
                            </div>
                        );
                    })
                ) : (
                    <div></div>
                )}
            </div>
            <footer className={Styles.ct_footer}>
                {
                    handleUseTemplate && <ClonosButton loading={loading} onClick={() => handleUseTemplate()} variant="filled">Use Template</ClonosButton>
                }
                {
                    handleGetInprogressDataSets && checkUserHasPermission({
                    moduleName,
                    action: CLONOS_GLOBAL_ACTION_FILL_ENTRY,
                    }) && <ClonosButton
                    loading={inprogressFillingEntriesLoading}
                       onClick={() => handleInProgressDataSetsStructure()}
                       isDisabled={shouldDisableInProgressButton()}
                    >
                        Record Now
                    </ClonosButton>
                }
                {
                    handleGetUpdatedDataSets && (
                        <ClonosButton
                        loading={fillingEntriesLoadings}
                        variant="filled"
                        onClick={() => {
                            if (checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })) {
                            handleSubmitManipulateDataSetsStructure();
                            } else {
                            handleUpdateManipulateDataSetsStructure();
                            }
                        }}
                        >
                        {checkUserHasPermission({ moduleName, action: CLONOS_GLOBAL_ACTION_FILL_ENTRY })
                            ? "Submit"
                            : "Update"}
                        </ClonosButton>
                    )
                    }

            </footer>
        </>
    );
};
