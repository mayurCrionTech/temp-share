import { memo, useEffect, useState } from "react";
// import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { DragDropContext, Draggable, Droppable } from "@hello-pangea/dnd";
import TEMPLATE_CREATION_GRIP_VERTICAL from "../../../../../assets/UIUX/icons/Checklist/grip-vertical.svg";
import SingleFieldValueComponent from "../AttributeElements/SingleFieldAttribute/SingleFieldValueComponent";
import { MultipleFieldValueComponent } from "../AttributeElements/MultiFieldsAttribute/MultipleFieldValueComponent";
import { useSelector } from "react-redux";
import { handleReturnedFieldValue } from "../../../../../utils/ChecklistAndReportsMethods/ChecklistMethods";
import { useDispatch } from "react-redux";
import { ChecklistAndReportsAction } from "../../../../../Store/Reducers/ClonosChecklistAndReportsReducer"
import { TemplateRowActions } from "./TemplateRowActions";
import Styles from "./TemplateAttributesTable.module.css"
import { doGetApiCall, doPostApiCall } from "../../../../../utils/ClonosApi";
import AppUrl from "../../../../../utils/AppUrl";
import useMultiPagination from "../../../../../CustomHooks/MultiPaginationHook";
import { commonPageState, handleRemoveDuplicatesFromAnArray } from "../../../../../utils/clonosCommon";
import { commonActions } from "../../../../../Store/Reducers/CommonReducer";
import { CLONOS_GLOBAL_APP_ENVIRONMENT, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE, CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER } from "../../../../../Constants/Constant";
import ClonosRadioAndCheckbox from "../../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox";
import Modal from "../../../../../components/CommonComponents/Modal/Modal";
import CloseIcon from "../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import Threshold from "../Threshold/Threshold";
import { LogsAndReportsAction } from "../../../../../Store/Reducers/ClonosLogsReducer";
import Scale from "../Scale/Scale";
import { LuSettings2 } from "react-icons/lu";
import Column from "antd/es/table/Column";
import { Mode } from "@mui/icons-material";
import { useLocation } from "react-router-dom";



const TemplateAttributesTable = ({
    attributes,
    uniqueKey,
    handleGetValues,
    uploadedAttributesFiles,
    handleGetErrorActivatorInformation,
    handlePrimaryObjectModifier,
    handleDeleteKeyFromPrimaryObject,
    handleIsAnyFieldUpdate,
    handleRemoveAttribute,
    isEdit,  
}) => {
    const columns = [
        { name: "SI.NO", width: "5%", visibility: true },
        { name: "Asset", width: "14%", visibility: true },
        { name: "DESCRIPTION", width: "18%", visibility: true },
        { name: "DEFAULT VALUE", width: "13%", visibility: true },
        { name: "TYPE", width: "8%", visibility: true },
        { name: "is Required", width: "8%", visibility: true },
        { name: "SET POINTS", width: "7%", visibility: true },
        { name: "ACTION", width: "5%", visibility: true },
    ];
   
    const { logTemplateAttributes, useTemplateInformation ,logGeneralDetailsCreationDetails} = useSelector(
        (store) => store?.logsAndReportsData
    );

    const dispatch = useDispatch();
    const [serverResponse, setServerResponse] = useState({ assets: {} });
    const { assets } = serverResponse;
    const LOCATION = useLocation();
    const { handleSetPage, handleSetLimit, paginations } = useMultiPagination({
        asset: commonPageState,
    });
    const [assetSearchString, setAssetSearchString] = useState("");
    const [assetSearchData, setAssetSearchData] = useState([]);
    const [isSetPointsOpenModal, setIsSetPointsOpenModal] = useState(false);
    const [activeAttributeDetails, setActiveAttributeDetails] = useState({});
    const [existingSetPointKeys, setExistingSetPointKeys] = useState(new Set());
    const [logToTagTagsData, setLogToTagTagsData] = useState([]);
    const [isLogToTagTagsLoading, setIsLogToTagTagsLoading] = useState(false);
    const [logToTagSearchString, setLogToTagSearchString] = useState("");
    const [openLogToTagModeDropdownId, setOpenLogToTagModeDropdownId] = useState(null);
    const [isLogToTagPickerModalOpen, setIsLogToTagPickerModalOpen] = useState(false);
    const [activeLogToTagAttributeId, setActiveLogToTagAttributeId] = useState(null);

    const fetchLogToTagTags = (search = "") => {
        setIsLogToTagTagsLoading(true);
        doGetApiCall({ url: AppUrl.getLogToTagTags, params: search ? { search } : {} })
            .then((res) => {
                const list = res?.data?.result?.data || res?.data?.result || res?.data || [];
                setLogToTagTagsData(
                    (list || []).map((tag) => ({
                        id: tag?.id || tag?._id,
                        name: tag?.tagname,
                        unit: tag?.unit,
                    }))
                );
            })
            .finally(() => setIsLogToTagTagsLoading(false));
    };

    const handleOpenLogToTagPicker = (attributeId) => {
        setActiveLogToTagAttributeId(attributeId);
        setIsLogToTagPickerModalOpen(true);
        fetchLogToTagTags();
    };

    const handleSelectLogToTagTag = (tag) => {
        handleLogToTagAttributeUpdate({
            attributeId: activeLogToTagAttributeId,
            updatedFields: { tagId: tag?.id || null, tagName: tag?.name || null },
        });
        setIsLogToTagPickerModalOpen(false);
    };

    const handleLogToTagAttributeUpdate = ({ attributeId, updatedFields }) => {
        const updatedAttributes = logTemplateAttributes?.map((attr) =>
            attr?.id === attributeId ? { ...attr, ...updatedFields } : attr
        );
        handleIsAnyFieldUpdate && handleIsAnyFieldUpdate();
        dispatch(LogsAndReportsAction.setSelectedAttributesToolkitState(updatedAttributes));
    };

    const handleDragEnd = (result) => {
        const { source, destination } = result;

        // Check if the item was dropped outside any droppable area
        if (!destination) return;

        // Reorder the items in the state
        const reorderedAttributes = Array.from(logTemplateAttributes);
        const [removed] = reorderedAttributes.splice(source.index, 1);
        reorderedAttributes.splice(destination.index, 0, removed);

        // Update the state using your Redux action
        dispatch(
            ChecklistAndReportsAction.setSelectedAttributesToolkitState(
                reorderedAttributes
            )
        );
        handleGetValues && handleGetValues({ uniqueKey, componentName: "templateAttributesTable", isTyping: true, updatedValue: reorderedAttributes })
    };

    const handleAttributes = ({ id, dispatch, attributes, value }) => {
        handleIsAnyFieldUpdate && handleIsAnyFieldUpdate()
        if (value?.isTyping) {
            handleReturnedFieldValue({ id, ...value, dispatch, attributes, handleGetValues })
        };
    }

    const lcHandleGetValues = (props) => {
        handleGetValues && handleGetValues({ uniqueKey: props?.uniqueKey, componentName: props?.componentName, updatedValue: props.updatedValue })
    }


    const handleGetAssets = (props = {}) => {
        const { limit = 15, name, page = 1 } = props;
        return doGetApiCall({ url: AppUrl.getAssets, params: { limit, name, page } }).then((res) => {
          
            return { ...res?.data?.result, data: (res?.data?.result?.data || []).map(item => ({ id: item?.id, name: item?.generalDetails?.name })) };
        });
    };


    const handleDynamicSearch = (props) => {
        setAssetSearchString(props?.input)
    };

    const handleLoadMoreData = ({ uniqueKey }) => {
        let pagination = paginations[uniqueKey];
        switch (uniqueKey) {
            case "asset": {
                if (assets.totalPageCount === pagination?.page) return;
                let updatedPage = null;
                if (pagination?.limit * pagination?.page === assets.data?.length) {
                    updatedPage = pagination?.page + 1
                } else {
                    updatedPage = pagination?.page
                }
                handleGetAssets({ page: updatedPage }).then(assetDataResponse => {
                    
                    const updatedAssets = handleRemoveDuplicatesFromAnArray({ data: [...assetDataResponse?.data, ...assets.data] })
                  
                    setServerResponse(prev => (
                        {
                            ...prev,
                            ["assets"]: { ...assetDataResponse, data: updatedAssets }
                        }));
                });
                handleSetPage({ page: updatedPage, key: uniqueKey });
            }
        }
    };

    useEffect(() => {
        if (assetSearchString === "") {
            handleGetAssets().then((assetData) => {
                setServerResponse({ ...serverResponse, ["assets"]: assetData })
            });
        }
        else {
            handleGetAssets({ name: assetSearchString }).then((assetData) => {
                setAssetSearchData(assetData?.data);
            });
            setAssetSearchData([]);
        };
    }, [assetSearchString]);


    const handleMouseDown = () => {
        console.log('handleMouseDown:')
    }
    const handleMouseUp = () => {
        console.log('handleMouseUp:')
    }

    const handleMouseMove = () => {
        console.log('handleMouseMove:')
    }

    const handleMouseLeave = () => {
        console.log('handleMouseLeave:')
    }



    const handleAddSetPoints = (props) => {
        
        // if (props?.isChecked) {
        //     const updatedAttributes = attributes?.map(attribute => {
        //         if (attribute?.id === props.uniqueKey) {
        //             return {
        //                 ...attribute, isSetpoints: false,
        //                 setPoints: {
        //                     minLimit: null,
        //                     safeOperatingLow: null,
        //                     criticalMinLimit,
        //                     criticalMaxLimit,
        //                     bestBatchLow: null,
        //                     bestBatchHigh: null,
        //                     safeOperatingHigh: null,
        //                     maxLimit: null
        //                 }
        //             };
        //         } else {
        //             return attribute;
        //         }
        //     });
        //     dispatch(
        //         LogsAndReportsAction.setSelectedAttributesToolkitState(updatedAttributes)
        //     );
        // } else {
        //     setIsSetPointsOpenModal(true);
        // }

        // Open modal
       
        setIsSetPointsOpenModal(true);

        setActiveAttributeDetails(props);
    }

    const handleSetSetPoints = (props) => {

        // If props is a payload object directly from Threshold
        if (props?.dataSets) {

            handleGetValues && handleGetValues(props);
            return; 
        }

        const setPoints = { ...props };
        delete setPoints.uniqueKey; // delete the unique key from the result.
        const updatedAttributes = attributes?.map(attribute => {


            if (attribute?.id === props.uniqueKey) {
                return { ...attribute, setPoints, isSetpoints: true };
            } else {
                return attribute;
            }
        });

        dispatch(
            LogsAndReportsAction.setSelectedAttributesToolkitState(updatedAttributes)
        );


        setIsSetPointsOpenModal(false);
    }
    
  useEffect(() => {
    const structureId = LOCATION?.state?.structureId;
    
  // If structureId is not present, skip the API call
  if (!structureId) {
    setExistingSetPointKeys(new Set()); // Reset to empty set
    return;
  }


    doGetApiCall({ url: `${AppUrl.getLogStructure}/${structureId}` }).then((res) => {
        const dataSets = res?.data?.result?.[0]?.dataSets || [];

        const idsWithSetPoints = new Set(
            dataSets
                .filter(item =>
                    item.upperBound !== null ||
                    item.lowerBound !== null 
                )
                .map(item => item._id) // Use _id instead of fieldName
        );

        setExistingSetPointKeys(idsWithSetPoints);
           
      
    });
   
}, []);


    const handleIsMandatory = ({ uniqueKey, isChecked }) => {
        const updatedAttributes = attributes?.map((attribute) => {
          if (attribute?.id === uniqueKey) {
            return {
              ...attribute,
              isMandatory: isChecked
            };
          }
          return attribute;
        });
      
        dispatch(
          LogsAndReportsAction.setSelectedAttributesToolkitState(updatedAttributes)
        );
      };

      
    useEffect(() => {
        dispatch(commonActions.showApiLoader(true))
        const timer = setTimeout(() => {
            dispatch(commonActions.showApiLoader(false))
        }, attributes?.length > 100 ? 1000 : attributes?.length > 50 ? 500 : 200);

        return () => clearTimeout(timer);
    }, [attributes?.length]);


    return (
        <>
            <div
                aria-label="template main container"
                className={Styles.template_table_container}
            >
                <DragDropContext onDragEnd={handleDragEnd}>
                    <div className={Styles.custom_table_container}>
                        <div className={Styles.custom_table_head}>
                            {/* widthCheck */}
                            {columns?.map((col) => {
                                return (
                                    col?.visibility && <div style={{ width: col?.width }} className={Styles.column_container}><p key={col?.name}>
                                        {col?.name}
                                    </p>
                                    </div>
                                );
                            })}
                        </div>
                        <Droppable droppableId="droppable-1">
                            {(provider) => (
                                <div
                                    ref={provider.innerRef}
                                    {...provider.droppableProps}
                                    className={Styles.custom_table_body}
                                >
                                    {logTemplateAttributes?.length > 0 &&
                                        attributes?.map((attribute, index) => {
                                            return (
                                                <Draggable
                                                    key={attribute.id}
                                                    draggableId={attribute.id}
                                                    index={index}
                                                >
                                                    {(provider) => (
                                                        <div
                                                            {...provider.draggableProps}
                                                            ref={provider.innerRef}
                                                            className={Styles.custom_table_row}
                                                        >
                                                            <div
                                                                style={{ width: `${columns[0].width}` }}
                                                                className={Styles.template_table_col_index}>
                                                                <div
                                                                    {...provider.dragHandleProps}
                                                                    className={Styles.template_table_col_handle}
                                                                >
                                                                    <img src={TEMPLATE_CREATION_GRIP_VERTICAL}
                                                                        onMouseDown={handleMouseDown}
                                                                        onMouseMove={handleMouseMove}
                                                                        onMouseUp={handleMouseUp}
                                                                        onMouseLeave={handleMouseLeave}
                                                                    />
                                                                </div>
                                                                <p>{index + 1}</p>
                                                            </div>
                                                            {attribute?.type === "text" && (
                                                                <SingleFieldValueComponent
                                                                    attribute={attribute}
                                                                    getFieldDetails={(value) => {
                                                                       
                                                                        handlePrimaryObjectModifier({ response: value?.fieldName, uniqueKey: value?.uniqueKey })
                                                                        handleAttributes({
                                                                            id: attribute?.id,
                                                                            value,
                                                                            dispatch,
                                                                            attributes: logTemplateAttributes,
                                                                        })
                                                                        setAssetSearchString("");
                                                                        handleSetPage({ page: 1, key: "asset" });
                                                                    }
                                                                    }
                                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                                    assets={assetSearchString?.length ? assetSearchData : serverResponse?.assets?.data}
                                                                    handleMoreData={assets.totalPageCount === paginations["asset"]?.page ? null : handleLoadMoreData}
                                                                    isEdit={isEdit}
                                                                    handleDynamicSearch={handleDynamicSearch}
                                                                    widths={{
                                                                        assetWidth: columns[1].width,
                                                                        descriptionWidth: columns[2].width,
                                                                        defaultValueWidth: columns[3].width,
                                                                    }}

                                                                />
                                                            )}
                                                            {attribute?.type === "number" && (
                                                                <SingleFieldValueComponent
                                                                    attribute={attribute}
                                                                    getFieldDetails={(value) => {
                                                                       
                                                                        handlePrimaryObjectModifier({ response: value?.fieldName, uniqueKey: value?.uniqueKey })
                                                                        handleAttributes({
                                                                            id: attribute?.id,
                                                                            value,
                                                                            dispatch,
                                                                            attributes: logTemplateAttributes,
                                                                        });
                                                                        setAssetSearchString("");
                                                                        handleSetPage({ page: 1, key: "asset" });

                                                                    }
                                                                    }
                                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                                    assets={assetSearchString?.length ? assetSearchData : serverResponse?.assets?.data}
                                                                    handleMoreData={assets.totalPageCount === paginations["asset"]?.page ? null : handleLoadMoreData}
                                                                    isEdit={isEdit}
                                                                    handleDynamicSearch={handleDynamicSearch}
                                                                    widths={{
                                                                        assetWidth: columns[1].width,
                                                                        descriptionWidth: columns[2].width,
                                                                        defaultValueWidth: columns[3].width,
                                                                    }}
                                                                />
                                                            )}
                                                                                                                        {attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG && (
                                                                <SingleFieldValueComponent
                                                                    attribute={attribute}
                                                                    getFieldDetails={(value) => {
                                                                        handlePrimaryObjectModifier({ response: value?.fieldName, uniqueKey: value?.uniqueKey })
                                                                        handleAttributes({
                                                                            id: attribute?.id,
                                                                            value,
                                                                            dispatch,
                                                                            attributes: logTemplateAttributes,
                                                                        });
                                                                        setAssetSearchString("");
                                                                        handleSetPage({ page: 1, key: "asset" });
                                                                    }
                                                                    }
                                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                                    assets={assetSearchString?.length ? assetSearchData : serverResponse?.assets?.data}
                                                                    handleMoreData={assets.totalPageCount === paginations["asset"]?.page ? null : handleLoadMoreData}
                                                                    isEdit={isEdit}
                                                                    handleDynamicSearch={handleDynamicSearch}
                                                                    widths={{
                                                                        assetWidth: columns[1].width,
                                                                        descriptionWidth: columns[2].width,
                                                                        defaultValueWidth: columns[3].width,
                                                                    }}
                                                                />
                                                            )}
                                                            {attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_MULTIPLE_CHOICE && (
                                                                <MultipleFieldValueComponent
                                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                                    handlePrimaryObjectModifier={handlePrimaryObjectModifier}
                                                                    handleDeleteKeyFromPrimaryObject={handleDeleteKeyFromPrimaryObject}
                                                                    attribute={attribute}
                                                                    getFieldDetails={(value) => {
                                                                     
                                                                        handleAttributes({
                                                                            id: attribute?.id,
                                                                            value,
                                                                            dispatch,
                                                                            attributes: logTemplateAttributes,
                                                                        });
                                                                        setAssetSearchString("");
                                                                        handleSetPage({ page: 1, key: "asset" });

                                                                    }
                                                                    }
                                                                    handleMoreData={assets.totalPageCount === paginations["asset"]?.page ? null : handleLoadMoreData}
                                                                    isEdit={isEdit}
                                                                    assets={assetSearchString?.length ? assetSearchData : serverResponse?.assets?.data}
                                                                    handleDynamicSearch={handleDynamicSearch}
                                                                    widths={{
                                                                        assetWidth: columns[1].width,
                                                                        descriptionWidth: columns[2].width,
                                                                        defaultValueWidth: columns[3].width,
                                                                    }}
                                                                />
                                                            )}
                                                            {attribute?.type === "dropdown" && (
                                                                <MultipleFieldValueComponent
                                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                                    handlePrimaryObjectModifier={handlePrimaryObjectModifier}
                                                                    handleDeleteKeyFromPrimaryObject={handleDeleteKeyFromPrimaryObject}
                                                                    attribute={attribute}
                                                                    getFieldDetails={(value) => {
                                                                        handleAttributes({
                                                                            id: attribute?.id,
                                                                            value,
                                                                            dispatch,
                                                                            attributes: logTemplateAttributes,
                                                                        });
                                                                        setAssetSearchString("");
                                                                        handleSetPage({ page: 1, key: "asset" });
                                                                    }
                                                                    }
                                                                    assets={assetSearchString?.length ? assetSearchData : serverResponse?.assets?.data}
                                                                    handleMoreData={assets.totalPageCount === paginations["asset"]?.page ? null : handleLoadMoreData}
                                                                    isEdit={isEdit}
                                                                    handleDynamicSearch={handleDynamicSearch}
                                                                    widths={{
                                                                        assetWidth: columns[1].width,
                                                                        descriptionWidth: columns[2].width,
                                                                        defaultValueWidth: columns[3].width,
                                                                    }}
                                                                />
                                                            )}
                                                            {attribute?.type === "date" && (
                                                                <SingleFieldValueComponent
                                                                    attribute={attribute}
                                                                    getFieldDetails={(value) => {
                                                                      
                                                                        handlePrimaryObjectModifier({ response: value?.fieldName, uniqueKey: value?.uniqueKey })
                                                                        handleAttributes({
                                                                            id: attribute?.id,
                                                                            value,
                                                                            dispatch,
                                                                            attributes: logTemplateAttributes,
                                                                        });
                                                                        setAssetSearchString("");
                                                                        handleSetPage({ page: 1, key: "asset" });
                                                                    }
                                                                    }
                                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                                    assets={assetSearchString?.length ? assetSearchData : serverResponse?.assets?.data}
                                                                    isEdit={isEdit}
                                                                    handleMoreData={assets.totalPageCount === paginations["asset"]?.page ? null : handleLoadMoreData}
                                                                    handleDynamicSearch={handleDynamicSearch}
                                                                    widths={{
                                                                        assetWidth: columns[1].width,
                                                                        descriptionWidth: columns[2].width,
                                                                        defaultValueWidth: columns[3].width,
                                                                    }}
                                                                />
                                                            )}
                                                            {attribute?.type === "checkboxes" && (
                                                                <MultipleFieldValueComponent
                                                                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                                                    handlePrimaryObjectModifier={handlePrimaryObjectModifier}
                                                                    handleDeleteKeyFromPrimaryObject={handleDeleteKeyFromPrimaryObject}
                                                                    attribute={attribute}
                                                                    getFieldDetails={(value) => {
                                                                        handleAttributes({
                                                                            id: attribute?.id,
                                                                            value,
                                                                            dispatch,
                                                                            attributes: logTemplateAttributes,
                                                                        });
                                                                        setAssetSearchString("");
                                                                        handleSetPage({ page: 1, key: "asset" });
                                                                    }
                                                                    }
                                                                    assets={assetSearchString?.length ? assetSearchData : serverResponse?.assets?.data}
                                                                    isEdit={isEdit}
                                                                    handleMoreData={assets.totalPageCount === paginations["asset"]?.page ? null : handleLoadMoreData}
                                                                    handleDynamicSearch={handleDynamicSearch}
                                                                    widths={{
                                                                        assetWidth: columns[1].width,
                                                                        descriptionWidth: columns[2].width,
                                                                        defaultValueWidth: columns[3].width,
                                                                    }}
                                                                />
                                                            )}


                                                            {/* Attribute Type Container */}
                                                            <div
                                                                style={{ width: columns[4].width }}
                                                                className={Styles.template_table_col_type_container}
                                                            >
                                                                {attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG ? (
                                                                    <div style={{ display: "flex", flexDirection: "column", gap: "4px", width: "100%", position: "relative" }}>
                                                                        <div
                                                                            onClick={() =>
                                                                                setOpenLogToTagModeDropdownId(
                                                                                    openLogToTagModeDropdownId === attribute?.id ? null : attribute?.id
                                                                                )
                                                                            }
                                                                            style={{
                                                                                display: "flex",
                                                                                alignItems: "center",
                                                                                justifyContent: "space-between",
                                                                                gap: "4px",
                                                                                border: "1px solid #c1c0c0",
                                                                                borderRadius: "6px",
                                                                                padding: "8px 8px",
                                                                                cursor: "pointer",
                                                                                color: "#0A5FFF",
                                                                                fontSize: "14px",
                                                                                fontWeight: 520,
                                                                                background: "#fff",
                                                                            }}
                                                                        >
                                                                            <span>
                                                                                {attribute?.tagMode === "saveToTag"
                                                                                    ? (attribute?.tagName || "Log to Tag")
                                                                                    : "Normal"}
                                                                            </span>
                                                                            <span style={{ fontSize: "10px" }}>▾</span>
                                                                        </div>

                                                                        {openLogToTagModeDropdownId === attribute?.id && (
                                                                            <>
                                                                                <div
                                                                                    onClick={() => setOpenLogToTagModeDropdownId(null)}
                                                                                    style={{ position: "fixed", inset: 0, zIndex: 9 }}
                                                                                />
                                                                                <div
                                                                                    style={{
                                                                                        position: "absolute",
                                                                                        top: "calc(100% + 2px)",
                                                                                        left: 0,
                                                                                        background: "#fff",
                                                                                        border: "1px solid #E0E0E0",
                                                                                        borderRadius: "6px",
                                                                                        boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
                                                                                        zIndex: 10,
                                                                                        minWidth: "140px",
                                                                                    }}
                                                                                >
                                                                                    <div
                                                                                        onClick={() => {
                                                                                            handleLogToTagAttributeUpdate({
                                                                                                attributeId: attribute?.id,
                                                                                                updatedFields: { tagMode: "normal", tagId: null, tagName: null },
                                                                                            });
                                                                                            setOpenLogToTagModeDropdownId(null);
                                                                                        }}
                                                                                        style={{ padding: "8px 12px", cursor: "pointer", fontSize: "13px" }}
                                                                                    >
                                                                                        Normal
                                                                                    </div>
                                                                                    <div
                                                                                        onClick={() => {
                                                                                            handleLogToTagAttributeUpdate({
                                                                                                attributeId: attribute?.id,
                                                                                                updatedFields: { tagMode: "saveToTag" },
                                                                                            });
                                                                                            setOpenLogToTagModeDropdownId(null);
                                                                                            handleOpenLogToTagPicker(attribute?.id);
                                                                                        }}
                                                                                        style={{ padding: "8px 12px", cursor: "pointer", fontSize: "13px" }}
                                                                                    >
                                                                                        Log to Tag
                                                                                    </div>
                                                                                </div>
                                                                            </>
                                                                        )}
                                                                    </div>
                                                                ) : (
                                                                    <p className={Styles.template_table_col_type}>
                                                                        {attribute?.attributeName}
                                                                    </p>
                                                                )}
                                                            </div>
                                                             {columns[5].visibility && <div style={{ 
                                                                            width: columns[5].width,
                                                                            display: 'flex',
                                                                            justifyContent: 'center',
                                                                            alignItems: 'center' 
                                                                            }} 
                                                                            
                                                                        className={Styles.template_table_col}>
                                                                        <ClonosRadioAndCheckbox
                                                                        label=""
                                                                        isLabel={true}
                                                                        uniqueKey={attribute?.id}
                                                                        isChecked={attribute?.isMandatory ? true : false}
                                                                        
                                                                        handleGetValues={({ uniqueKey, updatedValue }) =>
                                                                            handleIsMandatory({
                                                                              uniqueKey,
                                                                              isChecked: updatedValue 
                                                                            })
                                                                          }
                                                                          
                                                                    />

                                                                </div>

                                                             }

                                                            {/* Set Points Container */}
                                                            {columns[6].visibility && <div
                                                                className={Styles.template_table_set_points_container}
                                                                style={{ width: columns[6].width }}
                                                            >
                                                                {/* <ClonosRadioAndCheckbox
                                                                    label="Add Set Points"
                                                                    isLabel={true}
                                                                    uniqueKey={attribute?.id}
                                                                    isChecked={attribute?.isSetpoints ? true : false}
                                                                    handleGetValues={(props) => handleAddSetPoints({ ...props, isChecked: attribute?.isSetpoints })}
                                                                    isMandatory={attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER ? true : false}
                                                                    disabled={attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_NUMBER ? false : true}
                                                                /> */}

                                                                  
                                                                    <LuSettings2
                                                                        onClick={() => {

                                                                            if (attribute?.type !== 'number' && attribute?.type !== CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) return;
                                                                            handleAddSetPoints({uniqueKey: attribute.id});
                                                                        }}
                                                                        style={{
                                                                            cursor: (attribute?.type === 'number' || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) ? 'pointer' : 'not-allowed',
                                                                            opacity: (attribute?.type === 'number' || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG) ? 1 : 0.4,
                                                                            color: existingSetPointKeys.has(attribute.id) ? '#2C4E87' : '#6885B1', 
                                                                            fontSize: "20px",
                                                                            
                                                                        }}
                                                                        title={
                                                                            (attribute?.type === 'number' || attribute?.type === CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_LOG_TO_TAG)
                                                                                ? existingSetPointKeys.has(attribute.id)
                                                                                    ? 'Already Configured'
                                                                                    : 'Configure Set Points'
                                                                                : 'Only available for number type'
                                                                        }
                                                                        size={'26px'}
                                                                    />


                                                                {/* {
                                                                    attribute?.isSetpoints && <Scale
                                                                        minLimit={attribute?.setPoints?.minLimit}
                                                                        maxLimit={attribute?.setPoints?.maxLimit}
                                                                        safeOperatingLow={attribute?.setPoints?.safeOperatingLow}
                                                                        safeOperatingHigh={attribute?.setPoints?.safeOperatingHigh}
                                                                        bestBatchLow={attribute?.setPoints?.bestBatchLow}
                                                                        bestBatchHigh={attribute?.setPoints?.bestBatchHigh}
                                                                    />
                                                                } */}
                                                            </div>
                                                            }
                                                            {/* Actions Container  */}
                                                            <div
                                                                style={{ width: columns[7].width }}
                                                                className={Styles.template_table_col_action_container}
                                                            >
                                                                <TemplateRowActions
                                                                    isImage={false}
                                                                    isNote={false}
                                                                    attribute={attribute}
                                                                    handleGetValues={lcHandleGetValues}
                                                                    uniqueKey="templateRowActions"
                                                                    attributes={logTemplateAttributes}
                                                                    uploadedAttributesFiles={uploadedAttributesFiles}
                                                                    handleDeleteKeyFromPrimaryObject={handleDeleteKeyFromPrimaryObject}
                                                                    handleRemoveAttribute={handleRemoveAttribute}
                                                                />
                                                            </div>
                                                        </div>
                                                    )}
                                                </Draggable>
                                            );
                                        })}
                                    {provider.placeholder}
                                </div>
                            )}
                        </Droppable>
                    </div>
                </DragDropContext>
            </div>
            <Modal
                isOpen={isSetPointsOpenModal}
                closeModalMethod={setIsSetPointsOpenModal}
            >
                <div
                    className={Styles.set_points_container}
                >
                    <header className={Styles.set_points_header}>
                        <span></span>
                        <span>Add Threshold Value</span>
                        <CloseIcon onClick={() => setIsSetPointsOpenModal(false)} />
                    </header>
                    <Threshold
                        handleClose={() => setIsSetPointsOpenModal(false)}
                        uniqueKey={activeAttributeDetails?.uniqueKey}
                        handleGetValues={handleSetSetPoints}
                        isEdit={isEdit}
                    />
                </div>
            </Modal>

            <Modal
                isOpen={isLogToTagPickerModalOpen}
                closeModalMethod={setIsLogToTagPickerModalOpen}
            >
                <div style={{ width: "700px", maxWidth: "90vw", background: "#fff", borderRadius: "12px", boxShadow: "0 8px 30px rgba(0,0,0,0.2)", overflow: "hidden" }}>
                    <header style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px", background: "#fff" }}>
                        <span style={{ fontSize: "17px", fontWeight: 600, color: "#1a1a1a" }}>Select Log Tag</span>
                        <div style={{ position: "absolute", right: "20px", top: "50%", transform: "translateY(-50%)" }}>
                            <CloseIcon onClick={() => setIsLogToTagPickerModalOpen(false)} />
                        </div>
                    </header>
                    <div style={{ padding: "0 20px 16px", background: "#fff" }}>
                        <input
                            placeholder="Search log tag..."
                            value={logToTagSearchString}
                            onChange={(e) => {
                                setLogToTagSearchString(e.target.value);
                                fetchLogToTagTags(e.target.value);
                            }}
                            style={{ width: "100%", padding: "10px 12px", border: "1px solid #D9D9D9", borderRadius: "6px", fontSize: "14px", outline: "none", boxSizing: "border-box", background: "#fff" }}
                        />
                    </div>
                    <div style={{ padding: "0 20px 20px", maxHeight: "420px", overflowY: "auto", background: "#fff" }}>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr auto", padding: "10px 12px", fontSize: "12px", fontWeight: 600, color: "#6B7280", background: "#F7F9FC", borderRadius: "6px", position: "sticky", top: 0 }}>
                            <span>TAG</span>
                            <span>ACTION</span>
                        </div>
                        {isLogToTagTagsLoading && (
                            <div style={{ padding: "20px", textAlign: "center", color: "#8a8a8a" }}>Loading...</div>
                        )}
                        {!isLogToTagTagsLoading && logToTagTagsData?.length === 0 && (
                            <div style={{ padding: "20px", textAlign: "center", color: "#8a8a8a" }}>No LOG tags found</div>
                        )}
                        {!isLogToTagTagsLoading && logToTagTagsData?.map((tag) => (
                            <div key={tag.id} style={{ display: "grid", gridTemplateColumns: "1fr auto", alignItems: "center", padding: "14px 12px", borderBottom: "1px solid #F0F0F0", fontSize: "14px" }}>
                                <span>{tag.name}</span>
                                <button
                                    onClick={() => handleSelectLogToTagTag(tag)}
                                    style={{ background: "#06337E", color: "#fff", border: "none", borderRadius: "6px", padding: "8px 20px", fontSize: "13px", fontWeight: 500, cursor: "pointer" }}
                                >
                                    Select
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </Modal>
        </>
    );
};

export default memo(TemplateAttributesTable);
