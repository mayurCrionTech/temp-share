import { memo, useEffect, useState } from "react";
import Styles from "./SingleFieldValueComponent.module.css";
import ClonosInput from "../../../../../../components/CommonComponents/ClonosInput/ClonosInput";
import DynamicDropdown from "../../../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown";
import { assetDropdownStaticData } from "../../../../../../Constants/StaticData";
import { doGetApiCall } from "../../../../../../utils/ClonosApi";
import AppUrl from "../../../../../../utils/AppUrl";
import { CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE, CLONOS_GLOBAL_TIME_ZONE_UTC } from "../../../../../../Constants/Constant";
import { determineDateFormat, handleClientDateInConfiguredTimeZone, handleServerDateInConfiguredTimeZone, modifyString } from "../../../../../../utils/clonosCommon";

/**
 * Component for handling a single field value in a form.
 * @param {Object} attributes - Additional attributes for the component.
 * @param {Function} getFieldDetails - Function to update field details.
 * @param {Object} attribute - Object containing field details.
 * @param {Function} handleGetErrorActivatorInformation - Function to handle error information.
 * @returns {JSX.Element} - JSX Element for rendering a single field value.
 */
const SingleFieldValueComponent = ({
    getFieldDetails,
    attribute,
    handleGetErrorActivatorInformation,
    assets,
    handleMoreData,
    isEdit = false,
    handleDynamicSearch,
    widths
}) => {

    /**
     * Handles changes in the field name or field value.
     * @param {Object} e - Event object containing updated values and metadata.
     */
    const handleChange = (e) => {
      
        // if (!e?.updatedValue) return;
        let value = e.updatedValue;
        // if (e?.type === modifyString(CLONOS_GLOBAL_TEMPLATE_ATTRIBUTE_DATE, "capitalize")) {
        //     if (determineDateFormat(e?.updatedValue) === CLONOS_GLOBAL_TIME_ZONE_UTC) {
        //         const lcValue = handleClientDateInConfiguredTimeZone({ dateString: e?.updatedValue, parseType: "object" });
        //         value = `${lcValue?.year}-${lcValue?.month}-${lcValue?.day}`
        //     } else {
        //         value = handleServerDateInConfiguredTimeZone({ dateString: e?.updatedValue })
        //     }
        // }
        // else {
        //     value = e?.updatedValue;
        // };
        getFieldDetails({ ...attribute, [e?.name]: value, ["uniqueKey"]: e?.uniqueKey, isTyping: e?.isTyping });
    };

    return (
        <>
            <div
                style={{ width: widths?.assetWidth }}
                className={Styles.asset_container}>
                <DynamicDropdown
                    label="Asset"
                    isLabel={false}
                    uniqueKey={"asset"}
                    isActivator={true}
                    data={assets}
                    heading={"Select from Asset Library"}
                    placeholder={"Search"}
                    isSearchable={true}
                    isCheckbox={false}
                    isDynamicLoad={handleMoreData ? true : false}
                    isMandatory={false}
                    defaultValue={(attribute?.asset?.assetName?.length && isEdit) && [{ "name": attribute?.asset?.assetName || attribute?.asset?.name }]}
                    handleMoreData={handleMoreData}
                    handleGetValues={(props) => {
                        getFieldDetails({ ...attribute, uniqueKey: props.uniqueKey, asset: props?.updatedValue[0], "isTyping": true })
                    }}
                    handleDynamicSearch={handleDynamicSearch}
                />

            </div>
            {/* Input for capturing the field name */}
            <div
                style={{ width: widths?.descriptionWidth }}
                className={Styles.fieldNameTaker}>
                <ClonosInput
                    value={attribute?.fieldName || ""}
                    name="fieldName"
                    limit={100}
                    placeholder="Add Name"
                    uniqueKey={attribute?.id || ""}
                    isMandatory={true}
                    handleGetValues={(props) => {
                        const isTyping = (attribute?.fieldName?.length !== props?.updatedValue?.length && props?.updatedValue !== null) ? true : false;
                        handleChange({ ...props, isTyping });
                    }}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    ariaLabel="Field Name Input"
                    isDebounce={true}
                />
            </div>

            {/* Input for capturing the field value */}
            <div
                style={{ width: widths?.defaultValueWidth }}
                className={Styles.fieldValueTaker}
            >
                <ClonosInput
                    value={attribute?.fieldValue || ""}
                    name="fieldValue"
                    limit={attribute?.attributeName === "number" ? 20 : 500}
                    type={attribute?.attributeName}
                    placeholder={`Add ${attribute?.attributeName}`}
                    uniqueKey={attribute?.id || ""}
                    handleGetValues={(props) => {
                        const isTyping = (attribute?.fieldValue?.length !== props?.updatedValue?.length && props?.updatedValue !== null) ? true : false;
                        handleChange({ ...props, isTyping });
                    }}
                    ariaLabel="Field Value Input"
                    isDebounce={true}
                />
            </div>
        </>
    );
};

export default memo(SingleFieldValueComponent);
