import React, { useEffect, useState } from 'react'
import Styles from "./Threshold.module.css"
import ClonosInput from '../../../../../components/CommonComponents/ClonosInput/ClonosInput';
import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
import ClonosRadioAndCheckbox from '../../../../../components/CommonComponents/ClonosRadio&Checkbox/ClonosRadio&Checkbox';
import Scale from '../Scale/Scale';
import { ClonosButton } from '../../../../../components/CommonComponents/Button/Button';
import { useLocation } from 'react-router-dom';
import { doGetApiCall, doPatchApiCall } from '../../../../../utils/ClonosApi';
import AppUrl from '../../../../../utils/AppUrl';


/**
 * Threshold component for managing threshold limits and their associated values.
 * This component allows users to set and modify the following threshold parameters:
 * - Minimum Limit
 * - Maximum Limit
 * - critical Minimum Limit
 * - critical Maximum Limit
 * - Safe Operating Low Limit
 * - Safe Operating High Limit
 * - Best Batch Low Limit
 * - Best Batch High Limit
 * 
 * It utilizes local state to manage the values of these parameters, and integrates
 * with the `useFieldsChecker` hook for error handling and primary object modifications.
 * The component also provides a mechanism to retrieve updated values via the
 * `handleGetValues` function passed as a prop.
 * 
 * @param {Object} param0 - Component props
 * @param {string} param0.uniqueKey - Unique identifier for the threshold instance
 * @param {Function} param0.handleClose - Function to close the threshold component
 * @param {Function} param0.handleGetValues - Function to retrieve the current threshold values
 * @returns {JSX.Element} Rendered Threshold component
 */

const Threshold = ({ uniqueKey, handleClose, handleGetValues,isEdit }) => {
    const { handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleGetUpdatedPrimaryObject } = useFieldsChecker();
    const [minLimit, setMinLimit] = useState('');
    const [maxLimit, setMaxLimit] = useState('');
    const [criticalMinLimit,setCriticalMinLimit]=useState('')
    const [criticalMaxLimit,setCriticalMaxLimit]=useState('')
    const [safeOperatingLow, setSafeOperatingLow] = useState(null);
    const [safeOperatingHigh, setSafeOperatingHigh] = useState(null);
    const [bestBatchLow, setBestBatchLow] = useState(null);
    const [bestBatchHigh, setBestBatchHigh] = useState(null);
    const [lcValues, setLcValues] = useState({});
    const LOCATION =useLocation()
    const [originalLimits, setOriginalLimits] = useState({
    minLimit: '',
    maxLimit: '',
    criticalMinLimit: '',
    criticalMaxLimit: '',
    });

    const [errorsExist, setErrorsExist] = useState(false);

    const handleValidateLimits = ({
        minLimit,
        safeOperatingLow,
        criticalMinLimit,
        criticalMaxLimit,
        bestBatchLow,
        bestBatchHigh,
        safeOperatingHigh,
        maxLimit,
        uniqueKey
    }) => {

        // Helper function to check if a value is valid (not null, undefined, or empty)
        const isValidInput = (value) => value !== null && value !== undefined && value !== '' && value !== NaN;

        // Minimum Limit validations
        if (uniqueKey === "minLimit") {
            if (isValidInput(minLimit) && isValidInput(safeOperatingLow) && minLimit >= safeOperatingLow) {
                return "Minimum Limit must be less than Safe Operating Limit - Low.";
            }
            if (isValidInput(minLimit) && isValidInput(bestBatchLow) && minLimit >= bestBatchLow) {
                return "Minimum Limit must be less than Best Batch Limit - Low.";
            }
            if (isValidInput(minLimit) && isValidInput(bestBatchHigh) && minLimit >= bestBatchHigh) {
                return "Minimum Limit must be less than Best Batch Limit - High.";
            }
            if (isValidInput(minLimit) && isValidInput(safeOperatingHigh) && minLimit >= safeOperatingHigh) {
                return "Minimum Limit must be less than Safe Operating Limit - High.";
            }
            if (isValidInput(minLimit) && isValidInput(maxLimit) && minLimit >= maxLimit) {
                return "Minimum Limit must be less than Maximum Limit.";
            }
             
            if (isValidInput(minLimit) && isValidInput(criticalMinLimit) && minLimit <= criticalMinLimit) {
                return "Minimum Limit must be greater than Critical Minimum Limit.";
            }
            
        }
        
        //critical Minimum Limit validations

        if(uniqueKey== "criticalMinLimit"){

            if (isValidInput(criticalMinLimit) && isValidInput(minLimit) && criticalMinLimit >= minLimit) {
                return "Critical Minimum Limit  must be less than Minimum limit";
            }
       
            if (isValidInput(criticalMinLimit) && isValidInput(criticalMaxLimit) && criticalMinLimit >= criticalMaxLimit) {
                return "Critical Minimum Limit  must be less than Critical Maximum Limit.";
            } 

        }
        
       //critical Maximum Limit validations

        if(uniqueKey== "criticalMaxLimit"){

            if (isValidInput(criticalMaxLimit) && isValidInput(maxLimit) && criticalMaxLimit <= maxLimit) {
                return "Critical Maximum Limit  must be greater than Maximum limit";
            }
          
            if (isValidInput(criticalMaxLimit) && isValidInput(criticalMinLimit) && criticalMinLimit >= criticalMaxLimit) {
                return "Critical Maximum Limit  must be greater than Critical Minimum Limit.";
            }
            
        }

        // Safe Operating Limit - Low validations
        if (uniqueKey === "safeOperatingLow") {
            if (isValidInput(safeOperatingLow) && isValidInput(minLimit) && safeOperatingLow <= minLimit) {
                return "Safe Operating Limit - Low must be greater than Minimum Limit.";
            }
            if (isValidInput(safeOperatingLow) && isValidInput(bestBatchLow) && safeOperatingLow >= bestBatchLow) {
                return "Safe Operating Limit - Low must be less than Best Batch Limit - Low.";
            }
            if (isValidInput(safeOperatingLow) && isValidInput(bestBatchHigh) && safeOperatingLow >= bestBatchHigh) {
                return "Safe Operating Limit - Low must be less than Best Batch Limit - High.";
            }
            if (isValidInput(safeOperatingLow) && isValidInput(safeOperatingHigh) && safeOperatingLow >= safeOperatingHigh) {
                return "Safe Operating Limit - Low must be less than Safe Operating Limit - High.";
            }
            if (isValidInput(safeOperatingLow) && isValidInput(maxLimit) && safeOperatingLow >= maxLimit) {
                return "Safe Operating Limit - Low must be less than Maximum Limit.";
            }
        }

        // Best Batch Limit - Low validations
        if (uniqueKey === "bestBatchLow") {
            if (isValidInput(bestBatchLow) && isValidInput(minLimit) && bestBatchLow <= minLimit) {
                return "Best Batch Limit - Low must be greater than Minimum Limit.";
            }
            if (isValidInput(bestBatchLow) && isValidInput(safeOperatingLow) && bestBatchLow <= safeOperatingLow) {
                return "Best Batch Limit - Low must be greater than Safe Operating Limit - Low.";
            }
            if (isValidInput(bestBatchLow) && isValidInput(bestBatchHigh) && bestBatchLow >= bestBatchHigh) {
                return "Best Batch Limit - Low must be less than Best Batch Limit - High.";
            }
            if (isValidInput(bestBatchLow) && isValidInput(safeOperatingHigh) && bestBatchLow >= safeOperatingHigh) {
                return "Best Batch Limit - Low must be less than Safe Operating Limit - High.";
            }
            if (isValidInput(bestBatchLow) && isValidInput(maxLimit) && bestBatchLow >= maxLimit) {
                return "Best Batch Limit - Low must be less than Maximum Limit.";
            }
        }

        // Best Batch Limit - High validations
        if (uniqueKey === "bestBatchHigh") {
            if (isValidInput(bestBatchHigh) && isValidInput(minLimit) && bestBatchHigh <= minLimit) {
                return "Best Batch Limit - High must be greater than Minimum Limit.";
            }
            if (isValidInput(bestBatchHigh) && isValidInput(safeOperatingLow) && bestBatchHigh <= safeOperatingLow) {
                return "Best Batch Limit - High must be greater than Safe Operating Limit - Low.";
            }
            if (isValidInput(bestBatchHigh) && isValidInput(bestBatchLow) && bestBatchHigh <= bestBatchLow) {
                return "Best Batch Limit - High must be greater than Best Batch Limit - Low.";
            }
            if (isValidInput(bestBatchHigh) && isValidInput(safeOperatingHigh) && bestBatchHigh >= safeOperatingHigh) {
                return "Best Batch Limit - High must be less than Safe Operating Limit - High.";
            }
            if (isValidInput(bestBatchHigh) && isValidInput(maxLimit) && bestBatchHigh >= maxLimit) {
                return "Best Batch Limit - High must be less than Maximum Limit.";
            }
        }

        // Safe Operating Limit - High validations
        if (uniqueKey === "safeOperatingHigh") {
            if (isValidInput(safeOperatingHigh) && isValidInput(minLimit) && safeOperatingHigh <= minLimit) {
                return "Safe Operating Limit - High must be greater than Minimum Limit.";
            }
            if (isValidInput(safeOperatingHigh) && isValidInput(safeOperatingLow) && safeOperatingHigh <= safeOperatingLow) {
                return "Safe Operating Limit - High must be greater than Safe Operating Limit - Low.";
            }
            if (isValidInput(safeOperatingHigh) && isValidInput(bestBatchLow) && safeOperatingHigh <= bestBatchLow) {
                return "Safe Operating Limit - High must be greater than Best Batch Limit - Low.";
            }
            // if (isValidInput(safeOperatingHigh) && isValidInput(bestBatchHigh) && safeOperatingHigh >= bestBatchHigh) {
            //     return "Safe Operating Limit - High must be less than Best Batch Limit - High.";
            // }
            if (isValidInput(safeOperatingHigh) && isValidInput(maxLimit) && safeOperatingHigh >= maxLimit) {
                return "Safe Operating Limit - High must be less than Maximum Limit.";
            }
        }

        // Maximum Limit validations
        if (uniqueKey === "maxLimit") {
            if (isValidInput(maxLimit) && isValidInput(minLimit) && maxLimit <= minLimit) {
                return "Maximum Limit must be greater than Minimum Limit.";
            }
            if (isValidInput(maxLimit) && isValidInput(safeOperatingLow) && maxLimit <= safeOperatingLow) {
                return "Maximum Limit must be greater than Safe Operating Limit - Low.";
            }
            if (isValidInput(maxLimit) && isValidInput(bestBatchLow) && maxLimit <= bestBatchLow) {
                return "Maximum Limit must be greater than Best Batch Limit - Low.";
            }
            if (isValidInput(maxLimit) && isValidInput(bestBatchHigh) && maxLimit <= bestBatchHigh) {
                return "Maximum Limit must be greater than Best Batch Limit - High.";
            }
            if (isValidInput(maxLimit) && isValidInput(safeOperatingHigh) && maxLimit <= safeOperatingHigh) {
                return "Maximum Limit must be greater than Safe Operating Limit - High.";
            }
            if (isValidInput(maxLimit) && isValidInput(criticalMaxLimit) && maxLimit >= criticalMaxLimit ) {
                     return "Maximum Limit must be less than Critical Max Limit";
    }
    
        }
        // If all validations pass, return true
        return true;
    };

    // Handle input changes
    const handleMinChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit: props.updatedValue, maxLimit, safeOperatingLow, safeOperatingHigh,criticalMinLimit,criticalMaxLimit, bestBatchLow, bestBatchHigh, uniqueKey: props.uniqueKey })
      
        if (message?.length) {
            setErrorsExist(true);
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setErrorsExist(false); // No errors
            setMinLimit(value);
        }
    };
     // Handle input changes
     const handleCrticalMinChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit, criticalMinLimit : props.updatedValue, maxLimit, safeOperatingLow, safeOperatingHigh, bestBatchLow, bestBatchHigh, criticalMaxLimit, uniqueKey: props.uniqueKey })
      
        if (message?.length) {
            setErrorsExist(true);
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setErrorsExist(false); // No errors
            setCriticalMinLimit(value);
        }
    };

    const handleCrticalMaxChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit, criticalMinLimit , maxLimit, safeOperatingLow, safeOperatingHigh, bestBatchLow, bestBatchHigh, criticalMaxLimit: props.updatedValue , uniqueKey: props.uniqueKey })
    
        if (message?.length) {
            setErrorsExist(true);
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setErrorsExist(false); // No errors
            setCriticalMaxLimit(value);
        }
    };



    const handleMaxChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit, maxLimit: props.updatedValue, safeOperatingLow, safeOperatingHigh, bestBatchLow, bestBatchHigh,criticalMinLimit,criticalMaxLimit ,uniqueKey: props.uniqueKey })
        if (message?.length) {
            setErrorsExist(true);
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setErrorsExist(false); // No errors
            setMaxLimit(value);
        }
    };

    const handleSafeOperatingLowChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit, maxLimit, safeOperatingLow: props.updatedValue, safeOperatingHigh, bestBatchLow, bestBatchHigh, uniqueKey: props.uniqueKey })
        if (message?.length) {
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setSafeOperatingLow(value);
        }
    };

    const handleSafeOperatingHighChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit, maxLimit, safeOperatingLow, safeOperatingHigh: props.updatedValue, bestBatchLow, bestBatchHigh, uniqueKey: props.uniqueKey })
        if (message?.length) {
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setSafeOperatingHigh(value);
        };
    }



    // best batch
    const handleBestBatchLowChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit, maxLimit, safeOperatingLow, safeOperatingHigh, bestBatchLow: props.updatedValue, bestBatchHigh, uniqueKey: props.uniqueKey })
        if (message?.length) {
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setBestBatchLow(value)
        }
    };

    const handleBestBatchHighChange = (props) => {
        const value = parseFloat(props.updatedValue); // Use parseFloat to handle decimals and negative values
        const primaryObjectElement = handleGetUpdatedPrimaryObject()?.[props.uniqueKey];  // Get the element instence properties.
        const message = handleValidateLimits({ minLimit, maxLimit, safeOperatingLow, safeOperatingHigh, bestBatchLow, bestBatchHigh: props.updatedValue, uniqueKey: props.uniqueKey })
        if (message?.length) {
            primaryObjectElement?.errorSetterMethod(message);
            primaryObjectElement?.errorActivatorMethod(true);
        } else {
            setBestBatchHigh(value)
        }
    };


    // Function to handle changes in the threshold values
const handleChange = (props) => {
    // Update local state with the new value based on the unique key
    setLcValues(prev => ({ ...prev, [props.uniqueKey]: props.updatedValue }));
};

// Function to retrieve the current values of the threshold fields
const lcHandleGetValues = () => {
    // First update the state values
    handleGetValues && handleGetValues({
        uniqueKey,
        minLimit,
        maxLimit,
        criticalMinLimit,
        criticalMaxLimit,
        safeOperatingLow,
        safeOperatingHigh,
        bestBatchLow,
        bestBatchHigh
    });
   
    // Use a small timeout to ensure state updates have completed
    setTimeout(() => {
        // // Validate values before creating payload
        // const validMinLimit = isNaN(minLimit) ? 0 : minLimit; // Default to 1 if NaN
        // const validMaxLimit = isNaN(maxLimit) ? 999999999999999 : maxLimit; // Default to 100 if NaN
        
        const payload = {
            "dataSets": [{
                _id: uniqueKey,
                upperBound: maxLimit,
                lowerBound: minLimit,
                criticalLowerBound: criticalMinLimit,
                criticalUpperBound: criticalMaxLimit
            }]
        };
   
        if (!isEdit) {
            handleGetValues && handleGetValues(payload); 
            return;
          }
        
        const logId = LOCATION?.state?.logId;
        const structureId = LOCATION?.state?.structureId;
        const url = `/logs/${logId}/logStructures/${structureId}/templateSetPoints`;
        
        doPatchApiCall({url, payload}).then((res) => console.log(res, "logtempres"));
    }, 100); // A small delay to ensure state updates have completed
};


const isValidNumber = (val) => val !== '' && !isNaN(val) && val !== null;

// Check if both values in a pair are filled correctly
const isMinPairFilled = isValidNumber(minLimit) && isValidNumber(maxLimit);
const isCriticalPairFilled = isValidNumber(criticalMinLimit) && isValidNumber(criticalMaxLimit);

// Check for partially filled pairs (invalid case)
const isMinPairIncomplete = (isValidNumber(minLimit) || isValidNumber(maxLimit)) && !isMinPairFilled;
const isCriticalPairIncomplete = (isValidNumber(criticalMinLimit) || isValidNumber(criticalMaxLimit)) && !isCriticalPairFilled;

// At least one fully filled valid pair
const hasAtLeastOneFullValidPair = isMinPairFilled || isCriticalPairFilled;

const isUnchanged =
  minLimit === originalLimits.minLimit &&
  maxLimit === originalLimits.maxLimit &&
  criticalMinLimit === originalLimits.criticalMinLimit &&
  criticalMaxLimit === originalLimits.criticalMaxLimit;

// Final condition
const isButtonDisabled =
  !hasAtLeastOneFullValidPair || isMinPairIncomplete || isCriticalPairIncomplete || errorsExist || isUnchanged;





// Array of threshold fields configurations
const thresholdFields = [
    {
        uniqueKey: "minLimit", // Unique key for identifying the field
        handleGetValuesCheckbox: handleChange, // Function to handle checkbox changes
        label: "Minimum Limit", // Label for the input field
        value: minLimit, // Current value of the field
        disabled: true, // Whether the field is disabled
        handleGetValuesInput: handleMinChange, // Function to handle input changes
        isMandatory: true, // Whether the field is mandatory
        errorMessage: "Please enter some value.", // Error message for validation
        isChecked: false // Initial checked state for the checkbox
    },
    {
        uniqueKey: "criticalMinLimit", // Unique key for identifying the field
        handleGetValuesCheckbox: handleChange, // Function to handle checkbox changes
        label: "Critical Minimum Limit", // Label for the input field
        value: criticalMinLimit, // Current value of the field
        disabled: true, // Whether the field is disabled
        handleGetValuesInput: handleCrticalMinChange, // Function to handle input changes
        isMandatory: true, // Whether the field is mandatory
        errorMessage: "Please enter some value.", // Error message for validation
        isChecked: false // Initial checked state for the checkbox
    },
    {
        uniqueKey: "criticalMaxLimit",
        handleGetValuesCheckbox: handleChange,
        label: "Critical Maximum Limit",
        value: criticalMaxLimit,
        disabled: true, // This field is disabled
        handleGetValuesInput: handleCrticalMaxChange,
        isMandatory: true,
        errorMessage: "Please enter some value.",
        isChecked: false
    },
    
    // {
    //     uniqueKey: "safeOperatingLow",
    //     handleGetValuesCheckbox: handleChange,
    //     label: "Safe Operating Limit - Low",
    //     value: safeOperatingLow,
    //     disabled: lcValues?.safeOperatingLow, // Disable based on local values state
    //     handleGetValuesInput: handleSafeOperatingLowChange,
    //     isMandatory: lcValues?.safeOperatingLow ? true : false, // Determine if mandatory based on local state
    //     errorMessage: "Please enter some value.",
    //     isChecked: false
    // },
    // {
    //     uniqueKey: "bestBatchLow",
    //     handleGetValuesCheckbox: handleChange,
    //     label: "Best Batch Limit - Low",
    //     value: bestBatchLow,
    //     disabled: lcValues?.bestBatchLow,
    //     handleGetValuesInput: handleBestBatchLowChange,
    //     isMandatory: lcValues?.bestBatchLow ? true : false,
    //     errorMessage: "Please enter some value.",
    //     isChecked: false
    // },
    // {
    //     uniqueKey: "bestBatchHigh",
    //     handleGetValuesCheckbox: handleChange,
    //     label: "Best Batch Limit - High",
    //     value: bestBatchHigh,
    //     disabled: lcValues?.bestBatchHigh,
    //     handleGetValuesInput: handleBestBatchHighChange,
    //     isMandatory: lcValues?.bestBatchHigh ? true : false,
    //     errorMessage: "Please enter some value.",
    //     isChecked: false
    // },
    // {
    //     uniqueKey: "safeOperatingHigh",
    //     handleGetValuesCheckbox: handleChange,
    //     label: "Safe Operating Limit - High",
    //     value: safeOperatingHigh,
    //     disabled: lcValues?.safeOperatingHigh,
    //     handleGetValuesInput: handleSafeOperatingHighChange,
    //     isMandatory: lcValues?.safeOperatingHigh ? true : false,
    //     errorMessage: "Please enter some value.",
    //     isChecked: false
    // },
    {
        uniqueKey: "maxLimit",
        handleGetValuesCheckbox: handleChange,
        label: "Maximum Limit",
        value: maxLimit,
        disabled: true, // This field is disabled
        handleGetValuesInput: handleMaxChange,
        isMandatory: true,
        errorMessage: "Please enter some value.",
        isChecked: false
    },
];

// Effect to reset the threshold values when the component is unmounted
useEffect(() => {
  const structureId = LOCATION?.state?.structureId;

  if(structureId){
        doGetApiCall({ url: `${AppUrl.getLogStructure}/${structureId}` }).then((res) => {
        const dataSets = res?.data?.result?.[0]?.dataSets || [];
        
        const matchedField = dataSets.find(
        (item) => item._id === uniqueKey
        );

        if (matchedField) {
        setMinLimit(matchedField.lowerBound ?? "");
        setMaxLimit(matchedField.upperBound ?? "");
        setCriticalMinLimit(matchedField.criticalLowerBound ?? "");
        setCriticalMaxLimit(matchedField.criticalUpperBound ?? "");
        // add others if needed
        }
  });
  }else {
    // Set default values when structureId is not available (new template)
    
    const defaultValues = {
      minLimit: '',
      maxLimit: '',
      criticalMinLimit: '',
      criticalMaxLimit: '',
    };

    setOriginalLimits(defaultValues);
    setCriticalMinLimit("");
    setCriticalMaxLimit("");
    setMinLimit('')
    setMaxLimit('')
  }
  
  //     return () => {
//         // Reset all state values to their initial state
//         setMinLimit("");
//         setMaxLimit("");
//         setCriticalMinLimit("");
//         setCriticalMinLimit("");
//         setSafeOperatingLow("");
//         setSafeOperatingHigh("");
//         setBestBatchLow("");
//         setBestBatchHigh("");
//         setLcValues({}); // Clear local values
//     };
}, [uniqueKey]);


    return (
        <div className={Styles.threshold_container}>

            <Scale
                minLimit={minLimit}
                maxLimit={maxLimit}
                criticalMinLimit={criticalMinLimit}
                criticalMaxLimit={criticalMaxLimit}
                safeOperatingLow={safeOperatingLow}
                safeOperatingHigh={safeOperatingHigh}
                bestBatchLow={bestBatchLow}
                bestBatchHigh={bestBatchHigh}
            />

            {/* Inputs */}
            < div className={Styles.inputs_container} >
                {
                    thresholdFields?.map(item => {
                        return <div key={item?.uniqueKey} className={Styles.input_container}>
                            <div className={Styles.info_and_controller_container}>
                                <ClonosRadioAndCheckbox
                                    isChecked={item?.isChecked ? true : null}
                                    uniqueKey={item?.uniqueKey}
                                    type="checkbox"
                                    labelPosition="right"
                                    handleGetValues={item?.handleGetValuesCheckbox}
                                />
                                <span className={`${Styles.label} ${item?.disabled ? Styles.active : Styles.disabled}`}>{item?.label}:</span>
                            </div>

                            <ClonosInput
                                containerStyle={{ width: "300px" }}
                                disabled={!item?.disabled}
                                value={item?.value}
                                uniqueKey={item?.uniqueKey}
                                type="number"
                                handleGetValues={props => {
                                    handlePrimaryObjectModifier({ uniqueKey: props?.uniqueKey, response: props?.updatedValue });
                                    item?.handleGetValuesInput(props)
                                }}
                                debounceDelay={2000}
                                isDebounce={true}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                // isMandatory={item?.isMandatory}
                                // errorMessage={item?.errorMessage}
                            />
                        </div>
                    })
                }
            </div >
            <footer className={Styles.footer}>
                <ClonosButton
                    style={{ color: "red", borderColor: "red" }}
                    onClick={handleClose}
                >Cancel</ClonosButton>

                <ClonosButton
                    variant="filled"
                    onClick={lcHandleGetValues}
                    isDisabled={isButtonDisabled}
                >Save</ClonosButton>

            </footer>
        </div >
    );
};

export default Threshold