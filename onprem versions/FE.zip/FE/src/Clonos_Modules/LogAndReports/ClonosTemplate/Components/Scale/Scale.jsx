//old code
// import React, { useEffect, useState } from 'react'
// import Styles from "./Scale.module.css"

// /**
//  * Scale component dynamically renders a segmented scale with color-coded sections
//  * representing ranges between the provided minLimit, maxLimit, safeOperating limits, and bestBatch limits.
//  * 
//  * @param {Object} props - The props for the Scale component.
//  * @param {number} props.minLimit - The minimum limit value for the scale.
//  * @param {number} props.maxLimit - The maximum limit value for the scale.
//  * @param {number} props.safeOperatingLow - The lower boundary of the safe operating range.
//  * @param {number} props.safeOperatingHigh - The upper boundary of the safe operating range.
//  * @param {number} props.bestBatchLow - The lower boundary of the best batch range.
//  * @param {number} props.bestBatchHigh - The upper boundary of the best batch range.
//  * 
//  * The component computes the percentage width for each range and adjusts the styles accordingly.
//  * It also adds markers at specific points on the scale to indicate boundaries.
//  */
// const Scale = ({
//     minLimit,
//     maxLimit,
//     safeOperatingLow,
//     safeOperatingHigh,
//     bestBatchLow,
//     bestBatchHigh
// }) => {

//     // State to hold the percentage values for each segment in the scale.
//     const [scaleSegments, setScaleSegment] = useState({
//         minToSafeLowPercent: 0,           // Percentage from minLimit to safeOperatingLow
//         safeLowToBestLowPercent: 0,       // Percentage from safeOperatingLow to bestBatchLow
//         bestLowToBestHighPercent: 0,      // Percentage from bestBatchLow to bestBatchHigh
//         bestHighToSafeHighPercent: 0,     // Percentage from bestBatchHigh to safeOperatingHigh
//         safeHighToMaxPercent: 0,          // Percentage from safeOperatingHigh to maxLimit
//     });

//     // Destructuring the segments from state for ease of use in JSX.
//     const {
//         minToSafeLowPercent,
//         safeLowToBestLowPercent,
//         bestLowToBestHighPercent,
//         bestHighToSafeHighPercent,
//         safeHighToMaxPercent
//     } = scaleSegments;

//     /**
//      * Generates the scale points based on the provided min and max limits.
//      * Dynamically calculates the points dividing the range into equal steps.
//      */
//     const scaleSteps = 6; // Number of divisions on the scale
//     let scale = [];
//     scale = Array.from({ length: scaleSteps + 1 }, (_, i) =>
//         Math.round(minLimit + (i * (maxLimit - minLimit)) / scaleSteps)
//     );

//     useEffect(() => {
//         /**
//          * Computes the percentage width for each segment in the scale based on the provided limits.
//          * If a value isn't provided, it falls back to the min or max limits.
//          */
//         const lcSafeOperatingLow = safeOperatingLow ? safeOperatingLow : minLimit;
//         const lcBestBatchLow = bestBatchLow ? bestBatchLow : lcSafeOperatingLow;
//         const lcSafeOperatingHigh = safeOperatingHigh ? safeOperatingHigh : maxLimit;
//         const lcBestBatchHigh = bestBatchHigh ? bestBatchHigh : lcSafeOperatingHigh;

//         setScaleSegment(prev => {
//             return {
//                 minToSafeLowPercent: ((lcSafeOperatingLow - minLimit) / (maxLimit - minLimit)) * 100,
//                 safeLowToBestLowPercent: ((lcBestBatchLow - lcSafeOperatingLow) / (maxLimit - minLimit)) * 100,
//                 bestLowToBestHighPercent: ((lcBestBatchHigh - lcBestBatchLow) / (maxLimit - minLimit)) * 100,
//                 bestHighToSafeHighPercent: ((lcSafeOperatingHigh - lcBestBatchHigh) / (maxLimit - minLimit)) * 100,
//                 safeHighToMaxPercent: ((maxLimit - lcSafeOperatingHigh) / (maxLimit - minLimit)) * 100,
//             }
//         });
//     }, [minLimit, maxLimit, safeOperatingLow, safeOperatingHigh, bestBatchLow, bestBatchHigh]);

//     return (
//         <div className={Styles.scale}>
//             {/* Render each segment with corresponding color */}
//             <div className={`${Styles.scale_segment} ${Styles.red}`} style={{ width: `${minToSafeLowPercent}%` }}></div>
//             <div className={`${Styles.scale_segment} ${(safeOperatingLow) ? Styles.blue : Styles.red}`} style={{ width: `${safeLowToBestLowPercent}%` }}></div>
//             <div className={`${Styles.scale_segment} ${(bestBatchLow || bestBatchHigh) ? Styles.green : (safeOperatingLow || safeOperatingHigh) ? Styles.blue : Styles.red}`} style={{ width: `${bestLowToBestHighPercent}%` }}></div>
//             <div className={`${Styles.scale_segment} ${(safeOperatingHigh) ? Styles.blue : Styles.red}`} style={{ width: `${bestHighToSafeHighPercent}%` }}></div>
//             <div className={`${Styles.scale_segment} ${Styles.red}`} style={{ width: `${safeHighToMaxPercent}%` }}></div>

//             {/* Render scale points */}
//             {
//                 scale.map((step, index) => (
//                     <div
//                         key={index}
//                         className={Styles.scale_point}
//                         style={{ left: `${(index / scaleSteps) * 100}%` }}
//                     >
//                         {step}
//                     </div>
//                 ))
//             }

//             {/* Markers indicating various limit points */}
//             <div
//                 className={`${Styles.marker} ${Styles.low}`}
//                 style={{
//                     left: `${((safeOperatingLow - minLimit - 1) / (maxLimit - minLimit)) * 100}%`,
//                 }}
//             />
//             <div
//                 className={`${Styles.marker} ${Styles.high}`}
//                 style={{
//                     left: `${((safeOperatingHigh - minLimit - 1) / (maxLimit - minLimit)) * 100}%`,
//                 }}
//             />
//             <div
//                 className={`${Styles.marker} ${Styles.low}`}
//                 style={{
//                     left: `${((bestBatchLow - minLimit - 1) / (maxLimit - minLimit)) * 100}%`,
//                 }}
//             />
//             <div
//                 className={`${Styles.marker} ${Styles.high}`}
//                 style={{
//                     left: `${((bestBatchHigh - minLimit - 1) / (maxLimit - minLimit)) * 100}%`,
//                 }}
//             />
//         </div>
//     )
// }

// export default Scale;




//work code -final
// import React, { useEffect, useState } from 'react';
// import Styles from './Scale.module.css';
 
// /**
//  * Scale component dynamically renders a segmented scale with color-coded sections
//  * representing ranges between the provided minLimit, maxLimit, safeOperating limits, and bestBatch limits.
//  * 
//  * @param {Object} props - The props for the Scale component.
//  * @param {number} props.minLimit - The minimum limit value for the scale.
//  * @param {number} props.maxLimit - The maximum limit value for the scale.
//  * @param {number} props.criticalMinLimit - The critical minimum limit value for the scale.
//  * @param {number} props.criticalMaxLimit - The critical maximum limit value for the scale.
 
//  * The component computes the percentage width for each range and adjusts the styles accordingly.
//  * It also adds markers at specific points on the scale to indicate boundaries.
//  */

// const Scale = ({
//     minLimit,
//     maxLimit,
//     criticalMinLimit,
//     criticalMaxLimit
// }) => {
//     const [scaleSegments, setScaleSegments] = useState({
//         beforeCriticalMinPercent: 0,    // Percentage from visualStart to criticalMinLimit
//         criticalMinToMinPercent: 0,     // Percentage from criticalMinLimit to minLimit
//         minToMaxPercent: 0,             // Percentage from minLimit to maxLimit
//         maxToCriticalMaxPercent: 0,     // Percentage from maxLimit to crticalMaxLimit
//         afterCriticalMaxPercent: 0      // Percentage from criticalMaxLimit to visualEnd
//     });

//     // Dynamic visual range calculation based on critical limits
//     const paddingRange = 20; // padding for visual range
//     const visualStart = Math.min(criticalMinLimit, 0) - paddingRange; 
//     const visualEnd = Math.max(criticalMaxLimit, 100) + paddingRange;
//     const fullRange = visualEnd - visualStart;

//     // Generate scale steps
    
//     const scaleSteps = 6;
//     const scale = Array.from({ length: scaleSteps + 1 }, (_, i) =>
//         Math.round(visualStart + (i * fullRange) / scaleSteps)
//     );

//     useEffect(() => {
//           /**
//      * Calculates the percentage width of each scale segment based on the given limits.
//      * These percentages are used to visually render the scale bar.
//      * Each segment represents a specific range:
//      * - From visualStart to criticalMinLimit
//      * - From criticalMinLimit to minLimit
//      * - From minLimit to maxLimit
//      * - From maxLimit to criticalMaxLimit
//      * - From criticalMaxLimit to visualEnd
//      */
//         setScaleSegments({
//             beforeCriticalMinPercent: ((criticalMinLimit - visualStart) / fullRange) * 100,
//             criticalMinToMinPercent: ((minLimit - criticalMinLimit) / fullRange) * 100,
//             minToMaxPercent: ((maxLimit - minLimit) / fullRange) * 100,
//             maxToCriticalMaxPercent: ((criticalMaxLimit - maxLimit) / fullRange) * 100,
//             afterCriticalMaxPercent: ((visualEnd - criticalMaxLimit) / fullRange) * 100
//         });
//     }, [minLimit, maxLimit, criticalMinLimit, criticalMaxLimit, visualStart, visualEnd, fullRange]);

//     const getLeftPosition = (value) => ((value - visualStart) / fullRange) * 100;
    
//     const shouldRenderValue = (val) => typeof val === 'number' && !isNaN(val);


//     const {
//         beforeCriticalMinPercent,
//         criticalMinToMinPercent,
//         minToMaxPercent,
//         maxToCriticalMaxPercent,
//         afterCriticalMaxPercent
//     } = scaleSegments;

//     return (
//         <div className={Styles.scale}>
//             {/* Segments */}
//             <div className={`${Styles.scale_segment} ${Styles.darkRed}`} style={{ width: `${beforeCriticalMinPercent}%` }} />
//             <div className={`${Styles.scale_segment} ${Styles.orange}`} style={{ width: `${criticalMinToMinPercent}%` }} />
//             <div className={`${Styles.scale_segment} ${Styles.green}`} style={{ width: `${minToMaxPercent}%` }} />
//             <div className={`${Styles.scale_segment} ${Styles.orange}`} style={{ width: `${maxToCriticalMaxPercent}%` }} />
//             <div className={`${Styles.scale_segment} ${Styles.darkRed}`} style={{ width: `${afterCriticalMaxPercent}%` }} />

//            {/* Regular Scale Points */}
//             {/* {scale.map((step, index) => {
//                 if (index > 0 && index < scaleSteps) {
//                     return (
//                         <div
//                             key={`step-${index}`}
//                             className={Styles.scale_point}
//                             style={{ left: `${(index / scaleSteps) * 100}%` }}
//                         >
//                             {step}
//                         </div>
//                     );
//                 }
//                 return null;
//             })} */}

//             {/* Marker Points with Values */}
//              {[criticalMinLimit, minLimit, maxLimit, criticalMaxLimit]
//                 .filter(value => typeof value === 'number' && !isNaN(value))
//                 .map((value, index) => (
//                     <div
//                         key={`marker-value-${index}`}
//                         className={`${Styles.scale_point_Top} ${Styles.marker_point}`}
//                         style={{ left: `${getLeftPosition(value)}%` }}
//                     >
//                         {value}
//                     </div>
//                 ))}         


          
//             {/* Markers */}
//             {shouldRenderValue(minLimit) && (
//                 <div className={`${Styles.marker} ${Styles.low}`} style={{ left: `${getLeftPosition(minLimit)}%` }} />
//             )}
//             {shouldRenderValue(maxLimit) && (
//                 <div className={`${Styles.marker} ${Styles.high}`} style={{ left: `${getLeftPosition(maxLimit)}%` }} />
//             )}
//             {shouldRenderValue(criticalMinLimit) && (
//                 <div className={`${Styles.marker} ${Styles.low}`} style={{ left: `${getLeftPosition(criticalMinLimit)}%` }} />
//             )}
//             {shouldRenderValue(criticalMaxLimit) && (
//                 <div className={`${Styles.marker} ${Styles.high}`} style={{ left: `${getLeftPosition(criticalMaxLimit)}%` }} />
//             )}

//         </div>
//     );
// };

// export default Scale;



import React, { useEffect, useState } from 'react';
import Styles from './Scale.module.css';
 
/**
 * Enhanced Scale component dynamically renders a segmented scale with color-coded sections
 * representing ranges between the provided minLimit, maxLimit, criticalMinLimit, and criticalMaxLimit.
 * The component adapts to show appropriate segments based on which limit values are provided.
 * 
 * @param {Object} props - The props for the Scale component.
 * @param {number} [props.minLimit] - The minimum limit value for the scale.
 * @param {number} [props.maxLimit] - The maximum limit value for the scale.
 * @param {number} [props.criticalMinLimit] - The critical minimum limit value for the scale.
 * @param {number} [props.criticalMaxLimit] - The critical maximum limit value for the scale.
 */

const Scale = ({
    minLimit,
    maxLimit,
    criticalMinLimit,
    criticalMaxLimit
}) => {
    // Determine which values are provided
    const hasMinMax = typeof minLimit === 'number' && !isNaN(minLimit) &&  typeof maxLimit === 'number' && !isNaN(maxLimit);
    
    const hasCriticalLimits = typeof criticalMinLimit === 'number' && !isNaN(criticalMinLimit) && typeof criticalMaxLimit === 'number' && !isNaN(criticalMaxLimit);
    
    const [scaleSegments, setScaleSegments] = useState({
        beforeCriticalMinPercent: 0,    // Percentage from visualStart to criticalMinLimit
        criticalMinToMinPercent: 0,     // Percentage from criticalMinLimit to minLimit
        minToMaxPercent: 0,             // Percentage from minLimit to maxLimit
        maxToCriticalMaxPercent: 0,     // Percentage from maxLimit to crticalMaxLimit
        afterCriticalMaxPercent: 0      // Percentage from criticalMaxLimit to visualEnd
    });

    // Dynamic visual range calculation based on provided limits
    const paddingRange = 20; // padding for visual range
    
    // Determine scale boundaries based on available values
    let visualStart, visualEnd;
    
    if (hasMinMax && hasCriticalLimits) {
        // All values provided - use critical limits for visual range
        visualStart = Math.min(criticalMinLimit, minLimit, 0) - paddingRange;
        visualEnd = Math.max(criticalMaxLimit, maxLimit, 100) + paddingRange;
    } else if (hasMinMax) {
        // Only min/max provided
        visualStart = Math.min(minLimit, 0) - paddingRange;
        visualEnd = Math.max(maxLimit, 100) + paddingRange;
    } else if (hasCriticalLimits) {
        // Only critical limits provided
        visualStart = Math.min(criticalMinLimit, 0) - paddingRange;
        visualEnd = Math.max(criticalMaxLimit, 100) + paddingRange;
    } else {
        // No values provided - fallback to default range
        visualStart = 0 - paddingRange;
        visualEnd = 100 + paddingRange;
    }
    
    const fullRange = visualEnd - visualStart;

    // Generate scale steps
    const scaleSteps = 6;
    const scale = Array.from({ length: scaleSteps + 1 }, (_, i) =>
        Math.round(visualStart + (i * fullRange) / scaleSteps)
    );

    useEffect(() => {
        // Calculate segments based on which limit values are provided
        if (hasMinMax && hasCriticalLimits) {
            // All values provided - show all segments
            setScaleSegments({
                beforeCriticalMinPercent: ((criticalMinLimit - visualStart) / fullRange) * 100,
                criticalMinToMinPercent: ((minLimit - criticalMinLimit) / fullRange) * 100,
                minToMaxPercent: ((maxLimit - minLimit) / fullRange) * 100,
                maxToCriticalMaxPercent: ((criticalMaxLimit - maxLimit) / fullRange) * 100,
                afterCriticalMaxPercent: ((visualEnd - criticalMaxLimit) / fullRange) * 100
            });
        } else if (hasMinMax) {
            // Only min/max provided - show three segments
            setScaleSegments({
                beforeCriticalMinPercent: 0,
                criticalMinToMinPercent: ((minLimit - visualStart) / fullRange) * 100,
                minToMaxPercent: ((maxLimit - minLimit) / fullRange) * 100,
                maxToCriticalMaxPercent: ((visualEnd - maxLimit) / fullRange) * 100,
                afterCriticalMaxPercent: 0
            });
        } else if (hasCriticalLimits) {
            // Only critical limits provided - show three segments
            setScaleSegments({
                beforeCriticalMinPercent: ((criticalMinLimit - visualStart) / fullRange) * 100,
                criticalMinToMinPercent: 0,
                minToMaxPercent: ((criticalMaxLimit - criticalMinLimit) / fullRange) * 100,
                maxToCriticalMaxPercent: 0,
                afterCriticalMaxPercent: ((visualEnd - criticalMaxLimit) / fullRange) * 100
            });
        } else {
            // No values provided - show default single segment
            setScaleSegments({
                beforeCriticalMinPercent: 0,
                criticalMinToMinPercent: 0,
                minToMaxPercent: 100,
                maxToCriticalMaxPercent: 0,
                afterCriticalMaxPercent: 0
            });
        }
    }, [minLimit, maxLimit, criticalMinLimit, criticalMaxLimit, visualStart, visualEnd, fullRange, hasMinMax, hasCriticalLimits]);

    const getLeftPosition = (value) => ((value - visualStart) / fullRange) * 100;
    
    const shouldRenderValue = (val) => typeof val === 'number' && !isNaN(val);

    const {
        beforeCriticalMinPercent,
        criticalMinToMinPercent,
        minToMaxPercent,
        maxToCriticalMaxPercent,
        afterCriticalMaxPercent
    } = scaleSegments;

    return (
        <div className={Styles.scale}>
            {/* Segments - rendered conditionally based on available limits */}
            {hasCriticalLimits && (
                <div 
                    className={`${Styles.scale_segment} ${Styles.darkRed}`} 
                    style={{ width: `${beforeCriticalMinPercent}%` }} 
                />
            )}
            
            {hasMinMax && hasCriticalLimits && (
                <div 
                    className={`${Styles.scale_segment} ${Styles.orange}`} 
                    style={{ width: `${criticalMinToMinPercent}%` }} 
                />
            )}
            
            {hasMinMax && !hasCriticalLimits && (
                <div 
                    className={`${Styles.scale_segment} ${Styles.orange}`} 
                    style={{ width: `${criticalMinToMinPercent}%` }} 
                />
            )}
            
            <div 
                className={`${Styles.scale_segment} ${Styles.green}`} 
                style={{ width: `${minToMaxPercent}%` }} 
            />
            
            {hasMinMax && !hasCriticalLimits && (
                <div 
                    className={`${Styles.scale_segment} ${Styles.orange}`} 
                    style={{ width: `${maxToCriticalMaxPercent}%` }} 
                />
            )}
            
            {hasMinMax && hasCriticalLimits && (
                <div 
                    className={`${Styles.scale_segment} ${Styles.orange}`} 
                    style={{ width: `${maxToCriticalMaxPercent}%` }} 
                />
            )}
            
            {hasCriticalLimits && (
                <div 
                    className={`${Styles.scale_segment} ${Styles.darkRed}`} 
                    style={{ width: `${afterCriticalMaxPercent}%` }} 
                />
            )}

            {/* Marker Points with Values */}
            {[
                hasMinMax && minLimit,
                hasMinMax && maxLimit,
                hasCriticalLimits && criticalMinLimit,
                hasCriticalLimits && criticalMaxLimit
            ]
                .filter(value => typeof value === 'number' && !isNaN(value))
                .map((value, index) => (
                    <div
                        key={`marker-value-${index}`}
                        className={`${Styles.scale_point_Top} ${Styles.marker_point}`}
                        style={{ left: `${getLeftPosition(value)}%` }}
                    >
                        {value}
                    </div>
                ))}         

            {/* Markers */}
            {shouldRenderValue(minLimit) && (
                <div className={`${Styles.marker} ${Styles.low}`} style={{ left: `${getLeftPosition(minLimit)}%` }} />
            )}
            {shouldRenderValue(maxLimit) && (
                <div className={`${Styles.marker} ${Styles.high}`} style={{ left: `${getLeftPosition(maxLimit)}%` }} />
            )}
            {shouldRenderValue(criticalMinLimit) && (
                <div className={`${Styles.marker} ${Styles.low}`} style={{ left: `${getLeftPosition(criticalMinLimit)}%` }} />
            )}
            {shouldRenderValue(criticalMaxLimit) && (
                <div className={`${Styles.marker} ${Styles.high}`} style={{ left: `${getLeftPosition(criticalMaxLimit)}%` }} />
            )}
        </div>
    );
};

export default Scale;


