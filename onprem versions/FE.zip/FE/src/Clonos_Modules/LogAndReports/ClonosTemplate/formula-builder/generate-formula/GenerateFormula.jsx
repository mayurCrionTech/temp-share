import { Card } from "@mui/material"
import Styles from "./generate-formula.module.css"
import DynamicDropdown from "../../../../../components/CommonComponents/DynamicDropdown/DynamicDropdown"
import { useEffect, useState } from "react";
import { handleGetLogs, handleGetSingleLog } from "../../../../../utils/LogAndReportsMethods/LogMethods";
import { commonPageState, handleShowErrorAndWarning } from "../../../../../utils/clonosCommon";
import { ClonosButton } from "../../../../../components/CommonComponents/Button/Button";
import { handleAddConstantValue, handleAddField, handleAddOperation, handleClickBackspace, handleGenerateFormula, handleGetLogsDropdownData, handleGetTemplateVersionDataSetsDropdownData, handleIsOperationAllowed, handleValidateFormula } from "./generate-formula-manager";
import CloseIcon from "../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import CircleMinusIcon from "../../../../../resources/icons/static/CircleMinusIcon";
import BACKSPACESVG from "../../../../../resources/svgs/backspace.svg"
import ClonosSelect from "../../../../../components/CommonComponents/ClonosSelect/ClonosSelect";
import ClonosInput from "../../../../../components/CommonComponents/ClonosInput/ClonosInput";
import { useLocation, useNavigate } from "react-router-dom";
import useToggler from "../../../../../CustomHooks/TogglerHook";
import { useDispatch } from "react-redux";
import { UnAuthorizedModal } from "../../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal";
import ClonosConfirmationBox from "../../../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
const GenerateFormula = () => {
    const dispatch = useDispatch();
    const Location = useLocation();
    const Navigate = useNavigate();
    const [logs,setLogs] = useState({});
    const [dataSets,setDataSets] = useState({});
    const [isLoading,setIsLoading] = useToggler();
    const [fetchDataEntryLoder,setFetchDataEntryLoder] = useToggler();
    const [isFormulaValidated,setIsFormulaValidated] = useToggler({});
    const [showSkipFormulaDailog,setShowSkipFormulaDailog] = useToggler();
    const [showClearFormulaDailog,setShowClearFormulaDailog] = useToggler();
    const [lcFormulas,setLcFormulas] = useState([]);
    const operations = ["+","-","*","/","(",")","^"];
    const [selectedType,setSelectedType] = useState("");
    const [formulaParts,setFormulaParts] = useState([]);
    const [searchedLogs,setSearchedLogs] = useState({});
    const [searchedDataEntries,setSearchedDataEntries] = useState({});
    const [lcConstantValue,setLcConstantValue] = useState(0);
    const [lcFormulaStringArr,setLcFormulaStringArr] = useState([]);
    const [logsPagination,setLogsPagination] = useState(commonPageState);
    const [selectedReferenceField,setSelectedReferenceField] = useState({});

    const handleFetchMoreLogsOnScroll = () => {
        if(logs?.totalPageCount > logsPagination?.page){
            setLogsPagination(prev => ({...prev,page:prev.page + 1}))
        }
    }

    // const handleSearchLogs = (props) => {
    //     console.log(props,"searchprops")
    //     const {input} = props;
    //     if(input) {
    //         handleGetLogsDropdownData({setterMethod:setSearchedLogs,params:{...logsPagination,name:input}});
    //     } else {
    //         setSearchedLogs({})
    //     }
    // }

    const handleSearchLogs = (props) => {
        const { input } = props;
        if(input) {
            handleGetLogsDropdownData({
                setterMethod: setSearchedLogs,
                params: { ...logsPagination, page: 1, name: input } 
            });
        } else {
            setSearchedLogs({ data: [] });
        }
    };
 
    const handleSearchDataEntries = (props) => {
        const {input} = props;
        if (input) {
            try {
                // Create a case-insensitive regex from the input
                const regex = new RegExp(input, "i");
    
                // Filter the data based on the regex match
                setSearchedDataEntries({
                    ...dataSets,
                    data: dataSets?.data?.filter(entry => regex.test(entry?.fieldName))
                });
            } catch (error) {
                console.error("Invalid regex input:", error.message);
                // Optionally handle invalid regex gracefully
                setSearchedDataEntries({});
            }
        } else {
            setSearchedDataEntries({});
        }
    }

    useEffect(() => {
        handleGetLogsDropdownData({setterMethod:setLogs,params:logsPagination});
    },[logsPagination?.page,logsPagination?.limit])

    useEffect(() => {
        if(Location?.state?.structureId){
            setSelectedReferenceField({log:{name:Location?.state?.log?.logName,id:Location?.state?.log?.logId,structureId:Location?.state?.structureId}})
        }
    },[Location?.state?.structureId,isFormulaValidated])

    useEffect(() => {
        if(selectedReferenceField?.log?.structureId){
            handleGetTemplateVersionDataSetsDropdownData({setterMethod:setDataSets,structureId:selectedReferenceField?.log?.structureId,setIsLoading:setFetchDataEntryLoder})
        } else {
            setDataSets({});
        }
    },[selectedReferenceField?.log?.id])


    if(!Location?.state?.log?.logId) return <UnAuthorizedModal />
    return (
    <>
        <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem", overflowY: "auto" }}>
            <div className={Styles.f_b_container}>
                <div className={Styles.f_b_left_container}>
                    <h4>Formula Builder</h4>
                    <div className={Styles.f_b_formula_taker}>
                        <div className={Styles.f_b_f_t_1}>
                            {
                                formulaParts?.map(field => {
                                    return <div style={{background:!field?.isOperation ? "#F0F0EA":"none"}} className={Styles.f_b_f_t_1_tab}> 
                                        <p style={{color:field?.isOperation ? "#9333EB" : "#000"}} className={Styles.tab_field}>{field?.type === "reference" ? field.value?.name : field?.value}</p>
                                        {/* {!field?.isOperation ? <div className={Styles.cross}><CircleMinusIcon/></div> : <></>} */}
                                    </div>
                                })
                            }
                        </div>
                    </div>
                    <div className={Styles.f_b_validator_wrapper}>
                        <ClonosButton onClick={() => {
                            setShowClearFormulaDailog();
                        }}>Clear</ClonosButton>
                        <ClonosButton onClick={() => {
                            const isValid = handleValidateFormula({lcFormulaStringArr,formulaParts,setLcFormulas,setLcFormulaStringArr,setFormulaParts,setIsFormulaValidated});
                            if(!isValid) handleShowErrorAndWarning({dispatch,message:"Please enter valid formula",type:"error",showTime:"5000"})
                        }} variant="filled">Validate</ClonosButton>
                    </div>
                    <div className={Styles.f_b_preview_wrapper}>
                        {
                            lcFormulas?.map((formula,index) => {
                                return <div className={Styles.f_b_preview_item}>
                                <p>{formula?.previewFormulaString} </p>
                                <span onClick={() => setLcFormulas(lcFormulas.filter((value,i) => index !== i) )}><CircleMinusIcon/></span>
                            </div>
                            })
                        }
                    </div>
                    <div className={Styles.sbmt_wrapper}>
                        <ClonosButton loading={isLoading} isDisabled={!lcFormulas?.length || formulaParts?.length} onClick={() => handleGenerateFormula({lcFormulas,templateId:Location?.state?.templateId,setIsLoading,Navigate,dispatch})}>Generate Formula</ClonosButton>
                        <ClonosButton onClick={setShowSkipFormulaDailog}>Skip</ClonosButton>
                    </div>
                </div>
                <div className={Styles.f_b_right_container}>
                    <h4>Operation</h4>
                    <div className={Styles.f_b_operations_wrapper}>
                        {
                            operations?.map((operation) => {
                                return <div  key={operation} className={Styles.f_b_operation_item} onClick={() => handleIsOperationAllowed({operation,formulaParts,operations}) && handleAddOperation({operation,operations,formulaParts,lcFormulaStringArr,setterMethod:setFormulaParts,setLcFormulaStringArr})}>{operation}</div>
                            })
                        }
                        <div onClick={() => formulaParts?.length && lcFormulaStringArr?.length && handleClickBackspace({setFormulaParts,setLcFormulaStringArr})} className={`${Styles.f_b_operation_item} ${Styles.backspace_wrapper}`}><img src={BACKSPACESVG}/></div>
                    </div>
                    <div className={Styles.fields_wrapper}>
                    {formulaParts?.length >= 2 ? 
                    <>
                    <ClonosSelect
                        isLabel={true}
                        label="Select type"
                        placeholder="Select"
                        handleGetValues={(val) => setSelectedType(val?.updatedValue?.label)}
                        options={["Constant","Log Reference"]?.map(type => ({label:type,isNeeded:true}))}
                    />
                    {
                        selectedType === "Constant" ? 
                        <div className={Styles.constant_taker}>
                            <div style={{width:"70%"}}>
                            <ClonosInput
                                type="number"
                                isLabel={false}
                                name="constant"
                                uniqueKey="constant"
                                placeholder="Enter value"
                                handleGetValues={(val) => setLcConstantValue(val?.updatedValue)}
                            />
                            </div>
                        <ClonosButton  onClick={() => handleAddConstantValue({value:lcConstantValue,lcFormulaStringArr,formulaParts,setLcFormulaStringArr,setFormulaParts})}>Add</ClonosButton>
                        </div> :<></>
                    }</> : <></>}
                    {(selectedType === "Log Reference" || !formulaParts?.length) ?<> <DynamicDropdown
                        isLabel={true}
                        label="Select Log"
                        title={"Select Log"}
                        uniqueKey={"log"}
                        heading={"Select Log"}
                        placeholder={"Select"}
                        isSearchable={true}
                        isCheckbox={false}
                        disabled={formulaParts?.length < 2}
                        isDynamicLoad={logs?.totalPageCount > logsPagination?.page}
                        data={[...(searchedLogs?.data?.length ? searchedLogs?.data : logs?.data || [])]?.map(log => ({name:log?.name,id:log?.id,structureId:log?.structureId}))}
                        isActivator={true}
                        isMandatory={true}
                        errorMessage={"Please select the log!"}
                        defaultValue={[{name:Location?.state?.log?.logName,id:Location?.state?.log?.logId,structureId:Location?.state?.structureId}]}
                        handleDynamicSearch={(val) => handleSearchLogs(val)}
                        handleMoreData={() => handleFetchMoreLogsOnScroll()}
                        // handleGetValues={val => setSelectedReferenceField({log:val?.updatedValue[0]})}
                        handleGetValues={val =>
                        setSelectedReferenceField({
                            log: Array.isArray(val?.updatedValue) ? val.updatedValue[0] : null
                        })
                        }

                        handleGetErrorActivatorInformation={() => {}}
                    />
                    <DynamicDropdown
                        isLabel={true}
                        loading={fetchDataEntryLoder}
                        label="Select Dataset"
                        title={"Select Dataset"}
                        uniqueKey={"dataEntry"}
                        heading={"Select DataSet"}
                        placeholder={"Select"}
                        isSearchable={true}
                        isCheckbox={false}
                        // isDynamicLoad={false}
                        data={[...(searchedDataEntries?.data?.length ? searchedDataEntries?.data : dataSets?.data || [])]?.map(field => ({name:field?.fieldName,id:field?._id}))}
                        isActivator={true}
                        isMandatory={true}
                        noDataMessage="No datasets found of type number!"
                        value={selectedReferenceField?.dataEntry}
                        handleDynamicSearch={handleSearchDataEntries}
                        handleMoreData={() => {}}
                        errorMessage={"Please select the dataset"}
                        // handleGetValues={val => setSelectedReferenceField(prev => ({...prev,dataEntry:val?.updatedValue[0]}))}
                        handleGetValues={val =>
                        setSelectedReferenceField(prev => ({
                            ...prev,
                            dataEntry: Array.isArray(val?.updatedValue) ? val.updatedValue[0] : null
                        }))
                        }

                        handleGetErrorActivatorInformation={() => {}}
                    /> </>: <></>}
                    {(selectedReferenceField?.log?.id && selectedReferenceField?.dataEntry?.id) ? <div className={Styles.f_b_selected_fields_preview_wrapper}>
                        <p>{`${selectedReferenceField?.log?.name}-->${selectedReferenceField?.dataEntry?.name}`}</p>
                        <ClonosButton  onClick={() => handleAddField({field:{...selectedReferenceField,templateId:dataSets?.templateId},formulaParts,setSelectedReferenceField,setterMethod:setFormulaParts,setLcFormulaStringArr})}>Add Field</ClonosButton>
                    </div> : <></>}
                    </div>
                </div>
            </div>
        </Card>
        <ClonosConfirmationBox
            isOpen={showSkipFormulaDailog}
            closeModalMethod={setShowSkipFormulaDailog}
            rejectingMethod={() => {}}
            confirmingMethod={() => Navigate("/logs")}
            message={"Are you sure you want to skip formula building ?"}
            headerTitle={"Skip Formula"}
        />
        <ClonosConfirmationBox
            isOpen={showClearFormulaDailog}
            closeModalMethod={setShowClearFormulaDailog}
            rejectingMethod={() => {}}
            confirmingMethod={() => {
                setFormulaParts([]);
                setLcFormulaStringArr([]);
                setShowClearFormulaDailog();
            }}
            message={"Are you sure you want to Clear Formula ?"}
            headerTitle={"Clear Formula"}
        />
    </>)
}

export default GenerateFormula