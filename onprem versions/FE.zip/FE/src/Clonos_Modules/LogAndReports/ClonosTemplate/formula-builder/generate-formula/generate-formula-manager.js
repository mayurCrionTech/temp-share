import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../../Constants/Constant"
import AppUrl from "../../../../../utils/AppUrl"
import { doGetApiCall, doPatchApiCall, doPostApiCall, doPutApiCall } from "../../../../../utils/ClonosApi"
import { handleShowErrorAndWarning } from "../../../../../utils/clonosCommon"

// export const handleGetLogsDropdownData = ({setterMethod,params}) => {
//     doGetApiCall({url:AppUrl?.getLogs,params})
//     .then((res) => {
//         if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
//             const data = res?.data?.result;
//             const modifiedResponse = {...data,data:data?.data?.map(log => ({id:log?._id,name:log?.generalDetails?.name,structureId:log?.structureId}))}
//             setterMethod(prev => {
//                 const prevData = prev?.data?.length ? prev?.data : [];
//                 if(prevData?.length){
//                     const uniqueEntitiesObject = prevData.reduce((acc, entity) => {
//                         if (!acc[entity?.name]) {
//                             acc[entity?.name] = entity;
//                         }
//                         return acc;
//                     }, {});

//                     const newEntities = modifiedResponse?.data?.filter(entity => !uniqueEntitiesObject[entity?.name]);
//                     return {
//                         ...data,
//                         data: [...prevData, ...(newEntities || [])]
//                     }; 
//                 } else {
//                     return modifiedResponse
//                 }
//             })
//         }
//     })
//     .catch(err => console.error(err))
// }

export const handleGetLogsDropdownData = ({setterMethod,params}) => {
 
    doGetApiCall({url:AppUrl?.getFormulaLogs,params})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const data = res?.data?.result;
            const modifiedResponse = {...data,data:data?.data?.map(log => ({id:log?._id,name:log?.name,structureId:log?.structureId}))}
            setterMethod(prev => {
                const prevData = prev?.data?.length ? prev?.data : [];

                if (params?.page === 1) {
                    //  Fresh search — replace old data
                    return modifiedResponse;
                } else {
                    //  Paginated — append only new unique entries
                    const uniqueEntitiesObject = prevData.reduce((acc, entity) => {
                        if (!acc[entity?.name]) {
                            acc[entity?.name] = entity;
                        }
                        return acc;
                    }, {});

                    const newEntities = modifiedResponse?.data?.filter(
                        entity => !uniqueEntitiesObject[entity?.name]
                    );

                    return {
                        ...data,
                        data: [...prevData, ...(newEntities || [])],
                    };
                }
            });

        }
    })
    .catch(err => console.error(err))
}

export const handleGetTemplateVersionDataSetsDropdownData = ({setterMethod,structureId,params,setIsLoading}) => {
    setIsLoading && setIsLoading();
    doGetApiCall({url:`${AppUrl?.getLogVersionTemplateDataSets}/${structureId}`,params})
    .then((res) => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS){
            const dataSetsOfTypeNumber = res?.data?.result[0]?.dataSets?.filter((dataSet) => dataSet?.type === "number")
            setterMethod({data:dataSetsOfTypeNumber,templateId:res?.data?.result[0]?.templateId})
        }
    })
    .catch(err => console.error(err))
    .finally(() => setIsLoading && setIsLoading())
}


// export const handleIsOperationAllowed = ({operation,formulaParts,operations}) => {
//     const lastTyped = formulaParts[formulaParts?.length -1];
//     if(lastTyped?.value === "=" && operation !== "(") return false;
//     if(lastTyped.value === "(" && operations.includes(operation)) return false
//     if(!lastTyped?.isOperation && operation === "(") return false
//     if(operations?.includes(lastTyped?.value) && (operation !== "(")) return false
//     return true
// }
export const handleIsOperationAllowed = ({ operation, formulaParts, operations }) => {
    const lastTyped = formulaParts[formulaParts?.length - 1];
    const openParenthesesCount = formulaParts.filter((part) => part.value === "(").length;
    const closeParenthesesCount = formulaParts.filter((part) => part.value === ")").length;

    // Check if "=" is the last typed value and allow only "(" to follow
    if (lastTyped?.value === "=" && operation !== "(") return false;

    // Check if "(" can follow an operation or "="
    if (lastTyped?.value === "(" && operation !== "(" && operations.includes(operation)) return false;

    if(lastTyped?.value === ")" && operation === "(") return false

    // Disallow an opening parenthesis after a non-operation or closing parenthesis
    if (!lastTyped?.isOperation && operation === "(") return false;

    // Prevent closing parenthesis if no matching open parenthesis exists
    if (operation === ")" && openParenthesesCount <= closeParenthesesCount) return false;

    // Prevent closing parenthesis right after an operator
    if (operations.includes(lastTyped?.value) && lastTyped?.value !== ")" && operation === ")") return false;

    // Prevent multiple consecutive operators (excluding "(")
    // if (operations.includes(lastTyped?.value) && operation !== "(" && operation !== ")" && operations.includes(operation)) return false;

    // Prevent formula starting with invalid operators (except "(" or unary operators if applicable)
    // if (!lastTyped && operation !== "(") return false;

    return true;
};



export const handleAddOperation = ({operation,operations,lcFormulaStringArr,formulaParts,setterMethod,setLcFormulaStringArr}) => {
    if(!formulaParts?.length || !lcFormulaStringArr?.length) return false;
    const lastTyped = formulaParts[formulaParts?.length -1]?.value;
    if(operations?.includes(lastTyped) && operation !== "(" && operation !== ")" && lastTyped !== ")" && lastTyped !== "("){
        formulaParts[formulaParts?.length -1] = {isOperation:true,value:operation};
        lcFormulaStringArr[lcFormulaStringArr?.length -1] = operation
        setLcFormulaStringArr(lcFormulaStringArr)
        setterMethod([...formulaParts])
    } else {
        setterMethod(prev => ([...prev,{isOperation:true,value:operation}]));
        setLcFormulaStringArr(prev => ([...prev,operation]))
    }
}

export const handleAddField = ({field,formulaParts,setSelectedReferenceField,setterMethod,setLcFormulaStringArr}) => {
    if(formulaParts.length && !formulaParts[formulaParts.length -1].isOperation) return 
    if(field?.log?.id && field?.dataEntry?.id) {
            setterMethod(prev => {
                if(prev?.length > 0 ){
                    setLcFormulaStringArr(prevFields => ([...prevFields,`${field?.log?.name}-->${field?.dataEntry?.name}`]))
                    return [...prev,{value:{name:`${field?.log?.name}-->${field?.dataEntry?.name}`,logId:field?.log?.id,templateId:field?.templateId,dataEntryId:field?.dataEntry?.id},type:"reference"}]
                } else {
                    setLcFormulaStringArr([`${field?.log?.name}-->${field?.dataEntry?.name}`,"="])
                    return [...prev,{type:"reference",value:{name:`${field?.log?.name}-->${field?.dataEntry?.name}`,logId:field?.log?.id,templateId:field?.templateId,dataEntryId:field?.dataEntry?.id}},{isOperation:true,value:'=',type:"operator"}]
                }
            });
            
            setSelectedReferenceField(prev => ({...prev,dataEntry:null}))
    } else {
        return
    }
}


export const handleClickBackspace = ({setFormulaParts,setLcFormulaStringArr}) => {
    setFormulaParts(prev => {
        let temp = [...prev];
        if(temp.length > 2) temp.pop();
        else return []
        return temp
    })
    setLcFormulaStringArr(prev => {
        let temp = [...prev];
        if(temp.length > 2) temp.pop();
        else return []
        return temp
    })
}

export const handleValidateFormula = ({lcFormulaStringArr,formulaParts,setLcFormulas,setLcFormulaStringArr,setIsFormulaValidated,setFormulaParts}) => {
    const operators = ["+", "-", "*", "/"];
    let balance = 0; // Tracks parentheses balance
    let lastType = null; // Tracks last token type: "field", "operator", "parenthesis"
    if(!lcFormulaStringArr?.length) return false
    for (let i = 0; i < lcFormulaStringArr.length; i++) {
        const part = lcFormulaStringArr[i];
        if(i === 0 ) {
            if(operators.includes(part)){
                return false
            }
            lastType = "field"
        } else if(i === 1){
            if(part !== "="){
                return false
            }
            lastType = "operator"
        } else if (part === "(") {
            balance++;
            if (lastType === "field") {
                return false //"Error: Field cannot directly precede '('.";
            }
            lastType = "parenthesis";
        } else if (part === ")") {
            balance--;
            if (balance < 0) {
                return false  //"Error: Too many closing parentheses.";
            }
            if (lastType === "operator") {
                return false // "Error: Operator cannot directly precede ')'.";
            }
            lastType = "parenthesis";
        } else if (operators.includes(part) && i > 1) {
            if (!lastType || lastType === "operator" || lastType === "parenthesis" && lcFormulaStringArr[i - 1] !== ")") {
                return false // `Error: Operator '${part}' is not allowed here.`;
            }
            lastType = "operator";
        } else {
            // Assume anything else is a valid field
            if (lastType === "field") {
                return false // `Error: Field '${part}' cannot directly follow another field.`;
            }
            lastType = "field";
        }
    }

    if (balance !== 0) {
        return false // "Error: Unbalanced parentheses.";
    }

    if (lastType === "operator") {
        return false // "Error: Formula cannot end with an operator.";
    }
  
    
    const modifiedFormula = handleConvertFormula(formulaParts.slice(2));
 
    const formulaWithResultant = {_id : formulaParts[0]?.value?.dataEntryId,formula:{type:"formula",...modifiedFormula}}
    setLcFormulas(prev => ([...prev,{previewFormulaString:lcFormulaStringArr.join(" "),formula:formulaWithResultant}]));
    setFormulaParts([]);
    setLcFormulaStringArr([])
    setIsFormulaValidated();
    return true // "Valid formula.";
}



// export const handleConvertFormula = (formula) => {
//     const operators = ["+", "-", "*", "/", "^"];

//     function helper(elements) {
//         let obj = {};
//         let i = 0;

//         while (i < elements.length) {
//             const element = elements[i];

//             if (element?.value === "(") {
//                 // Find the matching closing parenthesis
//                 let start = i + 1;
//                 let balance = 1;

//                 while (balance > 0 && start < elements.length) {
//                     if (elements[start]?.value === "(") balance++;
//                     if (elements[start]?.value === ")") balance--;
//                     start++;
//                 }

//                 if (balance !== 0) throw new Error("Unbalanced parentheses");

//                 // Extract the subarray and process it recursively
//                 const subArray = elements.slice(i + 1, start - 1);
//                 const subObject = helper(subArray);

//                 // Assign to left or right
//                 if (!obj.left) {
//                     obj.left = subObject;
//                 } else {
//                     obj.right = subObject;
//                 }

//                 // Skip the processed part
//                 i = start - 1;
//             } else if (operators.includes(element?.value)) {
//                 // Assign operator
//                 if (!obj.operator) {
//                     obj.operator = element?.value;
//                 } else {
//                     // If an operator already exists, create a new object for nesting
//                     obj = {
//                         left: obj,
//                         operator: element?.value,
//                         right: null
//                     };
//                 }
//             } else {
//                 if (!obj.left) {
//                     obj.left = element;
//                 } else if (!obj.right) {
//                     obj.right = element;
//                 }
//             }
//             i++;
//         }

//         return obj;
//     }

//     return helper(formula);
// }


// const handleConvertFormula = (formula) => {
//     const operators = ["+", "-", "*", "/", "^"];
//     const operatorsWithPrecedence={
//         "+":{name:"add",precedence:1},
//         "-":{name:"subtract",precedence:1},
//         "*":{name:"multiply",precedence:2},
//         "/":{name:"divide",precedence:2},
//         "^":{name:"power",precedence:3}
//     }

//     function helper(elements) {
//         const outputStack = [];
//         const operatorStack = [];

//         const applyOperator = () => {
//             const operator = operatorStack.pop();
//             const right = outputStack.pop();
//             const left = outputStack.pop();
//             outputStack.push({
//                 left: left?.left || left?.right ? {...left,type:"formula"} : left,
//                 operation: operatorsWithPrecedence[operator?.value]?.name,
//                 right: right?.right || right?.left ? {...right,type:"formula"} : right,
//             });
//         };

//         let i = 0;
//         while (i < elements.length) {
//             const element = elements[i];

//             if (element?.value === "(") {
//                 // Find the matching closing parenthesis
//                 let start = i + 1;
//                 let balance = 1;
//                 while (balance > 0 && start < elements.length) {
//                     if (elements[start]?.value === "(") balance++;
//                     if (elements[start]?.value === ")") balance--;
//                     start++;
//                 }
//                 if (balance !== 0) throw new Error("Unbalanced parentheses");

//                 // Recursively process the subarray
//                 const subArray = elements.slice(i + 1, start - 1);
//                 const subObject = helper(subArray);
//                 outputStack.push(subObject);

//                 // Skip processed parentheses
//                 i = start - 1;
//             } else if (operators.includes(element?.value)) {
//                 // Handle operators with precedence
//                 while (
//                     operatorStack.length &&
//                     operatorsWithPrecedence[element?.valaue]?.precedence <= operatorsWithPrecedence[operatorStack[operatorStack.length - 1]]?.precedence
//                 ) {
//                     applyOperator();
//                 }
//                 operatorStack.push(element);
//             } else {
//                 // Handle operands (variables or numbers)
//                 outputStack.push(element);
//             }
//             i++;
//         }

//         // Apply remaining operators
//         while (operatorStack.length) {
//             applyOperator();
//         }

//         // Final result will be the only element in the output stack
//         return outputStack[0];
//     }

//     return helper(formula);
// };

const handleConvertFormula = (expressionArray) => {
 
    const precedence = { "+": 1, "-": 1, "*": 2, "/": 2, "^": 3 };
    const operators = {"+":"add","-":"subtract","*":"multiply","/":"divide","^":"power"}

    // Helper function to find the split point (lowest precedence operator outside parentheses)
    const findSplitPoint = (array) => {
        let minPrecedence = Infinity;
        let splitIndex = -1;
        let openParentheses = 0;

        array.forEach((item, index) => {
            if (item.value === "(") openParentheses++;
            else if (item.value === ")") openParentheses--;
            else if (item.isOperation && precedence[item.value] !== undefined && openParentheses === 0) {
                if (precedence[item.value] <= minPrecedence) {
                    minPrecedence = precedence[item.value];
                    splitIndex = index;
                }
            }
        });

        return splitIndex;
    };

    // Helper function to strip outer parentheses
    const stripParentheses = (array) => {
        if (array[0]?.value === "(" && array[array.length - 1]?.value === ")") {
            let openParentheses = 0;
            for (let i = 0; i < array.length; i++) {
                if (array[i].value === "(") openParentheses++;
                if (array[i].value === ")") openParentheses--;
                if (openParentheses === 0 && i < array.length - 1) return array; // Not fully wrapped
            }
            return array.slice(1, -1); // Fully wrapped
        }
        return array;
    };

    // Base case: If there's only one element, return it as a value node
    if (expressionArray.length === 1) {
        const singleItem = expressionArray[0];
        if (singleItem.type === "constant" || singleItem.type === "reference") {
            if(singleItem?.type === "constant"){
                return {...singleItem,value:Number(singleItem?.value)};
            } else {
                return singleItem
            }
        }
    }

    // Remove outer parentheses
    const strippedArray = stripParentheses(expressionArray);

    // Find the split point
    const splitPoint = findSplitPoint(strippedArray);

    // If no operator is found, it's a single operand or invalid structure
    if (splitPoint === -1) {
        // throw new Error("Invalid expression structure");
    }

    // Split the array into left and right parts
    const leftArray = strippedArray.slice(0, splitPoint);
    const rightArray = strippedArray.slice(splitPoint + 1);

    // Operator at the split point
    const operator = strippedArray[splitPoint].value;
    // Recursively parse the left and right parts
    return {
        operation:operators[operator],
        type:'formula',
        left: handleConvertFormula(leftArray),
        right: handleConvertFormula(rightArray),
    };
};

export const handleAddConstantValue = ({value,lcFormulaStringArr,formulaParts,setLcFormulaStringArr,setFormulaParts}) => {
    if(!formulaParts?.length) return
    const lastTyped = formulaParts[formulaParts?.length -1]
    if(!lastTyped?.isOperation) return 
    if(lastTyped.valaue === "(" || lastTyped.value === ")" || !isNaN(lastTyped?.value)) return false;
    setFormulaParts(prev => ([...prev,{type:"constant",value}]));
    setLcFormulaStringArr(prev => ([...prev,value]))
}


export const handleGenerateFormula = ({templateId,lcFormulas,setIsLoading,Navigate,dispatch}) => {
    const requestPayload = lcFormulas?.map((formula) => formula?.formula);
    setIsLoading()
    doPatchApiCall({url:`/logs/templates/${templateId}/updateDataSetFormula`,payload:{dataSets:requestPayload}})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
            handleShowErrorAndWarning({dispatch,type:"success",message:"Formula generated successfuly",showTime:"5000"});
            Navigate("/logs")
        }
    }) 
    .finally(setIsLoading)
}