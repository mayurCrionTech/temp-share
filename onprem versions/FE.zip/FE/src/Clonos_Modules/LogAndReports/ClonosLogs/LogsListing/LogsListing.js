import Reports from './Reports';
import { Card } from '@mui/material';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react'
import ClonosGridNav from '../../../../utils/ClonosGridNav';
import useToggler from '../../../../CustomHooks/TogglerHook';
import Modal from '../../../../components/CommonComponents/Modal/Modal';
import { commonPageState, handleAllowDirectAccessPage, handleLoggedInUser, handleSegregateURL, hasPermission, setSerialNumber } from '../../../../utils/clonosCommon';
import { ClonosButton } from '../../../../components/CommonComponents/Button/Button';
import CommonNavigator from '../../../../components/CommonComponents/Navigator/Navigator';
import { PendingForApproval, Checks, AllChecklists } from "../../../../assets/UIUX/icons/Checklist/Checklist"
import Styles from "../../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/ChecklistListing/ChecklistListing.module.css"

import "../../../../index.css"
import ClonosDataGrid from '../../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid';
import TemplateListingTable from './TemplateListingTable';
import { UnAuthorizedModal } from '../../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal';
import LogsListingTable from './LogsListingTable';
import { handleGetLogs, handleGetLogsStatus } from '../../../../utils/ChecklistAndReportsMethods/LogsMethod';
import { doGetApiCall } from '../../../../utils/ClonosApi';
import { CLONOS_GLOBAL_USER_TYPE_OPERATOR } from '../../../../Constants/Constant';

let navigatorValues = [
    { value: "Logs", status: true },
    { value: "Template Library", status: false },
];
const ChecklistListing = () => {
    // Local States
    const [toggleBetweenChecklistOrTemplateLibrary, setToggleBetweenChecklistOrTemplateLibrary] = useState("Logs");
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [checklistData, setChecklistData] = useState([]);
    const [isGenerateReport, setIsGenerateReport] = useState(false);
    const [pagination, setPagination] = useState(commonPageState);
    const [totalCount, setTotalCount] = useState(0);
    const [isLoading, setIsLoading] = useToggler();
    const [refreshApi, setRefreshApi] = useToggler();
    const [lcValues, setLcValues] = useState({});
    const [refreshStatusCount, setRefreshStatusCount] = useToggler();
    const URL = handleSegregateURL();


    // Local Handlers
    const handleToggleBetweenChecklistOrTemplateLibrary = (props) => {
        setToggleBetweenChecklistOrTemplateLibrary(props)
    };

    const handleGotoLogsCreate = () => {
        navigate('/create-log-generaldetails')
    };


    useEffect(() => {
        if ((URL?.unity && URL?.assetId) || (URL?.AR && URL?.assetId) || (URL?.VR && URL?.assetId)) {
            const loggedInUserDetails = handleLoggedInUser();
            (async () => {

                // const assetId = await handleAllowDirectAccessPage({ keyName: "assetId" });
                const assetId = URL?.assetId;
                doGetApiCall(`/assets/${assetId}/logs`).then(response => {
                    let data = response?.data?.result;

                    // Filter checklist items based on the logged-in user or who created that checklist.
                    let filteredData = null; // A variable that will store that will store the filtered data based on the below conditions.
                    if (loggedInUserDetails.role_id === CLONOS_GLOBAL_USER_TYPE_OPERATOR) {
                        // Same for Operator
                        filteredData = data?.data?.filter(
                            (item) => item?.assignee?.userId === loggedInUserDetails?.userId
                        );
                    } else {
                        // Remaining roles will comes under here.
                        filteredData = data?.data;
                    }
                    // Set the filtered data using the provided responseSetterMethod.
                    setTotalCount(data?.totalDataCount)
                    const records = setSerialNumber(filteredData, pagination?.page, pagination?.limit);
                    setChecklistData(records);
                }).finally(() => {

                })
            })()
        }
        else {
            handleGetLogs({ dispatch, responseSetterMethod: setChecklistData, payload: pagination, totalRecordSetter: setTotalCount, loadingSetter: setIsLoading });  // Get all the Checklists
        }
    }, [pagination, refreshApi])

    useEffect(() => {
        handleGetLogsStatus({ dispatch, responseSetterMethod: setLcValues })
    }, [refreshStatusCount])
    if (hasPermission("/checklists")) {
        return (
            <>
                {(!URL?.unity && !URL?.AR && !URL?.VR) && <ClonosGridNav items={[
                    {
                        icon: AllChecklists,
                        iconBg: '#E7EFFF',
                        title: 'Total Logs',
                        count: lcValues?.logsStatuses?.totalLogs
                    },
                    {
                        icon: Checks,
                        iconBg: '#EBFAEC',
                        title: 'Completed Logs',
                        count: lcValues?.logsStatuses?.completedLog
                    },
                    {
                        icon: PendingForApproval,
                        iconBg: '#F7E9BF',
                        title: 'Log Entries Pending for Approval',
                        count: lcValues?.logsStatuses?.pendingForApproval
                    },

                ]}>
                    <div className="d-fl-al-cen">
                        {/* <ClonosButton onClick={() => setIsGenerateReport(true)} variant={"filled"}>Generate Report</ClonosButton> */}
                        {hasPermission('/logs-creation') ? <ClonosButton onClick={() => handleGotoLogsCreate()} variant={"filled"}>Create Logs</ClonosButton> : <></>}
                    </div>
                </ClonosGridNav >}

                <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem 1rem 1rem 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto", height: "100vh" }}>
                    <CommonNavigator values={(URL?.unity || URL?.AR || URL?.VR) ? [{ value: "Logs", status: true }] : navigatorValues} getSelectedValue={handleToggleBetweenChecklistOrTemplateLibrary} />
                    {
                        toggleBetweenChecklistOrTemplateLibrary === "Logs" ?
                            <LogsListingTable
                                lcDataSetterMethod={setChecklistData}
                                tableData={checklistData.length > 0 ? checklistData : []}
                                totalCount={totalCount}
                                pageLimit={pagination.limit}
                                setPagination={setPagination}
                                isLoading={isLoading}
                                setRefreshApi={setRefreshApi}
                                setRefreshStatusCount={setRefreshStatusCount}
                            /> : <div className={Styles.template_container}>
                                {
                                    hasPermission("/template-listing") ?
                                        <TemplateListingTable
                                            lcDataSetterMethod={setChecklistData}
                                            tableData={checklistData.length > 0 ? checklistData : []}
                                            totalCount={totalCount}
                                            pageLimit={pagination.limit}
                                            setPagination={setPagination}
                                            isLoading={isLoading}
                                            setRefreshApi={setRefreshApi}
                                        /> : <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
                                }
                            </div>
                    }
                </Card>

                <Modal isOpen={isGenerateReport} closeModalMethod={setIsGenerateReport}>
                    <Reports closeModalMethod={setIsGenerateReport} />
                </Modal>
            </>
        )
    }
    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default React.memo(ChecklistListing)

