import React, { useEffect, useState } from 'react'
import Styles from "./TaskLibraryDropdown.module.css"
import searchIcon from "../../../../assets/UIUX/icons/search (1).svg"
import { commonPageState, generateUniqueId, globalHandleSearch } from '../../../../utils/clonosCommon';
import CloseIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon';
import BackIcon from '../../../../assets/Clonos Common Indicators/Icon_Components/BackIcon';
import useToggler from '../../../../CustomHooks/TogglerHook';
import { handleGetSubTasksOfTask, handleGetTasksDropdownData } from '../../../work-orders/work-order-manager';
import ClonosSpinner from '../../../../components/CommonComponents/ClonosSpinner/ClonosSpinner';

const TaskLibraryDropdown = ({ data, closeModalMethod, handleGetValues, isMultiple, type, uniqueKey }) => {
    // State for managing data
    const [tasksLibraryData, setTasksLibraryData] = useState({});
    const [isPreview, setIsPreview] = useState(false);
    const [selectedTask,setSelectedTask] = useState({});
    const [selectedValues, setSelectedValues] = useState([]);
    const [previewData, setPreviewData] = useState([]);
    const [isTasksLoading,setIsTasksLoading] = useToggler();
    const [isPreviewLoading,setIsPreviewLoading] = useToggler();
    const [tasksPagination,setTasksPagination] = useState(commonPageState);
    const [subTasksPagination,setSubTasksPagination] = useState(commonPageState);
    // Log data for debugging

    // Function to handle search
    const handleSearch = (e) => {
        if (e.target.value.length > 0) {
            const filteredData = data.filter((ele) => globalHandleSearch({ typedString: e.target.value, withCompareString: ele.name }));
            setTasksLibraryData(filteredData);
        } else {
            setTasksLibraryData(data);
        }
    };

    // Function to close the modal
    const lcHandleCloseModal = () => {
        handleGetValues && handleGetValues({ type, uniqueKey, selectedOption: [] });
        setSelectedValues([]);
        closeModalMethod(false);
    };

    // Function to handle getting values
    const lcHandleGetValues = (props) => {
        handleGetValues({ type, uniqueKey, selectedOption: [props] });
        // setSelectedValues((prev) => {
        //     const updatedState = isMultiple ? [...prev, props] : [props];
        //     handleGetValues({ type, uniqueKey, selectedOption: updatedState });
        //     return updatedState;
        // });
        closeModalMethod(false)
    };

    // Function to handle Ok button click
    const lcHandleOk = () => {
        handleGetValues && handleGetValues({ type, uniqueKey, selectedOption: previewData || []});
        closeModalMethod(false);
    };

    useEffect(() => {
      handleGetTasksDropdownData({setterMethod:setTasksLibraryData,setIsLoading:setIsTasksLoading,filterPayload:tasksPagination})
    },[])

    useEffect(() => {
        if(selectedTask?.id){
            handleGetSubTasksOfTask({setterMethod:setPreviewData,setIsLoading:setIsPreviewLoading,filterPayload:subTasksPagination,taskId:selectedTask?.id})
        }
    },[selectedTask?.id])

    return (
        <div role="dialog" aria-labelledby="TaskLibraryHeading" aria-modal="true" aria-label=" Task Library" className={Styles.task_library_dropdown_container}>
            <header>
                {isPreview === false ? (
                    <div aria-labelledby="taskLibraryHeading" className={Styles.task_library_dropdown_header_tasks}>
                        <span id="taskLibraryHeading">Select From Task Library</span>
                        <CloseIcon tooltipTitle="Close" onClick={closeModalMethod} />
                    </div>
                ) : (
                    <div aria-labelledby="taskPreviewHeading" className={Styles.task_library_dropdown_header_task_preview}>
                        <div>
                            <BackIcon tooltipTitle="Back" onClick={() => {
                                setIsPreview(false);
                                setPreviewData({})
                            }} />
                            <span id="taskPreviewHeading">Task Library</span>
                        </div>
                        <CloseIcon tooltipTitle="Close" onClick={closeModalMethod} />
                    </div>
                )}
            </header>
            {isPreview ? (
                <section className={Styles.task_library_dropdown_preview_container}>
                    {
                        isPreviewLoading ? <div className='center_wrapper'><ClonosSpinner/></div> : previewData?.length > 0 ? (
                            previewData?.map((task, index) => (
                                <div key={generateUniqueId(5)} className={Styles.task_library_dropdown_preview_single_task}>
                                    <span>Task {index+1}</span>
                                    <span>-</span>
                                    <span>{task.description}</span>
                                </div>
                            ))
                        ) : (
                            <div className='center_wrapper'><p style={{textAlign:"center"}}>No Tasks!</p></div>
                        )
                    }
                </section>
            ) : (
                <section className={Styles.task_library_dropdown_body}>
                    {
                        isTasksLoading ? <div className='center_wrapper'><ClonosSpinner/></div> : tasksLibraryData?.data?.length > 0 ? 
                        <>
                            <div role="search" aria-label="Search Bar" className={Styles.task_library_dropdown_search_bar} style={{ padding: "1rem" }} >
                                <img src={searchIcon} alt="Search" loading="lazy" />
                                <input onChange={(e) => handleSearch(e)} aria-label="Search Input" />
                            </div>
                            <div aria-label="All Tasks" className={Styles.task_library_dropdown_all_task_container} style={{ padding: "1rem" }}>
                                {tasksLibraryData?.data?.map((task) => (
                                    <div key={task.id} aria-label="task" className={Styles.task_library_dropdown_single_task} >
                                        <div>
                                            <span aria-label="Task Name">{task?.name}</span>
                                            <span aria-label="Asset Category">{task?.assetCategory?.name}</span>
                                        </div>
                                        <span onClick={() => {
                                            setSelectedTask(task);
                                            setIsPreview(true);
                                        }} aria-label="Preview">Preview</span>
                                    </div>
                                ))}
                            </div>
                        </> : <div className='center_wrapper'><p>No Tasks!</p></div>
                    }
                </section>
            )}
            <footer className={Styles.task_library_dropdown_footer_controller}>
                <span role="button" tabIndex="0" className={Styles.task_library_dropdown_footer_cancel} onClick={lcHandleCloseModal}>
                    Cancel
                </span>
                {previewData?.length ? <span role="button" tabIndex="0" className={Styles.task_library_dropdown_footer_ok} onClick={lcHandleOk}>
                    Ok
                </span> : <></>}
            </footer>
        </div>
    );
};

export default TaskLibraryDropdown;
