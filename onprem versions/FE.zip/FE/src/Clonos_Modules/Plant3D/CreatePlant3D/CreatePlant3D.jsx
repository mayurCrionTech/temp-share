import { Card, IconButton } from "@mui/material"
import Styles from "../../../ModuleStyles/Plant3D/CreatePlant3D.module.css"
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput"
import ClonosSelect from "../../../components/CommonComponents/ClonosSelect/ClonosSelect"
import { useEffect, useRef, useState } from "react"
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import { checkUserHasPermission, globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../utils/clonosCommon"
import { createPlant3DMethod, editPlant3DModelMethod, getSinglePlant3DModelDetails, getStandard3DOjectsMethod, getUserUploaded3DOjectsMethod } from "../../../utils/Plant3DMethods/Plant3DMethods"
import { useDispatch } from "react-redux"
import { useLocation, useNavigate } from "react-router-dom"
import useToggler from "../../../CustomHooks/TogglerHook"
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner"
import { AddFrom3DLibraryModal } from "../components/AddFrom3DLibrary/AddFrom3DLibraryModal"
import {ActiveRight} from "../../../assets/svg/RightIcon"
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_MODULE_PLANT_3D } from "../../../Constants/Constant"
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook"
let primaryObject = {};

const CreatePlant3D = ({mode}) => {
    const dispatch = useDispatch();
    const Location = useLocation();
    const Navigate = useNavigate();
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_PLANT_3D)
    const addFromLibraryRef = useRef(null);
    const [showPopup,setShowPopup] = useState(false);
    const [formData,setFormData] = useState({});
    const [isLoading,setIsLoading] = useToggler();
    const [changedData,setChangedData] = useState({});
    const [fetchLoading,setFetchLoading] = useToggler();
    const [all3DObjects,setAll3DObjects] = useState({
        userUploaded:[],
        standard:[]
    });
    const [pagination,setPagination] = useState({page:1,limit:15})
    const [showUserUploadedLibraryModal,setShowUserUploadedLibraryModal] = useState(false);
    const [showStandardLibraryModal,setShowStandardLibraryModal] = useState(false);
    const [locationsDropdown, setLocationsDropdown] = useState([
        {
          id: 1,
          locationId: "loc-203bc829-262c-4a77-b8cf-b15e89448776",
          name_of_city: "Mandapeta",
        },
        {
          id: 2,
          locationId: "loc-809e1938-d038-43eb-92ef-f64ce5b7889d",
          name_of_city: "Tatipaka",
        },
      ]);


  

    const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
        
        if (response === null) {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": false } }
            return false
        }
        else {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": true } }
            return true
        }
    }


    const handleGetValues = (props) => {
        const { name, selectedOption, updatedValue, uniqueKey, type,files } = props;
        if (type === "dynamicDropdown") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? {name:selectedOption[0]?.name,id:selectedOption[0]?.id} : null }
            })
            if(mode === 'edit'){
                setChangedData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ? {name:selectedOption[0]?.name,id:selectedOption[0]?.id} : null }
                })
            }
        }
        else if (type === "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? {name:updatedValue?.label,id:updatedValue?.value} : null }
            })
            if(mode === 'edit'){
                setChangedData((prev) => {
                    return { ...prev, [uniqueKey]: valueSetter ?  {name:updatedValue?.label,id:updatedValue?.value} : null }
                })
            }
        }

        else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            if(uniqueKey.includes("position")){ 
                let position = formData.position || {};
                if(uniqueKey === "positionX"){
                    position.x = updatedValue
                } else if(uniqueKey === "positionY"){
                    position.y = updatedValue
                } else if(uniqueKey === "positionZ"){
                    position.z = updatedValue
                }
                setFormData((prev) => ({...prev,position}));
                if(mode === 'edit'){
                    setChangedData((prev) => ({...prev,position}));
                }
            } else if (uniqueKey?.includes("rotation")){
                let rotation = formData.rotation || {};
                if(uniqueKey === "rotationX"){
                    rotation.x = updatedValue
                } else if(uniqueKey === "rotationY"){
                    rotation.y = updatedValue
                } else if(uniqueKey === "rotationZ"){
                    rotation.z = updatedValue
                }
                setFormData((prev) => ({...prev,rotation}))
                if(mode === 'edit'){
                    setChangedData((prev) => ({...prev,rotation}))
                }
            } else {
                setFormData((prev) => {
                    return { ...prev, [uniqueKey]: updatedValue }
                });
                if(mode === 'edit') {
                    setChangedData((prev) => {
                        return { ...prev, [uniqueKey]: updatedValue }
                    });
                }
            }
        } else if(type === "file"){
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
       
            if(mode === 'edit'){
                setChangedData((prev) => {
                    return { ...prev, [uniqueKey]: files }
                })
            }

            setFormData((prev) => {
                return { ...prev, [uniqueKey]: files }
            })
        } else {
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: updatedValue }
            });
            if(mode === 'edit'){
                setChangedData((prev) => {
                    return { ...prev, [uniqueKey]: updatedValue }
                });
            }
        }

    };

    const handleGetErrorActivatorInformation = (props) => {
        const {uniqueKey} = props
        const createModeProps = formData[uniqueKey] ? primaryObject[uniqueKey] : props;
        const editValueCheck = changedData[uniqueKey] ? changedData[uniqueKey] : formData[uniqueKey];
        const editModeProps =  props;
        
        primaryObject = { ...primaryObject, [props.uniqueKey]: mode === 'edit' ? editValueCheck : createModeProps }
    }

    const handleGetUploadedfile = (props) => {
        const {name,uniqueKey,files} = props;
       
        if(name === "needToDeleteDocuments"){
            if(uniqueKey === "model") delete formData.model
            if(uniqueKey === "layoutImage") delete formData.layoutImage
        } else {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: files?.length ? files[0] : null })
           
            if(mode === 'edit') {
                setChangedData((prev) => ({...prev,[uniqueKey]:files[0]}))
            } else {
                setFormData((prev) => ({...prev,[uniqueKey]:files[0]}))
            }
        }
    }


    const handleCreatePlant3D = (props) => {
        const { data, primaryObject } = props;

        
        if (!globalHandleIsAllRequiredFieldAvailable({ data, primaryObject })) {
            handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide all required fields",showTime:'5000'})
            return;
        } else {
            createPlant3DMethod({dispatch,formData:data,setIsLoading,Navigate})
        }
    }

    const handleEditPlant3D = ({data,primaryObject}) => {
          
        if (!globalHandleIsAllRequiredFieldAvailable({primaryObject })) {
            handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide all required fields",showTime:'5000'})
            return;
        } else {
            editPlant3DModelMethod({id:data?.id,modelId:data?.modelId,dispatch,changedData,Navigate,setIsLoading})
        }
    }

    const getFileFrom3DLibrary = (props) => {
        
        const {model2d,model3d,name} = props;
       
        handlePrimaryObjectModifier({ uniqueKey:"layoutImage", response:model2d })
        handlePrimaryObjectModifier({ uniqueKey:"model", response: model3d })
        if(mode === "edit"){
            setChangedData((prev) => ({...prev,model:[model3d],layoutImage:[model2d],modelId:props?.id}));
        } else {
            setFormData((prev) => ({...prev,model:[model3d],layoutImage:[model2d],modelId:props?.id}));
        }
        if(name === 'User Uploaded') setShowUserUploadedLibraryModal(false);
        if(name === 'Standard') setShowStandardLibraryModal(false)
    }

    useEffect(() => {
        const fetchData = async () => {
            if (mode === "edit") {
                getSinglePlant3DModelDetails({id: Location?.state?.id, dispatch, modelId: formData?.modelId, setterMethod: setFormData, setIsLoading: setFetchLoading});
            }
            
            const userUploadedRes = await getUserUploaded3DOjectsMethod({dispatch, pagination});
            if (userUploadedRes?.data?.length) {
                setAll3DObjects(prev => ({...prev, userUploaded: userUploadedRes?.data}));
            }
    
            // const standardRes = await getStandard3DOjectsMethod({dispatch, pagination});
            // if (standardRes?.data?.length) {
            //     setAll3DObjects(prev => ({...prev, standard: standardRes?.data}));
            // }
        };
    
        fetchData();
    },[]);

    useEffect(() => {
        const handleOutsideClick = (event) => {
          if (addFromLibraryRef.current && !addFromLibraryRef.current.contains(event.target)) {
            setShowPopup(false);
          }
        };
    
        if (showPopup) {
          document.addEventListener('mousedown', handleOutsideClick);
        } else {
          document.removeEventListener('mousedown', handleOutsideClick);
        }
    
        return () => {
          document.removeEventListener('mousedown', handleOutsideClick);
        };
      }, [showPopup]);

 

    if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}))
    return <>
        <Card style={{margin:"1rem",borderRadius:"6px",height:"100%",overflowY:"scroll"}}>
            {
                (mode === 'edit' && fetchLoading) ? <div className={Styles.spinnerWrapper}><ClonosSpinner/></div> :

            <>
                <div className={Styles.p_3d_container}>
                    <div className={Styles.p_3d_left_container}>
                        <ClonosInput
                            type="text"
                            isLabel={true}
                            label="Object Name"
                            isMandatory={false}
                            uniqueKey={"name"}
                            areaLabel={"3D object name"} 
                            placeholder={"Object Name"}
                            handleGetValues={handleGetValues}
                            defaultValue={mode === "edit" && formData?.name}
                        />

                        <h4>Location Details</h4>
                        <ClonosSelect
                            type="select"
                            isLabel={true}
                            label={"Location"}
                            isMandatory={true}
                            uniqueKey="location"
                            areaLabel="Location"
                            placeholder="Select"
                            options={locationsDropdown?.map((opt) => ({
                                label: opt?.name_of_city,
                                value: opt?.locationId,
                                isNeeded: true,
                            }))}
                            defaultValue={mode === "edit" && formData?.location?.name}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide location."}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                        <h5>Geographical Co-ordinates <span className={Styles.link}>Get Location from AR</span></h5>
                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Latitude(deg)"
                            isMandatory={true}
                            uniqueKey={"latitude"}
                            areaLabel={"latitude"} 
                            placeholder={"Enter Latitude"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide Latitude."}
                            defaultValue={mode === "edit" && !isNaN(formData?.latitude) && formData?.latitude.toString() }
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                        
                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Longitude(deg)"
                            isMandatory={true}
                            uniqueKey={"longitude"}
                            areaLabel={"longitude"} 
                            placeholder={"Enter Longitude"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide Longitude."}
                            defaultValue={mode === "edit" && !isNaN(formData?.longitude) && formData?.longitude.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Elevation(m)"
                            isMandatory={true}
                            uniqueKey={"elevation"}
                            areaLabel={"elevation"} 
                            placeholder={"Enter Elevation"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide Elevation."}
                            defaultValue={mode === "edit" && !isNaN(formData?.elevation) && formData?.elevation.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Floor"
                            isMandatory={false}
                            uniqueKey={"floor"}
                            areaLabel={"floor"} 
                            placeholder={"Enter Floor"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide floor."}
                            defaultValue={mode === "edit" && !isNaN(formData?.floor) && formData?.floor.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                        <h4>Position</h4>
                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="X"
                            isMandatory={false}
                            uniqueKey={"positionX"}
                            areaLabel={"positionX"} 
                            placeholder={"Enter X"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide X."}
                            defaultValue={mode === "edit" && !isNaN(formData?.position?.x) && formData?.position?.x.toString() }
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Y"
                            isMandatory={false}
                            uniqueKey={"positionY"}
                            areaLabel={"positionY"} 
                            placeholder={"Enter Y"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide Y."}
                            defaultValue={mode === "edit" && !isNaN(formData?.position?.y) && formData?.position?.y.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />
                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Z"
                            isMandatory={false}
                            uniqueKey={"positionZ"}
                            areaLabel={"positionZ"} 
                            placeholder={"Enter Z"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide Z."}
                            defaultValue={mode === "edit" && !isNaN(formData?.position?.z) && formData?.position?.z.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                        <h4>Rotation</h4>
                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="X"
                            isMandatory={false}
                            uniqueKey={"rotationX"}
                            areaLabel={"rotationX"} 
                            placeholder={"Enter X"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide X."}
                            defaultValue={mode === "edit" && !isNaN(formData?.rotation?.x) && formData?.rotation?.x.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Y"
                            isMandatory={false}
                            uniqueKey={"rotationY"}
                            areaLabel={"rotationY"} 
                            placeholder={"Enter Y"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide Y."}
                            defaultValue={mode === "edit" && !isNaN(formData?.rotation?.y) && formData?.rotation?.y.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                        <ClonosInput
                            type="number"
                            isLabel={true}
                            label="Z"
                            isMandatory={false}
                            uniqueKey={"rotationZ"}
                            areaLabel={"rotationZ"} 
                            placeholder={"Enter Z"}
                            handleGetValues={handleGetValues}
                            errorMessage={"Please provide Z."}
                            defaultValue={mode === "edit" && !isNaN(formData?.rotation?.z) && formData?.rotation?.z.toString()}
                            handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        />

                    </div>
                    <div className={Styles.p_3d_right_container}>
                        <div className={Styles.p_3d_add_from_library}>
                            <div className={Styles.p_3d_custom_btn}>
                                <div onClick={() => setShowPopup(true)} className={Styles.p_3d_custom_btn_}><span>+ Add from library</span>
                                <IconButton style={{rotate:"90deg"}}><ActiveRight/></IconButton></div>
                                {
                                    showPopup ? <div ref={addFromLibraryRef} className={Styles.p_3d_m_t}>
                                    <p onClick={() => setShowUserUploadedLibraryModal(true)}>User Uploaded Models</p>
                                    {/* <p onClick={() => setShowStandardLibraryModal(true)}>Standard Models</p> */}
                                </div> : <></>
                                }
                            </div>
                            
                        </div>
                        {/* <FileUploader defaultValue={mode === 'edit' && formData?.model ? [formData?.model] : []}  label={"3D Model"} isMandatory={false} uniqueKey={"model"} typeOfRecord={"Image"}  limit={1} acceptableFileTypes={[".fbx"]} fileSizeInMB={10} localPreviousPageFiles={mode === "edit" ? changedData?.model ? [changedData?.model] : [] : formData?.model ? [formData?.model]: []} handleGetSelectedData={handleGetUploadedfile} errorMessage={"Please provide 3D Model!"} handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} />
                        <FileUploader defaultValue={mode === 'edit' && formData?.layoutImage ? [formData?.layoutImage] : []} label={"Layout Image"} isMandatory={false} uniqueKey={"layoutImage"} typeOfRecord={"Image"}  limit={1} acceptableFileTypes={[".png", ".jpg", ".jpeg"]} fileSizeInMB={10} localPreviousPageFiles={ mode === "edit" ? changedData?.layoutImage ? [changedData.layoutImage] : [] : formData?.layoutImage ? [formData?.layoutImage] : []} handleGetSelectedData={handleGetUploadedfile} errorMessage={"Please provide layout image!"} handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} /> */}


                        {/* <FileUploader defaultValue={ mode === "edit" ? [formData?.model] || changedData?.model : formData?.model? formData?.model  : []  }  label={"3D Model"} isMandatory={true} uniqueKey={"model"} typeOfRecord={"Image"}  limit={1} acceptableFileTypes={[".fbx"]} fileSizeInMB={10}  handleGetSelectedData={handleGetUploadedfile} errorMessage={"Please provide 3D Model!"} handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} />
                        <FileUploader defaultValue={ mode === "edit" ? [formData?.layoutImage] || changedData?.layoutImage : formData?.layoutImage ? formData?.layoutImage : [] } label={"Layout Image"} isMandatory={true} uniqueKey={"layoutImage"} typeOfRecord={"Image"}  limit={1} acceptableFileTypes={[".png", ".jpg", ".jpeg"]} fileSizeInMB={10} handleGetSelectedData={handleGetUploadedfile} errorMessage={"Please provide layout image!"} handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} /> */}

                        <FileUploader defaultValue={ mode === "edit" ? formData?.model ? [formData?.model] : changedData?.model ? changedData?.model :[] : formData?.model? formData?.model  : []  }  label={"3D Model"} isMandatory={true} uniqueKey={"model"} typeOfRecord={"Image"}  limit={1} acceptableFileTypes={[".fbx"]} fileSizeInMB={10}  handleGetSelectedData={handleGetUploadedfile} errorMessage={"Please provide 3D Model!"} handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} />
                        <FileUploader defaultValue={ mode === "edit" ? formData?.layoutImage ? [formData?.layoutImage] : changedData?.layoutImage ? changedData?.layoutImage:[] : formData?.layoutImage ? formData?.layoutImage : [] } label={"Layout Image"} isMandatory={true} uniqueKey={"layoutImage"} typeOfRecord={"Image"}  limit={1} acceptableFileTypes={[".png", ".jpg", ".jpeg"]} fileSizeInMB={10} handleGetSelectedData={handleGetUploadedfile} errorMessage={"Please provide layout image!"} handleGetErrorActivatorInformation={handleGetErrorActivatorInformation} />


                    </div>
                </div>
                <div className={Styles.p_3d_btns_wrapper}>
                    <div>
                        <ClonosButton style={{padding:"0.8rem 3rem"}} onClick={()=> Navigate(-1)}>Cancel</ClonosButton>
                        {
                            mode === 'edit' ? 
                            <ClonosButton onClick={() => handleEditPlant3D({data:{...formData,...changedData},primaryObject})} variant="filled" style={{padding:"0.8rem 3rem"}} loading={isLoading}>Update</ClonosButton> : 
                            <ClonosButton onClick={() => handleCreatePlant3D({data:formData,primaryObject})} variant="filled" style={{padding:"0.8rem 3rem"}} loading={isLoading}>Submit</ClonosButton>
                        }
                    </div>
                </div>
            </>
            }
        </Card>
        <AddFrom3DLibraryModal  isOpen={showUserUploadedLibraryModal} closeMethod={setShowUserUploadedLibraryModal} getUploadedValue={getFileFrom3DLibrary} data={all3DObjects?.userUploaded} type={'User Uploaded'}/>
        <AddFrom3DLibraryModal isOpen={showStandardLibraryModal} closeMethod={setShowStandardLibraryModal} getUploadedValue={getFileFrom3DLibrary} data={all3DObjects?.standard} type={'Standard'}/>
    </>
    return <UnAuthorizedModal type="NOT_AUTHORIZED" />
}

export default CreatePlant3D