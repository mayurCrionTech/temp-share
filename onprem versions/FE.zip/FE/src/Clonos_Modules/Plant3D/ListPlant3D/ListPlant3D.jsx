import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import ClonosGridNav from "../../../utils/ClonosGridNav"
import { checkUserHasPermission, handleShowErrorAndWarning, hasPermission, setSerialNumber } from "../../../utils/clonosCommon"
import Styles from "../../../ModuleStyles/Plant3D/ListPlant3D.module.css"
import { useNavigate } from "react-router-dom"
import { ApprovedReports, PendingReports, TotalReports } from "../../../assets/Plant3D/Plant3DSubbarSVG"
import { Card, Tooltip } from "@mui/material"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { useEffect, useState } from "react"
import useToggler from "../../../CustomHooks/TogglerHook"
import { deletePlant3DModelMethod, getAllPlant3DModelsMethod } from "../../../utils/Plant3DMethods/Plant3DMethods"
import { useDispatch } from "react-redux"
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_PLANT_3D, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS } from "../../../Constants/Constant"
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook"
const ListPlant3D = () => {
    const [data, setData] = useState({})
    const Navigate = useNavigate();
    const dispatch = useDispatch();
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_PLANT_3D)
    const [isLoading, setIsLoading] = useToggler();
    const [selectedRows, setSelectedRows] = useState([]);
    const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
    const [pagination, setPagination] = useState({ page: 1, limit: 15 })
 
    const columns = [
       {
            field: "index",
            headerName: "SI.No",
            // flex: 1,
            width: "50",
            disableColumnFilter: true
        },
        {
            field: "name",
            headerName: "OBJECT NAME",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.name}>
                    <p onClick={() => Navigate(`/view-plant3D/${param?.row?.name}`, { state: { id: param?.row?.id } })} className="clonos_datagrid_link">{param?.row?.name}</p>
                </Tooltip>
            }
        },
        {
            field: "location",
            headerName: "LOCATION",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.location?.name?? "-"}>
                    <p>{param?.row?.location?.name ?? '-'}</p>
                </Tooltip>
            }
        },
        {
            field: "latitude",
            headerName: "LATITUDE",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.latitude}>
                    <p>{param?.row?.latitude}</p>
                </Tooltip>
            }
        },
        {
            field: "longitude",
            headerName: "LONGITUDE",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.longitude}>
                    <p>{param?.row?.longitude}</p>
                </Tooltip>
            }
        },
        {
            field: "elevation",
            headerName: "ELEVATION",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.longitude}>
                    <p>{param?.row?.longitude}</p>
                </Tooltip>
            }
        },
        {
            field: "floor",
            headerName: "FLOOR",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={param?.row?.floor}>
                    <p>{param?.row?.floor}</p>
                </Tooltip>
            }
        },
        {
            field: "position",
            headerName: "POSITION",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={`x:${param?.row?.position?.x},y:${param?.row?.position?.y},z:${param?.row?.position?.z}`}>
                    <p>{`x:${param?.row?.position?.x},y:${param?.row?.position?.y},z:${param?.row?.position?.z}`}</p>
                </Tooltip>
            }
        },
        {
            field: "rotation",
            headerName: "ROTATION",
            flex: 1,
            renderCell: (param) => {
                return <Tooltip title={`x:${param?.row?.rotation?.x},y:${param?.row?.rotation?.y},z:${param?.row?.rotation?.z}`}>
                    <p>{`x:${param?.row?.rotation?.x},y:${param?.row?.rotation?.y},z:${param?.row?.rotation?.z}`}</p>
                </Tooltip>
            }
        },
        {
            field: "model2d",
            headerName: "LAYOUT IMAGE",
            flex: 1,
            renderCell: (param) => {
                return <img  width={"30px"} height={"30px"} src={param?.row?.model?.model2d?.url} />
            }
        }
    ]


    const handleEditPlant3D = () => {
        Navigate("/edit-plant3D", { state: { id: selectedRows[0] } })
    }

    const handleDeletePlant3DModel = async () => {
        const status = await deletePlant3DModelMethod({ dispatch, payload: { plant3DIds: selectedRows } });
        if (status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS) {
            handleShowErrorAndWarning({ dispatch, type: "success", message: "Plant 3D deleted successfully.", showTime: "5000" });
            setShowConfirmationDialog(false);
            getAllPlant3DModelsMethod({ dispatch, setterMethod: setData, setIsLoading, pagination })
        }
    }


    useEffect(() => {
        getAllPlant3DModelsMethod({ dispatch, setterMethod: setData, setIsLoading, pagination })
    }, [pagination])
    if (checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_READ}))
        return <>
            <ClonosGridNav items={[
                {
                    icon: TotalReports,
                    iconBg: '#E7EFFF',
                    title: 'Total Reports',
                    count: data?.totalDataCount
                },
                // {
                //     icon: ApprovedReports,
                //     iconBg: '#EBFAEC',
                //     title: 'Approved Reports',
                //     count: 100
                // },
                // {
                //     icon: PendingReports,
                //     iconBg: '#EBFAEC',
                //     title: 'Reports Pending for Approval',
                //     count: 100
                // },
            ]}>
                <div className={Styles.p_3d_nav_right}>
                    {checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}) ? <div><ClonosButton onClick={() => Navigate("/create-plant3D")} variant={"filled"}>+ Add Plant 3D</ClonosButton></div> : <></>}
                </div>
            </ClonosGridNav>
            <Card style={{ margin: "0rem 1rem 1rem 1rem", height: "100%" }}>
                <ClonosDataGrid
                      rows={setSerialNumber(data?.data,pagination?.page,pagination?.limit)}
                    // rows={data?.data?.length > 0 ? data?.data?.map((model, index) => ({ ...model, rowIndex: index + 1 })) : []}
                    columns={columns}
                    isEditMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE}) ? handleEditPlant3D : false}
                    isDeleteMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE}) ? () => setShowConfirmationDialog(true) : false}
                    uniqueIdField="id"
                    onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                    isLoading={isLoading}
                    totalCount={data?.totalDataCount}
                    pageLimit={pagination.limit}
                    checkboxSelection={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE}) || checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE})}
                    handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                />
            </Card>
            <ClonosConfirmationBox
                isOpen={showConfirmationDialog}
                headerTitle={"Delete Plant 3D Model"}
                message={"Are you sure you want to Delete?"}
                closeModalMethod={setShowConfirmationDialog}
                confirmingMethod={handleDeletePlant3DModel}
            />
        </>

    return <UnAuthorizedModal type={"NOT_AUTHORIZED"} />
}

export default ListPlant3D