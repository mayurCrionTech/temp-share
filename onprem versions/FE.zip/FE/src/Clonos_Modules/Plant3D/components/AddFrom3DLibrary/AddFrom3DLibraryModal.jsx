import Styles from "./AddFrom3DLibraryModal.module.css"
import Modal from "../../../../components/CommonComponents/Modal/Modal"
import CloseIcon from "../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon"
import SEARCH_ICON from "../../../../assets/UIUX/icons/search (1).svg"
import { SearchIcon } from "../../../../assets/Clonos Common Indicators/Icon_Components/SearchIcon"
import { useEffect, useState } from "react"


// export const AddFrom3DLibraryModal = ({isOpen,closeMethod,getUploadedValue,data,type}) => {
//     const [objects,setObjects] = useState([]);
//     const handleUpload = (obj) => {
//         getUploadedValue({...obj,name:type})
//     }
//     return (
//         <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
//             <div className={Styles.main_container}>
//                     <div className={Styles.inner_container}>
//                         <div className={Styles.header}>
//                             <h4>{`Import from ${type} Model`}</h4>
//                             <CloseIcon onClick={() => closeMethod(false)}/>
//                         </div>
//                         <div className={Styles.searchbar}>
//                             <div>
//                                 <SearchIcon size={20} color={"#8CA1C4"}/>
//                                 <input placeholder="Search"/>
//                             </div>
//                         </div>
//                         <div className={Styles.section}>
//                             {
//                                 data?.length 
//                                 ? <div className={Styles.list_Wrapper}>
//                                     {
//                                         data?.map((obj) => {
//                                             return <div>
//                                                 <p>{obj?.name}</p>
//                                                 <span onClick={() => handleUpload(obj)}>Upload</span>
//                                             </div>
//                                         })
//                                     }
//                                 </div>
//                                 : <div className={Styles.error_wrapper}>
//                                     <h4>No Data Present!</h4>
//                                 </div>
//                             }
//                         </div>
//                     </div>
//             </div>
//         </Modal>
//     )
// }



export const AddFrom3DLibraryModal = ({
  isOpen,
  closeMethod,
  getUploadedValue,
  data,
  type
}) => {
  const [searchValue, setSearchValue] = useState("");

  const handleUpload = (obj) => {
    getUploadedValue({ ...obj, name: type });
  };

  const filteredData = data?.filter((obj) =>
    obj?.name?.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
      <div className={Styles.main_container}>
        <div className={Styles.inner_container}>
          <div className={Styles.header}>
            <h4>{`Import from ${type} Model`}</h4>
            <CloseIcon onClick={() => closeMethod(false)} />
          </div>

          <div className={Styles.searchbar}>
            <div>
              <SearchIcon size={20} color={"#8CA1C4"} />
              <input
                placeholder="Search"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
              />
            </div>
          </div>

          <div className={Styles.section}>
            {filteredData?.length ? (
              <div className={Styles.list_Wrapper}>
                {filteredData.map((obj) => (
                  <div key={obj?.id || obj?.name}>
                    <p>{obj?.name}</p>
                    <span onClick={() => handleUpload(obj)}>Upload</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className={Styles.error_wrapper}>
                <h4>No Data Present!</h4>
              </div>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};
