import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";

const FBXViewer = ({
  url,
  fallbackImage = "https://via.placeholder.com/400x400?text=No+Image",
}) => {
  const containerRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!url || !containerRef.current) {
      setLoading(false);
      return;
    }

    let scene, camera, renderer, controls, animationId;

    try {
      /* ---------- SCENE ---------- */
      scene = new THREE.Scene();
      scene.background = new THREE.Color(0xf5f5f5);

      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight || 400;

      /* ---------- CAMERA ---------- */
      camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 2000);
      camera.position.set(5, 5, 5);

      /* ---------- RENDERER ---------- */
      renderer = new THREE.WebGLRenderer({ antialias: true });
      renderer.setSize(width, height);
      renderer.setPixelRatio(window.devicePixelRatio);
      containerRef.current.appendChild(renderer.domElement);

      /* ---------- CONTROLS ---------- */
      controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      /* ---------- LIGHTS ---------- */
      scene.add(new THREE.AmbientLight(0xffffff, 0.8));

      const dirLight = new THREE.DirectionalLight(0xffffff, 1);
      dirLight.position.set(10, 10, 10);
      scene.add(dirLight);

      /* ---------- GRID ---------- */
      // const grid = new THREE.GridHelper(20, 20);
      // scene.add(grid);

      /* ---------- FBX LOADER ---------- */
      const loader = new FBXLoader();

      loader.load(
        url,
        (object) => {
          /* Center & scale model */
          const box = new THREE.Box3().setFromObject(object);
          const size = box.getSize(new THREE.Vector3());
          const center = box.getCenter(new THREE.Vector3());

          // Center model
          object.position.sub(center);
          scene.add(object);

          // Fit camera to model
          const maxDim = Math.max(size.x, size.y, size.z);
          const fov = camera.fov * (Math.PI / 180);
          let cameraZ = Math.abs(maxDim / Math.sin(fov / 2));

          cameraZ *= 1.2; // extra space
          camera.position.set(cameraZ, cameraZ, cameraZ);

          camera.near = maxDim / 100;
          camera.far = maxDim * 100;
          camera.updateProjectionMatrix();

          // Controls focus
          controls.target.set(0, 0, 0);
          controls.update();

          setLoading(false);

        },
        undefined,
        (err) => {
          console.error("FBX load error:", err);
          setError(true);
          setLoading(false);
        }
      );

      /* ---------- ANIMATION ---------- */
      const animate = () => {
        animationId = requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
      };
      animate();

      /* ---------- RESIZE ---------- */
      const handleResize = () => {
        if (!containerRef.current) return;
        const w = containerRef.current.clientWidth;
        const h = containerRef.current.clientHeight || 400;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };
      window.addEventListener("resize", handleResize);

      /* ---------- CLEANUP ---------- */
      return () => {
        window.removeEventListener("resize", handleResize);
        if (animationId) cancelAnimationFrame(animationId);
        controls?.dispose();
        renderer?.dispose();
        if (containerRef.current && renderer.domElement) {
          containerRef.current.removeChild(renderer.domElement);
        }
      };
    } catch (e) {
      console.error("Viewer error:", e);
      setError(true);
      setLoading(false);
    }
  }, [url]);

  /* ---------- FALLBACK IMAGE ---------- */
  if (!url || error) {
    return (
      <img
        src={fallbackImage}
        alt="No 3D model"
        style={{
          width: "100%",
          height: "400px",
          objectFit: "contain",
          borderRadius: "8px",
        }}
      />
    );
  }

  return (
    <div
      style={{
        position: "relative",
        width: "500px",
        height: "300px",
        borderRadius: "8px",
        overflow: "hidden",
      }}
    >
      {loading && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "#fafafa",
            fontWeight: 600,
            zIndex: 1,
          }}
        >
          Loading 3D model...
        </div>
      )}
      <div ref={containerRef} style={{ width: "100%", height: "100%" }} />

      <div
        style={{
          position: "absolute",
          bottom: 10,
          right: 10,
          background: "rgba(0,0,0,0.6)",
          padding: "6px 12px",
          borderRadius: "4px",
          fontSize: "12px",
        }}
      >
        <a
          href={url}
          download
          style={{ color: "#fff", textDecoration: "none" }}
        >
          ⬇ Download
        </a>
      </div>
    </div>
  );
};

export default FBXViewer;
