import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import Styles from "./Plant3DLibraryModal.module.css";
import { SearchIcon } from "../../../assets/Clonos Common Indicators/Icon_Components/SearchIcon";
import { useEffect, useState } from "react";
import { getAllPlant3DModelsMethod } from "../../../utils/Plant3DMethods/Plant3DMethods";
import useToggler from "../../../CustomHooks/TogglerHook";
import { useDispatch } from "react-redux";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
export const Plant3DLibraryModal = ({ isOpen, closeMethod ,getSelectedValue}) => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useToggler();
  const dispatch = useDispatch();
  const [pagination, setPagination] = useState({ page: 1, limit: 15 });
  const [preview, setPreview] = useState({show: false,data: null});

  const handleUseObject = () => {
    getSelectedValue(preview?.data);
    closeMethod(false)
  }

  useEffect(() => {
      getAllPlant3DModelsMethod({dispatch,setterMethod:setData,setIsLoading,pagination})
  },[]);

 

  return (
    <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
      <div className={Styles.container}>
        {!preview?.show ? (
          <>
            <div className={Styles.header}>
              <h4>Import from Plant 3D</h4>
              <CloseIcon onClick={() => closeMethod()} />
            </div>
            <div className={Styles.section}>
              <div className={Styles.searchbar}>
                <SearchIcon color="#8CA1C4" size={"20px"} />
                <input placeholder="Search" />
              </div>
              <div className={Styles.list_wrapper}>
                {data?.data?.map((obj) => {
                  return (
                    <div key={obj?.id} className={Styles.list_item}>
                      <p>{obj?.name}</p>
                      <span
                        onClick={() => setPreview({ show: true, data: obj })}
                      >
                        Preview
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        ) : (
          <>
            <div className={Styles.header}>
              <h4>Object Name</h4>
              <CloseIcon onClick={() => setPreview({ show: false, data: null })}/>
            </div>
            <div style={{overflowY:"scroll"}} className={Styles.preview_section}>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Object Name</h4>
                    <p>{preview?.data?.name || "-"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Location</h4>
                    <p>{preview?.data?.location?.name || "-"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Latitude</h4>
                    <p>{preview?.data?.latitude || "-"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Longitude</h4>
                    <p>{preview?.data?.longitude || "-"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Elevation</h4>
                    <p>{preview?.data?.elevation || "-"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Floor</h4>
                    <p>{preview?.data?.floor || "-"}</p>
                </div>
                <h5>Position</h5>
                <div className={Styles.preview_field_wrapper}>
                    <h4>X</h4>
                    <p>{preview?.data?.position?.X || "0"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Y</h4>
                    <p>{preview?.data?.position?.y || "0"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Z</h4>
                    <p>{preview?.data?.position?.z || "0"}</p>
                </div>
                <h5>Rotation</h5>
                <div className={Styles.preview_field_wrapper}>
                    <h4>X</h4>
                    <p>{preview?.data?.rotation?.x || "0"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Y</h4>
                    <p>{preview?.data?.rotation?.y || "0"}</p>
                </div>
                <div className={Styles.preview_field_wrapper}>
                    <h4>Z</h4>
                    <p>{preview?.data?.rotation?.z || "0"}</p>
                </div>
            </div>
            <div className={Styles.preview_footer}>
                <ClonosButton onClick={handleUseObject} isHollow={true}>Use Object</ClonosButton>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
};
