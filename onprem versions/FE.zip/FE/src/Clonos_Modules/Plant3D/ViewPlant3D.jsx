import { useLocation, useNavigate } from "react-router-dom";
import Styles from "../../ModuleStyles/Plant3D/Viewplant3D.module.css";
import Subbar from "../../components/CommonComponents/ClonosSubbar/Subbar";
import { checkUserHasPermission, getFormatedDate, handleShowErrorAndWarning, hasPermission } from "../../utils/clonosCommon";
import { useEffect, useState } from "react";
import { Card, Tooltip } from "@mui/material";
import { deletePlant3DModelMethod, getSinglePlant3DModelDetails } from "../../utils/Plant3DMethods/Plant3DMethods";
import useToggler from "../../CustomHooks/TogglerHook";
import ClonosSpinner from "../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { useDispatch } from "react-redux";
import NOIMAGE from "../../assets/images/No_image_available.png"
import ClonosConfirmationBox from "../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_MODULE_PLANT_3D, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS } from "../../Constants/Constant";
import { ImagePreviewModal } from "../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal";
import useModuleNameProvider from "../../CustomHooks/ModuleNameProviderHook";
import FBXViewer from "./FBXViewer";
const ViewPlant3D = () => {
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const Location = useLocation();
  const [isLoading, setIsLoading] = useToggler();
  const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_PLANT_3D)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [plant3DDetails, setPlant3DDetails] = useState({});
  const [showLayoutImage,setShowLayoutImage] = useState(false);

  const handleDeletePlant3DModel = async () => {
    const status = await deletePlant3DModelMethod({dispatch,payload:{plant3DIds:[plant3DDetails?.id]}});
    if(status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
        handleShowErrorAndWarning({dispatch,type:"success",message:"Plant 3D deleted successfully.",showTime:"5000"})
        Navigate('/plant3D-modules')
    }
}


  useEffect(() => {
    getSinglePlant3DModelDetails({
      id: Location?.state?.id,
      dispatch,
      setterMethod: setPlant3DDetails,
      setIsLoading,
    });
  }, []);
 
  if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_READ}))
  return isLoading ? (
    <div className={Styles.center_wrapper}>
      <ClonosSpinner />
    </div>
  ) : !Object.keys(plant3DDetails).length ? (
    <div className={Styles.center_wrapper}>
      <h4>No Detais!</h4>
    </div>
  ) : (
    <>
      <Subbar
        isDelete={hasPermission("/delete-plant-3D")}
        isDeleteMethod={() => setShowDeleteDialog(true)}
        isEdit={hasPermission("/edit-plant-3D")}
        isEditMethod={() =>
          Navigate("/edit-plant3D", {
            state: {id:plant3DDetails?.id},
          })
        }
        staticElements={[{key:"Created On :",value: getFormatedDate(plant3DDetails?.createdDate)},{key:"Last Updated On :", value:getFormatedDate(plant3DDetails?.updatedDate)}]}
        isHollow={true}
        subbarData={plant3DDetails}
      />
      <Card style={{ margin: "1rem", borderRadius: "6px" }}>
        <div className={Styles.v_p_container}>
          <div className={Styles.v_p_container_left}>
            <div className={Styles.v_p_left_fields_box}>
              <h4>General Details</h4>
              <div className={Styles.v_p_left_fields_wrapper}>
                <div>
                  <h4 className={Styles.v_p_left_field}>Object Name</h4>
                  <p className={Styles.v_p_left_value}>
                    {plant3DDetails?.name || "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Location</h4>
                  <p className={Styles.v_p_left_field}>
                    {plant3DDetails?.location?.name || "-"}
                  </p>
                </div>
              </div>
            </div>
            <div className={Styles.v_p_left_fields_box}>
              <h4>Geographical Co-ordinate</h4>
              <div className={Styles.v_p_left_fields_wrapper}>
                <div>
                  <h4 className={Styles.v_p_left_field}>Latitude (deg)</h4>
                  <p className={Styles.v_p_left_value}>
                    {!isNaN(plant3DDetails?.latitude)
                      ? plant3DDetails?.latitude
                      : "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Longitude (deg)</h4>
                  <p className={Styles.v_p_left_field}>
                    {!isNaN(plant3DDetails?.longitude)
                      ? plant3DDetails?.longitude
                      : "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Elevation (m)</h4>
                  <p className={Styles.v_p_left_field}>
                    {!isNaN(plant3DDetails?.elevation)
                      ? plant3DDetails?.elevation
                      : "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Floor</h4>
                  <p className={Styles.v_p_left_field}>
                    {!isNaN(plant3DDetails?.floor)
                      ? plant3DDetails?.floor
                      : "-"}
                  </p>
                </div>
              </div>
            </div>
            <div className={Styles.v_p_left_fields_box}>
              <h4>Position</h4>
              <div className={Styles.v_p_left_fields_wrapper}>
                <div>
                  <h4 className={Styles.v_p_left_field}>X</h4>
                  <p className={Styles.v_p_left_value}>
                    {!isNaN(plant3DDetails?.position?.x)
                      ? plant3DDetails?.position?.x
                      : "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Y</h4>
                  <p className={Styles.v_p_left_field}>
                    {!isNaN(plant3DDetails?.position?.y)
                      ? plant3DDetails?.position?.y
                      : "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Z</h4>
                  <p className={Styles.v_p_left_field}>
                    {!isNaN(plant3DDetails?.position?.z)
                      ? plant3DDetails?.position?.z
                      : "-"}
                  </p>
                </div>
              </div>
            </div>
            <div className={Styles.v_p_left_fields_box}>
              <h4>Rotation</h4>
              <div className={Styles.v_p_left_fields_wrapper}>
                <div>
                  <h4 className={Styles.v_p_left_field}>X</h4>
                  <p className={Styles.v_p_left_value}>
                    {!isNaN(plant3DDetails?.rotation?.x)
                      ? plant3DDetails?.rotation?.x
                      : "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Y</h4>
                  <p className={Styles.v_p_left_field}>
                    {!isNaN(plant3DDetails?.rotation?.y)
                      ? plant3DDetails?.rotation?.y
                      : "-"}
                  </p>
                </div>
                <div>
                  <h4 className={Styles.v_p_left_field}>Z</h4>
                  <p className={Styles.v_p_left_field}>
                    {!isNaN(plant3DDetails?.rotation?.z)
                      ? plant3DDetails?.rotation?.y
                      : "-"}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className={Styles.v_p_container_right}>
            <div className={Styles.v_p_layout_image_container}>
              <h4 className={Styles.v_p_3d_detail_header}>Layout Image</h4>
              <div className={Styles.thumbnailHolder}>
                <img
                  onClick={() => setShowLayoutImage(true)}
                  src={
                    plant3DDetails?.layoutImage
                      ? plant3DDetails?.layoutImage?.url
                      : NOIMAGE
                  }
                  loading="lazy"
                />
              </div>
            </div>
            <div className={Styles.v_p_3DModel_container}>
              <h4 className={Styles.v_p_3d_detail_header}>3D Model</h4>
              <div className={Styles.v_p_3DModelHolder}>
                {/* <img
                  src={
                   plant3DDetails?.model3d?.url
                      ? plant3DDetails?.model3d?.url
                      : NOIMAGE
                  }
                  loading="lazy"
                /> */}
                
                <FBXViewer url={plant3DDetails?.model?.url} fallbackImage={NOIMAGE} />
                  

                
                {plant3DDetails?.model && (
                  <Tooltip
                    title={`${plant3DDetails?.model?.name}`}
                  >
                    <p>
                      {plant3DDetails?.model?.name}
                    </p>
                  </Tooltip>
                )}
              </div>
            </div>
          </div>
        </div>
      </Card>
      <ClonosConfirmationBox
        isOpen={showDeleteDialog}
        headerTitle={"Delete Plant 3D Model"}
        message={"Are you sure you want to Delete?"}
        closeModalMethod={setShowDeleteDialog}
        confirmingMethod={handleDeletePlant3DModel}
     />
     <ImagePreviewModal activeImageIndex={0} open={showLayoutImage} closeModalMethod={setShowLayoutImage} images={[plant3DDetails?.layoutImage]}/>
    </>
  );
};

export default ViewPlant3D;
