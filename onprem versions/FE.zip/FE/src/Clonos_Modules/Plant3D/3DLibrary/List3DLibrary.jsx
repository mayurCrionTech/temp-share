import { Card, Tooltip } from "@mui/material"
import { ClonosButton } from "../../../components/CommonComponents/Button/Button"
import { checkUserHasPermission, hasPermission, setSerialNumber } from "../../../utils/clonosCommon"
import ClonosGridNav from "../../../utils/ClonosGridNav"
import ClonosDataGrid from "../../../components/CommonComponents/ClonosDataGrid/ClonosDataGrid"
import { useEffect, useState } from "react"
import { delete3DObjectMethod, get3DlibraryList } from "../../../utils/Plant3DMethods/3DLibraryMethods"
import useToggler from "../../../CustomHooks/TogglerHook"
import { useDispatch } from "react-redux"
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox"
import { UnAuthorizedModal } from "../../../components/CommonComponents/UnAuthorizedPage/UnAuthorizedModal"
import { useNavigate } from "react-router-dom"
import Styles from "../../../ModuleStyles/Plant3D/3DLibrary/List3DLibrary.module.css";
import { Create3DObject } from "./Create3DObject"
import { useSelector } from "react-redux"
import { View3DObject } from "./View3DObject"
import { Edit3DObject } from "./Edit3DObject"
import { CLONOS_GLOBAL_ACTION_CREATE, CLONOS_GLOBAL_ACTION_DELETE, CLONOS_GLOBAL_ACTION_READ, CLONOS_GLOBAL_ACTION_UPDATE, CLONOS_GLOBAL_MODULE_3D_LIBRARY, CLONOS_GLOBAL_MODULE_PLANT_3D, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS } from "../../../Constants/Constant"
import { getStandard3DOjectsMethod, getUserUploaded3DOjectsMethod } from "../../../utils/Plant3DMethods/Plant3DMethods"
import CommonNavigator from "../../../components/CommonComponents/Navigator/Navigator"
import useModuleNameProvider from "../../../CustomHooks/ModuleNameProviderHook"


const List3DLibrary = () => {
    const dispatch = useDispatch();
    const Navigate = useNavigate()
    const [data,setData] = useState({});
    const moduleName = useModuleNameProvider(CLONOS_GLOBAL_MODULE_3D_LIBRARY)
    const [isLoading,setIsLoading] = useToggler();
    const [activeTab, setActiveTab] = useState("User Uploaded Models");
    const [selectedRows,setSelectedRows] = useState([]);
    const [selected3DObject,setSelected3DObject] = useState({});
    const [pagination,setPagination] = useState({page:1,limit:15});
    const [showConfirmationDialog,setShowConfirmationDialog] = useState(false);
    const [showCreateObjectModal,setShowCreateObjectModal] = useState(false);
    const [showViewObjectModal,setShowViewObjectModal] = useState(false);
    const [showEditObjectModal,setShowEditObjectModal] = useState(false);
     const [refreshApi,setRefreshApi]=useToggler()

    const columns = [
        {
            field:"index",
            headerName:"SI.NO",
            width:100,
        },
        {
            field:"name",
            headerName:"OBJECT NAME",
            flex:1,
            renderCell:(param) => {
                return  <Tooltip title={param?.row?.name}>
                            <p>{param?.row?.name}</p>
                        </Tooltip>
            }
        },
        {
            field:"file",
            headerName:"FILE",
            // flex:1,
            width:100,
            renderCell:(param) => {

       
                return  <p onClick={() => {
                    setSelected3DObject(param?.row?.id)
                    setShowViewObjectModal(true)
                }}  className="clonos_datagrid_link">View</p>
            }
        },
    ]

const [navigatorValues, setNavigatorValues] = useState([
  {
    value: "User Uploaded Models",
    status: true,
    visibility: true,
    uniqueKey: "User Uploaded Models"
  },
  {
    value: "Standard Models",
    status: false,
    visibility: false,
    uniqueKey: "Standard Models"
  }
]);


 const getActiveTab = (val) => {
 

    setActiveTab(val);
    setPagination({ limit: 15, page: 1 });

    setNavigatorValues(prev =>
        prev.map(item => ({
            ...item,
            status: item.value === val
        }))
    );
};


    const handleDelete3DObject = async() => {
        await delete3DObjectMethod({dispatch,payload:{modelIds:selectedRows},next: () => {
      setRefreshApi(prev => !prev);      
      setShowConfirmationDialog(false);  
    }})
    };

    const handleEditPlant3D = () => {
        setShowEditObjectModal(true);
    };

    const updateListMethod = async (val) => {
        const {status} = val;
        if(status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS || status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            // get3DlibraryList({dispatch,setterMethod:setData,setIsLoading,pagination:{page:1,limit:15}});
            if(activeTab === 'User Uploaded Models'){
                const userUploadedRes = await getUserUploaded3DOjectsMethod({dispatch,setIsLoading, pagination});
                if (userUploadedRes?.data?.length) {
                    setData(userUploadedRes);
                }
            }
            setSelectedRows([]);
        }
    }

    useEffect(() => {
        const fetchData = async () => {
            if(activeTab === 'User Uploaded Models'){
                const userUploadedRes = await getUserUploaded3DOjectsMethod({dispatch,setIsLoading, pagination});
                if (userUploadedRes?.data?.length) {
                    setData(userUploadedRes);
                }
            }
            if(activeTab === 'Standard Models'){
                const standardRes = await getStandard3DOjectsMethod({dispatch,setIsLoading, pagination});
                if (standardRes?.data?.length) {
                    setData(standardRes);
                }
            }
        };
    
        fetchData();
    },[pagination,activeTab,refreshApi])

    if(checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_READ}))
    return <>
            <ClonosGridNav >
                <div className={Styles.p_3d_nav_right}>
                        {checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_CREATE}) ? <div><ClonosButton isDisabled={activeTab === 'Standard Models'} onClick={() => setShowCreateObjectModal(true)} variant={"filled"}>+ Add 3D Object</ClonosButton></div> : <></>}
                </div>
            </ClonosGridNav>
            <Card style={{margin:"0rem 1rem 1rem 1rem",height:"100%"}}>
                <CommonNavigator
                  web={true}
                  values={navigatorValues}
                  getSelectedValue={getActiveTab}
                />
                <div className={Styles.l_3d_datagrid_wrapper}>
                    {
                        activeTab === "User Uploaded Models" ? <ClonosDataGrid 
                        rows={setSerialNumber(data?.data,pagination?.page,pagination?.limit)}
                        columns={columns}
                        isEditMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE}) ? handleEditPlant3D : false}
                        isDeleteMethod={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE}) ? () => setShowConfirmationDialog(true) : false}
                        uniqueIdField="id"
                        onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                        isLoading={isLoading}
                        totalCount={data?.totalDataCount}
                        pageLimit={pagination.limit}
                        checkboxSelection={checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_DELETE}) || checkUserHasPermission({moduleName,action:CLONOS_GLOBAL_ACTION_UPDATE})}
                        handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                    /> : <></>
                    }
                    {
                        activeTab === "Standard Models" ? <ClonosDataGrid 
                        rows={data?.data?.length > 0 ? setSerialNumber(data?.data,pagination?.page,pagination?.limit) : []}
                        columns={columns}
                        uniqueIdField="id"
                        onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                        isLoading={isLoading}
                        totalCount={data?.totalDataCount}
                        pageLimit={pagination.limit}
                        checkboxSelection={false}
                        handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                    /> : <></>
                    }
                </div>
            </Card>
            <ClonosConfirmationBox
                isOpen={showConfirmationDialog}
                headerTitle={"Delete 3D Object"}
                message={"Are you sure you want to Delete?"}
                closeModalMethod={setShowConfirmationDialog}
                confirmingMethod={handleDelete3DObject}
            />
            <Create3DObject isOpen={showCreateObjectModal} closeMethod={setShowCreateObjectModal} updateListMethod={updateListMethod}/>
            <View3DObject isOpen={showViewObjectModal} closeMethod={setShowViewObjectModal} id={selected3DObject} updateListMethod={updateListMethod} type={activeTab} setRefreshApi={setRefreshApi}/>
            <Edit3DObject isOpen={showEditObjectModal} closeMethod={setShowEditObjectModal} id={selectedRows[0]} updateListMethod={updateListMethod}/>
    </>

    return <UnAuthorizedModal type={"NOT_AUTHORIZED"}/>
}


export default List3DLibrary