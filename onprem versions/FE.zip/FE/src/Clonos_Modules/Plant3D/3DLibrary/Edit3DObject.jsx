import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import Styles from "../../../ModuleStyles/Plant3D/3DLibrary/Create3DObject.module.css";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import { useEffect, useState } from "react";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { create3DObjectMethod, edit3DObjectMethod, getSingle3DObjectDetails } from "../../../utils/Plant3DMethods/3DLibraryMethods";
import { useDispatch } from "react-redux";
import useToggler from "../../../CustomHooks/TogglerHook";
import { globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS } from "../../../Constants/Constant";
let primaryObject = {};
export const Edit3DObject = ({ isOpen, closeMethod,updateListMethod,id }) => {
    const dispatch = useDispatch();
    const [isLoading,setIsLoading] = useToggler();
    const [fetchLoading,setFetchLoading] = useToggler();
    const [formData,setFormData] = useState({});
    const [changedData,setChangedData] = useState({});
    const handleGetErrorActivatorInformation = (props) => {
        primaryObject = { ...primaryObject, [props.uniqueKey]: props }
    }

    const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
        if (response === null) {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": false } }
            return false
        }
        else {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": true } }
            return true
        }
    }

    const handleGetValues = (props) => {
        const { name, selectedOption, updatedValue, uniqueKey, type,files } = props;
        if(type === "text"){
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setChangedData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
            })
        } else if(type === "file" || name === "needToDeleteDocuments"){
            if(name === "needToDeleteDocuments"){
                if(uniqueKey === 'model3d') delete formData.model3d;
                if(uniqueKey === 'model2d') delete formData.model2d;
            }
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setChangedData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ?  files[0] : null}
            })
        }
    }

    const handleSaveDetails = async ({ data, primaryObject }) => {
        if (!globalHandleIsAllRequiredFieldAvailable({ data, primaryObject })) {
            handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide all required fields",showTime:'5000'})
            return;
        } else {
            let response = await edit3DObjectMethod({dispatch,modelId:formData?.id,changedData:data,setIsLoading});
            if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
                closeMethod(false);
                updateListMethod(response);
                handleShowErrorAndWarning({dispatch,type:"success",message:"3D Object Edited Sucessfully",showTime:'5000'})
            }
        }
        
    }

    useEffect(() => {
        if(isOpen){
            getSingle3DObjectDetails({id,dispatch,setterMethod:setFormData,setIsLoading:setFetchLoading,type:"User Uploaded Models"})
        }
    },[isOpen])

  return (
    <Modal stopOverlayCloser={true} isOpen={isOpen} closeModalMethod={closeMethod}>
      <div className={Styles.c_3d_o_container}>
        {
            fetchLoading ? <div className={Styles.center_wrapper} ><ClonosSpinner/></div> : Object.keys(formData)?.length  ? <div className={Styles.c_3d_o_inner_container}>
            <div className={Styles.c_3d_o_header}>
              <h4>Edit 3D File</h4>
              <CloseIcon onClick={() => closeMethod(false)} />
            </div>
            <div className={Styles.c_3d_o_section}>
              <div className={Styles.inp_wrapper}>
                  <ClonosInput
                  type="text"
                  isLabel={true}
                  label="Object Name"
                  isMandatory={false}
                  uniqueKey={"name"}
                  areaLabel={"3D object name"}
                  placeholder={"Object Name"}
                  handleGetValues={handleGetValues}
                  defaultValue={formData?.name}
                  />
              </div>
              <h4>3D Model & Layout Image</h4>
              <div className={Styles.c_3d_o_files_wrapper}>
                <div>
                <FileUploader
                  limit={1}
                  fileSizeInMB={10}
                  label={"Upload 3D Model"}
                  isMandatory={true}
                  uniqueKey={"model3d"}
                  typeOfRecord={"Image"}
                  defaultValue={formData?.model3d ? [formData?.model3d] : []}
                  localPreviousPageFiles={changedData?.model3d ? [changedData?.model3d] : []}
                  acceptableFileTypes={[".fbx"]}
                  errorMessage={"Please provide 3D Model!"}
                  handleGetSelectedData={handleGetValues}
                  handleGetErrorActivatorInformahandleGetValuestion={handleGetErrorActivatorInformation}
                />
                </div>
                <div>
                <FileUploader
                  limit={1}
                  fileSizeInMB={10}
                  isMandatory={true}
                  typeOfRecord={"Image"}
                  label={"Upload Layout Image"}
                  uniqueKey={"model2d"}
                  defaultValue={formData?.model2d ? [formData?.model2d] : []}
                  localPreviousPageFiles={changedData?.model2d ? [changedData?.model2d] : []}
                  acceptableFileTypes={[".png", ".jpg", ".jpeg"]}
                  handleGetSelectedData={handleGetValues}
                  errorMessage={"Please provide layout image!"}
                  handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                />
                </div>
              </div>
            </div>
            <div className={Styles.c_3d_o_btns_wrapper}>
                  <div>
                      <ClonosButton onClick={() => closeMethod(false)}  style={{padding:"0.5rem 2rem"}}>Cancel</ClonosButton>
                      <ClonosButton loading={isLoading} onClick={() => handleSaveDetails({data:changedData,primaryObject})} variant="filled" style={{padding:"0.5rem 2rem"}}>Save</ClonosButton>
                  </div>
            </div>
          </div> : <div className={Styles.center_wrapper}>
            <h4>No Data</h4>
          </div>
        }
      </div>
    </Modal>
  );
};
