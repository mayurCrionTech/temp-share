import { useEffect, useState } from "react";
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import DeleteIcon from "../../../assets/Clonos Common Indicators/Icon_Components/DeleteIcon";
import EditIcon from "../../../assets/Clonos Common Indicators/Icon_Components/EditIcon";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import Styles from "../../../ModuleStyles/Plant3D/3DLibrary/View3DObject.module.css";
import { delete3DObjectMethod, getSingle3DObjectDetails } from "../../../utils/Plant3DMethods/3DLibraryMethods";
import useToggler from "../../../CustomHooks/TogglerHook";
import { useDispatch } from "react-redux";
import ClonosSpinner from "../../../components/CommonComponents/ClonosSpinner/ClonosSpinner";
import { Edit3DObject } from "./Edit3DObject";
import ClonosConfirmationBox from "../../../components/CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox";
import { Tooltip } from "@mui/material";
import ClonosTooltip from "../../../components/CommonComponents/ClonosTooltip/ClonosTooltip";
import { ImagePreviewModal } from "../../../components/CommonComponents/ImagePreviewModal/ImagePreviewModal";
import FBXViewer from "../FBXViewer";

export const View3DObject = ({ isOpen, closeMethod, id,updateListMethod,type,setRefreshApi }) => {
  const dispatch = useDispatch();
  const [data, setData] = useState({});
  const [isLoading, setIsLoading] = useToggler();
  const [showEditModal,setShowEditModal] = useState();
  const [showLayoutImage,setShowLayoutImage] = useState(false)
  const [showConfirmationDialog,setShowConfirmationDialog] = useState(false);
 

const handleDelete3DObject = async () => {
  await delete3DObjectMethod({
    dispatch,
    payload: { modelIds: [id] },
    next: () => {
      setRefreshApi(prev => !prev);      // ✅ trigger refresh
      setShowConfirmationDialog(false);  // ✅ close modal
    }
  });
};

  useEffect(() => {
    if (isOpen) getSingle3DObjectDetails({id,dispatch,setterMethod: setData,setIsLoading,type});
    return () => {
      setData({});
    };
  }, [isOpen]);


  return (
    <>
    <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
      <div className={Styles.v_3d_o_container}>
        {isLoading ? (
          <div className={Styles.center_wrapper}>
            <ClonosSpinner />
          </div>
        ) : Object.keys(data)?.length === 0 || !data ? (
          <div className={Styles.center_wrapper}>
            <h4>No Data Present!</h4>
          </div>
        ) : (
          <div className={Styles.v_3d_o_inner_container}>
            <div className={Styles.v_3d_o_header}>
              <h4>View 3D File</h4>
              <div className={Styles.v_3d_o_header_btns}>
                {
                  type === 'User Uploaded Models' ? <>
                    <EditIcon onClick={() => {
                    closeMethod(false);
                    setShowEditModal(true);
                }} />
                <DeleteIcon onClick={() => setShowConfirmationDialog(true)} />
                  </> : <></>
                }
                <CloseIcon onClick={() => closeMethod(false)} />
              </div>
            </div>
            <div className={Styles.v_3d_o_section}>
              <div className={Styles.v_3d_o_field_wrapper}>
                <div className={Styles.v_3d_o_field}>
                  <h4>Object Name</h4>
                  <p>{data?.name}</p>
                </div>
                <div className={Styles.v_3d_o_field}>
                  <h4>3D Model</h4>
                  <div className={Styles.v_3d_o_fbxviewer}>
                    {/* <img width={32} height={32} src={data?.model3d?.url} /> */}
                      {isOpen && data?.model3d?.url && (
                        <FBXViewer url={data.model3d.url} />
                      )}  
                    <ClonosTooltip content={data?.model3d?.name}><p>{data?.model3d?.name}</p></ClonosTooltip>
                  </div>
                </div>
                <div className={Styles.v_3d_o_field}>
                  <h4>Layout Image</h4>
                  <div>
                    <img onClick={() => setShowLayoutImage(true)} width={32} height={32} src={data?.model2d?.url} />
                    <ClonosTooltip content={data?.model2d?.name}><p>{data?.model2d?.name}</p></ClonosTooltip>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
    {
        showEditModal ? <Edit3DObject isOpen={showEditModal} closeMethod={setShowEditModal} id={id} updateListMethod={updateListMethod}/> : <></>
    }
    <ClonosConfirmationBox
        isOpen={showConfirmationDialog}
        headerTitle={"Delete 3D Object"}
        message={"Are you sure you want to Delete?"}
        closeModalMethod={setShowConfirmationDialog}
        confirmingMethod={handleDelete3DObject}
    />
    <ImagePreviewModal activeImageIndex={0} open={showLayoutImage} closeModalMethod={setShowLayoutImage} images={[data?.model2d]}/>
    </>   
  );
};
