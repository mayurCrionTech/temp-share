import { Style } from "@material-ui/icons";
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import Modal from "../../../components/CommonComponents/Modal/Modal";
import Styles from "../../../ModuleStyles/Plant3D/3DLibrary/Create3DObject.module.css";
import ClonosInput from "../../../components/CommonComponents/ClonosInput/ClonosInput";
import FileUploader from "../../../components/CommonComponents/FileUploader/FileUploader";
import { useState } from "react";
import { ClonosButton } from "../../../components/CommonComponents/Button/Button";
import { create3DObjectMethod } from "../../../utils/Plant3DMethods/3DLibraryMethods";
import { useDispatch } from "react-redux";
import useToggler from "../../../CustomHooks/TogglerHook";
import { globalHandleIsAllRequiredFieldAvailable, handleShowErrorAndWarning } from "../../../utils/clonosCommon";
import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS } from "../../../Constants/Constant";
let primaryObject = {};
export const Create3DObject = ({ isOpen, closeMethod,updateListMethod }) => {
    const dispatch = useDispatch();
    const [isLoading,setIsLoading] = useToggler();
    const [formData,setFormData] = useState({})

    const handleGetErrorActivatorInformation = (props) => {
        primaryObject = { ...primaryObject, [props.uniqueKey]: props }
    }

    const handlePrimaryObjectModifier = ({ uniqueKey, response }) => {
        if (response === null) {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": false } }
            return false
        }
        else {
            primaryObject = { ...primaryObject, [uniqueKey]: { ...primaryObject[uniqueKey], "value": true } }
            return true
        }
    }

    const handleGetValues = (props) => {
        const { name, selectedOption, updatedValue, uniqueKey, type,files } = props;
        if(type === "text"){
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: valueSetter ? updatedValue : null }
            })
        } else if(type === "file"){
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => {
                return { ...prev, [uniqueKey]: files[0] }
            })
        }
    }

    const handleSaveDetails = async ({ data, primaryObject }) => {
        if (!globalHandleIsAllRequiredFieldAvailable({ data, primaryObject })) {
            handleShowErrorAndWarning({dispatch,type:"error",message:"Please provide all required fields",showTime:'5000'})
            return;
        } else {
            let response = await create3DObjectMethod({dispatch,formData,setIsLoading});
           
            if(response?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
              updateListMethod(response)
              closeMethod(false);
              handleShowErrorAndWarning({dispatch,type:"success",message:"3D Object Created Sucessfully",showTime:'5000'})
            }
        }
        
    }

  return (
    <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
      <div className={Styles.c_3d_o_container}>
        <div className={Styles.c_3d_o_inner_container}>
          <div className={Styles.c_3d_o_header}>
            <h4>Upload 3D File</h4>
            <CloseIcon onClick={() => closeMethod(false)} />
          </div>
          <div className={Styles.c_3d_o_section}>
            <div className={Styles.inp_wrapper}>
                <ClonosInput
                type="text"
                isLabel={true}
                label="Object Name"
                isMandatory={false}
                uniqueKey={"name"}
                areaLabel={"3D object name"}
                placeholder={"Object Name"}
                handleGetValues={handleGetValues}
                />
            </div>
            <h4>3D Model & Layout Image</h4>
            <div className={Styles.c_3d_o_files_wrapper}>
              <div>
              <FileUploader
                limit={1}
                fileSizeInMB={10}
                label={"Upload 3D Model"}
                isMandatory={true}
                uniqueKey={"model"}
                typeOfRecord={"Image"}
                // localPreviousPageFiles={}
                acceptableFileTypes={[".fbx"]}
                errorMessage={"Please provide 3D Model!"}
                handleGetSelectedData={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
              </div>
              <div>
              <FileUploader
                limit={1}
                fileSizeInMB={10}
                isMandatory={true}
                typeOfRecord={"Image"}
                label={"Upload Layout Image"}
                uniqueKey={"layoutImage"}
                // localPreviousPageFiles={}
                acceptableFileTypes={[".png", ".jpg", ".jpeg"]}
                handleGetSelectedData={handleGetValues}
                errorMessage={"Please provide layout image!"}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
              </div>
            </div>
          </div>
          <div className={Styles.c_3d_o_btns_wrapper}>
                <div>
                    <ClonosButton onClick={() => closeMethod(false)}  style={{padding:"0.5rem 2rem"}}>Cancel</ClonosButton>
                    <ClonosButton loading={isLoading} onClick={() => handleSaveDetails({data:formData,primaryObject})} variant="filled" style={{padding:"0.5rem 2rem"}}>Save</ClonosButton>
                </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};
