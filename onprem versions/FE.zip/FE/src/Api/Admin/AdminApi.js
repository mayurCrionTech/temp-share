import axios from 'axios';
import { getToken } from '../../utils/clonosCommon';
import { axiosInstance } from '../AxioClient';

const API_BASE_URL = process.env.REACT_APP_PRODUCTION_CONFIG;

const axiosForJSON = axiosInstance('application/json');

// Organizations
export const getOrganizations = (params = {}) => {
  return axiosForJSON.get('/organizations', {
    params,
    headers: { Authorization: `Bearer ${getToken()}` }
  });
};

export const getOrganization = (id) => {
  return axiosForJSON.get(`/organizations/${id}`, {
    headers: { Authorization: `Bearer ${getToken()}` }
  });
};

export const createOrganization = (data) => {
  return axiosForJSON.post('/organizations', data, {
    headers: { Authorization: `Bearer ${getToken()}` }
  });
};

export const updateOrganization = (id, data) => {
  return axiosForJSON.put(`/organizations/${id}`, data, {
    headers: { Authorization: `Bearer ${getToken()}` }
  });
};

export const deleteOrganization = (id) => {
  const token = getToken();
  return axiosForJSON.delete(`/organizations/${id}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

// Business Units
export const getBusinessUnits = async (organizationId, params = {}) => {
  try {
    const axiosClient = axiosInstance('application/json');
    const response = await axiosClient.get(`/businessUnits`, {
      params: {
        ...params,
        organization: organizationId,
        selectFields: "name,organization,shortName,isEnabled,usersCount"
      },
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in getBusinessUnits:', error);
    throw error;
  }
};

export const getBusinessUnit = async (businessUnitId) => {
  try {
    const response = await axiosInstance('application/json').get(`/businessUnits/${businessUnitId}`, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in getBusinessUnit:', error);
    throw error;
  }
};

export const createBusinessUnit = async (organizationId, data) => {
  try {
    const axiosClient = axiosInstance('application/json');
    const response = await axiosClient.post(`/businessUnits`, {
      ...data,
      organization: organizationId
    }, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in createBusinessUnit:', error);
    throw error;
  }
};

export const updateBusinessUnit = async (businessUnitId, data) => {
  try {
    const response = await axiosInstance('application/json').put(`/businessUnits/${businessUnitId}`, data, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in updateBusinessUnit:', error);
    throw error;
  }
};

export const enableBusinessUnit = async (businessUnitId) => {
  try {
    const response = await axiosInstance('application/json').put(`/businessUnits/${businessUnitId}/enable`, {}, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in enableBusinessUnit:', error);
    throw error;
  }
};

export const disableBusinessUnit = async (businessUnitId) => {
  try {
    const response = await axiosInstance('application/json').put(`/businessUnits/${businessUnitId}/disable`, {}, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in disableBusinessUnit:', error);
    throw error;
  }
};

export const enableBusinessUnits = async (businessUnitIds) => {
  try {
    const response = await axiosInstance('application/json').put(`/businessUnits/enable`, {
      businessUnits: businessUnitIds
    }, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in enableBusinessUnits:', error);
    throw error;
  }
};

export const disableBusinessUnits = async (businessUnitIds) => {
  try {
    const response = await axiosInstance('application/json').put(`/businessUnits/disable`, {
      businessUnits: businessUnitIds
    }, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in disableBusinessUnits:', error);
    throw error;
  }
};

export const deleteBusinessUnit = async (businessUnitId) => {
  try {
    const response = await axiosInstance('application/json').delete(`/businessUnits/${businessUnitId}`, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in deleteBusinessUnit:', error);
    throw error;
  }
};

export const deleteBusinessUnits = async (businessUnitIds) => {
  try {
    const response = await axiosInstance('application/json').delete(`/businessUnits`, {
      data: { businessUnits: businessUnitIds },
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in deleteBusinessUnits:', error);
    throw error;
  }
};

// Departments
export const getDepartments = async (businessUnitId, params = {}) => {
  try {
    const axiosClient = axiosInstance('application/json');
    const response = await axiosClient.get(`/departments`, {
      params: {
        ...params,
        businessUnit: businessUnitId,
        selectFields: "name,businessUnit,isEnabled"
      },
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in getDepartments:', error);
    throw error;
  }
};

export const getDepartment = async (departmentId) => {
  try {
    const response = await axiosInstance('application/json').get(`/departments/${departmentId}`, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in getDepartment:', error);
    throw error;
  }
};

export const createDepartment = async (businessUnitId, data) => {
  try {
    const axiosClient = axiosInstance('application/json');
    const response = await axiosClient.post(`/departments`, {
      ...data,
      businessUnit: businessUnitId
    }, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in createDepartment:', error);
    throw error;
  }
};

export const updateDepartment = async (departmentId, data, businessUnitId) => {
  try {
    const response = await axiosInstance('application/json').put(`/departments/${departmentId}`, data, {
      params: { businessUnit: businessUnitId },
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in updateDepartment:', error);
    throw error;
  }
};

export const enableDepartment = async (departmentId) => {
  try {
    const response = await axiosInstance('application/json').patch(`/departments/${departmentId}/enable`, {}, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in enableDepartment:', error);
    throw error;
  }
};

export const disableDepartment = async (departmentId) => {
  try {
    const response = await axiosInstance('application/json').patch(`/departments/${departmentId}/disable`, {}, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in disableDepartment:', error);
    throw error;
  }
};

export const enableDepartments = async (departmentIds) => {
  try {
    const response = await axiosInstance('application/json').patch(`/departments/enable`, {
      departments: departmentIds
    }, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in enableDepartments:', error);
    throw error;
  }
};

export const disableDepartments = async (departmentIds) => {
  try {
    const response = await axiosInstance('application/json').patch(`/departments/disable`, {
      departments: departmentIds
    }, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in disableDepartments:', error);
    throw error;
  }
};

export const deleteDepartment = async (departmentId) => {
  try {
    const response = await axiosInstance('application/json').delete(`/departments/${departmentId}`, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in deleteDepartment:', error);
    throw error;
  }
};

export const deleteDepartments = async (departmentIds) => {
  try {
    const response = await axiosInstance('application/json').delete(`/departments`, {
      data: { departments: departmentIds },
      headers: { Authorization: `Bearer ${getToken()}` }
    });
    return response;
  } catch (error) {
    console.error('Error in deleteDepartments:', error);
    throw error;
  }
};

// User Types
export const getUserTypes = async (businessUnitId, departmentId, params = {}) => {
  try {
    const response = await axiosInstance().get(`/userTypes`, {
      params: {
        businessUnit: businessUnitId,
        department: departmentId,
        ...params,
        selectFields:"name,businessUnit,department,isEnabled"
      }
    });
    
    return response;
  } catch (error) {
    
    throw error;
  }
};

export const createUserType = async (businessUnitId, departmentId, data) => {
  try {
    const response = await axiosInstance().post(`/userTypes`, {
      ...data,
      businessUnit: businessUnitId,
      department: departmentId
    });
   
    return response;
  } catch (error) {
   
    throw error;
  }
};

export const updateUserType = async (userTypeId, data) => {
  try {
    const response = await axiosInstance().put(`/userTypes/${userTypeId}`, data);
    return response;
  } catch (error) {
    throw error;
  }
};

export const enableUserType = async (userTypeId) => {
  try {
    const response = await axiosInstance().patch(`/userTypes/${userTypeId}/enable`);
   
    return response;
  } catch (error) {
   
    throw error;
  }
};

export const disableUserType = async (userTypeId) => {
  try {
    const response = await axiosInstance().patch(`/userTypes/${userTypeId}/disable`);
   
    return response;
  } catch (error) {
 
    throw error;
  }
};

export const deleteUserType = async (userTypeId) => {
  try {
    const response = await axiosInstance().delete(`/userTypes/${userTypeId}`);
   
    return response;
  } catch (error) {

    throw error;
  }
};

// Designations
export const getDesignations = async (businessUnitId, userTypeId, params = {}) => {
  try {
    const response = await axiosInstance().get(`/designations`, {
      params: {
        businessUnit: businessUnitId,
        userType: userTypeId,
        ...params,
        selectFields: "name,businessUnit,userType,isEnabled,permissions",
        populateFields: "permissions"
      }
    });
 
    return response;
  } catch (error) {
   
    throw error;
  }
};

export const createDesignation = async (businessUnitId, userTypeId, data) => {
  try {
    const response = await axiosInstance().post(`/designations`, {
      ...data,
      businessUnit: businessUnitId,
      userType: userTypeId
    });
  
    return response;
  } catch (error) {
   
    throw error;
  }
};

export const updateDesignation = async (designationId, data) => {
  try {
    const response = await axiosInstance().put(`/designations/${designationId}`, data);

    return response;
  } catch (error) {
    
    throw error;
  }
};

export const enableDesignation = async (designationId) => {
  try {
    const response = await axiosInstance().patch(`/designations/${designationId}/enable`);
   
    return response;
  } catch (error) {

    throw error;
  }
};

export const disableDesignation = async (designationId) => {
  try {
    const response = await axiosInstance().patch(`/designations/${designationId}/disable`);
   
    return response;
  } catch (error) {
  
    throw error;
  }
};

export const deleteDesignation = async (designationId) => {
  try {
    const response = await axiosInstance().delete(`/designations/${designationId}`);
    return response;
  } catch (error) {

    throw error;
  }
};

// Permissions
export const getPermissions = () => {
  const token = getToken();
  return axios.get(`${API_BASE_URL}/permissions`, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const updateDesignationPermissions = (designationId, permissions) => {
  const token = getToken();
  return axios.put(`${API_BASE_URL}/designations/${designationId}/permissions`, { permissions }, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const getAllPermissionGroups = async (params = {}) => {
  try {
    const response = await axiosInstance().get('/permissionGroups', { params });
    
    return response;
  } catch (error) {
  
    throw error;
  }
};

export const getAllPermissions = async (params = {}) => {
  try {
    const response = await axiosInstance().get('/permissions', { params });

    return response;
  } catch (error) {
  
    throw error;
  }
};

// Shift Management APIs
export const createShift = (data) => {
  return axios.post(`${API_BASE_URL}/api/v1/shifts`, data, {
    headers: { Authorization: `Bearer ${getToken()}` }
  });
};

export const getShifts = (params) => {
  return axios.get(`${API_BASE_URL}/api/v1/shifts`, {
    params,
    headers: { Authorization: `Bearer ${getToken()}` }
  });
};

export const updateShift = (id, data) => {
  return axios.put(`${API_BASE_URL}/api/v1/shifts/${id}`, data, {
    headers: { Authorization: `Bearer ${getToken()}` }
  });
};

export const deleteShift = (id) => {
  return axios.delete(`${API_BASE_URL}/api/v1/shifts`, {
    data: { shiftsToDelete: [id] },
    headers: { Authorization: `Bearer ${getToken()}` }
  });
}; 