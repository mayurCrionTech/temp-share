import { getToken } from "../../utils/clonosCommon";
import { axiosInstance } from "../AxioClient";
const axiosForJSON = axiosInstance("application/json");


export function createDropdownsAPI({ payload }) {
    const token = getToken();
    return axiosForJSON.post(`dropdowns/create`, payload, {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    });
}
