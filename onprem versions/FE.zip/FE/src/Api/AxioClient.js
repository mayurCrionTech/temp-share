// import axios from "axios";
// import { getToken } from "../utils/clonosCommon";
// import configs from "../config";


// /*
// date            qid / cr#         comments
// 15-Apr-2026     CR0014            The secret key(X-device-key) is stored in session storage as x-device-key and is sent in the request headers for each API call.

// */

// export const axiosInstance = (contentType = "application/json") => {
//   const token = getToken();

//   const secretKey =JSON.parse(sessionStorage.getItem("x-device-key"))
//   // console.log(secretKey,"secretKey")
//   if(contentType === "application/json") {
//     const axiosClient = axios.create({
//       baseURL: `${configs?.url}/api/v1`,

//       headers: {
//         Accept: "application/json",
//         "Content-Type":contentType,
//         Authorization: "Bearer " + token,
//         "x-device-key":secretKey
//       },
//     })
//     return axiosClient
//   } else {
//     const axiosClient = axios.create({
//       baseURL: `${configs?.url}/api/v1`,
//       headers: {
//         Authorization: "Bearer " + token,
//          "x-device-key":secretKey
//       },
//     })
//     return axiosClient
//   }
//  };

//   const secretKey =JSON.parse(sessionStorage.getItem("secretKey"))
// export const loginAxiosClient = axios.create({
//   baseURL: `${configs.url}/api/v1`,
//   headers: {
//     Accept: "application/json",
//     "Content-Type": "application/json",
//     "x-device-key":secretKey
//   },
// });



// /*
// date            qid / cr#         comments
// 15-Apr-2026     CR0014            The secret key(X-device-key) is stored in session storage as x-device-key and is sent in the request headers for each API call.

// */

import axios from "axios";
import { getToken } from "../utils/clonosCommon";
import configs from "../config";

export const axiosInstance = (contentType = "application/json") => {
  const token = getToken();
  const secretKey = JSON.parse(sessionStorage.getItem("x-device-key"));

  const axiosClient = axios.create({
    baseURL: `${configs?.url}/api/v1`,
    headers:
      contentType === "application/json"
        ? {
            Accept: "application/json",
            "Content-Type": contentType,
            Authorization: "Bearer " + token,
            "x-device-key": secretKey,
          }
        : {
            Authorization: "Bearer " + token,
            "x-device-key": secretKey,
          },
  });

  // ✅ APPLY INTERCEPTOR FOR ALL REQUESTS
  axiosClient.interceptors.response.use(
    (response) => response,
    (error) => {
      if (
      error?.response?.status === 401 &&
      window.location.pathname !== "/" // already on login page
    ) {
      sessionStorage.clear();
      window.location.href = "/";
    }
      return Promise.reject(error);
    }
  );

  return axiosClient;
};

 const secretKey = JSON.parse(sessionStorage.getItem("x-device-key"));
export const loginAxiosClient = axios.create({
  baseURL: `${configs.url}/api/v1`,
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
    "x-device-key":secretKey
  },
});

loginAxiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (
      error?.response?.status === 401 &&
      window.location.pathname !== "/" // already on login page
    ) {
      sessionStorage.clear();
      window.location.href = "/";
    }

    return Promise.reject(error);
  }
);