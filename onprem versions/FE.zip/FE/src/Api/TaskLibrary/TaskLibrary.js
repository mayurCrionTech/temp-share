
import { getToken } from "../../utils/clonosCommon";
import { axiosInstance } from "../AxioClient";
const axiosForJSON = axiosInstance("application/json");

export function getAllTasksAPI() {
    const token = getToken();
    const optionalParams = { page: 1, limit: 100 }
    return axiosForJSON.get(`workorders/tasks`, {
        headers: {
            Authorization: `Bearer ${token}`,
        },
        params: optionalParams
    });
}