import * as React from 'react';
import { InputLabel, StyledEngineProvider } from "@mui/material";
import "./ClonosLabel.css"; 

const ClonosLabel = ({ children  }) => {

    return <StyledEngineProvider injectFirst>
        <InputLabel>{children}</InputLabel>
    </StyledEngineProvider>
}

export default ClonosLabel;