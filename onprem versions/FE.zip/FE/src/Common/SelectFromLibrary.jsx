import React, { useCallback, useState } from 'react'
import Styles from "../components/CommonComponents/DynamicDropdown/DynamicDropdown.module.css"
import Modal from '../components/CommonComponents/Modal/Modal'
import closeIcon from "../assets/UIUX/icons/WO/circle-x-filled.svg"
import searchIcon from "../assets/UIUX/icons/WO/search-1.svg"
import ClonosSpinner from "../assets/Clonos Common Indicators/Clonos_Spinner.svg"
import { useEffect } from 'react'
import AppUrl from '../utils/AppUrl'
import { debounce } from '../utils/clonosCommon'
import useToggler from '../CustomHooks/TogglerHook'
import { doGetApiCall } from '../utils/ClonosApi'
import { IoIosClose } from 'react-icons/io'

let loadMore = true;

const types = [
    'ASSET',
    'USER',
    'TEAM'
];

const config = {
    ASSET: {
        apiUrl: AppUrl.getAssetForDropdown,
        label: 'Asset From Library',
        heading: 'Asset From Library',
        searchKey: 'assetName'
    },
    USER: {
        apiUrl: AppUrl.getUserForDropdown,
        label: 'Assignee',
        heading: 'Select From User Library',
        searchKey: 'name',
    },
    TEAM: {
        apiUrl: AppUrl.getTeamForDropdown,
        label: 'Team',
        heading: 'Select From Team Library',
        searchKey: 'teamName',
    }
}

const SelectFromLibrary = React.memo(({ type = types[0], selectionType = 'SINGLE', defaultValue, uniqueKey, isMandatory, handleGetValues, errorMessage, handleGetErrorActivatorInformation }) => {

    const [isOpen, setIsOpen] = useToggler();
    const [pagination, setPagination] = useState({
        page: 1,
        limit: 50
    });
    const [data, setData] = useState([]);
    const [selectedItemsIds, setSelectedItemsIds] = useState(selectionType === 'SINGLE' ? null : []);
    const [selectedItems, setSelectedItems] = useState(selectionType === 'SINGLE' ? null : [])
    const [isLoading, setIsLoading] = useToggler();
    const [searchValue, setSearchValue] = useState(null);
    const [showErrorMessage, setShowErrorMessage] = useState(false);
    const [lcErrorMessage, setLcErrorMessage] = useState(null);
    const [selectedConfig, setSelectedConfig] = useState(config[type]);

    useEffect(() => {
        if ((selectionType === 'SINGLE' && selectedItems === null) || (selectionType === 'MULTIPLE' && selectedItems?.length === 0))
            setLcErrorMessage(errorMessage || "Field is required");
        else
            setLcErrorMessage(null);
    }, [selectedItems])


    useEffect(() => {
        handleGetErrorActivatorInformation && isMandatory && handleGetErrorActivatorInformation({ uniqueKey, type: "dynamicDropdown", value: false, errorActivatorMethod: setShowErrorMessage, errorSetterMethod: setLcErrorMessage })
    }, [])

    useEffect(() => {
        if ((pagination?.page === 1 || loadMore) && isOpen) {
            setIsLoading(false);
            const payload = { ...pagination };
            if (searchValue)
                payload[selectedConfig.searchKey] = searchValue
            doGetApiCall(selectedConfig.apiUrl, payload)
                .then(res => {
                    const data = res?.data?.result?.data || [];
                    if (data?.length === 0 || res?.data?.result?.totalPageCount === pagination.page) {
                        loadMore = false;
                    } else {
                        loadMore = true;
                    }
                    if (pagination.page === 1) {
                        setData(data || []);
                    } else {
                        setData(prev => ([
                            ...prev,
                            ...data || []
                        ]));
                    }
                })
                .finally(setIsLoading)
        }
    }, [pagination, isOpen]);

    const setSearchFn = (e) => {
        setSearchValue(e?.target?.value || '');
        setPagination({
            page: 1,
            limit: 50
        })
        loadMore = true;
    }

    const handleSearch = useCallback(debounce(setSearchFn, 1000), []);

    const onSelection = (item) => {
        if (selectionType === 'SINGLE') {
            setSelectedItems(item);
            setSelectedItemsIds(item.id);
        } else {
            setSelectedItemsIds(prev => {
                const index = prev.findIndex(a => a === item.id);
                if (index > -1) {
                    prev.splice(index, 1);
                    setSelectedItems(prev1 => {
                        prev1.splice(index, 1);
                        return [...prev1];
                    })
                    return [...prev];
                } else {
                    prev.push(item.id);
                    setSelectedItems(prev1 => {
                        prev1.push(item);
                        return [...prev1];
                    })
                    return prev;
                }
            });
        }
    }

    const onSubmit = (overWrite) => {
        const selectedOption = typeof overWrite === 'undefined' ? selectedItems : overWrite;
        setIsOpen(false);
        handleGetValues({
            uniqueKey,
            selectedOption,
            type: 'dynamicDropdown'
        })
    }

    const onScrollEvent = e => {
        const { scrollTop, clientHeight, scrollHeight } = e.currentTarget;
        if (loadMore && (scrollTop + clientHeight >= scrollHeight - 50) && !isLoading) {
            setPagination(prev => ({
                ...prev,
                page: prev.page + 1
            }))
        }
    }

    const handleMakeCapitalStrint = ({ string, splitterSign }) => {
        let splitedString = string?.split(splitterSign);
        let updatedArray = splitedString?.map(item => item.charAt(0).toUpperCase() + item.slice(1));
        return updatedArray?.join(" ")
    }

    const renderLabel = () => {
        if (selectionType === 'SINGLE' && defaultValue) {
            return <span style={{ color: '#000' }}>{defaultValue?.name}</span>
        } else {
            return <span>{selectedConfig.label}</span>
        }
    }

    useEffect(() => {
        if (isMandatory && !defaultValue)
            setLcErrorMessage(errorMessage || "Field is required");
    }, [defaultValue])


    return <>
        <div className={Styles.dynamicDropdown_container} >
            <label>{selectedConfig?.label} {isMandatory && <sup className={Styles.dynamicDropdown_label}>*</sup>}</label>
            <div className={Styles.dynamicDropdown_isActivator} style={{ cursor: 'pointer' }} onClick={() => setIsOpen()}>
                {renderLabel()}
                <div className={Styles.ddi_controllers}>
                    {((selectionType === 'SINGLE' && (defaultValue || selectedItems)) || (selectionType === 'MULTIPLE' && (defaultValue?.length > 0 || selectedItems?.length > 0))) && <IoIosClose fontSize="23px" color="#a3a3a7" onClick={(e) => {
                        e.preventDefault()
                        setSelectedItems(selectionType === 'SINGLE' ? null : [])
                        setSelectedItemsIds(selectionType === 'SINGLE' ? null : [])
                        onSubmit(selectionType === 'SINGLE' ? null : []);
                    }} />
                    }
                    <img src={searchIcon} alt="searchIcon" />
                </div>
            </div>
            {showErrorMessage && ((selectionType === 'SINGLE' && !defaultValue) || (selectionType === 'MULTIPLE' && defaultValue?.length === 0)) && <p>{lcErrorMessage}</p>}
            {selectionType === 'MULTIPLE' && <div className={Styles.ddi_checkbox_controller}>
                {
                    defaultValue && defaultValue.length > 0 && defaultValue?.map((ele) => {
                        return <div className={Styles.ddi_checkbox_controller_item}><span>{ele.name}</span> </div>
                    })
                    // <IoIosClose fontSize="23px" onClick={() => {
                    // let temp = selectedItemsIds.filter((lcItem => lcItem !== ele.id))
                    // setSelectedItemsIds(ele)
                    // return setSelectedItems(temp)
                    // }} />
                }
            </div>}
        </div>
        <Modal isOpen={isOpen} closeModalMethod={setIsOpen}>
            <div className={Styles.dd_body} style={{ height: '100%' }}> {/* dd: dynamic dropdown */}
                <header className={Styles.ddb_header}> {/* ddb: dynamic dropdown body */}
                    <span>{selectedConfig?.heading}</span>
                    <div><img onClick={setIsOpen} src={closeIcon} alt='Close Button' /></div>
                </header>

                <section>
                    <div>
                        <div className={Styles.ddb_search} >
                            <img src={searchIcon} alt="Search" />
                            <input
                                defaultValue={searchValue}
                                placeholder={"Search"}
                                onChange={handleSearch}
                            />
                        </div>
                    </div>
                    <div className={Styles.ddb_content} onScroll={onScrollEvent}>
                        {data.map((item, index) => {
                            const className = (selectionType === 'SINGLE' && ((selectedItems?.id === item.id) || (selectedItems === null && defaultValue?.id === item.id))) ? `${Styles.ddbc_item} ${Styles.listSelected}` : `${Styles.ddbc_item}`;
                            return <div key={index} className={`${className}`} onClick={() => onSelection(item)}> {/* ddbc: dynamic dropdown body content */}
                                {selectionType === 'MULTIPLE' && <div><input
                                    type='checkbox'
                                    checked={selectedItemsIds.includes(item.id)}
                                    // defaultChecked={defaultValue?.map( a => a.id ).includes(item.id)}
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        onSelection(item)
                                    }}
                                /></div>}
                                <div className={Styles.ddbc_item_values}>
                                    {
                                        type === 'ASSET' ? <>
                                            <span>{item?.name}</span>
                                            <span>{item?.assetNumber}</span>
                                        </>
                                            : type === 'USER' ? <>
                                                <span>{item?.name}</span>
                                                <span>{handleMakeCapitalStrint({ string: item?.roleName, splitterSign: "_" })}</span>
                                            </> : type === 'TEAM' ? <>
                                                <span>{item?.name}</span>
                                            </> : <></>
                                    }
                                </div>
                            </div>
                        })}
                        {isLoading && <img src={ClonosSpinner} />}
                        {!isLoading && !data.length && <section><span>No {type}'s Found!</span></section>}
                    </div>
                </section>
                <footer className={Styles.ddb_footer}>
                    <div className={Styles.ddbf_controller}> {/* ddbf: dynamic dropdown body footer */}
                        <span onClick={() => {
                            setIsOpen();
                            setSelectedItems(selectionType === 'SINGLE' ? { ...defaultValue } : [...defaultValue]);
                            setSelectedItemsIds(selectionType === 'SINGLE' ? defaultValue?.id : defaultValue?.map(a => a.id));
                        }}>Cancel</span>
                        <span onClick={() => onSubmit()}>Ok</span>
                    </div>
                </footer>
            </div>
        </Modal>
    </>
})

export default SelectFromLibrary;