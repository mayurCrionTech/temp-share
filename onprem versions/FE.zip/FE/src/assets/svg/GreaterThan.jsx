import React from 'react'
import { CLONOS_GLOBAL_COLOR_ICON_BLACK } from '../../Constants/Constant'

const GreaterThan = ({ height, width, color, size, strokeWidth, strokeColor }) => <svg width={size ? size : width ? width : "24"} height={size ? size : height ? height : "25"} viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M9 6.32532L15 12.3253L9 18.3253" stroke={strokeColor ? strokeColor : CLONOS_GLOBAL_COLOR_ICON_BLACK} stroke-width={strokeWidth ? strokeWidth : "3"} stroke-linecap="round" stroke-linejoin="round" />
</svg>

export default GreaterThan