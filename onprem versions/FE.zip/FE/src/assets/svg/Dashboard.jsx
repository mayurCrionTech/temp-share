import { MdOutlineSpaceDashboard ,MdOutlineAnalytics, MdSecurity } from "react-icons/md";
import { AiOutlineAreaChart } from "react-icons/ai";
import { SlEnergy } from "react-icons/sl";
import { AiOutlineDashboard } from 'react-icons/ai';
import { TbChartBar } from "react-icons/tb";
import { PiChartLineUp } from "react-icons/pi";


const Dashboard = () => <MdOutlineSpaceDashboard color="black" size={23} />;
const ActiveDashboard = () => <MdOutlineSpaceDashboard color="white" size={23} />;


const LogCompilanceDashboard=()=><MdOutlineAnalytics  color="black" size={23}/>
const ActiveLogCompilanceDashboard=()=><MdOutlineAnalytics  color="#06337E" size={23}/>

const AssetDashboard =()=> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="20" viewBox="0 0 18 20" fill="none">
<path d="M17 5.5L9 1L1 5.5M17 5.5V14.5L9 19M17 5.5L9 10M9 19L1 14.5V5.5M9 19V10M1 5.5L9 10" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
const ActiveAssetDashboard =()=><svg xmlns="http://www.w3.org/2000/svg" width="24" height="20" viewBox="0 0 18 20" fill="none">
<path d="M17 5.5L9 1L1 5.5M17 5.5V14.5L9 19M17 5.5L9 10M9 19L1 14.5V5.5M9 19V10M1 5.5L9 10" stroke="#06337E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

const ProcessDashboard=()=><AiOutlineAreaChart color="black" size={23}/>
const ActiveProcessDashboard=()=><AiOutlineAreaChart color="#06337E" size={23}/>
// const ProcessDashboard=()=><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
// <path d="M12.501 20.93C11.635 21.18 10.587 20.764 10.325 19.683C10.2611 19.4192 10.1358 19.1742 9.95929 18.968C9.7828 18.7618 9.56011 18.6001 9.30935 18.4963C9.05859 18.3924 8.78683 18.3491 8.51621 18.3701C8.24559 18.3911 7.98375 18.4757 7.752 18.617C6.209 19.557 4.442 17.791 5.382 16.247C5.5231 16.0153 5.60755 15.7537 5.62848 15.4832C5.64942 15.2128 5.60624 14.9412 5.50247 14.6906C5.3987 14.44 5.23726 14.2174 5.03127 14.0409C4.82529 13.8645 4.58056 13.7391 4.317 13.675C2.561 13.249 2.561 10.751 4.317 10.325C4.5808 10.2611 4.82578 10.1358 5.032 9.95929C5.23822 9.7828 5.39985 9.56011 5.50375 9.30935C5.60764 9.05859 5.65085 8.78683 5.62987 8.51621C5.60889 8.24559 5.5243 7.98375 5.383 7.752C4.443 6.209 6.209 4.442 7.753 5.382C8.753 5.99 10.049 5.452 10.325 4.317C10.751 2.561 13.249 2.561 13.675 4.317C13.7389 4.5808 13.8642 4.82578 14.0407 5.032C14.2172 5.23822 14.4399 5.39985 14.6907 5.50375C14.9414 5.60764 15.2132 5.65085 15.4838 5.62987C15.7544 5.60889 16.0162 5.5243 16.248 5.383C17.791 4.443 19.558 6.209 18.618 7.753C18.4769 7.98466 18.3924 8.24634 18.3715 8.51677C18.3506 8.78721 18.3938 9.05877 18.4975 9.30938C18.6013 9.55999 18.7627 9.78258 18.9687 9.95905C19.1747 10.1355 19.4194 10.2609 19.683 10.325C20.757 10.585 21.173 11.621 20.935 12.483M19 22V16M19 16L22 19M19 16L16 19M9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
// </svg>
// const ActiveProcessDashboard=()=><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
// <path d="M12.501 20.93C11.635 21.18 10.587 20.764 10.325 19.683C10.2611 19.4192 10.1358 19.1742 9.95929 18.968C9.7828 18.7618 9.56011 18.6001 9.30935 18.4963C9.05859 18.3924 8.78683 18.3491 8.51621 18.3701C8.24559 18.3911 7.98375 18.4757 7.752 18.617C6.209 19.557 4.442 17.791 5.382 16.247C5.5231 16.0153 5.60755 15.7537 5.62848 15.4832C5.64942 15.2128 5.60624 14.9412 5.50247 14.6906C5.3987 14.44 5.23726 14.2174 5.03127 14.0409C4.82529 13.8645 4.58056 13.7391 4.317 13.675C2.561 13.249 2.561 10.751 4.317 10.325C4.5808 10.2611 4.82578 10.1358 5.032 9.95929C5.23822 9.7828 5.39985 9.56011 5.50375 9.30935C5.60764 9.05859 5.65085 8.78683 5.62987 8.51621C5.60889 8.24559 5.5243 7.98375 5.383 7.752C4.443 6.209 6.209 4.442 7.753 5.382C8.753 5.99 10.049 5.452 10.325 4.317C10.751 2.561 13.249 2.561 13.675 4.317C13.7389 4.5808 13.8642 4.82578 14.0407 5.032C14.2172 5.23822 14.4399 5.39985 14.6907 5.50375C14.9414 5.60764 15.2132 5.65085 15.4838 5.62987C15.7544 5.60889 16.0162 5.5243 16.248 5.383C17.791 4.443 19.558 6.209 18.618 7.753C18.4769 7.98466 18.3924 8.24634 18.3715 8.51677C18.3506 8.78721 18.3938 9.05877 18.4975 9.30938C18.6013 9.55999 18.7627 9.78258 18.9687 9.95905C19.1747 10.1355 19.4194 10.2609 19.683 10.325C20.757 10.585 21.173 11.621 20.935 12.483M19 22V16M19 16L22 19M19 16L16 19M9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12Z" stroke="#06337E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
// </svg>

const EnergyDashboard=()=><SlEnergy color="black" size={22}/>
const ActiveEnergyDashboard=()=><SlEnergy color="#06337E" size={22}/>

const AnalyticsDashboard=()=><AiOutlineDashboard color="black" size={23}/>
const ActiveAnalyticsDashboard=()=><AiOutlineDashboard color="#06337E" size={23}/>

const QualityDashboard=()=><MdSecurity color="black" size={23}/>
const ActiveQualityDashboard=()=><MdSecurity color="#06337E" size={23}/>


const PowerBIDashboard=()=><TbChartBar color="black" size={23}/>
const ActivePowerBIDashboard=()=><TbChartBar color="#06337E" size={23}/>

const LiveDashboard=()=><PiChartLineUp color="black" size={23}/>
const ActiveLiveDashboard=()=><PiChartLineUp color="#06337E" size={23}/>

export { Dashboard, ActiveDashboard,LogCompilanceDashboard, ActiveLogCompilanceDashboard,AssetDashboard,ActiveAssetDashboard, ProcessDashboard, ActiveProcessDashboard ,EnergyDashboard,ActiveEnergyDashboard,AnalyticsDashboard,ActiveAnalyticsDashboard,QualityDashboard,ActiveQualityDashboard,PowerBIDashboard,ActivePowerBIDashboard,LiveDashboard,ActiveLiveDashboard};
