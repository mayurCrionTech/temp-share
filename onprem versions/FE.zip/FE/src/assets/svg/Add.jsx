const Add = ({ color, height, width, size }) => <svg xmlns="http://www.w3.org/2000/svg" width={width ? width : size ? size : "16"} height={height ? height : size ? size : "16"} viewBox="0 0 16 16" fill="none">
    <path d="M8.0026 3.33301V12.6663M3.33594 7.99967H12.6693" stroke={color ? color : "#0A5FFF"} stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
</svg>

export { Add }