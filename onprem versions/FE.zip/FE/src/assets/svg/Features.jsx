import { MdAutoAwesome } from "react-icons/md"

import { MdMemory } from "react-icons/md";

import { RiEarthLine } from "react-icons/ri";
import { GoDatabase } from "react-icons/go";
import { SiCountingworkspro } from "react-icons/si";
import { RiDropdownList } from "react-icons/ri";



const Features=()=><MdAutoAwesome color="black" size={23}/>
const ActiveFeatures=()=><MdAutoAwesome color="#fff" size={23}/>


const Timezones=()=><RiEarthLine color="black" size={23}/>
const ActiveTimezones=()=><RiEarthLine color="#06337E" size={23}/>

const Plc=()=><MdMemory color="black" size={25}/>
const ActivePlc=()=><MdMemory color="#06337E" size={25}/>

const Counter=()=><SiCountingworkspro color="black" size={22}/>
const ActiveCounter=()=><SiCountingworkspro color="#06337E" size={22}/>
const Dropdowns=()=><RiDropdownList color="black" size={22}/>
const ActiveDropdowns=()=><RiDropdownList color="#06337E" size={22}/>


export {Features, ActiveFeatures,Timezones,ActiveTimezones,Plc,ActivePlc,Counter,ActiveCounter,Dropdowns,ActiveDropdowns};
