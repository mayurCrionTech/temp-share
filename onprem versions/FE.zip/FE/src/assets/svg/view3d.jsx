import { Md3DRotation } from "react-icons/md";

const View3d = () => <Md3DRotation size={22} color="black" />;

const ActiveView3d = () => <Md3DRotation size={22} color="white" />;

export { View3d, ActiveView3d };
