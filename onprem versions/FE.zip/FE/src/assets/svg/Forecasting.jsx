	/*
date            qid / cr#         comments
5-may-2026      CR0027           Added a Forecasting side menu item that opens a new tab to view another hosted URL.

*/


import { MdAutoGraph } from "react-icons/md";

const Forecasting = () => <MdAutoGraph size={22} color="black" />;

const ActiveForecasting = () => <MdAutoGraph size={22} color="white" />;

export { Forecasting, ActiveForecasting };
