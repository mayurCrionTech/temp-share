// import { useEffect } from "react";

// const Svg = ({ svgName }) => {

//     useEffect(() => {
//         switch svgName {
//             s
//         }
//     }, [svgName])


//     return renderSvg();
// }