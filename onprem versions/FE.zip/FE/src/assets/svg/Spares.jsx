// import { FaTools } from "react-icons/fa";
import { IoSettingsOutline } from "react-icons/io5";

const Spares = () => <IoSettingsOutline color="black" size={23}/>
const ActiveSpares = () => <IoSettingsOutline color="white" size={23} />;



export {Spares,ActiveSpares};


