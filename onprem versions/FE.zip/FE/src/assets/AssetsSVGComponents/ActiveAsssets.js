export const ActiveAssetsIcon = () => {
    return <svg xmlns="http://www.w3.org/2000/svg" width="41" height="40" viewBox="0 0 41 40" fill="none">
    <path d="M11.7708 19.9993L20.1042 28.3327L36.7708 11.666M3.4375 19.9993L11.7708 28.3327M20.1042 19.9993L28.4375 11.666" stroke="#60D468" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
}