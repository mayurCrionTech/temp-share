export const TotalAssetsIcon = () => {
    return <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
    <path d="M33.3307 12.5L19.9974 5L6.66406 12.5M33.3307 12.5V27.5L19.9974 35M33.3307 12.5L19.9974 20M19.9974 35L6.66406 27.5V12.5M19.9974 35V20M6.66406 12.5L19.9974 20" stroke="#0A5FFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
}