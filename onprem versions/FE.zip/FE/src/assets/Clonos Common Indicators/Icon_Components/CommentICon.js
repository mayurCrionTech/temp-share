import React from 'react'
import useToggler from '../../../CustomHooks/TogglerHook'
import { Tooltip } from '@material-ui/core'
import { CLONOS_GLOBAL_COLOR_ICON_BLACK, CLONOS_GLOBAL_COLOUR_BLUE_HOVER } from '../../../Constants/Constant'

const CommentIcon = ({ height, width, color, size, strokeColor, strokeWidth, onClick, tooltipTitle }) => {
    let [isHover, setIsHover] = useToggler()
    return (
        <Tooltip title={tooltipTitle}>
            <div
                onMouseEnter={() => setIsHover(true)}
                onMouseLeave={() => setIsHover(false)}
                onClick={() => onClick()}
                style={{ padding: "0px", margin: "0px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", width: "fit-content", height: "fit-content" }}
            >   
                <svg width={size ? size : width ? width : "32"} height={size ? size : height ? height : "32"} viewBox="0 0 32 32" fill={color ? color : "none"} xmlns="http://www.w3.org/2000/svg">
                    <g id="message-2">
                        <path id="Vector" d="M10.6667 11.9987H21.3333M10.6667 17.332H18.6667M12 23.9987H8C6.93913 23.9987 5.92172 23.5773 5.17157 22.8271C4.42143 22.077 4 21.0596 4 19.9987V9.33203C4 8.27117 4.42143 7.25375 5.17157 6.5036C5.92172 5.75346 6.93913 5.33203 8 5.33203H24C25.0609 5.33203 26.0783 5.75346 26.8284 6.5036C27.5786 7.25375 28 8.27117 28 9.33203V19.9987C28 21.0596 27.5786 22.077 26.8284 22.8271C26.0783 23.5773 25.0609 23.9987 24 23.9987H20L16 27.9987L12 23.9987Z" stroke={isHover ? CLONOS_GLOBAL_COLOUR_BLUE_HOVER : strokeColor ? strokeColor : CLONOS_GLOBAL_COLOR_ICON_BLACK} stroke-width={strokeWidth ? strokeWidth : "2"} stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                </svg>
            </div>
        </Tooltip>
    )
}

export default CommentIcon