import React from 'react'

const ThreeDotsIcon = ({ tooltipTitle, onClick, height, width, color, size }) => {
    let [isHover, setIsHover] = useToggler();
    return (
        <Tooltip title={tooltipTitle}>
            <div
                onMouseEnter={() => setIsHover(true)}
                onMouseLeave={() => setIsHover(false)}
                onClick={() => onClick()}
                style={{ padding: "0px", margin: "0px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", width: "fit-content", height: "fit-content" }}
            >
                <svg width={width ? width : size ? size : "24"} height={height ? height : size ? size : "24"} viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill={color ? color : "#000000"} class="bi bi-three-dots-vertical">
                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                </svg>
            </div>
        </Tooltip>
    )
}

export default ThreeDotsIcon