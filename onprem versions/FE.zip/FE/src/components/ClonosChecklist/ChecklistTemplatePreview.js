import Styles from "../../ModuleStyles/ChecklistAndReports/ClonosChecklist/ChecklistTemplatePreview/ChecklistTemplatePreview.module.css";
import TEMPLATE_PREVIEW_ADDIMAGE from "../../assets/UIUX/icons/Checklist/add-image.svg";
import TEMPLATE_PREVIEW_VIEWIMAGE from "../../assets/UIUX/icons/Checklist/view-image.svg";
import TEMPLATE_PREVIEW_ADDNOTE from "../../assets/UIUX/icons/Checklist/add-note.svg";
import TEMPLATE_PREVIEW_VIEWNOTE from "../../assets/UIUX/icons/Checklist/view-note.svg";
import { useState } from "react";
import ClonosSelect from "../CommonComponents/ClonosSelect/ClonosSelect";
import ClonosInput from "../CommonComponents/ClonosInput/ClonosInput";
export const ChecklistTemplatePreview = ({ attributes = [], isEdit, getUpdatedValues }) => {
  const [showEditLabel, setShowEditLabel] = useState(false);
  const [localDetails, setLocalDetails] = useState([...attributes]);
  const [choosedValues, setChoosedValues] = useState({})
  const handleChange = ({ e, attributeId, attributeName, changeIn, optionId }) => {
    const { name, value } = e.target
    if (attributeName === "Text" || attributeName === "Number" || attributeName === "Date") {
      setLocalDetails((prev) => {
        let temp = attributes?.map((attribute) => {
          if (attribute?.id === attributeId) {
            return {
              ...attribute,
              [changeIn]: value
            }
          } else {
            return attribute
          }
        })
        getUpdatedValues(temp);
        return temp
      })

    } else if (attributeName === "Dropdown" || attributeName === "Checkboxes" || attributeName === "Multiple Choice") {
      let tempOptions = {};
      setLocalDetails((prev) => {
        let temp = attributes?.map((attribute) => {
          if (attribute?.id === attributeId) {
            if (changeIn === "choosedValue") {
              let prevOptions = choosedValues[`${attribute?.id}`]
              if (prevOptions?.includes(optionId)) {
                prevOptions = prevOptions?.filter((opt) => opt !== optionId);
                tempOptions[`${attribute.id}`] = [...prevOptions];
              } else {
                if (prevOptions?.length) {
                  tempOptions[`${attribute.id}`] = [...prevOptions, optionId];
                } else {
                  tempOptions[`${attribute.id}`] = [optionId];
                }
              }
              setChoosedValues(tempOptions)
              return {
                ...attribute,
                [changeIn]: tempOptions[`${attribute?.id}`]
              }
            } else {
              return {
                ...attribute,
                [changeIn]: value
              }
            }
          } else {
            return attribute
          }
        })
        return temp
      })
    }
  }

  const handleSubmit = () => {
    getUpdatedValues(localDetails)
  }
  return (
    <>
      <div className={Styles.ct_preview_container}>
        {attributes?.length ? (
          attributes?.map((attribute) => {
            return (
              <div className={Styles.ct_preview_attribute_container}>
                <div className={Styles.ct_preview_field_label_container}>
                  <h4 className={Styles.ct_preview_field_label}>
                    {attribute?.fieldName || "Untitled Field"}
                  </h4>
                </div>
                <div className={Styles.ct_preview_attribute_value_contanier}>
                  {
                    (attribute?.attributeName === "Text" || attribute?.attributeName === "Number" || attribute?.attributeName === "Date") &&
                    <div className={Styles.ct_preview_attribute_value_left}>
                      <ClonosInput
                        readOnly={!isEdit}
                        disabled={!isEdit}
                        defaultValue={attribute?.fieldValue}
                      />
                    </div>
                  }
                  {
                    attribute?.attributeName === "Dropdown" && <div className={Styles.ct_preview_attribute_value_left}>
                      <ClonosSelect
                        type="select"
                        isLabel={false}
                        uniqueKey="priority"
                        placeholder="Select"
                        options={attribute?.fieldValue?.map((type) => ({
                          value: type?.optionId,
                          label: type?.optionValue,
                          isNeeded: true,
                          disabled: isEdit ? false : true
                        }))}
                      />
                    </div>
                  }
                  {
                    attribute?.attributeName === "Multiple Choice" && <div className={Styles.ct_preview_attribute_value_left}>
                      {
                        attribute?.fieldValue?.map((opt) => {
                          return <div className={Styles.ct_preview_multichoice_options_container}>
                            {opt?.optionValue &&
                              <div className={Styles.ct_preview_attribute_option}>
                                <input value={opt?.optionId} onChange={(e) => handleChange({ e, attributeId: attribute?.id, attributeName: attribute?.attributeName, changeIn: "choosedValue" })} disabled={!isEdit} defaultChecked={attribute?.choosedValue?.includes(opt?.optionValue)} name="multichoice" type="radio" />
                                <label>{opt?.optionValue}</label>
                              </div>
                            }
                          </div>
                        })
                      }
                    </div>
                  }
                  {
                    attribute?.attributeName === "Checkboxes" && <div className={Styles.ct_preview_attribute_value_left}>
                      {
                        attribute?.fieldValue?.map((opt) => {
                          return <div className={Styles.ct_preview_checkboxes_option}>
                            {opt?.optionValue && <div className={Styles.ct_preview_attribute_option}>
                              <input value={opt?.optionId} onChange={(e) => handleChange({ e, attributeId: attribute?.id, attributeName: attribute?.attributeName, changeIn: "choosedValue", optionId: opt?.optionId })} disabled={!isEdit} defaultChecked={attribute?.choosedValue?.includes(opt?.optionId)} name="multichoice" type="checkbox" />
                              <label>{opt?.optionValue}</label>
                            </div>}
                          </div>
                        })
                      }
                    </div>
                  }
                  <div className={Styles.ct_preview_attribute_value_right}>
                    <div className={Styles.ct_preview_attribute_files_box}>
                      <img
                        src={
                          attribute?.filesCount > 0
                            ? TEMPLATE_PREVIEW_VIEWIMAGE
                            : TEMPLATE_PREVIEW_ADDIMAGE
                        }
                      />
                      {attribute?.filesCount > 0 && <div className={Styles.ct_preview_attribute_files_count}>1</div>}
                    </div>
                    <div>
                      <img
                        src={
                          attribute?.notes?.length > 0
                            ? TEMPLATE_PREVIEW_VIEWNOTE
                            : TEMPLATE_PREVIEW_ADDNOTE
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div></div>
        )}
      </div>
      {/* {isEdit && <div className={Styles.ct_preview_btn_container}>
        <div className={Styles.ct_preview_controllers}>
          <ClonosButton p={"0.5rem 1rem"} isHollow={true} style={{color:"#06337E"}} >Cancel</ClonosButton>
          <ClonosButton p={"0.5rem 1rem"} onClick={handleSubmit}>Submit</ClonosButton>
        </div>
      </div>} */}
    </>
  );
};


const data = [
  {
    "id": "2d146c58-d0bf-463e-a44a-9e2f20514ea1",
    "attributeName": "Multiple Choice",
    "fieldName": "sldkfsldjf",
    "fieldValue": [
      {
        "optionId": "4753a4d6-0e0d-46cc-a404-c5b1b650f2ee",
        "optionValue": "sdflksj"
      },
      {
        "optionId": "32706596-888f-42e4-87a6-4613b70cdd30",
        "optionValue": "dsldjfsldj"
      }
    ],
    "images": [],
    "notes": "",
    "choosedValue": []
  },
  {
    "id": "527a4942-3bd7-47e7-8042-c4b1ecc1c6df",
    "attributeName": "Text",
    "fieldName": "name",
    "fieldValue": "rohan",
    "images": [],
    "notes": ""
  },
  {
    "id": "10693cee-d620-4d55-8588-28b625b8314c",
    "attributeName": "Checkboxes",
    "fieldName": "Gender",
    "fieldValue": [
      {
        "optionId": "77e9cb40-f6ae-4a12-b2c4-5d8e36090a91",
        "optionValue": "Male"
      },
      {
        "optionId": "da83e0da-b09f-44f1-9f2d-94d83c4882cc",
        "optionValue": "Female"
      }
    ],
    "images": [],
    "notes": "",
    "choosedValue": []
  },
  {
    "id": "40f6512c-da9a-41e0-86b6-1df6fe286e80",
    "attributeName": "Dropdown",
    "fieldName": "State",
    "fieldValue": [
      {
        "optionId": "4e2b1896-571b-479d-a725-6feb2a694709",
        "optionValue": "TN"
      },
      {
        "optionId": "96350700-07ca-4c8b-b02f-9d9c0e3cc7c0",
        "optionValue": "MP"
      }
    ],
    "images": [],
    "notes": "",
    "choosedValue": []
  },
  {
    "id": "5d8d625b-0fd6-40de-9708-79e8e720a5a6",
    "attributeName": "Number",
    "fieldName": "BOM",
    "fieldValue": "2345678",
    "images": [],
    "notes": ""
  },
  {
    "id": "f37c28e8-9241-4707-aae5-e885687e372b",
    "attributeName": "Date",
    "fieldName": "DOB",
    "fieldValue": "2024-01-08",
    "images": [],
    "notes": ""
  }
]