// import React, { useState, useEffect } from "react";
// import TEMPLTE_CREATION_TEXTICON from "../../assets/UIUX/icons/Checklist/Attributes/alphabet-latin.svg";
// import TEMPLTE_CREATION_NUMBERICON from "../../assets/UIUX/icons/Checklist/Attributes/123.svg";
// import TEMPLTE_CREATION_DOTCIRCLE from "../../assets/UIUX/icons/Checklist/Attributes/circle-dot (1).svg";
// import TEMPLTE_CREATION_SQUARECHECK from "../../assets/UIUX/icons/Checklist/Attributes/square-check.svg";
// import TEMPLTE_CREATION_CIRCLEDOWN from "../../assets/UIUX/icons/Checklist/Attributes/circle-chevron-down.svg";
// import TEMPLTE_CREATION_CALENDARICON from "../../assets/UIUX/icons/Checklist/Attributes/calendar-event.svg";
// import Styles from "../../ModuleStyles/ChecklistAndReports/ClonosChecklist/TemplateCreationPage.module.css";
// import ClonosSkeletonLoading from "../CommonComponents/ClonosSkeletonLoading/ClonosSkeletonLoading";
// import useImagesLoaded from "../../CustomHooks/ImageLoaderHook";

// export const TemplateAttributes = ({ getSelectedValue }) => {
//     const isAllImagesLoaded = useImagesLoaded([
//         TEMPLTE_CREATION_TEXTICON,
//         TEMPLTE_CREATION_DOTCIRCLE,
//         TEMPLTE_CREATION_SQUARECHECK,
//         TEMPLTE_CREATION_CIRCLEDOWN,
//         TEMPLTE_CREATION_NUMBERICON,
//         TEMPLTE_CREATION_CALENDARICON
//     ])

//     const attributes = [
//         { id: 1, icon: TEMPLTE_CREATION_TEXTICON, title: "Text", type: "text" },
//         { id: 2, icon: TEMPLTE_CREATION_DOTCIRCLE, title: "Multiple Choice", type: "multipleChoice" },
//         { id: 3, icon: TEMPLTE_CREATION_SQUARECHECK, title: "Checkbox", type: "checkbox" },
//         { id: 4, icon: TEMPLTE_CREATION_CIRCLEDOWN, title: "Dropdown", type: "dropdown" },
//         { id: 5, icon: TEMPLTE_CREATION_NUMBERICON, title: "Number", type: "number" },
//         { id: 6, icon: TEMPLTE_CREATION_CALENDARICON, title: "Date", type: "date" },
//     ];

//     return (
//         <>
//             <div className={Styles.checklist_template_attribute_container} onClick={e => e.stopPropagation()}>
//                 {
//                     attributes.map((attr) => (
//                         <div key={attr.id} className={Styles.attributeItem} onClick={() => getSelectedValue({ attributeName: attr?.title, type: attr?.type })}>
//                             {
//                                 !isAllImagesLoaded ? <ClonosSkeletonLoading height="25px" width="25px" /> :
//                                     <img src={attr.icon} alt={attr.title} />
//                             }
//                             <p>{attr.title}</p>
//                         </div>
//                     ))
//                 }
//             </div>
//             <div className={Styles.overLay}></div>
//         </>
//     );
// };
