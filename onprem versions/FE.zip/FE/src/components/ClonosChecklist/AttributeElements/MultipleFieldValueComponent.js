import { useEffect } from "react";
import Styles from "../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/TemplateCreationPage.module.css";
import TEMPLATE_CREATION_REMOVEROW from "../../../assets/UIUX/icons/Checklist/circle-minus.svg";
import TEMPLATE_CREATION_CIRCLEPLUS from "../../../assets/UIUX/icons/Checklist/circle-plus.svg";
import ClonosInput from "../../CommonComponents/ClonosInput/ClonosInput";
import { v4 as uuidv4 } from 'uuid';

/**
 * Component for handling multiple field values in a form.
 * @param {Object} getFieldDetails - Function to update field details.
 * @param {Object} attribute - Object containing field details.
 * @param {Function} handleGetErrorActivatorInformation - Function to handle error information.
 * @param {Function} handlePrimaryObjectModifier - Function to modify the primary object.
 * @returns {JSX.Element} - JSX Element for rendering multiple field values.
 */
export const MultipleFieldValueComponent = ({ getFieldDetails, attribute, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleDeleteKeyFromPrimaryObject }) => {

    /**
     * Handles the addition of new options to the field value.
     */
    const handleAddOptions = () => {
        getFieldDetails({ ...attribute, fieldValue: [...attribute?.fieldValue, { optionId: uuidv4(), optionValue: "" }] })
    }

    /**
     * Handles the removal of a specific option from the field value.
     * @param {string} id - Unique identifier of the option to be removed.
     */
    const handleRemoveOption = (id) => {
        if (attribute?.fieldValue?.length > 1) {
            const newOptions = attribute?.fieldValue?.filter((option) => {
                if (option?.optionId !== id) {
                    return option
                } else {
                    handleDeleteKeyFromPrimaryObject(option?.optionId)
                }
            })
            getFieldDetails({ ...attribute, fieldValue: newOptions })
        }
    }

    /**
     * Handles changes in the field name or field value.
     * @param {Object} props - Updated values and metadata.
     * @param {string} optionId - Unique identifier of the option being modified.
     */
    const handleChange = (props, optionId) => {
        if (props?.name === "fieldName") {
            handlePrimaryObjectModifier({ response: props?.updatedValue, uniqueKey: props?.uniqueKey })
            getFieldDetails({ ...attribute, fieldName: props?.updatedValue, uniqueKey: props?.uniqueKey })
        } else if (props?.name === "fieldValue") {
            let changedElement = null;
            let updatedOptions = attribute?.fieldValue?.map((option) => {
                if (option?.optionId === props?.uniqueKey) {
                    changedElement = { ...option, optionValue: props?.updatedValue };
                    return { ...option, optionValue: props?.updatedValue }
                } else {
                    return option
                }
            })
            handlePrimaryObjectModifier({ response: changedElement?.optionValue, uniqueKey: changedElement?.optionId })
            getFieldDetails({ ...attribute, fieldValue: updatedOptions, uniqueKey: props?.uniqueKey })
        }
    }

    return <>
        <div className={Styles.fieldNameTaker}>
            {/* Input for capturing the field name */}
            <ClonosInput
                value={attribute?.fieldName || ""}
                name="fieldName"
                placeholder="Add Name"
                uniqueKey={attribute?.id || ""}
                isMandatory={true}
                handleGetValues={handleChange}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                ariaLabel="Field Name Input"
            />
        </div>
        <div className={Styles.fieldValueTaker}>
            <div className={Styles.multiple_fieldvalue_taker_container}>
                {
                    // Mapping through each field value option
                    attribute?.fieldValue?.map((option, index) => (
                        <div className={Styles.option_box} key={option?.optionId}>
                            {/* Input for capturing the field value */}
                            <ClonosInput
                                value={option?.optionValue || ""}
                                name="fieldValue"
                                placeholder={`Add ${attribute?.attributeName}`}
                                uniqueKey={option?.optionId || ""}
                                handleGetValues={handleChange}
                                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                isMandatory={true}
                                ariaLabel={`Field Value Input ${index + 1}`}
                            />
                            {
                                // Displaying remove option icon if there is more than one option
                                attribute?.fieldValue?.length > 1 && <div className={Styles.remove_option} onClick={() => handleRemoveOption(option?.optionId)}>
                                    <img src={TEMPLATE_CREATION_REMOVEROW} alt="Remove Option" />
                                </div>
                            }
                        </div>
                    ))
                }
                {/* Container for adding a new option */}
                <div className={Styles.add_option_container}>
                    <div onClick={handleAddOptions}>
                        <div><img src={TEMPLATE_CREATION_CIRCLEPLUS} alt="Add Option" /></div>
                        <p>Add Option</p>
                    </div>
                </div>
            </div>
        </div>
    </>
}
