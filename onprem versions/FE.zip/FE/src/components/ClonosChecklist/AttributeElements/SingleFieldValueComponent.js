import { memo } from "react";
import Styles from "../../../ModuleStyles/ChecklistAndReports/ClonosChecklist/TemplateCreationPage.module.css";
import ClonosInput from "../../CommonComponents/ClonosInput/ClonosInput";

/**
 * Component for handling a single field value in a form.
 * @param {Object} attributes - Additional attributes for the component.
 * @param {Function} getFieldDetails - Function to update field details.
 * @param {Object} attribute - Object containing field details.
 * @param {Function} handleGetErrorActivatorInformation - Function to handle error information.
 * @returns {JSX.Element} - JSX Element for rendering a single field value.
 */
const SingleFieldValueComponent = ({ attributes, getFieldDetails, attribute, handleGetErrorActivatorInformation }) => {

    /**
     * Handles changes in the field name or field value.
     * @param {Object} e - Event object containing updated values and metadata.
     */
    const handleChange = (e) => {
        getFieldDetails({ ...attribute, [e?.name]: e?.updatedValue, ["uniqueKey"]: e?.uniqueKey });
    };

    return (
        <>
            {/* Input for capturing the field name */}
            <div className={Styles.fieldNameTaker}>
                <ClonosInput
                    value={attribute?.fieldName || ""}
                    name="fieldName"
                    placeholder="Add Name"
                    uniqueKey={attribute?.id || ""}
                    isMandatory={true}
                    handleGetValues={handleChange}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    ariaLabel="Field Name Input"
                />
            </div>

            {/* Input for capturing the field value */}
            <div className={Styles.fieldValueTaker}>
                <ClonosInput
                    value={attribute?.fieldValue || ""}
                    name="fieldValue"
                    type={attribute?.attributeName}
                    placeholder={`Add ${attribute?.attributeName}`}
                    uniqueKey={attribute?.id || ""}
                    handleGetValues={handleChange}
                    ariaLabel="Field Value Input"
                />
            </div>
        </>
    );
};

export default memo(SingleFieldValueComponent);
