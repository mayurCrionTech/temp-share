import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Box, Typography, Paper } from '@material-ui/core';
import OrganizationsTab from './tabs/OrganizationsTab';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(3),
  },
  paper: {
    padding: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
}));

function SuperAdminPage() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Paper className={classes.paper}>
        <Typography variant="h5" gutterBottom>
          Super Admin Dashboard
        </Typography>
        <Typography variant="body1" color="textSecondary" paragraph>
          Manage organizations
        </Typography>
      </Paper>

      <Paper className={classes.paper}>
        <Box>
          <OrganizationsTab />
        </Box>
      </Paper>
    </div>
  );
}

export default SuperAdminPage; 