import React, { useState } from "react";
import { Tabs, Tab, Box, Divider, Card } from "@material-ui/core";
import CommonNavigator from "../../CommonComponents/Navigator/Navigator";
import ControllersPage from "./PLC- Page/controller/ControllerPage";
import TagsPage from "./PLC- Page/Tags/TagsPage";
import StagePage from "./PLC- Page/stages/StagePage";

 let navigatorValues = [
       {
           value: "Controller",
           status: true,
           visibility: true,
           uniqueKey: "controller"
       },
       {
           value: "Tags",
           status: false,
           visibility: true,
           uniqueKey:  "tags"
       },
      //    {
      //      value: "Stages",
      //      status: false,
      //      visibility: true,
      //      uniqueKey:  "stages"
      //  },
  
   ];

export default function Plc() {

   const [toggleBetweenPlcTab, setToggleBetweenPlcTab] = useState("controller");
  
   const handleTogglebetweenPlcTab = (props, uniqueKey) => {
 
        setToggleBetweenPlcTab(uniqueKey);
    };


  return (
      <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : " 1rem",backgroundColor:"#FAFAFA" ,borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto" }}>
                         <CommonNavigator web={true} values={navigatorValues} getSelectedValue={handleTogglebetweenPlcTab} />
                         
                        {toggleBetweenPlcTab === "controller" && (
                           <ControllersPage/>
                        )}
                          {toggleBetweenPlcTab === "tags" && (
                           <TagsPage/>
                        )}
                        {/* {toggleBetweenPlcTab === "stages" && (
                           <StagePage/>
                        )} */}
</Card>
  );
}
