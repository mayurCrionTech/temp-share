/*
date            qid / cr#         comments
18-mar-2026     CR0001            Apply filter on drop down

*/

import React, { useState } from 'react'
import Styles from '../dropdown-manager.module.css'
import CloseIcon from '../../../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon'
import { useDispatch } from 'react-redux'
import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
import ClonosConfirmationBox from '../../../../CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import { handleCreateDropDowns, handleCreateOptions, handleGetFilledValuesOfDropdowns } from '../dropdownManager';
import { ClonosButton } from '../../../../CommonComponents/Button/Button';
import ClonosInput from '../../../../CommonComponents/ClonosInput/ClonosInput';
import Modal from '../../../../CommonComponents/Modal/Modal';
import { useNavigate } from 'react-router-dom';

function AddOptionModal({isOpen, closeMethod, dropDownId ,onSuccess}) {

   
    const [formData, setFormData] = useState({});
    const [isLoading,setIsLoading]= useState(false)
    const[showConfirmationDialog,setShowConfirmationDialog]=useState(false)
 
    const dispatch =useDispatch()
    const navigate =useNavigate()
  
     const {
          handleGetErrorActivatorInformation,
          handlePrimaryObjectModifier,
          handleSubmit,
          handleGetUpdatedPrimaryObject,
          handleRemoveField,
          primaryObject
        } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "addQuantity" });

   const handleGetValues = (props) => {
       handleGetFilledValuesOfDropdowns({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier,formData})
  }
// const handleSaveOptions=()=>{
//         handleCreateOptions({dispatch,formData,setIsLoading:()=>setIsLoading(prev=> !prev),dropDownId})
//         closeMethod()
// }
const handleSaveOptions = async () => {
        try {
          await handleCreateOptions({ dispatch, formData,setIsLoading: () => setIsLoading(prev => !prev), dropDownId });

          // ✅ refresh parent FIRST
          onSuccess && onSuccess();

          // ✅ then close
          closeMethod();

        } catch (error) {
          console.log(error);
        }
  };
console.log(formData,"formData")
  return (
   <>
     <Modal isOpen={isOpen} closeModalMethod={closeMethod}>
                  <div className={Styles.container}>
                      <div className={Styles.header}>
                          <h4> Add Option </h4>
                          <CloseIcon onClick={() => closeMethod(false)} />
                      </div>
                      <div className={Styles.section}>
                         
                          <div className={Styles.dropdown_container}>
                                    <ClonosInput
                                      label="Option Name"
                                      isLabel={true}
                                      placeholder="value"
                                      isMandatory={true}
                                      type="text"
                                    //   limit='8'
                                      uniqueKey="value"
                                    //   defaultValue={mode=="edit" && data?.quantity}
                                        handleGetValues={handleGetValues}
                                      handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                                    />
                                   
                               </div>
                              
                         
                      </div>
                      
                      <div className={Styles.footer}>
                          <div>
                              <ClonosButton onClick={() => setShowConfirmationDialog(true)}>Cancel</ClonosButton>
                              <ClonosButton
                                  // loading={loadings.generateReportLoading}
                                  variant="filled"
                                //   onClick={() => handleAddQuantity({ handleSubmit, formData, setIsLoading: () => setIsLoading(prev => (!prev)), closeMethod ,spareId: data?.id})}
                                onClick={handleSaveOptions}
                              >
                                 save
                              </ClonosButton>
                          </div>
                      </div>
                  </div>
                 </Modal>
                 
                 <ClonosConfirmationBox
                     isOpen={showConfirmationDialog}
                     closeModalMethod={setShowConfirmationDialog}
                     confirmingMethod={() => {
                         closeMethod(false);
                         setShowConfirmationDialog(false);
                     }}
                     rejectingMethod={() => setShowConfirmationDialog(false)}
                     message={"Are you sure to cancel ?"}
                     headerTitle={"Cancel"}
                 />
   </>
  )
}

export default AddOptionModal