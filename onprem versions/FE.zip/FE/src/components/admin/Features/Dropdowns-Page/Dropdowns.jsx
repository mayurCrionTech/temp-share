/*
date            qid / cr#         comments
18-mar-2026     CR0001            Apply filter on drop down

*/

import React, { useEffect, useState } from "react";
import ClonosSelect from "../../../CommonComponents/ClonosSelect/ClonosSelect";
import DOWNANGLE from "../../../../assets/UIUX/icons/chevron-down.svg";
import { Card } from "@mui/material";
import useFieldsChecker from "../../../../CustomHooks/FieldsValidatorHook";
import {
  handleDisableChecking,
  handleEnableChecking,
  handleGetFilledValuesOfDropdowns,
  handleGetOrganizations,
} from "./dropdownManager";
import Styles from "./dropdown-manager.module.css";
import useToggler from "../../../../CustomHooks/TogglerHook";
import { doGetApiCall, doPostApiCall } from "../../../../utils/ClonosApi";
import AppUrl from "../../../../utils/AppUrl";
import Plus_Icon from "../../../../assets/UIUX/icons/WO/WO_Plus.svg";
import AddOptionModal from "./dropdownModals/AddOptionModal";
import { useDispatch } from "react-redux";
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

function Dropdowns() {
  const {
    handleGetErrorActivatorInformation,
    handlePrimaryObjectModifier,
    handleGetUpdatedPrimaryObject,
    primaryObject,
  } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "Dropdowns" });
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({});
  const [organization, setOrganizations] = useState({});
  const [buisnessUnits, setBuisnessUnits] = useState({});
  const [organizationId, setOrgainizationId] = useState("");
  const [dropdownList, setDropdownList] = useState([]);
  const [dropDownId, setDropDownId] = useState("");
  const [optionModal, setOptionModal] = useState(false);
  const [isLoading, setIsLoading] = useToggler();
  
  const handleGetValues = (props) => {
    handleGetFilledValuesOfDropdowns({
      fieldProps: props,
      primaryObject,
      setFormData,
      handlePrimaryObjectModifier,
    });
  };

 
  const handleGetBusinessUnits = async ({ organizationId }) => {
    try {
      const res = await doGetApiCall({
        url: AppUrl?.getBusinessUnits,
        params: {
          organization: organizationId,
          selectFields: "name,organization,shortName,isEnabled,usersCount",
        },
      });
  
      setBuisnessUnits(res?.data?.result);
    } catch (error) {
      console.log(error);
    }
  };

  const handleBulkInit =async({organizationId})=>{
    try {
       const payload={
        organization:organizationId
       }

      let res =await doPostApiCall({url:"dropdowns/admin/bulk-init",payload:payload})
    } catch (error) {
      console.log(error)
    }
  }

  const handleGetDropdowns = async ({ organizationId, businessUnitId }) => {
    try {
      const res = await doGetApiCall({
        url: "dropdowns/admin",
        params: { organization: organizationId, businessUnit: businessUnitId },
      });

      setDropdownList(res?.data?.result || []);
    } catch (error) {
      console.log(error);
    }
  };

  const handleCheckboxChange = async (dropdownId, optionId, isChecked) => {
    try {
      const payload = {
        organization: formData?.organization?.id,
        businessUnit: formData?.businessUnits?.id,
      };

      if (isChecked) {
        await handleDisableChecking({
          dispatch,
          dropdownId,
          optionId,
          setIsLoading,
          payload,
        });
      } else {
        await handleEnableChecking({
          dispatch,
          dropdownId,
          optionId,
          setIsLoading,
          payload,
        });
      }

      //Refresh dropdown list after update
      handleGetDropdowns({
        organizationId: formData?.organization?.id,
        businessUnitId: formData?.businessUnits?.id,
      });
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    handleGetOrganizations({
      setterMethod: setOrganizations,
      setIsLoading: setIsLoading,
    });
  }, []);

  return (
    <Card
      variant="outlined"
      style={{
        flex: 1,
        margin:
          URL?.unity || URL?.AR || URL?.VR ? "1rem 1rem 1rem 1rem" : " 1rem",
        borderRadius: "1rem",
        display: "flex",
        flexDirection: "column",
        overflowY: "auto",
        padding: "1rem",
      }}
    >
      <div className={Styles.DropdownContainer}>
          <p className={Styles.DropdownTitle}>Dropdown Management</p>
        <div className={Styles.DropdownSelectContainer}>
           <ClonosSelect
          type="select"
          isLabel={true}
          icon={DOWNANGLE}
          isMandatory={false}
          placeholder="Select"
          label={"Organization"}
          uniqueKey="organization"
          handleGetValues={async (props) => {
            handleGetValues(props);

            const organizationId = props?.updatedValue?.value;

            const fieldsControllers = handleGetUpdatedPrimaryObject();
            fieldsControllers["businessUnits"]?.resetMethod();

            //Get Business Units
            await handleGetBusinessUnits({ organizationId });

            setOrgainizationId(organizationId);

            //Initialize dropdowns in backend
            await handleBulkInit({ organizationId });

            // Fetch dropdowns AFTER init
            await handleGetDropdowns({ organizationId });
          }}
          errorMessage={"Organization is Required!."}
          handleGetErrorActivatorInformation={
            handleGetErrorActivatorInformation
          }
          options={
            organization?.data?.map((org) => ({
              label: org?.name,
              value: org?.id,
              isNeeded: true,
            })) || []
          }
        

          //   defaultValue={formData?.criticalityLevel ?? globalStateOfChildData?.generalDetails?.criticalityLevel?.name ?? globalStateOfChildData?.generalDetails?.criticalityLevel}
        />
        <ClonosSelect
          type="select"
          isLabel={true}
          icon={DOWNANGLE}
          isMandatory={false}
          placeholder="Select"
          label={"Business Unit"}
          uniqueKey="businessUnits"
          // handleGetValues={handleGetValues}
          handleGetValues={(props) => {
            handleGetValues(props);
            console.log(props, "props");
            const businessUnitId = props?.updatedValue?.value;
            handleGetDropdowns({ organizationId, businessUnitId });
          }}
          errorMessage={"BusinessUnits is Required!."}
          handleGetErrorActivatorInformation={
            handleGetErrorActivatorInformation
          }
          options={
            buisnessUnits?.data?.map((bu) => ({
              label: bu?.name,
              value: bu?.id,
              isNeeded: true,
            })) || []
          }
             disabled={!formData?.organization?.name}
          //   defaultValue={formData?.criticalityLevel ?? globalStateOfChildData?.generalDetails?.criticalityLevel?.name ?? globalStateOfChildData?.generalDetails?.criticalityLevel}
        />
        </div>
        
  {
    formData?.organization?.name &&  <>
    
    <div className={Styles.dropdownHeader}>
          <p>Dropdown List</p>
        </div>

          {/* Dropdown List Items */}

        <div className={Styles.dropdownListWrapper}>
          {dropdownList?.map((dropdown) => (
            <div key={dropdown._id} className={Styles.dropdownItem}>
              <Accordion
              disableGutters
              elevation={0}
              square
              sx={{
                background: "transparent",
                "&:before": { display: "none" }, // removes top line
              }}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                sx={{
                padding: 0,
                minHeight: "unset",
                "& .MuiAccordionSummary-content": {
                  margin: 0,
                  width: "100%",      
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                },
              }}
              >
                <div className={Styles.DropdownElements}>
                  <p>{dropdown.name}</p>

                  <button
                    className={Styles.plc_plain_button}
                    onClick={() => {
                      setOptionModal(true);
                      setDropDownId(dropdown._id);
                    }}
                  >
                    <img src={Plus_Icon} alt="Add" />
                    Add Options
                  </button>
                </div>
              </AccordionSummary>

              <AccordionDetails
                sx={{
                  padding: "8px 0 0 0", // control spacing manually
                }}
              >
                <div className={Styles.dropdownOptions}>
                  {dropdown.options?.map((opt) => {
                    const isChecked = !opt.isDisabled;

                    return (
                      <div key={opt._id} className={Styles.optionItem}>
                        <label>
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() =>
                              handleCheckboxChange(
                                dropdown._id,
                                opt._id,
                                isChecked
                              )
                            }
                          />
                          {opt?.value}
                        </label>
                      </div>
                    );
                  })}
                </div>
              </AccordionDetails>
              </Accordion>
            </div>
          ))}
        </div>
    
    </> 
  }
      
        {optionModal && (
          <AddOptionModal
          isOpen={optionModal}
          closeMethod={() => setOptionModal(false)}
          onSuccess={() => {
            handleGetDropdowns({
              organizationId: formData?.organization?.id,
              businessUnitId: formData?.businessUnits?.id,
            });
          }}
          dropDownId={dropDownId}
        />
        )}
      </div>
    </Card>
  );
}

export default Dropdowns;
