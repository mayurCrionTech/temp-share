import AppUrl from "../../../../utils/AppUrl";
import { doDeleteApiCall, doGetApiCall, doPostApiCall } from "../../../../utils/ClonosApi";
import { handleShowErrorAndWarning } from "../../../../utils/clonosCommon";
/*
date            qid / cr#         comments
18-mar-2026     CR0001            Apply filter on drop down

*/
export const handleGetFilledValuesOfDropdowns = ({fieldProps,primaryObject,setFormData,handlePrimaryObjectModifier,mode,setChangedData,serverResponse,}) => {
    const {type,uniqueKey,updatedValue,selectedOption,files} = fieldProps;
     
    if (type == "dynamicDropdown") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
      
        setFormData((prev) => ({ ...prev, [uniqueKey]: selectedOption?.map(opt => ({name:opt?.name,id:opt?.id,spareId:opt?.spareId,quantity:opt?.quantity}))}))
    } else if (type == "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
            setFormData((prev) => ({...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}}))
    } else if (type == "text" || type == "date" || type == "time" || type == "datetime-local" || type == "number") {
           
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
                setFormData((prev) => ({...prev,[uniqueKey]:updatedValue}))

            
    } else if (type == "file") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
       
        setFormData((prev) => ({ ...prev, [uniqueKey] : files }))
    } else if (type === "checkbox"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    } else if(type === "taskLibrary"){
        setFormData(prev => ({...prev,[uniqueKey]:selectedOption}))
    } else if(type === "toggle"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    }else if(type === "isEditable") {
      setFormData(prev => {
        let auxObj = {...prev,[`${uniqueKey}NeedToDelete`]:selectedOption};
        // debouncedSaveFildsToLocalStorage({key:"generalDetails",data:{generalDetails:{...prev,[uniqueKey]:files[0]}}})
        return auxObj
      }) 
    }
}


export const handleGetOrganizations = async({setterMethod,setIsLoading})=>{
   setIsLoading()
   try {
       let res = await doGetApiCall({url:AppUrl?.getOrgainzations}) 
       console.log(res,"resultorg")
       setterMethod(res?.data?.result)
   } catch (error) {
    console.log(error)
   }finally{
     setIsLoading()
   }
}

export const handleCreateDropDowns=async({dispatch,setIsLoading,formData})=>{
   setIsLoading()
   try {
        let res = await doPostApiCall({url:'/dropdowns/admin',payload:formData})
        handleShowErrorAndWarning({dispatch,message:`Dropdown Created successfully.`,type:"success",showTime:"5000"})
   } catch (error) {
    console.log(error)
   }
}


export const handleCreateOptions=async({dispatch,setIsLoading,formData,dropDownId})=>{
   setIsLoading()
   try {
        let res = await doPostApiCall({url:`dropdowns/admin/${dropDownId}/options`,payload:formData})
        handleShowErrorAndWarning({dispatch,message:`Dropdown Options Created successfully.`,type:"success",showTime:"5000"})
   } catch (error) {
    console.log(error)
   }
}

export const handleDisableChecking =async({dispatch,dropdownId,optionId,setIsLoading,payload})=>{
   setIsLoading()
   try {
        let res = await doPostApiCall({url:`dropdowns/admin/${dropdownId}/options/${optionId}/disable`,payload:payload})
        handleShowErrorAndWarning({dispatch,message:`Dropdown Options Disabled successfully.`,type:"success",showTime:"5000"})
   } catch (error) {
    console.log(error)
   }finally{
    setIsLoading()
   }
}

export const handleEnableChecking =async({dispatch,dropdownId,optionId,setIsLoading,payload})=>{
   setIsLoading()
   try {
        let res = await doDeleteApiCall({url:`dropdowns/admin/${dropdownId}/options/${optionId}/disable`,payload:payload})
        handleShowErrorAndWarning({dispatch,message:`Dropdown Options Enabled successfully.`,type:"success",showTime:"5000"})
   } catch (error) {
    console.log(error)
   }finally{
    setIsLoading()
   }
}