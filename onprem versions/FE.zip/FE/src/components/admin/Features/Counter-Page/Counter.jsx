import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  Card,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import { doGetApiCall, doPutApiCall } from "../../../../utils/ClonosApi";
import { handleShowErrorAndWarning } from "../../../../utils/clonosCommon";
import { useDispatch } from "react-redux";
import { ClonosButton } from "../../../CommonComponents/Button/Button";

const Counter = () => {
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  const [entries, setEntries] = useState({});
  const [loading, setLoading] = useState(false);
  const dispatch =useDispatch();
  const today = useMemo(() => {
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return t;
  }, []);

  // 🔹 Generate month days
  const getDaysInMonth = (year, month) => {
    const date = new Date(year, month, 1);
    const days = [];
    while (date.getMonth() === month) {
      days.push(new Date(date));
      date.setDate(date.getDate() + 1);
    }
    return days;
  };

  const days = useMemo(() => {
    return getDaysInMonth(
      selectedMonth.getFullYear(),
      selectedMonth.getMonth()
    );
  }, [selectedMonth]);

  // Fetch Month Data
  const fetchMonthData = async () => {
    try {
      setLoading(true);
      const year = selectedMonth.getFullYear();
      const month = selectedMonth.getMonth() + 1;

     const res = await doGetApiCall({url:`trucks?year=${year}&month=${month}`});
   
      const apiData = {};
      res?.data?.result?.forEach((item) => {
        apiData[item.date] = item.truckCount;
      });

      setEntries(apiData);
     
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMonthData();
  }, [selectedMonth]);

  // 🔹 Handle change
  const handleChange = (dateKey, value) => {
    setEntries((prev) => ({
      ...prev,
      [dateKey]: value,
    }));
  };

  // 🔹 Submit
  const handleSubmit = async () => {
    try {
      const payload = Object.keys(entries).map((key) => ({
        date: key,
        truckCount: Number(entries[key]),
      }));
     

      let res = await doPutApiCall({url:'/trucks',payload:payload})
       if(res.status==200){
           handleShowErrorAndWarning({dispatch,message:`Count updated successfully.`,type:"success",showTime:"5000"})
       }
      
    } catch (err) {
      console.error(err);
    }
  };



  const changeMonth = (direction) => {
  const newMonth = new Date(selectedMonth);
  newMonth.setMonth(newMonth.getMonth() + direction);

  const currentMonth = new Date();
  currentMonth.setDate(1);
  currentMonth.setHours(0, 0, 0, 0);

  // Prevent going before current month
  if (newMonth < currentMonth) return;

  setSelectedMonth(newMonth);
};

  return (
    <Card
  variant="outlined"
  sx={{
    flex: 1,
    m: 1,
    borderRadius: "1rem",
    display: "flex",
    flexDirection: "column",
    overflowY: "auto",
    p: 2,
  }}
>
  {/* Header Row */}
  <Box
    display="flex"
    justifyContent="space-between"
    alignItems="center"
  >
    <Typography variant="h6">
      {selectedMonth.toLocaleString("default", { month: "long" })}{" "}
      {selectedMonth.getFullYear()}
    </Typography>

    
    <Box display="flex" gap={1}>
 
  <ClonosButton
          variant="outlined"
          onClick={() => changeMonth(-1)}
          >
            Previous Month
      </ClonosButton>
<ClonosButton
          variant="filled"
           onClick={() => changeMonth(1)}
          >
           Next Month
          </ClonosButton>
  
   </Box>
  </Box>

  {/* Table */}
  <Table size="small" sx={{ mt: 2 }}>
    <TableHead>
      <TableRow>
        <TableCell>Date</TableCell>
        <TableCell>Counter</TableCell>
      </TableRow>
    </TableHead>

    <TableBody>
     {days.map((day) => {
  const d = new Date(day);
  d.setHours(0, 0, 0, 0);

  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const dayNum = String(d.getDate()).padStart(2, "0");

  const dateKey = `${year}-${month}-${dayNum}`;

  const isPast = d < today;

  return (
    <TableRow key={dateKey}>
      <TableCell>{dateKey}</TableCell>

      <TableCell>
        <TextField
          type="number"
          size="small"
          value={entries[dateKey] ?? 117}
          disabled={isPast}
          onChange={(e) =>
            handleChange(dateKey, e.target.value)
          }
        />
      </TableCell>
    </TableRow>
  );
})}
    </TableBody>
  </Table>

  {/* Submit Button */}
  <Box display="flex" justifyContent="flex-end" mt={2}>
    <ClonosButton
      variant="filled"
      onClick={handleSubmit}
      >
      Submit
      </ClonosButton>

  </Box>
</Card>

  );
};

export default Counter;

