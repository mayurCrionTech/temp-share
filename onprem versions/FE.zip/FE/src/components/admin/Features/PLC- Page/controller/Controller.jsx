


//working code
// import React, { useState, useEffect } from 'react';
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Grid,
//   IconButton,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Chip,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   Switch
// } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
// import DeleteOutlineIcon from '@material-ui/icons/DeleteOutline';
// import EditIcon from '@material-ui/icons/Edit';
// import SearchIcon from '@material-ui/icons/Search';
// import ClonosInput from '../../../CommonComponents/ClonosInput/ClonosInput';
// import ClonosSelect from '../../../CommonComponents/ClonosSelect/ClonosSelect';
// import { ClonosButton } from '../../../CommonComponents/Button/Button';


// const useStyles = makeStyles((theme) => ({
//   root: {
//     padding: theme.spacing(3),
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: theme.spacing(3),
//   },
//   card: {
//     marginBottom: theme.spacing(3),
//   },
//   parameterRow: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: theme.spacing(2),
//     marginBottom: theme.spacing(2),
//     padding: theme.spacing(2),
//     border: '1px solid #e0e0e0',
//     borderRadius: '4px',
//   },
//   addButton: {
//     marginTop: theme.spacing(2),
//   },
//   searchBox: {
//     marginBottom: theme.spacing(2),
//   },
//   statusChip: {
//     marginLeft: theme.spacing(1),
//   },
//   actionButtons: {
//     display: 'flex',
//     gap: theme.spacing(1),
//   }
// }));

// const Controller= () => {
//   const classes = useStyles();
//   const [mode, setMode] = useState('list'); // list, create, edit
//   const [controllers, setControllers] = useState([]);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [formData, setFormData] = useState({
//     name: '',
//     type: '',
//     ip: '',
//     unitId: '',
//     parameters: []
//   });
//   const [errors, setErrors] = useState({});
//   const [editingId, setEditingId] = useState(null);
//   const [deleteDialog, setDeleteDialog] = useState({ open: false, id: null });

//   // Data type options for parameters
//   const dataTypeOptions = [
//     { label: 'Text', value: 'text', isNeeded: true },
//     { label: 'Number', value: 'number', isNeeded: true },
//     { label: 'Dropdown', value: 'dropdown', isNeeded: true }
//   ];

//   const controllerTypeOptions = [
//     { label: 'Modbus', value: 'modbus', isNeeded: true },
//     { label: 'OPC UA', value: 'opcua', isNeeded: true },
//     { label: 'Ethernet/IP', value: 'ethernetip', isNeeded: true },
//     { label: 'Profinet', value: 'profinet', isNeeded: true }
//   ];

//   // Handle form value updates
//   const handleGetValues = (uniqueKey, value) => {
//     setFormData(prev => ({
//       ...prev,
//       [uniqueKey]: value
//     }));
//     // Clear error for this field
//     if (errors[uniqueKey]) {
//       setErrors(prev => {
//         const newErrors = { ...prev };
//         delete newErrors[uniqueKey];
//         return newErrors;
//       });
//     }
//   };

//   // Handle error states
//   const handleGetErrorActivatorInformation = (uniqueKey, hasError) => {
//     setErrors(prev => ({
//       ...prev,
//       [uniqueKey]: hasError
//     }));
//   };

//   // Add new parameter field
//   const addParameter = () => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: [
//         ...prev.parameters,
//         { id: Date.now(), name: '', dataType: '', required: false }
//       ]
//     }));
//   };

//   // Remove parameter field
//   const removeParameter = (id) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.filter(param => param.id !== id)
//     }));
//   };

//   // Update parameter field
//   const updateParameter = (id, field, value) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(param =>
//         param.id === id ? { ...param, [field]: value } : param
//       )
//     }));
//   };

//   // Validate form
//   const validateForm = () => {
//     const newErrors = {};
    
//     if (!formData.name?.trim()) {
//       newErrors.name = true;
//     }
    
//     if (!formData.type) {
//       newErrors.type = true;
//     }
    
//     if (!formData.ip?.trim()) {
//       newErrors.ip = true;
//     }
    
//     if (!formData.unitId) {
//       newErrors.unitId = true;
//     }

//     // Check for duplicate controller names
//     const isDuplicate = controllers.some(
//       controller => 
//         controller.name.toLowerCase() === formData.name.toLowerCase() &&
//         controller.id !== editingId
//     );

//     if (isDuplicate) {
//       newErrors.name = true;
//       alert('A controller with this name already exists!');
//     }

//     // Validate parameters
//     formData.parameters.forEach((param, index) => {
//       if (!param.name?.trim()) {
//         newErrors[`param_name_${param.id}`] = true;
//       }
//       if (!param.dataType) {
//         newErrors[`param_dataType_${param.id}`] = true;
//       }
//     });

//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };

//   // Submit form
//   const handleSubmit = () => {
//     if (!validateForm()) {
//       alert('Please fill all mandatory fields correctly!');
//       return;
//     }

//     const controllerData = {
//       id: editingId || Date.now(),
//       ...formData,
//       isActive: editingId ? controllers.find(c => c.id === editingId)?.isActive ?? true : true,
//       createdAt: editingId ? controllers.find(c => c.id === editingId)?.createdAt : new Date().toISOString(),
//       updatedAt: new Date().toISOString()
//     };

//     if (mode === 'edit') {
//       setControllers(prev =>
//         prev.map(controller =>
//           controller.id === editingId ? controllerData : controller
//         )
//       );
//       alert('Controller updated successfully!');
//     } else {
//       setControllers(prev => [...prev, controllerData]);
//       alert('Controller created successfully!');
//     }

//     handleCancel();
//   };

//   // Cancel and reset form
//   const handleCancel = () => {
//     setMode('list');
//     setFormData({
//       name: '',
//       type: '',
//       ip: '',
//       unitId: '',
//       parameters: []
//     });
//     setErrors({});
//     setEditingId(null);
//   };

//   // Edit controller
//   const handleEdit = (controller) => {
//     setMode('edit');
//     setEditingId(controller.id);
//     setFormData({
//       name: controller.name,
//       type: controller.type,
//       ip: controller.ip,
//       unitId: controller.unitId,
//       parameters: controller.parameters.map(p => ({ ...p, id: p.id || Date.now() + Math.random() }))
//     });
//   };

//   // Toggle active status
//   const toggleActiveStatus = (id) => {
//     setControllers(prev =>
//       prev.map(controller =>
//         controller.id === id
//           ? { ...controller, isActive: !controller.isActive }
//           : controller
//       )
//     );
//   };

//   // Delete controller
//   const handleDelete = (id) => {
//     setControllers(prev => prev.filter(controller => controller.id !== id));
//     setDeleteDialog({ open: false, id: null });
//     alert('Controller deleted successfully!');
//   };

//   // Filter controllers based on search
//   const filteredControllers = controllers.filter(controller =>
//     controller.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//     controller.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
//     controller.ip.includes(searchTerm)
//   );

//   // Render list view
//   if (mode === 'list') {
//     return (
//       <Box className={classes.root}>
//         <Box className={classes.header}>
//           <Typography variant="h4">Controller Management</Typography>
//           <ClonosButton
//             variant="filled"
//             onClick={() => setMode('create')}
//           >
//             Add New Controller
//           </ClonosButton>
//         </Box>

//         <div className={classes.card}>
//           <CardContent>
//             <Box className={classes.searchBox}>
//               <ClonosInput
//                 label="Search Controllers"
//                 isLabel={true}
//                 placeholder="Search by name, type, or IP..."
//                 type="text"
//                 uniqueKey="search"
//                 defaultValue={searchTerm}
//                 handleGetValues={(key, value) => setSearchTerm(value)}
//                 handleGetErrorActivatorInformation={() => {}}
//               />
//             </Box>

//             <TableContainer component={Paper}>
//               <Table>
//                 <TableHead>
//                   <TableRow>
//                     <TableCell><strong>Name</strong></TableCell>
//                     <TableCell><strong>Type</strong></TableCell>
//                     <TableCell><strong>IP Address</strong></TableCell>
//                     <TableCell><strong>Unit ID</strong></TableCell>
//                     <TableCell><strong>Parameters</strong></TableCell>
//                     <TableCell><strong>Status</strong></TableCell>
//                     <TableCell><strong>Actions</strong></TableCell>
//                   </TableRow>
//                 </TableHead>
//                 <TableBody>
//                   {filteredControllers.length === 0 ? (
//                     <TableRow>
//                       <TableCell colSpan={7} align="center">
//                         <Typography variant="body2" color="textSecondary">
//                           No controllers found. Click "Add New Controller" to create one.
//                         </Typography>
//                       </TableCell>
//                     </TableRow>
//                   ) : (
//                     filteredControllers.map((controller) => (
//                       <TableRow key={controller.id}>
//                         <TableCell>{controller.name}</TableCell>
//                         <TableCell>
//                           <Chip label={controller.type} size="small" color="primary" />
//                         </TableCell>
//                         <TableCell>{controller.ip}</TableCell>
//                         <TableCell>{controller.unitId}</TableCell>
//                         <TableCell>{controller.parameters.length}</TableCell>
//                         <TableCell>
//                           <Box display="flex" alignItems="center">
//                             <Switch
//                               checked={controller.isActive}
//                               onChange={() => toggleActiveStatus(controller.id)}
//                               color="primary"
//                             />
//                             <Chip
//                               label={controller.isActive ? 'Active' : 'Inactive'}
//                               size="small"
//                               color={controller.isActive ? 'primary' : 'default'}
//                               className={classes.statusChip}
//                             />
//                           </Box>
//                         </TableCell>
//                         <TableCell>
//                           <Box className={classes.actionButtons}>
//                             <IconButton
//                               size="small"
//                               color="primary"
//                               onClick={() => handleEdit(controller)}
//                             >
//                               <EditIcon />
//                             </IconButton>
//                             <IconButton
//                               size="small"
//                               color="secondary"
//                               onClick={() => setDeleteDialog({ open: true, id: controller.id })}
//                             >
//                               <DeleteOutlineIcon />
//                             </IconButton>
//                           </Box>
//                         </TableCell>
//                       </TableRow>
//                     ))
//                   )}
//                 </TableBody>
//               </Table>
//             </TableContainer>
//           </CardContent>
//         </div>

//         {/* Delete Confirmation Dialog */}
//         <Dialog
//           open={deleteDialog.open}
//           onClose={() => setDeleteDialog({ open: false, id: null })}
//         >
//           <DialogTitle>Confirm Delete</DialogTitle>
//           <DialogContent>
//             <Typography>
//               Are you sure you want to delete this controller? This action cannot be undone.
//             </Typography>
//           </DialogContent>
//           <DialogActions>
//             <ClonosButton
//               variant="outlined"
//               onClick={() => setDeleteDialog({ open: false, id: null })}
//             >
//               Cancel
//             </ClonosButton>
//             <ClonosButton
//               variant="filled"
//               onClick={() => handleDelete(deleteDialog.id)}
//             >
//               Delete
//             </ClonosButton>
//           </DialogActions>
//         </Dialog>
//       </Box>
//     );
//   }

//   // Render create/edit form
//   return (
//     <Box className={classes.root}>
//       <Box className={classes.header}>
//         <Typography variant="h4">
//           {mode === 'edit' ? 'Edit Controller' : 'Create New Controller'}
//         </Typography>
//       </Box>

//       <div className={classes.card}>
//         <CardContent>
//           <Grid container spacing={3}>
//             <Grid item xs={12} md={6}>
//               <ClonosInput
//                 tabIndex={1}
//                 label="Controller Name"
//                 isLabel={true}
//                 placeholder="Enter controller name"
//                 isMandatory={true}
//                 type="text"
//                 limit="50"
//                 uniqueKey="name"
//                 defaultValue={formData.name}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>

//             <Grid item xs={12} md={6}>
//               <ClonosSelect
//                 tabIndex={2}
//                 type="select"
//                 label="Controller Type"
//                 isMandatory={true}
//                 isLabel={true}
//                 uniqueKey="type"
//                 placeholder="Select controller type"
//                 defaultValue={formData.type}
//                 options={controllerTypeOptions}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>

//             <Grid item xs={12} md={6}>
//               <ClonosInput
//                 tabIndex={3}
//                 label="IP Address"
//                 isLabel={true}
//                 placeholder="e.g., 10.100.100.1"
//                 isMandatory={true}
//                 type="text"
//                 limit="15"
//                 uniqueKey="ip"
//                 defaultValue={formData.ip}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>

//             <Grid item xs={12} md={6}>
//               <ClonosInput
//                 tabIndex={4}
//                 label="Unit ID"
//                 isLabel={true}
//                 placeholder="Enter unit ID"
//                 isMandatory={true}
//                 type="number"
//                 limit="5"
//                 uniqueKey="unitId"
//                 defaultValue={formData.unitId}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>
//           </Grid>

//           {/* Dynamic Parameters Section */}
//           <Box mt={4}>
//             <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
//               <Typography variant="h6">Parameters (Custom Fields)</Typography>
//               <IconButton color="primary" onClick={addParameter}>
//                 <AddCircleOutlineIcon />
//               </IconButton>
//             </Box>

//             {formData.parameters.map((parameter, index) => (
//               <Box key={parameter.id} className={classes.parameterRow}>
//                 <Grid container spacing={2} alignItems="center">
//                   <Grid item xs={12} md={4}>
//                     <ClonosInput
//                       tabIndex={10 + index * 3}
//                       label="Parameter Name"
//                       isLabel={true}
//                       placeholder="e.g., Port, Address"
//                       isMandatory={true}
//                       type="text"
//                       limit="30"
//                       uniqueKey={`param_name_${parameter.id}`}
//                       defaultValue={parameter.name}
//                       handleGetValues={(key, value) => updateParameter(parameter.id, 'name', value)}
//                       handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />
//                   </Grid>

//                   <Grid item xs={12} md={4}>
//                     <ClonosSelect
//                       tabIndex={11 + index * 3}
//                       type="select"
//                       label="Data Type"
//                       isMandatory={true}
//                       isLabel={true}
//                       uniqueKey={`param_dataType_${parameter.id}`}
//                       placeholder="Select data type"
//                       defaultValue={parameter.dataType}
//                       options={dataTypeOptions}
//                       handleGetValues={(key, value) => updateParameter(parameter.id, 'dataType', value)}
//                       handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />
//                   </Grid>

//                   <Grid item xs={12} md={3}>
//                     <Box display="flex" alignItems="center" mt={3}>
//                       <Switch
//                         checked={parameter.required}
//                         onChange={(e) => updateParameter(parameter.id, 'required', e.target.checked)}
//                         color="primary"
//                       />
//                       <Typography variant="body2">Required</Typography>
//                     </Box>
//                   </Grid>

//                   <Grid item xs={12} md={1}>
//                     <IconButton
//                       color="secondary"
//                       onClick={() => removeParameter(parameter.id)}
//                     >
//                       <DeleteOutlineIcon />
//                     </IconButton>
//                   </Grid>
//                 </Grid>
//               </Box>
//             ))}

//             {formData.parameters.length === 0 && (
//               <Box
//                 p={3}
//                 textAlign="center"
//                 border="2px dashed #e0e0e0"
//                 borderRadius="4px"
//               >
//                 <Typography variant="body2" color="textSecondary">
//                   No parameters added yet. Click the + icon to add custom parameters.
//                 </Typography>
//               </Box>
//             )}
//           </Box>

//           {/* Action Buttons */}
//           <Box mt={4} display="flex" justifyContent="flex-end" gap={2}>
//             <ClonosButton variant="outlined" onClick={handleCancel}>
//               Cancel
//             </ClonosButton>
//             <ClonosButton variant="filled" onClick={handleSubmit}>
//               {mode === 'edit' ? 'Update' : 'Submit'}
//             </ClonosButton>
//           </Box>
//         </CardContent>
//       </div>
//     </Box>
//   );
// };

// export default Controller;


//last working code

// import React, { useState, useEffect } from 'react';
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Grid,
//   IconButton,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Chip,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   Switch
// } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
// import DeleteOutlineIcon from '@material-ui/icons/DeleteOutline';
// import EditIcon from '@material-ui/icons/Edit';
// import SearchIcon from '@material-ui/icons/Search';
// import ClonosInput from '../../../../CommonComponents/ClonosInput/ClonosInput';
// import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { handleGetFilledValuesOfPlc } from '../plc-manager';
// import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
// import Styles from '../../plc.module.css'
// import Plus_Icon from '../../../../../assets/UIUX/icons/WO/WO_Plus.svg'
// import TEMPLATE_CREATION_REMOVEROW from "../../../../../assets/UIUX/icons/Checklist/circle-minus.svg";
// import TEMPLATE_CREATION_GRIP_VERTICAL from "../../../../../assets/UIUX/icons/Checklist/grip-vertical.svg";
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer'
// import { useDispatch } from 'react-redux';
// import { useSelector } from 'react-redux';
// import { useLocation, useNavigate } from 'react-router-dom';

// const useStyles = makeStyles((theme) => ({
//   root: {
//     padding: theme.spacing(3),
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: theme.spacing(3),
//   },
//   card: {
//     marginBottom: theme.spacing(3),
//   },
//   parameterRow: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: theme.spacing(2),
//     marginBottom: theme.spacing(2),
//     padding: theme.spacing(2),
//     border: '1px solid #e0e0e0',
//     borderRadius: '4px',
//   },
//   addButton: {
//     marginTop: theme.spacing(2),
//   },
//   searchBox: {
//     marginBottom: theme.spacing(2),
//   },
//   statusChip: {
//     marginLeft: theme.spacing(1),
//   },
//   actionButtons: {
//     display: 'flex',
//     gap: theme.spacing(1),
//   }
// }));

// const Controller= ({mode}) => {
//   const classes = useStyles();
//  const dispatch =useDispatch()
//   const [formData, setFormData] = useState({});
//   const [activeParamId, setActiveParamId] = useState(null);
//   const navigate= useNavigate()
//   const location=useLocation();
//   console.log(location,"location")
   
//  const controllerData = useSelector((store)=>store.plcData.controller)
//   console.log(mode,"mode")
//  console.log(controllerData,"controllerData")
//   const {
//           handleGetErrorActivatorInformation,
//           handlePrimaryObjectModifier,
//           handleSubmit,
//           handleGetUpdatedPrimaryObject,
//           handleRemoveField,
//           primaryObject
//         } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "Plc" });

    

//   // Data type options for parameters
//   const dataTypeOptions = [
//     { label: 'Text', value: 'text', isNeeded: true },
//     { label: 'Number', value: 'number', isNeeded: true },
//     // { label: 'Dropdown', value: 'dropdown', isNeeded: true }
//   ];

//   const controllerTypeOptions = [
//     { label: 'Modbus', value: 'modbus', isNeeded: true },
//     { label: 'Siemens', value: 'Siemens', isNeeded: true },
//     { label: 'Ethernetip', value: 'ethernetip', isNeeded: true },
//   ];


//   const DEFAULT_PARAMETERS_BY_NETWORK = {
//   Modbus: [
//     {
//       id: Date.now() + 1,
//       name: "name",
//       dataType: "text",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 2,
//       name: "db",
//       dataType: "number",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 3,
//       name: "offset",
//       dataType: "number",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 4,
//       name: "type",
//       dataType: "text",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 5,
//       name: "unit",
//       dataType: "text",
//       options: [],
//       isDefault: true
//     }
//   ],

//   Siemens: [
//      {
//       id: Date.now() + 1,
//       name: "name",
//       dataType: "text",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 2,
//       name: "port",
//       dataType: "number",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 3,
//       name: "address",
//       dataType: "number",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 4,
//       name: "type",
//       dataType: "text",
//       options: [],
//       isDefault: true
//     },
//     {
//       id: Date.now() + 5,
//       name: "unit",
//       dataType: "text",
//       options: [],
//       isDefault: true
//     }
//   ],

//   Ethernetip: [
//     {
//       id: Date.now() + 1,
//       name: "name",
//       dataType: "text",
//       options: [],
//       isDefault: true
//     },
    
    
//   ]
// };


//     const handleGetValues = (props) => {
//           handleGetFilledValuesOfPlc({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier})
//       }


//   const handleAddParameter = () => {
//   const newParam = {
//     id: Date.now(),
//     name: "",
//     dataType: "",
//     options: [],
//     isNew: true 
//   };

//   setFormData(prev => ({
//     ...prev,
//     parameters: [...(prev.parameters || []), newParam]
//   }));

//   setActiveParamId(newParam.id); // ✅ open newly added parameter
// };

//   // Remove parameter row
//   const handleRemoveParameter = (paramId) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.filter(p => p.id !== paramId)
//     }));
//   };

//   // Update parameter name
//   const handleUpdateParameterName = (paramId, value) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId ? { ...p, name: value } : p
//       )
//     }));
//   };

//   // Update parameter type
//   const handleUpdateParameterType = (paramId, option) => {
//   console.log(paramId, option, "value");

//   setFormData(prev => ({
//     ...prev,
//     parameters: prev.parameters.map(p => {
//       if (p.id !== paramId) return p;

//       if (!option) {
//         return { ...p, dataType: "", options: [] };
//       }

//       return {
//         ...p,
//         dataType: option.value,
//         options: option.value === "dropdown" ? [] : []
//       };
//     })
//   }));
// };


//   // Add dropdown option
//   const handleAddOption = (paramId) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId ? { ...p, options: [...p.options, ""] } : p
//       )
//     }));
//   };

//   // Update dropdown option
//   const handleUpdateOption = (paramId, index, value) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId
//           ? { ...p, options: p.options.map((o, i) => (i === index ? value : o)) }
//           : p
//       )
//     }));
//   };

//   // Remove dropdown option
//   const handleRemoveOption = (paramId, index) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId
//           ? { ...p, options: p.options.filter((_, i) => i !== index) }
//           : p
//       )
//     }));
//   };



// console.log(formData,"formData")



// // const handleSubmitController = () => {
// //   if (mode === "edit") {
// //     dispatch(plcActions.updateController(formData));
// //   } else {
// //     dispatch(
// //       plcActions.setController({
// //         ...formData,
// //         id: Date.now()
// //       })
// //     );
// //   }

// //   navigate("/plc");
// // };

// const handleSubmitController = () => {
//   const normalizedFormData = {
//     ...formData,
//     parameters: formData.parameters?.map(p => ({
//       ...p,
//       isNew: false // 🔒 lock all params after save
//     }))
//   };

//   if (mode === "edit") {
//     dispatch(plcActions.updateController(normalizedFormData));
//   } else {
//     dispatch(
//       plcActions.setController({
//         ...normalizedFormData,
//         id: Date.now()
//       })
//     );
//   }

//   navigate("/plc");
// };

// const handleAddDefaultParameters = () => {
//   const networkName = formData.type?.name;

//   if (!networkName) return;

//   const defaults = DEFAULT_PARAMETERS_BY_NETWORK[networkName] || [];

//   setFormData(prev => {
//     const existingNames = (prev.parameters || []).map(p => p.name);

//     // avoid duplicates
//     const filteredDefaults = defaults.filter(
//       d => !existingNames.includes(d.name)
//     );

//     return {
//       ...prev,
//       parameters: [...(prev.parameters || []), ...filteredDefaults]
//     };
//   });

//  setActiveParamId(null);
// };


// const editData = controllerData.find(
//     (e) => e.id === location.state?.id
//   );

//   console.log(editData,"editData")

//   useEffect(() => {
//     if (editData) {
//       setFormData(editData);
//     }
//   }, [editData]);






//   return (
//          <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : " 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto",padding:"1rem" }}>
//       <Box className={classes.header}>
//         <Typography variant="h4">
//                {mode=="edit" ? "Edit Controller" : "Create Controller" }  
//         </Typography>
//       </Box>

//       <div className={classes.card}>
//         <CardContent>
//           <Grid container spacing={3}>
//             <Grid item xs={12} md={4}>
//               <ClonosInput
//                 tabIndex={1}
//                 label="Controller Name"
//                 isLabel={true}
//                 placeholder="Enter controller name"
//                 isMandatory={true}
//                 type="text"
//                 limit="50"
//                 uniqueKey="name"
//                 defaultValue={formData.name}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>

//             <Grid item xs={12} md={4}>
//               <ClonosSelect
//                 tabIndex={2}
//                 type="select"
//                 label="Network"
//                 isMandatory={true}
//                 isLabel={true}
//                 uniqueKey="type"
//                 placeholder="Select Network"
//                 defaultValue={formData?.type?.name}
//                 options={controllerTypeOptions}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>
            
//              <Grid item xs={12} md={4}>
//               <ClonosInput
//                 tabIndex={3}
//                 label="IP Address"
//                 isLabel={true}
//                 placeholder="e.g., 10.100.100.1"
//                 isMandatory={true}
//                 type="text"
//                 limit="15"
//                 uniqueKey="ip"
//                 defaultValue={formData.ip}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>
          
//           </Grid>


// {formData.type?.id && (
//   <Box mt={4}>
//     <Typography variant="subtitle1" color="textSecondary">
//       Protocol Configuration
//     </Typography>
//   </Box>
// )}

//  {/* ---------- Modbus ---------- */}
// {formData.type?.name === "Modbus" && (
//   <Box mt={2}>
//     <Grid container spacing={3}>
//       <Grid item xs={12} md={4}>
//         <ClonosInput
//           tabIndex={4}
//           label="Unit ID"
//           isLabel
//           placeholder="Enter unit ID (1–247)"
//           isMandatory
//           type="number"
//           limit="5"
//           uniqueKey="unitId"
//           defaultValue={formData.unitId}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>
//     </Grid>
//   </Box>
// )}

// {/* ---------- Siemens ---------- */}
// {formData.type?.name === "Siemens" && (
//   <Box mt={2}>
//     <Grid container spacing={3}>
//       <Grid item xs={12} md={4}>
//         <ClonosInput
//           tabIndex={5}
//           label="Slot"
//           isLabel
//           placeholder="Enter Slot"
//           isMandatory
//           type="text"
//           limit="15"
//           uniqueKey="slot"
//           defaultValue={formData.slot}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>

//       <Grid item xs={12} md={4}>
//         <ClonosInput
//           tabIndex={6}
//           label="Rack"
//           isLabel
//           placeholder="Enter rack"
//           isMandatory
//           type="number"
//           limit="5"
//           uniqueKey="rack"
//           defaultValue={formData.rack}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>
//     </Grid>
//   </Box>
// )}

// {formData.type?.name === "Ethernetip" && (
//   <Box mt={2}>
//     <Grid container spacing={3}>
//       <Grid item xs={12} md={4}>
//          <ClonosInput
//           tabIndex={5}
//           label="Slot"
//           isLabel
//           placeholder="Enter Slot"
//           isMandatory
//           type="text"
//           limit="15"
//           uniqueKey="slot"
//           defaultValue={formData.slot}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>

//       <Grid item xs={12} md={4}>
//         <ClonosSelect
//           tabIndex={2}
//           type="select"
//           label="Auto Discover"
//           isMandatory={true}
//           isLabel={true}
//           uniqueKey="autoDiscover"
//           placeholder="Select"
//           defaultValue={formData?.autoDiscover?.name}
//           options={[ { label: 'true', value: 'true', isNeeded: true }, { label: 'false', value: 'false', isNeeded: true },]}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>
//     </Grid>
//   </Box>
// )}


//           {/* Dynamic Parameters Section */}
         
//  <Box mt={4}>
//       {/* Header */}
//       <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
//         <Typography variant="h6">Parameter Template</Typography>

//         <Box display="flex" gap="8px">
//           <button
//             className={Styles.plc_plain_button}
//             onClick={handleAddDefaultParameters}
//             disabled={!formData.type?.name}
//           >
//             <img src={Plus_Icon} alt="Default" />
//             Default Parameters
//           </button>

//           <button
//             className={Styles.plc_plain_button}
//             disabled={!formData.type?.name}
//             onClick={handleAddParameter}
//           >
//             <img src={Plus_Icon} alt="Add" />
//             Add Parameter
//           </button>
//         </Box>
//       </Box>


//       {/* No parameters yet */}
//       {(!formData.parameters || formData.parameters.length === 0) && (
//         <Box
//           p={3}
//           textAlign="center"
//           border="2px dashed #e0e0e0"
//           borderRadius="4px"
//         >
//           <Typography variant="body2" color="textSecondary">
//             No parameters added yet. Click "Add Parameter" to create a new template row.
//           </Typography>
//         </Box>
//       )}

//     {formData.parameters?.map((param, index) => {
//   const isOpen = activeParamId === param.id;

//   return (
//     <Box
//       key={param.id}
//       mb={2}
//       border="1px solid #e0e0e0"
//       borderRadius="8px"
//     >
//       {/* ================= HEADER ================= */}
//       <Box
//         display="flex"
//         alignItems="center"
//         justifyContent="space-between"
//         px={2}
//         py={1.5}
//         sx={{ cursor: "pointer" }}
//        onClick={() =>
//   setActiveParamId(prev =>
//     prev === param.id ? null : param.id
//   )
// }

//       >
//         {/* LEFT */}
//         <Box display="flex" alignItems="center" sx={{ gap: "12px" }}>
//           <img
//             src={TEMPLATE_CREATION_GRIP_VERTICAL}
//             alt="drag"
//             style={{ opacity: 0.6 }}
//           />

//          {formData.type?.name !== "Ethernetip" && <Typography fontSize="14px" fontWeight={500}>
//             {param.name || "Unnamed Parameter"}
//           </Typography>
//     }
//         </Box>

//         {/* RIGHT */}
//         <Box display="flex" alignItems="center" sx={{ gap: "12px" }}>
//           {/* datatype badge */}
//           {param.dataType && (
//             <Box
//               px={1.5}
//               py={0.5}
//               borderRadius="12px"
//               bgcolor="#e0e0e0"
//               fontSize="12px"
//               fontWeight={500}
//               textTransform="capitalize"
//             >
//               {param.dataType}
//             </Box>
//           )}
//           {/* delete */}
//           <button
//             className={Styles.iconButtonheader}
//             onClick={(e) => {
//               e.stopPropagation(); // 👈 prevent collapse toggle
//               handleRemoveParameter(param.id);
//             }}
//           >
//             <img src={TEMPLATE_CREATION_REMOVEROW} alt="Remove" />
//           </button>
//         </Box>
//       </Box>

//       {/* ================= BODY ================= */}
//       {isOpen && (
//         <Box px={2} pb={2}>

//           <Grid container spacing={3} mt={1}>
//             {/* Parameter Name */}
//             {formData.type?.name !== "Ethernetip" && <Grid item xs={12} md={4}>
//               <ClonosInput
//                 label="Parameter Name"
//                 isLabel
//                 type="text"
//                 placeholder={"Parameter Name"}
//                 uniqueKey={`param-name-${param.id}`}
//                 defaultValue={param.name}
//                 handleGetValues={({ updatedValue }) =>
//                   handleUpdateParameterName(param.id, updatedValue)
//                 }
//                 disabled={mode === "edit" && !param.isNew}
//               />
//             </Grid>
// } 
//             {/* Data Type */}
//             <Grid item xs={12} md={4}>
//               <ClonosSelect
//                 label="Type"
//                 isLabel
//                 uniqueKey={`param-type-${param.id}`}
//                 options={dataTypeOptions}
//                  placeholder={"Select Type"}
//                 defaultValue={param.dataType}
//                 handleGetValues={({ updatedValue }) =>
//                   handleUpdateParameterType(param.id, updatedValue)
//                 }
//                disabled={mode === "edit" && !param.isNew}
//               />
//             </Grid>
//           </Grid>

//           {/* DROPDOWN OPTIONS */}
//           {param.dataType === "dropdown" && (
//             <Box mt={3}>
//               <Box
//                 display="flex"
//                 justifyContent="space-between"
//                 alignItems="center"
//                 mb={2}
//               >
//                 <Typography fontSize="14px" fontWeight={500}>
//                   Dropdown Options
//                 </Typography>

//                 <button
//                   className={Styles.plc_plain_button_option}
//                   onClick={() => handleAddOption(param.id)}
//                 >
//                   <img src={Plus_Icon} alt="Add" />
//                   Add option
//                 </button>
//               </Box>

//               {param.options.map((opt, i) => (
//                 <Grid
//                   container
//                   spacing={2}
//                   alignItems="center"
//                   key={i}
//                   mt={1}
//                 >
//                   <Grid item xs={10}>
//                     <ClonosInput
//                       label={`Option ${i + 1}`}
//                       isLabel
//                       type="text"
//                       defaultValue={opt} 
//                       handleGetValues={({ updatedValue }) => {
//                         console.log(updatedValue);
//                         handleUpdateOption(param.id, i, updatedValue);
//                       }}

//                     />
//                   </Grid>

//                   <Grid item xs={2}>
//                     <button
//                       className={Styles.iconButton}
//                       onClick={() => handleRemoveOption(param.id, i)}
//                     >
//                       <img
//                         src={TEMPLATE_CREATION_REMOVEROW}
//                         alt="Remove option"
//                       />
//                     </button>
//                   </Grid>
//                 </Grid>
//               ))}
//             </Box>
//           )}
//         </Box>
//       )}
//     </Box>
//   );
// })}




//     </Box>

//           {/* Action Buttons */}
//           <Box mt={4} display="flex" justifyContent="flex-end" gap={2} >
//             <ClonosButton variant="outlined" onClick={()=>navigate(-1)}>
//               Cancel
//             </ClonosButton>
//             &nbsp;
//             <ClonosButton variant="filled" onClick={handleSubmitController}>
//                  {mode=="edit" ? "Update" : "Submit" }  
//             </ClonosButton>
//           </Box>
//         </CardContent>
//       </div>
//     </Card>
//   );
// };

// export default Controller;

//optimized code

// import React, { useState, useEffect, useMemo, useCallback } from 'react';
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Grid
// } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import ClonosInput from '../../../../CommonComponents/ClonosInput/ClonosInput';
// import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { handleGetFilledValuesOfPlc } from '../plc-manager';
// import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
// import Styles from '../../plc.module.css';
// import Plus_Icon from '../../../../../assets/UIUX/icons/WO/WO_Plus.svg';
// import TEMPLATE_CREATION_REMOVEROW from "../../../../../assets/UIUX/icons/Checklist/circle-minus.svg";
// import TEMPLATE_CREATION_GRIP_VERTICAL from "../../../../../assets/UIUX/icons/Checklist/grip-vertical.svg";
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
// import { useDispatch, useSelector } from 'react-redux';
// import { useLocation, useNavigate } from 'react-router-dom';

// const useStyles = makeStyles((theme) => ({
//   root: { padding: theme.spacing(3) },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: theme.spacing(3),
//   },
//   card: { marginBottom: theme.spacing(3) }
// }));

// const Controller = ({ mode }) => {
//   const classes = useStyles();
//   const dispatch = useDispatch();
//   const navigate = useNavigate();
//   const location = useLocation();

//   const controllerData = useSelector(store => store.plcData.controller);

//   const [formData, setFormData] = useState({});
//   const [activeParamId, setActiveParamId] = useState(null);

//   const {
//     handleGetErrorActivatorInformation,
//     handlePrimaryObjectModifier,
//     primaryObject
//   } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "Plc" });

//   /* ------------------ MEMOIZED CONSTANTS ------------------ */

//   const dataTypeOptions = useMemo(() => ([
//     { label: 'Text', value: 'text', isNeeded: true },
//     { label: 'Number', value: 'number', isNeeded: true }
//   ]), []);

//   const controllerTypeOptions = useMemo(() => ([
//     { label: 'Modbus', value: 'modbus', isNeeded: true },
//     { label: 'Siemens', value: 'Siemens', isNeeded: true },
//     { label: 'Ethernetip', value: 'ethernetip', isNeeded: true }
//   ]), []);

//   const DEFAULT_PARAMETERS_BY_NETWORK = useMemo(() => ({
//     Modbus: [
//       { id: Date.now() + 1, name: "name", dataType: "text", options: [], isDefault: true },
//       { id: Date.now() + 2, name: "db", dataType: "number", options: [], isDefault: true },
//       { id: Date.now() + 3, name: "offset", dataType: "number", options: [], isDefault: true },
//       { id: Date.now() + 4, name: "type", dataType: "text", options: [], isDefault: true },
//       { id: Date.now() + 5, name: "unit", dataType: "text", options: [], isDefault: true }
//     ],
//     Siemens: [
//       { id: Date.now() + 1, name: "name", dataType: "text", options: [], isDefault: true },
//       { id: Date.now() + 2, name: "port", dataType: "number", options: [], isDefault: true },
//       { id: Date.now() + 3, name: "address", dataType: "number", options: [], isDefault: true },
//       { id: Date.now() + 4, name: "type", dataType: "text", options: [], isDefault: true },
//       { id: Date.now() + 5, name: "unit", dataType: "text", options: [], isDefault: true }
//     ],
//     Ethernetip: [
//       { id: Date.now() + 1, name: "name", dataType: "text", options: [], isDefault: true }
//     ]
//   }), []);

//   /* ------------------ HANDLERS ------------------ */

//   const handleGetValues = useCallback((props) => {
//     handleGetFilledValuesOfPlc({
//       fieldProps: props,
//       primaryObject,
//       setFormData,
//       handlePrimaryObjectModifier
//     });
//   }, [primaryObject, handlePrimaryObjectModifier]);

//   const handleAddParameter = useCallback(() => {
//     const newParam = {
//       id: Date.now(),
//       name: "",
//       dataType: "",
//       options: [],
//       isNew: true
//     };

//     setFormData(prev => ({
//       ...prev,
//       parameters: [...(prev.parameters || []), newParam]
//     }));

//     setActiveParamId(newParam.id);
//   }, []);

//   const handleRemoveParameter = useCallback((paramId) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters?.filter(p => p.id !== paramId)
//     }));
//   }, []);

//   const handleUpdateParameterName = useCallback((paramId, value) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId ? { ...p, name: value } : p
//       )
//     }));
//   }, []);

//   const handleUpdateParameterType = useCallback((paramId, option) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId
//           ? { ...p, dataType: option?.value || "", options: [] }
//           : p
//       )
//     }));
//   }, []);

//   const handleAddOption = useCallback((paramId) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId ? { ...p, options: [...p.options, ""] } : p
//       )
//     }));
//   }, []);

//   const handleUpdateOption = useCallback((paramId, index, value) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId
//           ? { ...p, options: p.options.map((o, i) => i === index ? value : o) }
//           : p
//       )
//     }));
//   }, []);

//   const handleRemoveOption = useCallback((paramId, index) => {
//     setFormData(prev => ({
//       ...prev,
//       parameters: prev.parameters.map(p =>
//         p.id === paramId
//           ? { ...p, options: p.options.filter((_, i) => i !== index) }
//           : p
//       )
//     }));
//   }, []);

//   const handleAddDefaultParameters = useCallback(() => {
//     const networkName = formData.type?.name;
//     if (!networkName) return;

//     const defaults = DEFAULT_PARAMETERS_BY_NETWORK[networkName] || [];

//     setFormData(prev => {
//       const existingNames = prev.parameters?.map(p => p.name) || [];
//       const filtered = defaults.filter(d => !existingNames.includes(d.name));
//       return { ...prev, parameters: [...(prev.parameters || []), ...filtered] };
//     });

//     setActiveParamId(null);
//   }, [formData.type, DEFAULT_PARAMETERS_BY_NETWORK]);

//   const handleSubmitController = useCallback(() => {
//     const normalized = {
//       ...formData,
//       parameters: formData.parameters?.map(p => ({ ...p, isNew: false }))
//     };

//     if (mode === "edit") {
//       dispatch(plcActions.updateController(normalized));
//     } else {
//       dispatch(plcActions.setController({ ...normalized, id: Date.now() }));
//     }

//     navigate("/plc");
//   }, [dispatch, formData, mode, navigate]);

//   /* ------------------ EDIT MODE LOAD ------------------ */

//   const editData = useMemo(
//     () => controllerData.find(e => e.id === location.state?.id),
//     [controllerData, location.state]
//   );

//   useEffect(() => {
//     if (editData) setFormData(editData);
//   }, [editData]);

//   /* ------------------ JSX (UNCHANGED) ------------------ */

//   return (
//           <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : " 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto",padding:"1rem" }}>
//       <Box className={classes.header}>
//         <Typography variant="h4">
//                {mode=="edit" ? "Edit Controller" : "Create Controller" }  
//         </Typography>
//       </Box>

//       <div className={classes.card}>
//         <CardContent>
//           <Grid container spacing={3}>
//             <Grid item xs={12} md={4}>
//               <ClonosInput
//                 tabIndex={1}
//                 label="Controller Name"
//                 isLabel={true}
//                 placeholder="Enter controller name"
//                 isMandatory={true}
//                 type="text"
//                 limit="50"
//                 uniqueKey="name"
//                 defaultValue={formData.name}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>

//             <Grid item xs={12} md={4}>
//               <ClonosSelect
//                 tabIndex={2}
//                 type="select"
//                 label="Network"
//                 isMandatory={true}
//                 isLabel={true}
//                 uniqueKey="type"
//                 placeholder="Select Network"
//                 defaultValue={formData?.type?.name}
//                 options={controllerTypeOptions}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>
            
//              <Grid item xs={12} md={4}>
//               <ClonosInput
//                 tabIndex={3}
//                 label="IP Address"
//                 isLabel={true}
//                 placeholder="e.g., 10.100.100.1"
//                 isMandatory={true}
//                 type="text"
//                 limit="15"
//                 uniqueKey="ip"
//                 defaultValue={formData.ip}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>
          
//           </Grid>


// {formData.type?.id && (
//   <Box mt={4}>
//     <Typography variant="subtitle1" color="textSecondary">
//       Protocol Configuration
//     </Typography>
//   </Box>
// )}

//  {/* ---------- Modbus ---------- */}
// {formData.type?.name === "Modbus" && (
//   <Box mt={2}>
//     <Grid container spacing={3}>
//       <Grid item xs={12} md={4}>
//         <ClonosInput
//           tabIndex={4}
//           label="Unit ID"
//           isLabel
//           placeholder="Enter unit ID (1–247)"
//           isMandatory
//           type="number"
//           limit="5"
//           uniqueKey="unitId"
//           defaultValue={formData.unitId}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>
//     </Grid>
//   </Box>
// )}

// {/* ---------- Siemens ---------- */}
// {formData.type?.name === "Siemens" && (
//   <Box mt={2}>
//     <Grid container spacing={3}>
//       <Grid item xs={12} md={4}>
//         <ClonosInput
//           tabIndex={5}
//           label="Slot"
//           isLabel
//           placeholder="Enter Slot"
//           isMandatory
//           type="text"
//           limit="15"
//           uniqueKey="slot"
//           defaultValue={formData.slot}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>

//       <Grid item xs={12} md={4}>
//         <ClonosInput
//           tabIndex={6}
//           label="Rack"
//           isLabel
//           placeholder="Enter rack"
//           isMandatory
//           type="number"
//           limit="5"
//           uniqueKey="rack"
//           defaultValue={formData.rack}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>
//     </Grid>
//   </Box>
// )}

// {formData.type?.name === "Ethernetip" && (
//   <Box mt={2}>
//     <Grid container spacing={3}>
//       <Grid item xs={12} md={4}>
//          <ClonosInput
//           tabIndex={5}
//           label="Slot"
//           isLabel
//           placeholder="Enter Slot"
//           isMandatory
//           type="text"
//           limit="15"
//           uniqueKey="slot"
//           defaultValue={formData.slot}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>

//       <Grid item xs={12} md={4}>
//         <ClonosSelect
//           tabIndex={2}
//           type="select"
//           label="Auto Discover"
//           isMandatory={true}
//           isLabel={true}
//           uniqueKey="autoDiscover"
//           placeholder="Select"
//           defaultValue={formData?.autoDiscover?.name}
//           options={[ { label: 'true', value: 'true', isNeeded: true }, { label: 'false', value: 'false', isNeeded: true },]}
//           handleGetValues={handleGetValues}
//           handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//         />
//       </Grid>
//     </Grid>
//   </Box>
// )}


//           {/* Dynamic Parameters Section */}
         
//  <Box mt={4}>
//       {/* Header */}
//       <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
//         <Typography variant="h6">Parameter Template</Typography>

//         <Box display="flex" gap="8px">
//           <button
//             className={Styles.plc_plain_button}
//             onClick={handleAddDefaultParameters}
//             disabled={!formData.type?.name}
//           >
//             <img src={Plus_Icon} alt="Default" />
//             Default Parameters
//           </button>

//           <button
//             className={Styles.plc_plain_button}
//             disabled={!formData.type?.name}
//             onClick={handleAddParameter}
//           >
//             <img src={Plus_Icon} alt="Add" />
//             Add Parameter
//           </button>
//         </Box>
//       </Box>


//       {/* No parameters yet */}
//       {(!formData.parameters || formData.parameters.length === 0) && (
//         <Box
//           p={3}
//           textAlign="center"
//           border="2px dashed #e0e0e0"
//           borderRadius="4px"
//         >
//           <Typography variant="body2" color="textSecondary">
//             No parameters added yet. Click "Add Parameter" to create a new template row.
//           </Typography>
//         </Box>
//       )}

//     {formData.parameters?.map((param, index) => {
//   const isOpen = activeParamId === param.id;

//   return (
//     <Box
//       key={param.id}
//       mb={2}
//       border="1px solid #e0e0e0"
//       borderRadius="8px"
//     >
//       {/* ================= HEADER ================= */}
//       <Box
//         display="flex"
//         alignItems="center"
//         justifyContent="space-between"
//         px={2}
//         py={1.5}
//         sx={{ cursor: "pointer" }}
//        onClick={() =>
//   setActiveParamId(prev =>
//     prev === param.id ? null : param.id
//   )
// }

//       >
//         {/* LEFT */}
//         <Box display="flex" alignItems="center" sx={{ gap: "12px" }}>
//           <img
//             src={TEMPLATE_CREATION_GRIP_VERTICAL}
//             alt="drag"
//             style={{ opacity: 0.6 }}
//           />

//          {formData.type?.name !== "Ethernetip" && <Typography fontSize="14px" fontWeight={500}>
//             {param.name || "Unnamed Parameter"}
//           </Typography>
//     }
//         </Box>

//         {/* RIGHT */}
//         <Box display="flex" alignItems="center" sx={{ gap: "12px" }}>
//           {/* datatype badge */}
//           {param.dataType && (
//             <Box
//               px={1.5}
//               py={0.5}
//               borderRadius="12px"
//               bgcolor="#e0e0e0"
//               fontSize="12px"
//               fontWeight={500}
//               textTransform="capitalize"
//             >
//               {param.dataType}
//             </Box>
//           )}
//           {/* delete */}
//           <button
//             className={Styles.iconButtonheader}
//             onClick={(e) => {
//               e.stopPropagation(); // 👈 prevent collapse toggle
//               handleRemoveParameter(param.id);
//             }}
//           >
//             <img src={TEMPLATE_CREATION_REMOVEROW} alt="Remove" />
//           </button>
//         </Box>
//       </Box>

//       {/* ================= BODY ================= */}
//       {isOpen && (
//         <Box px={2} pb={2}>

//           <Grid container spacing={3} mt={1}>
//             {/* Parameter Name */}
//             {formData.type?.name !== "Ethernetip" && <Grid item xs={12} md={4}>
//               <ClonosInput
//                 label="Parameter Name"
//                 isLabel
//                 type="text"
//                 placeholder={"Parameter Name"}
//                 uniqueKey={`param-name-${param.id}`}
//                 defaultValue={param.name}
//                 handleGetValues={({ updatedValue }) =>
//                   handleUpdateParameterName(param.id, updatedValue)
//                 }
//                 disabled={mode === "edit" && !param.isNew}
//               />
//             </Grid>
// } 
//             {/* Data Type */}
//             <Grid item xs={12} md={4}>
//               <ClonosSelect
//                 label="Type"
//                 isLabel
//                 uniqueKey={`param-type-${param.id}`}
//                 options={dataTypeOptions}
//                  placeholder={"Select Type"}
//                 defaultValue={param.dataType}
//                 handleGetValues={({ updatedValue }) =>
//                   handleUpdateParameterType(param.id, updatedValue)
//                 }
//                disabled={mode === "edit" && !param.isNew}
//               />
//             </Grid>
//           </Grid>

//           {/* DROPDOWN OPTIONS */}
//           {param.dataType === "dropdown" && (
//             <Box mt={3}>
//               <Box
//                 display="flex"
//                 justifyContent="space-between"
//                 alignItems="center"
//                 mb={2}
//               >
//                 <Typography fontSize="14px" fontWeight={500}>
//                   Dropdown Options
//                 </Typography>

//                 <button
//                   className={Styles.plc_plain_button_option}
//                   onClick={() => handleAddOption(param.id)}
//                 >
//                   <img src={Plus_Icon} alt="Add" />
//                   Add option
//                 </button>
//               </Box>

//               {param.options.map((opt, i) => (
//                 <Grid
//                   container
//                   spacing={2}
//                   alignItems="center"
//                   key={i}
//                   mt={1}
//                 >
//                   <Grid item xs={10}>
//                     <ClonosInput
//                       label={`Option ${i + 1}`}
//                       isLabel
//                       type="text"
//                       defaultValue={opt} 
//                       handleGetValues={({ updatedValue }) => {
//                         console.log(updatedValue);
//                         handleUpdateOption(param.id, i, updatedValue);
//                       }}

//                     />
//                   </Grid>

//                   <Grid item xs={2}>
//                     <button
//                       className={Styles.iconButton}
//                       onClick={() => handleRemoveOption(param.id, i)}
//                     >
//                       <img
//                         src={TEMPLATE_CREATION_REMOVEROW}
//                         alt="Remove option"
//                       />
//                     </button>
//                   </Grid>
//                 </Grid>
//               ))}
//             </Box>
//           )}
//         </Box>
//       )}
//     </Box>
//   );
// })}




//     </Box>

//           {/* Action Buttons */}
//           <Box mt={4} display="flex" justifyContent="flex-end" gap={2} >
//             <ClonosButton variant="outlined" onClick={()=>navigate(-1)}>
//               Cancel
//             </ClonosButton>
//             &nbsp;
//             <ClonosButton variant="filled" onClick={handleSubmitController}>
//                  {mode=="edit" ? "Update" : "Submit" }  
//             </ClonosButton>
//           </Box>
//         </CardContent>
//       </div>
//     </Card>
//   );
// };

// export default Controller;






import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import ClonosInput from '../../../../CommonComponents/ClonosInput/ClonosInput';
import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
import { ClonosButton } from '../../../../CommonComponents/Button/Button';
import { handleCreateController, handleEditController, handleGetFilledValuesOfPlc, handleGetSingleControllers } from '../plc-manager';
import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
import Styles from '../../plc.module.css';
import Plus_Icon from '../../../../../assets/UIUX/icons/WO/WO_Plus.svg';
import TEMPLATE_CREATION_REMOVEROW from "../../../../../assets/UIUX/icons/Checklist/circle-minus.svg";
import TEMPLATE_CREATION_GRIP_VERTICAL from "../../../../../assets/UIUX/icons/Checklist/grip-vertical.svg";
import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { handleShowErrorAndWarning } from '../../../../../utils/clonosCommon';
import { v4 as uuidv4 } from "uuid";

const useStyles = makeStyles((theme) => ({
  root: { padding: theme.spacing(3) },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing(3),
  },
  card: { marginBottom: theme.spacing(3) }
}));

const Controller = ({ mode }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const Location = useLocation();

  const controllerData = useSelector(store => store.plcData.controller);

  const [formData, setFormData] = useState({});
  const [activeParamId, setActiveParamId] = useState(null);

  const {
    handleGetErrorActivatorInformation,
    handlePrimaryObjectModifier,
    primaryObject
  } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "Plc" });

  /* ------------------ MEMOIZED CONSTANTS ------------------ */

  const dataTypeOptions = useMemo(() => ([
    { label: 'Text', value: 'text', isNeeded: true },
    { label: 'Number', value: 'number', isNeeded: true }
  ]), []);

  const controllerTypeOptions = useMemo(() => ([
    { label: 'Modbus', value: 'modbus', isNeeded: true },
    { label: 'Siemens', value: 'siemens', isNeeded: true },
    // { label: 'Ethernetip', value: 'ethernetip', isNeeded: true }
  ]), []);

  const DEFAULT_PARAMETERS_BY_NETWORK = useMemo(() => ({
    Modbus: [
      { _id: uuidv4(), name: "name", dataType: "text", isDefault: true },
      { _id: uuidv4(), name: "db", dataType: "number",  isDefault: true },
      { _id: uuidv4(), name: "offset", dataType: "number",  isDefault: true },
      { _id: uuidv4(),name: "type", dataType: "text", isDefault: true },
      { _id: uuidv4(), name: "unit", dataType: "text", isDefault: true }
    ],
    Siemens: [
      { _id: uuidv4(), name: "name", dataType: "text",  isDefault: true },
      { _id: uuidv4(), name: "port", dataType: "number", isDefault: true },
      { _id: uuidv4(), name: "address", dataType: "number", isDefault: true },
      { _id: uuidv4(), name: "type", dataType: "text",  isDefault: true },
      { _id: uuidv4(), name: "unit", dataType: "text", isDefault: true }
    ],
    Ethernetip: [
      { _id: uuidv4(), dataType: "text",  isDefault: true }
    ]
  }), []);


  const [loadersAndFlags,setLoadersAndFlags] = useState({
          saveControllerLoading:false,
          getControllerLoading:false,
          editControllerLoading:false
      })

  /* ------------------ HANDLERS ------------------ */

  const handleGetValues = useCallback((props) => {
    handleGetFilledValuesOfPlc({
      fieldProps: props,
      primaryObject,
      setFormData,
      handlePrimaryObjectModifier
    });
  }, [primaryObject, handlePrimaryObjectModifier]);

  // const handleAddParameter = useCallback(() => {
    
  //   const isEthernetIP = formData?.network?.name === "Ethernetip";

  //   const newParam = isEthernetIP
  //     ? {
  //         _id: uuidv4(),
  //         dataType: "",
  //         isNew: true
  //       }
  //     : {
  //         _id: uuidv4(),
  //         name: "",
  //         dataType: "",
  //         isNew: true
  //       };

  //   setFormData(prev => ({
  //     ...prev,
  //     parameters: [...(prev.parameters || []), newParam]
  //   }));

  //   setActiveParamId(newParam._id);
  // }, []);

  const handleAddParameter = useCallback(() => {
  setFormData(prev => {
    const isEthernetIP = prev?.network?.name === "Ethernetip";

    const newParam = isEthernetIP
      ? {
          _id: uuidv4(),
          dataType: "",
          isNew: true
        }
      : {
          _id: uuidv4(),
          name: "",
          dataType: "",
          isNew: true
        };

    setActiveParamId(newParam._id);

    return {
      ...prev,
      parameters: [...(prev.parameters || []), newParam]
    };
  });
}, []);


  const handleRemoveParameter = useCallback((paramId) => {
    setFormData(prev => ({
      ...prev,
      parameters: prev.parameters?.filter(p => p._id !== paramId)
    }));
  }, []);

  const handleUpdateParameterName = useCallback((paramId, value) => {
    setFormData(prev => ({
      ...prev,
      parameters: prev.parameters.map(p =>
        p._id === paramId ? { ...p, name: value } : p
      )
    }));
  }, []);

  const handleUpdateParameterType = useCallback((paramId, option) => {
    setFormData(prev => ({
      ...prev,
      parameters: prev.parameters.map(p =>
        p._id === paramId
          ? { ...p, dataType: option?.value || "", options: [] }
          : p
      )
    }));
  }, []);

  const handleAddOption = useCallback((paramId) => {
    setFormData(prev => ({
      ...prev,
      parameters: prev.parameters.map(p =>
        p._id === paramId ? { ...p, options: [...p.options, ""] } : p
      )
    }));
  }, []);

  const handleUpdateOption = useCallback((paramId, index, value) => {
    setFormData(prev => ({
      ...prev,
      parameters: prev.parameters.map(p =>
        p._id === paramId
          ? { ...p, options: p.options.map((o, i) => i === index ? value : o) }
          : p
      )
    }));
  }, []);

  const handleRemoveOption = useCallback((paramId, index) => {

  
    setFormData(prev => ({
      ...prev,
      parameters: prev.parameters.map(p =>
        p._id === paramId
          ? { ...p, options: p.options.filter((_, i) => i !== index) }
          : p
      )
    }));
  }, []);

  const handleAddDefaultParameters = useCallback(() => {
    const networkName = formData.network?.name;
    if (!networkName) return;

    const defaults = DEFAULT_PARAMETERS_BY_NETWORK[networkName] || [];

    setFormData(prev => {
      const existingNames = prev.parameters?.map(p => p.name) || [];
      const filtered = defaults.filter(d => !existingNames.includes(d.name));
      return { ...prev, parameters: [...(prev.parameters || []), ...filtered] };
    });

    setActiveParamId(null);
  }, [formData.network, DEFAULT_PARAMETERS_BY_NETWORK]);




  const handleSubmitController = useCallback(() => {
    const normalized = {
      ...formData,
      parameters: formData.parameters?.map(p => ({ ...p, isNew: false }))
    };
     
     const next = () => {
          navigate("/plc");
          handleShowErrorAndWarning({dispatch,message:` Controller ${mode === "create"? "created" : "updated"} successfully.`,type:"success",showTime:"5000"})
      }
    
    if (mode === "edit") {
      handleEditController({dispatch,payload:formData,controllerId:Location?.state?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,editControllerLoading:!prev.editControllerLoading})),next})
      // dispatch(plcActions.updateController(normalized));
    } else {
       handleCreateController({dispatch,payload:formData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveControllerLoading:!prev.saveControllerLoading})),next})
      
      // dispatch(plcActions.setController({ ...normalized, id: Date.now() }));
    }

  }, [dispatch, formData, mode, navigate]);

  /* ------------------ EDIT MODE LOAD ------------------ */

  // const editData = useMemo(
  //   () => controllerData.find(e => e.id === location.state?.id),
  //   [controllerData, location.state]
  // );


useEffect(()=>{

  if(mode=="edit"){
     handleGetSingleControllers({setterMethod:setFormData,controllerId: Location?.state?.id ,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,getControllerLoading:!prev.getControllerLoading}))})
  }

  },[mode,Location?.state?.id])

  /* ------------------ JSX (UNCHANGED) ------------------ */

  return (
          <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : " 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto",padding:"1rem" }}>
      <Box className={classes.header}>
        <Typography variant="h4">
               {mode=="edit" ? "Edit Controller" : "Create Controller" }  
        </Typography>
      </Box>

      <div className={classes.card}>
        <CardContent>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <ClonosInput
                tabIndex={1}
                label="Controller Name"
                isLabel={true}
                placeholder="Enter controller name"
                isMandatory={true}
                type="text"
                limit="50"
                uniqueKey="controllerName"
                defaultValue={formData.controllerName}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </Grid>

            <Grid item xs={12} md={4}>
              <ClonosSelect
                tabIndex={2}
                type="select"
                label="Network"
                isMandatory={true}
                isLabel={true}
                uniqueKey="network"
                placeholder="Select Network"
                defaultValue={formData?.network?.name}
                options={controllerTypeOptions}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                 disabled={mode== "edit" ?true:false}
              />
            </Grid>
            
             <Grid item xs={12} md={4}>
              <ClonosInput
                tabIndex={3}
                label="IP Address"
                isLabel={true}
                placeholder="e.g., 10.100.100.1"
                isMandatory={true}
                type="text"
                limit="15"
                uniqueKey="ipAddress"
                defaultValue={formData.ipAddress}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </Grid>
          
          </Grid>


{formData.network?.id && (
  <Box mt={4}>
    <Typography variant="subtitle1" color="textSecondary">
      Protocol Configuration
    </Typography>
  </Box>
)}

 {/* ---------- Modbus ---------- */}
{formData.network?.name === "Modbus" && (
  <Box mt={2}>
    <Grid container spacing={3}>
      <Grid item xs={12} md={4}>
        <ClonosInput
          tabIndex={4}
          label="Unit ID"
          isLabel
          placeholder="Enter unit ID (1–247)"
          isMandatory
          type="number"
          limit="5"
          uniqueKey="unitId"
          defaultValue={formData?.settings?.unitId}
          handleGetValues={handleGetValues}
          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
           disabled={mode== "edit" ?true:false}
        />
      </Grid>
    </Grid>
  </Box>
)}

{/* ---------- Siemens ---------- */}
{formData.network?.name === "Siemens" && (
  <Box mt={2}>
    <Grid container spacing={3}>
      <Grid item xs={12} md={4}>
        <ClonosInput
          tabIndex={5}
          label="Slot"
          isLabel
          placeholder="Enter Slot"
          isMandatory
          type="text"
          limit="15"
          uniqueKey="slot"
          defaultValue={formData?.settings?.slot}
          handleGetValues={handleGetValues}
          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
           disabled={mode== "edit" ?true:false}
        />
      </Grid>

      <Grid item xs={12} md={4}>
        <ClonosInput
          tabIndex={6}
          label="Rack"
          isLabel
          placeholder="Enter rack"
          isMandatory
          type="number"
          limit="5"
          uniqueKey="rack"
          defaultValue={formData?.settings?.rack}
          handleGetValues={handleGetValues}
          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
           disabled={mode== "edit" ?true:false}
        />
      </Grid>
    </Grid>
  </Box>
)}

{formData.network?.name === "Ethernetip" && (
  <Box mt={2}>
    <Grid container spacing={3}>
      <Grid item xs={12} md={4}>
         <ClonosInput
          tabIndex={5}
          label="Slot"
          isLabel
          placeholder="Enter Slot"
          isMandatory
          type="text"
          limit="15"
          uniqueKey="slot"
          defaultValue={formData?.settings?.slot}
          handleGetValues={handleGetValues}
          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
           disabled={mode== "edit" ?true:false}
        />
      </Grid>

      <Grid item xs={12} md={4}>
        <ClonosSelect
          tabIndex={2}
          type="select"
          label="Auto Discover"
          isMandatory={true}
          isLabel={true}
          uniqueKey="autoDiscover"
          placeholder="Select"
          defaultValue={formData?.settings?.autoDiscover?.name}
          options={[ { label: 'true', value: 'true', isNeeded: true }, { label: 'false', value: 'false', isNeeded: true },]}
          handleGetValues={handleGetValues}
          handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
          disabled={mode== "edit" ?true:false}
        />
      </Grid>
    </Grid>
  </Box>
)}


          {/* Dynamic Parameters Section */}
         
 <Box mt={4}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h6">Parameter Template</Typography>

        <Box display="flex" gap="8px">
          <button
            className={Styles.plc_plain_button}
            onClick={handleAddDefaultParameters}
            disabled={!formData.network?.name}
          >
            <img src={Plus_Icon} alt="Default" />
            Default Parameters
          </button>

          <button
            className={Styles.plc_plain_button}
            disabled={!formData.network?.name}
            onClick={handleAddParameter}
          >
            <img src={Plus_Icon} alt="Add" />
            Add Parameter
          </button>
        </Box>
      </Box>


      {/* No parameters yet */}
      {(!formData.parameters || formData.parameters.length === 0) && (
        <Box
          p={3}
          textAlign="center"
          border="2px dashed #e0e0e0"
          borderRadius="4px"
        >
          <Typography variant="body2" color="textSecondary">
            No parameters added yet. Click "Add Parameter" to create a new template row.
          </Typography>
        </Box>
      )}

    {formData.parameters?.map((param, index) => {
  const isOpen = activeParamId === param._id;

  return (
    <Box
      key={param._id}
      mb={2}
      border="1px solid #e0e0e0"
      borderRadius="8px"
    >
      {/* ================= HEADER ================= */}
      <Box
        display="flex"
        alignItems="center"
        justifyContent="space-between"
        px={2}
        py={1.5}
        sx={{ cursor: "pointer" }}
       onClick={() =>
      setActiveParamId(prev =>
        prev === param._id ? null : param._id
      )
    }

      >
        {/* LEFT */}
        <Box display="flex" alignItems="center" sx={{ gap: "12px" }}>
          <img
            src={TEMPLATE_CREATION_GRIP_VERTICAL}
            alt="drag"
            style={{ opacity: 0.6 }}
          />

         {formData.network?.name !== "Ethernetip" && <Typography fontSize="14px" fontWeight={500}>
            {param.name || "Unnamed Parameter"}
          </Typography>
    }
        </Box>

        {/* RIGHT */}
        <Box display="flex" alignItems="center" sx={{ gap: "12px" }}>
          {/* datatype badge */}
          {param.dataType && (
            <Box
              px={1.5}
              py={0.5}
              borderRadius="12px"
              bgcolor="#e0e0e0"
              fontSize="12px"
              fontWeight={500}
              textTransform="capitalize"
            >
              {param.dataType}
            </Box>
          )}
          {/* delete */}
          <button
            className={Styles.iconButtonheader}
            onClick={(e) => {
              e.stopPropagation(); 
              handleRemoveParameter(param._id);
            }}
          >
            <img src={TEMPLATE_CREATION_REMOVEROW} alt="Remove" />
          </button>
        </Box>
      </Box>

      {/* ================= BODY ================= */}
      {isOpen && (
        <Box px={2} pb={2}>

          <Grid container spacing={3} mt={1}>
            {/* Parameter Name */}
            {formData.network?.name !== "Ethernetip" && <Grid item xs={12} md={4}>
              <ClonosInput
                label="Parameter Name"
                isLabel
                type="text"
                placeholder={"Parameter Name"}
                uniqueKey={`param-name-${param._id}`}
                defaultValue={param.name}
                handleGetValues={({ updatedValue }) =>
                  handleUpdateParameterName(param._id, updatedValue)
                }
                disabled={mode === "edit" && !param.isNew}
              />
            </Grid>
} 
            {/* Data Type */}
            <Grid item xs={12} md={4}>
              <ClonosSelect
                label="Type"
                isLabel
                uniqueKey={`param-type-${param._id}`}
                options={dataTypeOptions}
                 placeholder={"Select Type"}
                defaultValue={param.dataType}
                handleGetValues={({ updatedValue }) =>
                  handleUpdateParameterType(param._id, updatedValue)
                }
               disabled={mode === "edit" && !param.isNew}
              />
            </Grid>
          </Grid>

          {/* DROPDOWN OPTIONS */}
          {param.dataType === "dropdown" && (
            <Box mt={3}>
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                mb={2}
              >
                <Typography fontSize="14px" fontWeight={500}>
                  Dropdown Options
                </Typography>

                <button
                  className={Styles.plc_plain_button_option}
                  onClick={() => handleAddOption(param._id)}
                >
                  <img src={Plus_Icon} alt="Add" />
                  Add option
                </button>
              </Box>

              {param.options.map((opt, i) => (
                <Grid
                  container
                  spacing={2}
                  alignItems="center"
                  key={i}
                  mt={1}
                >
                  <Grid item xs={10}>
                    <ClonosInput
                      label={`Option ${i + 1}`}
                      isLabel
                      type="text"
                      defaultValue={opt} 
                      handleGetValues={({ updatedValue }) => {
                        
                        handleUpdateOption(param._id, i, updatedValue);
                      }}

                    />
                  </Grid>

                  <Grid item xs={2}>
                    <button
                      className={Styles.iconButton}
                      onClick={() => handleRemoveOption(param._id, i)}
                    >
                      <img
                        src={TEMPLATE_CREATION_REMOVEROW}
                        alt="Remove option"
                      />
                    </button>
                  </Grid>
                </Grid>
              ))}
            </Box>
          )}
        </Box>
      )}
    </Box>
  );
})}




    </Box>

          {/* Action Buttons */}
          <Box mt={4} display="flex" justifyContent="flex-end" gap={2} >
            <ClonosButton variant="outlined" onClick={()=>navigate(-1)}>
              Cancel
            </ClonosButton>
            &nbsp;
            <ClonosButton variant="filled" onClick={handleSubmitController}>
                 {mode=="edit" ? "Update" : "Submit" }  
            </ClonosButton>
          </Box>
        </CardContent>
      </div>
    </Card>
  );
};

export default Controller;














































