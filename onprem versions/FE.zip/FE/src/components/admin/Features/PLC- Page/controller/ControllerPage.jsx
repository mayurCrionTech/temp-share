// import React, { useState } from 'react';
// import { Box, Typography, Button, Grid, Card, CardContent } from '@material-ui/core';
// import AddIcon from '@material-ui/icons/Add';
// import { useSelector } from 'react-redux';
// import Controller from './Controller'; // your existing component
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';

// const ControllersPage = () => {
//   const controllerData = useSelector(store => store.plcData.controller);

//   // State to toggle showing the creation form
//   const [showCreateForm, setShowCreateForm] = useState(false);

//   // Convert controllerData to array if needed
//   const controllersArray = controllerData ? [controllerData] : [];

//   return (
//     <Box p={4} bgcolor="#ffffff" minHeight="100vh">
//       <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
//         <Typography variant="h4">Controllers</Typography>
//         <ClonosButton variant="filled"   onClick={() => setShowCreateForm(true)}  >
//                      <AddIcon />  New Controller
//           </ClonosButton>
//       </Box>

//       <Typography variant="subtitle1" color="textSecondary" mb={3}>
//         Define controller frameworks with custom parameters
//       </Typography>

//       {/* Show Controller form */}
//       {showCreateForm ? (
//         <Controller />
//       ) : (
//         <>
//           {controllersArray.length === 0 ? (
//             <Card variant="outlined" style={{ padding: '2rem', textAlign: 'center' }}>
//               <CardContent>
//                 <Typography variant="h6" gutterBottom>No controllers yet</Typography>
//                 <Typography variant="body2" color="textSecondary" gutterBottom>
//                   Create your first controller to define parameters for your tags
//                 </Typography>
//                 <Button
//                   variant="contained"
//                   color="primary"
//                   startIcon={<AddIcon />}
//                   onClick={() => setShowCreateForm(true)}
//                 >
//                   Create Controller
//                 </Button>
//               </CardContent>
//             </Card>
//           ) : (
//             <Grid container spacing={3}>
//               {controllersArray.map((ctrl, index) => (
//                 <Grid item xs={12} md={4} key={index}>
//                   <Card variant="outlined" style={{ padding: '1rem' }}>
//                     <CardContent>
//                       <Typography variant="h6">{ctrl.name}</Typography>
//                       <Typography variant="body2" color="textSecondary">
//                         {ctrl.description || 'No description'}
//                       </Typography>
//                       <Typography variant="body2">
//                         <strong>{ctrl.parameters?.length || 0}</strong> parameters
//                       </Typography>
//                       <Typography variant="body2">
//                         <strong>{ctrl.tags?.length || 0}</strong> tags
//                       </Typography>
//                     </CardContent>
//                   </Card>
//                 </Grid>
//               ))}
//             </Grid>
//           )}
//         </>
//       )}
//     </Box>
//   );
// };

// export default ControllersPage;


// import React, { useState } from 'react';
// import {
//   Box,
//   Typography,
//   Button,
//   Grid,
//   Card,
//   CardContent,
//   TextField,
//   InputAdornment,
//   Chip,
//   IconButton,
// } from '@mui/material';
// import AddIcon from '@mui/icons-material/Add';
// import SearchIcon from '@mui/icons-material/Search';
// import SettingsIcon from '@mui/icons-material/Settings';
// import { useSelector } from 'react-redux';
// import Controller from './Controller';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';

// const ControllersPage = () => {
//   const controllerData = useSelector(store => store.plcData.controller);
//   const [showCreateForm, setShowCreateForm] = useState(false);
//   const [searchQuery, setSearchQuery] = useState('');

//   // Convert controllerData to array if needed
//   const controllersArray = controllerData ? [controllerData] : [];

//   // Filter controllers based on search query
//   const filteredControllers = controllersArray.filter(ctrl =>
//     ctrl.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
//     ctrl.description?.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   return (
//     <Box sx={{ p: 4, bgcolor: '#f5f7fa', minHeight: '100vh' }}>
//       {/* Header */}
//       <Box
//         sx={{
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           mb: 1,
//         }}
//       >
//         <Box>
//           <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
//             Controllers
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280' }}>
//             Define controller frameworks with custom parameters
//           </Typography>
//         </Box>
//         <ClonosButton
//           variant="filled"
//           onClick={() => setShowCreateForm(true)}
//           startIcon={<AddIcon />}
//         >
//           New Controller
//         </ClonosButton>
//       </Box>

//       {/* Show Controller form when creating */}
//       {showCreateForm ? (
//         <Box sx={{ mt: 3 }}>
//           <Controller />
//         </Box>
//       ) : (
//         <>
//           {controllersArray.length === 0 ? (
//             // Empty State
//             <Box
//               sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//               }}
//             >
//               <Box
//                 sx={{
//                   width: 80,
//                   height: 80,
//                   borderRadius: '50%',
//                   bgcolor: '#374151',
//                   display: 'flex',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   mb: 3,
//                 }}
//               >
//                 <SettingsIcon sx={{ fontSize: 40, color: '#6b7280' }} />
//               </Box>
//               <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 No controllers yet
//               </Typography>
//               <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                 Create your first controller to define parameters for your tags
//               </Typography>
//               <Button
//                 variant="contained"
//                 startIcon={<AddIcon />}
//                 onClick={() => setShowCreateForm(true)}
//                 sx={{
//                   bgcolor: '#06b6d4',
//                   color: '#fff',
//                   textTransform: 'none',
//                   px: 3,
//                   py: 1,
//                   borderRadius: 2,
//                   fontWeight: 500,
//                   '&:hover': {
//                     bgcolor: '#0891b2',
//                   },
//                 }}
//               >
//                 Create Controller
//               </Button>
//             </Box>
//           ) : (
//             <>
//               {/* Search Bar */}
//               <Box sx={{ mt: 3, mb: 3 }}>
//                 <TextField
//                   fullWidth
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: '#9ca3af' }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     maxWidth: 560,
//                     bgcolor: '#ffffff',
//                     borderRadius: 2,
//                     '& .MuiOutlinedInput-root': {
//                       borderRadius: 2,
//                       '& fieldset': {
//                         borderColor: '#e5e7eb',
//                       },
//                       '&:hover fieldset': {
//                         borderColor: '#d1d5db',
//                       },
//                       '&.Mui-focused fieldset': {
//                         borderColor: '#06b6d4',
//                       },
//                     },
//                     '& .MuiOutlinedInput-input': {
//                       py: 1.5,
//                       color: '#1a1a1a',
//                       '&::placeholder': {
//                         color: '#9ca3af',
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />
//               </Box>

//               {/* Controllers Grid */}
//               <Grid container spacing={3}>
//                 {filteredControllers.map((ctrl, index) => (
//                   <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
//                     <Card
//                       sx={{
//                         bgcolor: '#1f2937',
//                         borderRadius: 3,
//                         border: '1px solid #374151',
//                         transition: 'all 0.2s',
//                         cursor: 'pointer',
//                         '&:hover': {
//                           transform: 'translateY(-2px)',
//                           boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
//                         },
//                       }}
//                     >
//                       <CardContent sx={{ p: 3 }}>
//                         <Typography
//                           variant="h6"
//                           sx={{
//                             fontWeight: 600,
//                             mb: 1,
//                             color: '#f9fafb',
//                           }}
//                         >
//                           {ctrl.name || 'Unnamed Controller'}
//                         </Typography>
//                         <Typography
//                           variant="body2"
//                           sx={{
//                             color: '#9ca3af',
//                             mb: 2,
//                             minHeight: 40,
//                           }}
//                         >
//                           {ctrl.description || 'No description'}
//                         </Typography>
//                         <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
//                           <Chip
//                             label={`${ctrl.parameters?.length || 0} parameters`}
//                             size="small"
//                             sx={{
//                               bgcolor: 'transparent',
//                               color: '#06b6d4',
//                               border: '1px solid #06b6d4',
//                               fontSize: '0.75rem',
//                             }}
//                           />
//                           <Chip
//                             label={`${ctrl.tags?.length || 0} tags`}
//                             size="small"
//                             icon={
//                               <Box
//                                 component="span"
//                                 sx={{
//                                   width: 6,
//                                   height: 6,
//                                   bgcolor: '#6b7280',
//                                   borderRadius: '50%',
//                                   ml: 1,
//                                 }}
//                               />
//                             }
//                             sx={{
//                               bgcolor: 'transparent',
//                               color: '#9ca3af',
//                               fontSize: '0.75rem',
//                               '& .MuiChip-icon': {
//                                 ml: 1,
//                               },
//                             }}
//                           />
//                         </Box>
//                         {ctrl.tags && ctrl.tags.length > 0 && (
//                           <Box sx={{ mt: 2 }}>
//                             <Chip
//                               label="needs"
//                               size="small"
//                               sx={{
//                                 bgcolor: '#374151',
//                                 color: '#9ca3af',
//                                 fontSize: '0.7rem',
//                                 height: 20,
//                               }}
//                             />
//                           </Box>
//                         )}
//                       </CardContent>
//                     </Card>
//                   </Grid>
//                 ))}
//               </Grid>

//               {/* No Results */}
//               {filteredControllers.length === 0 && searchQuery && (
//                 <Box sx={{ textAlign: 'center', py: 8 }}>
//                   <Typography variant="body1" sx={{ color: '#6b7280' }}>
//                     No controllers found matching "{searchQuery}"
//                   </Typography>
//                 </Box>
//               )}
//             </>
//           )}
//         </>
//       )}
//     </Box>
//   );
// };

// export default ControllersPage;


// import React, { useState } from 'react';
// import {
//   Box,
//   Typography,
//   Button,
//   Grid,
//   Card,
//   CardContent,
//   TextField,
//   InputAdornment,
//   Chip,
//   IconButton,
// } from '@mui/material';
// import AddIcon from '@mui/icons-material/Add';
// import SearchIcon from '@mui/icons-material/Search';
// import SettingsIcon from '@mui/icons-material/Settings';
// import { useSelector } from 'react-redux';
// import Controller from './Controller';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';

// const ControllersPage = () => {
//   const controllerData = useSelector(store => store.plcData.controller);
//   const [showCreateForm, setShowCreateForm] = useState(false);
//   const [searchQuery, setSearchQuery] = useState('');

//   // Convert controllerData to array if needed
//   const controllersArray = controllerData ? [controllerData] : [];

//   // Filter controllers based on search query
//   const filteredControllers = controllersArray.filter(ctrl =>
//     ctrl.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
//     ctrl.description?.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   return (
//     <Box sx={{ p: 4, bgcolor: '#ffffff', minHeight: '100vh' }}>
//       {/* Header */}
//       <Box
//         sx={{
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           mb: 1,
//         }}
//       >
//         <Box>
//           <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
//             Controllers
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280' }}>
//             Define controller frameworks with custom parameters
//           </Typography>
//         </Box>
//         <ClonosButton
//           variant="filled"
//           onClick={() => setShowCreateForm(true)}
//           startIcon={<AddIcon />}
//         >
//           New Controller
//         </ClonosButton>
//       </Box>

//       {/* Show Controller form when creating */}
//       {showCreateForm ? (
//         <Box sx={{ mt: 3 }}>
//           <Controller />
//         </Box>
//       ) : (
//         <>
//           {controllersArray.length === 0 ? (
//             // Empty State
//             <Box
//               sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//               }}
//             >
//               <Box
//                 sx={{
//                   width: 80,
//                   height: 80,
//                   borderRadius: '50%',
//                   bgcolor: '#e5e7eb',
//                   display: 'flex',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   mb: 3,
//                 }}
//               >
//                 <SettingsIcon sx={{ fontSize: 40, color: '#9ca3af' }} />
//               </Box>
//               <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 No controllers yet
//               </Typography>
//               <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                 Create your first controller to define parameters for your tags
//               </Typography>
//               <Button
//                 variant="contained"
//                 startIcon={<AddIcon />}
//                 onClick={() => setShowCreateForm(true)}
//                 sx={{
//                   bgcolor: '#22d3ee',
//                   color: '#1a1a1a',
//                   textTransform: 'none',
//                   px: 3,
//                   py: 1.2,
//                   borderRadius: 2,
//                   fontWeight: 500,
//                   boxShadow: 'none',
//                   '&:hover': {
//                     bgcolor: '#06b6d4',
//                     boxShadow: 'none',
//                   },
//                 }}
//               >
//                 Create Controller
//               </Button>
//             </Box>
//           ) : (
//             <>
//               {/* Search Bar */}
//               <Box sx={{ mt: 3, mb: 3 }}>
//                 <TextField
//                   fullWidth
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: '#9ca3af' }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     maxWidth: 560,
//                     bgcolor: '#ffffff',
//                     borderRadius: 2,
//                     '& .MuiOutlinedInput-root': {
//                       borderRadius: 2,
//                       '& fieldset': {
//                         borderColor: '#e5e7eb',
//                       },
//                       '&:hover fieldset': {
//                         borderColor: '#d1d5db',
//                       },
//                       '&.Mui-focused fieldset': {
//                         borderColor: '#06b6d4',
//                       },
//                     },
//                     '& .MuiOutlinedInput-input': {
//                       py: 1.5,
//                       color: '#1a1a1a',
//                       '&::placeholder': {
//                         color: '#9ca3af',
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />
//               </Box>

//               {/* Controllers Grid */}
//               <Grid container spacing={3}>
//                 {filteredControllers.map((ctrl, index) => (
//                   <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
//                     <Card
//                       sx={{
//                         bgcolor: '#ffffff',
//                         borderRadius: 3,
//                         border: '1px solid #e5e7eb',
//                         transition: 'all 0.2s',
//                         cursor: 'pointer',
//                         boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
//                         '&:hover': {
//                           transform: 'translateY(-2px)',
//                           boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
//                           borderColor: '#d1d5db',
//                         },
//                       }}
//                     >
//                       <CardContent sx={{ p: 3 }}>
//                         <Typography
//                           variant="h6"
//                           sx={{
//                             fontWeight: 600,
//                             mb: 1,
//                             color: '#1a1a1a',
//                           }}
//                         >
//                           {ctrl.name || 'Unnamed Controller'}
//                         </Typography>
//                         <Typography
//                           variant="body2"
//                           sx={{
//                             color: '#6b7280',
//                             mb: 2,
//                             minHeight: 40,
//                           }}
//                         >
//                           {ctrl.description || 'No description'}
//                         </Typography>
//                         <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
//                           <Chip
//                             label={`${ctrl.parameters?.length || 0} parameters`}
//                             size="small"
//                             sx={{
//                               bgcolor: 'transparent',
//                               color: '#22d3ee',
//                               border: '1px solid #22d3ee',
//                               fontSize: '0.75rem',
//                             }}
//                           />
//                           <Chip
//                             label={`${ctrl.tags?.length || 0} tags`}
//                             size="small"
//                             icon={
//                               <Box
//                                 component="span"
//                                 sx={{
//                                   width: 6,
//                                   height: 6,
//                                   bgcolor: '#9ca3af',
//                                   borderRadius: '50%',
//                                   ml: 1,
//                                 }}
//                               />
//                             }
//                             sx={{
//                               bgcolor: 'transparent',
//                               color: '#6b7280',
//                               fontSize: '0.75rem',
//                               '& .MuiChip-icon': {
//                                 ml: 1,
//                               },
//                             }}
//                           />
//                         </Box>
//                         {ctrl.tags && ctrl.tags.length > 0 && (
//                           <Box sx={{ mt: 2 }}>
//                             <Chip
//                               label="needs"
//                               size="small"
//                               sx={{
//                                 bgcolor: '#f3f4f6',
//                                 color: '#6b7280',
//                                 fontSize: '0.7rem',
//                                 height: 20,
//                               }}
//                             />
//                           </Box>
//                         )}
//                       </CardContent>
//                     </Card>
//                   </Grid>
//                 ))}
//               </Grid>

//               {/* No Results */}
//               {filteredControllers.length === 0 && searchQuery && (
//                 <Box sx={{ textAlign: 'center', py: 8 }}>
//                   <Typography variant="body1" sx={{ color: '#6b7280' }}>
//                     No controllers found matching "{searchQuery}"
//                   </Typography>
//                 </Box>
//               )}
//             </>
//           )}
//         </>
//       )}
//     </Box>
//   );
// };

// export default ControllersPage;

// import React, { useState } from 'react';
// import {
//   Box,
//   Typography,
//   Button,
//   Grid,
//   Card,
//   CardContent,
//   TextField,
//   InputAdornment,
//   Chip,
//   IconButton,
// } from '@mui/material';
// import AddIcon from '@mui/icons-material/Add';
// import SearchIcon from '@mui/icons-material/Search';
// import SettingsIcon from '@mui/icons-material/Settings';
// import { useSelector } from 'react-redux';
// import Controller from './Controller';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';

// const ControllersPage = () => {
//   const controllerData = useSelector(store => store.plcData.controller);
//   const [showCreateForm, setShowCreateForm] = useState(false);
//   const [searchQuery, setSearchQuery] = useState('');

//   // Convert controllerData to array if needed
//   const controllersArray = controllerData ? [controllerData] : [];
//   console.log(controllersArray,"controllersArray")
//   // Filter controllers based on search query
//   const filteredControllers = controllersArray.filter(ctrl =>
//     ctrl.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
//     ctrl.description?.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   return (
//     <Box sx={{ p: 4, bgcolor: '#ffffff', minHeight: '100vh' }}>
//       {/* Header */}
//       <Box
//         sx={{
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           mb: 1,
//         }}
//       >
//         <Box>
//           <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
//             Controllers
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280' }}>
//             Define controller frameworks with custom parameters
//           </Typography>
//         </Box>
//         <ClonosButton
//           variant="filled"
//           onClick={() => setShowCreateForm(true)}
//           startIcon={<AddIcon />}
//         >
//           New Controller
//         </ClonosButton>
//       </Box>

//       {/* Show Controller form when creating */}
//       {showCreateForm ? (
//         <Box sx={{ mt: 3 }}>
//           <Controller />
//         </Box>
//       ) : (
//         <>
//           {controllersArray.length === 0 ? (
//             // Empty State - No Search Bar
//             <Box
//               sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//               }}
//             >
//               <Box
//                 sx={{
//                   width: 80,
//                   height: 80,
//                   borderRadius: '50%',
//                   bgcolor: '#e5e7eb',
//                   display: 'flex',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   mb: 3,
//                 }}
//               >
//                 <SettingsIcon sx={{ fontSize: 40, color: '#9ca3af' }} />
//               </Box>
//               <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 No controllers yet
//               </Typography>
//               <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                 Create your first controller to define parameters for your tags
//               </Typography>
//               <Button
//                 variant="contained"
//                 startIcon={<AddIcon />}
//                 onClick={() => setShowCreateForm(true)}
//                 sx={{
//                   bgcolor: '#22d3ee',
//                   color: '#1a1a1a',
//                   textTransform: 'none',
//                   px: 3,
//                   py: 1.2,
//                   borderRadius: 2,
//                   fontWeight: 500,
//                   boxShadow: 'none',
//                   '&:hover': {
//                     bgcolor: '#06b6d4',
//                     boxShadow: 'none',
//                   },
//                 }}
//               >
//                 Create Controller
//               </Button>
//             </Box>
//           ) : (
//             <>
//               {/* Search Bar - Only show when controllers exist */}
//               <Box sx={{ mt: 3, mb: 3 }}>
//                 <TextField
//                   fullWidth
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: '#9ca3af' }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     maxWidth: 560,
//                     bgcolor: '#ffffff',
//                     borderRadius: 2,
//                     '& .MuiOutlinedInput-root': {
//                       borderRadius: 2,
//                       '& fieldset': {
//                         borderColor: '#e5e7eb',
//                       },
//                       '&:hover fieldset': {
//                         borderColor: '#d1d5db',
//                       },
//                       '&.Mui-focused fieldset': {
//                         borderColor: '#06b6d4',
//                       },
//                     },
//                     '& .MuiOutlinedInput-input': {
//                       py: 1.5,
//                       color: '#1a1a1a',
//                       '&::placeholder': {
//                         color: '#9ca3af',
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />
//               </Box>

//               {/* Controllers Grid */}
//               <Grid container spacing={3}>
//                 {filteredControllers.map((ctrl, index) => (
//                   <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
//                     <Card
//                       sx={{
//                         bgcolor: '#ffffff',
//                         borderRadius: 3,
//                         border: '1px solid #e5e7eb',
//                         transition: 'all 0.2s',
//                         cursor: 'pointer',
//                         boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
//                         '&:hover': {
//                           transform: 'translateY(-2px)',
//                           boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
//                           borderColor: '#d1d5db',
//                         },
//                       }}
//                     >
//                       <CardContent sx={{ p: 3 }}>
//                         <Typography
//                           variant="h6"
//                           sx={{
//                             fontWeight: 600,
//                             mb: 1,
//                             color: '#1a1a1a',
//                           }}
//                         >
//                           {ctrl.name || 'Unnamed Controller'}
//                         </Typography>
//                         <Typography
//                           variant="body2"
//                           sx={{
//                             color: '#6b7280',
//                             mb: 2,
//                             minHeight: 40,
//                           }}
//                         >
//                           {ctrl.type.name || 'No description'}
//                         </Typography>
//                         <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
//                           <Chip
//                             label={`${ctrl.parameters?.length || 0} parameters`}
//                             size="small"
//                             sx={{
//                               bgcolor: 'transparent',
//                               color: '#22d3ee',
//                               border: '1px solid #22d3ee',
//                               fontSize: '0.75rem',
//                             }}
//                           />
//                           <Chip
//                             label={`${ctrl.tags?.length || 0} tags`}
//                             size="small"
//                             icon={
//                               <Box
//                                 component="span"
//                                 sx={{
//                                   width: 6,
//                                   height: 6,
//                                   bgcolor: '#9ca3af',
//                                   borderRadius: '50%',
//                                   ml: 1,
//                                 }}
//                               />
//                             }
//                             sx={{
//                               bgcolor: 'transparent',
//                               color: '#6b7280',
//                               fontSize: '0.75rem',
//                               '& .MuiChip-icon': {
//                                 ml: 1,
//                               },
//                             }}
//                           />
//                         </Box>
//                         {ctrl.tags && ctrl.tags.length > 0 && (
//                           <Box sx={{ mt: 2 }}>
//                             <Chip
//                               label="needs"
//                               size="small"
//                               sx={{
//                                 bgcolor: '#f3f4f6',
//                                 color: '#6b7280',
//                                 fontSize: '0.7rem',
//                                 height: 20,
//                               }}
//                             />
//                           </Box>
//                         )}
//                       </CardContent>
//                     </Card>
//                   </Grid>
//                 ))}
//               </Grid>

//               {/* No Results */}
//               {filteredControllers.length === 0 && searchQuery && (
//                 <Box sx={{ textAlign: 'center', py: 8 }}>
//                   <Typography variant="body1" sx={{ color: '#6b7280' }}>
//                     No controllers found matching "{searchQuery}"
//                   </Typography>
//                 </Box>
//               )}
//             </>
//           )}
//         </>
//       )}
//     </Box>
//   );
// };

// export default ControllersPage;

//last working code

// import React, { useMemo, useState } from 'react';
// import {
//   Box,
//   Typography,
//   Button,
//   Grid,
//   Card,
//   CardContent,
//   TextField,
//   InputAdornment,
//   Chip,
//   IconButton,
//   Tooltip
// } from '@mui/material';
// import AddIcon from '@mui/icons-material/Add';
// import SearchIcon from '@mui/icons-material/Search';
// import SettingsIcon from '@mui/icons-material/Settings';
// import { useSelector } from 'react-redux';
// import Controller from './Controller';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { useNavigate } from 'react-router-dom';
// import EditOutlinedIcon from '@material-ui/icons/EditOutlined';
// import DeleteOutlineOutlinedIcon from '@material-ui/icons/DeleteOutlineOutlined';
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
// import { useDispatch } from 'react-redux';


// const ControllersPage = () => {
//   const controllerData = useSelector(store => store.plcData.controller);
//   const [showCreateForm, setShowCreateForm] = useState(false);
//   const [searchQuery, setSearchQuery] = useState('');
//   const navigate =useNavigate()
//   const dispatch =useDispatch()
//   // Convert controllerData to array if needed
//   const controllersArray = Array.isArray(controllerData) 
//     ? controllerData 
//     : controllerData 
//       ? [controllerData] 
//       : [];

//   console.log(controllersArray, "controllersArray");

//   const handleDelete = (id) => {
//   dispatch(plcActions.deleteController(id));
// };

// const tagData = useSelector(store => store.plcData.tags);
// console.log(tagData,"tagData")

// const tagCountByController = useMemo(() => {
//   return tagData.reduce((acc, tag) => {
//     const name = tag.controllerName?.name;
//     if (!name) return acc;

//     acc[name] = (acc[name] || 0) + 1;
//     return acc;
//   }, {});
// }, [tagData]);



//   // Filter controllers based on search query
//   const filteredControllers = controllersArray.filter(ctrl =>
//     ctrl?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
//     ctrl?.type?.name?.toLowerCase().includes(searchQuery.toLowerCase())
//   );
// console.log(filteredControllers,"filteredControllers")
//   return (
//     <Box sx={{ p: 3, overFlowY:"auto" }}>
//       {/* Header */}
//       <Box
//         sx={{
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           mb: 1,
//         }}
//       >
//         <Box>
//           <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
//             Controllers
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280' }}>
//             Define controller frameworks with custom parameters
//           </Typography>
//         </Box>
//         <ClonosButton
//           variant="filled"
//           onClick={() => navigate('/create-controller')}
//         >
//          <AddIcon />  Create Controller
//         </ClonosButton>
//       </Box>

       
//           {controllersArray.length === 0 ? (
//             // Empty State - No Search Bar
//             <Box
//               sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//               }}
//             >
//               <Box
//                 sx={{
//                   width: 80,
//                   height: 80,
//                   borderRadius: '50%',
//                   bgcolor: '#e5e7eb',
//                   display: 'flex',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   mb: 3,
//                 }}
//               >
//                 <SettingsIcon sx={{ fontSize: 40, color: '#9ca3af' }} />
//               </Box>
//               <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 No controllers yet
//               </Typography>
//               <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                 Create your first controller to define parameters for your tags
//               </Typography>
//               <ClonosButton
//                 variant="outlined"
//                 onClick={() => navigate('/create-controller')}
    
//                 >
//                  <AddIcon />  Create Controller
//                 </ClonosButton>
//             </Box>
//           ) : (
//             <>
//               {/* Search Bar - Only show when controllers exist */}
//               <Box sx={{ mt: 3, mb: 3 ,BorderColor:"black"}}>
//                 <TextField
//                   fullWidth
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: '#212223' }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     maxWidth: 560,
//                     bgcolor: '#ffffff',
//                     borderRadius: 2,
//                     '& .MuiOutlinedInput-root': {
//                       borderRadius: 2,
//                       '& fieldset': {
//                         borderColor: '#494a4d',
//                       },
//                       '&:hover fieldset': {
//                         borderColor: '#444546',
//                       },
//                       '&.Mui-focused fieldset': {
//                         borderColor: '#06b6d4',
//                       },
//                     },
//                     '& .MuiOutlinedInput-input': {
//                       py: 1.5,
//                       color: '#1a1a1a',
//                       '&::placeholder': {
//                         color: '#9ca3af',
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />
//               </Box>

//               {/* Controllers Grid */}
//               <Grid container spacing={3}>
//                 {filteredControllers.map((ctrl, index) => (
//                   <Grid item sx={{
//                       display: 'grid',
//                       gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
//                     }}
//                     key={index}>
//                     <Card
//                        sx={{
//                         maxWidth: 200,
//                         width: '100%',
//                         margin: '0 auto',
//                         position: 'relative',
//                         backgroundColor: '#ffffff',
//                         borderRadius: 3,
//                         border: '1px solid #e5e7eb',
//                         // cursor: 'pointer',
//                         transition: 'box-shadow 0.2s ease',
//                         // boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
//                         boxShadow: '0px 2px 6px rgba(0,0,0,0.12)',

//                         //  boxShadow: 3,
//                         '&:hover': {
//                           boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
//                         },
//                       }}

//                     >
//                       <CardContent sx={{ p: 2 }}>
//   {/* Name + Actions row */}
//                     <Box
//                         sx={{
//                         display: 'flex',
//                         alignItems: 'center',
//                         justifyContent: 'space-between',
                        
//                         }}
//                     >
//                         <Typography
//                         variant="h6"
//                         sx={{
//                             fontWeight: 600,
//                             color: '#1a1a1a',
//                             overflow: 'hidden',
//                             textOverflow: 'ellipsis',
//                             whiteSpace: 'nowrap',
//                         }}
//                         >
//                         {ctrl.name || 'Unnamed Controller'}
//                         </Typography>

//                         <Box sx={{ display: 'flex', gap: 0.5 }}>
//                         <Tooltip title="Edit">
//                             <IconButton
//                             size="small"
//                              onClick={() =>
//                                 navigate(`/edit-controller/${ctrl.id}`, {
//                                     state: { id: ctrl.id }
//                                 })
//                                 }

//                             >
//                             <EditOutlinedIcon fontSize="small" />
//                             </IconButton>
//                         </Tooltip>

//                         <Tooltip title="Delete">
//                             <IconButton
//                             size="small"
//                               onClick={(e) => {
//                                 e.stopPropagation();
//                                 handleDelete(ctrl.id);
//                               }}
//                             >
//                             <DeleteOutlineOutlinedIcon
//                                 fontSize="small"
//                                 style={{ color: '#ef4444' }}
//                             />
//                             </IconButton>
//                         </Tooltip>
//                         </Box>
//                     </Box>

//                     {/* Type */}
//                     <Typography
//                         variant="body2"
//                         sx={{
//                         color: '#6b7280',
//                         // mb: 2,
//                         minHeight: 40,
//                         }}
//                     >
//                         {ctrl.type?.name || 'No type'}
//                     </Typography>

//                     {/* Chips */}
//                     <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
//                         <Chip
//                         label={`${ctrl.parameters?.length || 0} parameters`}
//                         size="small"
//                         sx={{
//                             bgcolor: 'transparent',
//                             color: '#06337E',
//                             border: '1px solid #06337E',
//                             fontSize: '0.75rem',
//                         }}
//                         />
//                         <Chip
//                         label={`${tagCountByController[ctrl.name] || 0} tags`}
//                         size="small"
//                         sx={{
//                             color: '#06337E',
//                             bgcolor: 'transparent',
//                             border: '1px solid #06337E',
//                             fontSize: '0.75rem',
//                         }}
//                         />
//                     </Box>
//                     </CardContent>


                     
//                     </Card>
//                   </Grid>
//                 ))}
//               </Grid>

//               {/* No Results */}
//                 {filteredControllers.length === 0 && searchQuery &&   <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "1rem", padding: "2.5rem 2rem", borderRadius: "1rem", overflowY: "auto"}}>
             
//                 <Box sx={{ textAlign: 'center', py: 8 }}>
//                   <Typography variant="body1" sx={{ color: '#6b7280' }}>
//                     No controllers found matching "{searchQuery}"
//                   </Typography>
//                 </Box>

//               </Card>
// }
//             </>
//       )}
//     </Box>
//   );
// };

// export default ControllersPage;

//optimized code
// import React, { useMemo, useState, useCallback } from 'react';
// import {
//   Box,
//   Typography,
//   Grid,
//   Card,
//   CardContent,
//   TextField,
//   InputAdornment,
//   Chip,
//   IconButton,
//   Tooltip
// } from '@mui/material';
// import AddIcon from '@mui/icons-material/Add';
// import SearchIcon from '@mui/icons-material/Search';
// import SettingsIcon from '@mui/icons-material/Settings';
// import { useSelector, useDispatch } from 'react-redux';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { useNavigate } from 'react-router-dom';
// import EditOutlinedIcon from '@material-ui/icons/EditOutlined';
// import DeleteOutlineOutlinedIcon from '@material-ui/icons/DeleteOutlineOutlined';
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';

// const ControllersPage = () => {
//   const { controller, tags } = useSelector(store => store.plcData);
//   const [searchQuery, setSearchQuery] = useState('');
//   const navigate = useNavigate();
//   const dispatch = useDispatch();

//   // Convert controllerData to array if needed
//   const controllersArray = useMemo(() => {
//     return Array.isArray(controller)
//       ? controller
//       : controller
//       ? [controller]
//       : [];
//   }, [controller]);

//   const handleDelete = useCallback((id) => {
//     dispatch(plcActions.deleteController(id));
//   }, [dispatch]);

//   const tagCountByController = useMemo(() => {
//     return tags.reduce((acc, tag) => {
//       const name = tag.controllerName?.name;
//       if (!name) return acc;
//       acc[name] = (acc[name] || 0) + 1;
//       return acc;
//     }, {});
//   }, [tags]);

//   // Filter controllers based on search query
//   const filteredControllers = useMemo(() => {
//     const q = searchQuery.toLowerCase();
//     return controllersArray.filter(ctrl =>
//       ctrl?.name?.toLowerCase().includes(q) ||
//       ctrl?.type?.name?.toLowerCase().includes(q)
//     );
//   }, [controllersArray, searchQuery]);

//   return (
//     <Box sx={{ p: 3, overFlowY:"auto" }}>
//       {/* Header */}
//       <Box
//         sx={{
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           mb: 1,
//         }}
//       >
//         <Box>
//           <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
//             Controllers
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280' }}>
//             Define controller frameworks with custom parameters
//           </Typography>
//         </Box>
//         <ClonosButton
//           variant="filled"
//           onClick={() => navigate('/create-controller')}
//         >
//          <AddIcon />  Create Controller
//         </ClonosButton>
//       </Box>

//       {controllersArray.length === 0 ? (
//         /* Empty State */
//         <Box
//           sx={{
//             display: 'flex',
//             flexDirection: 'column',
//             alignItems: 'center',
//             justifyContent: 'center',
//             minHeight: '60vh',
//             textAlign: 'center',
//           }}
//         >
//           <Box
//             sx={{
//               width: 80,
//               height: 80,
//               borderRadius: '50%',
//               bgcolor: '#e5e7eb',
//               display: 'flex',
//               alignItems: 'center',
//               justifyContent: 'center',
//               mb: 3,
//             }}
//           >
//             <SettingsIcon sx={{ fontSize: 40, color: '#9ca3af' }} />
//           </Box>
//           <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//             No controllers yet
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//             Create your first controller to define parameters for your tags
//           </Typography>
//           <ClonosButton
//             variant="outlined"
//             onClick={() => navigate('/create-controller')}
//           >
//             <AddIcon />  Create Controller
//           </ClonosButton>
//         </Box>
//       ) : (
//         <>
//           {/* Search Bar */}
//           <Box sx={{ mt: 3, mb: 3 ,BorderColor:"black"}}>
//             <TextField
//               fullWidth
//               placeholder="Search controllers..."
//               value={searchQuery}
//               onChange={(e) => setSearchQuery(e.target.value)}
//               InputProps={{
//                 startAdornment: (
//                   <InputAdornment position="start">
//                     <SearchIcon sx={{ color: '#212223' }} />
//                   </InputAdornment>
//                 ),
//               }}
//               sx={{
//                 maxWidth: 560,
//                 bgcolor: '#ffffff',
//                 borderRadius: 2,
//                 '& .MuiOutlinedInput-root': {
//                   borderRadius: 2,
//                   '& fieldset': {
//                     borderColor: '#494a4d',
//                   },
//                   '&:hover fieldset': {
//                     borderColor: '#444546',
//                   },
//                   '&.Mui-focused fieldset': {
//                     borderColor: '#06b6d4',
//                   },
//                 },
//                 '& .MuiOutlinedInput-input': {
//                   py: 1.5,
//                   color: '#1a1a1a',
//                   '&::placeholder': {
//                     color: '#9ca3af',
//                     opacity: 1,
//                   },
//                 },
//               }}
//             />
//           </Box>

//           {/* Controllers Grid */}
//           <Grid container spacing={3}>
//             {filteredControllers.map((ctrl, index) => (
//               <Grid
//                 item
//                 sx={{
//                   display: 'grid',
//                   gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
//                 }}
//                 key={index}
//               >
//                <Card
//                        sx={{
//                         maxWidth: 200,
//                         width: '100%',
//                         margin: '0 auto',
//                         position: 'relative',
//                         backgroundColor: '#ffffff',
//                         borderRadius: 3,
//                         border: '1px solid #e5e7eb',
//                         // cursor: 'pointer',
//                         transition: 'box-shadow 0.2s ease',
//                         // boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
//                         boxShadow: '0px 2px 6px rgba(0,0,0,0.12)',

//                         //  boxShadow: 3,
//                         '&:hover': {
//                           boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
//                         },
//                       }}

//                     >
//                       <CardContent sx={{ p: 2 }}>
//   {/* Name + Actions row */}
//                     <Box
//                         sx={{
//                         display: 'flex',
//                         alignItems: 'center',
//                         justifyContent: 'space-between',
                        
//                         }}
//                     >
//                         <Typography
//                         variant="h6"
//                         sx={{
//                             fontWeight: 600,
//                             color: '#1a1a1a',
//                             overflow: 'hidden',
//                             textOverflow: 'ellipsis',
//                             whiteSpace: 'nowrap',
//                         }}
//                         >
//                         {ctrl.name || 'Unnamed Controller'}
//                         </Typography>

//                         <Box sx={{ display: 'flex', gap: 0.5 }}>
//                         <Tooltip title="Edit">
//                             <IconButton
//                             size="small"
//                              onClick={() =>
//                                 navigate(`/edit-controller/${ctrl.id}`, {
//                                     state: { id: ctrl.id }
//                                 })
//                                 }

//                             >
//                             <EditOutlinedIcon fontSize="small" />
//                             </IconButton>
//                         </Tooltip>

//                         <Tooltip title="Delete">
//                             <IconButton
//                             size="small"
//                               onClick={(e) => {
//                                 e.stopPropagation();
//                                 handleDelete(ctrl.id);
//                               }}
//                             >
//                             <DeleteOutlineOutlinedIcon
//                                 fontSize="small"
//                                 style={{ color: '#ef4444' }}
//                             />
//                             </IconButton>
//                         </Tooltip>
//                         </Box>
//                     </Box>

//                     {/* Type */}
//                     <Typography
//                         variant="body2"
//                         sx={{
//                         color: '#6b7280',
//                         // mb: 2,
//                         minHeight: 40,
//                         }}
//                     >
//                         {ctrl.type?.name || 'No type'}
//                     </Typography>

//                     {/* Chips */}
//                     <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
//                         <Chip
//                         label={`${ctrl.parameters?.length || 0} parameters`}
//                         size="small"
//                         sx={{
//                             bgcolor: 'transparent',
//                             color: '#06337E',
//                             border: '1px solid #06337E',
//                             fontSize: '0.75rem',
//                         }}
//                         />
//                         <Chip
//                         label={`${tagCountByController[ctrl.name] || 0} tags`}
//                         size="small"
//                         sx={{
//                             color: '#06337E',
//                             bgcolor: 'transparent',
//                             border: '1px solid #06337E',
//                             fontSize: '0.75rem',
//                         }}
//                         />
//                     </Box>
//                     </CardContent>


                     
//                     </Card>
//               </Grid>
//             ))}
//           </Grid>
//         </>
//       )}
//     </Box>
//   );
// };

// export default ControllersPage;





import React, { useMemo, useState, useCallback, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  TextField,
  InputAdornment,
  Chip,
  IconButton,
  Tooltip
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import SettingsIcon from '@mui/icons-material/Settings';
import { useSelector, useDispatch } from 'react-redux';
import { ClonosButton } from '../../../../CommonComponents/Button/Button';
import { useNavigate } from 'react-router-dom';
import EditOutlinedIcon from '@material-ui/icons/EditOutlined';
import DeleteOutlineOutlinedIcon from '@material-ui/icons/DeleteOutlineOutlined';
import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
import useToggler from '../../../../../CustomHooks/TogglerHook';
import { handleDeleteControllers, handleGetAllControllers } from '../plc-manager';
import { doDeleteApiCall } from '../../../../../utils/ClonosApi';
import { handleShowErrorAndWarning } from '../../../../../utils/clonosCommon';

const ControllersPage = () => {
  const { controller, tags } = useSelector(store => store.plcData);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useToggler(); 
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [refreshApi,setRefreshApi]=useToggler()

  const [controllerData,setControllerData]=useState({})

  // Convert controllerData to array if needed
  const controllersArray = useMemo(() => {
    return Array.isArray(controllerData)
      ? controllerData
      : controllerData
      ? [controllerData]
      : [];
  }, [controllerData]);

  const handleDelete = (id) => {
   
          const next = () => {
               setRefreshApi()
               handleShowErrorAndWarning({dispatch,message:` Controller Deleted successfully.`,type:"success",showTime:"5000"})
           }
          handleDeleteControllers({setIsLoading,controllerId:id,next})
  }

  const tagCountByController = useMemo(() => {
    return tags.reduce((acc, tag) => {
      const name = tag.controllerName?.name;
      if (!name) return acc;
      acc[name] = (acc[name] || 0) + 1;
      return acc;
    }, {});
  }, [tags]);

  

  // Filter controllers based on search query
  const filteredControllers = useMemo(() => {
    const q = searchQuery.toLowerCase();
    return controllersArray.filter(ctrl =>
      ctrl?.controllerName?.toLowerCase().includes(q) ||
      ctrl?.network?.name.toLowerCase().includes(q)
    );
  }, [controllersArray, searchQuery]);




  useEffect(()=>{
      handleGetAllControllers({dispatch,setterMethod:setControllerData,setIsLoading})
  },[refreshApi])


  return (
    <Box sx={{ p: 3, overFlowY:"auto" }}>
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 1,
        }}
      >
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
            Controllers
          </Typography>
          <Typography variant="body2" sx={{ color: '#6b7280' }}>
            Define controller frameworks with custom parameters
          </Typography>
        </Box>
        <ClonosButton
          variant="filled"
          onClick={() => navigate('/create-controller')}
        >
         <AddIcon />  Create Controller
        </ClonosButton>
      </Box>

      {controllersArray.length === 0 ? (
        /* Empty State */
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '60vh',
            textAlign: 'center',
          }}
        >
          <Box
            sx={{
              width: 80,
              height: 80,
              borderRadius: '50%',
              bgcolor: '#e5e7eb',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 3,
            }}
          >
            <SettingsIcon sx={{ fontSize: 40, color: '#9ca3af' }} />
          </Box>
          <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
            No controllers yet
          </Typography>
          <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
            Create your first controller to define parameters for your tags
          </Typography>
          <ClonosButton
            variant="outlined"
            onClick={() => navigate('/create-controller')}
          >
            <AddIcon />  Create Controller
          </ClonosButton>
        </Box>
      ) : (
        <>
          {/* Search Bar */}
          <Box sx={{ mt: 3, mb: 3 ,BorderColor:"black"}}>
            <TextField
              fullWidth
              placeholder="Search controllers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: '#212223' }} />
                  </InputAdornment>
                ),
              }}
              sx={{
                maxWidth: 560,
                bgcolor: '#ffffff',
                borderRadius: 2,
                '& .MuiOutlinedInput-root': {
                  borderRadius: 2,
                  '& fieldset': {
                    borderColor: '#494a4d',
                  },
                  '&:hover fieldset': {
                    borderColor: '#444546',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#06b6d4',
                  },
                },
                '& .MuiOutlinedInput-input': {
                  py: 1.5,
                  color: '#1a1a1a',
                  '&::placeholder': {
                    color: '#9ca3af',
                    opacity: 1,
                  },
                },
              }}
            />
          </Box>

          {/* Controllers Grid */}
          <Grid container spacing={3}>
            {filteredControllers.map((ctrl, index) => (
              <Grid
                item
                sx={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
                }}
                key={index}
              >
               <Card
                       sx={{
                        maxWidth: 200,
                        width: '100%',
                        margin: '0 auto',
                        position: 'relative',
                        backgroundColor: '#ffffff',
                        borderRadius: 3,
                        border: '1px solid #e5e7eb',
                        // cursor: 'pointer',
                        transition: 'box-shadow 0.2s ease',
                        // boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
                        boxShadow: '0px 2px 6px rgba(0,0,0,0.12)',

                        //  boxShadow: 3,
                        '&:hover': {
                          boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
                        },
                      }}

                    >
                      <CardContent sx={{ p: 2 }}>
  {/* Name + Actions row */}
                    <Box
                        sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        
                        }}
                    >
                        <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 600,
                            color: '#1a1a1a',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                        }}
                        >
                        {ctrl.controllerName || 'Unnamed Controller'}
                        </Typography>

                        <Box sx={{ display: 'flex', gap: 0.5 }}>
                        <Tooltip title="Edit">
                            <IconButton
                            size="small"
                             onClick={() =>
                                navigate(`/edit-controller/${ctrl._id}`, {
                                    state: { id: ctrl._id }
                                })
                                }

                            >
                            <EditOutlinedIcon fontSize="small" />
                            </IconButton>
                        </Tooltip>

                        <Tooltip title="Delete">
                            <IconButton
                            size="small"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(ctrl._id);
                              }}
                            >
                            <DeleteOutlineOutlinedIcon
                                fontSize="small"
                                style={{ color: '#ef4444' }}
                            />
                            </IconButton>
                        </Tooltip>
                        </Box>
                    </Box>

                    {/* Type */}
                    <Typography
                        variant="body2"
                        sx={{
                        color: '#6b7280',
                        // mb: 2,
                        minHeight: 40,
                        }}
                    >
                        {ctrl?.network?.name || 'No type'}
                    </Typography>

                    {/* Chips */}
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        <Chip
                        label={`${ctrl.parameters?.length || 0} parameters`}
                        size="small"
                        sx={{
                            bgcolor: 'transparent',
                            color: '#06337E',
                            border: '1px solid #06337E',
                            fontSize: '0.75rem',
                        }}
                        />
                        <Chip
                        label={`${tagCountByController[ctrl.controllerName] || 0} tags`}
                        size="small"
                        sx={{
                            color: '#06337E',
                            bgcolor: 'transparent',
                            border: '1px solid #06337E',
                            fontSize: '0.75rem',
                        }}
                        />
                    </Box>
                    </CardContent>


                     
                    </Card>
              </Grid>
            ))}
          </Grid>
        </>
      )}
    </Box>
  );
};

export default ControllersPage;
