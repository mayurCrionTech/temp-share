// import React, { useState } from 'react';
// import {
//   Box,
//   Typography,
//   Button,
//   Grid,
//   Card,
//   CardContent,
//   TextField,
//   InputAdornment,
//   Chip,
//   IconButton,
//   Tooltip
// } from '@mui/material';
// import AddIcon from '@mui/icons-material/Add';
// import SearchIcon from '@mui/icons-material/Search';
// import SettingsIcon from '@mui/icons-material/Settings';
// import LocalOfferOutlinedIcon from '@mui/icons-material/LocalOfferOutlined';
// import { useSelector } from 'react-redux';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { useNavigate } from 'react-router-dom';
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
// import { useDispatch } from 'react-redux';
// import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
// import { Height } from '@material-ui/icons';
// import ClonosDataGrid from '../../../../CommonComponents/ClonosDataGrid/ClonosDataGrid';
// import { setSerialNumber } from '../../../../../utils/clonosCommon';
// import { Switch} from "@material-ui/core";
// import EditOutlinedIcon from "@material-ui/icons/EditOutlined";
// import DeleteOutlineOutlinedIcon from "@material-ui/icons/DeleteOutlineOutlined";
// import { IoDocumentTextOutline } from 'react-icons/io5';
// import Styles from '../../plc.module.css'
// import * as XLSX from "xlsx";


// const TagsPage = () => {
//   const tagsData = useSelector(store => store.plcData.tags);
//   const controllerData = useSelector(store => store.plcData.controller);
  
//   const [searchQuery, setSearchQuery] = useState('');
//   const navigate =useNavigate()
//   const dispatch =useDispatch()
//   // Convert controllerData to array if needed
//   const tagsArray = Array.isArray(tagsData) 
//     ? tagsData 
//     : tagsData 
//       ? [tagsData] 
//       : [];

//    const controllersArray = Array.isArray(controllerData) 
//     ? controllerData 
//     : controllerData 
//       ? [controllerData] 
//       : [];    

//   console.log(tagsData, "tagsData");
//   console.log(tagsArray, "tagsArray");

// //   const handleDelete = (id) => {
// //   dispatch(plcActions.deleteController(id));
// // };

// const handleExportExcel = () => {
//   if (!filteredtags || filteredtags.length === 0) return;

//   const exportableColumns = columns.filter(
//     (col) => col.field !== "actions"
//   );

//   const excelData = filteredtags.map((row) => {
//     const rowData = {};

//     exportableColumns.forEach((col) => {
//       let value = "-";

//       if (col.field === "status") {
//         // value = row?.isActive ? "Active" : "Inactive";
//          value = "Active";
//       } 
//       else if (col.valueGetter) {
//         value = col.valueGetter({ row }) ?? "-";
//       } 
//       else {
//         value = row[col.field] ?? "-";
//       }

//       rowData[col.headerName] = value;
//     });

//     return rowData;
//   });

//   const worksheet = XLSX.utils.json_to_sheet(excelData);
//   const workbook = XLSX.utils.book_new();
//   XLSX.utils.book_append_sheet(workbook, worksheet, "Tags");

//   XLSX.writeFile(workbook, "Tags_Report.xlsx");
// }



// const handleDeleteTag=(id)=>{
//    dispatch(plcActions.deleteTags(id))
// }

// const columns = [


//   {
//     field: "name",
//     headerName: "TAG NAME",
//     flex: 1,
//     disableColumnFilter: true,
//     renderCell: (params) => (
//       <span>{params.row.name || "-"}</span>
//     ),
//   },
//   {
//     field: "controller",
//     headerName: "CONTROLLER",
//     flex: 1,
//     disableColumnFilter: true,
//     valueGetter: (params) =>
//       params.row?.controllerName?.name || "-",
//     renderCell: (params) => (
//       <span>{params.value}</span>
//     ),
//   },
//   {
//     field: "status",
//     headerName: "STATUS",
//     flex: 1,
//     disableColumnFilter: true,
//     renderCell: () => (
//       <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
//         <Switch checked size="small" color="primary" />
//         <span style={{ color: "#06337e", fontSize: 14 }}>
//           Active
//         </span>
//       </div>
//     ),
//   },
//   {
//     field: "createdAt",
//     headerName: "CREATED",
//     flex: 1,
//     disableColumnFilter: true,
//     renderCell: () => (
//       <span style={{ color: "#8b9bb4" }}>-</span>
//     ),
//   },
//   {
//     field: "actions",
//     headerName: "ACTIONS",
//     flex: 0.7,
//     sortable: false,
//     disableColumnFilter: true,
//     renderCell: (params) => (
//       <div style={{ display: "flex", gap: 8 }}>
//         <IconButton size="small"  onClick={() => navigate(`/edit-tag/${params?.row?.id}`,{
//           state: { id: params?.row?.id }
//         })} >
        
//           <EditOutlinedIcon style={{ color: "#8b9bb4" }} />
//         </IconButton>
//         <IconButton size="small" onClick={()=>handleDeleteTag(params?.row?.id)}>
//           <DeleteOutlineOutlinedIcon style={{ color: "#dc2626" }} />
//         </IconButton>
//       </div>
//     ),
//   },
// ];

// //   // Filter controllers based on search query
//   const filteredtags = tagsArray.filter(tag =>
//     tag?.name?.toLowerCase().includes(searchQuery.toLowerCase())
//   );


//     let controllerOptions = controllerData.map((controller)=> controller.name)
   
//   console.log(controllerOptions,"controllerOptions")
// // console.log(filteredControllers,"filteredControllers")
//   return (
//     <Box sx={{ p: 3, overFlowY:"auto" }}>
//       {/* Header */}
//       <Box
//         sx={{
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           mb: 1,
//         }}
//       >
//         <Box>
//           <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
//             Tags
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280' }}>
//             Create and manage tags based on controller configurations
//           </Typography>
//         </Box>

//         <div style={{ display: "flex", alignItems: "center" }}>
 

//         {/* Export */}
//        {controllersArray.length > 0 &&  <div
//           className={Styles.reportButton}
//           onClick={filteredtags.length ? handleExportExcel : undefined}
//           style={{
//             opacity: filteredtags.length ? 1 : 0.5,
//             cursor: filteredtags.length ? "pointer" : "not-allowed",
//           }}
//         >
//           <IoDocumentTextOutline size={20} />
//           <span>Export</span>
//         </div>
// }


//         {controllersArray.length > 0 &&
//           <ClonosButton
//           variant="filled"
//           onClick={() => navigate('/create-tag')}
//           >
//           <AddIcon />  New Tags
//           </ClonosButton>
//         }
//        </div>

        
//       </Box>

//       {/* Show Controller form when creating */}
     
//           {controllersArray.length === 0 ? (
//             // Empty State - No Search Bar
//             <Box
//             sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//             }}
//             >
//             <Box
//                 sx={{
//                 width: 80,
//                 height: 80,
//                 borderRadius: '50%',
//                 bgcolor: '#e5e7eb',
//                 display: 'flex',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 mb: 3,
//                 }}
//             >
//                 <LocalOfferOutlinedIcon sx={{ fontSize: 35, color: '#9ca3af' }} />
//             </Box>
//             <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 Create a controller first
//             </Typography>
//             <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                You need to create at least one controller before you can create tags
//             </Typography>
//             </Box> 
//           ) : tagsArray.length === 0 ?(
//             // Empty State - No Search Bar
//             <Box
//               sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//               }}
//             >
//               <Box
//                 sx={{
//                   width: 80,
//                   height: 80,
//                   borderRadius: '50%',
//                   bgcolor: '#e5e7eb',
//                   display: 'flex',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   mb: 3,
//                 }}
//               >
//                 <LocalOfferOutlinedIcon sx={{ fontSize: 35, color: '#9ca3af' }} />
//               </Box>
//               <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 No Tags yet
//               </Typography>
//               <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                 Create your first tag to start configuring your controllers
//               </Typography>
//               <ClonosButton
//                 variant="outlined"
//                 onClick={() => navigate('/create-tag')}
    
//                 >
//                  <AddIcon />  Create Tag
//                 </ClonosButton>
//             </Box>
//           ) : (
//             <>
//               {/* Search Bar - Only show when controllers exist */}
             
//                 {/* <Grid  item xs={12} sm={6} md={4} lg={3}>

//                      <Box   sx={{ mt: 3, mb: 3 ,BorderColor:"black"}}>
//                 <TextField
//                   fullWidth
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: '#212223' }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     // maxWidth: 560,
//                     bgcolor: '#ffffff',
//                     borderRadius: 2,
//                     '& .MuiOutlinedInput-root': {
//                       borderRadius: 2,
//                       '& fieldset': {
//                         borderColor: '#494a4d',
//                       },
//                       '&:hover fieldset': {
//                         borderColor: '#444546',
//                       },
//                       '&.Mui-focused fieldset': {
//                         borderColor: '#06b6d4',
//                       },
//                     },
//                     '& .MuiOutlinedInput-input': {
//                       py: 1.5,
//                       color: '#1a1a1a',
//                       '&::placeholder': {
//                         color: '#9ca3af',
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />

                  

//               </Box>

//                   <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     // isMandatory={true}
//                     isLabel={false}
//                     uniqueKey="controllerName"
//                     placeholder="All Controller"
//                     // defaultValue={formData?.type?.name}
//                     options={[]}
//                     // handleGetValues={handleGetValues}
//                     // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />

//                      <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     // isMandatory={true}
//                     isLabel={false}
//                     uniqueKey="Status"
//                     placeholder="All Status"
//                     // defaultValue={formData?.type?.name}
//                     options={[]}
//                     // handleGetValues={handleGetValues}
//                     // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />

//                 </Grid> */}
                 
//             <Grid item xs={12}>
//               <Box
//                 sx={{
//                   mt: 3,
//                   mb: 3,
//                   display: "flex",
//                   alignItems: "center",
//                   gap: 2,
//                 }}
//               >
//                 {/* Search */}
//                 <TextField
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: "#212223" }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     flex: 1, // 👈 takes remaining space
//                     bgcolor: "#ffffff",
//                     borderRadius: 2,
//                     "& .MuiOutlinedInput-root": {
//                       borderRadius: 2,
//                       "& fieldset": {
//                         borderColor: "#494a4d",
//                       },
//                       "&:hover fieldset": {
//                         borderColor: "#444546",
//                       },
//                       "&.Mui-focused fieldset": {
//                         borderColor: "#06b6d4",
//                       },
//                     },
//                     "& .MuiOutlinedInput-input": {
//                       py: 1.5,
//                       color: "#1a1a1a",
//                       "&::placeholder": {
//                         color: "#9ca3af",
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />

//                 {/* Controller dropdown */}
//                 <Box sx={{ minWidth: 180,Height:10 }}>
//                   <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     isLabel={false}
//                     uniqueKey="controllerName"
//                     placeholder="All Controller"
//                     options={controllerOptions.map((cont) => ({
//                   label: cont,
//                   value: cont,
//                   isNeeded: true,
//                 }))}
//                   />
//                 </Box>

//                 {/* Status dropdown */}
//                 <Box sx={{ minWidth: 160 ,Height:10 }}>
//                   <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     isLabel={false}
//                     uniqueKey="Status"
//                     placeholder="All Status"
//                     options={[{label:"Active",value:"Active",isNeeded:true},{label:"In Active",value:"In Active",isNeeded:true},]}
                  
                    
//                   />
//                 </Box>
//               </Box>
//             </Grid>
//            {filteredtags.length > 0 &&   <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem", padding: "1.5rem", borderRadius: "1rem", overflowY: "auto"}}>
//                            <ClonosDataGrid
//                                 rows={setSerialNumber(filteredtags)}
//                                 columns={columns}
//                                 // isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
//                                 // isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
//                                 uniqueIdField="id"
//                                 // onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
//                                 // isLoading={isLoading}
//                                 totalCount={tagsData?.length}
//                                 pageLimit={15}
//                                checkboxSelection={false}
//                                 // handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
//                             />
            
//             </Card>
// }
//               {/* No Results */}

//                 {filteredtags.length === 0 && searchQuery &&  <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "1rem", padding: "2.5rem 2rem", borderRadius: "1rem", overflowY: "auto"}}>
       
//                 <Box sx={{ textAlign: 'center', py: 8 }}>
//                   <Typography variant="body1" sx={{ color: '#6b7280' }}>
//                     No controllers found matching "{searchQuery}"
//                   </Typography>
//                 </Box>
//               </Card>
//               }
//             </>
//       )}
//     </Box>
//   );
// };

// export default TagsPage;


//optimized code

// import React, { useState, useMemo, useCallback } from 'react';
// import {
//   Box,
//   Typography,
//   Grid,
//   Card,
//   TextField,
//   InputAdornment,
//   IconButton
// } from '@mui/material';
// import AddIcon from '@mui/icons-material/Add';
// import SearchIcon from '@mui/icons-material/Search';
// import LocalOfferOutlinedIcon from '@mui/icons-material/LocalOfferOutlined';
// import { useSelector, useDispatch } from 'react-redux';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { useNavigate } from 'react-router-dom';
// import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
// import ClonosDataGrid from '../../../../CommonComponents/ClonosDataGrid/ClonosDataGrid';
// import { setSerialNumber } from '../../../../../utils/clonosCommon';
// import { Switch } from "@material-ui/core";
// import EditOutlinedIcon from "@material-ui/icons/EditOutlined";
// import DeleteOutlineOutlinedIcon from "@material-ui/icons/DeleteOutlineOutlined";
// import { IoDocumentTextOutline } from 'react-icons/io5';
// import Styles from '../../plc.module.css';
// import * as XLSX from "xlsx";
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';

// const TagsPage = () => {
//   const tagsData = useSelector(store => store.plcData.tags);
//   const controllerData = useSelector(store => store.plcData.controller);

//   const [searchQuery, setSearchQuery] = useState('');
//   const navigate = useNavigate();
//   const dispatch = useDispatch();

//   const tagsArray = useMemo(() => (
//     Array.isArray(tagsData) ? tagsData : tagsData ? [tagsData] : []
//   ), [tagsData]);

//   const controllersArray = useMemo(() => (
//     Array.isArray(controllerData) ? controllerData : controllerData ? [controllerData] : []
//   ), [controllerData]);

//   const filteredtags = useMemo(() => {
//     const q = searchQuery.toLowerCase();
//     return tagsArray.filter(tag =>
//       tag?.name?.toLowerCase().includes(q)
//     );
//   }, [tagsArray, searchQuery]);

//   const controllerOptions = useMemo(() => (
//     controllersArray.map(controller => controller.name)
//   ), [controllersArray]);

//   const handleDeleteTag = useCallback((id) => {
//     dispatch(plcActions.deleteTags(id));
//   }, [dispatch]);

//   const handleExportExcel = useCallback(() => {
//     if (!filteredtags.length) return;

//     const exportableColumns = columns.filter(col => col.field !== "actions");

//     const excelData = filteredtags.map(row => {
//       const rowData = {};
//       exportableColumns.forEach(col => {
//         let value = "-";
//         if (col.field === "status") value = "Active";
//         else if (col.valueGetter) value = col.valueGetter({ row }) ?? "-";
//         else value = row[col.field] ?? "-";
//         rowData[col.headerName] = value;
//       });
//       return rowData;
//     });

//     const worksheet = XLSX.utils.json_to_sheet(excelData);
//     const workbook = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(workbook, worksheet, "Tags");
//     XLSX.writeFile(workbook, "Tags_Report.xlsx");
//   }, [filteredtags]);

//   const columns = useMemo(() => ([
//     {
//       field: "name",
//       headerName: "TAG NAME",
//       flex: 1,
//       renderCell: (params) => <span>{params.row.name || "-"}</span>,
//     },
//     {
//       field: "controller",
//       headerName: "CONTROLLER",
//       flex: 1,
//       valueGetter: (params) =>
//         params.row?.controllerName?.name || "-",
//       renderCell: (params) => <span>{params.value}</span>,
//     },
//     {
//       field: "status",
//       headerName: "STATUS",
//       flex: 1,
//       renderCell: () => (
//         <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
//           <Switch checked size="small" color="primary" />
//           <span style={{ color: "#06337e", fontSize: 14 }}>Active</span>
//         </div>
//       ),
//     },
//     {
//       field: "createdAt",
//       headerName: "CREATED",
//       flex: 1,
//       renderCell: () => <span style={{ color: "#8b9bb4" }}>-</span>,
//     },
//     {
//       field: "actions",
//       headerName: "ACTIONS",
//       flex: 0.7,
//       sortable: false,
//       renderCell: (params) => (
//         <div style={{ display: "flex", gap: 8 }}>
//           <IconButton
//             size="small"
//             onClick={() =>
//               navigate(`/edit-tag/${params.row.id}`, {
//                 state: { id: params.row.id }
//               })
//             }
//           >
//             <EditOutlinedIcon style={{ color: "#8b9bb4" }} />
//           </IconButton>
//           <IconButton
//             size="small"
//             onClick={() => handleDeleteTag(params.row.id)}
//           >
//             <DeleteOutlineOutlinedIcon style={{ color: "#dc2626" }} />
//           </IconButton>
//         </div>
//       ),
//     },
//   ]), [handleDeleteTag, navigate]);

//   return (
//   <Box sx={{ p: 3, overFlowY:"auto" }}>
//       {/* Header */}
//       <Box
//         sx={{
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           mb: 1,
//         }}
//       >
//         <Box>
//           <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
//             Tags
//           </Typography>
//           <Typography variant="body2" sx={{ color: '#6b7280' }}>
//             Create and manage tags based on controller configurations
//           </Typography>
//         </Box>

//         <div style={{ display: "flex", alignItems: "center" }}>
 

//         {/* Export */}
//        {controllersArray.length > 0 &&  <div
//           className={Styles.reportButton}
//           onClick={filteredtags.length ? handleExportExcel : undefined}
//           style={{
//             opacity: filteredtags.length ? 1 : 0.5,
//             cursor: filteredtags.length ? "pointer" : "not-allowed",
//           }}
//         >
//           <IoDocumentTextOutline size={20} />
//           <span>Export</span>
//         </div>
// }


//         {controllersArray.length > 0 &&
//           <ClonosButton
//           variant="filled"
//           onClick={() => navigate('/create-tag')}
//           >
//           <AddIcon />  New Tags
//           </ClonosButton>
//         }
//        </div>

        
//       </Box>

//       {/* Show Controller form when creating */}
     
//           {controllersArray.length === 0 ? (
//             // Empty State - No Search Bar
//             <Box
//             sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//             }}
//             >
//             <Box
//                 sx={{
//                 width: 80,
//                 height: 80,
//                 borderRadius: '50%',
//                 bgcolor: '#e5e7eb',
//                 display: 'flex',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 mb: 3,
//                 }}
//             >
//                 <LocalOfferOutlinedIcon sx={{ fontSize: 35, color: '#9ca3af' }} />
//             </Box>
//             <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 Create a controller first
//             </Typography>
//             <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                You need to create at least one controller before you can create tags
//             </Typography>
//             </Box> 
//           ) : tagsArray.length === 0 ?(
//             // Empty State - No Search Bar
//             <Box
//               sx={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 minHeight: '60vh',
//                 textAlign: 'center',
//               }}
//             >
//               <Box
//                 sx={{
//                   width: 80,
//                   height: 80,
//                   borderRadius: '50%',
//                   bgcolor: '#e5e7eb',
//                   display: 'flex',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   mb: 3,
//                 }}
//               >
//                 <LocalOfferOutlinedIcon sx={{ fontSize: 35, color: '#9ca3af' }} />
//               </Box>
//               <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
//                 No Tags yet
//               </Typography>
//               <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
//                 Create your first tag to start configuring your controllers
//               </Typography>
//               <ClonosButton
//                 variant="outlined"
//                 onClick={() => navigate('/create-tag')}
    
//                 >
//                  <AddIcon />  Create Tag
//                 </ClonosButton>
//             </Box>
//           ) : (
//             <>
//               {/* Search Bar - Only show when controllers exist */}
             
//                 {/* <Grid  item xs={12} sm={6} md={4} lg={3}>

//                      <Box   sx={{ mt: 3, mb: 3 ,BorderColor:"black"}}>
//                 <TextField
//                   fullWidth
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: '#212223' }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     // maxWidth: 560,
//                     bgcolor: '#ffffff',
//                     borderRadius: 2,
//                     '& .MuiOutlinedInput-root': {
//                       borderRadius: 2,
//                       '& fieldset': {
//                         borderColor: '#494a4d',
//                       },
//                       '&:hover fieldset': {
//                         borderColor: '#444546',
//                       },
//                       '&.Mui-focused fieldset': {
//                         borderColor: '#06b6d4',
//                       },
//                     },
//                     '& .MuiOutlinedInput-input': {
//                       py: 1.5,
//                       color: '#1a1a1a',
//                       '&::placeholder': {
//                         color: '#9ca3af',
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />

                  

//               </Box>

//                   <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     // isMandatory={true}
//                     isLabel={false}
//                     uniqueKey="controllerName"
//                     placeholder="All Controller"
//                     // defaultValue={formData?.type?.name}
//                     options={[]}
//                     // handleGetValues={handleGetValues}
//                     // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />

//                      <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     // isMandatory={true}
//                     isLabel={false}
//                     uniqueKey="Status"
//                     placeholder="All Status"
//                     // defaultValue={formData?.type?.name}
//                     options={[]}
//                     // handleGetValues={handleGetValues}
//                     // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                     />

//                 </Grid> */}
                 
//             <Grid item xs={12}>
//               <Box
//                 sx={{
//                   mt: 3,
//                   mb: 3,
//                   display: "flex",
//                   alignItems: "center",
//                   gap: 2,
//                 }}
//               >
//                 {/* Search */}
//                 <TextField
//                   placeholder="Search controllers..."
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <SearchIcon sx={{ color: "#212223" }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                   sx={{
//                     flex: 1, // 👈 takes remaining space
//                     bgcolor: "#ffffff",
//                     borderRadius: 2,
//                     "& .MuiOutlinedInput-root": {
//                       borderRadius: 2,
//                       "& fieldset": {
//                         borderColor: "#494a4d",
//                       },
//                       "&:hover fieldset": {
//                         borderColor: "#444546",
//                       },
//                       "&.Mui-focused fieldset": {
//                         borderColor: "#06b6d4",
//                       },
//                     },
//                     "& .MuiOutlinedInput-input": {
//                       py: 1.5,
//                       color: "#1a1a1a",
//                       "&::placeholder": {
//                         color: "#9ca3af",
//                         opacity: 1,
//                       },
//                     },
//                   }}
//                 />

//                 {/* Controller dropdown */}
//                 <Box sx={{ minWidth: 180,Height:10 }}>
//                   <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     isLabel={false}
//                     uniqueKey="controllerName"
//                     placeholder="All Controller"
//                     options={controllerOptions.map((cont) => ({
//                   label: cont,
//                   value: cont,
//                   isNeeded: true,
//                 }))}
//                   />
//                 </Box>

//                 {/* Status dropdown */}
//                 <Box sx={{ minWidth: 160 ,Height:10 }}>
//                   <ClonosSelect
//                     tabIndex={2}
//                     type="select"
//                     isLabel={false}
//                     uniqueKey="Status"
//                     placeholder="All Status"
//                     options={[{label:"Active",value:"Active",isNeeded:true},{label:"In Active",value:"In Active",isNeeded:true},]}
                  
                    
//                   />
//                 </Box>
//               </Box>
//             </Grid>
//            {filteredtags.length > 0 &&   <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem", padding: "1.5rem", borderRadius: "1rem", overflowY: "auto"}}>
//                            <ClonosDataGrid
//                                 rows={setSerialNumber(filteredtags)}
//                                 columns={columns}
//                                 // isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
//                                 // isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
//                                 uniqueIdField="id"
//                                 // onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
//                                 // isLoading={isLoading}
//                                 totalCount={tagsData?.length}
//                                 pageLimit={15}
//                                checkboxSelection={false}
//                                 // handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
//                             />
            
//             </Card>
// }
//               {/* No Results */}

//                 {filteredtags.length === 0 && searchQuery &&  <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "1rem", padding: "2.5rem 2rem", borderRadius: "1rem", overflowY: "auto"}}>
       
//                 <Box sx={{ textAlign: 'center', py: 8 }}>
//                   <Typography variant="body1" sx={{ color: '#6b7280' }}>
//                     No controllers found matching "{searchQuery}"
//                   </Typography>
//                 </Box>
//               </Card>
//               }
//             </>
//       )}
//     </Box>
//   );
// };

// export default TagsPage;





import React, { useState, useMemo, useCallback, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  TextField,
  InputAdornment,
  IconButton
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import LocalOfferOutlinedIcon from '@mui/icons-material/LocalOfferOutlined';
import { useSelector, useDispatch } from 'react-redux';
import { ClonosButton } from '../../../../CommonComponents/Button/Button';
import { useNavigate } from 'react-router-dom';
import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
import ClonosDataGrid from '../../../../CommonComponents/ClonosDataGrid/ClonosDataGrid';
import { commonPageState, getFormatedDate, handleClientDateInConfiguredTimeZone, setSerialNumber } from '../../../../../utils/clonosCommon';
import { Switch } from "@material-ui/core";
import EditOutlinedIcon from "@material-ui/icons/EditOutlined";
import DeleteOutlineOutlinedIcon from "@material-ui/icons/DeleteOutlineOutlined";
import { IoDocumentTextOutline } from 'react-icons/io5';
import Styles from '../../plc.module.css';
import * as XLSX from "xlsx";
import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
import useToggler from '../../../../../CustomHooks/TogglerHook';
import { handleDeleteTag, handleGetAllTags } from '../plc-manager';
import ClonosConfirmationBox from '../../../../CommonComponents/ClonosConfirmationBox/ClonosConfirmationBox';
import { doDeleteApiCall } from '../../../../../utils/ClonosApi';

const TagsPage = () => {
  const tagsData = useSelector(store => store.plcData.tags);
  const controllerData = useSelector(store => store.plcData.controller);

  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const dispatch = useDispatch();

   const [tagData,setTagData]=useState({})
    const [isLoading, setIsLoading] = useToggler(); 
     const [refreshApi,setRefreshApi]=useToggler()
       const [pagination, setPagination] = useState(commonPageState);
       const [showConfirmationDailog, setShowConfirmationDailog] = useState(false);
       const [selectedTagId, setSelectedTagId] = useState(null);


        const [loadersAndFlags,setLoadersAndFlags] = useState({
                 deleteTagAlert:false,
                 deleteLoading:false,
                 
             })
  
  
  const tagsArray = useMemo(() => (
    Array.isArray(tagData?.data) ? tagData?.data : tagData?.data ? [tagData?.data] : []
  ), [tagData?.data]);


  const controllersArray = useMemo(() => (
    Array.isArray(controllerData) ? controllerData : controllerData ? [controllerData] : []
  ), [controllerData]);

  const filteredtags = useMemo(() => {
    const q = searchQuery.toLowerCase();
    return tagsArray.filter(tag =>
      tag?.controllerName?.toLowerCase().includes(q) || tag?.value?.name.toLowerCase().includes(q)
    );
  }, [tagsArray, searchQuery]);

//   const filteredtags = useMemo(() => {
//   const q = searchQuery.toLowerCase();

//   return tagsArray.filter(tag => {
//     const controller = tag?.controllerName?.toLowerCase() || "";

//     let valueText = "";

//     if (typeof tag?.value === "object" && tag?.value !== null) {
//       valueText = tag.value?.name?.toLowerCase() || "";
//     } else if (typeof tag?.value === "string") {
//       valueText = tag.value.toLowerCase();
//     }

//     return controller.includes(q) || valueText.includes(q);
//   });
// }, [tagsArray, searchQuery]);




  const controllerOptions = useMemo(() => (
    controllersArray.map(controller => controller.controllerName)
  ), [controllersArray]);

 


  const handleExportExcel = useCallback(() => {
    if (!filteredtags.length) return;

    const exportableColumns = columns.filter(col => col.field !== "actions");

    const excelData = filteredtags.map(row => {
      const rowData = {};
      exportableColumns.forEach(col => {
        let value = "-";
        if (col.field === "status") value = "Active";
        else if (col.valueGetter) value = col.valueGetter({ row }) ?? "-";
        else value = row[col.field] ?? "-";
        rowData[col.headerName] = value;
      });
      return rowData;
    });

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Tags");
    XLSX.writeFile(workbook, "Tags_Report.xlsx");
  }, [filteredtags]);




  const columns = useMemo(() => ([
    {
            field: "index",
            headerName: "SI.No",
            // flex: 1,
            width: "50",
            disableColumnFilter: true,
            headerClassName: "ast_column_header",
        },

      {
      field: "name",
      headerName: "TAG NAME",
      flex: 1,
      renderCell: (params) => {
  
        return <span>
          {params.row?.value?.name ?? params.row?.value ?? "-"}
        </span>
      },
    },

    {
      field: "controllerName",
      headerName: "CONTROLLER NAME",
      flex: 1,
      renderCell: (params) => <span>{params.row.controllerName || "-"}</span>,
    },
    {
      field: "networkType",
      headerName: "NETWORK",
      flex: 1,
      renderCell: (params) => <span>{params.row.networkType}</span>,
    },
   {
  field: "status",
  headerName: "STATUS",
  flex: 1,
  renderCell: (params) => {
    const isActive = params.row.isActive;

    return (
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <Switch
          checked={isActive}
          size="small"
          color="primary"
          // onChange={() => handleStatusToggle(params.row)}
        />
        <span
          style={{
            color: isActive ? "#16a34a" : "#dc2626",
            fontSize: 14
          }}
        >
          {isActive ? "Active" : "Inactive"}
        </span>
      </div>
    );
  },
},

    {
      field: "createdAt",
      headerName: "CREATED ON",
      // width: "200",
      flex: 1,
      disableColumnFilter: true,
      headerClassName: "ast_column_header",
      valueGetter: (params) => params?.row?.createdAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params?.row?.createdAt,parseType:"string"})) : "-"
    },
    {
      field: "updatedAt",
      headerName: "UPDATED ON",
      // width: "200",
      flex: 1,
      disableColumnFilter: true,
      headerClassName: "ast_column_header",
      valueGetter: (params) => params?.row?.updatedAt ? getFormatedDate(handleClientDateInConfiguredTimeZone({dateString:params?.row?.updatedAt,parseType:"string"})) : "-"
    },
    {
      field: "actions",
      headerName: "ACTIONS",
      flex: 0.7,
      sortable: false,
      renderCell: (params) => (
        <div style={{ display: "flex", gap: 8 }}>
          <IconButton
            size="small"
            onClick={() =>
              navigate(`/edit-tag/${params.row.id}`, {
                state: { id: params.row.id }
              })
            }
          >
            <EditOutlinedIcon style={{ color: "#8b9bb4" }} />
          </IconButton>
          <IconButton
            size="small"
             onClick={() => {
              setSelectedTagId(params?.row?.id);  
              setShowConfirmationDailog(true);
            }}
          >
            <DeleteOutlineOutlinedIcon style={{ color: "#dc2626" }} />
          </IconButton>
        </div>
      ),
    },
  ]), [handleDeleteTag, navigate]);



//   const handleExportExcel = useCallback(() => {
//   if (!filteredtags.length) return;

//   const exportableColumns = columns.filter(col => col.field !== "actions");

// const excelData = filteredtags.map((row, index) => {
//   const rowData = {};

//   exportableColumns.forEach(col => {
//     let value = "-";

//     // ✅ Handle SI column properly
//     if (col.field === "index") {
//       value = index + 1;
//     }

//     else if (col.field === "status") {
//       value = row.isActive ? "Active" : "Inactive";
//     }

//     else if (col.field === "name") {
//       if (typeof row.value === "object" && row.value !== null) {
//         value = row.value?.name ?? "-";
//       } else {
//         value = row.value ?? "-";
//       }
//     }

//     else if (col.valueGetter) {
//       value = col.valueGetter({ row }) ?? "-";
//     }

//     else {
//       value = row[col.field] ?? "-";
//     }

//     rowData[col.headerName] = value;
//   });

//   return rowData;
// });


//   const worksheet = XLSX.utils.json_to_sheet(excelData);
//   const workbook = XLSX.utils.book_new();
//   XLSX.utils.book_append_sheet(workbook, worksheet, "Tags");
//   XLSX.writeFile(workbook, "Tags_Report.xlsx");
// }, [filteredtags, columns]);





  useEffect(()=>{
      handleGetAllTags({dispatch,setterMethod:setTagData,setIsLoading,pagination})
  },[pagination?.page,pagination?.limit,refreshApi])


  return (
  <Box sx={{ p: 3, overFlowY:"auto" }}>
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 1,
        }}
      >
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a1a1a', mb: 0.5 }}>
            Tags
          </Typography>
          <Typography variant="body2" sx={{ color: '#6b7280' }}>
            Create and manage tags based on controller configurations
          </Typography>
        </Box>

        <div style={{ display: "flex", alignItems: "center" }}>
 

        {/* Export */}
       {controllersArray.length > 0 &&  <div
          className={Styles.reportButton}
          onClick={filteredtags.length ? handleExportExcel : undefined}
          style={{
            opacity: filteredtags.length ? 1 : 0.5,
            cursor: filteredtags.length ? "pointer" : "not-allowed",
          }}
        >
          <IoDocumentTextOutline size={20} />
          <span>Export</span>
        </div>
}


        {controllersArray.length > 0 &&
          <ClonosButton
          variant="filled"
          onClick={() => navigate('/create-tag')}
          >
          <AddIcon />  New Tags
          </ClonosButton>
        }
       </div>

        
      </Box>

      {/* Show Controller form when creating */}
     
          {controllersArray.length === 0 ? (
            // Empty State - No Search Bar
            <Box
            sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: '60vh',
                textAlign: 'center',
            }}
            >
            <Box
                sx={{
                width: 80,
                height: 80,
                borderRadius: '50%',
                bgcolor: '#e5e7eb',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mb: 3,
                }}
            >
                <LocalOfferOutlinedIcon sx={{ fontSize: 35, color: '#9ca3af' }} />
            </Box>
            <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
                Create a controller first
            </Typography>
            <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
               You need to create at least one controller before you can create tags
            </Typography>
            </Box> 
          ) : tagsArray.length === 0 ?(
            // Empty State - No Search Bar
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: '60vh',
                textAlign: 'center',
              }}
            >
              <Box
                sx={{
                  width: 80,
                  height: 80,
                  borderRadius: '50%',
                  bgcolor: '#e5e7eb',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  mb: 3,
                }}
              >
                <LocalOfferOutlinedIcon sx={{ fontSize: 35, color: '#9ca3af' }} />
              </Box>
              <Typography variant="h6" sx={{ fontWeight: 500, mb: 1, color: '#1a1a1a' }}>
                No Tags yet
              </Typography>
              <Typography variant="body2" sx={{ color: '#6b7280', mb: 3, maxWidth: 400 }}>
                Create your first tag to start configuring your controllers
              </Typography>
              <ClonosButton
                variant="outlined"
                onClick={() => navigate('/create-tag')}
    
                >
                 <AddIcon />  Create Tag
                </ClonosButton>
            </Box>
          ) : (
            <>
              {/* Search Bar - Only show when controllers exist */}
             
                {/* <Grid  item xs={12} sm={6} md={4} lg={3}>

                     <Box   sx={{ mt: 3, mb: 3 ,BorderColor:"black"}}>
                <TextField
                  fullWidth
                  placeholder="Search controllers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon sx={{ color: '#212223' }} />
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    // maxWidth: 560,
                    bgcolor: '#ffffff',
                    borderRadius: 2,
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 2,
                      '& fieldset': {
                        borderColor: '#494a4d',
                      },
                      '&:hover fieldset': {
                        borderColor: '#444546',
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: '#06b6d4',
                      },
                    },
                    '& .MuiOutlinedInput-input': {
                      py: 1.5,
                      color: '#1a1a1a',
                      '&::placeholder': {
                        color: '#9ca3af',
                        opacity: 1,
                      },
                    },
                  }}
                />

                  

              </Box>

                  <ClonosSelect
                    tabIndex={2}
                    type="select"
                    // isMandatory={true}
                    isLabel={false}
                    uniqueKey="controllerName"
                    placeholder="All Controller"
                    // defaultValue={formData?.type?.name}
                    options={[]}
                    // handleGetValues={handleGetValues}
                    // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />

                     <ClonosSelect
                    tabIndex={2}
                    type="select"
                    // isMandatory={true}
                    isLabel={false}
                    uniqueKey="Status"
                    placeholder="All Status"
                    // defaultValue={formData?.type?.name}
                    options={[]}
                    // handleGetValues={handleGetValues}
                    // handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />

                </Grid> */}
                 
            <Grid item xs={12}>
              <Box
                sx={{
                  mt: 3,
                  mb: 3,
                  display: "flex",
                  alignItems: "center",
                  gap: 2,
                }}
              >
                {/* Search */}
                <TextField
                  placeholder="Search controllers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon sx={{ color: "#212223" }} />
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    flex: 1, // 👈 takes remaining space
                    bgcolor: "#ffffff",
                    borderRadius: 2,
                    "& .MuiOutlinedInput-root": {
                      borderRadius: 2,
                      "& fieldset": {
                        borderColor: "#494a4d",
                      },
                      "&:hover fieldset": {
                        borderColor: "#444546",
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "#06b6d4",
                      },
                    },
                    "& .MuiOutlinedInput-input": {
                      py: 1.5,
                      color: "#1a1a1a",
                      "&::placeholder": {
                        color: "#9ca3af",
                        opacity: 1,
                      },
                    },
                  }}
                />

                {/* Controller dropdown */}
                <Box sx={{ minWidth: 180,Height:10 }}>
                  <ClonosSelect
                    tabIndex={2}
                    type="select"
                    isLabel={false}
                    uniqueKey="controllerName"
                    placeholder="All Controller"
                    options={controllerOptions.map((cont) => ({
                  label: cont,
                  value: cont,
                  isNeeded: true,
                }))}
                  />
                </Box>

                {/* Status dropdown */}
                <Box sx={{ minWidth: 160 ,Height:10 }}>
                  <ClonosSelect
                    tabIndex={2}
                    type="select"
                    isLabel={false}
                    uniqueKey="Status"
                    placeholder="All Status"
                    options={[{label:"Active",value:"Active",isNeeded:true},{label:"In Active",value:"In Active",isNeeded:true},]}
                  
                    
                  />
                </Box>
              </Box>
            </Grid>
           {filteredtags.length > 0 &&   <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "0rem", padding: "1.5rem", borderRadius: "1rem", overflowY: "auto"}}>
                           <ClonosDataGrid
                                // rows={setSerialNumber(filteredtags.map(tag => ({ ...tag,id: tag._id })),pagination.page,pagination.limit)}
                                rows={setSerialNumber(filteredtags,pagination.page,pagination.limit)}
                                columns={columns}
                                // isEditMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_UPDATE }) ? handleEditWorkOrder : false}
                                // isDeleteMethod={checkUserHasPermission({ moduleName: moduleName, action: CLONOS_GLOBAL_ACTION_DELETE }) ? () => setDeleteWorkOrderAlert(true) : false}
                                uniqueIdField="id"
                                onPageChange={e => setPagination({ page: e.page + 1, limit: e.pageSize })}
                                isLoading={isLoading}
                                totalCount={tagData?.total}
                                pageLimit={pagination.limit}
                               checkboxSelection={false}
                                // handleGetSelectedRowsMethod={(val) => setSelectedRows(val?.selectedRows)}
                            />

<ClonosConfirmationBox
  isOpen={showConfirmationDailog}
  loading={loadersAndFlags?.deleteTagAlert}
  confirmingMethod={() => {
    handleDeleteTag({
      selectedTagId,
      setIsLoading,
      next: () => {
        setRefreshApi();
        setShowConfirmationDailog(false);
        setSelectedTagId(null);
      }
    });
  }}
  closeModalMethod={() => setShowConfirmationDailog(false)}
  headerTitle="Delete Tag"
  message="Are you sure that you want to delete this Tag?"
/>

            
            </Card>

            
}
              {/* No Results */}

                {filteredtags.length === 0 && searchQuery &&  <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : "1rem", padding: "2.5rem 2rem", borderRadius: "1rem", overflowY: "auto"}}>
       
                <Box sx={{ textAlign: 'center', py: 8 }}>
                  <Typography variant="body1" sx={{ color: '#6b7280' }}>
                    No controllers found matching "{searchQuery}"
                  </Typography>
                </Box>


            
              </Card>




              }
            </>
      )}
    </Box>
  );
};

export default TagsPage;
