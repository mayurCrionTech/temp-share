import React from 'react'

function StagePage() {
  return (
    <div>StagePage</div>
  )
}

export default StagePage