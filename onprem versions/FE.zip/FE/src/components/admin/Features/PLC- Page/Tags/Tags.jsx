// import React, { useState, useEffect } from 'react';
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Grid,
//   IconButton,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Chip,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   Switch
// } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
// import DeleteOutlineIcon from '@material-ui/icons/DeleteOutline';
// import EditIcon from '@material-ui/icons/Edit';
// import SearchIcon from '@material-ui/icons/Search';
// import ClonosInput from '../../../../CommonComponents/ClonosInput/ClonosInput';
// import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { handleGetFilledValuesOfPlc } from '../plc-manager';
// import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
// import Styles from '../../plc.module.css'
// import Plus_Icon from '../../../../../assets/UIUX/icons/WO/WO_Plus.svg'
// import TEMPLATE_CREATION_REMOVEROW from "../../../../../assets/UIUX/icons/Checklist/circle-minus.svg";
// import TEMPLATE_CREATION_GRIP_VERTICAL from "../../../../../assets/UIUX/icons/Checklist/grip-vertical.svg";
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer'
// import { useDispatch } from 'react-redux';
// import { useSelector } from 'react-redux';
// import { useLocation, useNavigate } from 'react-router-dom';
// import { Height } from '@material-ui/icons';

// const useStyles = makeStyles((theme) => ({
//   root: {
//     padding: theme.spacing(3),
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: theme.spacing(3),
//   },
//   card: {
//     marginBottom: theme.spacing(3),
//   },
//   parameterRow: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: theme.spacing(2),
//     marginBottom: theme.spacing(2),
//     padding: theme.spacing(2),
//     border: '1px solid #e0e0e0',
//     borderRadius: '4px',
//   },
//   addButton: {
//     marginTop: theme.spacing(2),
//   },
//   searchBox: {
//     marginBottom: theme.spacing(2),
//   },
//   statusChip: {
//     marginLeft: theme.spacing(1),
//   },
//   actionButtons: {
//     display: 'flex',
//     gap: theme.spacing(1),
//   }
// }));

// const Tags= ({mode}) => {
//   const classes = useStyles();
//  const dispatch =useDispatch()
//   const [formData, setFormData] = useState({});
//   const [activeParamId, setActiveParamId] = useState(null);
//   const navigate= useNavigate()
//   const location=useLocation();
//   console.log(location,"location")
   
//  const controllerData = useSelector((store)=>store.plcData.controller)
//   const tagsData = useSelector((store)=>store.plcData.tags)
//   console.log(mode,"mode")
//  console.log(controllerData,"controllerData")

   
//   const {
//           handleGetErrorActivatorInformation,
//           handlePrimaryObjectModifier,
//           handleSubmit,
//           handleGetUpdatedPrimaryObject,
//           handleRemoveField,
//           primaryObject
//         } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "Plc" });

    

//  const selectedController = controllerData.find(
//   (c) => c.name === formData?.controllerName?.name
// );


  



// console.log(selectedController,"selectedController")


//     const handleGetValues = (props) => {
//       console.log(props,"props")
//           handleGetFilledValuesOfPlc({fieldProps:props,primaryObject,setFormData,handlePrimaryObjectModifier})
//       }



// console.log(formData,"formData")




// const handleSubmitController = () => {
//   if (mode === "edit") {
//     dispatch(plcActions.updateTags(formData));
//   } else {
//     dispatch(
//       plcActions.setTags({
//         ...formData,
//         id: Date.now()
//       })
//     );
//   }

//   navigate("/plc");
// };



// const editData = tagsData.find(
//     (e) => e.id === location.state?.id
//   );

//   useEffect(() => {
//     if (editData) {
//       setFormData(editData);
//     }
//   }, [editData]);


//   return (
//          <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : " 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto",padding:"1rem" }}>
//       <Box className={classes.header}>
//         <Typography variant="h4">
//                {mode=="edit" ? "Edit Tag" : "Create Tag" }  
//         </Typography>
//       </Box>

//       <div className={classes.card}>
//         <CardContent>
//           <Grid container spacing={3}>
     
//             <Grid item xs={12} md={4}>
//               <ClonosSelect
//                 tabIndex={2}
//                 type="select"
//                 label="Controller Name"
//                 isMandatory={true}
//                 isLabel={true}
//                 uniqueKey="controllerName"
//                 placeholder="Select controller Name"
//                 defaultValue={formData?.controllerName?.name}
//                 options={controllerData.map((controller)=>({label:controller.name,value:controller.name,isNeeded:true}))}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>
            
//              {/* <Grid item xs={12} md={4} >
//               <ClonosInput
//                 tabIndex={3}
//                 label="Tag Name"
//                 isLabel={true}
//                 placeholder="Enter Tag Name"
//                 isMandatory={true}
//                 type="text"
//                 limit="15"
//                 uniqueKey="tagName"
//                 defaultValue={formData.tagName}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid> */}
          
//           </Grid>


//           {/* Dynamic Parameters Section */}
         
//       {/* Header */}
//           <Box display="flex" justifyContent="space-between" alignItems="center" mt={3}>
//             <Typography variant="h6">Parameter Values</Typography>
//           </Box>

//           {selectedController?.parameters?.length > 0 ?(
//             selectedController.parameters.map((param)=>(
//                <Grid item xs={12} md={4}   key={param.id}>
//                 <Box mb={2} mt={2}>
//                 {param.dataType ==="text" &&(
//                       <ClonosInput
//                     tabIndex={3}
//                     label={param.name}
//                     isLabel={selectedController.type.name =="Ethernetip" ? false :true}
//                     placeholder={selectedController.type.name =="Ethernetip" ? "Enter Name" : `Enter ${param.name}`}
//                     // isMandatory={true}
//                     type={param.dataType}
//                     limit="15"
//                     uniqueKey={param.name}
//                     defaultValue={formData?.[param.name] || ""}

//                     handleGetValues={handleGetValues}
//                     handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                   />
//                 )}


//                     {param.dataType ==="number" &&(
//                       <ClonosInput
//                     tabIndex={3}
//                     label={param.name}
//                     isLabel={true}
//                     placeholder={`Enter ${param.name}`}
//                     // isMandatory={true}
//                     type={param.dataType}
//                     limit="15"
//                     uniqueKey={param.name}
//                    defaultValue={formData?.[param.name] || ""}
//                     handleGetValues={handleGetValues}
//                     handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                   /> 
//                 )}

//                  {param.dataType === "dropdown" &&(
//                        <ClonosSelect
//                 tabIndex={2}
//                 label={param.name}
//                 // isMandatory={true}
//                 type="select"
//                 isLabel={true}
//                 uniqueKey={param.name}
//                placeholder={`Select ${param.name}`}
//               defaultValue={formData?.[param.name]?.name || ""}

//                 options={param.options.map((opt) => ({
//       label: opt,
//       value: opt,
//       isNeeded: true,
//     }))}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//                  )}

//                </Box>
//                </Grid>
//             ))

//           ):(
//              <Typography color="textSecondary" style={{ padding: "16px" }}>
//               No parameters available for this controller
//             </Typography>
//           )
//           }

          
         

//           {/* Action Buttons */}
//           <Box mt={4} display="flex" justifyContent="flex-end" gap={2} >
//             <ClonosButton variant="outlined" onClick={()=>navigate(-1)}>
//               Cancel
//             </ClonosButton>
//             &nbsp;
//             <ClonosButton variant="filled" onClick={handleSubmitController}>
//                  {mode=="edit" ? "Update" : "Submit" }  
//             </ClonosButton>
//           </Box>
//         </CardContent>
//       </div>
//     </Card>
//   );
// };

// export default Tags;


//optimizedcode

// import React, { useState, useEffect, useMemo, useCallback } from 'react';
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Grid
// } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import ClonosInput from '../../../../CommonComponents/ClonosInput/ClonosInput';
// import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
// import { ClonosButton } from '../../../../CommonComponents/Button/Button';
// import { handleGetFilledValuesOfPlc } from '../plc-manager';
// import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
// import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
// import { useDispatch, useSelector } from 'react-redux';
// import { useLocation, useNavigate } from 'react-router-dom';

// const useStyles = makeStyles((theme) => ({
//   root: { padding: theme.spacing(3) },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: theme.spacing(3),
//   },
//   card: { marginBottom: theme.spacing(3) }
// }));

// const Tags = ({ mode }) => {
//   const classes = useStyles();
//   const dispatch = useDispatch();
//   const navigate = useNavigate();
//   const location = useLocation();

//   const [formData, setFormData] = useState({});

//   const controllerData = useSelector((store) => store.plcData.controller);
//   const tagsData = useSelector((store) => store.plcData.tags);

//   const {
//     handleGetErrorActivatorInformation,
//     handlePrimaryObjectModifier,
//     primaryObject
//   } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "Plc" });

//   /* -------------------- MEMOIZED VALUES -------------------- */

//   const controllerOptions = useMemo(
//     () =>
//       controllerData.map((controller) => ({
//         label: controller.name,
//         value: controller.name,
//         isNeeded: true
//       })),
//     [controllerData]
//   );

//   const selectedController = useMemo(
//     () =>
//       controllerData.find(
//         (c) => c.name === formData?.controllerName?.name
//       ),
//     [controllerData, formData?.controllerName?.name]
//   );

//   const editData = useMemo(
//     () => tagsData.find((e) => e.id === location.state?.id),
//     [tagsData, location.state?.id]
//   );

//   /* -------------------- CALLBACKS -------------------- */

//   const handleGetValues = useCallback(
//     (props) => {
//       handleGetFilledValuesOfPlc({
//         fieldProps: props,
//         primaryObject,
//         setFormData,
//         handlePrimaryObjectModifier
//       });
//     },
//     [primaryObject, handlePrimaryObjectModifier]
//   );

//   const handleSubmitController = useCallback(() => {
//     if (mode === "edit") {
//       dispatch(plcActions.updateTags(formData));
//     } else {
//       dispatch(
//         plcActions.setTags({
//           ...formData,
//           id: Date.now()
//         })
//       );
//     }
//     navigate("/plc");
//   }, [dispatch, formData, mode, navigate]);

//   /* -------------------- EFFECT -------------------- */

//   useEffect(() => {
//     if (editData) {
//       setFormData(editData);
//     }
//   }, [editData]);

//   /* -------------------- JSX -------------------- */

//   return (
//            <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : " 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto",padding:"1rem" }}>
//       <Box className={classes.header}>
//         <Typography variant="h4">
//                {mode=="edit" ? "Edit Tag" : "Create Tag" }  
//         </Typography>
//       </Box>

//       <div className={classes.card}>
//         <CardContent>
//           <Grid container spacing={3}>
     
//             <Grid item xs={12} md={4}>
//               <ClonosSelect
//                 tabIndex={2}
//                 type="select"
//                 label="Controller Name"
//                 isMandatory={true}
//                 isLabel={true}
//                 uniqueKey="controllerName"
//                 placeholder="Select controller Name"
//                 defaultValue={formData?.controllerName?.name}
//                 options={controllerData.map((controller)=>({label:controller.name,value:controller.name,isNeeded:true}))}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid>
            
//              {/* <Grid item xs={12} md={4} >
//               <ClonosInput
//                 tabIndex={3}
//                 label="Tag Name"
//                 isLabel={true}
//                 placeholder="Enter Tag Name"
//                 isMandatory={true}
//                 type="text"
//                 limit="15"
//                 uniqueKey="tagName"
//                 defaultValue={formData.tagName}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//             </Grid> */}
          
//           </Grid>


//           {/* Dynamic Parameters Section */}
         
//       {/* Header */}
//           <Box display="flex" justifyContent="space-between" alignItems="center" mt={3}>
//             <Typography variant="h6">Parameter Values</Typography>
//           </Box>

//           {selectedController?.parameters?.length > 0 ?(
//             selectedController.parameters.map((param)=>(
//                <Grid item xs={12} md={4}   key={param.id}>
//                 <Box mb={2} mt={2}>
//                 {param.dataType ==="text" &&(
//                       <ClonosInput
//                     tabIndex={3}
//                     label={param.name}
//                     isLabel={selectedController.type.name =="Ethernetip" ? false :true}
//                     placeholder={selectedController.type.name =="Ethernetip" ? "Enter Name" : `Enter ${param.name}`}
//                     // isMandatory={true}
//                     type={param.dataType}
//                     limit="15"
//                     uniqueKey={param.name}
//                     defaultValue={formData?.[param.name] || ""}

//                     handleGetValues={handleGetValues}
//                     handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                   />
//                 )}


//                     {param.dataType ==="number" &&(
//                       <ClonosInput
//                     tabIndex={3}
//                     label={param.name}
//                     isLabel={true}
//                     placeholder={`Enter ${param.name}`}
//                     // isMandatory={true}
//                     type={param.dataType}
//                     limit="15"
//                     uniqueKey={param.name}
//                    defaultValue={formData?.[param.name] || ""}
//                     handleGetValues={handleGetValues}
//                     handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//                   /> 
//                 )}

//                  {param.dataType === "dropdown" &&(
//                        <ClonosSelect
//                 tabIndex={2}
//                 label={param.name}
//                 // isMandatory={true}
//                 type="select"
//                 isLabel={true}
//                 uniqueKey={param.name}
//                placeholder={`Select ${param.name}`}
//               defaultValue={formData?.[param.name]?.name || ""}

//                 options={param.options.map((opt) => ({
//       label: opt,
//       value: opt,
//       isNeeded: true,
//     }))}
//                 handleGetValues={handleGetValues}
//                 handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
//               />
//                  )}

//                </Box>
//                </Grid>
//             ))

//           ):(
//              <Typography color="textSecondary" style={{ padding: "16px" }}>
//               No parameters available for this controller
//             </Typography>
//           )
//           }

          
         

//           {/* Action Buttons */}
//           <Box mt={4} display="flex" justifyContent="flex-end" gap={2} >
//             <ClonosButton variant="outlined" onClick={()=>navigate(-1)}>
//               Cancel
//             </ClonosButton>
//             &nbsp;
//             <ClonosButton variant="filled" onClick={handleSubmitController}>
//                  {mode=="edit" ? "Update" : "Submit" }  
//             </ClonosButton>
//           </Box>
//         </CardContent>
//       </div>
//     </Card>
//   );
// };

// export default Tags;




import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import ClonosInput from '../../../../CommonComponents/ClonosInput/ClonosInput';
import ClonosSelect from '../../../../CommonComponents/ClonosSelect/ClonosSelect';
import { ClonosButton } from '../../../../CommonComponents/Button/Button';
import { handleCreateTag, handleEditTag, handleGetFilledValuesOfPlc, handleGetSingleTag } from '../plc-manager';
import useFieldsChecker from '../../../../../CustomHooks/FieldsValidatorHook';
import { plcActions } from '../../../../../Store/Reducers/ClonosPlcReducer';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { handleShowErrorAndWarning } from '../../../../../utils/clonosCommon';

const useStyles = makeStyles((theme) => ({
  root: { padding: theme.spacing(3) },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing(3),
  },
  card: { marginBottom: theme.spacing(3) }
}));

const Tags = ({ mode }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const Location = useLocation();

  const [formData, setFormData] = useState({});

  const controllerData = useSelector((store) => store.plcData.controller);
  const tagsData = useSelector((store) => store.plcData.tags);

 
  const {
    handleGetErrorActivatorInformation,
    handlePrimaryObjectModifier,
    primaryObject
  } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: "Plc" });

  /* -------------------- MEMOIZED VALUES -------------------- */


   const [loadersAndFlags,setLoadersAndFlags] = useState({
            saveTagLoading:false,
            getTagLoading:false,
            editTagLoading:false
        })
 

const controllerMap = useMemo(() => {
  const map = new Map();
  controllerData.forEach(c => map.set(c._id, c));
  return map;
}, [controllerData]);

const selectedController = controllerMap.get(formData?.controllerName?.id || formData?.controllerId);




  // const editData = useMemo(
  //   () => tagsData.find((e) => e.id === location.state?.id),
  //   [tagsData, location.state?.id]
  // );

  /* -------------------- CALLBACKS -------------------- */

  const handleGetValues = useCallback(
    (props) => {
      handleGetFilledValuesOfPlc({
        fieldProps: props,
        primaryObject,
        setFormData,
        handlePrimaryObjectModifier
      });
    },
    [primaryObject, handlePrimaryObjectModifier]
  );

  const handleSubmitController = useCallback(() => {

     const next = () => {
            navigate("/plc");
            handleShowErrorAndWarning({dispatch,message:` Tag ${mode === "create"? "created" : "updated"} successfully.`,type:"success",showTime:"5000"})
     }

    if (mode === "edit") {
      // dispatch(plcActions.updateTags(formData));
      handleEditTag({dispatch,payload:formData,tagId:Location?.state?.id,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,editTagLoading:!prev.editTagLoading})),next})
    } else {

      handleCreateTag({dispatch,payload:formData,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,saveTagLoading:!prev.saveTagLoading})),next})
            
      // dispatch(
      //   plcActions.setTags({
      //     ...formData,
      //     id: Date.now()
      //   })
      // );
    }
  }, [dispatch, formData, mode, navigate]);

  /* -------------------- EFFECT -------------------- */

  // useEffect(() => {
  //   if (editData) {
  //     setFormData(editData);
  //   }
  // }, [editData]);


 useEffect(()=>{
 
   if(mode=="edit"){
      handleGetSingleTag({setterMethod:setFormData,tagId: Location?.state?.id ,setIsLoading:() => setLoadersAndFlags(prev => ({...prev,getTagLoading:!prev.getTagLoading}))})
   }
 
   },[mode,Location?.state?.id])

// console.log(editData,"editData")
  /* -------------------- JSX -------------------- */

  return (
           <Card variant="outlined" style={{ flex: 1, margin: (URL?.unity || URL?.AR || URL?.VR) ? "1rem 1rem 1rem 1rem" : " 1rem", borderRadius: "0rem 0rem 1rem 1rem", display: 'flex', flexDirection: 'column', overflowY: "auto",padding:"1rem" }}>
      <Box className={classes.header}>
        <Typography variant="h4">
               {mode=="edit" ? "Edit Tag" : "Create Tag" }  
        </Typography>
      </Box>

      <div className={classes.card}>
        <CardContent>
          <Grid container spacing={3}>
     
            <Grid item xs={12} md={4}>
              <ClonosSelect
                tabIndex={2}
                type="select"
                label="Controller Name"
                isMandatory={true}
                isLabel={true}
                uniqueKey="controllerName"
                placeholder="Select controller Name"
                // defaultValue={formData?.controllerName?.controllerName}
                 defaultValue={formData?.controllerName}
                options={controllerData.map((controller)=>({label:controller.controllerName,value:controller._id,isNeeded:true}))}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </Grid>
            
             {/* <Grid item xs={12} md={4} >
              <ClonosInput
                tabIndex={3}
                label="Tag Name"
                isLabel={true}
                placeholder="Enter Tag Name"
                isMandatory={true}
                type="text"
                limit="15"
                uniqueKey="tagName"
                defaultValue={formData.tagName}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
            </Grid> */}
          
          </Grid>


          {/* Dynamic Parameters Section */}
         
      {/* Header */}
          <Box display="flex" justifyContent="space-between" alignItems="center" mt={3}>
            <Typography variant="h6">Parameter Values</Typography>
          </Box>
   
{
    mode=="edit" && selectedController?.network?.name === "Ethernetip"
    ? (
        <Grid item xs={12} md={4}>
          <Box mb={2} mt={2}>
            <ClonosInput
              tabIndex={3}
              label="Tag"
              isLabel={false}
              placeholder="Enter Name"
              type="text"
              limit="50"
              uniqueKey="value"
              defaultValue={formData?.value || ""}
              handleGetValues={handleGetValues}
              handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
            />
          </Box>
        </Grid>
      )
    : (
            selectedController?.parameters?.length > 0 ?(
            selectedController.parameters.map((param,i)=>(
               
              

               <Grid item xs={12} md={4}   key={param._id}>
                <Box mb={2} mt={2}>
                {param.dataType ==="text" &&(
                      <ClonosInput
                    tabIndex={3}
                    label={param.name}
                    isLabel={selectedController?.network?.name =="Ethernetip" ? false :true}
                    placeholder={selectedController?.network?.name  =="Ethernetip" ? "Enter Name" : `Enter ${param.name}`}
                    // isMandatory={true}
                    type={param.dataType}
                    limit="50"
                    uniqueKey={param.name ?? `tag${i+1}`}
                    // defaultValue={formData?.[param.name] || ""}
                   defaultValue={formData?.value?.[param.name] || ""}

                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  />
                )}


                    {param.dataType ==="number" &&(
                      <ClonosInput
                    tabIndex={3}
                    label={param.name}
                   isLabel={selectedController?.network?.name =="Ethernetip" ? false :true}
                    placeholder={selectedController?.network?.name  =="Ethernetip" ? "Enter Name" : `Enter ${param.name}`}
                    // isMandatory={true}
                    type={param.dataType}
                    limit="15"
                    uniqueKey={param.name ?? `tag${i+1}`}
                  //  defaultValue={formData?.[param.name] || ""}
                 defaultValue={formData?.value?.[param.name] || ""}
                    handleGetValues={handleGetValues}
                    handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                  /> 
                )}

                 {/* {param.dataType === "dropdown" &&(
                       <ClonosSelect
                tabIndex={2}
                label={param.name}
                // isMandatory={true}
                type="select"
                isLabel={true}
                uniqueKey={param.name}
               placeholder={`Select ${param.name}`}
              defaultValue={formData?.[param.name]?.name || ""}

                options={param.options.map((opt) => ({
      label: opt,
      value: opt,
      isNeeded: true,
    }))}
                handleGetValues={handleGetValues}
                handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
              />
                 )} */}

               </Box>
               </Grid>
            ))

          ):(
             <Typography color="textSecondary" style={{ padding: "16px" }}>
              No parameters available for this controller
            </Typography>
          )
        
      )
}



      


    


          
         

          {/* Action Buttons */}
          <Box mt={4} display="flex" justifyContent="flex-end" gap={2} >
            <ClonosButton variant="outlined" onClick={()=>navigate(-1)}>
              Cancel
            </ClonosButton>
            &nbsp;
            <ClonosButton variant="filled" onClick={handleSubmitController}>
                 {mode=="edit" ? "Update" : "Submit" }  
            </ClonosButton>
          </Box>
        </CardContent>
      </div>
    </Card>
  );
};

export default Tags;
