

// export const handleGetWorkOrderPriorities = ({setterMethod}) => {
//     doGetApiCall({url:AppUrl.getWorkOrderConstants})
//     .then(res => {
//         if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
//             const data = res?.data?.result;
//             setterMethod(data?.priority)
//         }
//     })
// }

import { CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS, CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS } from "../../../../Constants/Constant";
import { plcActions } from "../../../../Store/Reducers/ClonosPlcReducer";
import { doDeleteApiCall, doGetApiCall, doPostApiCall, doPutApiCall } from "../../../../utils/ClonosApi";

// //  TO CHECK THE UNIQUNESS OF FIELD
// const uniqueFieldHandler = ({ module, mode, fieldName,updatedValue,fieldValue, primaryObject, handlePrimaryObjectModifier, setFormData, setChangedData }) => {
//     handleCheckUniqueFieldsMethod({ module, fieldName, fieldValue,updatedValue }).then((res) => {
//         if (res === "unique") {
//             const valueSetter = handlePrimaryObjectModifier({ uniqueKey: fieldName, response: fieldValue })
//             setFormData((prev) => {
//                 return { ...prev, [fieldName]: updatedValue }
//             })
//             if (mode === "edit") setChangedData((prev) => ({ ...prev, [fieldName]: fieldValue }))
//         } else if (res === "not_unique") {
//             primaryObject[fieldName] = { ...primaryObject?.[fieldName], value: false };
//             primaryObject?.[fieldName]?.errorActivatorMethod(true);
//             primaryObject?.[fieldName]?.errorSetterMethod(`Already exists, please provide different ${fieldName}.`)
//         }
//     })
// }




export const handleGetFilledValuesOfPlc = ({fieldProps,primaryObject,setFormData,handlePrimaryObjectModifier,mode,setChangedData,serverResponse,formData}) => {
    const {type,uniqueKey,updatedValue,selectedOption,files} = fieldProps;
    if (type === "dynamicDropdown") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: selectedOption })
        setFormData((prev) => ({ ...prev, [uniqueKey]: selectedOption?.map(opt => ({name:opt?.name,id:opt?.id}))}))
    } else if (type === "select") {
            const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })

              // 🔥 SPECIAL CASE: Network (type) cleared → FULL RESET
        if (uniqueKey === "type" && !updatedValue) {
            setFormData({});
            return;
        }
            setFormData((prev) => ({...prev,[uniqueKey]:{name:updatedValue?.label,id:updatedValue?.value}}))
    } else if (type === "text" || type === "date" || type === "time" || type === "datetime-local" || type === "number") {
           
                const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
              
                setFormData((prev) => ({...prev,[uniqueKey]:updatedValue}))
            
    } else if (type === "file") {
        const valueSetter = handlePrimaryObjectModifier({ uniqueKey, response: updatedValue })
        setFormData((prev) => ({ ...prev, [uniqueKey] : files }))
    } else if (type === "checkbox"){
        setFormData(prev => ({...prev,[uniqueKey]:updatedValue}))
    }  
}




// const handleModifyRequestPayload = (payload,mode,isDraftExisting) => {
//     console.log("workpay",payload)
//     const requestPayload = {};
//       if(payload.controllerName)  requestPayload.controllerName = payload.controllerName
//       if(payload.network)  requestPayload.network = payload.network.name
//       if (payload.ipAddress) requestPayload.ipAddress = payload.ipAddress
//       if (payload.unitId) {
//         requestPayload.settings = {
//             ...requestPayload.settings,
//             unitId: payload.unitId
//         };
//         }

//     return requestPayload
// }


// const handleModifyRequestPayload = (payload, mode, isDraftExisting) => {
//   console.log("workpay", payload);

//   const requestPayload = {};

//   if (payload.controllerName) {
//     requestPayload.controllerName = payload.controllerName;
//   }

//   if (payload.network) {
//     requestPayload.network = payload.network;
//   }

//   if (payload.ipAddress) {
//     requestPayload.ipAddress = payload.ipAddress;
//   }

//   // 👇 SETTINGS BASED ON NETWORK TYPE
//   if (payload.network?.name) {
//     requestPayload.settings = {};

//     switch (payload.network.name) {
//       case "Modbus":
//         if (payload.unitId) {
//           requestPayload.settings.unitId = payload.unitId;
//         }
//         break;

//       case "Siemens":
//         if (payload.rack !== undefined) {
//           requestPayload.settings.rack = payload.rack;
//         }
//         if (payload.slot !== undefined) {
//           requestPayload.settings.slot = payload.slot;
//         }
//         break;

//       case "Ethernetip":
//         if (payload.slot !== undefined) {
//           requestPayload.settings.slot = payload.slot;
//         }
//         if (payload.autoDiscover?.name) {
//           requestPayload.settings.autoDiscover =  payload.autoDiscover.name 
//         }
//         break;

//       default:
//         // optional fallback
//         delete requestPayload.settings;
//     }
//   }

//     if (payload.parameters && payload.parameters.length > 0) {
//     requestPayload.parameters = payload.parameters;
//   }

//   if (payload.parameters?.length) {
//   requestPayload.parameters = payload.parameters.map(
//     ({ _id, ...rest }) => rest
//   );
// }


//   return requestPayload;
// };


const handleModifyRequestPayload = (payload, mode, isDraftExisting) => {
  const requestPayload = {};

  if (payload.controllerName) requestPayload.controllerName = payload.controllerName;
  if (payload.network) requestPayload.network = payload.network;
  if (payload.ipAddress) requestPayload.ipAddress = payload.ipAddress;

  // SETTINGS BASED ON NETWORK TYPE
  if (payload.network?.name) {
    requestPayload.settings = {};
    switch (payload.network.name) {
      case "Modbus":
        if (payload.unitId !== undefined) requestPayload.settings.unitId = payload.unitId;
        break;

      case "Siemens":
        if (payload.rack !== undefined) requestPayload.settings.rack = payload.rack;
        if (payload.slot !== undefined) requestPayload.settings.slot = payload.slot;
        break;

      case "Ethernetip":
        if (payload.slot !== undefined) requestPayload.settings.slot = payload.slot;
        if (payload.autoDiscover?.name) requestPayload.settings.autoDiscover = payload.autoDiscover.name;
        break;

      default:
        delete requestPayload.settings;
    }
  }

  // PARAMETERS
  if (payload.parameters?.length) {
    requestPayload.parameters = payload.parameters.map(({ _id, ...rest }) => rest);
  }

  return requestPayload;
};



export const handleCreateController =({dispatch,payload,setIsLoading,next})=>{
      
      

    setIsLoading();
    const requestPayload = handleModifyRequestPayload(payload,"create");
    
    doPostApiCall({url:`plcTags/createController`,payload:requestPayload})
    .then((res) => {
          if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
            next && next()
          }
          
    })
    .finally(() => setIsLoading())


}


export const handleGetAllControllers=({dispatch,setterMethod,setIsLoading})=>{
  setIsLoading()
doGetApiCall({url:`/plcTags/controllers`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
          
            setterMethod(res.data.data.controllers)
            dispatch(plcActions.setController(res.data.data.controllers));
        }
    })
    .finally(setIsLoading)
}



export  const handleGetSingleControllers=({setterMethod,controllerId,setIsLoading})=>{
  setIsLoading()
doGetApiCall({url:`plcTags/controllers/${controllerId}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
         
            setterMethod(res?.data?.data)
            // dispatch(plcActions.setController(res.data.data.controllers));
        }
    })
    .finally(setIsLoading)
}



export const handleEditController =({dispatch,payload,controllerId,setIsLoading,next})=>{
    
      

    setIsLoading();
    const requestPayload = handleModifyRequestPayload(payload,"edit");
    
    doPutApiCall({url:`plcTags/controllers/${controllerId}`,payload:requestPayload})
    .then((res) => {
          if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            next && next()
          }
          
    })
    .finally(() => setIsLoading())


}


export const handleDeleteControllers = ({setIsLoading,controllerId,next}) => {
    setIsLoading()
    doDeleteApiCall({url:`plcTags/controllers/${controllerId}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
            next && next()
        }
    })
    .finally(setIsLoading)
}





// const handleModifyTagsRequestPayload = (payload, mode) => {
//   const { controllerName, ...rest } = payload;

 
//   let requestPayload;

//   if (mode === "edit") {
//     requestPayload = { value: { ...rest } };
//   } else {
//     requestPayload = { ...rest };
//   }

  
//   if (controllerName) {
//     requestPayload.controllerId = controllerName.id;
//     requestPayload.controllerName = controllerName.name;
//   }

//   return requestPayload;
// };


// const handleModifyTagsRequestPayload = (payload, mode) => {
//   const { controllerName, ...rest } = payload;

//   const requestPayload =
//     mode === "edit"
//       ? { value: { ...rest } }
//       : { ...rest };
  
//   if(mode !="edit"){
//       if (controllerName) {
//         requestPayload.controllerId = controllerName.id;
//         requestPayload.controllerName = controllerName.name;
//       }
// }

//   return requestPayload;
// };


const handleModifyTagsRequestPayload = (payload, mode) => {
  if (mode === "edit") {
    // Remove unwanted DB fields ONLY for edit
    const {
      _id,
      controllerId,
      controllerName,
      networkType,
      createdAt,
      updatedAt,
      isActive,
      __v,
      value, // remove old nested value
      ...editableFields
    } = payload;

      if (networkType === "ethernetip") {
      return {
        value: typeof value === "string" ? value : "",
        networkType:networkType
      };
    }

    // ✅ Other networks → spread safely
    return {
      value: { ...editableFields }
    };
  
  }

  // ✅ CREATE MODE (unchanged structure)
  const { controllerName, ...rest } = payload;

  const requestPayload = { ...rest };

  if (controllerName) {
    requestPayload.controllerId = controllerName.id;
    requestPayload.controllerName = controllerName.name;
  }

  return requestPayload;
};


// const handleModifyTagsRequestPayload = (payload, mode) => {
//   const { controllerName, ...rest } = payload;

//   const requestPayload = {
//     ...rest,
//   };

//   if (controllerName) {
//     requestPayload.controllerName = controllerName.name;
//     requestPayload.controllerId = controllerName.id;

//     // ✅ Detect EthernetIP automatically
//     const keys = Object.keys(rest);

//     const isEthernetIP =
//       keys.length > 0 &&
//       keys.every((key) => /^[0-9a-fA-F]{24}$/.test(key)); // Mongo ObjectId check

//     if (isEthernetIP) {
//       const tags = keys.map((key) => rest[key]);

//       // remove dynamic keys
//       keys.forEach((key) => delete requestPayload[key]);

//       requestPayload.tags = tags;
//     }
//   }

//   return requestPayload;
// };






export const handleCreateTag = ({dispatch,payload,setIsLoading,next})=>{
     setIsLoading();
    const requestPayload = handleModifyTagsRequestPayload(payload,"create");
 
    doPostApiCall({url:`plcTags/controllers/tags`,payload:requestPayload})
    .then((res) => {
          if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_CREATE_SUCCESS){
            next && next()
          }
          
    })
    .finally(() => setIsLoading())
}


export const handleGetAllTags=({dispatch,setterMethod,setIsLoading,pagination})=>{
  setIsLoading()
doGetApiCall({url:`/plcTags/controllers/tags`,params:pagination})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
       
            setterMethod(res?.data?.result)
            // dispatch(plcActions.setTags(res.data.tags));
        }
    })
    .finally(setIsLoading)
}


  export const handleDeleteTag = async ({selectedTagId,setIsLoading,next}) => {
    

    doDeleteApiCall({url:`plcTags/controllers/tags/${selectedTagId}`})
        .then(res => {
            if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_DELETE_SUCCESS){
                next && next()
            }
        })
        .finally(setIsLoading)
  
};





export  const handleGetSingleTag=({setterMethod,tagId,setIsLoading})=>{
  setIsLoading()
doGetApiCall({url:`plcTags/controllers/tags/${tagId}`})
    .then(res => {
        if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
           
            setterMethod(res?.data?.tag)
            // dispatch(plcActions.setController(res.data.data.controllers));
        }
    })
    .finally(setIsLoading)
}


export const handleEditTag =({dispatch,payload,tagId,setIsLoading,next})=>{
     
      

    setIsLoading();
    const requestPayload = handleModifyTagsRequestPayload(payload,"edit");

    doPutApiCall({url:`plcTags/controllers/tags/${tagId}`,payload:requestPayload})
    .then((res) => {
          if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_EDIT_SUCCESS){
            next && next()
          }
          
    })
    .finally(() => setIsLoading())


}


export const handleGetTagsPerController =({dispatch,setterMethod,setIsLoading,pagination,controllerId})=>{
    setIsLoading()

  doGetApiCall({url:`plcTags/controllers/${controllerId}/tags`,params:pagination})
      .then(res => {
          if(res?.status === CLONOS_GLOBAL_SERVER_RESPONSE_CODE_GET_SUCCESS) {
              
              setterMethod(res?.data?.tag)
              // dispatch(plcActions.setController(res.data.data.controllers));
          }
      })
      .finally(setIsLoading) 
}