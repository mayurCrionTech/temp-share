// import React, { useState, useMemo } from "react";
// import {
//   Button,
//   Modal,
//   Box,
//   TextField,
//   MenuItem,
//   List,
//   ListItemButton,
//   ListItemText,
// } from "@mui/material";

// const style = {
//   position: "absolute",
//   top: "50%",
//   left: "50%",
//   transform: "translate(-50%, -50%)",
//   width: 400,
//   bgcolor: "background.paper",
//   boxShadow: 24,
//   p: 3,
//   borderRadius: 2,
//   maxHeight: "80vh",
//   overflowY: "auto",
// };

// // Get all IANA timezones
// const timezones = Intl.supportedValuesOf("timeZone");

// // Function for GMT offset like (GMT+05:30)
// const formatGMT = (tz) => {
//   const now = new Date();
//   const formatter = new Intl.DateTimeFormat("en-US", {
//     timeZone: tz,
//     hour12: false,
//     hour: "2-digit",
//     minute: "2-digit",
//   });

//   const parts = formatter.formatToParts(now);
//   const hour = parseInt(parts.find((p) => p.type === "hour").value);
//   const minute = parseInt(parts.find((p) => p.type === "minute").value);

//   // calculate offset
//   const utc = now.getTime() + now.getTimezoneOffset() * 60000;
//   const tzTime = new Date(utc + hour * 3600000 + minute * 60000);
//   const offsetInMin = (tzTime - now) / 60000;

//   const sign = offsetInMin >= 0 ? "+" : "-";
//   const absMin = Math.abs(offsetInMin);
//   const hh = String(Math.floor(absMin / 60)).padStart(2, "0");
//   const mm = String(absMin % 60).padStart(2, "0");

//   return `(GMT${sign}${hh}:${mm})`;
// };

// export default function TimeZonePage({ value, onChange }) {
//   const [open, setOpen] = useState(false);
//   const [search, setSearch] = useState("");

//   // filter timezones
//   const filteredZones = useMemo(() => {
//     return timezones.filter((tz) =>
//       tz.toLowerCase().includes(search.toLowerCase())
//     );
//   }, [search]);

//   return (
//     <>
//       {/* Button */}
//       <Button variant="contained" onClick={() => setOpen(true)}>
//         Select Timezone
//       </Button>

//       {/* Modal */}
//       <Modal open={open} onClose={() => setOpen(false)}>
//         <Box sx={style}>
//           <h3>Select Timezone</h3>

//           {/* Search */}
//           <TextField
//             fullWidth
//             label="Search timezone"
//             value={search}
//             onChange={(e) => setSearch(e.target.value)}
//             sx={{ mb: 2 }}
//           />

//           {/* List */}
//           <List>
//             {filteredZones.map((tz) => {
//               const gmt = formatGMT(tz);
//               return (
//                 <ListItemButton
//   key={tz}
//   disableRipple
//   sx={{
//     "&:hover": {
//       backgroundColor: "action.hover",
//     },
//   }}
//   onClick={() => {
//     onChange(tz);
//     setOpen(false);
//   }}
// >
//   <Box
//     sx={{
//       display: "flex",
//       justifyContent: "space-between",
//       width: "100%",
//       alignItems: "center",
//     }}
//   >
//     {/* Timezone name */}
//     <Box sx={{ fontSize: "0.95rem", fontWeight: 500 }}>
//       {tz}
//     </Box>

//     {/* GMT offset */}
//     <Box
//       sx={{
//         fontSize: "0.85rem",
//         color: "text.secondary",
//         whiteSpace: "nowrap",
//       }}
//     >
//       {gmt}
//     </Box>
//   </Box>
// </ListItemButton>

//               );
//             })}
//           </List>
//         </Box>
//       </Modal>
//     </>
//   );
// }


// import React, { useState, useMemo } from "react";
// import {
//   Box,
//   TextField,
//   List,
//   ListItemButton,
//   Button,
//   Typography,
//   Card
// } from "@mui/material";

// const timezones = Intl.supportedValuesOf("timeZone");

// const formatGMT = (tz) => {
//   const now = new Date();
//   const formatter = new Intl.DateTimeFormat("en-US", {
//     timeZone: tz,
//     hour12: false,
//     hour: "2-digit",
//     minute: "2-digit",
//   });

//   const parts = formatter.formatToParts(now);
//   const hour = parseInt(parts.find((p) => p.type === "hour").value);
//   const minute = parseInt(parts.find((p) => p.type === "minute").value);

//   // calculate offset
//   const utc = now.getTime() + now.getTimezoneOffset() * 60000;
//   const tzTime = new Date(utc + hour * 3600000 + minute * 60000);
//   const offsetInMin = (tzTime - now) / 60000;

//   const sign = offsetInMin >= 0 ? "+" : "-";
//   const absMin = Math.abs(offsetInMin);
//   const hh = String(Math.floor(absMin / 60)).padStart(2, "0");
//   const mm = String(absMin % 60).padStart(2, "0");

//   return `(GMT${sign}${hh}:${mm})`;
// };


// export default function TimezonesPage() {
//   const [search, setSearch] = useState("");
//   const [selected, setSelected] = useState("");

//   const filteredZones = useMemo(
//     () =>
//       timezones.filter((tz) =>
//         tz.toLowerCase().includes(search.toLowerCase())
//       ),
//     [search]
//   );

//   const handleSubmit = () => {
//     console.log("Selected Timezone:", selected);
//     alert(`Selected Timezone: ${selected}`)
//     // API call / global state update here
//   };

//   return (
//      <Card variant="outlined" style={{ flex: 1, margin: "1rem", borderRadius: "1rem" }}>
//     <Box sx={{ p: 3, maxWidth: 600, mx: "auto" }}>
//       <Typography variant="h6" mb={2}>
//         Set Timezone
//       </Typography>

//       <TextField
//         fullWidth
//         label="Search timezone"
//         value={search}
//         onChange={(e) => setSearch(e.target.value)}
//         sx={{ mb: 2 }}
//       />

//       <List sx={{ maxHeight: 400, overflowY: "auto" }}>
//         {filteredZones.map((tz) => (
//           <ListItemButton
//             key={tz}
//             selected={selected === tz}
//             onClick={() => setSelected(tz)}
//           >
//             <Box
//               sx={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 width: "100%",
//               }}
//             >
//               <span>{tz}</span>
//               <span style={{ color: "#777" }}>{formatGMT(tz)}</span>
//             </Box>
//           </ListItemButton>
//         ))}
//       </List>

//       <Button
//         variant="contained"
//         fullWidth
//         sx={{ mt: 2 }}
//         disabled={!selected}
//         onClick={handleSubmit}
//       >
//         Submit
//       </Button>
//     </Box>
//     </Card>
//   );
// }

// import React, { useState, useMemo } from "react";
// import {
//   Box,
//   TextField,
//   List,
//   ListItemButton,
//   Button,
//   Typography,
//   Card,
// } from "@mui/material";

// // Get all IANA timezones
// const timezones = Intl.supportedValuesOf("timeZone");

// // Format GMT offset like (GMT+05:30)
// const formatGMT = (tz) => {
//   try {
//     const now = new Date();

//     // Get the time in the target timezone as ISO string
//     const tzDateStr = now.toLocaleString("en-US", {
//       timeZone: tz,
//       hour12: false,
//     });

//     const [month, day, year, hour, minute, second] = tzDateStr
//       .match(/\d+/g)
//       .map(Number);

//     // Create a date object in target timezone
//     const tzDate = new Date(year, month - 1, day, hour, minute, second);

//     // Offset in minutes = tzDate - UTC
//     const offset = (tzDate.getTime() - now.getTime()) / 60000;

//     const sign = offset >= 0 ? "+" : "-";
//     const hh = String(Math.floor(Math.abs(offset) / 60)).padStart(2, "0");
//     const mm = String(Math.abs(offset) % 60).padStart(2, "0");

//     return `(GMT${sign}${hh}:${mm})`;
//   } catch (e) {
//     return "(GMT+00:00)";
//   }
// };



// export default function TimezonesPage() {
//   const [search, setSearch] = useState("");
//   const [selected, setSelected] = useState(null);

//   // Filter timezones based on search input
//   const filteredZones = useMemo(
//     () =>
//       timezones.filter((tz) =>
//         tz.toLowerCase().includes(search.toLowerCase())
//       ),
//     [search]
//   );

//   const handleSubmit = () => {
//     if (!selected) return;
//     console.log("Selected Timezone:", selected);
//     alert(`Selected Timezone: ${selected} ${formatGMT(selected)}`);
//     setSelected(null)
//     // Here you can call API or update global state
//   };

//   return (
//     <Card
//       variant="outlined"
//       style={{
//         flex: 1,
//         margin: "1rem",
//         borderRadius: "1rem",
//       }}
//     >
//       <Box sx={{ p: 3, maxWidth: 600, mx: "auto" }}>
//         <Typography variant="h6" mb={2}>
//           Set Timezone
//         </Typography>

//         {/* Input field: shows search or selected timezone */}
//         <TextField
//           fullWidth
//           label="Search or select timezone"
//           value={search}
//           onChange={(e) => {
//             setSearch(e.target.value);
//             setSelected(null); // reset selection when typing
//           }}
//           sx={{ mb: 2 }}
//         />

//         {/* Timezone List */}
//         <List sx={{ maxHeight: 400, overflowY: "auto" }}>
//           {filteredZones.map((tz) => (
//             <ListItemButton
//               key={tz}
//               selected={selected === tz}
//               onClick={() => {
//                 setSelected(tz);
//                 setSearch(`${tz} ${formatGMT(tz)}`); // show selected in input
//               }}
//             >
//               <Box
//                 sx={{
//                   display: "flex",
//                   justifyContent: "space-between",
//                   width: "100%",
//                 }}
//               >
//                 <span>{tz}</span>
//                 <span style={{ color: "#777" }}>{formatGMT(tz)}</span>
//               </Box>
//             </ListItemButton>
//           ))}
//         </List>

//         {/* Submit Button */}
//         <Button
//           variant="contained"
//           fullWidth
//           sx={{ mt: 2 }}
//           disabled={!selected}
//           onClick={handleSubmit}
//         >
//           Submit
//         </Button>
//       </Box>
//     </Card>
//   );
// }







// const formatGMT = (tz) => {
//   try {
//     // Use Intl.DateTimeFormat with short timeZoneName
//     const formatter = new Intl.DateTimeFormat("en-US", {
//       timeZone: tz,
//       hour12: false,
//       hour: "2-digit",
//       minute: "2-digit",
//       timeZoneName: "short",
//     });

//     const parts = formatter.formatToParts(new Date());

//     // Extract the GMT offset part
//     let offsetPart = parts.find((p) => p.type === "timeZoneName")?.value || "GMT";

//     // Normalize to (GMT+hh:mm)
//     const match = offsetPart.match(/GMT([+-]\d{1,2})(?::?(\d{2}))?/);

//     if (match) {
//       const sign = match[1][0]; // + or -
//       const hh = match[1].slice(1).padStart(2, "0");
//       const mm = match[2] ? match[2].padStart(2, "0") : "00";
//       return `(GMT${sign}${hh}:${mm})`;
//     }

//     return "(GMT+00:00)"; // fallback
//   } catch (e) {
//     return "(GMT+00:00)"; // fallback
//   }
// };















// import React, { useState, useMemo } from "react";
// import {
//   Box,
//   TextField,
//   List,
//   ListItemButton,
//   Button,
//   Typography,
//   Card,
// } from "@mui/material";
// import { DateTime } from "luxon";
// import { timeZonesActions } from "../../Store/Reducers/ClonosTimeZoneReducer";
// import { useDispatch } from "react-redux";
// import { useSelector } from "react-redux";

// // Get all IANA timezones
// const timezones = Intl.supportedValuesOf("timeZone");

// // Format GMT offset like (GMT+05:30) using Luxon
// const formatGMT = (tz) => {
//   try {
//     const dt = DateTime.now().setZone(tz); // current time in timezone
//     const offset = dt.offset; // offset in minutes
//     const sign = offset >= 0 ? "+" : "-";
//     const hh = String(Math.floor(Math.abs(offset) / 60)).padStart(2, "0");
//     const mm = String(Math.abs(offset) % 60).padStart(2, "0");
//     return `(GMT${sign}${hh}:${mm})`;
//   } catch (e) {
//     return "(GMT+00:00)";
//   }
// };



// export default function TimezonesPage() {
//   const dispatch =useDispatch()
//   const [search, setSearch] = useState("");
//   const [selected, setSelected] = useState(null);

//   const getCurrentTimeZone = useSelector((store)=> store.timeZonesData.timezone)
//   console.log(getCurrentTimeZone,"getCurrentTimeZone")

//   // Filter timezones based on search input
//   const filteredZones = useMemo(
//     () =>
//       timezones.filter((tz) =>
//         tz.toLowerCase().includes(search.toLowerCase())
//       ),
//     [search]
//   );

//   const handleSubmit = () => {
//     if (!selected) return;
//     dispatch((timeZonesActions.setTimezone(selected))); // 🔥 global update
//     alert(`Global Timezone set to: ${selected}`);

//     // Reset selection if needed
//     setSelected(null);
//     setSearch("");
//     // Here you can call API or update global state
//   };

//   return (
//     <Card
//       variant="outlined"
//       style={{
//         flex: 1,
//         margin: "1rem",
//         borderRadius: "1rem",
//       }}
//     >
//       <Box sx={{ p: 3, maxWidth: 600, mx: "auto" }}>
//         <Typography variant="h6" mb={2}>
//           Set Timezone
//         </Typography>

//         {/* Input field: shows search or selected timezone */}
//         <TextField
//           fullWidth
//           label="Search or select timezone"
//           value={search}
//           onChange={(e) => {
//             setSearch(e.target.value);
//             setSelected(null); // reset selection when typing
//           }}
//           sx={{ mb: 2 }}
//         />

//         {/* Timezone List */}
//         <List sx={{ maxHeight: 400, overflowY: "auto" }}>
//           {filteredZones.map((tz) => (
//             <ListItemButton
//               key={tz}
//               selected={selected === tz}
//               onClick={() => {
//                 setSelected(tz);
//                 setSearch(`${tz} ${formatGMT(tz)}`); // show selected in input
//               }}
//             >
//               <Box
//                 sx={{
//                   display: "flex",
//                   justifyContent: "space-between",
//                   width: "100%",
//                 }}
//               >
//                 <span>{tz}</span>
//                 <span style={{ color: "#777" }}>{formatGMT(tz)}</span>
//               </Box>
//             </ListItemButton>
//           ))}
//         </List>

//         {/* Submit Button */}
//         <Button
//           variant="contained"
//           fullWidth
//           sx={{ mt: 2 }}
//           disabled={!selected}
//           onClick={handleSubmit}
//         >
//           Submit
//         </Button>
//       </Box>
//     </Card>
//   );
// }


// import React, { useState, useMemo } from "react";
// import {
//   Box,
//   TextField,
//   MenuItem,
//   Typography,
//   Card,
//   Button,
// } from "@mui/material";
// import { DateTime } from "luxon";
// import { useDispatch, useSelector } from "react-redux";
// import { timeZonesActions } from "../../Store/Reducers/ClonosTimeZoneReducer";

// const timezones = Intl.supportedValuesOf("timeZone");
// const DEFAULT_TZ = "Asia/Kolkata";

// const formatGMT = (tz) => {
//   const offset = DateTime.now().setZone(tz).offset;
//   const sign = offset >= 0 ? "+" : "-";
//   const hh = String(Math.floor(Math.abs(offset) / 60)).padStart(2, "0");
//   const mm = String(Math.abs(offset) % 60).padStart(2, "0");
//   return `GMT${sign}${hh}:${mm}`;
// };

// const getOffsetMinutes = (tz) =>
//   DateTime.now().setZone(tz).offset;

// export default function TimezonesPage() {
//   const dispatch = useDispatch();

//   const globalTZ = useSelector(
//     (store) => store.timeZonesData.timezone
//   );

//   const [selected, setSelected] = useState(
//     globalTZ || DEFAULT_TZ
//   );

//   // 🔥 SORTED FROM - TO +
//   const sortedTimezones = useMemo(() => {
//     return [...timezones].sort(
//       (a, b) => getOffsetMinutes(a) - getOffsetMinutes(b)
//     );
//   }, []);

//   const handleSubmit = () => {
//     dispatch(timeZonesActions.setTimezone(selected));
//     alert(`Timezone set to ${selected}`);
//   };

//   return (
//     <Card sx={{ m: 2, borderRadius: 2 }}>
//       <Box sx={{ p: 3, maxWidth: 450, mx: "auto" }}>
//         <Typography variant="h6" mb={2}>
//           Select Timezone
//         </Typography>

//         {/* ✅ SINGLE DROPDOWN */}
//         <TextField
//           select
//           fullWidth
//           label="Timezone"
//           value={selected}
//           onChange={(e) => setSelected(e.target.value)}
//         >
//           {sortedTimezones.map((tz) => (
//             <MenuItem key={tz} value={tz}>
//               {formatGMT(tz)} — {tz}
//             </MenuItem>
//           ))}
//         </TextField>

//         <Button
//           fullWidth
//           variant="contained"
//           sx={{ mt: 2 }}
//           onClick={handleSubmit}
//         >
//           Save
//         </Button>
//       </Box>
//     </Card>
//   );
// }







// import React, { useEffect, useMemo, useRef, useState } from "react";
// import { Box, Typography, Paper, Card } from "@mui/material";
// import { DateTime } from "luxon";
// import { useDispatch, useSelector } from "react-redux";
// import { timeZonesActions } from "../../Store/Reducers/ClonosTimeZoneReducer";

// /* CONFIG */
// const VISIBLE_ITEMS = 5;
// const ITEM_HEIGHT = 48;
// const DEFAULT_TZ = "Asia/Calcutta"; // Keep your preference
// const PADDING_ITEMS = Math.floor(VISIBLE_ITEMS / 2);

// /* HELPERS */
// const getOffset = (tz) => DateTime.now().setZone(tz).offset;

// const formatLabel = (tz) => {
//   const offset = getOffset(tz);
//   const sign = offset >= 0 ? "+" : "-";
//   const h = String(Math.floor(Math.abs(offset) / 60)).padStart(2, "0");
//   const m = String(Math.abs(offset) % 60).padStart(2, "0");
//   return `${tz} (GMT${sign}${h}:${m})`;
// };

// export default function TimeZonePage() {
//   const dispatch = useDispatch();
//   const wheelRef = useRef(null);

//   const globalTZ = useSelector(
//     (store) => store.timeZonesData.timezone
//   );

//   /* Base timezone list (GMT - → +) */
//   const baseZones = useMemo(() => {
//     return Intl.supportedValuesOf("timeZone")
//       .map((tz) => ({ tz, offset: getOffset(tz) }))
//       .sort((a, b) => a.offset - b.offset);
//   }, []);

//   /* Padding rows for true center selection */
//   const timezones = useMemo(() => {
//     const padding = Array(PADDING_ITEMS).fill(null);
//     return [...padding, ...baseZones, ...padding];
//   }, [baseZones]);



// const defaultBaseIndex = useMemo(() => {
//   // Prioritize: globalTZ > India timezone > UTC
//   return baseZones.findIndex(t => t.tz === globalTZ) >= 0 
//     ? baseZones.findIndex(t => t.tz === globalTZ)
//     : baseZones.findIndex(t => t.tz.includes('Calcutta') || t.tz.includes('Kolkata'));
// }, [globalTZ, baseZones]);

// const [selectedIndex, setSelectedIndex] = useState(() => {
//   const idx = defaultBaseIndex >= 0 ? defaultBaseIndex + PADDING_ITEMS : PADDING_ITEMS;
//   return idx;
// });




//   /* Scroll handler → center selection */
//   const handleScroll = () => {
//     const scrollTop = wheelRef.current.scrollTop;
//     const topIndex = Math.round(scrollTop / ITEM_HEIGHT);
//     const centerIndex = topIndex + PADDING_ITEMS;

//     const zone = timezones[centerIndex];
//     if (zone && zone.tz && centerIndex !== selectedIndex) {
//       setSelectedIndex(centerIndex);
//       dispatch(timeZonesActions.setTimezone(zone.tz));
//     }
//   };

//   /* 🔥 CRITICAL: center Asia/Kolkata AFTER render */
//   useEffect(() => {
//     setTimeout(() => {
//       if (wheelRef.current) {
//         wheelRef.current.scrollTop =
//           (selectedIndex - PADDING_ITEMS) * ITEM_HEIGHT;
//       }
//     }, 0);
//   }, []);
// return (
//   <Card
//     variant="outlined"
//     style={{
//       flex: 1,
//       margin: "1rem",
//       borderRadius: "1rem",
//     }}
//   >
//     <Paper
//       elevation={3}
//       sx={{
//         width: 420,
//         p: 2,
//         mx: "auto",
//         mt: 3,
//         borderRadius: 2,
//       }}
//     >
//       {/* Header */}
//       <Typography textAlign="center" mb={2} fontWeight={600}>
//         Select Timezone
//       </Typography>

//       {/* Top dropdown-like selector (shows current selection) */}
//       <Box
//         sx={{
//           mb: 2,
//           px: 1.5,
//           py: 1,
//           borderRadius: 1,
//           border: "1px solid",
//           borderColor: "divider",
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "space-between",
//           cursor: "pointer",
//           bgcolor: "background.paper",
//         }}
//         // Optional: open a real MUI Select or Dialog on click
//       >
//         <Typography
//           variant="body2"
//           sx={{ color: "text.primary", fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
//         >
//           {timezones[selectedIndex] ? formatLabel(timezones[selectedIndex].tz) : "Select timezone"}
//         </Typography>
//         <Box
//           sx={{
//             width: 0,
//             height: 0,
//             borderLeft: "6px solid transparent",
//             borderRight: "6px solid transparent",
//             borderTop: "6px solid",
//             borderTopColor: "text.secondary",
//             ml: 1,
//           }}
//         />
//       </Box>

//       {/* Wheel container */}
//       <Box sx={{ position: "relative" }}>
//         {/* Scroll wheel */}
//         <Box
//           ref={wheelRef}
//           onScroll={handleScroll}
//           sx={{
//             height: ITEM_HEIGHT * VISIBLE_ITEMS,
//             overflowY: "auto",
//             scrollSnapType: "y mandatory",
//             borderRadius: 1.5,
//             bgcolor: "background.default",
//           }}
//         >
//           {timezones.map((item, i) => (
//             <Box
//               key={i}
//               sx={{
//                 height: ITEM_HEIGHT,
//                 display: "flex",
//                 alignItems: "center",
//                 justifyContent: "center",
//                 scrollSnapAlign: "center",
//                 opacity: item ? 1 : 0,
//                 fontWeight: i === selectedIndex ? 600 : 400,
//                 color:
//                   i === selectedIndex
//                     ? "primary.main"
//                     : "text.secondary",
//                 transform:
//                   i === selectedIndex
//                     ? "scale(1.05)"
//                     : "scale(0.9)",
//                 transition: "0.15s",
//               }}
//             >
//               {item ? formatLabel(item.tz) : ""}
//             </Box>
//           ))}
//         </Box>

//         {/* Center highlight (alarm style) */}
//         <Box
//           sx={{
//             position: "absolute",
//             top: "50%",
//             left: 8,
//             right: 8,
//             height: ITEM_HEIGHT,
//             transform: "translateY(-50%)",
//             borderTop: "2px solid #1976d2",
//             borderBottom: "2px solid #1976d2",
//             borderRadius: 1,
//             pointerEvents: "none",
//             background:
//               "linear-gradient(to bottom, rgba(25,118,210,0.03), rgba(25,118,210,0.08), rgba(25,118,210,0.03))",
//           }}
//         />
//       </Box>

//       {/* Save button */}
//       <Box mt={3} display="flex" justifyContent="center">
//         <button
//           style={{
//             minWidth: 120,
//             padding: "8px 16px",
//             borderRadius: 999,
//             border: "none",
//             background: "#1976d2",
//             color: "#fff",
//             fontWeight: 600,
//             cursor: "pointer",
//           }}
//           onClick={() => {
//             const zone = timezones[selectedIndex];
//             if (zone && zone.tz) {
//               // already dispatching on scroll; this is for explicit save
//               dispatch(timeZonesActions.setTimezone(zone.tz));
//               // TODO: call API / close dialog etc.
//             }
//           }}
//         >
//           Save
//         </button>
//       </Box>
//     </Paper>
//   </Card>
// );
// }



//work2

// import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
// import { Box, Typography, Paper, Card } from "@mui/material";
// import { DateTime } from "luxon";
// import { useDispatch, useSelector } from "react-redux";
// import { timeZonesActions } from "../../Store/Reducers/ClonosTimeZoneReducer";

// /* CONFIG */
// const VISIBLE_ITEMS = 5;
// const ITEM_HEIGHT = 48;
// const DEFAULT_TZ = "Asia/Calcutta";
// const PADDING_ITEMS = Math.floor(VISIBLE_ITEMS / 2);

// /* HELPERS */
// const getOffset = (tz) => DateTime.now().setZone(tz).offset;

// const formatLabel = (tz) => {
//   const offset = getOffset(tz);
//   const sign = offset >= 0 ? "+" : "-";
//   const h = String(Math.floor(Math.abs(offset) / 60)).padStart(2, "0");
//   const m = String(Math.abs(offset) % 60).padStart(2, "0");
//   return `${tz} (GMT${sign}${h}:${m})`;
// };

// export default function TimeZonePage() {
//   const dispatch = useDispatch();
//   const wheelRef = useRef(null);

//   const globalTZ = useSelector((store) => store.timeZonesData.timezone);

//   /* Base timezone list (GMT - → +) */
//   const baseZones = useMemo(() => {
//     return Intl.supportedValuesOf("timeZone")
//       .map((tz) => ({ tz, offset: getOffset(tz) }))
//       .sort((a, b) => a.offset - b.offset);
//   }, []);

//   /* Padding rows for true center selection */
//   const timezones = useMemo(() => {
//     const padding = Array(PADDING_ITEMS).fill(null);
//     return [...padding, ...baseZones, ...padding];
//   }, [baseZones]);

//   /* Default index (find Asia/Calcutta or Kolkata) */
//   const defaultBaseIndex = useMemo(() => {
//     // Try globalTZ first
//     let index = baseZones.findIndex((t) => t.tz === globalTZ);
//     if (index >= 0) return index;

//     // Find India timezone (Calcutta/Kolkata)
//     index = baseZones.findIndex(
//       (t) => t.tz.includes("Calcutta") || t.tz.includes("Kolkata")
//     );
//     return index >= 0 ? index : 0;
//   }, [globalTZ, baseZones]);

//   const [selectedIndex, setSelectedIndex] = useState(
//     defaultBaseIndex + PADDING_ITEMS
//   );
//   const [isDropdownOpen, setIsDropdownOpen] = useState(false);

//   /* Center selected timezone */
//   useEffect(() => {
//     const targetIndex = defaultBaseIndex + PADDING_ITEMS;
//     setSelectedIndex(targetIndex);

//     requestAnimationFrame(() => {
//       if (wheelRef.current) {
//         wheelRef.current.scrollTop = defaultBaseIndex * ITEM_HEIGHT;
//       }
//     });
//   }, [defaultBaseIndex]);

//   /* Scroll handler → center selection */
//   const handleScroll = useCallback(() => {
//     const scrollTop = wheelRef.current.scrollTop;
//     const topIndex = Math.round(scrollTop / ITEM_HEIGHT);
//     const centerIndex = topIndex + PADDING_ITEMS;

//     const zone = timezones[centerIndex];
//     if (zone && zone.tz && centerIndex !== selectedIndex) {
//       setSelectedIndex(centerIndex);
//       dispatch(timeZonesActions.setTimezone(zone.tz));
//     }
//   }, [timezones, selectedIndex, dispatch]);

//   /* Close dropdown on outside click */
//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (wheelRef.current && !wheelRef.current.contains(event.target)) {
//         setIsDropdownOpen(false);
//       }
//     };

//     if (isDropdownOpen) {
//       document.addEventListener("mousedown", handleClickOutside);
//     }

//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, [isDropdownOpen]);

//   return (
//     <Card
//       variant="outlined"
//       style={{
//         flex: 1,
//         margin: "1rem",
//         borderRadius: "1rem",
//       }}
//     >
//       <Paper
//         elevation={3}
//         sx={{
//           width: 420,
//           p: 2,
//           mx: "auto",
//           mt: 3,
//           borderRadius: 2,
//         }}
//       >
//         {/* Header */}
//         <Typography textAlign="center" mb={2} fontWeight={600}>
//           Select Timezone
//         </Typography>

//         {/* 🔥 CLICKABLE DROPDOWN */}
//         <Box
//           sx={{
//             mb: 2,
//             px: 1.5,
//             py: 1,
//             borderRadius: 1,
//             border: "1px solid",
//             borderColor: "divider",
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "space-between",
//             cursor: "pointer",
//             bgcolor: "background.paper",
//             transition: "all 0.2s",
//             "&:hover": {
//               bgcolor: "action.hover",
//               borderColor: "primary.main",
//             },
//           }}
//           onClick={() => setIsDropdownOpen(!isDropdownOpen)} // ← TOGGLE DROPDOWN
//         >
//           <Typography
//             variant="body2"
//             sx={{
//               color: "text.primary",
//               fontWeight: 500,
//               overflow: "hidden",
//               textOverflow: "ellipsis",
//               whiteSpace: "nowrap",
//             }}
//           >
//             {timezones[selectedIndex]
//               ? formatLabel(timezones[selectedIndex].tz)
//               : "Select timezone"}
//           </Typography>
//           <Box
//             sx={{
//               width: 0,
//               height: 0,
//               borderLeft: "6px solid transparent",
//               borderRight: "6px solid transparent",
//               borderTop: "6px solid",
//               borderTopColor: isDropdownOpen ? "primary.main" : "text.secondary",
//               ml: 1,
//               transition: "0.2s",
//               transform: isDropdownOpen ? "rotate(180deg)" : "rotate(0deg)",
//             }}
//           />
//         </Box>

//         {/* 🔥 DROPDOWN WHEEL LIST (shows only when clicked) */}
//         {isDropdownOpen && (
//           <Box sx={{ position: "relative", mb: 3 }}>
//             {/* Scroll wheel */}
//             <Box
//               ref={wheelRef}
//               onScroll={handleScroll}
//               sx={{
//                 height: ITEM_HEIGHT * VISIBLE_ITEMS,
//                 overflowY: "auto",
//                 scrollSnapType: "y mandatory",
//                 borderRadius: 1.5,
//                 bgcolor: "background.default",
//                 border: "1px solid",
//                 borderColor: "divider",
//               }}
//             >
//               {timezones.map((item, i) => (
//                 <Box
//                   key={i}
//                   sx={{
//                     height: ITEM_HEIGHT,
//                     display: "flex",
//                     alignItems: "center",
//                     justifyContent: "center",
//                     scrollSnapAlign: "center",
//                     opacity: item ? 1 : 0,
//                     fontWeight: i === selectedIndex ? 600 : 400,
//                     color: i === selectedIndex ? "primary.main" : "text.secondary",
//                     transform: i === selectedIndex ? "scale(1.05)" : "scale(0.9)",
//                     transition: "0.15s",
//                     bgcolor: i === selectedIndex ? "action.selected" : "transparent",
//                   }}
//                 >
//                   {item ? formatLabel(item.tz) : ""}
//                 </Box>
//               ))}
//             </Box>

//             {/* Center highlight */}
//             <Box
//               sx={{
//                 position: "absolute",
//                 top: "50%",
//                 left: 8,
//                 right: 8,
//                 height: ITEM_HEIGHT,
//                 transform: "translateY(-50%)",
//                 borderTop: "2px solid #1976d2",
//                 borderBottom: "2px solid #1976d2",
//                 borderRadius: 1,
//                 pointerEvents: "none",
//                 background:
//                   "linear-gradient(to bottom, rgba(25,118,210,0.03), rgba(25,118,210,0.08), rgba(25,118,210,0.03))",
//               }}
//             />
//           </Box>
//         )}

//         {/* Save button (always visible) */}
//         <Box mt={3} display="flex" justifyContent="center">
//           <button
//             style={{
//               minWidth: 120,
//               padding: "8px 16px",
//               borderRadius: 999,
//               border: "none",
//               background: "#1976d2",
//               color: "#fff",
//               fontWeight: 600,
//               cursor: "pointer",
//             }}
//             onClick={() => {
//               const zone = timezones[selectedIndex];
//               if (zone && zone.tz) {
//                 dispatch(timeZonesActions.setTimezone(zone.tz));
//                 setIsDropdownOpen(false); // Close dropdown after save
//               }
//             }}
//           >
//             Save
//           </button>
//         </Box>
//       </Paper>
//     </Card>
//   );
// }

//final working code
import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { Box, Typography, Paper, Card } from "@mui/material";
import { DateTime } from "luxon";
import { useDispatch, useSelector } from "react-redux";
import { timeZonesActions } from "../../Store/Reducers/ClonosTimeZoneReducer";

/* CONFIG */
const VISIBLE_ITEMS = 5;
const ITEM_HEIGHT = 48;
const DEFAULT_TZ = "Asia/Calcutta";
const PADDING_ITEMS = Math.floor(VISIBLE_ITEMS / 2);

/* HELPERS */
const getOffset = (tz) => DateTime.now().setZone(tz).offset;

const formatLabel = (tz) => {
  const offset = getOffset(tz);
  const sign = offset >= 0 ? "+" : "-";
  const h = String(Math.floor(Math.abs(offset) / 60)).padStart(2, "0");
  const m = String(Math.abs(offset) % 60).padStart(2, "0");
  return `${tz} (GMT${sign}${h}:${m})`;
};

export default function TimeZonePage() {
  const dispatch = useDispatch();
  const wheelRef = useRef(null);

  const globalTZ = useSelector((store) => store.timeZonesData.timezone);


  /* Base timezone list (GMT - → +) */
  const baseZones = useMemo(() => {
    return Intl.supportedValuesOf("timeZone")
      .map((tz) => ({ tz, offset: getOffset(tz) }))
      .sort((a, b) => a.offset - b.offset);
  }, []);

  /* Padding rows for true center selection */
  const timezones = useMemo(() => {
    const padding = Array(PADDING_ITEMS).fill(null);
    return [...padding, ...baseZones, ...padding];
  }, [baseZones]);

  /* Default index (find Asia/Calcutta or Kolkata) */
  const defaultBaseIndex = useMemo(() => {
    // Try globalTZ first
    let index = baseZones.findIndex((t) => t.tz === globalTZ);
    if (index >= 0) return index;

    // Find India timezone (Calcutta/Kolkata)
    index = baseZones.findIndex(
      (t) => t.tz.includes("Calcutta") || t.tz.includes("Kolkata")
    );
    return index >= 0 ? index : 0;
  }, [globalTZ, baseZones]);

  const [selectedIndex, setSelectedIndex] = useState(
    defaultBaseIndex + PADDING_ITEMS
  );
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  /* Center selected timezone */
  useEffect(() => {
    const targetIndex = defaultBaseIndex + PADDING_ITEMS;
    setSelectedIndex(targetIndex);

    requestAnimationFrame(() => {
      if (wheelRef.current) {
        wheelRef.current.scrollTop = defaultBaseIndex * ITEM_HEIGHT;
      }
    });
  }, [defaultBaseIndex]);

  /* Scroll handler → center selection */
  const handleScroll = useCallback(() => {
    const scrollTop = wheelRef.current.scrollTop;
    const topIndex = Math.round(scrollTop / ITEM_HEIGHT);
    const centerIndex = topIndex + PADDING_ITEMS;

    const zone = timezones[centerIndex];
    if (zone && zone.tz && centerIndex !== selectedIndex) {
      setSelectedIndex(centerIndex);
      dispatch(timeZonesActions.setTimezone(zone.tz));
    }
  }, [timezones, selectedIndex, dispatch]);

/* Center selected timezone when dropdown opens */
useEffect(() => {
  const targetIndex = defaultBaseIndex + PADDING_ITEMS;
  setSelectedIndex(targetIndex);
}, [defaultBaseIndex]);

/* Scroll wheel to center when dropdown opens */
useEffect(() => {
  if (!isDropdownOpen || !wheelRef.current) return;

  requestAnimationFrame(() => {
    if (wheelRef.current) {
      wheelRef.current.scrollTop = defaultBaseIndex * ITEM_HEIGHT;
    }
  });
}, [isDropdownOpen, defaultBaseIndex]);


  return (
    <Card
      variant="outlined"
      style={{
        flex: 1,
        margin: "1rem",
        borderRadius: "1rem",
      }}
    >
      <Paper
        elevation={3}
        sx={{
          width: 420,
          p: 2,
          mx: "auto",
          mt: 3,
          borderRadius: 2,
        }}
      >
        {/* Header */}
        <Typography textAlign="center" mb={2} fontWeight={600}>
          Select Timezone
        </Typography>

        {/* CLICKABLE DROPDOWN */}
        <Box
          sx={{
            mb: 2,
            px: 1.5,
            py: 1,
            borderRadius: 1,
            border: "1px solid",
            borderColor: "divider",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            cursor: "pointer",
            // bgcolor: "background.paper",
            transition: "all 0.2s",
           
          }}
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        >
          <Typography
            variant="body2"
            sx={{
              color: "text.primary",
              fontWeight: 500,
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
            }}
          >
            {timezones[selectedIndex]
              ? formatLabel(timezones[selectedIndex].tz)
              : "Select timezone"}
          </Typography>
          <Box
            sx={{
              width: 0,
              height: 0,
              borderLeft: "6px solid transparent",
              borderRight: "6px solid transparent",
              borderTop: "6px solid",
              borderTopColor: isDropdownOpen ? "primary.main" : "text.secondary",
              ml: 1,
              transition: "0.2s",
              transform: isDropdownOpen ? "rotate(180deg)" : "rotate(0deg)",
            }}
          />
        </Box>

        {/* DROPDOWN WHEEL LIST (shows only when clicked) */}
        {isDropdownOpen && (
          <Box sx={{ position: "relative", mb: 3 }}>
            {/* Scroll wheel */}
            <Box
              ref={wheelRef}
              onScroll={handleScroll}
              sx={{
                height: ITEM_HEIGHT * VISIBLE_ITEMS,
                overflowY: "auto",
                scrollSnapType: "y mandatory",
                borderRadius: 1.5,
                bgcolor: "background.default",
                border: "1px solid",
                borderColor: "divider",
              }}
            >
              {timezones.map((item, i) => (
                <Box
                  key={i}
                  sx={{
                    height: ITEM_HEIGHT,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    scrollSnapAlign: "center",
                    opacity: item ? 1 : 0,
                    fontWeight: i === selectedIndex ? 600 : 400,
                    color: i === selectedIndex ? "primary.main" : "text.secondary",
                    transform: i === selectedIndex ? "scale(1.05)" : "scale(0.9)",
                    transition: "0.15s",
                    // bgcolor: i === selectedIndex ? "action.selected" : "transparent",
                  }}
                >
                  {item ? formatLabel(item.tz) : ""}
                </Box>
              ))}
            </Box>

            {/* Center highlight */}
            <Box
              sx={{
                position: "absolute",
                top: "50%",
                left: 8,
                right: 8,
                height: ITEM_HEIGHT,
                transform: "translateY(-50%)",
                borderTop: "2px solid #1976d2",
                borderBottom: "2px solid #1976d2",
                borderRadius: 1,
                pointerEvents: "none",
                background:
                  "linear-gradient(to bottom, rgba(25,118,210,0.03), rgba(25,118,210,0.08), rgba(25,118,210,0.03))",
              }}
            />
          </Box>
        )}

        {globalTZ && (
            <Typography
              variant="body2"
              sx={{
                mt: 2,
                textAlign: "center",
                fontWeight: 500,
                color: "success.main",
              }}
            >
              Global Timezone: {formatLabel(globalTZ)}
            </Typography>
          )}


        {/* Save button */}
        <Box mt={3} display="flex" justifyContent="center">
          <button
            style={{
              minWidth: 120,
              padding: "8px 16px",
              borderRadius: 999,
              border: "none",
              background: "#1976d2",
              color: "#fff",
              fontWeight: 600,
              cursor: "pointer",
            }}
            onClick={() => {
              const zone = timezones[selectedIndex];
              if (zone && zone.tz) {
                dispatch(timeZonesActions.setTimezone(zone.tz));
                alert(`Global Time Zone now is ${globalTZ}`)
                setIsDropdownOpen(false);
              }
            }}
          >
            Save
          </button>
        </Box>
      </Paper>
    </Card>
  );
}








  // return (
  //       <Card
  //     variant="outlined"
  //     style={{
  //       flex: 1,
  //       margin: "1rem",
  //       borderRadius: "1rem",
  //     }}
  //   >
  //   <Paper
  //     elevation={3}
  //     sx={{
  //       width: 420,
  //       p: 2,
  //       mx: "auto",
  //       mt: 3,
  //       borderRadius: 2,
  //     }}
  //   >
  //     <Typography textAlign="center" mb={1}>
  //       Select Timezone
  //     </Typography>

  //     {/* Wheel container */}
  //     <Box
  //       sx={{
  //         position: "relative",
  //       }}
  //     >
  //       {/* Scroll wheel */}
  //       <Box
  //         ref={wheelRef}
  //         onScroll={handleScroll}
  //         sx={{
  //           height: ITEM_HEIGHT * VISIBLE_ITEMS,
  //           overflowY: "auto",
  //           scrollSnapType: "y mandatory",
  //         }}
  //       >
  //         {timezones.map((item, i) => (
  //           <Box
  //             key={i}
  //             sx={{
  //               height: ITEM_HEIGHT,
  //               display: "flex",
  //               alignItems: "center",
  //               justifyContent: "center",
  //               scrollSnapAlign: "center",
  //               opacity: item ? 1 : 0,
  //               fontWeight: i === selectedIndex ? 600 : 400,
  //               color:
  //                 i === selectedIndex
  //                   ? "primary.main"
  //                   : "text.secondary",
  //               transform:
  //                 i === selectedIndex
  //                   ? "scale(1.05)"
  //                   : "scale(0.9)",
  //               transition: "0.15s",
  //             }}
  //           >
  //             {item ? formatLabel(item.tz) : ""}
  //           </Box>
  //         ))}
  //       </Box>

  //       {/* ✅ PERFECT CENTER LINES (Alarm style) */}
  //       <Box
  //         sx={{
  //           position: "absolute",
  //           top: "50%",
  //           left: 0,
  //           right: 0,
  //           height: ITEM_HEIGHT,
  //           transform: "translateY(-50%)",
  //           borderTop: "2px solid #1976d2",
  //           borderBottom: "2px solid #1976d2",
  //           pointerEvents: "none",
  //         }}
  //       />
  //     </Box>
  //   </Paper>
  //   </Card>
  // );




