import React, { useState, useEffect } from 'react';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  makeStyles,
  Typography,
  Box,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@material-ui/core';
import { 
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
} from '@material-ui/icons';
import { 
  createShift,
  getShifts,
  updateShift,
  deleteShift
} from '../../../Api/Admin/AdminApi';
import { toast } from 'react-toastify';

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
  },
  paper: {
    width: '100%',
    marginBottom: theme.spacing(2),
  },
  table: {
    minWidth: 750,
  },
  visuallyHidden: {
    border: 0,
    clip: 'rect(0 0 0 0)',
    height: 1,
    margin: -1,
    overflow: 'hidden',
    padding: 0,
    position: 'absolute',
    top: 20,
    width: 1,
  },
  button: {
    margin: theme.spacing(1),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  timeInput: {
    margin: theme.spacing(1),
    width: 150,
  },
}));

const ShiftsTab = ({ businessUnitId }) => {
  const classes = useStyles();
  const [shifts, setShifts] = useState([]);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    shiftHours: {
      start: '',
      end: ''
    }
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (businessUnitId) {
      fetchShifts();
    }
  }, [businessUnitId]);

  const fetchShifts = async () => {
    try {
      setLoading(true);
      const response = await getShifts({ businessUnit: businessUnitId });
      if (response?.data?.result?.data) {
        setShifts(response.data.result.data);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Error fetching shifts');
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingId(null);
    setFormData({
      name: '',
      shiftHours: {
        start: '',
        end: ''
      }
    });
  };

  const handleEdit = (shift) => {
    setEditingId(shift.id);
    setFormData({
      name: shift.name,
      shiftHours: {
        start: convertUtcToLocal(shift.shiftHours.start),
        end: convertUtcToLocal(shift.shiftHours.end)
      }
    });
    setOpen(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this shift?')) {
      try {
        await deleteShift(id);
        toast.success('Shift deleted successfully');
        fetchShifts();
      } catch (error) {
        toast.error(error?.response?.data?.message || 'Error deleting shift');
      }
    }
  };

 // helper
const convertToUtcTime = (timeString) => {
  if (!timeString) return "";
  const [hours, minutes] = timeString.split(":");
  const localDate = new Date();
  localDate.setHours(hours, minutes, 0, 0);

  const utcHours = String(localDate.getUTCHours()).padStart(2, "0");
  const utcMinutes = String(localDate.getUTCMinutes()).padStart(2, "0");

  return `${utcHours}:${utcMinutes}`; // "HH:mm"
};

const convertUtcToLocal = (utcTime) => {
  if (!utcTime) return "";
  const [hours, minutes] = utcTime.split(":");
  const utcDate = new Date();
  utcDate.setUTCHours(hours, minutes, 0, 0);

  const localHours = String(utcDate.getHours()).padStart(2, "0");
  const localMinutes = String(utcDate.getMinutes()).padStart(2, "0");

  return `${localHours}:${localMinutes}`;
};


const handleSubmit = async () => {
  try {
    // prepare payload with UTC times
    const payload = {
      ...formData,
      shiftHours: {
        start: convertToUtcTime(formData.shiftHours.start),
        end: convertToUtcTime(formData.shiftHours.end),
      },
      businessUnit: businessUnitId,
    };

    if (editingId) {
      await updateShift(editingId, payload);
      toast.success("Shift updated successfully");
    } else {
      await createShift(payload);
      toast.success("Shift created successfully");
    }

    handleClose();
    fetchShifts();
  } catch (error) {
    toast.error(error?.response?.data?.message || "Error saving shift");
  }
};


  // const handleSubmit = async () => {
  //   try {
  //     if (editingId) {
  //       await updateShift(editingId, formData);
  //       toast.success('Shift updated successfully');
  //     } else {
  //       await createShift({
  //         ...formData,
  //         businessUnit: businessUnitId
  //       });
  //       toast.success('Shift created successfully');
  //     }
  //     handleClose();
  //     fetchShifts();
  //   } catch (error) {
  //     toast.error(error?.response?.data?.message || 'Error saving shift');
  //   }
  // };





  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  return (
    <div className={classes.root}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h6">Shifts</Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={handleOpen}
          className={classes.button}
        >
          Add Shift
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table className={classes.table}>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Start Time</TableCell>
              <TableCell>End Time</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {shifts.map((shift) => (
              <TableRow key={shift.id}>
                <TableCell>{shift.name}</TableCell>
               <TableCell>{convertUtcToLocal(shift.shiftHours.start)}</TableCell>
               <TableCell>{convertUtcToLocal(shift.shiftHours.end)}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleEdit(shift)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton onClick={() => handleDelete(shift.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>{editingId ? 'Edit Shift' : 'Add Shift'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Shift Name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                margin="normal"
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Start Time"
                name="shiftHours.start"
                type="time"
                value={formData.shiftHours.start}
                onChange={handleChange}
                margin="normal"
                required
                InputLabelProps={{
                  shrink: true,
                }}
                inputProps={{
                  step: 300
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="End Time"
                name="shiftHours.end"
                type="time"
                value={formData.shiftHours.end}
                onChange={handleChange}
                margin="normal"
                required
                InputLabelProps={{
                  shrink: true,
                }}
                inputProps={{
                  step: 300
                }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} color="primary" variant="contained">
            {editingId ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ShiftsTab; 