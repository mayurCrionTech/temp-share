// import React, { useState, useEffect } from 'react';
// import {
//   Button,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   TextField,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   IconButton,
//   makeStyles,
//   Chip,
//   Switch,
//   FormControlLabel,
//   CircularProgress,
//   Snackbar,
//   Collapse,
//   Box,
//   Typography,
//   Tooltip,
//   FormGroup,
//   Checkbox,
//   Card,
//   CardContent,
//   Grid,
//   Divider,
//   Breadcrumbs,
//   Link,
//   Fade,
//   Zoom,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
// } from '@material-ui/core';
// import { Alert } from '@material-ui/lab';
// import { 
//   Edit as EditIcon,
//   KeyboardArrowDown as ExpandMoreIcon,
//   KeyboardArrowUp as ExpandLessIcon,
//   Add as AddIcon,
//   Business as BusinessIcon,
//   AccountTree as AccountTreeIcon,
//   Group as GroupIcon,
//   Assignment as AssignmentIcon,
//   Person as PersonIcon,
//   Delete as DeleteIcon,
//   Schedule as ScheduleIcon,
// } from '@material-ui/icons';
// import { 
//   createOrganization, 
//   getOrganizations, 
//   updateOrganization,
//   getBusinessUnits,
//   getDepartments,
//   getUserTypes,
//   getDesignations,
//   updateBusinessUnit,
//   createBusinessUnit,
//   disableBusinessUnit,
//   enableBusinessUnit,
//   updateDepartment,
//   createDepartment,
//   disableDepartment,
//   enableDepartment,
//   updateUserType,
//   createUserType,
//   disableUserType,
//   enableUserType,
//   updateDesignation,
//   createDesignation,
//   disableDesignation,
//   enableDesignation,
//   getAllPermissionGroups,
//   getAllPermissions,
//   deleteOrganization,
//   deleteBusinessUnit,
// } from '../../../Api/Admin/AdminApi';
// import { toast } from 'react-toastify';
// import ShiftsTab from './ShiftsTab';

// const useStyles = makeStyles((theme) => ({
//   root: {
//     width: '100%',
//     padding: theme.spacing(3),
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: theme.spacing(3),
//   },
//   title: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: theme.spacing(1),
//   },
//   addButton: {
//     marginBottom: theme.spacing(2),
//     borderRadius: theme.spacing(2),
//     textTransform: 'none',
//     padding: theme.spacing(1, 3),
//   },
//   table: {
//     minWidth: 650,
//     borderRadius: theme.spacing(1),
//     overflow: 'hidden',
//     boxShadow: theme.shadows[2],
//   },
//   tableHead: {
//     backgroundColor: theme.palette.primary.main,
//     '& .MuiTableCell-head': {
//       color: theme.palette.primary.contrastText,
//       fontWeight: 'bold',
//     },
//   },
//   dialogContent: {
//     minWidth: 400,
//     padding: theme.spacing(3),
//   },
//   dialogTitle: {
//     backgroundColor: theme.palette.primary.main,
//     color: theme.palette.primary.contrastText,
//     padding: theme.spacing(2, 3),
//   },
//   chips: {
//     display: 'flex',
//     flexWrap: 'wrap',
//     gap: theme.spacing(1),
//     marginTop: theme.spacing(1),
//   },
//   chip: {
//     margin: theme.spacing(0.5),
//     borderRadius: theme.spacing(1),
//   },
//   loadingContainer: {
//     display: 'flex',
//     justifyContent: 'center',
//     padding: theme.spacing(3),
//   },
//   nestedRow: {
//     backgroundColor: theme.palette.background.default,
//     transition: 'background-color 0.3s ease',
//     '&:hover': {
//       backgroundColor: theme.palette.action.hover,
//     },
//   },
//   nestedCell: {
//     paddingLeft: theme.spacing(4),
//   },
//   expandButton: {
//     padding: theme.spacing(1),
//     transition: 'transform 0.3s ease',
//   },
//   expanded: {
//     transform: 'rotate(180deg)',
//   },
//   expandedSection: {
//     backgroundColor: theme.palette.background.default,
//     borderLeft: `4px solid ${theme.palette.primary.main}`,
//     borderRadius: theme.shape.borderRadius,
//     margin: theme.spacing(1, 0),
//     boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
//   },
//   nestedTable: {
//     '& .MuiTableCell-root': {
//       borderBottom: 'none',
//     },
//   },
//   nestedTableHead: {
//     backgroundColor: theme.palette.grey[50],
//     borderBottom: `1px solid ${theme.palette.divider}`,
//     '& .MuiTableCell-head': {
//       color: theme.palette.text.primary,
//       fontWeight: 'bold',
//     },
//   },
//   rowContent: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: theme.spacing(2),
//   },
//   levelIndicator: {
//     width: theme.spacing(2),
//     height: theme.spacing(2),
//     borderRadius: '50%',
//     backgroundColor: theme.palette.primary.main,
//     opacity: 0.7,
//   },
//   shortNameField: {
//     width: '120px',
//     marginRight: theme.spacing(2),
//   },
//   nameField: {
//     flex: 1,
//   },
//   nameContainer: {
//     display: 'flex',
//     alignItems: 'flex-start',
//     gap: theme.spacing(2),
//   },
//   addBusinessUnitButton: {
//     marginLeft: theme.spacing(2),
//     borderRadius: theme.spacing(2),
//   },
//   domainChip: {
//     margin: theme.spacing(0.5),
//     borderRadius: theme.spacing(1),
//   },
//   statusChip: {
//     borderRadius: theme.spacing(1),
//     fontWeight: 'bold',
//   },
//   breadcrumbs: {
//     marginBottom: theme.spacing(2),
//     padding: theme.spacing(1),
//     backgroundColor: theme.palette.background.paper,
//     borderRadius: theme.spacing(1),
//   },
//   actionButton: {
//     borderRadius: theme.spacing(1),
//     textTransform: 'none',
//     padding: theme.spacing(0.5, 1),
//   },
//   errorAlert: {
//     marginBottom: theme.spacing(2),
//   },
//   formGroup: {
//     marginTop: theme.spacing(2),
//   },
//   permissionSection: {
//     marginTop: theme.spacing(3),
//     padding: theme.spacing(2),
//     backgroundColor: theme.palette.background.default,
//     borderRadius: theme.spacing(1),
//   },
//   permissionGroup: {
//     marginBottom: theme.spacing(2),
//   },
//   permissionGroupTitle: {
//     marginBottom: theme.spacing(1),
//     color: theme.palette.text.secondary,
//   },
//   headerContent: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     padding: theme.spacing(1, 0),
//   },
//   headerTitle: {
//     fontWeight: 'bold',
//     color: theme.palette.text.primary,
//   },
//   addButton: {
//     textTransform: 'none',
//     padding: theme.spacing(0.5, 1),
//   },
// }));

// function OrganizationsTab() {
//   const classes = useStyles();
//   const [organizations, setOrganizations] = useState([]);
//   const [businessUnits, setBusinessUnits] = useState([]);
//   const [departments, setDepartments] = useState([]);
//   const [userTypes, setUserTypes] = useState([]);
//   const [designations, setDesignations] = useState([]);
//   const [open, setOpen] = useState(false);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const [formData, setFormData] = useState({
//     name: '',
//     shortName: '',
//     isEnabled: true,
//   });
//   const [editingId, setEditingId] = useState(null);
//   const [editingLevel, setEditingLevel] = useState(0);
//   const [selectedOrganization, setSelectedOrganization] = useState(null);
//   const [selectedBusinessUnit, setSelectedBusinessUnit] = useState(null);
//   const [selectedDepartment, setSelectedDepartment] = useState(null);
//   const [selectedUserType, setSelectedUserType] = useState(null);
//   const [selectedPermissions, setSelectedPermissions] = useState({});
//   const [newDomain, setNewDomain] = useState('');
//   const [permissionGroups, setPermissionGroups] = useState([]);
//   const [permissions, setPermissions] = useState({});
//   const [originalRow, setOriginalRow] = useState(null);
//   const [expandedItems, setExpandedItems] = useState(new Set());
//   const [shiftsDialogOpen, setShiftsDialogOpen] = useState(false);

//   const childrenData = [
//     getBusinessUnits,
//     getDepartments,
//     getUserTypes,
//     getDesignations,
//   ];

//   const levelNames = ['Organization', 'Business Unit', 'Department', 'User Type', 'Designation'];

//   useEffect(() => {
//     fetchOrganizations();
//     fetchPermissionGroups();
//   }, []);

//   const fetchOrganizations = async () => {
//     try {
//       setLoading(true);
//       const response = await getOrganizations();
//       if (response.data?.result?.data) {
//         setOrganizations(response.data.result.data);
//       } else {
//         console.log('Unexpected response structure:', response.data);
//         setOrganizations([]);
//       }
//     } catch (error) {
//       console.error('Error fetching organizations:', error);
//       setError(error.response?.data?.message || 'Error fetching organizations');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const fetchPermissionGroups = async () => {
//     try {
//       const response = await getAllPermissionGroups({ selectFields: "name" });
//       if (response.data?.result?.data) {
//         setPermissionGroups(response.data.result.data);
//         // Fetch permissions for each group
//         response.data.result.data.forEach(group => {
//           fetchPermissions(group.id);
//         });
//       }
//     } catch (error) {
//       console.error('Error fetching permission groups:', error);
//       setError(error.response?.data?.message || 'Error fetching permission groups');
//     }
//   };

//   const fetchPermissions = async (groupId) => {
//     try {
//       const response = await getAllPermissions({ 
//         permissionGroups: [groupId],
//         selectFields: "name"
//       });
//       if (response.data?.result?.data) {
//         setPermissions(prev => ({
//           ...prev,
//           [groupId]: response.data.result.data
//         }));
//       }
//     } catch (error) {
//       console.error('Error fetching permissions:', error);
//       setError(error.response?.data?.message || 'Error fetching permissions');
//     }
//   };

//   const handlePermissionChange = (groupId, permissionId, checked) => {
//     setSelectedPermissions(prev => {
//       const groupPermissions = prev[groupId] || {};
//       return {
//         ...prev,
//         [groupId]: {
//           ...groupPermissions,
//           [permissionId]: checked
//         }
//       };
//     });
//   };

//   const handleOpen = async (row = null, level = 0, parentRow = null) => {
//     if (row) {
//       setOriginalRow(row);
//       if (level === 0) {
//         // Organization
//         setFormData({
//           name: row.name,
//           isEnabled: row.isEnabled,
//         });
//       } else if (level === 1) {
//         // Business Unit
//         setFormData({
//           name: row.name,
//           shortName: row.shortName,
//           isEnabled: row.isEnabled
//         });
//         // Find the parent organization
//         const parentOrg = organizations.find(org => org.id === row.organization);
//         setSelectedOrganization(parentOrg);
//       } else if (level === 2) {
//         // Department
//         setFormData({
//           name: row.name,
//           isEnabled: row.isEnabled
//         });
//         // Find the parent business unit
//         const parentBU = businessUnits.find(bu => bu.id === row.businessUnit);
//         setSelectedBusinessUnit(parentBU);
//         // Find the parent organization through the business unit
//         if (parentBU) {
//           const parentOrg = organizations.find(org => org.id === parentBU.organization);
//           setSelectedOrganization(parentOrg);
//         }
//       } else if (level === 3) {
//         // User Type
//         setFormData({
//           name: row.name,
//           isEnabled: row.isEnabled
//         });
//         // Find the parent department
//         const parentDept = departments.find(dept => dept.id === row.department);
//         setSelectedDepartment(parentDept);
//         // Find the parent business unit through the department
//         if (parentDept) {
//           const parentBU = businessUnits.find(bu => bu.id === parentDept.businessUnit);
//           setSelectedBusinessUnit(parentBU);
//           // Find the parent organization through the business unit
//           if (parentBU) {
//             const parentOrg = organizations.find(org => org.id === parentBU.organization);
//             setSelectedOrganization(parentOrg);
//           }
//         }
//       } else if (level === 4) {
//         // Designation
//         setFormData({
//           name: row.name,
//           isEnabled: row.isEnabled,
//           permissions: row.permissions || {}
//         });
        
//         // Set selected permissions based on the permissions object
//         const initialPermissions = {};
        
//         // First, ensure we have all permission groups
//         permissionGroups.forEach(group => {
//           initialPermissions[group.id] = {};
//         });

//         // Then map the permissions from the nested structure
//         if (row.permissions) {
//           Object.entries(row.permissions).forEach(([groupName, groupPermissions]) => {
//             // Find the group ID that matches this group name
//             const group = permissionGroups.find(g => g.name.toLowerCase() === groupName.toLowerCase());
//             if (group) {
//               Object.entries(groupPermissions).forEach(([permissionName, permissionData]) => {
//                 if (permissionData && permissionData.id) {
//                   initialPermissions[group.id][permissionData.id] = true;
//                 }
//               });
//             }
//           });
//         }
        
//         console.log('Initial Permissions:', initialPermissions); // Debug log
//         setSelectedPermissions(initialPermissions);
        
//         // Find the parent user type
//         const parentUT = userTypes.find(ut => ut.id === row.userType);
//         setSelectedUserType(parentUT);
        
//         // Find the parent department through the user type
//         if (parentUT) {
//           const parentDept = departments.find(dept => dept.id === parentUT.department);
//           setSelectedDepartment(parentDept);
          
//           // Find the parent business unit through the department
//           if (parentDept) {
//             const parentBU = businessUnits.find(bu => bu.id === parentDept.businessUnit);
//             setSelectedBusinessUnit(parentBU);
            
//             // Find the parent organization through the business unit
//             if (parentBU) {
//               const parentOrg = organizations.find(org => org.id === parentBU.organization);
//               setSelectedOrganization(parentOrg);
//             }
//           }
//         }
//       }
//       setEditingId(row.id);
//       setEditingLevel(level);
//     } else {
//       setOriginalRow(null);
//       if (level === 0) {
//         // New Organization
//         setFormData({
//           name: '',
//           isEnabled: true,
//         });
//       } else if (level === 1 && parentRow) {
//         // New Business Unit
//         setFormData({
//           name: '',
//           shortName: '',
//           isEnabled: true
//         });
//         setSelectedOrganization(parentRow);
//       } else if (level === 2 && parentRow) {
//         // New Department
//         setFormData({
//           name: '',
//           isEnabled: true
//         });
//         setSelectedBusinessUnit(parentRow);
//       } else if (level === 3 && parentRow) {
//         // New User Type
//         setFormData({
//           name: '',
//           isEnabled: true
//         });
//         setSelectedDepartment(parentRow);
//       } else if (level === 4 && parentRow) {
//         // New Designation
//         setFormData({
//           name: '',
//           isEnabled: true,
//           permissions: {}
//         });
//         setSelectedUserType(parentRow);
//       }
//       setEditingId(null);
//       setEditingLevel(level);
//     }
//     setOpen(true);
//   };

//   const handleClose = () => {
//     setOpen(false);
//     setFormData({
//       name: '',
//       shortName: '',
//       isEnabled: true,
//     });
//     setEditingId(null);
//     setEditingLevel(0);
//     setSelectedOrganization(null);
//     setSelectedBusinessUnit(null);
//     setSelectedDepartment(null);
//     setSelectedUserType(null);
//     setSelectedPermissions({});
//     setNewDomain('');
//     setOriginalRow(null);
//   };

//   const handleSubmit = async () => {
//     setLoading(true);
//     try {
//       if (editingLevel === 0) {
//         // Organization
//         if (editingId) {
//           await updateOrganization(editingId, formData);
//         } else {
//           await createOrganization(formData);
//         }
//       } else if (editingLevel === 1) {
//         // Business Unit
//         if (!selectedOrganization) {
//           throw new Error('Organization is required for business unit operations');
//         }
//         const businessUnitData = {
//           name: formData.name,
//           shortName: formData.shortName,
//           isEnabled: formData.isEnabled,
//           organization: selectedOrganization.id
//         };
        
//         if (editingId) {
//           await updateBusinessUnit(editingId, businessUnitData);
//         } else {
//           await createBusinessUnit(selectedOrganization.id, businessUnitData);
//         }
//       } else if (editingLevel === 2) {
//         // Department
//         if (!selectedBusinessUnit) {
//           throw new Error('Business Unit is required for department operations');
//         }
//         const departmentData = {
//           name: formData.name,
//           isEnabled: formData.isEnabled,
//           businessUnit: selectedBusinessUnit.id
//         };
        
//         if (editingId) {
//           await updateDepartment(editingId, departmentData, selectedBusinessUnit.id);
//         } else {
//           await createDepartment(selectedBusinessUnit.id, departmentData);
//         }
//       } else if (editingLevel === 3) {
//         // User Type
//         const userTypeData = {
//           name: formData.name,
//           isEnabled: formData.isEnabled
//         };
        
//         if (editingId) {
//           await updateUserType(editingId, userTypeData);
//         } else {
//           await createUserType(selectedDepartment.businessUnit, selectedDepartment.id, userTypeData);
//         }
//       } else if (editingLevel === 4) {
//         // Designation
//         const designationData = {
//           isEnabled: formData.isEnabled
//         };

//         // For editing, check if name is modified
//         if (editingId) {
//           // Get the original name from when we opened the dialog
//           const originalName = originalRow?.name;
          
//           // Only include name if it's actually different from original
//           if (originalName !== formData.name) {
//             designationData.name = formData.name;
//           }
//         } else {
//           // For new designations, always include name
//           designationData.name = formData.name;
//         }
        
//         // Convert selected permissions to flat array
//         const selectedPermissionIds = Object.values(selectedPermissions)
//           .flatMap(groupPermissions => 
//             Object.entries(groupPermissions)
//               .filter(([_, selected]) => selected)
//               .map(([permissionId]) => permissionId)
//           );
        
//         if (selectedPermissionIds.length > 0) {
//           designationData.permissions = selectedPermissionIds;
//         }
        
//         console.log('Designation Update Payload:', designationData); // Debug log
        
//         if (editingId) {
//           await updateDesignation(editingId, designationData);
//         } else {
//           await createDesignation(selectedUserType.businessUnit, selectedUserType.id, designationData);
//         }
//       }
      
//       handleClose();
//       fetchOrganizations();
//     } catch (error) {
//       console.error('Error saving:', error);
//       setError(error.response?.data?.message || 'Error saving data');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleAddDomain = () => {
//     if (newDomain && !formData.allowedDomains.includes(newDomain)) {
//       setFormData({
//         ...formData,
//         allowedDomains: [...formData.allowedDomains, newDomain],
//         isDomainRestricted: true,
//       });
//       setNewDomain('');
//     }
//   };

//   const handleRemoveDomain = (domainToRemove) => {
//     const updatedDomains = formData.allowedDomains.filter(domain => domain !== domainToRemove);
//     setFormData({
//       ...formData,
//       allowedDomains: updatedDomains,
//       isDomainRestricted: updatedDomains.length > 0,
//     });
//   };

//   const handleCloseError = () => {
//     setError(null);
//   };

//   const handleToggleStatus = async (row, level) => {
//     setLoading(true);
//     try {
//       if (level === 0) {
//         // Organization
//         await updateOrganization(row.id, {
//           ...row,
//           isEnabled: !row.isEnabled
//         });
//       } else if (level === 1) {
//         // Business Unit
//         if (row.isEnabled) {
//           await disableBusinessUnit(row.id);
//         } else {
//           await enableBusinessUnit(row.id);
//         }
//       } else if (level === 2) {
//         // Department
//         if (row.isEnabled) {
//           await disableDepartment(row.id);
//         } else {
//           await enableDepartment(row.id);
//         }
//       } else if (level === 3) {
//         // User Type
//         if (row.isEnabled) {
//           await disableUserType(row.id);
//         } else {
//           await enableUserType(row.id);
//         }
//       } else if (level === 4) {
//         // Designation
//         if (row.isEnabled) {
//           await disableDesignation(row.id);
//         } else {
//           await enableDesignation(row.id);
//         }
//       }
//       fetchOrganizations();
//     } catch (error) {
//       console.error('Error toggling status:', error);
//       setError(error.response?.data?.message || 'Error updating status');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleExpand = async (row, level) => {
//     const itemKey = `${level}-${row.id}`;
//     const newExpandedItems = new Set(expandedItems);
    
//     if (expandedItems.has(itemKey)) {
//       // When collapsing, remove all child expanded states
//       const keysToRemove = Array.from(expandedItems).filter(key => {
//         const [keyLevel, keyId] = key.split('-');
//         return parseInt(keyLevel) > level;
//       });
//       keysToRemove.forEach(key => newExpandedItems.delete(key));
//       newExpandedItems.delete(itemKey);
//     } else {
//       newExpandedItems.add(itemKey);
//     }
    
//     setExpandedItems(newExpandedItems);
//   };

//   const isExpanded = (row, level) => {
//     return expandedItems.has(`${level}-${row.id}`);
//   };

//   const Row = ({ row, level, onEdit, handleShiftsClick }) => {
//     const [loading, setLoading] = useState(false);
//     const [childData, setChildData] = useState([]);
//     const classes = useStyles();
//     const open = isExpanded(row, level);

//     useEffect(() => {
//       if (open) {
//         fetchChildData();
//       } else {
//         // Clear child data when collapsed
//         setChildData([]);
//       }
//     }, [open]);

//     // const fetchChildData = async () => {
//     //     setLoading(true);
//     //     try {
//     //     let response;
//     //       if (level === 0) {
//     //         // Fetch business units for organization
//     //       response = await getBusinessUnits(row.id);
//     //       } else if (level === 1) {
//     //         // Fetch departments for business unit
//     //       response = await getDepartments(row.id);
//     //       } 
          
//     //       else if (level === 2) {
//     //         // Fetch user types for department
//     //       response = await getUserTypes(row.businessUnit, row.id);
//     //       } 
          
          
//     //       else if (level === 3) {
//     //         // Fetch designations for user type
//     //       response = await getDesignations(row.businessUnit, row.id);
//     //     }
            
//     //         if (response.data?.result?.data) {
//     //       setChildData(response.data.result.data);
//     //         } else if (response.data?.data) {
//     //       setChildData(response.data.data);
//     //         } else if (Array.isArray(response.data)) {
//     //       setChildData(response.data);
//     //         } else {
//     //           console.log('Unexpected response structure:', response.data);
//     //       setChildData([]);
//     //       }
//     //     } catch (error) {
//     //     console.error('Error expanding:', error);
//     //     setChildData([]);
//     //     } finally {
//     //       setLoading(false);
//     //     }
//     // };

//     const fetchChildData = async () => {
//   setLoading(true);
//   try {
//     let response;

//     if (level === 0) {
//       response = await getBusinessUnits(row.id);
//     } else if (level === 1) {
//       response = await getDepartments(row.id);
//     } else if (level === 2) {
//       response = await getUserTypes(row.businessUnit, row.id);
//     } else if (level === 3) {
//       response = await getDesignations(row.businessUnit, row.id);
//     }

//     if (response.data?.result?.data) {
//       let data = response.data.result.data;

//       // 👇 FIX: Filter only for the correct department
//       if (level === 2) {
//         data = data.filter(item => item.department === row.id);
//       }

//       // 👇 If you want to filter designations also (optional)
//       if (level === 3) {
//         data = data.filter(item => item.userType === row.id);
//       }

//       setChildData(data);
//     } 
//     else if (response.data?.data) {
//       setChildData(response.data.data);
//     } 
//     else if (Array.isArray(response.data)) {
//       setChildData(response.data);
//     } 
//     else {
//       console.log('Unexpected response structure:', response.data);
//       setChildData([]);
//     }

//   } catch (error) {
//     console.error('Error expanding:', error);
//     setChildData([]);
//   } finally {
//     setLoading(false);
//   }
// };


//     const getLevelIcon = () => {
//       switch (level) {
//         case 0:
//           return <BusinessIcon />;
//         case 1:
//           return <AccountTreeIcon />;
//         case 2:
//           return <GroupIcon />;
//         case 3:
//           return <PersonIcon />;
//         case 4:
//           return <AssignmentIcon />;
//         default:
//           return null;
//       }
//     };

//     const getLevelHeader = () => {
//       switch (level) {
//         case 0:
//           return "Business Units";
//         case 1:
//           return "Departments";
//         case 2:
//           return "User Types";
//         case 3:
//           return "Designations";
//         default:
//           return "";
//       }
//     };

//     const handleAdd = () => {
//       switch (level) {
//         case 0:
//           onEdit(null, 1, row);
//           break;
//         case 1:
//           onEdit(null, 2, row);
//           break;
//         case 2:
//           onEdit(null, 3, row);
//           break;
//         case 3:
//           onEdit(null, 4, row);
//           break;
//       }
//     };

//     return (
//       <>
//         <Fade in={true}>
//           <TableRow className={classes.nestedRow}>
//           <TableCell>
//               <div className={classes.rowContent}>
//               {(level === 0 || level === 1 || level === 2 || level === 3) && (
//                 <IconButton
//                   size="small"
//                     onClick={() => handleExpand(row, level)}
//                     className={`${classes.expandButton} ${open ? classes.expanded : ''}`}
//                 >
//                   {open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
//                 </IconButton>
//               )}
//                 <div className={classes.levelIndicator} />
//                 {getLevelIcon()}
//                 <Typography variant="body1">{row.name}</Typography>
//                 {row.shortName && (
//                 <Chip
//                     label={row.shortName}
//                   size="small"
//                     className={classes.chip}
//                     color="primary"
//                     variant="outlined"
//                 />
//                 )}
//               </div>
//           </TableCell>
//           <TableCell>
//               <Chip
//                 label={row.isEnabled ? 'Active' : 'Inactive'}
//                 color={row.isEnabled ? 'primary' : 'default'}
//                 className={classes.statusChip}
//                 size="small"
//             />
//           </TableCell>
//           <TableCell>
//               <Tooltip title="Edit">
//                   <IconButton
//                     size="small"
//                   onClick={() => onEdit(row, level)}
//                     className={classes.actionButton}
//                   >
//                   <EditIcon />
//                   </IconButton>
//                 </Tooltip>
//               {level === 1 && (
//                 <Tooltip title="Manage Shifts">
//                   <IconButton
//                     size="small"
//                     onClick={() => handleShiftsClick(row)}
//                     className={classes.actionButton}
//                   >
//                     <ScheduleIcon />
//                   </IconButton>
//                 </Tooltip>
//               )}
//           </TableCell>
//         </TableRow>
//         </Fade>
//         {open && (
//           <>
//           <TableRow>
//               <TableCell colSpan={3} style={{ padding: 0 }}>
//                 <Box margin={1}>
//                   <div className={classes.expandedSection}>
//                   <Table size="small" className={classes.nestedTable}>
//                       <TableHead className={classes.nestedTableHead}>
//                         <TableRow>
//                           <TableCell>
//                             <div className={classes.headerContent}>
//                               <Typography variant="subtitle1" className={classes.headerTitle}>
//                                 {getLevelHeader()}
//                               </Typography>
//                               <Button
//                                 size="small"
//                                 startIcon={<AddIcon />}
//                                 onClick={handleAdd}
//                                 className={classes.addButton}
//                               >
//                                 Add {getLevelHeader().slice(0, -1)}
//                               </Button>
//                             </div>
//                           </TableCell>
//                           <TableCell>Status</TableCell>
//                           <TableCell align="right">Actions</TableCell>
//                         </TableRow>
//                       </TableHead>
//                     <TableBody>
//                       {loading ? (
//                         <TableRow>
//                             <TableCell colSpan={3} align="center">
//                             <CircularProgress size={24} />
//                           </TableCell>
//                         </TableRow>
//                         ) : childData.length > 0 ? (
//                           childData.map((child) => (
//                             <Row
//                               key={child.id}
//                               row={child}
//                               level={level + 1}
//                               onEdit={onEdit}
//                               handleShiftsClick={handleShiftsClick}
//                             />
//                           ))
//                         ) : (
//                           <TableRow>
//                             <TableCell colSpan={3} align="center">
//                               No items found
//                             </TableCell>
//                           </TableRow>
//                         )}
//                     </TableBody>
//                   </Table>
//                   </div>
//                 </Box>
//             </TableCell>
//           </TableRow>
//           </>
//         )}
//       </>
//     );
//   };

//   const handleShiftsClick = (businessUnit) => {
//     setSelectedBusinessUnit(businessUnit);
//     setShiftsDialogOpen(true);
//   };

//   const handleShiftsDialogClose = () => {
//     setShiftsDialogOpen(false);
//     setSelectedBusinessUnit(null);
//   };

//   if (loading && organizations.length === 0) {
//     return (
//       <div className={classes.loadingContainer}>
//         <CircularProgress />
//       </div>
//     );
//   }

//   return (
//     <div className={classes.root}>
//       <div className={classes.header}>
//         <div className={classes.title}>
//           <BusinessIcon color="primary" />
//           <Typography variant="h5">Organizations</Typography>
//         </div>
//       <Button
//         variant="contained"
//         color="primary"
//           startIcon={<AddIcon />}
//           onClick={() => handleOpen(null, 0)}
//         className={classes.addButton}
//       >
//         Add Organization
//       </Button>
//       </div>

//       <Breadcrumbs className={classes.breadcrumbs}>
//         <Link color="inherit" href="#">
//           Admin
//         </Link>
//         <Typography color="textPrimary">Organizations</Typography>
//       </Breadcrumbs>

//       {error && (
//         <Alert severity="error" className={classes.errorAlert} onClose={handleCloseError}>
//           {error}
//         </Alert>
//       )}

//       {loading ? (
//         <div className={classes.loadingContainer}>
//           <CircularProgress />
//         </div>
//       ) : (
//         <TableContainer component={Paper} className={classes.table}>
//           <Table>
//             <TableHead className={classes.tableHead}>
//             <TableRow>
//               <TableCell>Name</TableCell>
//               <TableCell>Status</TableCell>
//               <TableCell>Actions</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {organizations.map((org) => (
//               <Row
//                 key={org.id}
//                 row={org}
//                 level={0}
//                 onEdit={handleOpen}
//                   handleShiftsClick={handleShiftsClick}
//               />
//             ))}
//           </TableBody>
//         </Table>
//       </TableContainer>
//       )}

//       <Dialog
//         open={open}
//         onClose={handleClose}
//         maxWidth="sm"
//         fullWidth
//         TransitionComponent={Zoom}
//       >
//         <DialogTitle className={classes.dialogTitle}>
//           {editingId ? `Edit ${levelNames[editingLevel]}` : `Add ${levelNames[editingLevel]}`}
//         </DialogTitle>
//         <DialogContent className={classes.dialogContent}>
//           <TextField
//             autoFocus
//             margin="dense"
//             label="Name"
//             type="text"
//             fullWidth
//             value={formData.name}
//             onChange={(e) => setFormData({ ...formData, name: e.target.value })}
//           />
//           {editingLevel === 1 && (
//             <TextField
//               margin="dense"
//               label="Short Name"
//               type="text"
//               fullWidth
//               value={formData.shortName}
//               onChange={(e) => setFormData({ ...formData, shortName: e.target.value })}
//             />
//           )}
//           {editingLevel === 4 && (
//             <Box mt={2}>
//               <Typography variant="h6">Permissions</Typography>
//               {permissionGroups.map(group => (
//                 <Box key={group.id} mt={2}>
//                   <Typography variant="subtitle1">{group.name}</Typography>
//                   <FormGroup>
//                     {permissions[group.id]?.map(permission => (
//                       <FormControlLabel
//                         key={permission.id}
//                         control={
//                           <Checkbox
//                             checked={selectedPermissions[group.id]?.[permission.id] || false}
//                             onChange={(e) => handlePermissionChange(group.id, permission.id, e.target.checked)}
//                           />
//                         }
//                         label={permission.name}
//                       />
//                     ))}
//                   </FormGroup>
//                 </Box>
//               ))}
//             </Box>
//           )}
//           <FormControlLabel
//             control={
//               <Switch
//                 checked={formData.isEnabled}
//                 onChange={(e) => setFormData({ ...formData, isEnabled: e.target.checked })}
//                 color="primary"
//               />
//             }
//             label="Enabled"
//           />
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleClose} color="primary">
//             Cancel
//           </Button>
//           <Button onClick={handleSubmit} color="primary" disabled={loading}>
//             {loading ? <CircularProgress size={24} /> : 'Save'}
//           </Button>
//         </DialogActions>
//       </Dialog>

//       <Dialog 
//         open={shiftsDialogOpen} 
//         onClose={handleShiftsDialogClose}
//         maxWidth="md"
//         fullWidth
//       >
//         <DialogTitle>
//           Manage Shifts - {selectedBusinessUnit?.name}
//         </DialogTitle>
//         <DialogContent>
//           {selectedBusinessUnit && (
//             <ShiftsTab businessUnitId={selectedBusinessUnit.id} />
//           )}
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleShiftsDialogClose} color="primary">
//             Close
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </div>
//   );
// }

// export default OrganizationsTab; 



import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  makeStyles,
  Chip,
  Switch,
  FormControlLabel,
  CircularProgress,
  Snackbar,
  Collapse,
  Box,
  Typography,
  Tooltip,
  FormGroup,
  Checkbox,
  Card,
  CardContent,
  Grid,
  Divider,
  Breadcrumbs,
  Link,
  Fade,
  Zoom,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import { 
  Edit as EditIcon,
  KeyboardArrowDown as ExpandMoreIcon,
  KeyboardArrowUp as ExpandLessIcon,
  Add as AddIcon,
  Business as BusinessIcon,
  AccountTree as AccountTreeIcon,
  Group as GroupIcon,
  Assignment as AssignmentIcon,
  Person as PersonIcon,
  Delete as DeleteIcon,
  Schedule as ScheduleIcon,
} from '@material-ui/icons';
import { 
  createOrganization, 
  getOrganizations, 
  updateOrganization,
  getBusinessUnits,
  getDepartments,
  getUserTypes,
  getDesignations,
  updateBusinessUnit,
  createBusinessUnit,
  disableBusinessUnit,
  enableBusinessUnit,
  updateDepartment,
  createDepartment,
  disableDepartment,
  enableDepartment,
  updateUserType,
  createUserType,
  disableUserType,
  enableUserType,
  updateDesignation,
  createDesignation,
  disableDesignation,
  enableDesignation,
  getAllPermissionGroups,
  getAllPermissions,
  deleteOrganization,
  deleteBusinessUnit,
} from '../../../Api/Admin/AdminApi';
import { toast } from 'react-toastify';
import ShiftsTab from './ShiftsTab';

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
    padding: theme.spacing(3),
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing(3),
  },
  title: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
  },
  addButton: {
    marginBottom: theme.spacing(2),
    borderRadius: theme.spacing(2),
    textTransform: 'none',
    padding: theme.spacing(1, 3),
  },
  table: {
    minWidth: 650,
    borderRadius: theme.spacing(1),
    overflow: 'hidden',
    boxShadow: theme.shadows[2],
  },
  tableHead: {
    backgroundColor: theme.palette.primary.main,
    '& .MuiTableCell-head': {
      color: theme.palette.primary.contrastText,
      fontWeight: 'bold',
    },
  },
  dialogContent: {
    minWidth: 400,
    padding: theme.spacing(3),
  },
  dialogTitle: {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    padding: theme.spacing(2, 3),
  },
  chips: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: theme.spacing(1),
    marginTop: theme.spacing(1),
  },
  chip: {
    margin: theme.spacing(0.5),
    borderRadius: theme.spacing(1),
  },
  loadingContainer: {
    display: 'flex',
    justifyContent: 'center',
    padding: theme.spacing(3),
  },
  nestedRow: {
    backgroundColor: theme.palette.background.default,
    transition: 'background-color 0.3s ease',
    '&:hover': {
      backgroundColor: theme.palette.action.hover,
    },
  },
  nestedCell: {
    paddingLeft: theme.spacing(4),
  },
  expandButton: {
    padding: theme.spacing(1),
    transition: 'transform 0.3s ease',
  },
  expanded: {
    transform: 'rotate(180deg)',
  },
  expandedSection: {
    backgroundColor: theme.palette.background.default,
    borderLeft: `4px solid ${theme.palette.primary.main}`,
    borderRadius: theme.shape.borderRadius,
    margin: theme.spacing(1, 0),
    boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
  },
  nestedTable: {
    '& .MuiTableCell-root': {
      borderBottom: 'none',
    },
  },
  nestedTableHead: {
    backgroundColor: theme.palette.grey[50],
    borderBottom: `1px solid ${theme.palette.divider}`,
    '& .MuiTableCell-head': {
      color: theme.palette.text.primary,
      fontWeight: 'bold',
    },
  },
  rowContent: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(2),
  },
  levelIndicator: {
    width: theme.spacing(2),
    height: theme.spacing(2),
    borderRadius: '50%',
    backgroundColor: theme.palette.primary.main,
    opacity: 0.7,
  },
  shortNameField: {
    width: '120px',
    marginRight: theme.spacing(2),
  },
  nameField: {
    flex: 1,
  },
  nameContainer: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: theme.spacing(2),
  },
  addBusinessUnitButton: {
    marginLeft: theme.spacing(2),
    borderRadius: theme.spacing(2),
  },
  domainChip: {
    margin: theme.spacing(0.5),
    borderRadius: theme.spacing(1),
  },
  statusChip: {
    borderRadius: theme.spacing(1),
    fontWeight: 'bold',
  },
  breadcrumbs: {
    marginBottom: theme.spacing(2),
    padding: theme.spacing(1),
    backgroundColor: theme.palette.background.paper,
    borderRadius: theme.spacing(1),
  },
  actionButton: {
    borderRadius: theme.spacing(1),
    textTransform: 'none',
    padding: theme.spacing(0.5, 1),
  },
  errorAlert: {
    marginBottom: theme.spacing(2),
  },
  formGroup: {
    marginTop: theme.spacing(2),
  },
  permissionSection: {
    marginTop: theme.spacing(3),
    padding: theme.spacing(2),
    backgroundColor: theme.palette.background.default,
    borderRadius: theme.spacing(1),
  },
  permissionGroup: {
    marginBottom: theme.spacing(2),
  },
  permissionGroupTitle: {
    marginBottom: theme.spacing(1),
    color: theme.palette.text.secondary,
  },
  headerContent: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing(1, 0),
  },
  headerTitle: {
    fontWeight: 'bold',
    color: theme.palette.text.primary,
  },
}));

// Memoized Row component to prevent unnecessary re-renders
const Row = React.memo(({ row, level, onEdit, handleShiftsClick, isExpanded, onExpand, expandedItems }) => {
  const [loading, setLoading] = useState(false);
  const [childData, setChildData] = useState([]);
  const classes = useStyles();
  const open = isExpanded;

  useEffect(() => {
    if (open && childData.length === 0) {
      fetchChildData();
    }
  }, [open]);

  const fetchChildData = async () => {
    setLoading(true);
    try {
      let response;

      if (level === 0) {
        response = await getBusinessUnits(row.id);
      } else if (level === 1) {
        response = await getDepartments(row.id);
      } else if (level === 2) {
        response = await getUserTypes(row.businessUnit, row.id);
      } else if (level === 3) {
        response = await getDesignations(row.businessUnit, row.id);
      }

      if (response.data?.result?.data) {
        let data = response.data.result.data;

        if (level === 2) {
          data = data.filter(item => item.department === row.id);
        }

        if (level === 3) {
          data = data.filter(item => item.userType === row.id);
        }

        setChildData(data);
      } 
      else if (response.data?.data) {
        setChildData(response.data.data);
      } 
      else if (Array.isArray(response.data)) {
        setChildData(response.data);
      } 
      else {
       
        setChildData([]);
      }

    } catch (error) {
    
      setChildData([]);
    } finally {
      setLoading(false);
    }
  };

  const getLevelIcon = useMemo(() => {
    switch (level) {
      case 0:
        return <BusinessIcon />;
      case 1:
        return <AccountTreeIcon />;
      case 2:
        return <GroupIcon />;
      case 3:
        return <PersonIcon />;
      case 4:
        return <AssignmentIcon />;
      default:
        return null;
    }
  }, [level]);

  const getLevelHeader = useMemo(() => {
    switch (level) {
      case 0:
        return "Business Units";
      case 1:
        return "Departments";
      case 2:
        return "User Types";
      case 3:
        return "Designations";
      default:
        return "";
    }
  }, [level]);

  const handleAdd = useCallback(() => {
    switch (level) {
      case 0:
        onEdit(null, 1, row);
        break;
      case 1:
        onEdit(null, 2, row);
        break;
      case 2:
        onEdit(null, 3, row);
        break;
      case 3:
        onEdit(null, 4, row);
        break;
    }
  }, [level, onEdit, row]);

  const handleExpandClick = useCallback(() => {
    onExpand(row, level);
  }, [onExpand, row, level]);

  const handleEditClick = useCallback(() => {
    onEdit(row, level);
  }, [onEdit, row, level]);

  const handleShiftsClickMemo = useCallback(() => {
    handleShiftsClick(row);
  }, [handleShiftsClick, row]);

  return (
    <>
      <Fade in={true}>
        <TableRow className={classes.nestedRow}>
          <TableCell>
            <div className={classes.rowContent}>
              {(level === 0 || level === 1 || level === 2 || level === 3) && (
                <IconButton
                  size="small"
                  onClick={handleExpandClick}
                  className={`${classes.expandButton} ${open ? classes.expanded : ''}`}
                >
                  {open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                </IconButton>
              )}
              <div className={classes.levelIndicator} />
              {getLevelIcon}
              <Typography variant="body1">{row.name}</Typography>
              {row.shortName && (
                <Chip
                  label={row.shortName}
                  size="small"
                  className={classes.chip}
                  color="primary"
                  variant="outlined"
                />
              )}
            </div>
          </TableCell>
          <TableCell>
            <Chip
              label={row.isEnabled ? 'Active' : 'Inactive'}
              color={row.isEnabled ? 'primary' : 'default'}
              className={classes.statusChip}
              size="small"
            />
          </TableCell>
          <TableCell>
            <Tooltip title="Edit">
              <IconButton
                size="small"
                onClick={handleEditClick}
                className={classes.actionButton}
              >
                <EditIcon />
              </IconButton>
            </Tooltip>
            {level === 1 && (
              <Tooltip title="Manage Shifts">
                <IconButton
                  size="small"
                  onClick={handleShiftsClickMemo}
                  className={classes.actionButton}
                >
                  <ScheduleIcon />
                </IconButton>
              </Tooltip>
            )}
          </TableCell>
        </TableRow>
      </Fade>
      {open && (
        <TableRow>
          <TableCell colSpan={3} style={{ padding: 0 }}>
            <Box margin={1}>
              <div className={classes.expandedSection}>
                <Table size="small" className={classes.nestedTable}>
                  <TableHead className={classes.nestedTableHead}>
                    <TableRow>
                      <TableCell>
                        <div className={classes.headerContent}>
                          <Typography variant="subtitle1" className={classes.headerTitle}>
                            {getLevelHeader}
                          </Typography>
                          <Button
                            size="small"
                            startIcon={<AddIcon />}
                            onClick={handleAdd}
                            className={classes.addButton}
                          >
                            Add {getLevelHeader.slice(0, -1)}
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell align="right">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {loading ? (
                      <TableRow>
                        <TableCell colSpan={3} align="center">
                          <CircularProgress size={24} />
                        </TableCell>
                      </TableRow>
                    ) : childData.length > 0 ? (
                      childData.map((child) => {
                        const childKey = `${level + 1}-${child.id}`;
                        const childExpanded = expandedItems?.has?.(childKey) || false;
                        return (
                          <Row
                            key={child.id}
                            row={child}
                            level={level + 1}
                            onEdit={onEdit}
                            handleShiftsClick={handleShiftsClick}
                            isExpanded={childExpanded}
                            onExpand={onExpand}
                            expandedItems={expandedItems}
                          />
                        );
                      })
                    ) : (
                      <TableRow>
                        <TableCell colSpan={3} align="center">
                          No items found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </Box>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}, (prevProps, nextProps) => {
  // Custom comparison function for memo
  return (
    prevProps.row.id === nextProps.row.id &&
    prevProps.row.name === nextProps.row.name &&
    prevProps.row.isEnabled === nextProps.row.isEnabled &&
    prevProps.level === nextProps.level &&
    prevProps.isExpanded === nextProps.isExpanded &&
    prevProps.expandedItems === nextProps.expandedItems
  );
});

function OrganizationsTab() {
  const classes = useStyles();
  const [organizations, setOrganizations] = useState([]);
  const [businessUnits, setBusinessUnits] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [userTypes, setUserTypes] = useState([]);
  const [designations, setDesignations] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    shortName: '',
    isEnabled: true,
  });
  const [editingId, setEditingId] = useState(null);
  const [editingLevel, setEditingLevel] = useState(0);
  const [selectedOrganization, setSelectedOrganization] = useState(null);
  const [selectedBusinessUnit, setSelectedBusinessUnit] = useState(null);
  const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [selectedUserType, setSelectedUserType] = useState(null);
  const [selectedPermissions, setSelectedPermissions] = useState({});
  const [newDomain, setNewDomain] = useState('');
  const [permissionGroups, setPermissionGroups] = useState([]);
  const [permissions, setPermissions] = useState({});
  const [originalRow, setOriginalRow] = useState(null);
  const [expandedItems, setExpandedItems] = useState(new Set());
  const [shiftsDialogOpen, setShiftsDialogOpen] = useState(false);

  const levelNames = useMemo(() => ['Organization', 'Business Unit', 'Department', 'User Type', 'Designation'], []);

  useEffect(() => {
    fetchOrganizations();
    fetchPermissionGroups();
  }, []);

  const fetchOrganizations = async () => {
    try {
      setLoading(true);
      const response = await getOrganizations();
      if (response.data?.result?.data) {
        setOrganizations(response.data.result.data);
      } else {
       
        setOrganizations([]);
      }
    } catch (error) {
      console.error('Error fetching organizations:', error);
      setError(error.response?.data?.message || 'Error fetching organizations');
    } finally {
      setLoading(false);
    }
  };

  const fetchPermissionGroups = async () => {
    try {
      const response = await getAllPermissionGroups({ selectFields: "name" });
      if (response.data?.result?.data) {
        setPermissionGroups(response.data.result.data);
        response.data.result.data.forEach(group => {
          fetchPermissions(group.id);
        });
      }
    } catch (error) {
      console.error('Error fetching permission groups:', error);
      setError(error.response?.data?.message || 'Error fetching permission groups');
    }
  };

  const fetchPermissions = async (groupId) => {
    try {
      const response = await getAllPermissions({ 
        permissionGroups: [groupId],
        selectFields: "name"
      });
      if (response.data?.result?.data) {
        setPermissions(prev => ({
          ...prev,
          [groupId]: response.data.result.data
        }));
      }
    } catch (error) {
      console.error('Error fetching permissions:', error);
      setError(error.response?.data?.message || 'Error fetching permissions');
    }
  };

  const handlePermissionChange = useCallback((groupId, permissionId, checked) => {
    setSelectedPermissions(prev => {
      const groupPermissions = prev[groupId] || {};
      return {
        ...prev,
        [groupId]: {
          ...groupPermissions,
          [permissionId]: checked
        }
      };
    });
  }, []);

  const handleOpen = useCallback(async (row = null, level = 0, parentRow = null) => {
    if (row) {
      setOriginalRow(row);
      if (level === 0) {
        setFormData({
          name: row.name,
          isEnabled: row.isEnabled,
        });
      } else if (level === 1) {
        setFormData({
          name: row.name,
          shortName: row.shortName,
          isEnabled: row.isEnabled
        });
        const parentOrg = organizations.find(org => org.id === row.organization);
        setSelectedOrganization(parentOrg);
      } else if (level === 2) {
        setFormData({
          name: row.name,
          isEnabled: row.isEnabled
        });
        
        // Fetch business units if not already loaded
        let parentBU = businessUnits.find(bu => bu.id === row.businessUnit);
        if (!parentBU) {
          try {
            const response = await getBusinessUnits();
            if (response.data?.result?.data) {
              setBusinessUnits(response.data.result.data);
              parentBU = response.data.result.data.find(bu => bu.id === row.businessUnit);
            }
          } catch (error) {
            console.error('Error fetching business units:', error);
          }
        }
        
        setSelectedBusinessUnit(parentBU);
        if (parentBU) {
          const parentOrg = organizations.find(org => org.id === parentBU.organization);
          setSelectedOrganization(parentOrg);
        }
      } else if (level === 3) {
        setFormData({
          name: row.name,
          isEnabled: row.isEnabled
        });
        
        // Fetch departments if not already loaded
        let parentDept = departments.find(dept => dept.id === row.department);
        if (!parentDept) {
          try {
            const response = await getDepartments(row.businessUnit);
            if (response.data?.result?.data) {
              setDepartments(response.data.result.data);
              parentDept = response.data.result.data.find(dept => dept.id === row.department);
            }
          } catch (error) {
            console.error('Error fetching departments:', error);
          }
        }
        
        setSelectedDepartment(parentDept);
        if (parentDept) {
          let parentBU = businessUnits.find(bu => bu.id === parentDept.businessUnit);
          if (!parentBU) {
            try {
              const response = await getBusinessUnits();
              if (response.data?.result?.data) {
                setBusinessUnits(response.data.result.data);
                parentBU = response.data.result.data.find(bu => bu.id === parentDept.businessUnit);
              }
            } catch (error) {
              console.error('Error fetching business units:', error);
            }
          }
          setSelectedBusinessUnit(parentBU);
          if (parentBU) {
            const parentOrg = organizations.find(org => org.id === parentBU.organization);
            setSelectedOrganization(parentOrg);
          }
        }
      } else if (level === 4) {
        setFormData({
          name: row.name,
          isEnabled: row.isEnabled,
          permissions: row.permissions || {}
        });
        
        const initialPermissions = {};
        permissionGroups.forEach(group => {
          initialPermissions[group.id] = {};
        });

        if (row.permissions) {
          Object.entries(row.permissions).forEach(([groupName, groupPermissions]) => {
            const group = permissionGroups.find(g => g.name.toLowerCase() === groupName.toLowerCase());
            if (group) {
              Object.entries(groupPermissions).forEach(([permissionName, permissionData]) => {
                if (permissionData && permissionData.id) {
                  initialPermissions[group.id][permissionData.id] = true;
                }
              });
            }
          });
        }
        
        setSelectedPermissions(initialPermissions);
        
        // Fetch user types if not already loaded
        let parentUT = userTypes.find(ut => ut.id === row.userType);
        if (!parentUT) {
          try {
            const response = await getUserTypes(row.businessUnit, row.department);
            if (response.data?.result?.data) {
              setUserTypes(response.data.result.data);
              parentUT = response.data.result.data.find(ut => ut.id === row.userType);
            }
          } catch (error) {
            console.error('Error fetching user types:', error);
          }
        }
        
        setSelectedUserType(parentUT);
        
        if (parentUT) {
          let parentDept = departments.find(dept => dept.id === parentUT.department);
          if (!parentDept) {
            try {
              const response = await getDepartments(row.businessUnit);
              if (response.data?.result?.data) {
                setDepartments(response.data.result.data);
                parentDept = response.data.result.data.find(dept => dept.id === parentUT.department);
              }
            } catch (error) {
              console.error('Error fetching departments:', error);
            }
          }
          setSelectedDepartment(parentDept);
          
          if (parentDept) {
            let parentBU = businessUnits.find(bu => bu.id === parentDept.businessUnit);
            if (!parentBU) {
              try {
                const response = await getBusinessUnits();
                if (response.data?.result?.data) {
                  setBusinessUnits(response.data.result.data);
                  parentBU = response.data.result.data.find(bu => bu.id === parentDept.businessUnit);
                }
              } catch (error) {
                console.error('Error fetching business units:', error);
              }
            }
            setSelectedBusinessUnit(parentBU);
            
            if (parentBU) {
              const parentOrg = organizations.find(org => org.id === parentBU.organization);
              setSelectedOrganization(parentOrg);
            }
          }
        }
      }
      setEditingId(row.id);
      setEditingLevel(level);
    } else {
      setOriginalRow(null);
      if (level === 0) {
        setFormData({
          name: '',
          isEnabled: true,
        });
      } else if (level === 1 && parentRow) {
        setFormData({
          name: '',
          shortName: '',
          isEnabled: true
        });
        setSelectedOrganization(parentRow);
      } else if (level === 2 && parentRow) {
        setFormData({
          name: '',
          isEnabled: true
        });
        setSelectedBusinessUnit(parentRow);
      } else if (level === 3 && parentRow) {
        setFormData({
          name: '',
          isEnabled: true
        });
        setSelectedDepartment(parentRow);
      } else if (level === 4 && parentRow) {
        setFormData({
          name: '',
          isEnabled: true,
          permissions: {}
        });
        setSelectedUserType(parentRow);
      }
      setEditingId(null);
      setEditingLevel(level);
    }
    setOpen(true);
  }, [organizations, businessUnits, departments, userTypes, permissionGroups]);

  const handleClose = useCallback(() => {
    setOpen(false);
    setFormData({
      name: '',
      shortName: '',
      isEnabled: true,
    });
    setEditingId(null);
    setEditingLevel(0);
    setSelectedOrganization(null);
    setSelectedBusinessUnit(null);
    setSelectedDepartment(null);
    setSelectedUserType(null);
    setSelectedPermissions({});
    setNewDomain('');
    setOriginalRow(null);
  }, []);

  const handleSubmit = useCallback(async () => {
    setLoading(true);
    try {
      if (editingLevel === 0) {
        if (editingId) {
          await updateOrganization(editingId, formData);
        } else {
          await createOrganization(formData);
        }
      } else if (editingLevel === 1) {
        if (!selectedOrganization) {
          throw new Error('Organization is required for business unit operations');
        }
        const businessUnitData = {
          name: formData.name,
          shortName: formData.shortName,
          isEnabled: formData.isEnabled,
          organization: selectedOrganization.id
        };
        
        if (editingId) {
          await updateBusinessUnit(editingId, businessUnitData);
        } else {
          await createBusinessUnit(selectedOrganization.id, businessUnitData);
        }
      } else if (editingLevel === 2) {
        if (!selectedBusinessUnit) {
          throw new Error('Business Unit is required for department operations');
        }
        const departmentData = {
          name: formData.name,
          isEnabled: formData.isEnabled,
          businessUnit: selectedBusinessUnit.id
        };
        
        if (editingId) {
          await updateDepartment(editingId, departmentData, selectedBusinessUnit.id);
        } else {
          await createDepartment(selectedBusinessUnit.id, departmentData);
        }
      } else if (editingLevel === 3) {
        const userTypeData = {
          name: formData.name,
          isEnabled: formData.isEnabled
        };
        
        if (editingId) {
          await updateUserType(editingId, userTypeData);
        } else {
          await createUserType(selectedDepartment.businessUnit, selectedDepartment.id, userTypeData);
        }
      } else if (editingLevel === 4) {
        const designationData = {
          isEnabled: formData.isEnabled
        };

        if (editingId) {
          const originalName = originalRow?.name;
          if (originalName !== formData.name) {
            designationData.name = formData.name;
          }
        } else {
          designationData.name = formData.name;
        }
        
        const selectedPermissionIds = Object.values(selectedPermissions)
          .flatMap(groupPermissions => 
            Object.entries(groupPermissions)
              .filter(([_, selected]) => selected)
              .map(([permissionId]) => permissionId)
          );
        
        if (selectedPermissionIds.length > 0) {
          designationData.permissions = selectedPermissionIds;
        }
        
        if (editingId) {
          await updateDesignation(editingId, designationData);
        } else {
          await createDesignation(selectedUserType.businessUnit, selectedUserType.id, designationData);
        }
      }
      
      handleClose();
      await fetchOrganizations();
      toast.success('Saved successfully');
    } catch (error) {
      console.error('Error saving:', error);
      setError(error.response?.data?.message || 'Error saving data');
      toast.error(error.response?.data?.message || 'Error saving data');
    } finally {
      setLoading(false);
    }
  }, [editingLevel, editingId, formData, selectedOrganization, selectedBusinessUnit, selectedDepartment, selectedUserType, selectedPermissions, originalRow, handleClose]);

  const handleCloseError = useCallback(() => {
    setError(null);
  }, []);

  const handleExpand = useCallback((row, level) => {
    const itemKey = `${level}-${row.id}`;
    setExpandedItems(prev => {
      const newExpandedItems = new Set(prev);
      
      if (prev.has(itemKey)) {
        const keysToRemove = Array.from(prev).filter(key => {
          const [keyLevel] = key.split('-');
          return parseInt(keyLevel) > level;
        });
        keysToRemove.forEach(key => newExpandedItems.delete(key));
        newExpandedItems.delete(itemKey);
      } else {
        newExpandedItems.add(itemKey);
      }
      
      return newExpandedItems;
    });
  }, []);

  const isExpanded = useCallback((row, level) => {
    return expandedItems.has(`${level}-${row.id}`);
  }, [expandedItems]);

  const handleShiftsClick = useCallback((businessUnit) => {
    setSelectedBusinessUnit(businessUnit);
    setShiftsDialogOpen(true);
  }, []);

  const handleShiftsDialogClose = useCallback(() => {
    setShiftsDialogOpen(false);
    setSelectedBusinessUnit(null);
  }, []);

  if (loading && organizations.length === 0) {
    return (
      <div className={classes.loadingContainer}>
        <CircularProgress />
      </div>
    );
  }

  return (
    <div className={classes.root}>
      <div className={classes.header}>
        <div className={classes.title}>
          <BusinessIcon color="primary" />
          <Typography variant="h5">Organizations</Typography>
        </div>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpen(null, 0)}
          className={classes.addButton}
        >
          Add Organization
        </Button>
      </div>

      <Breadcrumbs className={classes.breadcrumbs}>
        <Link color="inherit" href="#">
          Admin
        </Link>
        <Typography color="textPrimary">Organizations</Typography>
      </Breadcrumbs>

      {error && (
        <Alert severity="error" className={classes.errorAlert} onClose={handleCloseError}>
          {error}
        </Alert>
      )}

      {loading ? (
        <div className={classes.loadingContainer}>
          <CircularProgress />
        </div>
      ) : (
        <TableContainer component={Paper} className={classes.table}>
          <Table>
            <TableHead className={classes.tableHead}>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {organizations.map((org) => {
                const orgKey = `0-${org.id}`;
                const orgExpanded = expandedItems.has(orgKey);
                return (
                  <Row
                    key={org.id}
                    row={org}
                    level={0}
                    onEdit={handleOpen}
                    handleShiftsClick={handleShiftsClick}
                    isExpanded={orgExpanded}
                    onExpand={handleExpand}
                    expandedItems={expandedItems}
                  />
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="sm"
        fullWidth
        TransitionComponent={Zoom}
      >
        <DialogTitle className={classes.dialogTitle}>
          {editingId ? `Edit ${levelNames[editingLevel]}` : `Add ${levelNames[editingLevel]}`}
        </DialogTitle>
        <DialogContent className={classes.dialogContent}>
          <TextField
            autoFocus
            margin="dense"
            label="Name"
            type="text"
            fullWidth
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
          {editingLevel === 1 && (
            <TextField
              margin="dense"
              label="Short Name"
              type="text"
              fullWidth
              value={formData.shortName}
              onChange={(e) => setFormData({ ...formData, shortName: e.target.value })}
            />
          )}
          {editingLevel === 4 && (
            <Box mt={2}>
              <Typography variant="h6">Permissions</Typography>
              {permissionGroups.map(group => (
                <Box key={group.id} mt={2}>
                  <Typography variant="subtitle1">{group.name}</Typography>
                  <FormGroup>
                    {permissions[group.id]?.map(permission => (
                      <FormControlLabel
                        key={permission.id}
                        control={
                          <Checkbox
                            checked={selectedPermissions[group.id]?.[permission.id] || false}
                            onChange={(e) => handlePermissionChange(group.id, permission.id, e.target.checked)}
                          />
                        }
                        label={permission.name}
                      />
                    ))}
                  </FormGroup>
                </Box>
              ))}
            </Box>
          )}
          <FormControlLabel
            control={
              <Switch
                checked={formData.isEnabled}
                onChange={(e) => setFormData({ ...formData, isEnabled: e.target.checked })}
                color="primary"
              />
            }
            label="Enabled"
            style={{ marginTop: '16px' }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} color="primary" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog 
        open={shiftsDialogOpen} 
        onClose={handleShiftsDialogClose}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Manage Shifts - {selectedBusinessUnit?.name}
        </DialogTitle>
        <DialogContent>
          {selectedBusinessUnit && (
            <ShiftsTab businessUnitId={selectedBusinessUnit.id} />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleShiftsDialogClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default OrganizationsTab;

//last updated code with timezone
// import React, { useState, useEffect, useCallback, useMemo } from 'react';
// import {
//   Button,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   TextField,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   IconButton,
//   makeStyles,
//   Chip,
//   Switch,
//   FormControlLabel,
//   CircularProgress,
//   Snackbar,
//   Collapse,
//   Box,
//   Typography,
//   Tooltip,
//   FormGroup,
//   Checkbox,
//   Card,
//   CardContent,
//   Grid,
//   Divider,
//   Breadcrumbs,
//   Link,
//   Fade,
//   Zoom,
//   // FormControl,
//   // InputLabel,
//   // Select,
//   // MenuItem,
// } from '@material-ui/core';
// // import {
// //   FormControl,
// //   InputLabel,
// //   Select,
// //   MenuItem,
// // } from "@mui/material";
// import {  Autocomplete } from "@mui/material";
// import { DateTime } from "luxon";
// import { Alert } from '@material-ui/lab';
// import { 
//   Edit as EditIcon,
//   KeyboardArrowDown as ExpandMoreIcon,
//   KeyboardArrowUp as ExpandLessIcon,
//   Add as AddIcon,
//   Business as BusinessIcon,
//   AccountTree as AccountTreeIcon,
//   Group as GroupIcon,
//   Assignment as AssignmentIcon,
//   Person as PersonIcon,
//   Delete as DeleteIcon,
//   Schedule as ScheduleIcon,
// } from '@material-ui/icons';
// import { 
//   createOrganization, 
//   getOrganizations, 
//   updateOrganization,
//   getBusinessUnits,
//   getDepartments,
//   getUserTypes,
//   getDesignations,
//   updateBusinessUnit,
//   createBusinessUnit,
//   disableBusinessUnit,
//   enableBusinessUnit,
//   updateDepartment,
//   createDepartment,
//   disableDepartment,
//   enableDepartment,
//   updateUserType,
//   createUserType,
//   disableUserType,
//   enableUserType,
//   updateDesignation,
//   createDesignation,
//   disableDesignation,
//   enableDesignation,
//   getAllPermissionGroups,
//   getAllPermissions,
//   deleteOrganization,
//   deleteBusinessUnit,
// } from '../../../Api/Admin/AdminApi';
// import { toast } from 'react-toastify';
// import ShiftsTab from './ShiftsTab';


// const useStyles = makeStyles((theme) => ({
//   root: {
//     width: '100%',
//     padding: theme.spacing(3),
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: theme.spacing(3),
//   },
//   title: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: theme.spacing(1),
//   },
//   addButton: {
//     marginBottom: theme.spacing(2),
//     borderRadius: theme.spacing(2),
//     textTransform: 'none',
//     padding: theme.spacing(1, 3),
//   },
//   table: {
//     minWidth: 650,
//     borderRadius: theme.spacing(1),
//     overflow: 'hidden',
//     boxShadow: theme.shadows[2],
//   },
//   tableHead: {
//     backgroundColor: theme.palette.primary.main,
//     '& .MuiTableCell-head': {
//       color: theme.palette.primary.contrastText,
//       fontWeight: 'bold',
//     },
//   },
//   dialogContent: {
//     minWidth: 400,
//     padding: theme.spacing(3),
//   },
//   dialogTitle: {
//     backgroundColor: theme.palette.primary.main,
//     color: theme.palette.primary.contrastText,
//     padding: theme.spacing(2, 3),
//   },
//   chips: {
//     display: 'flex',
//     flexWrap: 'wrap',
//     gap: theme.spacing(1),
//     marginTop: theme.spacing(1),
//   },
//   chip: {
//     margin: theme.spacing(0.5),
//     borderRadius: theme.spacing(1),
//   },
//   loadingContainer: {
//     display: 'flex',
//     justifyContent: 'center',
//     padding: theme.spacing(3),
//   },
//   nestedRow: {
//     backgroundColor: theme.palette.background.default,
//     transition: 'background-color 0.3s ease',
//     '&:hover': {
//       backgroundColor: theme.palette.action.hover,
//     },
//   },
//   nestedCell: {
//     paddingLeft: theme.spacing(4),
//   },
//   expandButton: {
//     padding: theme.spacing(1),
//     transition: 'transform 0.3s ease',
//   },
//   expanded: {
//     transform: 'rotate(180deg)',
//   },
//   expandedSection: {
//     backgroundColor: theme.palette.background.default,
//     borderLeft: `4px solid ${theme.palette.primary.main}`,
//     borderRadius: theme.shape.borderRadius,
//     margin: theme.spacing(1, 0),
//     boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
//   },
//   nestedTable: {
//     '& .MuiTableCell-root': {
//       borderBottom: 'none',
//     },
//   },
//   nestedTableHead: {
//     backgroundColor: theme.palette.grey[50],
//     borderBottom: `1px solid ${theme.palette.divider}`,
//     '& .MuiTableCell-head': {
//       color: theme.palette.text.primary,
//       fontWeight: 'bold',
//     },
//   },
//   rowContent: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: theme.spacing(2),
//   },
//   levelIndicator: {
//     width: theme.spacing(2),
//     height: theme.spacing(2),
//     borderRadius: '50%',
//     backgroundColor: theme.palette.primary.main,
//     opacity: 0.7,
//   },
//   shortNameField: {
//     width: '120px',
//     marginRight: theme.spacing(2),
//   },
//   nameField: {
//     flex: 1,
//   },
//   nameContainer: {
//     display: 'flex',
//     alignItems: 'flex-start',
//     gap: theme.spacing(2),
//   },
//   addBusinessUnitButton: {
//     marginLeft: theme.spacing(2),
//     borderRadius: theme.spacing(2),
//   },
//   domainChip: {
//     margin: theme.spacing(0.5),
//     borderRadius: theme.spacing(1),
//   },
//   statusChip: {
//     borderRadius: theme.spacing(1),
//     fontWeight: 'bold',
//   },
//   breadcrumbs: {
//     marginBottom: theme.spacing(2),
//     padding: theme.spacing(1),
//     backgroundColor: theme.palette.background.paper,
//     borderRadius: theme.spacing(1),
//   },
//   actionButton: {
//     borderRadius: theme.spacing(1),
//     textTransform: 'none',
//     padding: theme.spacing(0.5, 1),
//   },
//   errorAlert: {
//     marginBottom: theme.spacing(2),
//   },
//   formGroup: {
//     marginTop: theme.spacing(2),
//   },
//   permissionSection: {
//     marginTop: theme.spacing(3),
//     padding: theme.spacing(2),
//     backgroundColor: theme.palette.background.default,
//     borderRadius: theme.spacing(1),
//   },
//   permissionGroup: {
//     marginBottom: theme.spacing(2),
//   },
//   permissionGroupTitle: {
//     marginBottom: theme.spacing(1),
//     color: theme.palette.text.secondary,
//   },
//   headerContent: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     padding: theme.spacing(1, 0),
//   },
//   headerTitle: {
//     fontWeight: 'bold',
//     color: theme.palette.text.primary,
//   },
// }));

// // Memoized Row component to prevent unnecessary re-renders
// const Row = React.memo(({ row, level, onEdit, handleShiftsClick, isExpanded, onExpand, expandedItems }) => {
//   const [loading, setLoading] = useState(false);
//   const [childData, setChildData] = useState([]);

//   const classes = useStyles();
//   const open = isExpanded;

//   useEffect(() => {
//     if (open && childData.length === 0) {
//       fetchChildData();
//     }
//   }, [open]);

//   const fetchChildData = async () => {
//     setLoading(true);
//     try {
//       let response;

//       if (level === 0) {
//         response = await getBusinessUnits(row.id);
//       } else if (level === 1) {
//         response = await getDepartments(row.id);
//       } else if (level === 2) {
//         response = await getUserTypes(row.businessUnit, row.id);
//       } else if (level === 3) {
//         response = await getDesignations(row.businessUnit, row.id);
//       }

//       if (response.data?.result?.data) {
//         let data = response.data.result.data;

//         if (level === 2) {
//           data = data.filter(item => item.department === row.id);
//         }

//         if (level === 3) {
//           data = data.filter(item => item.userType === row.id);
//         }

//         setChildData(data);
//       } 
//       else if (response.data?.data) {
//         setChildData(response.data.data);
//       } 
//       else if (Array.isArray(response.data)) {
//         setChildData(response.data);
//       } 
//       else {
       
//         setChildData([]);
//       }

//     } catch (error) {
    
//       setChildData([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const getLevelIcon = useMemo(() => {
//     switch (level) {
//       case 0:
//         return <BusinessIcon />;
//       case 1:
//         return <AccountTreeIcon />;
//       case 2:
//         return <GroupIcon />;
//       case 3:
//         return <PersonIcon />;
//       case 4:
//         return <AssignmentIcon />;
//       default:
//         return null;
//     }
//   }, [level]);

//   const getLevelHeader = useMemo(() => {
//     switch (level) {
//       case 0:
//         return "Business Units";
//       case 1:
//         return "Departments";
//       case 2:
//         return "User Types";
//       case 3:
//         return "Designations";
//       default:
//         return "";
//     }
//   }, [level]);

//   const handleAdd = useCallback(() => {
//     switch (level) {
//       case 0:
//         onEdit(null, 1, row);
//         break;
//       case 1:
//         onEdit(null, 2, row);
//         break;
//       case 2:
//         onEdit(null, 3, row);
//         break;
//       case 3:
//         onEdit(null, 4, row);
//         break;
//     }
//   }, [level, onEdit, row]);

//   const handleExpandClick = useCallback(() => {
//     onExpand(row, level);
//   }, [onExpand, row, level]);

//   const handleEditClick = useCallback(() => {
//     onEdit(row, level);
//   }, [onEdit, row, level]);

//   const handleShiftsClickMemo = useCallback(() => {
//     handleShiftsClick(row);
//   }, [handleShiftsClick, row]);

//   return (
//     <>
//       <Fade in={true}>
//         <TableRow className={classes.nestedRow}>
//           <TableCell>
//             <div className={classes.rowContent}>
//               {(level === 0 || level === 1 || level === 2 || level === 3) && (
//                 <IconButton
//                   size="small"
//                   onClick={handleExpandClick}
//                   className={`${classes.expandButton} ${open ? classes.expanded : ''}`}
//                 >
//                   {open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
//                 </IconButton>
//               )}
//               <div className={classes.levelIndicator} />
//               {getLevelIcon}
//               <Typography variant="body1">{row.name}</Typography>
//               {row.shortName && (
//                 <Chip
//                   label={row.shortName}
//                   size="small"
//                   className={classes.chip}
//                   color="primary"
//                   variant="outlined"
//                 />
//               )}
//             </div>
//           </TableCell>
//           <TableCell>
//             <Chip
//               label={row.isEnabled ? 'Active' : 'Inactive'}
//               color={row.isEnabled ? 'primary' : 'default'}
//               className={classes.statusChip}
//               size="small"
//             />
//           </TableCell>
//           <TableCell>
//             <Tooltip title="Edit">
//               <IconButton
//                 size="small"
//                 onClick={handleEditClick}
//                 className={classes.actionButton}
//               >
//                 <EditIcon />
//               </IconButton>
//             </Tooltip>
//             {level === 1 && (
//               <Tooltip title="Manage Shifts">
//                 <IconButton
//                   size="small"
//                   onClick={handleShiftsClickMemo}
//                   className={classes.actionButton}
//                 >
//                   <ScheduleIcon />
//                 </IconButton>
//               </Tooltip>
//             )}
//           </TableCell>
//         </TableRow>
//       </Fade>
//       {open && (
//         <TableRow>
//           <TableCell colSpan={3} style={{ padding: 0 }}>
//             <Box margin={1}>
//               <div className={classes.expandedSection}>
//                 <Table size="small" className={classes.nestedTable}>
//                   <TableHead className={classes.nestedTableHead}>
//                     <TableRow>
//                       <TableCell>
//                         <div className={classes.headerContent}>
//                           <Typography variant="subtitle1" className={classes.headerTitle}>
//                             {getLevelHeader}
//                           </Typography>
//                           <Button
//                             size="small"
//                             startIcon={<AddIcon />}
//                             onClick={handleAdd}
//                             className={classes.addButton}
//                           >
//                             Add {getLevelHeader.slice(0, -1)}
//                           </Button>
//                         </div>
//                       </TableCell>
//                       <TableCell>Status</TableCell>
//                       <TableCell align="right">Actions</TableCell>
//                     </TableRow>
//                   </TableHead>
//                   <TableBody>
//                     {loading ? (
//                       <TableRow>
//                         <TableCell colSpan={3} align="center">
//                           <CircularProgress size={24} />
//                         </TableCell>
//                       </TableRow>
//                     ) : childData.length > 0 ? (
//                       childData.map((child) => {
//                         const childKey = `${level + 1}-${child.id}`;
//                         const childExpanded = expandedItems?.has?.(childKey) || false;
//                         return (
//                           <Row
//                             key={child.id}
//                             row={child}
//                             level={level + 1}
//                             onEdit={onEdit}
//                             handleShiftsClick={handleShiftsClick}
//                             isExpanded={childExpanded}
//                             onExpand={onExpand}
//                             expandedItems={expandedItems}
//                           />
//                         );
//                       })
//                     ) : (
//                       <TableRow>
//                         <TableCell colSpan={3} align="center">
//                           No items found
//                         </TableCell>
//                       </TableRow>
//                     )}
//                   </TableBody>
//                 </Table>
//               </div>
//             </Box>
//           </TableCell>
//         </TableRow>
//       )}
//     </>
//   );
// }, (prevProps, nextProps) => {
//   // Custom comparison function for memo
//   return (
//     prevProps.row.id === nextProps.row.id &&
//     prevProps.row.name === nextProps.row.name &&
//     prevProps.row.isEnabled === nextProps.row.isEnabled &&
//     prevProps.level === nextProps.level &&
//     prevProps.isExpanded === nextProps.isExpanded &&
//     prevProps.expandedItems === nextProps.expandedItems
//   );
// });

// //lastworking code
// function TimezoneDropdown({ value, onChange,disabled }) {

//   const getOffset = (zone) => {
//     const now = DateTime.now().setZone(zone);
//     return now.offset; // offset in minutes
//   };
//    const timezones = Intl.supportedValuesOf("timeZone").sort(
//     (a, b) => getOffset(a) - getOffset(b)
//   );

//   const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

//   const formatTimezone = (zone) => {
//     const now = DateTime.now().setZone(zone);
//     return `(GMT${now.toFormat("ZZ")}) ${zone}`;
//   };

//   const selectedValue = value || userTimezone;

//   useEffect(() => {
//     if (!value) {
//       const now = DateTime.now().setZone(userTimezone);
//       onChange(userTimezone, now.toFormat("ZZ"));
//     }
//   }, [value]);

//   return (
//     <Autocomplete
//       options={timezones}
//       value={selectedValue || null}
//       disabled={disabled}
//       onChange={(e, newValue) => {
//         if (!newValue) return;

//         const now = DateTime.now().setZone(newValue);
//         onChange(newValue, now.toFormat("ZZ"));
//       }}
//       getOptionLabel={(option) =>
//         option ? formatTimezone(option) : ""
//       }
//       renderInput={(params) => (
//         <TextField {...params} label="Select Timezone" />
//       )}
//     />
//   );
// }


// function OrganizationsTab() {
//   const classes = useStyles();
//   const [organizations, setOrganizations] = useState([]);
//   const [businessUnits, setBusinessUnits] = useState([]);
//   const [departments, setDepartments] = useState([]);
//   const [userTypes, setUserTypes] = useState([]);
//   const [designations, setDesignations] = useState([]);
//   const [open, setOpen] = useState(false);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);
  
//   const [formData, setFormData] = useState({
//     name: '',
//     shortName: '',
//     timezone:{},
//     isEnabled: true,
//   });
//   console.log(formData,"formData")
//   const [editingId, setEditingId] = useState(null);
//   const [editingLevel, setEditingLevel] = useState(0);
//   const [selectedOrganization, setSelectedOrganization] = useState(null);
//   const [selectedBusinessUnit, setSelectedBusinessUnit] = useState(null);
//   const [selectedDepartment, setSelectedDepartment] = useState(null);
//   const [selectedUserType, setSelectedUserType] = useState(null);
//   const [selectedPermissions, setSelectedPermissions] = useState({});
//   const [newDomain, setNewDomain] = useState('');
//   const [permissionGroups, setPermissionGroups] = useState([]);
//   const [permissions, setPermissions] = useState({});
//   const [originalRow, setOriginalRow] = useState(null);
//   const [expandedItems, setExpandedItems] = useState(new Set());
//   const [shiftsDialogOpen, setShiftsDialogOpen] = useState(false);

//   const levelNames = useMemo(() => ['Organization', 'Business Unit', 'Department', 'User Type', 'Designation'], []);

//   useEffect(() => {
//     fetchOrganizations();
//     fetchPermissionGroups();
//   }, []);

//   const fetchOrganizations = async () => {
//     try {
//       setLoading(true);
//       const response = await getOrganizations();
//       if (response.data?.result?.data) {
//         setOrganizations(response.data.result.data);
//       } else {
       
//         setOrganizations([]);
//       }
//     } catch (error) {
//       console.error('Error fetching organizations:', error);
//       setError(error.response?.data?.message || 'Error fetching organizations');
//     } finally {
//       setLoading(false);
//     }
//   };
// console.log(originalRow,"originalRow")
//   const fetchPermissionGroups = async () => {
//     try {
//       const response = await getAllPermissionGroups({ selectFields: "name" });
//       if (response.data?.result?.data) {
//         setPermissionGroups(response.data.result.data);
//         response.data.result.data.forEach(group => {
//           fetchPermissions(group.id);
//         });
//       }
//     } catch (error) {
//       console.error('Error fetching permission groups:', error);
//       setError(error.response?.data?.message || 'Error fetching permission groups');
//     }
//   };

//   const fetchPermissions = async (groupId) => {
//     try {
//       const response = await getAllPermissions({ 
//         permissionGroups: [groupId],
//         selectFields: "name"
//       });
//       if (response.data?.result?.data) {
//         setPermissions(prev => ({
//           ...prev,
//           [groupId]: response.data.result.data
//         }));
//       }
//     } catch (error) {
//       console.error('Error fetching permissions:', error);
//       setError(error.response?.data?.message || 'Error fetching permissions');
//     }
//   };

//   const handlePermissionChange = useCallback((groupId, permissionId, checked) => {
//     setSelectedPermissions(prev => {
//       const groupPermissions = prev[groupId] || {};
//       return {
//         ...prev,
//         [groupId]: {
//           ...groupPermissions,
//           [permissionId]: checked
//         }
//       };
//     });
//   }, []);

//   const handleOpen = useCallback(async (row = null, level = 0, parentRow = null) => {
//     if (row) {
//       setOriginalRow(row);
//       if (level === 0) {
//         setFormData({
//           name: row.name,
//           timezone:row.timezone,
//           isEnabled: row.isEnabled,
//         });
//       } else if (level === 1) {
//         setFormData({
//           name: row.name,
//           shortName: row.shortName,
//           isEnabled: row.isEnabled
//         });
//         const parentOrg = organizations.find(org => org.id === row.organization);
//         setSelectedOrganization(parentOrg);
//       } else if (level === 2) {
//         setFormData({
//           name: row.name,
//           isEnabled: row.isEnabled
//         });
        
//         // Fetch business units if not already loaded
//         let parentBU = businessUnits.find(bu => bu.id === row.businessUnit);
//         if (!parentBU) {
//           try {
//             const response = await getBusinessUnits();
//             if (response.data?.result?.data) {
//               setBusinessUnits(response.data.result.data);
//               parentBU = response.data.result.data.find(bu => bu.id === row.businessUnit);
//             }
//           } catch (error) {
//             console.error('Error fetching business units:', error);
//           }
//         }
        
//         setSelectedBusinessUnit(parentBU);
//         if (parentBU) {
//           const parentOrg = organizations.find(org => org.id === parentBU.organization);
//           setSelectedOrganization(parentOrg);
//         }
//       } else if (level === 3) {
//         setFormData({
//           name: row.name,
//           isEnabled: row.isEnabled
//         });
        
//         // Fetch departments if not already loaded
//         let parentDept = departments.find(dept => dept.id === row.department);
//         if (!parentDept) {
//           try {
//             const response = await getDepartments(row.businessUnit);
//             if (response.data?.result?.data) {
//               setDepartments(response.data.result.data);
//               parentDept = response.data.result.data.find(dept => dept.id === row.department);
//             }
//           } catch (error) {
//             console.error('Error fetching departments:', error);
//           }
//         }
        
//         setSelectedDepartment(parentDept);
//         if (parentDept) {
//           let parentBU = businessUnits.find(bu => bu.id === parentDept.businessUnit);
//           if (!parentBU) {
//             try {
//               const response = await getBusinessUnits();
//               if (response.data?.result?.data) {
//                 setBusinessUnits(response.data.result.data);
//                 parentBU = response.data.result.data.find(bu => bu.id === parentDept.businessUnit);
//               }
//             } catch (error) {
//               console.error('Error fetching business units:', error);
//             }
//           }
//           setSelectedBusinessUnit(parentBU);
//           if (parentBU) {
//             const parentOrg = organizations.find(org => org.id === parentBU.organization);
//             setSelectedOrganization(parentOrg);
//           }
//         }
//       } else if (level === 4) {
//         setFormData({
//           name: row.name,
//           isEnabled: row.isEnabled,
//           permissions: row.permissions || {}
//         });
        
//         const initialPermissions = {};
//         permissionGroups.forEach(group => {
//           initialPermissions[group.id] = {};
//         });

//         if (row.permissions) {
//           Object.entries(row.permissions).forEach(([groupName, groupPermissions]) => {
//             const group = permissionGroups.find(g => g.name.toLowerCase() === groupName.toLowerCase());
//             if (group) {
//               Object.entries(groupPermissions).forEach(([permissionName, permissionData]) => {
//                 if (permissionData && permissionData.id) {
//                   initialPermissions[group.id][permissionData.id] = true;
//                 }
//               });
//             }
//           });
//         }
        
//         setSelectedPermissions(initialPermissions);
        
//         // Fetch user types if not already loaded
//         let parentUT = userTypes.find(ut => ut.id === row.userType);
//         if (!parentUT) {
//           try {
//             const response = await getUserTypes(row.businessUnit, row.department);
//             if (response.data?.result?.data) {
//               setUserTypes(response.data.result.data);
//               parentUT = response.data.result.data.find(ut => ut.id === row.userType);
//             }
//           } catch (error) {
//             console.error('Error fetching user types:', error);
//           }
//         }
        
//         setSelectedUserType(parentUT);
        
//         if (parentUT) {
//           let parentDept = departments.find(dept => dept.id === parentUT.department);
//           if (!parentDept) {
//             try {
//               const response = await getDepartments(row.businessUnit);
//               if (response.data?.result?.data) {
//                 setDepartments(response.data.result.data);
//                 parentDept = response.data.result.data.find(dept => dept.id === parentUT.department);
//               }
//             } catch (error) {
//               console.error('Error fetching departments:', error);
//             }
//           }
//           setSelectedDepartment(parentDept);
          
//           if (parentDept) {
//             let parentBU = businessUnits.find(bu => bu.id === parentDept.businessUnit);
//             if (!parentBU) {
//               try {
//                 const response = await getBusinessUnits();
//                 if (response.data?.result?.data) {
//                   setBusinessUnits(response.data.result.data);
//                   parentBU = response.data.result.data.find(bu => bu.id === parentDept.businessUnit);
//                 }
//               } catch (error) {
//                 console.error('Error fetching business units:', error);
//               }
//             }
//             setSelectedBusinessUnit(parentBU);
            
//             if (parentBU) {
//               const parentOrg = organizations.find(org => org.id === parentBU.organization);
//               setSelectedOrganization(parentOrg);
//             }
//           }
//         }
//       }
//       setEditingId(row.id);
//       setEditingLevel(level);
//     } else {
//       setOriginalRow(null);
//       if (level === 0) {
//         setFormData({
//           name: '',
//           timezone:'',
//           isEnabled: true,
//         });
//       } else if (level === 1 && parentRow) {
//         setFormData({
//           name: '',
//           shortName: '',
//           isEnabled: true
//         });
//         setSelectedOrganization(parentRow);
//       } else if (level === 2 && parentRow) {
//         setFormData({
//           name: '',
//           isEnabled: true
//         });
//         setSelectedBusinessUnit(parentRow);
//       } else if (level === 3 && parentRow) {
//         setFormData({
//           name: '',
//           isEnabled: true
//         });
//         setSelectedDepartment(parentRow);
//       } else if (level === 4 && parentRow) {
//         setFormData({
//           name: '',
//           isEnabled: true,
//           permissions: {}
//         });
//         setSelectedUserType(parentRow);
//       }
//       setEditingId(null);
//       setEditingLevel(level);
//     }
//     setOpen(true);
//   }, [organizations, businessUnits, departments, userTypes, permissionGroups]);

//   const handleClose = useCallback(() => {
//     setOpen(false);
//     setFormData({
//       name: '',
//       shortName: '',
//       isEnabled: true,
//     });
//     setEditingId(null);
//     setEditingLevel(0);
//     setSelectedOrganization(null);
//     setSelectedBusinessUnit(null);
//     setSelectedDepartment(null);
//     setSelectedUserType(null);
//     setSelectedPermissions({});
//     setNewDomain('');
//     setOriginalRow(null);
//   }, []);

//   const handleSubmit = useCallback(async () => {
//     setLoading(true);
//     try {
//       if (editingLevel === 0) {
//         if (editingId) {
//           await updateOrganization(editingId, formData);
//         } else {
//           await createOrganization(formData);
//         }
//       } else if (editingLevel === 1) {
//         if (!selectedOrganization) {
//           throw new Error('Organization is required for business unit operations');
//         }
//         const businessUnitData = {
//           name: formData.name,
//           shortName: formData.shortName,
//           isEnabled: formData.isEnabled,
//           organization: selectedOrganization.id
//         };
        
//         if (editingId) {
//           await updateBusinessUnit(editingId, businessUnitData);
//         } else {
//           await createBusinessUnit(selectedOrganization.id, businessUnitData);
//         }
//       } else if (editingLevel === 2) {
//         if (!selectedBusinessUnit) {
//           throw new Error('Business Unit is required for department operations');
//         }
//         const departmentData = {
//           name: formData.name,
//           isEnabled: formData.isEnabled,
//           businessUnit: selectedBusinessUnit.id
//         };
        
//         if (editingId) {
//           await updateDepartment(editingId, departmentData, selectedBusinessUnit.id);
//         } else {
//           await createDepartment(selectedBusinessUnit.id, departmentData);
//         }
//       } else if (editingLevel === 3) {
//         const userTypeData = {
//           name: formData.name,
//           isEnabled: formData.isEnabled
//         };
        
//         if (editingId) {
//           await updateUserType(editingId, userTypeData);
//         } else {
//           await createUserType(selectedDepartment.businessUnit, selectedDepartment.id, userTypeData);
//         }
//       } else if (editingLevel === 4) {
//         const designationData = {
//           isEnabled: formData.isEnabled
//         };

//         if (editingId) {
//           const originalName = originalRow?.name;
//           if (originalName !== formData.name) {
//             designationData.name = formData.name;
//           }
//         } else {
//           designationData.name = formData.name;
//         }
        
//         const selectedPermissionIds = Object.values(selectedPermissions)
//           .flatMap(groupPermissions => 
//             Object.entries(groupPermissions)
//               .filter(([_, selected]) => selected)
//               .map(([permissionId]) => permissionId)
//           );
        
//         if (selectedPermissionIds.length > 0) {
//           designationData.permissions = selectedPermissionIds;
//         }
        
//         if (editingId) {
//           await updateDesignation(editingId, designationData);
//         } else {
//           await createDesignation(selectedUserType.businessUnit, selectedUserType.id, designationData);
//         }
//       }
      
//       handleClose();
//       await fetchOrganizations();
//       toast.success('Saved successfully');
//     } catch (error) {
//       console.error('Error saving:', error);
//       setError(error.response?.data?.message || 'Error saving data');
//       toast.error(error.response?.data?.message || 'Error saving data');
//     } finally {
//       setLoading(false);
//     }
//   }, [editingLevel, editingId, formData, selectedOrganization, selectedBusinessUnit, selectedDepartment, selectedUserType, selectedPermissions, originalRow, handleClose]);

//   const handleCloseError = useCallback(() => {
//     setError(null);
//   }, []);

//   const handleExpand = useCallback((row, level) => {
//     const itemKey = `${level}-${row.id}`;
//     setExpandedItems(prev => {
//       const newExpandedItems = new Set(prev);
      
//       if (prev.has(itemKey)) {
//         const keysToRemove = Array.from(prev).filter(key => {
//           const [keyLevel] = key.split('-');
//           return parseInt(keyLevel) > level;
//         });
//         keysToRemove.forEach(key => newExpandedItems.delete(key));
//         newExpandedItems.delete(itemKey);
//       } else {
//         newExpandedItems.add(itemKey);
//       }
      
//       return newExpandedItems;
//     });
//   }, []);

//   const isExpanded = useCallback((row, level) => {
//     return expandedItems.has(`${level}-${row.id}`);
//   }, [expandedItems]);

//   const handleShiftsClick = useCallback((businessUnit) => {
//     setSelectedBusinessUnit(businessUnit);
//     setShiftsDialogOpen(true);
//   }, []);

//   const handleShiftsDialogClose = useCallback(() => {
//     setShiftsDialogOpen(false);
//     setSelectedBusinessUnit(null);
//   }, []);

//   if (loading && organizations.length === 0) {
//     return (
//       <div className={classes.loadingContainer}>
//         <CircularProgress />
//       </div>
//     );
//   }

//   return (
//     <div className={classes.root}>
//       <div className={classes.header}>
//         <div className={classes.title}>
//           <BusinessIcon color="primary" />
//           <Typography variant="h5">Organizations</Typography>
//         </div>
//         <Button
//           variant="contained"
//           color="primary"
//           startIcon={<AddIcon />}
//           onClick={() => handleOpen(null, 0)}
//           className={classes.addButton}
//         >
//           Add Organization
//         </Button>
//       </div>

//       <Breadcrumbs className={classes.breadcrumbs}>
//         <Link color="inherit" href="#">
//           Admin
//         </Link>
//         <Typography color="textPrimary">Organizations</Typography>
//       </Breadcrumbs>

//       {error && (
//         <Alert severity="error" className={classes.errorAlert} onClose={handleCloseError}>
//           {error}
//         </Alert>
//       )}

//       {loading ? (
//         <div className={classes.loadingContainer}>
//           <CircularProgress />
//         </div>
//       ) : (
//         <TableContainer component={Paper} className={classes.table}>
//           <Table>
//             <TableHead className={classes.tableHead}>
//               <TableRow>
//                 <TableCell>Name</TableCell>
//                 <TableCell>Status</TableCell>
//                 <TableCell>Actions</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {organizations.map((org) => {
//                 const orgKey = `0-${org.id}`;
//                 const orgExpanded = expandedItems.has(orgKey);
//                 return (
//                   <Row
//                     key={org.id}
//                     row={org}
//                     level={0}
//                     onEdit={handleOpen}
//                     handleShiftsClick={handleShiftsClick}
//                     isExpanded={orgExpanded}
//                     onExpand={handleExpand}
//                     expandedItems={expandedItems}
//                   />
//                 );
//               })}
//             </TableBody>
//           </Table>
//         </TableContainer>
//       )}

//       <Dialog
//         open={open}
//         onClose={handleClose}
//         maxWidth="sm"
//         fullWidth
//         TransitionComponent={Zoom}
//       >
//         <DialogTitle className={classes.dialogTitle}>
//           {editingId ? `Edit ${levelNames[editingLevel]}` : `Add ${levelNames[editingLevel]}`}
//         </DialogTitle>
//         <DialogContent className={classes.dialogContent}>
//           <TextField
//             autoFocus
//             margin="dense"
//             label="Name"
//             type="text"
//             fullWidth
//             value={formData.name}
//             onChange={(e) => setFormData({ ...formData, name: e.target.value })}
//           />
//           {editingLevel === 0 && (
            
//           //  <TimezoneDropdown
//           //   value={formData.timezone}
//           //   onChange={(tz) =>
//           //     setFormData({ ...formData, timezone: tz })
//           //   }
//           // />
//           // <TimezoneDropdown
//           //   value={formData.timezone?.zone}
//           //   onChange={(tz) => {
//           //     if (!tz) return; // prevent null issue

//           //     const now = DateTime.now().setZone(tz);

//           //     setFormData({
//           //       ...formData,
//           //       timezone: {
//           //         zone: tz,
//           //         offset: now.toFormat("ZZ"),
//           //       },
//           //     });
//           //   }}
//           // />

//           <TimezoneDropdown
//             value={formData.timezone?.zone}
//             onChange={(zone, offset) => {
//               setFormData((prev) => ({
//                 ...prev,
//                 timezone: {
//                   zone,
//                   offset,
//                 },
//               }));
//             }}
//             disabled={originalRow?.timezone?.zone} 
//           />
//           )}
//           {editingLevel === 1 && (
//             <TextField
//               margin="dense"
//               label="Short Name"
//               type="text"
//               fullWidth
//               value={formData.shortName}
//               onChange={(e) => setFormData({ ...formData, shortName: e.target.value })}
//             />
//           )}
//           {editingLevel === 4 && (
//             <Box mt={2}>
//               <Typography variant="h6">Permissions</Typography>
//               {permissionGroups.map(group => (
//                 <Box key={group.id} mt={2}>
//                   <Typography variant="subtitle1">{group.name}</Typography>
//                   <FormGroup>
//                     {permissions[group.id]?.map(permission => (
//                       <FormControlLabel
//                         key={permission.id}
//                         control={
//                           <Checkbox
//                             checked={selectedPermissions[group.id]?.[permission.id] || false}
//                             onChange={(e) => handlePermissionChange(group.id, permission.id, e.target.checked)}
//                           />
//                         }
//                         label={permission.name}
//                       />
//                     ))}
//                   </FormGroup>
//                 </Box>
//               ))}
//             </Box>
//           )}
//           <FormControlLabel
//             control={
//               <Switch
//                 checked={formData.isEnabled}
//                 onChange={(e) => setFormData({ ...formData, isEnabled: e.target.checked })}
//                 color="primary"
//               />
//             }
//             label="Enabled"
//             style={{ marginTop: '16px' }}
//           />
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleClose} color="primary">
//             Cancel
//           </Button>
//           <Button onClick={handleSubmit} color="primary" disabled={loading}>
//             {loading ? <CircularProgress size={24} /> : 'Save'}
//           </Button>
//         </DialogActions>
//       </Dialog>

//       <Dialog 
//         open={shiftsDialogOpen} 
//         onClose={handleShiftsDialogClose}
//         maxWidth="md"
//         fullWidth
//       >
//         <DialogTitle>
//           Manage Shifts - {selectedBusinessUnit?.name}
//         </DialogTitle>
//         <DialogContent>
//           {selectedBusinessUnit && (
//             <ShiftsTab businessUnitId={selectedBusinessUnit.id} />
//           )}
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleShiftsDialogClose} color="primary">
//             Close
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </div>
//   );
// }

// export default OrganizationsTab;