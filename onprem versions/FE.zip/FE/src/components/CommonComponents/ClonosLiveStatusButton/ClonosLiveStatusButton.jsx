import React from "react";
import { Tooltip } from "@mui/material";

const ClonosLiveStatusButton = ({ status, type = "gradient" }) => {
  const isOnline = status === "online" || status === true;

  // 1️⃣ Gradient style
  if (type === "gradient") {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          padding: "6px 14px",
          borderRadius: "25px",
          background: isOnline
            ? "linear-gradient(90deg, #4ade80, #16a34a)"
            : "linear-gradient(90deg, #f87171, #dc2626)",
          color: "#fff",
          fontWeight: 600,
          fontSize: "14px",
          boxShadow: "0 2px 10px rgba(0,0,0,0.15)",
          transition: "all 0.3s ease",
        }}
      >
        <span
          style={{
            width: "10px",
            height: "10px",
            borderRadius: "50%",
            backgroundColor: "#fff",
          }}
        ></span>
        {isOnline ? "LIVE NOW" : "OFFLINE"}
      </div>
    );
  }

  // 2️⃣ Glass style
  if (type === "glass") {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          padding: "6px 14px",
          borderRadius: "25px",
          background: "rgba(255, 255, 255, 0.2)",
          backdropFilter: "blur(10px)",
          color: isOnline ? "#22c55e" : "#ef4444",
          border: `1px solid ${isOnline ? "#22c55e66" : "#ef444466"}`,
          fontWeight: 600,
          fontSize: "14px",
        }}
      >
        <span
          style={{
            width: "10px",
            height: "10px",
            borderRadius: "50%",
            backgroundColor: isOnline ? "#22c55e" : "#ef4444",
            boxShadow: `0 0 6px ${isOnline ? "#22c55e" : "#ef4444"}`,
          }}
        ></span>
        {isOnline ? "Live" : "Offline"}
      </div>
    );
  }

  // 3️⃣ Minimal dot style
  if (type === "minimal") {
    return (
      <Tooltip title={isOnline ? "Active" : "Inactive"} arrow>
        <div
          style={{
            width: "12px",
            height: "12px",
            borderRadius: "50%",
            backgroundColor: isOnline ? "#22c55e" : "#ef4444",
            boxShadow: `0 0 8px ${isOnline ? "#22c55e88" : "#ef444488"}`,
            cursor: "pointer",
          }}
        ></div>
      </Tooltip>
    );
  }

  // 4️⃣ Animated style
  if (type === "animated") {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "6px",
          backgroundColor: isOnline ? "#dc2626" : "#6b7280",
          color: "white",
          padding: "4px 10px",
          borderRadius: "6px",
          fontWeight: 600,
          textTransform: "uppercase",
          letterSpacing: "0.5px",
          animation: isOnline ? "pulse 1s infinite" : "none",
        }}
      >
        <div
          style={{
            width: "8px",
            height: "8px",
            borderRadius: "50%",
            backgroundColor: "white",
          }}
        ></div>
        {isOnline ? "Live" : "Offline"}

        <style>
          {`
          @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(220,38,38,0.7); }
            70% { box-shadow: 0 0 0 8px rgba(220,38,38,0); }
            100% { box-shadow: 0 0 0 0 rgba(220,38,38,0); }
          }`}
        </style>
      </div>
    );
  }

  return null;
};

export default ClonosLiveStatusButton;
