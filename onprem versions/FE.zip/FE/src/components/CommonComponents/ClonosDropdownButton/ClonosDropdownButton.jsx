import { useEffect, useRef, useState } from "react";
import {IconButton } from "@mui/material"
import Styles from "./ClonosDropdownButton.module.css";
import { ActiveRight } from "../../../assets/svg/RightIcon";
export const ClonosDropdownButton = ({dropdownItems,w,bg,p,color,PreIcon,PostIcon,buttonTitle,border,iconStroke}) => {
    const [showPopup,setShowPopup] = useState(false);
    const addFromLibraryRef = useRef()
    useEffect(() => {
        const handleOutsideClick = (event) => {
          if (addFromLibraryRef.current && !addFromLibraryRef.current.contains(event.target)) {
            setShowPopup(false);
          }
        };
    
        if (showPopup) {
          document.addEventListener('mousedown', handleOutsideClick);
        } else {
          document.removeEventListener('mousedown', handleOutsideClick);
        }
    
        return () => {
          document.removeEventListener('mousedown', handleOutsideClick);
        };
      }, [showPopup]);

 
    return (
        <div style={{background:bg ? bg : "#FFF",color:color ? color : "#000",padding:p ? p : "0.5rem",width:w ? w : "250px",border: border ? border : "1px solid black"}}  className={Styles.container}>
            <div onClick={() => setShowPopup((prev) => !prev)} className={Styles.c_d_b_1}>
                {PreIcon ? <PreIcon color={iconStroke ? iconStroke : "black"}/> : <></>}
                <p>{buttonTitle || "Click Me"}</p>
                {PostIcon ? <PostIcon/> : <IconButton style={{rotate:"90deg"}}><ActiveRight color={iconStroke ? iconStroke :"black"}/></IconButton>}
            </div>
            {
                showPopup ? <div ref={addFromLibraryRef} className={Styles.c_d_b_2}>
                {
                    dropdownItems?.length && dropdownItems?.map((item,i) => {
                        return <div onClick={item?.onClickMethod} id={i+1} className={Styles.c_d_b_item}>{item?.title}</div>
                    })
                }
            </div>   : <></>
            }                
        </div>
    )
}