import React, { useEffect } from 'react'
import { DataGrid, GridToolbar } from '@mui/x-data-grid'
import { useState } from 'react'
import MultiSelectionController from '../MultiSelectionController/MultiSelectionController'
import { commonPageState, generateSkeletonColumns, generateUniqueId } from '../../../utils/clonosCommon'

/**
 * A reusable component for rendering a DataGrid with loading state control.
 *
 * @param {object[]} rows - An array of data rows to display in the DataGrid.
 * @param {object[]} columns - An array of columns configuration for the DataGrid.
 * @param {function} handleGetSelectedRowsMethod - A callback function to handle selected rows that will return an object with one key: "selectedRows". 
 * @param {number} pageLimit - The number of rows per page in the DataGrid.
 * @param {boolean} isEditMethod - Flag indicating if editing functionality is enabled.
 * @param {boolean} isDeleteMethod - Flag indicating if deleting functionality is enabled.
 * @param {boolean} isCreateMethod - Flag indicating if creating functionality is enabled.
 * @param {string} uniqueIdField - The unique identifier field for the rows.
 * @param {boolean} checkboxSelection - Flag indicating if checkbox selection is enabled.
 * @param {function} onPageChange - Callback function for handling page change events.
 * @param {boolean} loading - Flag indicating if the DataGrid is in a loading state.
 * @param {function} handleFilterModelChange - Return updated filter details.
 * @param {boolean} toolbar - Allow to show and hide the toolbar at the top of the grid, for easy access of filters.
 * @param {number} totalCount - Total count of rows.
 */

const ClonosDataGrid = React.memo((
    {
        rows = [],
        columns,
        toolbar,
        handleFilterModelChange,
        handleGetSelectedRowsMethod,
        isEditMethod,
        isDeleteMethod,
        isCreateMethod,
        isApproveMethod,
        uniqueIdField = "_id",
        checkboxSelection = true,
        onPageChange,
        loading,
        totalCount,
        hideFooter,
        height,
        autoPageSize,
        paginationMode,
        noRowsOverlayMessage,
        filterMode,
        pageLimit
    }
) => {
    const [selectedRows, setSelectedRows] = useState([]);

    const [lcRows, setLcRows] = useState(rows) // lc : local
 
    const [lcColumns, setLcColumns] = useState([]) // lc : local

    useEffect(() => {
        if (loading) {
            const rows = Array(commonPageState.limit).fill(0)?.map((item) => {
                return { [uniqueIdField]: generateUniqueId(5) }
            });
            setLcColumns(generateSkeletonColumns(columns));
            setLcRows(rows);
        } else {
            setLcRows(rows);
            setLcColumns(columns);
        }
    }, [loading, rows, columns]);

    return (
        <div style={{ height: "100%", display: 'flex', flexDirection: 'column', display: 'contents', padding: "1rem" }}>
            <MultiSelectionController
                isActiveComponent={selectedRows.length > 0 && true}
                isEditMethod={selectedRows.length === 1 ? isEditMethod : false}
                isDeleteMethod={isDeleteMethod}
                isCreateMethod={isCreateMethod}
                isApproveMethod={isApproveMethod}
                selectedRowCount={selectedRows?.length}
            />
            <DataGrid
                onPaginationModelChange={onPageChange}
                rows={lcRows || []}
                columns={lcColumns || []}
                getRowId={(row) => row[uniqueIdField]}
                initialState={{
                    pagination: {
                        paginationModel: {
                            pageSize: pageLimit? pageLimit : commonPageState.limit,
                        },
                    },
                }}
                sx={{ overflowX: 'scroll'}}
                height={height || 400}
                paginationMode={paginationMode || 'server'}
                onRowSelectionModelChange={(selectedRow) => {
                    setSelectedRows(selectedRow)
                    handleGetSelectedRowsMethod({ selectedRows: [...selectedRow] })
                }}
                rowCount={totalCount}
                pageSizeOptions={[commonPageState.limit, commonPageState.limit * 2, commonPageState.limit * 3]}
                checkboxSelection={checkboxSelection}
                disableRowSelectionOnClick
                loading={false}
                hideFooter={hideFooter}
                filterMode={filterMode || "server"}
                autoPageSize={autoPageSize}
                onFilterModelChange={handleFilterModelChange}
                slots={toolbar && { toolbar: GridToolbar }}
            // components={{
            //     NoRowsOverlay: CustomNoRowsOverlay,
            // }}
            // componentsProps={{
            //     noRowsOverlay: { noRowsOverlayMessage },
            // }}
            />
        </div>
    )
})

export default ClonosDataGrid


const CustomNoRowsOverlay = ({ noRowsOverlayMessage }) => {
    return (
        <div style={{ width: "100%", height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
            <p>
                {noRowsOverlayMessage ? noRowsOverlayMessage : "No Rows"}
            </p>
        </div>
    );
};



// import React, { useEffect } from 'react'
// import { DataGrid, GridToolbar } from '@mui/x-data-grid'
// import { useState } from 'react'
// import MultiSelectionController from '../MultiSelectionController/MultiSelectionController'
// import { commonPageState, generateSkeletonColumns, generateUniqueId } from '../../../utils/clonosCommon'

// /**
//  * A reusable component for rendering a DataGrid with loading state control.
//  *
//  * @param {object[]} rows - An array of data rows to display in the DataGrid.
//  * @param {object[]} columns - An array of columns configuration for the DataGrid.
//  * @param {function} handleGetSelectedRowsMethod - A callback function to handle selected rows that will return an object with one key: "selectedRows". 
//  * @param {number} pageLimit - The number of rows per page in the DataGrid.
//  * @param {boolean} isEditMethod - Flag indicating if editing functionality is enabled.
//  * @param {boolean} isDeleteMethod - Flag indicating if deleting functionality is enabled.
//  * @param {boolean} isCreateMethod - Flag indicating if creating functionality is enabled.
//  * @param {string} uniqueIdField - The unique identifier field for the rows.
//  * @param {boolean} checkboxSelection - Flag indicating if checkbox selection is enabled.
//  * @param {function} onPageChange - Callback function for handling page change events.
//  * @param {boolean} loading - Flag indicating if the DataGrid is in a loading state.
//  * @param {function} handleFilterModelChange - Return updated filter details.
//  * @param {boolean} toolbar - Allow to show and hide the toolbar at the top of the grid, for easy access of filters.
//  * @param {number} totalCount - Total count of rows.
//  */

// const ClonosDataGrid = React.memo((
//     {
//         rows = [],
//         columns,
//         toolbar,
//         handleFilterModelChange,
//         handleGetSelectedRowsMethod,
//         isEditMethod,
//         isDeleteMethod,
//         isCreateMethod,
//         isApproveMethod,
//         uniqueIdField = "_id",
//         checkboxSelection = true,
//         onPageChange,
//         loading,
//         totalCount,
//         hideFooter,
//         height,
//         autoPageSize,
//         paginationMode,
//         noRowsOverlayMessage,
//         filterMode,
//         filterModel,
//         pageLimit
//     }
// ) => {
//     const [selectedRows, setSelectedRows] = useState([]);
//     console.log('selectedRows:', selectedRows)
//     const [lcRows, setLcRows] = useState(rows) // lc : local
//     console.log('lcRows:', lcRows)
//     const [lcColumns, setLcColumns] = useState([]) // lc : local
//     console.log('lcColumns:', lcColumns)
//     useEffect(() => {
//         if (loading) {
//             const rows = Array(commonPageState.limit).fill(0)?.map((item) => {
//                 return { [uniqueIdField]: generateUniqueId(5) }
//             });
//             setLcColumns(generateSkeletonColumns(columns));
//             setLcRows(rows);
//         } else {
//             setLcRows(rows);
//             setLcColumns(columns);
//         }
//     }, [loading, rows, columns]);

//     return (
//         <div style={{ height: "100%", display: 'flex', flexDirection: 'column', display: 'contents', padding: "1rem" }}>
//             <MultiSelectionController
//                 isActiveComponent={selectedRows.length > 0 && true}
//                 isEditMethod={selectedRows.length === 1 ? isEditMethod : false}
//                 isDeleteMethod={isDeleteMethod}
//                 isCreateMethod={isCreateMethod}
//                 isApproveMethod={isApproveMethod}
//                 selectedRowCount={selectedRows?.length}
//             />
//            <DataGrid
//     onPaginationModelChange={onPageChange}
//     rows={lcRows || []}
//     columns={lcColumns || []}
//     getRowId={(row) => row[uniqueIdField]}
//     initialState={{
//         pagination: {
//             paginationModel: {
//                 pageSize: pageLimit || commonPageState.limit,
//             },
//         },
//     }}
//     sx={{ overflowX: 'scroll' }}
//     paginationMode={paginationMode || 'server'}
//     onRowSelectionModelChange={(selectedRow) => {
//         setSelectedRows(selectedRow)
//         handleGetSelectedRowsMethod({ selectedRows: [...selectedRow] })
//     }}
//     rowCount={totalCount}
//     pageSizeOptions={[
//         commonPageState.limit,
//         commonPageState.limit * 2,
//         commonPageState.limit * 3
//     ]}
//     checkboxSelection={checkboxSelection}
//     disableRowSelectionOnClick

//     loading={loading}   

//     hideFooter={hideFooter}
//     filterMode={filterMode || "server"}
//     autoPageSize={autoPageSize}

//     onFilterModelChange={(model) => {
//         handleFilterModelChange && handleFilterModelChange(model)
//     }}
// filterModel={filterModel}
//     slots={toolbar ? { toolbar: GridToolbar } : undefined}
// />
//         </div>
//     )
// })

// export default ClonosDataGrid


// const CustomNoRowsOverlay = ({ noRowsOverlayMessage }) => {
//     return (
//         <div style={{ width: "100%", height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
//             <p>
//                 {noRowsOverlayMessage ? noRowsOverlayMessage : "No Rows"}
//             </p>
//         </div>
//     );
// };
