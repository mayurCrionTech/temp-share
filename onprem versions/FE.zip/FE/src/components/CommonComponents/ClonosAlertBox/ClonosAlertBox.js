import React from "react";
import COMMON_WARNING_ICON from "../../../assets/UIUX/icons/Common_Icon/COMMON_WARNING_ICON.svg";
import Modal from "../Modal/Modal";
import Styles from "./ClonosAlertBox.module.css";
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";

const ClonosAlertBox = ({ isOpen, closeModalMethod, headerTitle = "Alert", message }) => {
  return (
    <Modal isOpen={isOpen} closeModalMethod={closeModalMethod}>
      <div className={Styles.main_container}>
        <header>
          <span></span>
          <div className={Styles.header_title}>
            <img src={COMMON_WARNING_ICON} alt="alert-icon" />
            <span>{headerTitle}</span>
          </div>
          <CloseIcon onClick={closeModalMethod} />
        </header>
        <section className={Styles.body}>
          <p>{message}</p>
        </section>
      </div>
    </Modal>
  );
};

export default ClonosAlertBox;
