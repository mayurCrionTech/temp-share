import React from 'react'
import Styles from "./ClonosLoader.module.css"

const ClonosLineLoader = () => {
    return (
        <div className={Styles.line_loading}></div>
    )
}

export default ClonosLineLoader