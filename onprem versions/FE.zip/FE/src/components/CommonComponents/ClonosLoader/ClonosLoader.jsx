import ClonosSpinner from '../ClonosSpinner/ClonosSpinner';
import Styles from './ClonosLoader.module.css';

const ClonosLoader = () => <div className={Styles.clonos_loader}>
    <ClonosSpinner />
</div>

export default ClonosLoader;