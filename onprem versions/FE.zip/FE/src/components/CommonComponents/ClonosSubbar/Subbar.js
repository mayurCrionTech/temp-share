import React, { useEffect } from 'react'
import Styles from "./Subbar.module.css"
import { generateUniqueId, getFormatedDate, handleLoggedInUser, handleMakeCamelCase } from '../../../utils/clonosCommon'
import DownloadIcon from '../../../assets/Clonos Common Indicators/Icon_Components/DownloadIcon'
import DeleteIcon from '../../../assets/Clonos Common Indicators/Icon_Components/DeleteIcon'
import EditIcon from '../../../assets/Clonos Common Indicators/Icon_Components/EditIcon'
import CopyIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CopyIcon'
import { statusStaticData, statusStyleStaticData } from '../../../Constants/StaticData'
import { ClonosButton } from '../Button/Button'
import CommentIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CommentICon'



const Subbar = (
    {
        isDeleteMethod,
        isRemarksMethod,
        isDownloadMethod,
        isEditMethod,
        isCreatedOn,
        isCopyMethod,
        isExpiredOn,
        isStatus,
        isPriority,
        subbarData,
        staticElements,
        buttons,
        htmlElements
    }
) => {

    let buttonVariant = {
        hollow: { border: "1px solid #000", color: "black", background: "white" },
        solid: { backgroundColor: "#06337E", color: "white" }
    }

    useEffect(() => {
        let temp = handleMakeCamelCase({ string: subbarData?.status })
    }, [])

    return (
        <div className={Styles.subbar_container}>
            <section className={Styles.status_bar_container}>
                {
                    isStatus && <div className={Styles.subbar_status}>
                        <span>Status:</span>
                        {/* <span style={statusStyle[handleMakeCamelCase({ string: subbarData?.status || subbarData?.assetStatus })] || statusStyle[subbarData?.status]}>{subbarData?.status || subbarData?.assetStatus ? statusStaticData[subbarData?.status] ? status[subbarData?.status] : subbarData?.status || subbarData?.assetStatus : "Not Mentioned"}</span> */}
                        <span
                            style={{ ...statusStyleStaticData[subbarData?.status], padding: "0.25rem 0.5rem", borderRadius: "0.25rem", cursor: "default" }}>
                            {statusStaticData[subbarData?.status]}
                        </span>
                    </div>
                }
                {
                    isCreatedOn && <div className={Styles.subbar_createdOn}>
                        <span>Created On:</span>
                        <span>{subbarData?.createdAt?.split("T")[0]?.split("-")?.reverse()?.join("/")}</span>
                    </div>
                }
                {
                    isExpiredOn && subbarData?.endAt && <div className={Styles.subbar_expiredOn}>
                        <span>Expired On:</span>
                        <span>{subbarData?.endAt?.split("T")[0]?.split("-")?.reverse()?.join("/")}</span>
                    </div>
                }
                {
                    isPriority && <div className={Styles.subbar_priority}>
                        <span>Priority:</span>
                        <span style={{ backgroundColor: subbarData?.priority === "High-P1" ? "#D24B5A" : subbarData?.priority === "Medium-P2" ? "#E5B82F" : subbarData?.priority === "Low-P3" ? "#60D468" : "gray" }} >{subbarData?.priority ? subbarData?.priority : "Not Mentioned"}</span>
                    </div>
                }
                {
                    subbarData?.decommissionedDate && <div className={Styles.subbar_decommissionedDate}>
                        <span>Decommissioned Date:</span>
                        <span>{subbarData?.decommissionedDate.split("T")[0]?.split("-")?.reverse()?.join("/")}</span>
                    </div>
                }
                {
                    staticElements?.length > 0 && staticElements.map((ele, index) => {
                        return <div key={index} className={Styles.subbar_decommissionedDate}>
                            <span style={ele.keyStyle}>{ele.key}</span>
                            <span style={ele.valueStyle}>{ele.value}</span>
                        </div>
                    })
                }

            </section>
            <section className={Styles.subbar_controllers}>
                {
                    htmlElements?.map((element, index) => {
                        return element
                    })
                }
                {
                    isRemarksMethod && <CommentIcon onClick={() => isRemarksMethod()} tooltipTitle={"Remarks"} />
                }
                {
                    isEditMethod && <EditIcon onClick={() => isEditMethod()} tooltipTitle={"Edit"} />
                }
                {
                    isDeleteMethod && <DeleteIcon onClick={() => isDeleteMethod()} tooltipTitle={"Delete"} />
                }
                {
                    isDownloadMethod && <DownloadIcon onClick={() => isDownloadMethod()} tooltipTitle={"Download"} />
                }
                {
                    isCopyMethod && <CopyIcon onClick={() => isCopyMethod()} tooltipTitle={"Copy"} />
                }
                {
                    buttons?.length > 0 && <div>
                        {
                            buttons?.length > 0 && buttons.map((item, index) => {
                                if (item.type === "select") {
                                    return item.isActive ? <select className={Styles.subbar_select} onChange={item.buttonMethod} placeholder={item.buttonText} disabled={item.isDisabled}>
                                        <option style={{ visibility: "hidden" }}>{item.buttonText}</option>
                                        {
                                            item.options.map((option) => option.isNeeded && <option option key={generateUniqueId(5)} value={option.value} disabled={option.isDisabled}> {option.label}</option>)
                                        }
                                        <option style={{ visibility: "hidden" }}>{item.buttonText}</option>
                                    </select> : <></>
                                } else {
                                    return item.isActive ? <ClonosButton key={index + 10} onClick={() => item.buttonMethod()} style={item.isHollow ? buttonVariant.hollow : buttonVariant.solid}>{item.buttonText}</ClonosButton> : <></>
                                }
                            })
                        }
                    </div>
                }

            </section >
        </div >
    )
}

export default Subbar