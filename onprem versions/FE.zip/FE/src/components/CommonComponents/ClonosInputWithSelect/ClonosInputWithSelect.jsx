import { useEffect, useState } from "react"
import ClonosInput from "../ClonosInput/ClonosInput"
import ClonosSelect from "../ClonosSelect/ClonosSelect"
import Styles from "./ClonosInputWithSelect.module.css"
import useFieldsChecker from "../../../CustomHooks/FieldsValidatorHook"
export const ClonosInputWithSelect = ({ label, isLabel, type, isMandatory, uniqueKey, dropdownOptions, defaultValue, inputProps, selectProps, handleGetValues, field }) => {
    const [lcDefaultValues, setLcDefaultValues] = useState({});
    const { isClear, primaryObject, handleGetErrorActivatorInformation, handlePrimaryObjectModifier, handleSubmit, handleRemoveField, activeHookInstances, } = useFieldsChecker({ isIndexKey: false, hookUniqueKey: field })
    const [lcValue, setLcValue] = useState({
        isValueSelected: false,
        countValue: null,
        dropdownValue: null
    });
    const handleChangedValues = (val) => {
        const { updatedValue } = val;
        const uniqueKeyField = val?.uniqueKey;
        handlePrimaryObjectModifier({ uniqueKey, response: updatedValue });
        setLcValue((prev) => {
            let temp = { ...prev, [uniqueKeyField]: updatedValue, isValueSelected: true };
            handleGetValues({ type, uniqueKey, updatedValue: { countValue: temp?.countValue, dropdownValue: temp?.dropdownValue } })
            return temp
        });
    }

    useEffect(() => {
     
    }, [primaryObject])


    return (
        <div className={Styles.i_w_s_container}>
            {isLabel ? <label className={Styles.i_w_s_label}>{label} {isMandatory && <sup className={Styles.i_w_s_mandatory}>*</sup>}</label> : <></>}
            <div className={Styles.i_w_s_flex_wrapper}>
                <div style={{ width: inputProps?.width ? inputProps?.width : "100px" }}>
                    <ClonosInput
                        isMandatory={true}
                        uniqueKey={"countValue"}
                        type={inputProps?.type}
                        placeholder={inputProps?.placeholder}
                        handleGetValues={handleChangedValues}
                        defaultValue={defaultValue?.countValue}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                    />
                </div>
                <div style={{ width: selectProps?.width ? selectProps?.width : "150px" }}>
                    <ClonosSelect
                        type={"select"}
                        isMandatory={true}
                        uniqueKey={"dropdownValue"}
                        handleGetValues={handleChangedValues}
                        defaultValue={defaultValue?.dropdownValue?.name}
                        placeholder={selectProps?.placeholder || "select"}
                        handleGetErrorActivatorInformation={handleGetErrorActivatorInformation}
                        options={selectProps?.data?.length ? selectProps?.data?.map((option) => ({ label: option?.name, value: option?.id, isNeeded: true })) : []}
                    />
                </div>
            </div>
        </div>
    )
}
