import React from 'react'
import COMMON_WARNING_ICON from "../../../assets/UIUX/icons/Common_Icon/COMMON_WARNING_ICON.svg"
import Modal from '../Modal/Modal'
import { ClonosButton } from '../Button/Button';
import Styles from "./ClonosNextConfirmationBox.module.css"
import CloseIcon from '../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon';


const ClonosNextConfirmationBox = ({ isOpen, closeModalMethod, confirmingMethod, rejectingMethod, type, message, headerTitle, loading }) => {

   
    return (
        <Modal isOpen={isOpen}  >
            <div className={Styles.main_container}>
                <header>
                    <span></span>
                    <div className={Styles.header_title}><img src={COMMON_WARNING_ICON} /><span>{headerTitle}</span></div>
                    
                </header>
                <section className={Styles.body}>
                    <p>{message}</p>
                </section>
                <footer>
                    <ClonosButton loading={loading} variant="filled" onClick={confirmingMethod}>Next</ClonosButton>
                </footer>
            </div>
        </Modal>
    )
}

export default ClonosNextConfirmationBox