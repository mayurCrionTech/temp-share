// import React, { useState, useEffect, useRef, useCallback } from "react";
// import {
//   Autocomplete,
//   TextField,
//   Box,
//   Typography,
//   CircularProgress,
// } from "@mui/material";
// import styles from "./ClonosSearchableDropdown.module.css";
// import {
//   CLONOS_GLOBAL_COLOUR_RED,
//   CLONOS_GLOBAL_ERROR_HANDLING_SIZE,
// } from "../../../Constants/Constant";
// import { ErrorSVGCom } from "../../../assets/svg/ErrorHandling";
// import { Placeholder } from "rsuite";

// const ClonosSearchableDropdown = ({
//   label = "Search",
//   data = [],
//   tabIndex,
//   onSearch,
//   onLoadMore,
//   hasMore = false,
//   loading = false,
//   debounceDelay = 500,
//   isLabel = true,
//   isMandatory = false,
//   uniqueKey = "",
//   errorMessage = "",
//   isIndexKey = false,
//   indexUniqueKey = "",
//   placeholder,
//   handleGetValues,
//   handleGetErrorActivatorInformation,
//   defaultValue,
//   allowCustomInput=false
// }) => {
//   const [inputValue, setInputValue] = useState("");
//   const [selectedValue, setSelectedValue] = useState(null);
//   const [localError, setLocalError] = useState("");
//   const [open, setOpen] = useState(false);
// const [mouseOverList, setMouseOverList] = useState(false); // optional: avoid auto-closing when moving mouse

//   const listRef = useRef(null);
//   const debounceTimer = useRef(null);

//   // ✅ store latest search handler
//   const latestSearchRef = useRef(onSearch);
//   useEffect(() => {
//     latestSearchRef.current = onSearch;
//   }, [onSearch]);

//   // ✅ debounce search
//   const triggerSearch = useCallback(
//     (query) => {
//       clearTimeout(debounceTimer.current);
//       debounceTimer.current = setTimeout(() => {
//         if (query.trim().length >= 1 && latestSearchRef.current) {
//           latestSearchRef.current(query);
//         } else if (query.trim().length === 0 && latestSearchRef.current) {
//           latestSearchRef.current(null);
//         }
//       }, debounceDelay);
//     },
//     [debounceDelay]
//   );

//   console.log(data,"assetdatainside")
//   useEffect(() => {
//     triggerSearch(inputValue);
//     return () => clearTimeout(debounceTimer.current);
//   }, [inputValue, triggerSearch]);

//   const isFirstRender = useRef(true);

// useEffect(() => {
//   if (isFirstRender.current) {
    
//     // CASE 1: If defaultValue is an object → use directly
//     if (defaultValue && typeof defaultValue === "object") {
//       setSelectedValue(defaultValue);
//       setInputValue(defaultValue.name || "");
//     } 
    
//     // CASE 2: If defaultValue is a string (e.g. "asset1")
//     else if (typeof defaultValue === "string" && defaultValue.trim() !== "") {
//       const obj = { name: defaultValue };
//       setSelectedValue(obj);
//       setInputValue(defaultValue);
//     } 
    
//     // CASE 3: empty defaultValue → create mode
//     else {
//       setSelectedValue(null);
//       setInputValue("");
//     }

//     isFirstRender.current = false;
//   }
// }, [defaultValue]);



// console.log(defaultValue,"defaultvaluesearch")

//   // ✅ infinite scroll
//   const handleScroll = (event) => {
//     const listboxNode = event.currentTarget;
//     if (
//       listboxNode.scrollTop + listboxNode.clientHeight >=
//       listboxNode.scrollHeight - 50
//     ) {
//       if (hasMore && !loading && onLoadMore) {
//         onLoadMore();
//       }
//     }
//   };

//   // ✅ handle value change
//   const handleChange = (e, newValue) => {

//       // ⭐ NEW → If freeSolo allowed AND newValue is string → convert to object
//   if (allowCustomInput && typeof newValue === "string") {
//     newValue = { name: newValue };
//   }
//   console.log(newValue,"newValue")
//     setSelectedValue(newValue);
  
//     setLocalError("");

//     // ✅ send value to parent (formData)
//     if (handleGetValues) {
//       handleGetValues({
//         type: "searchableDropdown",
//         uniqueKey,
//         updatedValue: newValue,
//       });
//     }

//     // ✅ clear error when user selects
//     if (handleGetErrorActivatorInformation) {
//       handleGetErrorActivatorInformation({
//         uniqueKey,
//         indexUniqueKey,
//         error: false,
//       });
//     }
//   };

//   // ✅ handle blur (click outside)
//   // const handleBlur = () => {
//   //   if (isMandatory && !selectedValue) {
//   //     const message = errorMessage || `Please select ${label.toLowerCase()}.`;
//   //     setLocalError(message);

//   //     if (handleGetErrorActivatorInformation) {
//   //       handleGetErrorActivatorInformation({
//   //         uniqueKey,
//   //         indexUniqueKey,
//   //         error: true,
//   //       });
//   //     }
//   //   } else {
//   //     setLocalError("");

//   //     if (handleGetErrorActivatorInformation) {
//   //       handleGetErrorActivatorInformation({
//   //         uniqueKey,
//   //         indexUniqueKey,
//   //         error: false,
//   //       });
//   //     }
//   //   }
//   // };

//   const handleBlur = () => {

//   // ⭐ NEW — Handle user-typed custom value
//   if (allowCustomInput && inputValue && !selectedValue) {

//     const customObj = { name: inputValue };

//     setSelectedValue(customObj);

//     // send custom value to parent (formData)
//     if (handleGetValues) {
//       handleGetValues({
//         type: "searchableDropdown",
//         uniqueKey,
//         updatedValue: customObj,
//       });
//     }

//     // clear error
//     if (handleGetErrorActivatorInformation) {
//       handleGetErrorActivatorInformation({
//         uniqueKey,
//         indexUniqueKey,
//         error: false,
//       });
//     }

//     setLocalError("");
//     return; // STOP here so mandatory error won’t run
//   }

//   // ⭐ YOUR ORIGINAL LOGIC BELOW (unchanged)
//   if (isMandatory && !selectedValue) {
//     const message = errorMessage || `Please select ${label.toLowerCase()}.`;
//     setLocalError(message);

//     if (handleGetErrorActivatorInformation) {
//       handleGetErrorActivatorInformation({
//         uniqueKey,
//         indexUniqueKey,
//         error: true,
//       });
//     }
//   } else {
//     setLocalError("");

//     if (handleGetErrorActivatorInformation) {
//       handleGetErrorActivatorInformation({
//         uniqueKey,
//         indexUniqueKey,
//         error: false,
//       });
//     }
//   }
// };


//   return (
//     <Box className={styles.searchableDropdownContainer}>
//       {isLabel && (
//         <Box className={styles.dropdownLabel}>
//           {label}
//           {isMandatory && <span className={styles.requiredStar}>*</span>}
//         </Box>
//       )}

//       <Box className={styles.dropdownWrapper}>
//         {/* <Autocomplete
//           disablePortal
//           autoHighlight
//           options={data}
//           freeSolo={allowCustomInput}
//           getOptionLabel={(option) => option.name || ""}
//           loading={loading}
//           value={selectedValue}
//           inputValue={inputValue}
//           isOptionEqualToValue={(option, value) =>
//     option?.id === value?.id || option?.name === value?.name
//   }
//           // onInputChange={(e, newInputValue) => setInputValue(newInputValue)}
//           onInputChange={(e, newInputValue) => {
//           setInputValue(newInputValue);

//           // ⭐ FIX: If user typed something different after selecting from list
//           if (
//             allowCustomInput &&
//             selectedValue &&
//             newInputValue !== selectedValue?.name
//           ) {
//             // Keep selectedValue but update it with the user's typed text
//             setSelectedValue((prev) => ({ ...prev, name: newInputValue }));
//           }

//         }}

//           onChange={handleChange}
//           onBlur={handleBlur}
//           renderInput={(params) => (
//             <TextField
//               {...params}
//               variant="outlined"
//                inputProps={{
//                   ...params.inputProps,
//                   tabIndex: tabIndex   
//                 }}
//               placeholder={placeholder}
//               className={styles.dropdownInput}
//               error={!!localError}
//             />
//           )}
//           renderOption={(props, option) => (
//             <Box component="li" {...props} className={styles.dropdownOption}>
//               <Typography>{option.name}</Typography>
//             </Box>
//           )}
//           ListboxProps={{
//             onScroll: handleScroll,
//             ref: listRef,
//             sx: {
//               maxHeight: 250,
//               overflow: "auto",
//               "& li": { padding: "10px 12px", fontSize: "14px" },
//             },
            
//           }}
//         /> */}

//         <Autocomplete
//   disablePortal
//   open={open}
//   onOpen={() => setOpen(true)}
//   onClose={() => {
//     // prevent immediate close when using mouse inside list
//     if (!mouseOverList) setOpen(false);
//   }}
//   autoHighlight
//   options={data}
//   freeSolo={allowCustomInput}
//   getOptionLabel={(option) => option?.name || ""}
//   loading={loading}
//   value={selectedValue}
//   inputValue={inputValue}
//   isOptionEqualToValue={(option, value) =>
//     option?.id === value?.id || option?.name === value?.name
//   }

//   // open the list when user presses ArrowDown while focused
//   onKeyDown={(e) => {
//     if (e.key === "ArrowDown") {
//       // prevent default page scroll and open list
//       e.preventDefault();
//       setOpen(true);
//     }
//   }}

//   onInputChange={(e, newInputValue) => {
//     setInputValue(newInputValue);

//     if (
//       allowCustomInput &&
//       selectedValue &&
//       newInputValue !== selectedValue?.name
//     ) {
//       // Keep selectedValue but update it with the user's typed text
//       setSelectedValue((prev) => ({ ...prev, name: newInputValue }));
//     }
//   }}

//   onChange={handleChange}
//   onBlur={handleBlur}
//   renderInput={(params) => (
//     <TextField
//       {...params}
//       variant="outlined"
//       inputProps={{
//         ...params.inputProps,
//         tabIndex: tabIndex
//       }}
//       placeholder={placeholder}
//       className={styles.dropdownInput}
//       error={!!localError}
//     />
//   )}
//   renderOption={(props, option) => (
//     <Box
//       component="li"
//       {...props}
//       className={styles.dropdownOption}
//       onMouseEnter={() => setMouseOverList(true)}
//       onMouseLeave={() => setMouseOverList(false)}
//     >
//       <Typography>{option.name}</Typography>
//     </Box>
//   )}
//   ListboxProps={{
//     onScroll: handleScroll,
//     ref: listRef,
//     sx: {
//       maxHeight: 250,
//       overflow: "auto",
//       "& li": { padding: "10px 12px", fontSize: "14px" },
//       // ensure keyboard highlight shows clearly (adjust colors to your theme)
//       "& .Mui-focused": {
//         backgroundColor: "#e6f0ff !important",
//         color: "inherit",
//       },
//       "& .Mui-selected": {
//         backgroundColor: "#d0d7ff !important",
//         color: "inherit",
//       },
//       "& .Mui-selected.Mui-focused": {
//         backgroundColor: "#c2ccff !important",
//       },
//     },
//   }}
// />


//         {/* ✅ Local Error Message with Icon */}
//         {localError && (
//           <span
//             style={{ color: CLONOS_GLOBAL_COLOUR_RED }}
//             className={styles.clonosSelectError}
//           >
//             <ErrorSVGCom
//               size={CLONOS_GLOBAL_ERROR_HANDLING_SIZE}
//               color={CLONOS_GLOBAL_COLOUR_RED}
//             />
//             {localError}
//           </span>
//         )}
//       </Box>

//       {loading && data.length > 0 && (
//         <Box sx={{ textAlign: "center", mt: 1 }}>
//           <CircularProgress size={20} />
//         </Box>
//       )}
//     </Box>
//   );
// };

// export default ClonosSearchableDropdown;

//work code

import React, { useState, useEffect, useRef, useCallback } from "react";
import { Autocomplete, TextField, Box, Typography, CircularProgress } from "@mui/material";
import styles from "./ClonosSearchableDropdown.module.css";
import { CLONOS_GLOBAL_COLOUR_RED, CLONOS_GLOBAL_ERROR_HANDLING_SIZE } from "../../../Constants/Constant";
import { ErrorSVGCom } from "../../../assets/svg/ErrorHandling";

const ClonosSearchableDropdown = ({
  label = "Search",
  data = [],
  tabIndex,
  onSearch,
  onLoadMore,
  hasMore = false,
  loading = false,
  debounceDelay = 500,
  isLabel = true,
  isMandatory = false,
  uniqueKey = "name", // dynamically used for both label and value
  errorMessage = "",
  isIndexKey = false,
  indexUniqueKey = "",
  placeholder,
  handleGetValues,
  handleGetErrorActivatorInformation,
  defaultValue,
  allowCustomInput = false,
  hasEdited,
  setHasEdited
  
}) => {
  const [inputValue, setInputValue] = useState("");
  const [selectedValue, setSelectedValue] = useState(null);
  const [localError, setLocalError] = useState("");
  const [open, setOpen] = useState(false);
  const [mouseOverList, setMouseOverList] = useState(false);
 
  const listRef = useRef(null);
  const debounceTimer = useRef(null);

  // store latest search handler
  const latestSearchRef = useRef(onSearch);
  useEffect(() => {
    latestSearchRef.current = onSearch;
  }, [onSearch]);

  // debounce search
  const triggerSearch = useCallback(
    (query) => {
      clearTimeout(debounceTimer.current);
      debounceTimer.current = setTimeout(() => {
        if (query.trim().length >= 1 && latestSearchRef.current) {
          latestSearchRef.current(query);
        } else if (query.trim().length === 0 && latestSearchRef.current) {
          latestSearchRef.current(null);
        }
      }, debounceDelay);
    },
    [debounceDelay]
  );

  useEffect(() => {
    triggerSearch(inputValue);
    return () => clearTimeout(debounceTimer.current);
  }, [inputValue, triggerSearch]);


useEffect(() => {
  
  if (!defaultValue || hasEdited) return; // only populate if user hasn't typed

  let initialValue = null;

  if (typeof defaultValue === "string") {
    initialValue = data.find(item => item[uniqueKey] === defaultValue) || { [uniqueKey]: defaultValue };
  } else if (typeof defaultValue === "object") {
    initialValue = data.find(item => item[uniqueKey] === defaultValue[uniqueKey]) || defaultValue;
  }

  setSelectedValue(initialValue);
  setInputValue(initialValue?.[uniqueKey] || "");
 

}, [defaultValue, data, uniqueKey, hasEdited]);


  // infinite scroll
  const handleScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (hasMore && !loading && onLoadMore) {
        onLoadMore();
      }
    }
  };


// mark as edited whenever user types
const handleInputChange = (e, newInputValue, reason) => {
  setInputValue(newInputValue);
  if (reason === "input") setHasEdited(true); // user typed
};

const handleChange = (e, newValue) => {
   setHasEdited(true); // user selected from list
  if (!newValue) {
    setSelectedValue(null);
    setInputValue("");
  } else if (typeof newValue === "string") {
    // Enter/Tab pressed with free input
    const obj = { [uniqueKey]: newValue };
    setSelectedValue(obj);
    setInputValue(newValue);
  } else {
    // Selected from list
    setSelectedValue(newValue);
    setInputValue(newValue[uniqueKey] || "");
  }

  // trigger your callbacks
  setLocalError("");
  if (handleGetValues) {
    handleGetValues({
      type: "searchableDropdown",
      uniqueKey,
      updatedValue: newValue,
    });
  }
};


  // handle blur
const handleBlur = () => {
  // If allowCustomInput and inputValue is non-empty
  if (allowCustomInput && inputValue) {
    // Only set custom input if it’s not already a selectedValue
    if (!selectedValue || selectedValue[uniqueKey] !== inputValue) {
      const customObj = { [uniqueKey]: inputValue };
      setSelectedValue(customObj);

      if (handleGetValues) {
        handleGetValues({
          type: "searchableDropdown",
          uniqueKey,
          updatedValue: customObj,
        });
      }

      if (handleGetErrorActivatorInformation) {
        handleGetErrorActivatorInformation({
          uniqueKey,
          indexUniqueKey,
          error: false,
        });
      }
    }
  }

  // mandatory validation
  if (isMandatory && !selectedValue) {
    const message = errorMessage || `Please select ${label.toLowerCase()}.`;
    setLocalError(message);

    if (handleGetErrorActivatorInformation) {
      handleGetErrorActivatorInformation({
        uniqueKey,
        indexUniqueKey,
        error: true,
      });
    }
  } else {
    setLocalError("");
    if (handleGetErrorActivatorInformation) {
      handleGetErrorActivatorInformation({
        uniqueKey,
        indexUniqueKey,
        error: false,
      });
    }
  }
};



  return (
    <Box className={styles.searchableDropdownContainer}>
      {isLabel && (
        <Box className={styles.dropdownLabel}>
          {label}
          {isMandatory && <span className={styles.requiredStar}>*</span>}
        </Box>
      )}

      <Box className={styles.dropdownWrapper}>
        <Autocomplete
          disablePortal
          open={open}
          onOpen={() => setOpen(true)}
          onClose={() => { if (!mouseOverList) setOpen(false); setOpen(false); }}
          autoHighlight
          options={data}
          freeSolo={allowCustomInput}
          getOptionLabel={(option) => option?.[uniqueKey] || ""}
          loading={loading}
          value={selectedValue}
          inputValue={inputValue}
          isOptionEqualToValue={(option, value) =>
            option?.id === value?.id || option?.[uniqueKey] === value?.[uniqueKey]
          }
           noOptionsText="No options available"
          onKeyDown={(e) => { if (e.key === "ArrowDown") { e.preventDefault(); setOpen(true); } }}
           onInputChange={handleInputChange}
          onChange={handleChange}
          onBlur={handleBlur}
          renderInput={(params) => (
            <TextField
              {...params}
              variant="outlined"
              inputProps={{ ...params.inputProps, tabIndex: tabIndex }}
              placeholder={placeholder}
              className={styles.dropdownInput}
              error={!!localError}
            />
          )}
          renderOption={(props, option) => (
            <Box
              component="li"
              {...props}
                key={option.id}   
              className={styles.dropdownOption}
              onMouseEnter={() => setMouseOverList(true)}
              onMouseLeave={() => setMouseOverList(false)}
            >
              <Typography>{option?.[uniqueKey]}</Typography>
            </Box>
          )}
          ListboxProps={{
            onScroll: handleScroll,
            ref: listRef,
            sx: {
              maxHeight: 250,
              overflow: "auto",
              "& li": { padding: "10px 12px", fontSize: "14px" },
              "& .Mui-focused": { backgroundColor: "#e6f0ff !important", color: "inherit" },
              "& .Mui-selected": { backgroundColor: "#d0d7ff !important", color: "inherit" },
              "& .Mui-selected.Mui-focused": { backgroundColor: "#c2ccff !important" },
            },
          }}
        />

        {localError && (
          <span style={{ color: CLONOS_GLOBAL_COLOUR_RED }} className={styles.clonosSelectError}>
            <ErrorSVGCom size={CLONOS_GLOBAL_ERROR_HANDLING_SIZE} color={CLONOS_GLOBAL_COLOUR_RED} />
            {localError}
          </span>
        )}
      </Box>

      {loading && data.length > 0 && (
        <Box sx={{ textAlign: "center", mt: 1 }}>
          <CircularProgress size={20} />
        </Box>
      )}
    </Box>
  );
};

export default ClonosSearchableDropdown;







