import React, { useState } from 'react';
import Styles from "./ClonosReadMoreAndLess.module.css";


const ClonosReadMoreReadLess = ({ text, maxLength, style }) => {
    const [isReadMore, setIsReadMore] = useState(true);

    const toggleReadMore = () => {
        setIsReadMore(!isReadMore);
    };

    return (
        <div style={{ ...style }} className={Styles.main_container}>
            {isReadMore ? text?.slice(0, maxLength) : text}
            {text?.length > maxLength && (
                <span className={Styles.more_and_less} onClick={toggleReadMore} style={{ color: 'blue', cursor: 'pointer' }}>
                    {isReadMore ? '...read more' : ' read less'}
                </span>
            )}
        </div>
    );
};

export default ClonosReadMoreReadLess;
