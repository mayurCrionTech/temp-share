import React, { useEffect, useState } from "react";
import ReactFlow, {
  Controls,
  Position,
  applyNodeChanges,
} from "reactflow";
// import dagre from "dagre";
import dagre from "@dagrejs/dagre";
import "reactflow/dist/style.css";
import { useLocation } from "react-router-dom";
import Modal from "../Modal/Modal";
import CloseIcon from "../../../assets/Clonos Common Indicators/Icon_Components/CloseIcon";
import Styles from "./ClonosHierarchyModal.module.css";

const nodeWidth = 180;
const nodeHeight = 60;

const getLayoutedElements = (nodes, edges) => {
  const dagreGraph = new dagre.graphlib.Graph();
  
  dagreGraph.setDefaultEdgeLabel(() => ({}));
  dagreGraph.setGraph({
    rankdir: "TB",
    nodesep: 40,     // tighter horizontal spacing
    ranksep: 60,     // vertical spacing between levels
    marginx: 10,     // reduce graph left/right padding
    marginy: 10,    
    ranker: "tight-tree", // or "longest-path"
  });

  
  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  return nodes.map((node) => {
    const { x, y } = dagreGraph.node(node.id);
    return {
      ...node,
      position: { x, y },
      sourcePosition: Position.Bottom,
      targetPosition: Position.Top,
    };
  });
};

const ClonosHierarchyModal = ({ isOpen, closeModalMethod, nodes: inputNodes, edges }) => {


  const location = useLocation();
  const highlightedNodeId = location?.state?.id;

  const [nodes, setNodes] = useState([]);
 
  useEffect(() => {
    const layoutedNodes = getLayoutedElements(inputNodes, edges).map((node) => ({
      ...node,
      draggable: false,
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: node.id === highlightedNodeId ? "#6885B1" : "#FFF",
        border: node.id === highlightedNodeId ? "2px solid #2C4E87" : "1px solid black",
        color: node.id === highlightedNodeId ? "white" : "#000",
        fontWeight: node.id === highlightedNodeId ? "600" : "normal",
        borderRadius: "6px",
        // padding: "6px 8px",
        fontSize: "14px",
        width: `${nodeWidth}px`,
        height: `${nodeHeight}px`,
      },
    }));
    setNodes(layoutedNodes);
  }, [inputNodes, edges, highlightedNodeId]);

  const stepEdges = edges.map((edge) => ({
    ...edge,
    type: "step",
    animated: true,
    style: { strokeWidth: 2, stroke: "gray" },
  }));

  // 🛠️ Handles node dragging
  const handleNodesChange = (changes) => {
    setNodes((nds) => applyNodeChanges(changes, nds));
  };

  return (
    <Modal isOpen={isOpen} >
      <div className={Styles.main_container}>
        <header>
          <div className={Styles.header_title}>
            <span>Asset Hierarchy</span>
          </div>
          <div className={Styles.close_button} aria-label="Close Modal" onClick={closeModalMethod}>
            <CloseIcon onClick={closeModalMethod}/>
          </div>
        </header>

        <section className={Styles.body}>
          <div className={Styles.tree_container} style={{ width: "100%", height: "500px" }}>
            <ReactFlow
              nodes={nodes}
              edges={stepEdges}
              onNodesChange={handleNodesChange}
              // nodesDraggable={false}
              fitView
              fitViewOptions={{ padding: 0.3 }}
              minZoom={0.1}
              maxZoom={2}
              proOptions={{ hideAttribution: true }}
            >
              <Controls />
            </ReactFlow>
          </div>
        </section>
      </div>
    </Modal>
  );
};

export default React.memo(ClonosHierarchyModal);
