import React, { useRef } from 'react';
import { useEffect, useState } from 'react';
import Styles from './ClonosTextarea.module.css';
import { ErrorSVGCom } from '../../../assets/svg/ErrorHandling';
import { CLONOS_GLOBAL_COLOUR_RED, CLONOS_GLOBAL_ERROR_HANDLING_SIZE } from '../../../Constants/Constant';
import useDebounce from '../../../CustomHooks/DebounceHook';

/**
 * ClonosTextarea component for rendering a custom input field.
 * @param {Object} props - Component props.
 * @property {string} type - Type of the input field.
 * @property {string} name - Name attribute for the input field.
 * @property {string} placeholder - Placeholder text for the input field.
 * @property {string} label - Label for the input field.
 * @property {boolean} isLabel - Flag to show/hide the label.
 * @property {Object} inputStyle - Additional styles for the input field.
 * @property {Object} labelStyle - Additional styles for the label.
 * @property {string} uniqueKey - Unique key for the component.
 * @property {string} defaultValue - Default value for the input field.
 * @property {boolean} isMandatory - Flag indicating whether the field is mandatory.
 * @property {function} handleGetValues - Callback function to handle value changes.
 * @property {string} areaLabel - Description of the area.
 * @property {number} tabIndex - tabIndex for input tag.
 * @property {function} handleGetErrorActivatorInformation - This function will handle all kind of error handling, that returns one object.
 * @property {function} handleGetErrorActivatorInformation.errorActivatorMethod  - This function will trigger or allow to show the error, it takes boolean value (true/false).
 * @property {function} handleGetErrorActivatorInformation.errorSetterMethod  - This function can set the error massage, it takes string.
 * @property {function} handleGetErrorActivatorInformation.type  - "type" represent that which kind of components is it like, "input, select, textarea"
 * @property {function} handleGetErrorActivatorInformation.uniqueKey  - "uniqueKey" will be be unique string that represent specific element.
 * @property {function} handleGetErrorActivatorInformation.value  - "value" Initially will be false that you need to change once that specific element has come value. and make it as true.
 * @returns {React.Component} - ClonosTextarea component.
 */
const ClonosTextarea = React.memo(({
    type,
    uniqueKey,
    tabIndex,
    isDebounce = true,
    debounceDelay,
    value,
    name,
    placeholder,
    label,
    errorMessage,
    isLabel,
    inputStyle,
    labelStyle,
    defaultValue,
    isMandatory = false,
    handleGetValues,
    areaLabel,
    onChange,
    limit,
    handleGetErrorActivatorInformation,
    ...props }) => {
    const [lcValue, setLcValue] = useState('');
    const [showErrorMessage, setShowErrorMessage] = useState(false);
    const [lcErrorMessage, setLcErrorMessage] = useState(errorMessage);
    const elementReference = useRef(null);
    const inputStringDebounced = useDebounce(lcValue, debounceDelay || 500)




    const getElementReferenceMethod = () => {
        return elementReference;
    }

    /**
     * Handle change event for the input field.
     * @param {Object} props - Event object and type of the input field.
     */
    const handleChange = ({ type, e }) => {
        if (type !== 'file') {
            setLcValue((prev) => {
                if (e.target.value.length > limit) {
                    setShowErrorMessage(true)
                    setLcErrorMessage(`Your input should contain less then ${limit} letters!`)
                }
                else setShowErrorMessage(false)

                let updatedValue = e.target.value;
                !isDebounce && handleGetValues && handleGetValues({ type, uniqueKey, updatedValue });
                return updatedValue
            });
        }
    };

    /**
     * Handle form submission, check for mandatory fields.
     */
    const handleSubmit = () => {
        if (lcValue.trim() === '') {
            setShowErrorMessage(true);
        } else {
            setShowErrorMessage(false);
        }
    };

    useEffect(() => {
        defaultValue && defaultValue?.length > 0 && setLcValue(defaultValue);
        value && setLcValue(value)
        setLcErrorMessage(errorMessage || `Please fill ${label ? label?.toLowerCase() : "this"} field!`)
        handleGetErrorActivatorInformation && isMandatory && handleGetErrorActivatorInformation(
            {
                uniqueKey,
                isMandatory, 
                value: (typeof (defaultValue) === "string" || (Array.isArray(defaultValue) === "array" || defaultValue?.length > 0)) ? true : false,
                type,
                errorActivatorMethod: setShowErrorMessage,
                errorSetterMethod: setLcErrorMessage,
                getElementReferenceMethod
            }
        )

    }, [defaultValue]);

    useEffect(() => {
        isDebounce && handleGetValues && handleGetValues({ type, uniqueKey, updatedValue: inputStringDebounced, name });
    }, [inputStringDebounced]);


    return (
        <div className={Styles.clonos_textarea_container} aria-label={areaLabel} id={uniqueKey}>
            {isLabel && <label style={{ ...labelStyle }}>{label} {isMandatory && <sup className={Styles.clonos_textarea_isMandatory}>*</sup>}</label>}
            <div className={Styles.clonos_textarea} style={{ borderColor: showErrorMessage ? CLONOS_GLOBAL_COLOUR_RED : "#8CA1C4" }}>
                <textarea
                    ref={elementReference}
                    tabIndex={tabIndex}
                    type={type}
                    name={name}
                    placeholder={placeholder}
                    value={value ? value : lcValue}
                    defaultValue={defaultValue}
                    onChange={(e) => {
                        handleChange({ type, e })
                        onChange && onChange(e)
                    }}
                    // onBlur={isMandatory && handleSubmit}
                    onBlur={isMandatory ? handleSubmit : undefined}
                    style={{ ...inputStyle }}
                    maxLength={Number(limit) + 1 || 500}
                    {...props}
                />
            </div>
            {showErrorMessage && !value && <span style={{ color: CLONOS_GLOBAL_COLOUR_RED }} className={Styles.clonos_textarea_error}> <ErrorSVGCom size={CLONOS_GLOBAL_ERROR_HANDLING_SIZE} color={CLONOS_GLOBAL_COLOUR_RED} /> {lcErrorMessage}</span>}
        </div>
    );
});

export default ClonosTextarea;
