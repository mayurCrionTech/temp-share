const mongoDbConfig = require("./mongoDb_config");
const serverConfig = require("./server_config");
const authConfig = require("./auth_config");
const securityConfig = require("./security_config");
const smtpConfig = require("./smtp_config");
const fileStorageConfig = require("./fileStorage_config");
const dataCleanupConfig = require("./dataCleanupConfig"); //new cleaner


module.exports = {
	authConfig,
	mongoDbConfig,
	dataCleanupConfig, // new
	serverConfig,
	securityConfig,
	smtpConfig,
	fileStorageConfig
};
