// src/configs/dataCleanupConfig.js

const rollingWindowCleanupConfig = [
  {
    collection: "aiforecast",
    field: "_id",        // use ObjectId creation time, since `timestamp` is a future predicted time
    keepMinutes: 40,
  },
  {
    collection: "setpoint_deviation_events",
    field: "createdAt",
    keepMinutes: 35,
  },
  {
    collection: "forecastDefects",
    field: "lastUpdatedAt",
    keepMinutes: 30,
  },
];

module.exports = { rollingWindowCleanupConfig };