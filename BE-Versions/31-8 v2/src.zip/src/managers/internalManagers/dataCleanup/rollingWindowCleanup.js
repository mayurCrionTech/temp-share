// src/managers/internalManagers/dataCleanup/rollingWindowCleanup.js
const mongoose = require("mongoose");
const { dataCleanupConfig } = require("../../../configs");
const { rollingWindowCleanupConfig } = dataCleanupConfig;

async function cleanupRollingWindows() {
  const db = mongoose.connection.db;

  for (const { collection, field, keepMinutes } of rollingWindowCleanupConfig) {
    const cutoffDate = new Date(Date.now() - keepMinutes * 60 * 1000);

    // aiforecast has no reliable "inserted at" date field (its `timestamp`
    // is a future predicted time), so fall back to the ObjectId's embedded
    // creation time instead.
    const filter =
      field === "_id"
        ? { _id: { $lt: mongoose.Types.ObjectId.createFromTime(Math.floor(cutoffDate.getTime() / 1000)) } }
        : { [field]: { $lt: cutoffDate } };

    try {
      const res = await db.collection(collection).deleteMany(filter);
      if (res.deletedCount) {
        console.log(`cleanupRollingWindows: ${collection} removed ${res.deletedCount}`);
      }
    } catch (err) {
      console.error(`cleanupRollingWindows: ${collection} failed:`, err.message);
    }
  }
}

module.exports = { cleanupRollingWindows };