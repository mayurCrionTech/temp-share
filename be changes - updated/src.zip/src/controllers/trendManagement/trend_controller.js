const trendManager = require("../../managers/internalManagers/trendManagement/trend_manager");
const apiResponseHandler = require("../../managers/common/apiResponseHandler_manager");

// ============================================================
// QID_167 - TREND ANALYSIS
// ============================================================

// Get available trend parameters
exports.getTrendParameters = async (req, res) => {
  try {
    const result = await trendManager.getTrendParameters();

    return apiResponseHandler.successResponse(
      res,
      "Trend parameters fetched successfully",
      200,
      result,
    );
  } catch (error) {
    console.error("Error fetching trend parameters:", error);

    return apiResponseHandler.errorResponse(
      error,
      req,
      res,
      error.message || "Failed to fetch trend parameters",
      500,
      null,
    );
  }
};

// Get complete trend parameter master
exports.getTrendParameterMaster = async (req, res) => {
  try {
    const result = await trendManager.getTrendParameterMaster();

    return apiResponseHandler.successResponse(
      res,
      "Trend parameter master fetched successfully",
      200,
      result,
    );
  } catch (error) {
    console.error("Error fetching trend parameter master:", error);

    return apiResponseHandler.errorResponse(
      error,
      req,
      res,
      error.message || "Failed to fetch trend parameter master",
      500,
      null,
    );
  }
};

// Get current live values for selected parameters
exports.getTrendLiveData = async (req, res) => {
  try {
    const { tagIds, temporaryRanges } = req.query;

    const parsedTagIds = tagIds
      ? tagIds
          .split(",")
          .map((id) => id.trim())
          .filter(Boolean)
      : [];

    const parsedTemporaryRanges = temporaryRanges
      ? JSON.parse(temporaryRanges)
      : {};

    const result = await trendManager.getTrendLiveData(
      parsedTagIds,
      parsedTemporaryRanges,
    );

    return apiResponseHandler.successResponse(
      res,
      "Trend live data fetched successfully",
      200,
      result,
    );
  } catch (error) {
    console.error("Error fetching trend live data:", error);

    return apiResponseHandler.errorResponse(
      error,
      req,
      res,
      error.message || "Failed to fetch trend live data",
      500,
      null,
    );
  }
};

// Get historical trend data
exports.getTrendHistory = async (req, res) => {
  try {
    const { tagIds, startDate, endDate, temporaryRanges, bucket } = req.query;

    const parsedTagIds = tagIds
      ? tagIds
          .split(",")
          .map((id) => id.trim())
          .filter(Boolean)
      : [];

    const parsedTemporaryRanges = temporaryRanges
      ? JSON.parse(temporaryRanges)
      : {};

    const result = await trendManager.getTrendHistory(
      parsedTagIds,
      startDate,
      endDate,
      parsedTemporaryRanges,
      bucket,
    );

    return apiResponseHandler.successResponse(
      res,
      "Trend history fetched successfully",
      200,
      result,
    );
  } catch (error) {
    console.error("Error fetching trend history:", error);

    return apiResponseHandler.errorResponse(
      error,
      req,
      res,
      error.message || "Failed to fetch trend history",
      500,
      null,
    );
  }
};

// Get trend statistics / summary
exports.getTrendSummary = async (req, res) => {
  try {
    const { tagIds, startDate, endDate, temporaryRanges } = req.query;

    const parsedTagIds = tagIds
      ? tagIds
          .split(",")
          .map((id) => id.trim())
          .filter(Boolean)
      : [];

    const parsedTemporaryRanges = temporaryRanges
      ? JSON.parse(temporaryRanges)
      : {};

    const result = await trendManager.getTrendSummary({
      tagIds: parsedTagIds,
      startDate,
      endDate,
      temporaryRanges: parsedTemporaryRanges,
    });

    return apiResponseHandler.successResponse(
      res,
      "Trend summary fetched successfully",
      200,
      result,
    );
  } catch (error) {
    console.error("Error fetching trend summary:", error);

    return apiResponseHandler.errorResponse(
      error,
      req,
      res,
      error.message || "Failed to fetch trend summary",
      500,
      null,
    );
  }
};

// Get latest values for selected parameters
exports.getTrendLatestValues = async (req, res) => {
  try {
    const { tagIds, temporaryRanges } = req.query;

    const parsedTagIds = tagIds
      ? tagIds
          .split(",")
          .map((id) => id.trim())
          .filter(Boolean)
      : [];

    const parsedTemporaryRanges = temporaryRanges
      ? JSON.parse(temporaryRanges)
      : {};

    const result = await trendManager.getTrendLatestValues({
      tagIds: parsedTagIds,
      temporaryRanges: parsedTemporaryRanges,
    });

    return apiResponseHandler.successResponse(
      res,
      "Trend latest values fetched successfully",
      200,
      result,
    );
  } catch (error) {
    console.error("Error fetching trend latest values:", error);

    return apiResponseHandler.errorResponse(
      error,
      req,
      res,
      error.message || "Failed to fetch trend latest values",
      500,
      null,
    );
  }
};
