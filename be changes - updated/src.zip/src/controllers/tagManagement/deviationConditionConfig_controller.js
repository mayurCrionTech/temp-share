// #QID_174

const deviationConditionConfigManager = require("../../managers/internalManagers/tagManagement/deviationConditionConfig_manager");

const {
  successResponse,
  errorResponse,
} = require("../../managers/common/apiResponseHandler_manager");

// Get user ID from authenticated request
function getUserId(req) {
  return req.userId || req.user?._id || req.user?.id || null;
}

// Standard success response
function sendSuccess(res, message, data, status = 200) {
  return successResponse(res, message, status, data);
}

// Standard error response
function sendError(res, error, req, statusCode) {
  const message = error?.message || "Something went wrong";

  const status =
    statusCode ||
    (/not found/i.test(message)
      ? 404
      : /already exists|another configuration/i.test(message)
        ? 409
        : /invalid|select at least|must have datatype|must be a boolean|not valid Boolean/i.test(
              message,
            )
          ? 400
          : 500);

  return errorResponse(error, req, res, message, status);
}

// GET /deviation-condition-configs/numeric-tags
async function getNumericTags(req, res) {
  try {
    const tags = await deviationConditionConfigManager.getNumericTags();

    return sendSuccess(res, "Numeric tags fetched successfully.", tags);
  } catch (error) {
    return sendError(res, error, req);
  }
}

// GET /deviation-condition-configs/condition-tags
async function getConditionTags(req, res) {
  try {
    const tags = await deviationConditionConfigManager.getConditionTags();

    return sendSuccess(res, "Condition tags fetched successfully.", tags);
  } catch (error) {
    return sendError(res, error, req);
  }
}

// GET /deviation-condition-configs
async function getAllConfigurations(req, res) {
  try {
    const configs =
      await deviationConditionConfigManager.getAllConfigurations();

    return sendSuccess(
      res,
      "Deviation condition configurations fetched successfully.",
      configs,
    );
  } catch (error) {
    return sendError(res, error, req);
  }
}

// POST /deviation-condition-configs
async function createConfiguration(req, res) {
  try {
    const config = await deviationConditionConfigManager.createConfiguration(
      req.body,
      getUserId(req),
    );

    return sendSuccess(
      res,
      "Deviation condition configuration created successfully.",
      config,
      201,
    );
  } catch (error) {
    return sendError(res, error, req);
  }
}

// PUT /deviation-condition-configs/:id
async function updateConfiguration(req, res) {
  try {
    const config = await deviationConditionConfigManager.updateConfiguration(
      req.params.id,
      req.body,
      getUserId(req),
    );

    return sendSuccess(
      res,
      "Deviation condition configuration updated successfully.",
      config,
    );
  } catch (error) {
    return sendError(res, error, req);
  }
}

// PATCH /deviation-condition-configs/:id/status
async function updateConfigurationStatus(req, res) {
  try {
    const config =
      await deviationConditionConfigManager.updateConfigurationStatus(
        req.params.id,
        req.body.isEnabled,
        getUserId(req),
      );

    return sendSuccess(
      res,
      "Deviation condition configuration status updated successfully.",
      config,
    );
  } catch (error) {
    return sendError(res, error, req);
  }
}

module.exports = {
  getNumericTags,
  getConditionTags,
  getAllConfigurations,
  createConfiguration,
  updateConfiguration,
  updateConfigurationStatus,
};
