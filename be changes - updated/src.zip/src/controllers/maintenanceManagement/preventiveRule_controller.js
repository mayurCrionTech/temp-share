const preventiveRuleManager = require("../../managers/internalManagers/maintenanceManagement/preventiveRule_manager");
const apiResponseHandler = require("../../managers/common/apiResponseHandler_manager");

exports.createPreventiveRule = async (req, res) => {
  try {
    const ruleObj = {
      ruleName: req.body.ruleName,
      tagId: req.body.tagId,
      parameter: req.body.parameter,
      operator: req.body.operator,
      cutoffValue: req.body.cutoffValue,
      unit: req.body.unit,
      evaluationFrequency: req.body.evaluationFrequency,
      autoRearm: req.body.autoRearm,
      priority: req.body.priority,
    };
    const createdRule = await preventiveRuleManager.createPreventiveRule(ruleObj, req.userId);
    return apiResponseHandler.successResponse(res, "Preventive Rule created successfully", 201, { id: createdRule._id });
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

exports.fetchPreventiveRules = async (req, res) => {
  try {
    const result = await preventiveRuleManager.fetchPreventiveRules(req.query);
    return apiResponseHandler.successResponse(res, "Preventive Rules fetched successfully", 200, result);
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

exports.fetchPreventiveRule = async (req, res) => {
  try {
    return apiResponseHandler.successResponse(res, "Preventive Rule fetched successfully", 200, req.preventiveRuleObj);
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

exports.editPreventiveRule = async (req, res) => {
  try {
    await preventiveRuleManager.editPreventiveRule(req.preventiveRule, req.body, req.userId);
    return apiResponseHandler.successResponse(res, "Preventive Rule updated successfully", 200, null);
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

exports.deletePreventiveRules = async (req, res) => {
  try {
    await preventiveRuleManager.deletePreventiveRules(req.body.preventiveRules, req.userId);
    return apiResponseHandler.successResponse(res, "Preventive Rules deleted successfully", 200, null);
  } catch (error) {
    return apiResponseHandler.errorResponse(
      error, req, res,
      error.linkedPlans ? error.message : "Internal server error",
      error.linkedPlans ? 409 : 500,
      error.linkedPlans ? { linkedPlans: error.linkedPlans } : null
    );
  }
};