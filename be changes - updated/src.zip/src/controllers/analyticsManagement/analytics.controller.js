/**
 * analytics.controller.js
 * Place at: src/controllers/analyticsManagement/analytics.controller.js
 */
const apiResponseHandler = require("../../managers/common/apiResponseHandler_manager");
const analyticsManager = require("../../managers/internalManagers/analyticsManagement/analytics.manager");
const analyticsReportManager = require("../../managers/internalManagers/analyticsManagement/analyticsReport.manager");

const fail = (error, req, res) =>
  apiResponseHandler.errorResponse(
    error,
    req,
    res,
    error.message || "Server error",
    error.status || 500,
    {},
  );

/**
 * GET /analytics/search?searchBy=hanger|skid|cabin&value=HA09&from=ISO&to=ISO[&limit=200]
 */
const searchVehicles = async (req, res) => {
  try {
    const { searchBy, value, from, to, limit } = req.query;
    const result = await analyticsManager.searchVehicles({
      searchBy,
      value,
      from: new Date(from),
      to: new Date(to),
      limit: limit ? Math.min(Number(limit) || 200, 500) : 200,
    });
    return apiResponseHandler.successResponse(
      res,
      "Vehicle search completed",
      200,
      result,
    );
  } catch (error) {
    return fail(error, req, res);
  }
};

/**
 * GET /analytics/journey?cabinNumber=296357[&skid=1061][&includeStatus=true]
 */
const getVehicleJourney = async (req, res) => {
  try {
    const { cabinNumber, skid, includeStatus } = req.query;
    const result = await analyticsManager.getVehicleJourney({
      cabinNumber,
      skid,
      includeStatus: includeStatus === "true",
    });
    if (!result) {
      return apiResponseHandler.errorResponse(
        new Error("No journey found"),
        req,
        res,
        "No journey found for this vehicle",
        404,
        {},
      );
    }
    return apiResponseHandler.successResponse(
      res,
      "Vehicle journey fetched",
      200,
      result,
    );
  } catch (error) {
    return fail(error, req, res);
  }
};

/**
 * GET /analytics/stage-readings?cabinNumber=296357&skid=1061&stageId=PT-1
 */
const getStageReadings = async (req, res) => {
  try {
    const { cabinNumber, skid, stageId } = req.query;
    const result = await analyticsManager.getStageReadings({
      cabinNumber,
      skid,
      stageId,
    });
    if (!result) {
      return apiResponseHandler.errorResponse(
        new Error("Vehicle not seen at this stage"),
        req,
        res,
        "This vehicle was not recorded at this stage",
        404,
        {},
      );
    }
    return apiResponseHandler.successResponse(
      res,
      "Stage readings fetched",
      200,
      result,
    );
  } catch (error) {
    return fail(error, req, res);
  }
};

const generateCorrelationReport = async (req, res) => {
  try {
    const { searchBy, value, from, to } = req.query;

    const csv = await analyticsReportManager.generateCorrelationCsvReport({
      searchBy,
      value,
      from: new Date(from),
      to: new Date(to),
    });

    if (!csv) {
      return apiResponseHandler.errorResponse(
        new Error("No correlation data found"),
        req,
        res,
        "No correlation data found for the given search",
        404,
        {},
      );
    }

    const buffer = Buffer.from(`\uFEFF${csv}`, "utf8");

    const fileName = `correlation-report-${searchBy}-${value}.csv`;

    res.setHeader("Content-Type", "text/csv; charset=utf-8");

    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);

    res.setHeader("Content-Length", buffer.length);

    return res.end(buffer);
  } catch (error) {
    return fail(error, req, res);
  }
};

const generateProcessReport = async (req, res) => {
  try {
    const { cabinNumber, skid } = req.query;

    const csv = await analyticsReportManager.generateProcessCsvReport({
      cabinNumber,
      skid,
    });

    if (!csv) {
      return apiResponseHandler.errorResponse(
        new Error("No process data found"),
        req,
        res,
        "No process data found for this vehicle",
        404,
        {},
      );
    }

    const buffer = Buffer.from(`\uFEFF${csv}`, "utf8");

    const fileName = `process-report-${cabinNumber || skid}.csv`;

    res.setHeader("Content-Type", "text/csv; charset=utf-8");

    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);

    res.setHeader("Content-Length", buffer.length);

    return res.end(buffer);
  } catch (error) {
    return fail(error, req, res);
  }
};

/**
 * GET /analytics/overview?limit=20
 *
 * Default data when Analytics page is opened.
 */
const getAnalyticsOverview = async (req, res) => {
  try {
    const { limit } = req.query;

    const result = await analyticsManager.getAnalyticsOverview({
      limit: limit ? Number(limit) : 20,
    });

    return apiResponseHandler.successResponse(
      res,
      "Analytics overview fetched",
      200,
      result,
    );
  } catch (error) {
    return fail(error, req, res);
  }
};

module.exports = {
  searchVehicles,
  getVehicleJourney,
  getStageReadings,
  generateCorrelationReport,
  generateProcessReport,
  getAnalyticsOverview,
};
