const { mongoDbManager } = require("../../dBManagers/index");
const { PreventiveRule } = require("../../../models/mongoDB/maintenanceManagement/preventiveRule_model");
const { MaintenancePlan } = require("../../../models/mongoDB/maintenanceManagement/maintenancePlan_model");
const paginationHandler = require("../../common/paginationHandler_manager");

async function createPreventiveRule(ruleObject, userId) {
  try {
    ruleObject.createdBy = userId;
    ruleObject.updatedBy = userId;
    const createdRule = await mongoDbManager.insertOne(PreventiveRule, ruleObject);
    return createdRule;
  } catch (error) {
    throw error;
  }
}

async function fetchPreventiveRules(reqData) {
  try {
    const query = { isDeleted: false };
    if (reqData.status) query.status = reqData.status;
    if (reqData.priority) query.priority = reqData.priority;
    if (reqData.tagId) query.tagId = reqData.tagId;

    const page = parseInt(reqData.page) || 1;
    const limit = parseInt(reqData.limit) || 10;

    const countData = await mongoDbManager.count(PreventiveRule, query);
    const rules = await PreventiveRule.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .lean();

    return paginationHandler.paginationResObj(page, limit, countData, rules);
  } catch (error) {
    throw error;
  }
}

async function fetchPreventiveRule(ruleId) {
  try {
    const rule = await PreventiveRule.findOne({ _id: ruleId, isDeleted: false }).lean();
    return rule;
  } catch (error) {
    throw error;
  }
}

async function editPreventiveRule(ruleId, updateObject, userId) {
  try {
    updateObject.updatedBy = userId;
    updateObject.updatedAt = Date.now();
    const updatedRule = await mongoDbManager.findOneAndUpdate(
      PreventiveRule,
      { _id: ruleId, isDeleted: false },
      updateObject
    );
    return updatedRule;
  } catch (error) {
    throw error;
  }
}

async function deletePreventiveRules(ruleIds, userId) {
  try {
    // A rule still linked to an active plan shouldn't be deleted out from under it —
    // worth confirming this check with Adlin/product, flagging here rather than skipping silently.
    const linkedPlans = await MaintenancePlan.find({
      preventiveMaintenanceRuleId: { $in: ruleIds },
      isDeleted: false,
    }).select("_id name preventiveMaintenanceRuleId");

    if (linkedPlans.length > 0) {
      const error = new Error("One or more rules are still linked to an active Maintenance Plan and cannot be deleted.");
      error.linkedPlans = linkedPlans;
      throw error;
    }

    const result = await mongoDbManager.updateMany(
      PreventiveRule,
      { _id: { $in: ruleIds } },
      { $set: { isDeleted: true, updatedBy: userId, updatedAt: new Date() } }
    );
    return result;
  } catch (error) {
    throw error;
  }
}

module.exports = {
  createPreventiveRule,
  fetchPreventiveRules,
  fetchPreventiveRule,
  editPreventiveRule,
  deletePreventiveRules,
};