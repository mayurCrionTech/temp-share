const { MaintenancePlan } = require("../../../models/mongoDB/maintenanceManagement/maintenancePlan_model");
const { workOrders } = require("../../../models/mongoDB/maintenanceManagement/workOrder_model");
const { PreventiveRule } = require("../../../models/mongoDB/maintenanceManagement/preventiveRule_model");
const LiveDataEntries = require("../../../models/mongoDB/liveDataManagement/liveDataEntries_model");
const { mongoDbManager } = require("../../dBManagers/index");
const workOrderManager = require("./workOrder_manager");
const workOrderTaskManager = require("../../internalManagers/maintenanceManagement/workOrderTask_manager");
const fileManager = require("../../internalManagers/fileSystem/fileSystem_manager");
const { sendPreventiveWorkOrderEmail } = require("../../../utils/emailService/templates/preventiveWorkOrderEmailTemplate");
const User = require("../../../models/mongoDB/userManagement/user_model");
const mongoose = require("mongoose");
const { DateTime, Duration } = require("luxon");
const { AssetHistory } = require("../../../models/mongoDB/assetManagement/assetHistory_model");


// CR0127
const OPEN_STATUSES = ["scheduled", "accepted", "onHold", "pendingForApproval", "assigned"];
const EVAL_WINDOW_SECONDS = 900; // both flows now run on this cadence
const BATCH_SIZE = 20;
const AGGREGATION_TIMEOUT_MS = 8000;
const PRE_WINDOW_LOOKBACK_LIMIT = 500;

const PARAMETER_TYPES = {
  RUNNING_HOURS: "runningHours",
  SETPOINT: "setpoint",
};

let cycleInProgress = false;

const evaluatePreventiveRules = async () => {
  if (cycleInProgress) {
    console.warn("evaluatePreventiveRules: previous cycle still running, skipping this tick");
    return;
  }
  cycleInProgress = true;

  try {
    const plans = await MaintenancePlan.find({
      status: "scheduled",
      isDeleted: false,
      isPreventive: true,
    }).populate("tasks");

    console.log(`evaluatePreventiveRules: checking ${plans.length} plans with preventive rules`);

    for (let i = 0; i < plans.length; i += BATCH_SIZE) {
      const batch = plans.slice(i, i + BATCH_SIZE);
      await Promise.all(
        batch.map((plan) =>
          evaluateSinglePlan(plan).catch((err) => {
            console.error(`evaluatePreventiveRules: plan ${plan._id} failed:`, err.message);
          })
        )
      );
    }
  } catch (error) {
    console.error("evaluatePreventiveRules: cycle failed", error);
  } finally {
    cycleInProgress = false;
  }
};

const evaluateSinglePlan = async (plan) => {
  const rule = await mongoDbManager.findOne(
    PreventiveRule,
    { _id: plan.preventiveMaintenanceRuleId, status: "Active", isDeleted: false },
    {}
  );

  if (!rule) {
    console.warn(`evaluatePreventiveRules: plan ${plan._id} marked isPreventive but no active rule found`);
    return;
  }

  const rangeEnd = new Date();
  let newAccumulatedValue;
  let breached;
  let nextEvaluatedAt = rangeEnd; // default: window fully consumed

  // ---------------------------------------------------------
  // Branch by parameter type — the two flows have different semantics:
  // RUNNING_HOURS accumulates a total over time; SETPOINT compares each
  // raw reading directly against the cutoff, in order.
  // ---------------------------------------------------------
  if (rule.parameter === PARAMETER_TYPES.RUNNING_HOURS) {
    const rangeStart = rule.lastEvaluatedAt || new Date(Date.now() - EVAL_WINDOW_SECONDS * 1000);
    const incrementValue = await calculateRunningHours(rule.tagId, rangeStart, rangeEnd);

    newAccumulatedValue = (rule.accumulatedValue || 0) + incrementValue;
    breached = checkBreach(rule.operator, newAccumulatedValue, rule.cutoffValue);
  } else if (rule.parameter === PARAMETER_TYPES.SETPOINT) {
    const rangeStart = rule.lastEvaluatedAt || new Date(Date.now() - EVAL_WINDOW_SECONDS * 1000);
    const result = await findFirstSetpointBreach(rule.tagId, rangeStart, rangeEnd, rule.operator, rule.cutoffValue);

    if (result.value === null) {
      // no new readings this cycle — leave lastEvaluatedAt untouched, retry same window next tick
      return;
    }

    // Setpoint is a direct reading, not a running sum — don't add to previous accumulatedValue.
    newAccumulatedValue = result.value;
    breached = result.crossed;

    if (result.crossed) {
      // Advance just past the exact breaching reading so next cycle doesn't re-match it,
      // while not skipping any readings that came after it within this same window.
      nextEvaluatedAt = new Date(result.timestamp.getTime() + 1);
    }
  } else {
    console.warn(`evaluatePreventiveRules: rule ${rule._id} has unknown parameter "${rule.parameter}"`);
    return;
  }

  if (!breached) {
    await mongoDbManager.updateOne(
      PreventiveRule,
      { _id: rule._id },
      { $set: { accumulatedValue: newAccumulatedValue, lastEvaluatedAt: nextEvaluatedAt } }
    );
    return;
  }

  const existingOpenWO = await mongoDbManager.findOne(
    workOrders,
    { maintenanceId: plan._id, triggerType: "preventive", status: { $in: OPEN_STATUSES }, isDeleted: false },
    {}
  );
  if (existingOpenWO) {
    console.log(`evaluatePreventiveRules: plan ${plan._id} already has open WO ${existingOpenWO._id} — skipping`);
    await mongoDbManager.updateOne(
      PreventiveRule,
      { _id: rule._id },
      { $set: { accumulatedValue: newAccumulatedValue, lastEvaluatedAt: nextEvaluatedAt } }
    );
    return;
  }

  if (!rule.autoRearm && rule.lastWorkOrderId) {
    console.log(`evaluatePreventiveRules: rule ${rule._id} autoRearm=false, already triggered — skipping`);
    await mongoDbManager.updateOne(
      PreventiveRule,
      { _id: rule._id },
      { $set: { accumulatedValue: newAccumulatedValue, lastEvaluatedAt: nextEvaluatedAt } }
    );
    return;
  }

  const createdWorkOrder = await createWorkOrderFromPlanAndRule(plan, rule, newAccumulatedValue);
  await mongoDbManager.updateOne(
    PreventiveRule,
    { _id: rule._id },
    {
      $set: {
        accumulatedValue: rule.autoRearm ? 0 : newAccumulatedValue,
        lastEvaluatedAt: nextEvaluatedAt,
        lastTriggeredValue: newAccumulatedValue,
        lastWorkOrderId: createdWorkOrder._id,
      },
    }
  );

  console.log(`evaluatePreventiveRules: [${rule.parameter}] WO ${createdWorkOrder._id} created — plan ${plan._id}, rule ${rule._id}, total ${newAccumulatedValue}`);

  const userIds = [plan.createdBy, ...(plan.assignees || [])];

  // Deduplicate in case createdBy is also listed as an assignee
  const uniqueUserIds = [...new Set(userIds.map((id) => id.toString()))];

  const users = await mongoDbManager.findMany(User, { _id: { $in: uniqueUserIds } });
  const validUsers = users.filter((u) => u.email);

  await Promise.all(
    validUsers.map((userDetails) =>
      sendPreventiveWorkOrderEmail(
        [userDetails.email],
        "Preventive Workorder",
        createdWorkOrder._id,
        userDetails
      )
    )
  );
};

// =========================================================
// FLOW 1 — RUNNING HOURS (Method A: gap-based elapsed time)
// =========================================================
async function calculateRunningHours(tagId, rangeStart, rangeEnd) {
  const tagObjectId = mongoose.Types.ObjectId.isValid(tagId)
    ? new mongoose.Types.ObjectId(tagId)
    : tagId;

  const result = await LiveDataEntries.aggregate(
    [
      { $match: { tagId: tagObjectId, timestamp: { $lt: rangeEnd } } },
      { $sort: { timestamp: -1 } },
      { $limit: PRE_WINDOW_LOOKBACK_LIMIT },
      { $sort: { timestamp: 1 } },
      {
        $setWindowFields: {
          partitionBy: "$tagId",
          sortBy: { timestamp: 1 },
          output: {
            prevTimestamp: { $shift: { output: "$timestamp", by: -1 } },
            prevValue: { $shift: { output: "$value", by: -1 } },
          },
        },
      },
      { $match: { timestamp: { $gte: rangeStart } } },
      {
        $project: {
          runningSeconds: {
            $cond: [
              {
                $and: [
                  { $ne: ["$prevTimestamp", null] },
                  { $ne: ["$prevValue", null] },
                  { $gt: ["$prevValue", 0] },
                ],
              },
              { $divide: [{ $subtract: ["$timestamp", "$prevTimestamp"] }, 1000] },
              0,
            ],
          },
        },
      },
      { $group: { _id: null, totalRunningSeconds: { $sum: "$runningSeconds" } } },
      { $project: { incrementHours: { $divide: ["$totalRunningSeconds", 3600] } } },
    ],
    { maxTimeMS: AGGREGATION_TIMEOUT_MS }
  );

  return result.length > 0 ? result[0].incrementHours : 0;
}

// =========================================================
// FLOW 2 — SETPOINT (first reading in window that crosses cutoff)
// =========================================================
async function findFirstSetpointBreach(tagId, rangeStart, rangeEnd, operator, cutoffValue) {
  const tagObjectId = mongoose.Types.ObjectId.isValid(tagId)
    ? new mongoose.Types.ObjectId(tagId)
    : tagId;

  const readings = await LiveDataEntries.find(
    { tagId: tagObjectId, timestamp: { $gte: rangeStart, $lt: rangeEnd } },
    { value: 1, timestamp: 1, _id: 0 }
  )
    .sort({ timestamp: 1 })
    .lean();

  for (const reading of readings) {
    if (checkBreach(operator, reading.value, cutoffValue)) {
      return { crossed: true, value: reading.value, timestamp: reading.timestamp };
    }
  }

  const lastReading = readings[readings.length - 1];
  return {
    crossed: false,
    value: lastReading ? lastReading.value : null,
    timestamp: null,
  };
}

// =========================================================
// SHARED HELPERS
// =========================================================
function checkBreach(operator, value, cutoff) {
  switch (operator) {
    case ">": return value > cutoff;
    case ">=": return value >= cutoff;
    case "<": return value < cutoff;
    case "<=": return value <= cutoff;
    default: return false;
  }
}

async function createWorkOrderFromPlanAndRule(plan, rule, currentValue) {
  const workOrderObjectToBeCreated = await preventiveWorkOrderCreateObject(plan, rule, currentValue);
  const createdWorkOrder = await workOrderManager.createWorkOrder(workOrderObjectToBeCreated, plan.createdBy);

  const taskObj = createTaskObj(plan, createdWorkOrder._id);
  await workOrderTaskManager.createWorkOrderTasksManager(taskObj, createdWorkOrder._id);

  await AssetHistory.create({
    name: "WorkOrderCreated",
    description: createdWorkOrder.name,
    status: "planned",
    moduleId: createdWorkOrder._id,
    moduleName: "workOrders",
    asset: createdWorkOrder.asset,
    businessUnit: createdWorkOrder.businessUnit,
    eventDate: createdWorkOrder.createdAt,
  });

  return createdWorkOrder;
}

const preventiveWorkOrderCreateObject = async (plan, rule, currentValue) => {
  try {
    const now = new Date();
    const estimatedDuration = Duration.fromObject({
      days: plan.estimatedDays || 0,
      hours: plan.estimatedHours || 0,
    });

    const calculatedEndAt = DateTime.fromJSDate(now).plus(estimatedDuration).toJSDate();
    const obj = {
      name: (await generateNumber()) + plan.name,
      description: plan.description,
      asset: plan.asset,
      departments: plan.departments,
      priority: rule.priority || plan.priority,
      startAt: now,
      endAt: calculatedEndAt,
      estimatedDays: plan.estimatedDays,
      estimatedHours: plan.estimatedHours,
      assignees: plan.assignees,
      existingTeams: plan.existingTeams,
      addToAssetHistory: plan.addToAssetHistory,
      localTeams: plan.localTeams,
      images: await updateFiles(plan, plan.createdBy, "images"),
      documents: await updateFiles(plan, plan.createdBy, "documents"),
      status: "assigned",
      isMaintenanceScheduled: true,
      triggerType: "preventive",
      preventiveMaintenanceRuleId: rule._id,
      triggerReading: currentValue,
      maintenanceId: plan._id,
      createdBy: plan.createdBy,
      updatedBy: plan.updatedBy,
      businessUnit: plan.businessUnit,
    };
    return obj;
  } catch (error) {
    throw error;
  }
};

async function generateNumber() {
  try {
    const currentYear = new Date().getFullYear();
    const yearStart = new Date(`${currentYear}-01-01T00:00:00.000Z`);
    const yearEnd = new Date(`${currentYear + 1}-01-01T00:00:00.000Z`);

    const lastWONumber = await mongoDbManager.count(workOrders, {
      isDeleted: false,
      triggerType: "preventive",
      createdAt: { $gte: yearStart, $lt: yearEnd },
    });

    let currentVersion = 1;
    if (lastWONumber !== null) {
      currentVersion = lastWONumber + 1;
    }

    const paddedVersion = String(currentVersion).padStart(6, "0");
    return `PM-WO-${currentYear}-${paddedVersion}`;
  } catch (error) {
    throw error;
  }
}

async function updateFiles(maintenancePlanObject, userId, fileType) {
  try {
    const createdFiles = [];
    const files = maintenancePlanObject[fileType];

    if (files && files.length > 0) {
      const copiedFiles = await fileManager.copyToLocation(null, userId, "uploads", files);
      for (let file of copiedFiles) {
        const transformedFile = await fileManager.transformFileObj(file, "internal");
        createdFiles.push(transformedFile);
      }
      return createdFiles;
    }
    return [];
  } catch (error) {
    throw error;
  }
}

function createTaskObj(plan, workOrderId) {
  const tasks = plan.tasks;
  if (!Array.isArray(tasks)) {
    return [];
  }
  return tasks.map((task) => ({
    description: task.description || task.name,
    index: task.index || task.order,
    workOrderId: workOrderId,
    updatedBy: task.updatedBy,
    createdBy: task.createdBy,
  }));
}

module.exports = { evaluatePreventiveRules };