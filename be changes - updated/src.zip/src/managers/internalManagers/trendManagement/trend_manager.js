const mongoose = require("mongoose");

const {
  TagLive,
  TagHistory,
  getLiveDataCollection,
} = require("../../../models/mongoDB/tags/tagsModel");

// ============================================================
// QID_167 - TREND ANALYSIS
// ============================================================
//
// Parameter master is intentionally maintained here.
// DO NOT read TagLive.ranges for QID_167.
//
// Data sources:
//   LIVE       -> tag_lives / liveData_test
//   MANUAL LOG -> LogEntry collection
// ============================================================

// ============================================================
// PARAMETER MASTER
// ============================================================

const TREND_PARAMETERS = [
  // ==========================================================
  // PT - PRE TREATMENT - 62 PARAMETERS
  // ==========================================================

  {
    id: 1,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Degreasing Spray Bath Temperature",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a050d",
    unit: "ºC",
    min: 50,
    max: 60,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 2,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Spray Pressure Bottom",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a050a",
    unit: "Bar",
    min: 0.9,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 3,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Spray Pressure Top",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0507",
    unit: "Bar",
    min: 0.9,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 4,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Heat Exchanger ∆P",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0510",
    unit: "Bar",
    min: null,
    max: 0.7,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 5,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Cyclone Inlet Pressure",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a051f",
    unit: "Bar",
    min: 2.0,
    max: 2.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 6,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Cyclone ∆P",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0522",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 7,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Bag Filter 1 ∆P",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0516",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 8,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Bag Filter 2 ∆P",
    source: "LIVE",
    tagId: "6a7c688863f1464aebae7645",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 9,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Oil Separator Temperature",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0525",
    unit: "°C",
    min: 80,
    max: 85,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 10,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Oil Separator Flow",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0528",
    unit: "LPM",
    min: 10,
    max: 15,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 11,
    process: "PT",
    stage: "Degreasing Spray",
    parameter: "Free Alkali",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0519",
    unit: "Points",
    min: 16,
    max: 19,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 12,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Bath Temperature",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a052b",
    unit: "ºC",
    min: 52,
    max: 58,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 13,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Circulation Pressure - LH",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a052e",
    unit: "Bar",
    min: 1.0,
    max: 1.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 14,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Circulation Pressure - RH",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0531",
    unit: "Bar",
    min: 1.0,
    max: 1.5,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 15,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Circulation Pressure - LH Side",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0552",
    unit: "Bar",
    min: 2.6,
    max: 3.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 16,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Circulation Pressure - Bottom",
    source: "LIVE",
    tagId: "69a18055be84d052e4e1eb46",
    unit: "Bar",
    min: 2.6,
    max: 3.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 17,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Cyclone Inlet Pressure",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a054f",
    unit: "Bar",
    min: 3.0,
    max: 3.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 18,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Cyclone ∆P",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a054c",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 19,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Bag Filter ∆P",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0540",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 20,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Heat Exchanger ∆P",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0540",
    unit: "Bar",
    min: null,
    max: 0.7,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 21,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Exit Spray Flow",
    source: "MANUAL_LOG",
    tagId: "6a8ed4d56a2948fd77de1660",
    unit: "LPM",
    min: 160,
    max: 200,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 22,
    process: "PT",
    stage: "Degreasing Dip",
    parameter: "Free Alkali",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0543",
    unit: "Points",
    min: 16,
    max: 19,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 23,
    process: "PT",
    stage: "Water Rinse 1",
    parameter: "Spray Pressure - Top",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a055b",
    unit: "Bar",
    min: 0.7,
    max: 0.9,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 24,
    process: "PT",
    stage: "Water Rinse 1",
    parameter: "Spray Pressure - Bottom",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a055e",
    unit: "Bar",
    min: 0.8,
    max: 1.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 25,
    process: "PT",
    stage: "Water Rinse 1",
    parameter: "Free Alkali",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0564",
    unit: "Points",
    min: null,
    max: 5,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 26,
    process: "PT",
    stage: "Water Rinse 1",
    parameter: "Water Transfer To Degrease",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0567",
    unit: "LPM",
    min: 14,
    max: 19,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 27,
    process: "PT",
    stage: "Water Rinse 2",
    parameter: "Spray Top Pressure",
    source: "LIVE",
    tagId: null,
    unit: "Bar",
    min: 0.8,
    max: 1.0,
    minInclusive: true,
    maxInclusive: true,
    unmapped: true,
  },

  {
    id: 28,
    process: "PT",
    stage: "Water Rinse 2",
    parameter: "Spray Bottom Pressure",
    source: "LIVE",
    tagId: null,
    unit: "Bar",
    min: 0.7,
    max: 0.9,
    minInclusive: true,
    maxInclusive: true,
    unmapped: true,
  },

  {
    id: 29,
    process: "PT",
    stage: "Water Rinse 2",
    parameter: "Free Alkali",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a056a",
    unit: "Points",
    min: null,
    max: 2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 30,
    process: "PT",
    stage: "Activation",
    parameter: "Circulation Pressure - RH",
    source: "LIVE",
    tagId: "69a1805abe84d052e4e48e48",
    unit: "Bar",
    min: 0.8,
    max: 1.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 31,
    process: "PT",
    stage: "Activation",
    parameter: "Circulation Pressure - LH",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a056d",
    unit: "Bar",
    min: 0.8,
    max: 1.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 32,
    process: "PT",
    stage: "Activation",
    parameter: "Circulation Pressure - Bottom",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0570",
    unit: "Bar",
    min: 1.8,
    max: 2.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 33,
    process: "PT",
    stage: "Activation",
    parameter: "Exit Spray Flow",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0579",
    unit: "LPM",
    min: 160,
    max: 200,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 34,
    process: "PT",
    stage: "Activation",
    parameter: "Total Concentration",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0573",
    unit: "Points",
    min: 3.0,
    max: 3.9,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 35,
    process: "PT",
    stage: "Activation",
    parameter: "pH",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0576",
    unit: null,
    min: 9.0,
    max: 11.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 36,
    process: "PT",
    stage: "Phosphating",
    parameter: "Bath Temperature",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a057c",
    unit: "ºC",
    min: 40,
    max: 45,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 37,
    process: "PT",
    stage: "Phosphating",
    parameter: "Hot Water Circuit Temp.",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0594",
    unit: "ºC",
    min: null,
    max: 65,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 38,
    process: "PT",
    stage: "Phosphating",
    parameter: "Circulation Pressure - LH",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a057f",
    unit: "Bar",
    min: 1.0,
    max: 1.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 39,
    process: "PT",
    stage: "Phosphating",
    parameter: "Circulation Pressure - RH",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0582",
    unit: "Bar",
    min: 1.0,
    max: 1.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 40,
    process: "PT",
    stage: "Phosphating",
    parameter: "Circulation Pressure - LH Side",
    source: "LIVE",
    tagId: "6a7c688863f1464aebae7796",
    unit: "Bar",
    min: 1.0,
    max: 1.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 41,
    process: "PT",
    stage: "Phosphating",
    parameter: "Circulation Pressure Bottom 1",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0585",
    unit: "Bar",
    min: 1.2,
    max: 1.6,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 42,
    process: "PT",
    stage: "Phosphating",
    parameter: "Circulation Pressure Bottom 2",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a0588",
    unit: "Bar",
    min: 1.2,
    max: 1.6,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 43,
    process: "PT",
    stage: "Phosphating",
    parameter: "Circulation Pressure - Hopper",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a059a",
    unit: "Bar",
    min: 1.2,
    max: 1.6,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 44,
    process: "PT",
    stage: "Phosphating",
    parameter: "Heat Exchanger Pressure Loss",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a05a0",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 45,
    process: "PT",
    stage: "Phosphating",
    parameter: "Exit Spray Flow",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a059d",
    unit: "LPM",
    min: 160,
    max: 200,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 46,
    process: "PT",
    stage: "Phosphating",
    parameter: "Total Acidity",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a058b",
    unit: "Points",
    min: 22,
    max: 24,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 47,
    process: "PT",
    stage: "Phosphating",
    parameter: "Free Acidity",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a058e",
    unit: "Points",
    min: 0.7,
    max: 1.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 48,
    process: "PT",
    stage: "Phosphating",
    parameter: "Accelerator Content",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a0591",
    unit: "Points",
    min: 3.0,
    max: 4.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 49,
    process: "PT",
    stage: "Water Rinse 3",
    parameter: "Spray Top Pressure",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a05a6",
    unit: "Bar",
    min: 0.9,
    max: 1.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 50,
    process: "PT",
    stage: "Water Rinse 3",
    parameter: "Spray Bottom Pressure",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a05a9",
    unit: "Bar",
    min: 0.8,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 51,
    process: "PT",
    stage: "Water Rinse 3",
    parameter: "Total Acid",
    source: "MANUAL_LOG",
    // tagId: "699426acbfb07d6db09a05b5",
    tagId: "6a9e9e7fa4169be4f0f3df41",
    unit: "Points",
    min: null,
    max: 5,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 52,
    process: "PT",
    stage: "Water Rinse 4",
    parameter: "Spray Top Pressure",
    source: "LIVE",
    tagId: null,
    unit: "Bar",
    min: 0.9,
    max: 1.2,
    minInclusive: true,
    maxInclusive: true,
    unmapped: true,
  },

  {
    id: 53,
    process: "PT",
    stage: "Water Rinse 4",
    parameter: "Spray Bottom Pressure",
    source: "LIVE",
    tagId: null,
    unit: "Bar",
    min: 0.8,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
    unmapped: true,
  },

  {
    id: 54,
    process: "PT",
    stage: "Water Rinse 4",
    parameter: "Total Acid",
    source: "MANUAL_LOG",
    // tagId: "699426acbfb07d6db09a05b5",
    tagId: "6a9e9e7fa4169be4f0f3df42",
    unit: "Points",
    min: null,
    max: 2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 55,
    process: "PT",
    stage: "Water Rinse 5",
    parameter: "Conductivity",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a05c1",
    unit: "µs/cm",
    min: null,
    max: 30,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 56,
    process: "PT",
    stage: "Water Rinse 5",
    parameter: "Circulation Pressure - LH",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a05b8",
    unit: "Bar",
    min: 1.0,
    max: 1.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 57,
    process: "PT",
    stage: "Water Rinse 5",
    parameter: "Circulation Pressure - RH",
    source: "LIVE",
    tagId: "699426acbfb07d6db09a05bb",
    unit: "Bar",
    min: 1.0,
    max: 1.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 58,
    process: "PT",
    stage: "Water Rinse 5",
    parameter: "Circulation Pressure - Bottom",
    source: "LIVE",
    tagId: "6a7c688963f1464aebae7820",
    unit: "Bar",
    min: 1.0,
    max: 1.4,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 59,
    process: "PT",
    stage: "Water Rinse 5",
    parameter: "Exit Spray Flow",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a05be",
    unit: "LPM",
    min: 160,
    max: 200,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 60,
    process: "PT",
    stage: "DI Water Spray",
    parameter: "pH",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a05c4",
    unit: null,
    min: 6.0,
    max: 7.5,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 61,
    process: "PT",
    stage: "DI Water Spray",
    parameter: "Conductivity DI Water",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a05ca",
    unit: "µs/cm",
    min: null,
    max: 10,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 62,
    process: "PT",
    stage: "DI Water Spray",
    parameter: "DI Water Spray Flow",
    source: "MANUAL_LOG",
    tagId: "699426acbfb07d6db09a05cd",
    unit: "LPM",
    min: 110,
    max: 180,
    minInclusive: true,
    maxInclusive: true,
  },

  // ==========================================================
  // ED - ELECTRO DEPOSITION - 46 PARAMETERS
  // ==========================================================

  {
    id: 1,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Bath Level",
    source: "LIVE",
    tagId: "6a7c688963f1464aebae7898",
    unit: "Cms",
    min: 240,
    max: 300,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 2,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Bath Temperature",
    source: "LIVE",
    tagId: "699d79acefe574e9bb79f5d4",
    unit: "˚C",
    min: 30,
    max: 32,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 3,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - Bottom 1",
    source: "LIVE",
    tagId: "699d79afefe574e9bb7b4755",
    unit: "Bar",
    min: 1.6,
    max: 2.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 4,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - Bottom 2",
    source: "LIVE",
    tagId: "699d79b1efe574e9bb7c98d6",
    unit: "Bar",
    min: 1.6,
    max: 2.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 5,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - Bottom 3",
    source: "LIVE",
    tagId: "699d79b4efe574e9bb7dea57",
    unit: "Bar",
    min: 1.6,
    max: 2.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 6,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - Bottom 4",
    source: "LIVE",
    tagId: "699d79b6efe574e9bb7f3bd8",
    unit: "Bar",
    min: 1.6,
    max: 2.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 7,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - Inlet Wall",
    source: "LIVE",
    tagId: "699d79b9efe574e9bb808d59",
    unit: "Bar",
    min: 1.8,
    max: 2.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 8,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - Sub Tank",
    source: "LIVE",
    tagId: "699d79bbefe574e9bb81deda",
    unit: "Bar",
    min: 0.5,
    max: 0.9,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 9,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - RH",
    source: "LIVE",
    tagId: "699d79beefe574e9bb83305b",
    unit: "Bar",
    min: 0.8,
    max: 1.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 10,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Circulation Pressure - LH",
    source: "LIVE",
    tagId: "699d79c0efe574e9bb8481dc",
    unit: "Bar",
    min: 0.8,
    max: 1.2,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 11,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Paint Filter 1 ∆P",
    source: "LIVE",
    tagId: "699d79c5efe574e9bb8724de",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 12,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Paint Filter 2 ∆P",
    source: "LIVE",
    tagId: "699d79c7efe574e9bb88765f",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 13,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Heat Exchanger ∆P",
    source: "LIVE",
    tagId: "699d79caefe574e9bb89c7e0",
    unit: "Bar",
    min: null,
    max: 0.2,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 14,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Exit Spray Flow",
    source: "MANUAL_LOG",
    tagId: "69c27cb0553da24f12522f2e",
    unit: "LPM",
    min: 120,
    max: 140,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 15,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Solids Content",
    source: "MANUAL_LOG",
    tagId: "69c27c8a553da24f123e689f",
    unit: "%",
    min: 22,
    max: 24,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 16,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Ash Content",
    source: "MANUAL_LOG",
    tagId: "69c27c8d553da24f123fba20",
    unit: "%",
    min: 20,
    max: 24,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 17,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat pH",
    source: "MANUAL_LOG",
    tagId: "69c27c8f553da24f12410ba1",
    unit: null,
    min: 5.5,
    max: 6.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 18,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat Conductivity",
    source: "MANUAL_LOG",
    tagId: "69c27c92553da24f12425d22",
    unit: "µs/cm",
    min: 1200,
    max: 2400,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 19,
    process: "ED",
    stage: "E-Coat Bath",
    parameter: "E-Coat MEQ",
    source: "MANUAL_LOG",
    tagId: "69c27c94553da24f1243aea3",
    unit: "Mmol",
    min: 23,
    max: 31,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 20,
    process: "ED",
    stage: "Anolyte",
    parameter: "Anolyte Conductivity",
    source: "LIVE",
    tagId: "699d79cfefe574e9bb8c6ae2",
    unit: "µs/cm",
    min: 500,
    max: 1000,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 21,
    process: "ED",
    stage: "Anolyte",
    parameter: "Anolyte Flow Total",
    source: "LIVE",
    tagId: "69c27cc0553da24f125a1834",
    unit: "LPM",
    min: 60,
    max: 90,
    minInclusive: true,
    maxInclusive: true,
    acquisitionReview: true,
  },

  {
    id: 22,
    process: "ED",
    stage: "Anolyte",
    parameter: "Anolyte Flow Individual Cell",
    source: "LIVE",
    tagId: "69c27cc3553da24f125b69b5",
    unit: "LPM",
    min: 2.0,
    max: 3.0,
    minInclusive: true,
    maxInclusive: true,
    acquisitionReview: true,
  },

  {
    id: 23,
    process: "ED",
    stage: "UF System",
    parameter: "UF System Flux Rate",
    source: "LIVE",
    tagId: "69a0058fcc5780b526a18cf6",
    unit: "LPH",
    min: 1950,
    max: null,
    minInclusive: false,
    maxInclusive: true,
  },

  {
    id: 24,
    process: "ED",
    stage: "UF System",
    parameter: "UF System Inlet Pressure",
    source: "LIVE",
    tagId: "699d79d9efe574e9bb91b0e6",
    unit: "Bar",
    min: 3.3,
    max: 4.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 25,
    process: "ED",
    stage: "UF System",
    parameter: "UF System Back Pressure",
    source: "LIVE",
    tagId: "699d79dcefe574e9bb930267",
    unit: "Bar",
    min: 1.5,
    max: 1.8,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 26,
    process: "ED",
    stage: "UF System",
    parameter: "UF System Bag Filter ∆P",
    source: "LIVE",
    tagId: "699d79e2efe574e9bb95a569",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 27,
    process: "ED",
    stage: "UF System",
    parameter: "UF System Flux Rate Module (4 of 5)",
    source: "LIVE",
    tagId: "69c27d02553da24f127b0dcd",
    unit: "LPH",
    min: 500,
    max: null,
    minInclusive: false,
    maxInclusive: true,
  },

  {
    id: 28,
    process: "ED",
    stage: "UF System",
    parameter: "UF System Permeate Transfer Flow",
    source: "LIVE",
    tagId: "69c27cd0553da24f1260afb9",
    unit: "LPH",
    min: 7300,
    max: 7500,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 29,
    process: "ED",
    stage: "UF System",
    parameter: "UF System pH",
    source: "MANUAL_LOG",
    tagId: "69c27cc6553da24f125cbb36",
    unit: null,
    min: 5.2,
    max: 5.9,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 30,
    process: "ED",
    stage: "After DI Rinse",
    parameter: "DI Water Spray Flow",
    source: "MANUAL_LOG",
    tagId: "699d79ccefe574e9bb8b1961",
    unit: "LPH",
    min: 80,
    max: 120,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 31,
    process: "ED",
    stage: "RCID",
    parameter: "Spray Conductivity",
    source: "LIVE",
    tagId: "69a0058ccc5780b526a03b75",
    unit: "µs/Cm",
    min: null,
    max: 100,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 32,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "Spray Pressure - Bottom",
    source: "LIVE",
    tagId: "699d79eaefe574e9bb9999ec",
    unit: "Bar",
    min: 0.9,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 33,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "Spray Pressure - Side 1",
    source: "LIVE",
    tagId: "699d79edefe574e9bb9aeb6d",
    unit: "Bar",
    min: 0.9,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 34,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "Spray Pressure - Side 2",
    source: "LIVE",
    tagId: "699d79f0efe574e9bb9c3cee",
    unit: "Bar",
    min: 0.9,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 35,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "Spray Pressure - Side 3",
    source: "LIVE",
    tagId: "699d79f2efe574e9bb9d8e6f",
    unit: "Bar",
    min: 1.4,
    max: 1.6,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 36,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "Spray Pressure - Side 4",
    source: "LIVE",
    tagId: "699d79f5efe574e9bb9edff0",
    unit: "Bar",
    min: 0.9,
    max: 1.1,
    minInclusive: true,
    maxInclusive: true,
    scalingIssue: true,
  },

  {
    id: 37,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "Bag Filter ∆P",
    source: "LIVE",
    tagId: "699d79f7efe574e9bba03171",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 38,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "Solids Content",
    source: "MANUAL_LOG",
    tagId: "69c27cd4553da24f126352bb",
    unit: "%",
    min: null,
    max: 2.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 39,
    process: "ED",
    stage: "UF Rinse-1 (Spray)",
    parameter: "pH",
    source: "MANUAL_LOG",
    tagId: "69c27cd8553da24f1264a43c",
    unit: null,
    min: 5.2,
    max: 5.9,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 40,
    process: "ED",
    stage: "UF Rinse-2 (Dip)",
    parameter: "Circulation Pressure - Bottom 1",
    source: "LIVE",
    tagId: "699d79ffefe574e9bba425f4",
    unit: "Bar",
    min: 1.3,
    max: 1.7,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 41,
    process: "ED",
    stage: "UF Rinse-2 (Dip)",
    parameter: "Circulation Pressure - Bottom 2",
    source: "LIVE",
    tagId: "699d7a01efe574e9bba57775",
    unit: "Bar",
    min: 1.3,
    max: 1.7,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 42,
    process: "ED",
    stage: "UF Rinse-2 (Dip)",
    parameter: "Circulation Pressure - Bottom 3",
    source: "LIVE",
    tagId: "699d7a04efe574e9bba6c8f6",
    unit: "Bar",
    min: 1.3,
    max: 1.7,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 43,
    process: "ED",
    stage: "UF Rinse-2 (Dip)",
    parameter: "Bag Filter ∆P",
    source: "LIVE",
    tagId: "699d7a09efe574e9bba96bf8",
    unit: "Bar",
    min: null,
    max: 0.8,
    minInclusive: true,
    maxInclusive: false,
  },

  {
    id: 44,
    process: "ED",
    stage: "UF Rinse-2 (Dip)",
    parameter: "Solids Content",
    source: "MANUAL_LOG",
    tagId: "69c27ce9553da24f126ddec3",
    unit: "%",
    min: null,
    max: 2.0,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 45,
    process: "ED",
    stage: "UF Rinse-2 (Dip)",
    parameter: "pH",
    source: "MANUAL_LOG",
    tagId: "69c27ceb553da24f126f3044",
    unit: null,
    min: 5.2,
    max: 5.9,
    minInclusive: true,
    maxInclusive: true,
  },

  {
    id: 46,
    process: "ED",
    stage: "UF Rinse-2 (Dip)",
    parameter: "Exit Spray Flow",
    source: "MANUAL_LOG",
    tagId: "69c27cf5553da24f12747648",
    unit: "LPM",
    min: 120,
    max: 140,
    minInclusive: true,
    maxInclusive: true,
  },

  // ==========================================================
  // OVEN - 4 PARAMETERS
  // ==========================================================

  {
    id: 1,
    process: "OVEN",
    stage: "Oven Zones",
    parameter: "Preheat Zone",
    source: "LIVE",
    tagId: "699d7a0fefe574e9bbac0efa",
    unit: "˚C",
    min: null,
    max: null,
    pendingRange: true,
  },

  {
    id: 2,
    process: "OVEN",
    stage: "Oven Zones",
    parameter: "Heat Up Zone",
    source: "LIVE",
    tagId: "699d7a11efe574e9bbad607b",
    unit: "˚C",
    min: null,
    max: null,
    pendingRange: true,
  },

  {
    id: 3,
    process: "OVEN",
    stage: "Oven Zones",
    parameter: "Cooling Zone",
    source: "LIVE",
    tagId: "699d7a14efe574e9bbaeb1fc",
    unit: "˚C",
    min: null,
    max: null,
    pendingRange: true,
  },

  {
    id: 4,
    process: "OVEN",
    stage: "Oven Zones",
    parameter: "Air Seal Zone",
    source: "LIVE",
    tagId: "6a7c688a63f1464aebae7b99",
    unit: "˚C",
    min: null,
    max: null,
    pendingRange: true,
  },
];

// ============================================================
// HELPERS
// ============================================================

const normalizeTagId = (tagId) => {
  if (!tagId) return null;
  return String(tagId);
};

const getParameterByTagId = (tagId) => {
  const normalized = normalizeTagId(tagId);

  return TREND_PARAMETERS.find(
    (parameter) => normalizeTagId(parameter.tagId) === normalized,
  );
};

const getParametersByTagIds = (tagIds = []) => {
  const normalizedInputIds = tagIds
    .filter(Boolean)
    .map((id) => normalizeTagId(id));

  const ids = new Set(normalizedInputIds);

  const matchedParameters = TREND_PARAMETERS.filter((parameter) => {
    if (!parameter.tagId) {
      return false;
    }

    return ids.has(normalizeTagId(parameter.tagId));
  });

  console.log(
    "Matched parameter IDs:",
    matchedParameters.map((parameter) => ({
      tagId: parameter.tagId,
      parameter: parameter.parameter,
      source: parameter.source,
    })),
  );

  return matchedParameters;
};

// ------------------------------------------------------------
// OOS CHECK
// ------------------------------------------------------------

const isOutOfSpec = (value, parameter, temporaryRange = null) => {
  if (value === null || value === undefined || value === "") {
    return false;
  }

  const numericValue = Number(value);

  if (!Number.isFinite(numericValue)) {
    return false;
  }

  const min =
    temporaryRange?.min !== undefined ? temporaryRange.min : parameter.min;

  const max =
    temporaryRange?.max !== undefined ? temporaryRange.max : parameter.max;

  if (min === null && max === null) {
    return false;
  }

  if (min !== null && min !== undefined) {
    if (parameter.minInclusive === false) {
      if (numericValue <= Number(min)) {
        return true;
      }
    } else if (numericValue < Number(min)) {
      return true;
    }
  }

  if (max !== null && max !== undefined) {
    if (parameter.maxInclusive === false) {
      if (numericValue >= Number(max)) {
        return true;
      }
    } else if (numericValue > Number(max)) {
      return true;
    }
  }

  return false;
};

// ------------------------------------------------------------
// RANGE DISPLAY
// ------------------------------------------------------------

const getRangeDisplay = (parameter, temporaryRange = null) => {
  const min =
    temporaryRange?.min !== undefined ? temporaryRange.min : parameter.min;

  const max =
    temporaryRange?.max !== undefined ? temporaryRange.max : parameter.max;

  if (min === null && max === null) {
    return "Pending";
  }

  if (min === null) {
    return parameter.maxInclusive === false ? `< ${max}` : `≤ ${max}`;
  }

  if (max === null) {
    return parameter.minInclusive === false ? `> ${min}` : `≥ ${min}`;
  }

  return `${min} – ${max}`;
};

// ------------------------------------------------------------
// NORMALIZATION
//
// Only two-sided ranges can be normalized reliably using
// percentage of the parameter's own specification range.
//
// 0%  = lower limit
// 100% = upper limit
//
// One-sided specifications return null.
// ------------------------------------------------------------

const normalizeToSpecRange = (value, parameter, temporaryRange = null) => {
  if (value === null || value === undefined) {
    return null;
  }

  const min =
    temporaryRange?.min !== undefined ? temporaryRange.min : parameter.min;

  const max =
    temporaryRange?.max !== undefined ? temporaryRange.max : parameter.max;

  if (min === null || max === null || Number(max) === Number(min)) {
    return null;
  }

  const numericValue = Number(value);

  if (!Number.isFinite(numericValue)) {
    return null;
  }

  const percentage =
    ((numericValue - Number(min)) / (Number(max) - Number(min))) * 100;

  return Number(percentage.toFixed(2));
};

// ------------------------------------------------------------
// NUMBER PARSER
// ------------------------------------------------------------

const parseNumericValue = (value) => {
  if (value === null || value === undefined) {
    return null;
  }

  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }

  if (typeof value === "string") {
    const trimmed = value.trim();

    if (!trimmed) {
      return null;
    }

    const numericValue = Number(trimmed);

    return Number.isFinite(numericValue) ? numericValue : null;
  }

  return null;
};

// ------------------------------------------------------------
// BUCKET SUPPORT
//
// raw   -> existing behaviour (every LIVE record)
// hour / day / week / month -> LIVE data aggregated in MongoDB
//
// All bucketing is done in UTC (stored timestamps are UTC) so the
// result never depends on the Node.js server's local timezone.
// Weeks start on Monday (ISO convention).
// ------------------------------------------------------------

const VALID_BUCKETS = ["raw", "hour", "day", "week", "month"];

const normalizeBucket = (bucket) => {
  if (bucket === undefined || bucket === null || bucket === "") {
    return "raw"; // default keeps old API behaviour
  }

  const value = String(bucket).trim().toLowerCase();

  if (!VALID_BUCKETS.includes(value)) {
    throw new Error(
      `Invalid bucket "${bucket}". Allowed values: ${VALID_BUCKETS.join(", ")}`,
    );
  }

  return value;
};

// Builds a Mongo expression that is true when a single raw sample is OOS.
// Mirrors isOutOfSpec() exactly (same inclusive/exclusive rules and
// temporary range override), so OOS is judged per sample, not per average.
const buildOosExpression = (parameter, temporaryRange = null) => {
  const min =
    temporaryRange?.min !== undefined ? temporaryRange.min : parameter.min;

  const max =
    temporaryRange?.max !== undefined ? temporaryRange.max : parameter.max;

  const conditions = [];

  if (min !== null && min !== undefined) {
    conditions.push(
      parameter.minInclusive === false
        ? { $lte: ["$numericValue", Number(min)] }
        : { $lt: ["$numericValue", Number(min)] },
    );
  }

  if (max !== null && max !== undefined) {
    conditions.push(
      parameter.maxInclusive === false
        ? { $gte: ["$numericValue", Number(max)] }
        : { $gt: ["$numericValue", Number(max)] },
    );
  }

  // No limits (e.g. OVEN pendingRange) -> never OOS
  return conditions.length ? { $or: conditions } : false;
};

// ============================================================
// PARAMETER APIs
// ============================================================

// ------------------------------------------------------------
// GET TREND PARAMETERS
//
// Optional:
//   process=PT
//   stage=Degreasing Spray
//
// Returns process -> stage -> parameters
// ------------------------------------------------------------

const getTrendParameters = async ({ process = null, stage = null } = {}) => {
  let parameters = [...TREND_PARAMETERS];

  if (process) {
    parameters = parameters.filter(
      (item) => item.process.toUpperCase() === String(process).toUpperCase(),
    );
  }

  if (stage) {
    parameters = parameters.filter(
      (item) => item.stage.toLowerCase() === String(stage).toLowerCase(),
    );
  }

  const processes = {};

  for (const parameter of parameters) {
    if (!processes[parameter.process]) {
      processes[parameter.process] = {};
    }

    if (!processes[parameter.process][parameter.stage]) {
      processes[parameter.process][parameter.stage] = [];
    }

    processes[parameter.process][parameter.stage].push({
      ...parameter,
      range: getRangeDisplay(parameter),
    });
  }

  return {
    total: parameters.length,
    processes,
  };
};

// ------------------------------------------------------------
// GET PARAMETER MASTER
// ------------------------------------------------------------

const getTrendParameterMaster = async () => {
  // Get only LIVE parameters having a valid tagId
  const liveTagIds = TREND_PARAMETERS.filter(
    (parameter) =>
      parameter.tagId && mongoose.Types.ObjectId.isValid(parameter.tagId),
  ).map((parameter) => new mongoose.Types.ObjectId(parameter.tagId));

  // Fetch latest value and lastUpdated from TagLive
  const liveTags = await TagLive.find({
    _id: { $in: liveTagIds },
    isActive: true,
  })
    .select("_id latestValue lastUpdated")
    .lean();

  // Create tagId -> latestValue / lastUpdated map
  const liveTagMap = new Map(
    liveTags.map((tag) => [
      String(tag._id),
      {
        latestValue: parseNumericValue(tag.latestValue),
        lastUpdated: tag.lastUpdated || null,
      },
    ]),
  );

  // Add latestValue and lastUpdated to parameter master
  return TREND_PARAMETERS.map((parameter) => {
    const liveData = parameter.tagId
      ? liveTagMap.get(String(parameter.tagId))
      : null;

    return {
      ...parameter,
      range: getRangeDisplay(parameter),

      latestValue: liveData?.latestValue ?? null,
      lastUpdated: liveData?.lastUpdated ?? null,
    };
  });
};

// ============================================================
// LIVE DATA
// ============================================================

async function getTrendLiveData(tagIds = [], temporaryRanges = {}) {
  const normalizedIds = tagIds.map((id) => normalizeTagId(id)).filter(Boolean);

  if (!normalizedIds.length) {
    return [];
  }

  const parameters = getParametersByTagIds(normalizedIds);

  if (!parameters.length) {
    return [];
  }

  const objectIds = normalizedIds
    .filter((id) => mongoose.Types.ObjectId.isValid(id))
    .map((id) => new mongoose.Types.ObjectId(id));

  if (!objectIds.length) {
    return [];
  }

  const liveTags = await TagLive.find({
    _id: { $in: objectIds },
    isActive: true,
  }).lean();

  const liveTagMap = new Map(liveTags.map((tag) => [String(tag._id), tag]));

  return parameters
    .map((parameter) => {
      const tag = liveTagMap.get(String(parameter.tagId));

      if (!tag) {
        return null;
      }

      const value = parseNumericValue(tag.latestValue);

      const temporaryRange = temporaryRanges?.[parameter.tagId] || null;

      const outOfSpec =
        value === null ? null : isOutOfSpec(value, parameter, temporaryRange);

      const normalizedValue =
        value === null
          ? null
          : normalizeToSpecRange(value, parameter, temporaryRange);

      return {
        tagId: parameter.tagId,
        process: parameter.process,
        stage: parameter.stage,
        parameter: parameter.parameter,
        source: parameter.source,

        value,
        unit: parameter.unit || tag.unit || null,

        timestamp: tag.lastUpdated || tag.updatedAt || null,

        range: getRangeDisplay(parameter, temporaryRange),

        min: temporaryRange?.min ?? parameter.min,
        max: temporaryRange?.max ?? parameter.max,

        outOfSpec,
        normalizedValue,
      };
    })
    .filter(Boolean);
}

// ============================================================
// HISTORY
// ============================================================

// ------------------------------------------------------------
// LIVE HISTORY (RAW)
// ------------------------------------------------------------

async function getLiveHistory({ tagIds = [], startDate, endDate } = {}) {
  const normalizedIds = tagIds.map((id) => normalizeTagId(id)).filter(Boolean);

  const parameters = getParametersByTagIds(normalizedIds);

  if (!normalizedIds.length) {
    return [];
  }

  const objectIds = normalizedIds
    .filter((id) => mongoose.Types.ObjectId.isValid(id))
    .map((id) => new mongoose.Types.ObjectId(id));

  console.log(
    "ObjectIds:",
    objectIds.map((id) => id.toString()),
  );

  if (!objectIds.length) {
    return [];
  }

  const start = new Date(startDate);
  const end = new Date(endDate);

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    throw new Error("Invalid startDate or endDate");
  }

  const records = await TagHistory.find({
    tag_id: { $in: objectIds },
    timestamp: {
      $gte: start,
      $lte: end,
    },
  })
    .sort({ timestamp: 1 })
    .lean();

  if (records.length > 0) {
    console.log("First LIVE record:", records[0]);
    console.log("Last LIVE record:", records[records.length - 1]);
  }

  return records;
}

// ------------------------------------------------------------
// LIVE HISTORY - BUCKETED (MongoDB aggregation)
//
// One aggregation per parameter, so every parameter keeps its own
// spec range / OOS rule and parameters are never mixed in a bucket.
// ------------------------------------------------------------

async function getLiveHistoryBuckets({
  parameters = [],
  startDate,
  endDate,
  bucket,
  temporaryRanges = {},
} = {}) {
  if (!parameters.length) {
    return [];
  }

  const start = new Date(startDate);
  const end = new Date(endDate);

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    throw new Error("Invalid startDate or endDate");
  }

  const dateTrunc = {
    date: "$timestamp",
    unit: bucket,
    timezone: "UTC",
  };

  if (bucket === "week") {
    dateTrunc.startOfWeek = "monday";
  }

  const perParameter = await Promise.all(
    parameters.map(async (parameter) => {
      if (!mongoose.Types.ObjectId.isValid(parameter.tagId)) {
        return [];
      }

      const temporaryRange = temporaryRanges?.[parameter.tagId] || null;

      const rows = await TagHistory.aggregate(
        [
          {
            $match: {
              tag_id: new mongoose.Types.ObjectId(parameter.tagId),
              timestamp: { $gte: start, $lte: end },
            },
          },
          {
            // Same tolerance as parseNumericValue(): numeric strings are
            // accepted, anything non-numeric becomes null and is skipped.
            $addFields: {
              numericValue: {
                $convert: {
                  input: "$value",
                  to: "double",
                  onError: null,
                  onNull: null,
                },
              },
            },
          },
          { $match: { numericValue: { $ne: null } } },
          {
            $group: {
              _id: { $dateTrunc: dateTrunc },
              average: { $avg: "$numericValue" },
              min: { $min: "$numericValue" },
              max: { $max: "$numericValue" },
              sampleCount: { $sum: 1 },
              // OOS judged on each raw sample, NOT on the bucket average
              oosCount: {
                $sum: {
                  $cond: [buildOosExpression(parameter, temporaryRange), 1, 0],
                },
              },
            },
          },
          { $sort: { _id: 1 } },
        ],
        { allowDiskUse: true },
      );

      return rows.map((row) => ({
        tagId: normalizeTagId(parameter.tagId),
        bucketStart: row._id,
        average: row.average,
        min: row.min,
        max: row.max,
        sampleCount: row.sampleCount,
        oosCount: row.oosCount,
      }));
    }),
  );

  return perParameter.flat();
}

// ------------------------------------------------------------
// MANUAL LOG HISTORY
//
// The project log data uses:
//   fieldName
//   fieldValue
//   tagId
//   type = "logtotag"
//   isFilled
//   fieldEnteredAt
//
// We intentionally use the Mongo collection directly here so
// QID_167 does not depend on a specific LogEntry model path.
// ------------------------------------------------------------

// const getManualLogHistory = async ({ tagIds, startDate, endDate } = {}) => {
//   if (!tagIds.length) {
//     return [];
//   }

//   const db = mongoose.connection.db;

//   if (!db) {
//     throw new Error("MongoDB connection is not available");
//   }

//   const collection = db.collection("logentries");

//   return collection
//     .find({
//       tagId: {
//         $in: tagIds,
//       },
//       type: "logtotag",
//       isFilled: true,
//       fieldEnteredAt: {
//         $gte: startDate,
//         $lte: endDate,
//       },
//     })
//     .sort({
//       fieldEnteredAt: 1,
//     })
//     .project({
//       fieldName: 1,
//       fieldValue: 1,
//       tagId: 1,
//       fieldEnteredAt: 1,
//       _id: 1,
//     })
//     .toArray();
// };
const getManualLogHistory = async ({ tagIds, startDate, endDate } = {}) => {
  if (!tagIds?.length) {
    return [];
  }

  const db = mongoose.connection.db;

  if (!db) {
    throw new Error("MongoDB connection is not available");
  }

  const collection = db.collection("logentries");

  const start = new Date(startDate);
  const end = new Date(endDate);

  const records = await collection
    .find({
      data: {
        $elemMatch: {
          tagId: { $in: tagIds },
          type: "logtotag",
          isFilled: true,
          // fieldEnteredAt: {
          //   $gte: startDate,
          //   $lte: endDate,
          // },
          fieldEnteredAt: {
            $gte: start,
            $lte: end,
          },
        },
      },
    })
    .sort({ "data.fieldEnteredAt": 1 })
    .project({
      data: 1,
    })
    .toArray();

  const historyRecords = [];

  for (const record of records) {
    if (!Array.isArray(record.data)) {
      continue;
    }

    for (const field of record.data) {
      if (!tagIds.includes(String(field.tagId))) {
        continue;
      }

      if (field.type !== "logtotag") {
        continue;
      }

      if (field.isFilled !== true) {
        continue;
      }

      if (!field.fieldEnteredAt) {
        continue;
      }

      const enteredAt = new Date(field.fieldEnteredAt);

      if (enteredAt < start || enteredAt > end) {
        continue;
      }

      historyRecords.push({
        _id: field._id,
        fieldName: field.fieldName,
        fieldValue: field.fieldValue,
        tagId: String(field.tagId),
        fieldEnteredAt: enteredAt,
      });
    }
  }

  historyRecords.sort(
    (a, b) => new Date(a.fieldEnteredAt) - new Date(b.fieldEnteredAt),
  );

  if (historyRecords.length > 0) {
    console.log("First MANUAL LOG record:", historyRecords[0]);

    console.log(
      "Last MANUAL LOG record:",
      historyRecords[historyRecords.length - 1],
    );
  }

  return historyRecords;
};

// ------------------------------------------------------------
// FORMAT LIVE HISTORY
// ------------------------------------------------------------

const formatLiveHistory = (records, parameterMap, temporaryRanges) => {
  return records
    .map((record) => {
      const tagId = normalizeTagId(record.tag_id);

      const parameter = parameterMap.get(tagId);

      if (!parameter) {
        return null;
      }

      const value = parseNumericValue(record.value);

      if (value === null) {
        return null;
      }

      const temporaryRange = temporaryRanges?.[tagId] || null;

      const oos = isOutOfSpec(value, parameter, temporaryRange);

      return {
        parameterId: parameter.id,
        tagId: parameter.tagId,
        process: parameter.process,
        stage: parameter.stage,
        parameter: parameter.parameter,
        source: "LIVE",
        value,
        unit: parameter.unit,
        timestamp: record.timestamp,
        status: oos ? "OOS" : "IN_SPEC",
        outOfSpec: oos,
        normalizedValue: normalizeToSpecRange(value, parameter, temporaryRange),
      };
    })
    .filter(Boolean);
};

// ------------------------------------------------------------
// FORMAT MANUAL HISTORY
// ------------------------------------------------------------

const formatManualLogHistory = (records, parameterMap, temporaryRanges) => {
  return records
    .map((record) => {
      const tagId = normalizeTagId(record.tagId);

      const parameter = parameterMap.get(tagId);

      if (!parameter) {
        return null;
      }

      const value = parseNumericValue(record.fieldValue);

      if (value === null) {
        return null;
      }

      const temporaryRange = temporaryRanges?.[tagId] || null;

      const oos = isOutOfSpec(value, parameter, temporaryRange);

      return {
        parameterId: parameter.id,
        tagId: parameter.tagId,
        process: parameter.process,
        stage: parameter.stage,
        parameter: parameter.parameter,
        source: "MANUAL_LOG",
        value,
        unit: parameter.unit,
        timestamp: record.fieldEnteredAt,
        status: oos ? "OOS" : "IN_SPEC",
        outOfSpec: oos,
        normalizedValue: normalizeToSpecRange(value, parameter, temporaryRange),
      };
    })
    .filter(Boolean);
};

// ------------------------------------------------------------
// FORMAT LIVE BUCKETS
//
// Reuses normalizeToSpecRange() for normalizedAverage/Min/Max.
// `timestamp` = bucketStart so existing sorting / chart x-axis
// code keeps working.
// ------------------------------------------------------------

const formatLiveBucketHistory = (
  buckets,
  parameterMap,
  temporaryRanges,
  bucket,
) => {
  return buckets
    .map((row) => {
      const parameter = parameterMap.get(normalizeTagId(row.tagId));

      if (!parameter) {
        return null;
      }

      const temporaryRange = temporaryRanges?.[row.tagId] || null;

      const average = Number(row.average.toFixed(3));

      return {
        parameterId: parameter.id,
        tagId: parameter.tagId,
        process: parameter.process,
        stage: parameter.stage,
        parameter: parameter.parameter,
        source: "LIVE",
        bucket,
        bucketStart: row.bucketStart,
        timestamp: row.bucketStart,
        unit: parameter.unit,

        average,
        min: row.min,
        max: row.max,
        sampleCount: row.sampleCount,
        oosCount: row.oosCount,
        oosPercentage: Number(
          ((row.oosCount / row.sampleCount) * 100).toFixed(2),
        ),
        hasOOS: row.oosCount > 0,

        normalizedAverage: normalizeToSpecRange(
          average,
          parameter,
          temporaryRange,
        ),
        normalizedMin: normalizeToSpecRange(row.min, parameter, temporaryRange),
        normalizedMax: normalizeToSpecRange(row.max, parameter, temporaryRange),
      };
    })
    .filter(Boolean);
};

// ============================================================
// GET TREND HISTORY
//
// bucket (optional, default "raw"):
//   raw   -> every LIVE record (original behaviour)
//   hour | day | week | month -> LIVE data aggregated in MongoDB
//
// MANUAL_LOG is never bucketed - actual submissions are returned.
// ============================================================

const getTrendHistory = async (
  tagIds = [],
  startDate,
  endDate,
  temporaryRanges = {},
  bucket = "raw",
) => {
  if (!Array.isArray(tagIds) || tagIds.length === 0) {
    return [];
  }

  if (!startDate || !endDate) {
    throw new Error("startDate and endDate are required");
  }

  const bucketMode = normalizeBucket(bucket);

  const parameters = getParametersByTagIds(tagIds);

  if (!parameters.length) {
    return [];
  }

  const parameterMap = new Map(
    parameters.map((parameter) => [normalizeTagId(parameter.tagId), parameter]),
  );

  const liveParameters = parameters.filter(
    (parameter) => parameter.source === "LIVE",
  );

  const manualParameters = parameters.filter(
    (parameter) => parameter.source === "MANUAL_LOG",
  );

  const liveTagIds = liveParameters
    .map((parameter) => parameter.tagId)
    .filter(Boolean);

  const manualTagIds = manualParameters
    .map((parameter) => parameter.tagId)
    .filter(Boolean);

  console.log(
    "QID_167 DEBUG - parameters:",
    parameters.map((p) => ({
      tagId: p.tagId,
      parameter: p.parameter,
      source: p.source,
    })),
  );

  console.log(
    "QID_167 DEBUG - liveParameters:",
    liveParameters.map((p) => ({
      tagId: p.tagId,
      parameter: p.parameter,
      source: p.source,
    })),
  );

  console.log(
    "QID_167 DEBUG - manualParameters:",
    manualParameters.map((p) => ({
      tagId: p.tagId,
      parameter: p.parameter,
      source: p.source,
    })),
  );

  // MANUAL_LOG is never bucketed - always the actual submissions.
  const manualPromise = manualTagIds.length
    ? getManualLogHistory({
        tagIds: manualTagIds,
        startDate,
        endDate,
      })
    : [];

  let formattedLive = [];

  if (bucketMode === "raw") {
    // ---- existing behaviour, unchanged ----
    const liveRecords = liveTagIds.length
      ? await getLiveHistory({
          tagIds: liveTagIds,
          startDate,
          endDate,
        })
      : [];

    formattedLive = formatLiveHistory(
      liveRecords,
      parameterMap,
      temporaryRanges,
    );
  } else {
    // ---- bucketed LIVE (MongoDB aggregation) ----
    const liveBuckets = await getLiveHistoryBuckets({
      parameters: liveParameters.filter((p) => p.tagId),
      startDate,
      endDate,
      bucket: bucketMode,
      temporaryRanges,
    });

    formattedLive = formatLiveBucketHistory(
      liveBuckets,
      parameterMap,
      temporaryRanges,
      bucketMode,
    );
  }

  const manualRecords = await manualPromise;

  const formattedManual = formatManualLogHistory(
    manualRecords,
    parameterMap,
    temporaryRanges,
  );

  return [...formattedLive, ...formattedManual].sort(
    (a, b) => new Date(a.timestamp) - new Date(b.timestamp),
  );
};

// ============================================================
// SUMMARY / STATISTICS
// ============================================================

const calculateStatistics = (points = []) => {
  const numericPoints = points.filter(
    (point) => typeof point.value === "number" && Number.isFinite(point.value),
  );

  if (!numericPoints.length) {
    return {
      count: 0,
      average: null,
      min: null,
      max: null,
      outOfSpecCount: 0,
      outOfSpecPercentage: 0,
    };
  }

  const values = numericPoints.map((point) => point.value);

  const count = values.length;

  const sum = values.reduce((total, value) => total + value, 0);

  const average = sum / count;

  const min = Math.min(...values);
  const max = Math.max(...values);

  const outOfSpecCount = numericPoints.filter(
    (point) => point.outOfSpec === true,
  ).length;

  const outOfSpecPercentage = count > 0 ? (outOfSpecCount / count) * 100 : 0;

  return {
    count,
    average: Number(average.toFixed(3)),
    min,
    max,
    outOfSpecCount,
    outOfSpecPercentage: Number(outOfSpecPercentage.toFixed(2)),
  };
};

// ============================================================
// GET TREND SUMMARY
// ============================================================

const getTrendSummary = async ({
  tagIds = [],
  startDate,
  endDate,
  temporaryRanges = {},
} = {}) => {
  const history = await getTrendHistory(
    tagIds,
    startDate,
    endDate,
    temporaryRanges,
    "raw",
  );

  const grouped = {};

  for (const point of history) {
    const tagId = normalizeTagId(point.tagId);

    if (!grouped[tagId]) {
      grouped[tagId] = {
        parameterId: point.parameterId,
        tagId: point.tagId,
        process: point.process,
        stage: point.stage,
        parameter: point.parameter,
        source: point.source,
        unit: point.unit,
        points: [],
      };
    }

    grouped[tagId].points.push(point);
  }

  return Object.values(grouped).map((item) => ({
    parameterId: item.parameterId,
    tagId: item.tagId,
    process: item.process,
    stage: item.stage,
    parameter: item.parameter,
    source: item.source,
    unit: item.unit,
    statistics: calculateStatistics(item.points),
  }));
};
// ============================================================
// GET LATEST VALUE
//
// Useful for the parameter cards.
//
// For MANUAL_LOG, latest value is taken from the latest
// log submission rather than TagLive.
// ============================================================

const getLatestManualLogValues = async (tagIds = []) => {
  if (!tagIds.length) {
    return [];
  }

  const db = mongoose.connection.db;

  if (!db) {
    throw new Error("MongoDB connection is not available");
  }

  const collection = db.collection("logentries");

  const records = await collection
    .aggregate([
      {
        $match: {
          tagId: {
            $in: tagIds,
          },
          type: "logtotag",
          isFilled: true,
        },
      },

      {
        $sort: {
          fieldEnteredAt: -1,
        },
      },

      {
        $group: {
          _id: "$tagId",
          fieldName: {
            $first: "$fieldName",
          },
          fieldValue: {
            $first: "$fieldValue",
          },
          fieldEnteredAt: {
            $first: "$fieldEnteredAt",
          },
        },
      },
    ])
    .toArray();

  return records;
};

const getTrendLatestValues = async ({
  tagIds = [],
  temporaryRanges = {},
} = {}) => {
  if (!Array.isArray(tagIds) || !tagIds.length) {
    return [];
  }

  const parameters = getParametersByTagIds(tagIds);

  if (!parameters.length) {
    console.log("QID_167 HISTORY DEBUG: NO PARAMETER FOUND");
    return [];
  }

  const liveParameters = parameters.filter(
    (parameter) => parameter.source === "LIVE",
  );

  const manualParameters = parameters.filter(
    (parameter) => parameter.source === "MANUAL_LOG",
  );

  const liveTagIds = liveParameters
    .map((parameter) => parameter.tagId)
    .filter(Boolean);

  const manualTagIds = manualParameters
    .map((parameter) => parameter.tagId)
    .filter(Boolean);

  const [liveTags, manualLogs] = await Promise.all([
    liveTagIds.length
      ? TagLive.find({
          _id: {
            $in: liveTagIds,
          },
          isActive: true,
        }).lean()
      : [],

    manualTagIds.length ? getLatestManualLogValues(manualTagIds) : [],
  ]);

  const liveMap = new Map(
    liveTags.map((tag) => [normalizeTagId(tag._id), tag]),
  );

  const manualMap = new Map(
    manualLogs.map((log) => [normalizeTagId(log._id), log]),
  );

  return parameters.map((parameter) => {
    const tagId = normalizeTagId(parameter.tagId);

    let value = null;
    let timestamp = null;

    if (parameter.source === "LIVE") {
      const tag = liveMap.get(tagId);

      value = parseNumericValue(tag?.latestValue);

      timestamp = tag?.lastUpdated || null;
    } else {
      const log = manualMap.get(tagId);

      value = parseNumericValue(log?.fieldValue);

      timestamp = log?.fieldEnteredAt || null;
    }

    const temporaryRange = temporaryRanges?.[tagId] || null;

    const oos =
      value !== null ? isOutOfSpec(value, parameter, temporaryRange) : false;

    return {
      parameterId: parameter.id,
      tagId: parameter.tagId,
      process: parameter.process,
      stage: parameter.stage,
      parameter: parameter.parameter,
      source: parameter.source,
      value,
      unit: parameter.unit,
      timestamp,
      range: {
        min:
          temporaryRange?.min !== undefined
            ? temporaryRange.min
            : parameter.min,
        max:
          temporaryRange?.max !== undefined
            ? temporaryRange.max
            : parameter.max,
      },
      rangeDisplay: getRangeDisplay(parameter, temporaryRange),
      status: value === null ? "NO_DATA" : oos ? "OOS" : "IN_SPEC",
      outOfSpec: oos,
      normalizedValue:
        value !== null
          ? normalizeToSpecRange(value, parameter, temporaryRange)
          : null,
    };
  });
};

// ============================================================
// VALIDATE PARAMETER SELECTION
//
// Requirement:
//   Maximum 6 parameters can be selected.
// ============================================================

const validateParameterSelection = (tagIds = []) => {
  if (!Array.isArray(tagIds)) {
    throw new Error("tagIds must be an array");
  }

  const uniqueTagIds = [...new Set(tagIds.filter(Boolean).map(normalizeTagId))];

  if (uniqueTagIds.length > 6) {
    throw new Error("Maximum 6 parameters can be selected for trend analysis");
  }

  const parameters = getParametersByTagIds(uniqueTagIds);

  const foundIds = new Set(
    parameters.map((parameter) => normalizeTagId(parameter.tagId)),
  );

  const invalidIds = uniqueTagIds.filter((tagId) => !foundIds.has(tagId));

  return {
    valid: invalidIds.length === 0,
    tagIds: uniqueTagIds,
    parameters,
    invalidIds,
  };
};

// ============================================================
// EXPORTS
// ============================================================

module.exports = {
  TREND_PARAMETERS,

  // Parameter master
  getTrendParameters,
  getTrendParameterMaster,

  // Current/live data
  getTrendLiveData,
  getTrendLatestValues,

  // Historical data
  getTrendHistory,

  // Statistics
  getTrendSummary,
  calculateStatistics,

  // Validation
  validateParameterSelection,

  // Helpers
  getParameterByTagId,
  getParametersByTagIds,
  isOutOfSpec,
  getRangeDisplay,
  normalizeToSpecRange,
};
