/**
 * analyticsOccurrenceCron.js
 *
 * Incrementally materialises vehicle stage occurrences from historical
 * TagHistory data.
 *
 * Runs periodically (recommended: every 15 minutes).
 *
 * Strategy:
 *  - Read the last successful processing checkpoint.
 *  - Re-process an overlap window before that checkpoint.
 *  - Stop a few minutes before "now" so data has time to settle.
 *  - Rebuild occurrences for the affected window.
 *  - Stitch an occurrence that started before the processing window.
 *  - Update checkpoint only after all assets succeed.
 */

const mongoose = require("mongoose");

const {
  LINE_ASSETS,
  buildOccurrencesRange,
} = require("./analyticsOccurrence.service");

const VehicleStageOccurrence = require("../../../models/mongoDB/analyticsManagement/vehicleStageOccurrence_model");

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const CHECKPOINT_KEY = "analyticsOccurrence";

const OVERLAP_MS = 30 * 60 * 1000; // 30 minutes
const SAFETY_DELAY_MS = 5 * 60 * 1000; // 5 minutes

const MAX_GAP_MS = 60 * 1000;

const CHECKPOINT_COLLECTION = "analytics_cron_checkpoints";

// ---------------------------------------------------------------------------
// Checkpoint helpers
// ---------------------------------------------------------------------------

async function getCheckpoint() {
  const db = mongoose.connection.db;

  const document = await db.collection(CHECKPOINT_COLLECTION).findOne({
    jobName: CHECKPOINT_KEY,
  });

  return document?.lastProcessedAt ? new Date(document.lastProcessedAt) : null;
}

async function saveCheckpoint(timestamp) {
  const db = mongoose.connection.db;

  await db.collection(CHECKPOINT_COLLECTION).updateOne(
    {
      jobName: CHECKPOINT_KEY,
    },
    {
      $set: {
        jobName: CHECKPOINT_KEY,
        lastProcessedAt: new Date(timestamp),
        updatedAt: new Date(),
      },
      $setOnInsert: {
        createdAt: new Date(),
      },
    },
    {
      upsert: true,
    },
  );
}

// ---------------------------------------------------------------------------
// Occurrence helpers
// ---------------------------------------------------------------------------

function sameVehicle(a, b) {
  return (
    String(a.cabinNumber) === String(b.cabinNumber) &&
    Number(a.skid) === Number(b.skid)
  );
}

function canStitch(previous, next) {
  if (!previous || !next) return false;

  if (!sameVehicle(previous, next)) return false;

  const gap =
    new Date(next.entryTime).getTime() - new Date(previous.exitTime).getTime();

  return gap >= 0 && gap <= MAX_GAP_MS;
}

function mergeOccurrences(previous, next) {
  const entryTime = new Date(previous.entryTime);
  const exitTime = new Date(next.exitTime);

  return {
    ...previous,
    exitTime,
    dwellSeconds: Math.round((exitTime.getTime() - entryTime.getTime()) / 1000),
    samples: Number(previous.samples || 0) + Number(next.samples || 0),
    isOpen: Boolean(next.isOpen),
    hanger: previous.hanger || next.hanger || "",
    type: previous.type || next.type || "",
    colour: previous.colour || next.colour || "",
  };
}

// ---------------------------------------------------------------------------
// Process one asset
// ---------------------------------------------------------------------------

async function processAsset(assetConfig, from, to) {
  const { assetNumber, stageIds } = assetConfig;

  /*
   * Build occurrences for the complete overlap window.
   */
  const { resolved, segments } = await buildOccurrencesRange(
    assetNumber,
    from,
    to,
  );

  /*
   * Find occurrences that overlap the processing window.
   *
   * This is broader than:
   *
   *   entryTime >= from
   *
   * because an occurrence may have started BEFORE `from` and continued
   * into the window.
   */
  const affectedExisting = await VehicleStageOccurrence.find({
    assetNumber,
    $or: [
      {
        entryTime: {
          $gte: from,
          $lte: to,
        },
      },
      {
        entryTime: { $lt: from },
        exitTime: { $gte: from },
      },
    ],
  })
    .sort({ entryTime: 1 })
    .lean();

  /*
   * Remove all affected occurrences.
   *
   * We rebuild them from TagHistory below.
   */
  if (affectedExisting.length) {
    await VehicleStageOccurrence.deleteMany({
      _id: {
        $in: affectedExisting.map((item) => item._id),
      },
    });
  }

  let inserted = 0;
  let merged = 0;

  /*
   * If an occurrence started before `from`, keep it available so the newly
   * generated first segment can be stitched back to it.
   *
   * Normally this should already have been removed above, so we preserve
   * its information in memory.
   */
  const previousOutsideWindow = affectedExisting
    .filter((item) => new Date(item.entryTime).getTime() < from.getTime())
    .sort(
      (a, b) => new Date(a.exitTime).getTime() - new Date(b.exitTime).getTime(),
    );

  /*
   * Process generated segments.
   */
  for (const segment of segments) {
    const document = {
      assetId: resolved.asset._id,
      assetNumber,
      assetName: resolved.asset.generalDetails?.name || "",
      stageIds,
      ...segment,
    };

    /*
     * Check whether this segment continues an occurrence that started
     * before the processing window.
     */
    const previous = previousOutsideWindow
      .filter((item) => sameVehicle(item, segment))
      .sort(
        (a, b) =>
          new Date(b.exitTime).getTime() - new Date(a.exitTime).getTime(),
      )[0];

    if (previous && canStitch(previous, segment)) {
      const mergedOccurrence = mergeOccurrences(previous, document);

      await VehicleStageOccurrence.create({
        ...mergedOccurrence,
        _id: undefined,
      });

      /*
       * Mark this previous occurrence as consumed so that another segment
       * cannot merge into it accidentally.
       */
      previousOutsideWindow.splice(previousOutsideWindow.indexOf(previous), 1);

      merged += 1;
      continue;
    }

    await VehicleStageOccurrence.create(document);
    inserted += 1;
  }

  /*
   * If an affected occurrence existed before the processing window but
   * there was no matching generated segment, restore it.
   *
   * This protects data if the current TagHistory window does not contain
   * enough information to rebuild that older occurrence.
   */
  if (previousOutsideWindow.length) {
    await VehicleStageOccurrence.insertMany(
      previousOutsideWindow.map((item) => {
        const { _id, ...document } = item;
        return document;
      }),
    );
  }

  return {
    assetNumber,
    stageIds,
    generated: segments.length,
    inserted,
    merged,
    restored: previousOutsideWindow.length,
  };
}

// ---------------------------------------------------------------------------
// Main cron job
// ---------------------------------------------------------------------------

async function runAnalyticsOccurrence() {
  const now = new Date();

  /*
   * Don't process the newest few minutes because PLC data may still
   * be arriving.
   */
  const processingTo = new Date(now.getTime() - SAFETY_DELAY_MS);

  const lastProcessedAt = await getCheckpoint();

  /*
   * First run:
   *
   * Do NOT automatically process the entire production database.
   * Historical data must be populated using backfillStageOccurrences.js.
   *
   * We only create the checkpoint here if it doesn't exist.
   */
  if (!lastProcessedAt) {
    await saveCheckpoint(processingTo);

    console.log(
      `Analytics occurrence cron: initial checkpoint created at ${processingTo.toISOString()}`,
    );

    return;
  }

  if (lastProcessedAt >= processingTo) {
    console.log("Analytics occurrence cron: no new data to process");

    return;
  }

  /*
   * Re-process an overlap period.
   *
   * Example:
   *
   * checkpoint = 10:00
   * overlap    = 30 minutes
   *
   * processingFrom = 09:30
   */
  const processingFrom = new Date(lastProcessedAt.getTime() - OVERLAP_MS);

  console.log("Analytics occurrence cron started:", {
    from: processingFrom.toISOString(),
    to: processingTo.toISOString(),
    lastProcessedAt: lastProcessedAt.toISOString(),
  });

  const summary = [];

  try {
    for (const asset of LINE_ASSETS) {
      const result = await processAsset(asset, processingFrom, processingTo);

      summary.push(result);

      console.log(
        `Analytics occurrence: #${asset.assetNumber} ` +
          `generated=${result.generated} ` +
          `inserted=${result.inserted} ` +
          `merged=${result.merged} ` +
          `restored=${result.restored}`,
      );
    }

    /*
     * IMPORTANT:
     *
     * Only update the checkpoint after every asset succeeds.
     */
    await saveCheckpoint(processingTo);

    const totalGenerated = summary.reduce(
      (total, item) => total + item.generated,
      0,
    );

    const totalInserted = summary.reduce(
      (total, item) => total + item.inserted,
      0,
    );

    const totalMerged = summary.reduce((total, item) => total + item.merged, 0);

    const totalRestored = summary.reduce(
      (total, item) => total + item.restored,
      0,
    );

    console.log("Analytics occurrence cron completed:", {
      from: processingFrom.toISOString(),
      to: processingTo.toISOString(),
      assets: summary.length,
      generated: totalGenerated,
      inserted: totalInserted,
      merged: totalMerged,
      restored: totalRestored,
    });

    return {
      from: processingFrom,
      to: processingTo,
      summary,
      totalGenerated,
      totalInserted,
      totalMerged,
      totalRestored,
    };
  } catch (error) {
    /*
     * IMPORTANT:
     *
     * Do NOT update the checkpoint if any asset fails.
     * The next cron run will retry this period.
     */
    console.error("Analytics occurrence cron failed:", error.message);

    throw error;
  }
}

module.exports = {
  runAnalyticsOccurrence,
};
