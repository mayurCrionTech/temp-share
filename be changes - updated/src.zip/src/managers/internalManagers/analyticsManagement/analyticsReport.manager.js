/**
 * analyticsReport.manager.js
 *
 * Historical Analytics report data manager.
 *
 * Uses:
 * - vehicle_stage_occurrences
 * - analytics_stage_tag_master
 *
 * This manager prepares the data used by:
 * - Correlation report
 * - Process report
 *
 * Excel generation can be added at the controller/report layer.
 */

// const ExcelJS = require("exceljs");
const VehicleStageOccurrence = require("../../../models/mongoDB/analyticsManagement/vehicleStageOccurrence_model");
const AnalyticsStageTagMaster = require("../../../models/mongoDB/analyticsManagement/analyticsStageTagMaster_model");
const { computeStageReadings } = require("./analytics.manager");

const getStageMaster = async (stageId) => {
  return AnalyticsStageTagMaster.findOne({ stageId }).lean();
};

const escapeCsvValue = (value) => {
  if (value === null || value === undefined) {
    return "";
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  const stringValue = String(value);

  if (
    stringValue.includes(",") ||
    stringValue.includes('"') ||
    stringValue.includes("\n") ||
    stringValue.includes("\r")
  ) {
    return `"${stringValue.replace(/"/g, '""')}"`;
  }

  return stringValue;
};

const rowsToCsv = (rows) => {
  return rows.map((row) => row.map(escapeCsvValue).join(",")).join("\r\n");
};

/**
 * ---------------------------------------------------------
 * Get vehicle occurrences
 * ---------------------------------------------------------
 */

const getVehicleOccurrences = async ({ cabinNumber, skid }) => {
  const query = {};

  if (cabinNumber) {
    query.cabinNumber = String(cabinNumber);
  }

  if (skid !== undefined && skid !== null && skid !== "") {
    query.skid = Number(skid);
  }

  return VehicleStageOccurrence.find(query).sort({ entryTime: 1 }).lean();
};

/**
 * ---------------------------------------------------------
 * Expand shared assets
 *
 * Example:
 *
 * occurrence:
 * {
 *   assetNumber: "40203",
 *   stageIds: ["PT-3", "PT-4"]
 * }
 *
 * becomes:
 *
 * PT-3
 * PT-4
 * ---------------------------------------------------------
 */

const expandOccurrenceStages = (occurrence) => {
  const stageIds = Array.isArray(occurrence.stageIds)
    ? occurrence.stageIds
    : [];

  return stageIds.map((stageId) => ({
    occurrence,
    stageId,
  }));
};

/**
 * ---------------------------------------------------------
 * PROCESS REPORT
 * ---------------------------------------------------------
 *
 * Returns vehicle journey with one row per logical stage.
 */

const generateProcessReport = async ({ cabinNumber, skid }) => {
  if (!cabinNumber && skid === undefined) {
    const error = new Error("cabinNumber or skid is required");

    error.status = 400;
    throw error;
  }

  const occurrences = await getVehicleOccurrences({
    cabinNumber,
    skid,
  });

  if (!occurrences.length) {
    return null;
  }

  const first = occurrences[0];

  const vehicle = {
    cabinNumber: first.cabinNumber,
    skid: first.skid,
    hanger: first.hanger,
    type: first.type,
    colour: first.colour,

    firstEntry: occurrences.reduce((min, occurrence) => {
      const entryTime = new Date(occurrence.entryTime);

      return entryTime < new Date(min) ? occurrence.entryTime : min;
    }, occurrences[0].entryTime),

    lastExit: occurrences.reduce((max, occurrence) => {
      const exitTime = new Date(occurrence.exitTime);

      return exitTime > new Date(max) ? occurrence.exitTime : max;
    }, occurrences[0].exitTime),
  };

  /**
   * Expand shared assets into logical stages.
   */
  const expandedStages = [];

  for (const occurrence of occurrences) {
    const stages = expandOccurrenceStages(occurrence);

    for (const { stageId } of stages) {
      const stageMaster = await getStageMaster(stageId);

      expandedStages.push({
        stageId,

        stageName: stageMaster?.name || null,

        line: stageMaster?.line || null,

        order: stageMaster?.order ?? null,

        entryTime: occurrence.entryTime,

        exitTime: occurrence.exitTime,

        dwellSeconds: occurrence.dwellSeconds ?? 0,

        status: "recorded",

        isManualInspection: stageMaster?.isManualInspection || false,

        assetId: occurrence.assetId,

        assetNumber: occurrence.assetNumber,

        assetName: occurrence.assetName,

        samples: occurrence.samples,

        isOpen: occurrence.isOpen,
      });
    }
  }

  /**
   * Sort using the stage master's logical order.
   *
   * PT stages come first, followed by ED.
   */
  expandedStages.sort((a, b) => {
    if (a.line !== b.line) {
      if (a.line === "PT") return -1;
      if (b.line === "PT") return 1;
    }

    return (a.order ?? 999) - (b.order ?? 999);
  });

  return {
    vehicle,

    totalStages: expandedStages.length,

    stages: expandedStages,
  };
};

/**
 * ---------------------------------------------------------
 * CORRELATION REPORT
 * ---------------------------------------------------------
 *
 * Historical vehicle search + stage information.
 *
 * The report groups occurrences by vehicle pass and expands
 * shared assets into individual logical stages.
 *
 * Tag-level correlation data can be added on top of this
 * structure once the exact Excel format is finalized.
 */

const generateCorrelationReport = async ({ searchBy, value, from, to }) => {
  const validSearchBy = ["hanger", "skid", "cabin"];

  if (!validSearchBy.includes(searchBy)) {
    const error = new Error("searchBy must be hanger, skid or cabin");

    error.status = 400;
    throw error;
  }

  if (!value) {
    const error = new Error("Search value is required");

    error.status = 400;
    throw error;
  }

  if (!from || !to) {
    const error = new Error("from and to dates are required");

    error.status = 400;
    throw error;
  }

  const query = {};

  // if (searchBy === "cabin") {
  //   query.cabinNumber = String(value);
  // }

  // if (searchBy === "skid") {
  //   query.skid = Number(value);
  // }

  // if (searchBy === "hanger") {
  //   query.hanger = String(value);
  // }

  if (searchBy === "cabin") {
    query.cabinNumber = {
      $regex: `^${String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`,
      $options: "i",
    };
  }

  if (searchBy === "skid") {
    query.skid = Number(value);
  }

  if (searchBy === "hanger") {
    query.hanger = {
      $regex: `^${String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`,
      $options: "i",
    };
  }

  query.entryTime = {
    $gte: new Date(from),
    $lte: new Date(to),
  };

  const occurrences = await VehicleStageOccurrence.find(query)
    .sort({ entryTime: 1 })
    .lean();

  if (!occurrences.length) {
    return {
      searchBy,
      value,
      from,
      to,
      totalVehicles: 0,
      vehicles: [],
    };
  }

  /**
   * Group occurrences by vehicle pass.
   *
   * A pass is identified using:
   * cabinNumber + skid
   */
  const vehicleMap = new Map();

  for (const occurrence of occurrences) {
    const passKey = `${occurrence.cabinNumber}|${occurrence.skid}`;

    if (!vehicleMap.has(passKey)) {
      vehicleMap.set(passKey, {
        passKey,

        cabinNumber: occurrence.cabinNumber,

        skid: occurrence.skid,

        hanger: occurrence.hanger,

        type: occurrence.type,

        colour: occurrence.colour,

        firstEntry: occurrence.entryTime,

        lastExit: occurrence.exitTime,

        stages: [],
      });
    }

    const vehicle = vehicleMap.get(passKey);

    /**
     * Update vehicle boundaries.
     */
    if (new Date(occurrence.entryTime) < new Date(vehicle.firstEntry)) {
      vehicle.firstEntry = occurrence.entryTime;
    }

    if (new Date(occurrence.exitTime) > new Date(vehicle.lastExit)) {
      vehicle.lastExit = occurrence.exitTime;
    }

    /**
     * Expand shared asset.
     */
    const stageIds = Array.isArray(occurrence.stageIds)
      ? occurrence.stageIds
      : [];

    for (const stageId of stageIds) {
      const stageMaster = await getStageMaster(stageId);

      vehicle.stages.push({
        stageId,

        stageName: stageMaster?.name || null,

        line: stageMaster?.line || null,

        order: stageMaster?.order ?? null,

        entryTime: occurrence.entryTime,

        exitTime: occurrence.exitTime,

        dwellSeconds: occurrence.dwellSeconds ?? 0,

        status: "recorded",

        isManualInspection: stageMaster?.isManualInspection || false,

        assetNumber: occurrence.assetNumber,

        assetName: occurrence.assetName,

        samples: occurrence.samples,

        isOpen: occurrence.isOpen,
      });
    }
  }

  /**
   * Sort stages according to PT/ED logical stage order.
   */
  for (const vehicle of vehicleMap.values()) {
    vehicle.stages.sort((a, b) => {
      if (a.line !== b.line) {
        if (a.line === "PT") return -1;
        if (b.line === "PT") return 1;
      }

      return (a.order ?? 999) - (b.order ?? 999);
    });
  }

  return {
    searchBy,

    value,

    from,

    to,

    totalVehicles: vehicleMap.size,

    vehicles: Array.from(vehicleMap.values()),
  };
};

const generateProcessCsvReport = async ({ cabinNumber, skid }) => {
  const reportData = await generateProcessReport({
    cabinNumber,
    skid,
  });

  if (!reportData) {
    return null;
  }

  const rows = [];

  // Title
  rows.push(["Vehicle Process Report"]);
  rows.push([]);

  // Vehicle information
  rows.push(["Cabin Number", reportData.vehicle.cabinNumber]);

  rows.push(["Skid", reportData.vehicle.skid]);

  rows.push(["Hanger", reportData.vehicle.hanger]);

  rows.push(["Type", reportData.vehicle.type]);

  rows.push(["Colour", reportData.vehicle.colour]);

  rows.push(["First Entry", reportData.vehicle.firstEntry]);

  rows.push(["Last Exit", reportData.vehicle.lastExit]);

  rows.push([]);

  // Stage table
  rows.push([
    "Stage ID",
    "Stage Name",
    "Line",
    "Order",
    "Entry Time",
    "Exit Time",
    "Dwell (Seconds)",
    "Status",
    "Manual Inspection",
    "Asset Number",
    "Asset Name",
    "Samples",
    "Open",
  ]);

  for (const stage of reportData.stages) {
    rows.push([
      stage.stageId,
      stage.stageName,
      stage.line,
      stage.order,
      stage.entryTime,
      stage.exitTime,
      stage.dwellSeconds,
      stage.status,
      stage.isManualInspection ? "Yes" : "No",
      stage.assetNumber,
      stage.assetName,
      stage.samples,
      stage.isOpen ? "Yes" : "No",
    ]);
  }

  return rowsToCsv(rows);
};

const generateCorrelationCsvReport = async ({ searchBy, value, from, to }) => {
  const reportData = await generateCorrelationReport({
    searchBy,
    value,
    from,
    to,
  });

  if (!reportData || !reportData.vehicles?.length) {
    return null;
  }

  const rows = [];

  // Report information
  rows.push(["Historical Correlation Report"]);

  rows.push([]);

  rows.push(["Search By", searchBy]);

  rows.push(["Search Value", value]);

  rows.push(["From", from]);

  rows.push(["To", to]);

  rows.push([]);

  // Header
  rows.push([
    "Cabin Number",
    "Skid",
    "Hanger",
    "Type",
    "Colour",
    "Stage ID",
    "Stage Name",
    "Line",
    "Stage Order",
    "Entry Time",
    "Exit Time",
    "Dwell (Seconds)",
    "Parameter",
    "Source",
    "Reference Range",
    "Value",
    "Min",
    "Max",
    "Average",
    "Samples",
    "Status",
    "Reason",
  ]);

  // for (const vehicle of reportData.vehicles) {
  //   for (const stage of vehicle.stages) {

  //     // Manual inspection stages
  //     if (stage.isManualInspection) {
  //       rows.push([
  //         vehicle.cabinNumber,
  //         vehicle.skid,
  //         vehicle.hanger,
  //         vehicle.type,
  //         vehicle.colour,

  //         stage.stageId,
  //         stage.stageName,
  //         stage.line,
  //         stage.order,

  //         stage.entryTime,
  //         stage.exitTime,
  //         stage.dwellSeconds,

  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",

  //         "manual",
  //         "Manual inspection stage",
  //       ]);

  //       continue;
  //     }

  //     // Get stage master
  //     const stageMaster = await getStageMaster(stage.stageId);

  //     if (!stageMaster) {
  //       rows.push([
  //         vehicle.cabinNumber,
  //         vehicle.skid,
  //         vehicle.hanger,
  //         vehicle.type,
  //         vehicle.colour,

  //         stage.stageId,
  //         stage.stageName,
  //         stage.line,
  //         stage.order,

  //         stage.entryTime,
  //         stage.exitTime,
  //         stage.dwellSeconds,

  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",

  //         "no_data",
  //         "Stage master not found",
  //       ]);

  //       continue;
  //     }

  //     // Get exact stage readings
  //     const readings = await computeStageReadings(
  //       stageMaster,
  //       {
  //         entryTime: stage.entryTime,
  //         exitTime: stage.exitTime,
  //         dwellSeconds: stage.dwellSeconds,
  //       },
  //     );

  //     // No tags
  //     if (!readings.tags?.length) {
  //       rows.push([
  //         vehicle.cabinNumber,
  //         vehicle.skid,
  //         vehicle.hanger,
  //         vehicle.type,
  //         vehicle.colour,

  //         stage.stageId,
  //         stage.stageName,
  //         stage.line,
  //         stage.order,

  //         stage.entryTime,
  //         stage.exitTime,
  //         stage.dwellSeconds,

  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",
  //         "",

  //         readings.status || "no_data",
  //         "",
  //       ]);

  //       continue;
  //     }

  //     // One row per tag
  //     for (const tag of readings.tags) {
  //       rows.push([
  //         vehicle.cabinNumber,
  //         vehicle.skid,
  //         vehicle.hanger,
  //         vehicle.type,
  //         vehicle.colour,

  //         stage.stageId,
  //         stage.stageName,
  //         stage.line,
  //         stage.order,

  //         stage.entryTime,
  //         stage.exitTime,
  //         stage.dwellSeconds,

  //         tag.name,
  //         tag.source,
  //         tag.rangeRaw,

  //         tag.value ?? "",
  //         tag.min ?? "",
  //         tag.max ?? "",
  //         tag.avg ?? "",
  //         tag.samples ?? "",

  //         tag.status ?? "",
  //         tag.reason ?? "",
  //       ]);
  //     }
  //   }
  // }

  // return rowsToCsv(rows);

  for (const vehicle of reportData.vehicles) {
    for (const stage of vehicle.stages) {
      // Preserve manual inspection stages.
      if (stage.isManualInspection) {
        rows.push([
          vehicle.cabinNumber,
          vehicle.skid,
          vehicle.hanger,
          vehicle.type,
          vehicle.colour,
          stage.stageId,
          stage.stageName,
          stage.line,
          stage.order,
          stage.entryTime,
          stage.exitTime,
          stage.dwellSeconds,
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "manual",
          "Manual inspection stage",
        ]);
        continue;
      }

      try {
        const stageMaster = await getStageMaster(stage.stageId);

        if (!stageMaster) {
          rows.push([
            vehicle.cabinNumber,
            vehicle.skid,
            vehicle.hanger,
            vehicle.type,
            vehicle.colour,
            stage.stageId,
            stage.stageName,
            stage.line,
            stage.order,
            stage.entryTime,
            stage.exitTime,
            stage.dwellSeconds,
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "no_data",
            "Stage master not found",
          ]);
          continue;
        }

        const readings = await computeStageReadings(stageMaster, {
          entryTime: stage.entryTime,
          exitTime: stage.exitTime,
          dwellSeconds: stage.dwellSeconds,
        });

        // Keep the stage even when no tag readings exist.
        if (!readings?.tags?.length) {
          rows.push([
            vehicle.cabinNumber,
            vehicle.skid,
            vehicle.hanger,
            vehicle.type,
            vehicle.colour,
            stage.stageId,
            stage.stageName,
            stage.line,
            stage.order,
            stage.entryTime,
            stage.exitTime,
            stage.dwellSeconds,
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            readings?.status || "no_data",
            "",
          ]);
          continue;
        }

        // Export every available tag reading.
        for (const tag of readings.tags) {
          rows.push([
            vehicle.cabinNumber,
            vehicle.skid,
            vehicle.hanger,
            vehicle.type,
            vehicle.colour,
            stage.stageId,
            stage.stageName,
            stage.line,
            stage.order,
            stage.entryTime,
            stage.exitTime,
            stage.dwellSeconds,
            tag.name ?? "",
            tag.source ?? "",
            tag.rangeRaw ?? "",
            tag.value ?? "",
            tag.min ?? "",
            tag.max ?? "",
            tag.avg ?? "",
            tag.samples ?? "",
            tag.status ?? "",
            tag.reason ?? "",
          ]);
        }
      } catch (error) {
        // One failed stage must not stop the entire report.
        console.error(
          `[Correlation CSV] Failed stage ${stage.stageId} ` +
            `for cabin ${vehicle.cabinNumber}, skid ${vehicle.skid}:`,
          error.message,
        );

        rows.push([
          vehicle.cabinNumber,
          vehicle.skid,
          vehicle.hanger,
          vehicle.type,
          vehicle.colour,
          stage.stageId,
          stage.stageName,
          stage.line,
          stage.order,
          stage.entryTime,
          stage.exitTime,
          stage.dwellSeconds,
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "error",
          error.message || "Failed to fetch stage readings",
        ]);
      }
    }
  }

  return rowsToCsv(rows);
};

module.exports = {
  generateCorrelationReport,
  generateProcessReport,
  generateProcessCsvReport,
  generateCorrelationCsvReport,
};
