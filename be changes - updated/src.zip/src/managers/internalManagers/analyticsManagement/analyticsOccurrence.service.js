/**
 * analyticsOccurrence.service.js
 * Place at: src/managers/internalManagers/analyticsManagement/analyticsOccurrence.service.js
 *
 * Reads raw identity-tag history (liveData_test) for each PT/ED line asset and
 * materialises vehicle dwell records into vehicle_stage_occurrences.
 */
const { TagLive, TagHistory } = require("../../../models/mongoDB/tags/tagsModel");
const { Assets: Asset } = require("../../../models/mongoDB/assetManagement/asset_model");
const VehicleStageOccurrence = require("../../../models/mongoDB/analyticsManagement/vehicleStageOccurrence_model");
const { segmentSamples, MAX_TICK_GAP_MS } = require("../../../utils/analytics/occurrenceSegmenter");

/**
 * Line assets confirmed against the live DB. Two PT assets cover two
 * doc-stages each. NOT listed on purpose (default: skipped): LOADING STATION
 * (#LS_PT_01).
 */
const LINE_ASSETS = [
  { assetNumber: "40201", stageIds: ["PT-1"] }, // PRE DEGREASE-SPRAY
  { assetNumber: "40202", stageIds: ["PT-2"] }, // DEGREASE DIP
  { assetNumber: "40203", stageIds: ["PT-3", "PT-4"] }, // WATER RINSE 1&2
  { assetNumber: "40204", stageIds: ["PT-5"] }, // SURFACE ACTIVATION
  { assetNumber: "40205", stageIds: ["PT-6"] }, // PHOSPHATING
  { assetNumber: "40206", stageIds: ["PT-7", "PT-8"] }, // WATER RINSE 3&4
  { assetNumber: "40207", stageIds: ["PT-9"] }, // WATER RINSE 5
  { assetNumber: "40208", stageIds: ["PT-10"] }, // DI RINSE
  // DEFAULT (change if wrong): ED-2 Anolyte, ED-3 UF System and ED-4 After DI
  // Rinse have no asset of their own and most of their tags sit on E-Coat
  // equipment, so they are treated as support systems that share the E-Coat
  // vehicle window.
  { assetNumber: "40301", stageIds: ["ED-1", "ED-2", "ED-3", "ED-4"] }, // E-COAT
  { assetNumber: "40304", stageIds: ["ED-5"] }, // RCDI WATER SPRAY
  { assetNumber: "40302", stageIds: ["ED-6"] }, // UF RINSE-1 (SPRAY)
  { assetNumber: "40303", stageIds: ["ED-7"] }, // UF RINSE-2 (DIP)
];

const MAPPED_STAGE_IDS = new Set(LINE_ASSETS.flatMap((a) => a.stageIds));

/** Current stage list for an asset (read-time truth, so mapping changes do not need a re-backfill). */
const stageIdsForAsset = (assetNumber) =>
  LINE_ASSETS.find((a) => a.assetNumber === assetNumber)?.stageIds || [];
const DAY_MS = 24 * 60 * 60 * 1000;

const tagCache = new Map();

/** Resolve the identity tags for one line asset (cached for the process). */
async function resolveAssetTags(assetNumber) {
  if (tagCache.has(assetNumber)) return tagCache.get(assetNumber);

  const asset = await Asset.findOne({ "generalDetails.number": assetNumber })
    .select("_id generalDetails.name generalDetails.number")
    .lean();
  if (!asset) throw new Error(`Line asset #${assetNumber} not found in assets collection`);

  const tags = await TagLive.find({ assetId: asset._id }).select("_id tagname").lean();
  const find = (re) => tags.find((t) => re.test(t.tagname));

  // IMPORTANT: a tag being attached to this asset (by assetId) does NOT
  // guarantee it belongs to the SAME physical RB_File[N] record as the
  // asset's other identity tags. Confirmed on PT-6 (PHOSPHATING): every
  // identity tag there is RB_File[182].* except Serial_No_VIN_2, which is
  // wired to RB_File[179] - a different slot, tracking a different vehicle
  // on its own schedule. Trusting it doubled PT-6's occurrence count (103
  // vs ~55 everywhere else) by fragmenting one real dwell into two whenever
  // VIN_2 changed out of step with VIN_1/Type/Skid.
  //
  // Fix: anchor on Cab_Body_Code's RB_File[N] index, then look up every
  // other identity field by that EXACT index - never by "any tag with a
  // matching name attached to this asset". A field missing at that index is
  // reported as missing (see `missing` below) rather than silently
  // substituted with a same-named tag from a different index.
  const typeTag = find(/cab_body_code/i);
  const n = typeTag?.tagname.match(/RB_File\[(\d+)\]/i)?.[1];

  const byExactIndex = async (fieldSuffix) =>
    n ? TagLive.findOne({ tagname: `RB_File[${n}].${fieldSuffix}` }).select("_id tagname").lean() : null;

  const picked = {
    hanger: find(/^hanger_rfid_data/i),
    type: typeTag,
    vin1: await byExactIndex("Serial_No_VIN_1"),
    vin2: await byExactIndex("Serial_No_VIN_2"),
    skid: await byExactIndex("Dip_Paint_skid"),
    colour: await byExactIndex("Color_Code1"),
  };

  const missing = Object.entries(picked).filter(([, v]) => !v).map(([k]) => k);
  if (missing.includes("skid") || missing.includes("vin2")) {
    throw new Error(`Asset #${assetNumber}: missing required identity tag(s): ${missing.join(", ")}`);
  }

  const fieldByTagId = new Map();
  const tagIds = [];
  for (const [field, tag] of Object.entries(picked)) {
    if (!tag) continue;
    fieldByTagId.set(String(tag._id), field);
    tagIds.push(tag._id); // keep the real ObjectId from the tag document
  }

  const resolved = { asset, tagIds, fieldByTagId, missingOptional: missing };
  tagCache.set(assetNumber, resolved);
  return resolved;
}

/** Segments for one time window (no stitching). `to` is exclusive. */
async function segmentsForWindow(resolved, from, to) {
  const docs = await TagHistory.find({
    tag_id: { $in: resolved.tagIds },
    timestamp: { $gte: from, $lt: to },
  })
    .sort({ timestamp: 1 })
    .select("timestamp value tag_id")
    .lean();

  return segmentSamples(
    docs.map((d) => ({
      timestamp: d.timestamp,
      field: resolved.fieldByTagId.get(String(d.tag_id)),
      value: d.value,
    })),
  );
}

function stitch(acc, next) {
  const last = acc[acc.length - 1];
  if (
    last &&
    last.isOpen &&
    last.cabinNumber === next.cabinNumber &&
    last.skid === next.skid &&
    next.entryTime - last.exitTime <= MAX_TICK_GAP_MS
  ) {
    last.exitTime = next.exitTime;
    last.dwellSeconds = Math.round((last.exitTime - last.entryTime) / 1000);
    last.samples += next.samples;
    last.isOpen = next.isOpen;
    last.hanger = last.hanger || next.hanger;
    last.type = last.type || next.type;
    last.colour = last.colour || next.colour;
    return;
  }
  acc.push(next);
}

/** Segments over any range, processed a day at a time and stitched. */
async function buildOccurrencesRange(assetNumber, from, to) {
  const resolved = await resolveAssetTags(assetNumber);
  const toExclusive = new Date(to.getTime() + 1);
  const out = [];
  for (let cursor = from.getTime(); cursor < toExclusive.getTime(); cursor += DAY_MS) {
    const chunkEnd = new Date(Math.min(cursor + DAY_MS, toExclusive.getTime()));
    const segs = await segmentsForWindow(resolved, new Date(cursor), chunkEnd);
    // A vehicle present at the chunk edge is only "open" because of the
    // chunk boundary; stitch() merges it into the next chunk.
    segs.forEach((s) => stitch(out, s));
  }
  return { resolved, segments: out };
}

/**
 * Rebuild persisted occurrences for [from, to]. Idempotent for the same
 * window: existing rows that START in the window are replaced. Run on whole
 * days to avoid clipping a vehicle at the window edge.
 */
async function backfillOccurrences({ from, to, assetNumbers }) {
  const targets = LINE_ASSETS.filter(
    (a) => !assetNumbers || assetNumbers.includes(a.assetNumber),
  );
  const summary = [];

  for (const line of targets) {
    const { resolved, segments } = await buildOccurrencesRange(line.assetNumber, from, to);
    const docs = segments.map((s) => ({
      assetId: resolved.asset._id,
      assetNumber: line.assetNumber,
      assetName: resolved.asset.generalDetails?.name || "",
      stageIds: line.stageIds,
      ...s,
    }));

    await VehicleStageOccurrence.deleteMany({
      assetNumber: line.assetNumber,
      entryTime: { $gte: from, $lte: to },
    });
    if (docs.length) await VehicleStageOccurrence.insertMany(docs);

    summary.push({
      assetNumber: line.assetNumber,
      assetName: resolved.asset.generalDetails?.name,
      stageIds: line.stageIds,
      occurrences: docs.length,
      missingOptionalTags: resolved.missingOptional,
    });
  }
  return summary;
}

module.exports = {
  LINE_ASSETS,
  MAPPED_STAGE_IDS,
  stageIdsForAsset,
  resolveAssetTags,
  buildOccurrencesRange,
  backfillOccurrences,
};
