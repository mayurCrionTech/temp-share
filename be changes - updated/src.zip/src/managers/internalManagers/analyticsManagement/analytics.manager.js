/**
 * analytics.manager.js
 * Place at: src/managers/internalManagers/analyticsManagement/analytics.manager.js
 */
const { TagHistory } = require("../../../models/mongoDB/tags/tagsModel");
const VehicleStageOccurrence = require("../../../models/mongoDB/analyticsManagement/vehicleStageOccurrence_model");
const AnalyticsStageTagMaster = require("../../../models/mongoDB/analyticsManagement/analyticsStageTagMaster_model");
const {
  groupPasses,
  buildJourney,
} = require("../../../utils/analytics/passBuilder");
const {
  LogEntryModel,
} = require("../../../models/mongoDB/logManagement/logEntry_model");
const { parseRange } = require("../../../utils/analytics/rangeParser");
const { pickLogSamples } = require("../../../utils/analytics/logSampleFinder");
const {
  evaluateLive,
  evaluateLog,
  summariseStage,
} = require("../../../utils/analytics/readingEvaluator");
const {
  MAPPED_STAGE_IDS,
  stageIdsForAsset,
} = require("./analyticsOccurrence.service");

const SEARCH_BY = ["hanger", "skid", "cabin"];
const PASS_LOOKBACK_MS = 6 * 60 * 60 * 1000; // a pass spans well under this
const PASS_LOOKAHEAD_MS = 12 * 60 * 60 * 1000;
const MAX_MATCHES = 5000;
const LOG_LOOKBACK_MS = 24 * 60 * 60 * 1000; // log entries are created about once a shift

function badRequest(message, status = 400) {
  const err = new Error(message);
  err.status = status;
  return err;
}

/** Apply the CURRENT asset->stages mapping to stored rows. */
const withCurrentStageIds = (rows) =>
  rows.map((o) => ({
    ...o,
    stageIds: stageIdsForAsset(o.assetNumber).length
      ? stageIdsForAsset(o.assetNumber)
      : o.stageIds,
  }));

/**
 * Search vehicle passes by hanger, skid or cabin number within a date range.
 */
async function searchVehicles({ searchBy, value, from, to, limit = 200 }) {
  if (!SEARCH_BY.includes(searchBy)) {
    throw badRequest(`searchBy must be one of: ${SEARCH_BY.join(", ")}`);
  }
  if (value === undefined || String(value).trim() === "")
    throw badRequest("value is required");
  if (
    !(from instanceof Date) ||
    isNaN(from) ||
    !(to instanceof Date) ||
    isNaN(to)
  ) {
    throw badRequest("from and to must be valid ISO dates");
  }
  if (from > to) throw badRequest("from must be before to");

  const v = String(value).trim();
  const filter = { entryTime: { $gte: from, $lte: to } };
  if (searchBy === "hanger") filter.hanger = v.toUpperCase();
  else if (searchBy === "skid") {
    if (!Number.isFinite(Number(v))) throw badRequest("skid must be a number");
    filter.skid = Number(v);
  } else filter.cabinNumber = v;

  const matches = await VehicleStageOccurrence.find(filter)
    .sort({ entryTime: 1 })
    .limit(MAX_MATCHES)
    .lean();

  const pairs = new Map();
  for (const m of matches) {
    const key = `${m.cabinNumber}|${m.skid}`;
    if (!pairs.has(key) && pairs.size < limit)
      pairs.set(key, { cabinNumber: m.cabinNumber, skid: m.skid });
  }
  if (!pairs.size) return { total: 0, results: [] };

  const minEntry = new Date(matches[0].entryTime.getTime() - PASS_LOOKBACK_MS);
  const maxEntry = new Date(
    matches[matches.length - 1].entryTime.getTime() + PASS_LOOKAHEAD_MS,
  );
  const all = await VehicleStageOccurrence.find({
    $or: [...pairs.values()],
    entryTime: { $gte: minEntry, $lte: maxEntry },
  }).lean();

  const results = groupPasses(withCurrentStageIds(all)).filter((r) =>
    pairs.has(r.passKey),
  );
  return { total: results.length, results };
}

function calculateStageInRange(tags) {
  const tagsWithData = tags.filter((tag) => tag.status !== "no_data");

  // No tag has a reading
  if (!tagsWithData.length) {
    return null;
  }

  // Stage is in range only when every available tag is in range
  return tagsWithData.every((tag) => tag.status === "in_range");
}

/**
 * Readings for ONE stage over ONE vehicle's dwell window.
 *  Live tag -> samples during [entry, exit], judged on the last sample.
 *  Log tag  -> latest value operators entered on a log form at/before entry
 *              (not taken as the vehicle passed).
 */

async function computeStageReadings(stage, window) {
  const entry = new Date(window.entryTime);
  const exit = new Date(window.exitTime);

  const withId = (src) => stage.tags.filter((t) => t.source === src && t.tagId);
  const liveTags = withId("Live");
  const logTags = withId("Log");

  const liveDocs = liveTags.length
    ? await TagHistory.find({
        tag_id: { $in: liveTags.map((t) => t.tagId) },
        timestamp: { $gte: entry, $lte: exit },
      })
        .sort({ timestamp: 1 })
        .select("timestamp value tag_id")
        .lean()
    : [];
  const liveById = new Map();
  for (const d of liveDocs) {
    const k = String(d.tag_id);
    if (!liveById.has(k)) liveById.set(k, []);
    liveById.get(k).push(d);
  }

  // LOG tags: values are typed in on log forms, so read them from the log
  // entries (tag_lives only holds the latest value, not history).
  let logById = new Map();
  if (logTags.length) {
    const entries = await LogEntryModel.find({
      data: {
        $elemMatch: { tagId: { $in: logTags.map((t) => String(t.tagId)) } },
      },
      entryCreatedAt: {
        $gte: new Date(entry.getTime() - LOG_LOOKBACK_MS),
        $lte: entry,
      },
    })
      .select(
        "entryCreatedAt data.tagId data.type data.fieldValue data.fieldEnteredAt data.isFilled",
      )
      .lean();
    logById = pickLogSamples(
      entries,
      logTags.map((t) => t.tagId),
      entry,
    );
  }

  const tags = stage.tags.map((t) => {
    const range = parseRange(t.rangeRaw);
    const base = {
      name: t.name,
      rangeRaw: t.rangeRaw,
      range,
      unit: range?.unit || "",
      source: t.source,
    };

    if (t.source === "Not mapped")
      return {
        ...base,
        status: "no_data",
        reason: "Not mapped to a PLC tag yet",
      };
    if (!t.tagId)
      return {
        ...base,
        status: "no_data",
        reason: "Tag not configured in the system",
      };
    if (!range)
      return {
        ...base,
        status: "no_data",
        reason: "No reference range defined",
      };

    const key = String(t.tagId);
    const result =
      t.source === "Live"
        ? evaluateLive(liveById.get(key) || [], range)
        : evaluateLog(logById.get(key), range);
    return {
      ...base,
      ...result,
      ...(result.status === "no_data"
        ? { reason: "No reading in this window" }
        : {}),
    };
  });

  const stageStatus = summariseStage(tags);
  const inRange = calculateStageInRange(tags);

  return {
    stageId: stage.stageId,
    name: stage.name,
    status: stageStatus,
    inRange,
    window: {
      entryTime: window.entryTime,
      exitTime: window.exitTime,
      dwellSeconds: window.dwellSeconds,
    },
    tags,
  };
}

/** Occurrences for one vehicle, current stage mapping applied. */
async function loadVehicleOccurrences(cabinNumber, skid) {
  if (!cabinNumber) throw badRequest("cabinNumber is required");
  const filter = { cabinNumber: String(cabinNumber).trim() };
  if (skid !== undefined && skid !== "") {
    if (!Number.isFinite(Number(skid)))
      throw badRequest("skid must be a number");
    filter.skid = Number(skid);
  }
  const rows = await VehicleStageOccurrence.find(filter)
    .sort({ entryTime: 1 })
    .lean();
  return withCurrentStageIds(rows);
}

/**
 * One vehicle's journey laid over the ordered PT and ED stage lists.
 * includeStatus=true also computes each visited stage's process status
 * (red/green node colour) - heavier, so it is opt-in.
 */
async function getVehicleJourney({ cabinNumber, skid, includeStatus = false }) {
  const occurrences = await loadVehicleOccurrences(cabinNumber, skid);
  if (!occurrences.length) return null;

  const stages = await AnalyticsStageTagMaster.find({}).lean();
  const lines = buildJourney(stages, occurrences, MAPPED_STAGE_IDS);
  const [pass] = groupPasses(occurrences);

  if (includeStatus) {
    const byId = new Map(stages.map((s) => [s.stageId, s]));
    const visited = [...lines.PT, ...lines.ED].filter(
      (s) => s.status === "visited",
    );
    await Promise.all(
      visited.map(async (node) => {
        const result = await computeStageReadings(byId.get(node.stageId), node);

        node.processStatus = result.status;
        node.inRange = result.inRange;
      }),
    );
  }

  return {
    vehicle: {
      cabinNumber: pass.cabinNumber,
      skid: pass.skid,
      hanger: pass.hanger,
      type: pass.type,
      colour: pass.colour,
    },
    firstEntryTime: pass.firstEntryTime,
    lastExitTime: pass.lastExitTime,
    lines,
  };
}

/**
 * Tag table for one stage of one vehicle: reading, reference range, source,
 * capture time and In/Out of Range status.
 */
async function getStageReadings({ cabinNumber, skid, stageId }) {
  if (!stageId) throw badRequest("stageId is required");
  const stage = await AnalyticsStageTagMaster.findOne({
    stageId: String(stageId).trim().toUpperCase(),
  }).lean();
  if (!stage) throw badRequest(`Unknown stage "${stageId}"`, 404);

  if (stage.isManualInspection) {
    return {
      stageId: stage.stageId,
      name: stage.name,
      status: "manual",
      tags: [],
      reason: "Manual inspection, no PLC tags",
    };
  }

  const occurrences = await loadVehicleOccurrences(cabinNumber, skid);
  const occ = occurrences.find((o) => o.stageIds.includes(stage.stageId));
  if (!occ) return null;

  return computeStageReadings(stage, occ);
}

/**
 * Get default overview data for Analytics page.
 *
 * Returns the latest vehicle passes based on historical
 * vehicle_stage_occurrences data.
 *
 * This is intentionally lightweight:
 * - Does NOT calculate stage readings
 * - Does NOT query liveData_test
 * - Does NOT query logEntries
 * - Only uses vehicle_stage_occurrences
 */
async function getAnalyticsOverview({ limit = 20 } = {}) {
  const safeLimit = Math.min(Math.max(Number(limit) || 20, 1), 100);

  const occurrences = await VehicleStageOccurrence.find({})
    .sort({ entryTime: -1 })
    .limit(MAX_MATCHES)
    .lean();

  if (!occurrences.length) {
    return {
      total: 0,
      results: [],
    };
  }

  // Apply the current asset -> stage mapping.
  const mappedOccurrences = withCurrentStageIds(occurrences);

  // groupPasses() needs the complete vehicle pass history.
  const passes = groupPasses(mappedOccurrences);

  // Latest vehicles first.
  passes.sort(
    (a, b) =>
      new Date(b.lastExitTime || b.firstEntryTime) -
      new Date(a.lastExitTime || a.firstEntryTime),
  );

  const results = passes.slice(0, safeLimit).map((pass) => ({
    passKey: pass.passKey,
    cabinNumber: pass.cabinNumber,
    skid: pass.skid,
    hanger: pass.hanger,
    type: pass.type,
    colour: pass.colour,
    firstEntryTime: pass.firstEntryTime,
    lastExitTime: pass.lastExitTime,
    stagesSeen: pass.stageIds?.length || 0,
  }));

  return {
    total: results.length,
    results,
  };
}

module.exports = {
  searchVehicles,
  getVehicleJourney,
  getStageReadings,
  computeStageReadings,
  getAnalyticsOverview,
};
