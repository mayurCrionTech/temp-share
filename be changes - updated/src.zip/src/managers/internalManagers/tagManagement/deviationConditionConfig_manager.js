// #QID_174

const mongoose = require("mongoose");

const { TagLive } = require("../../../models/mongoDB/tags/tagsModel");

const DeviationConditionConfig = require("../../../models/mongoDB/tags/deviationConditionConfig_model");

const NUMERIC_TYPES = ["number"];

// Keep these variants to support the Boolean datatype values
// that may exist in the database.
const BOOLEAN_TYPES = ["BOOL", "boolean", "BOOLEAN", "bool"];

function serializeTag(tag) {
  return {
    _id: tag._id.toString(),
    displayName:
      (typeof tag.displayName === "string" && tag.displayName.trim()) ||
      (typeof tag.tagname === "string" && tag.tagname.trim()) ||
      tag._id.toString(),
    tagname: tag.tagname || "",
    datatype: tag.datatype,
    latestValue: tag.latestValue ?? null,
    unit: tag.unit || "",
    plcName: tag.plcName || "",
    ranges: tag.ranges || null,
  };
}

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// Fetch numeric tags eligible for deviation configuration.
async function getNumericTags() {
  const tags = await TagLive.find({
    datatype: { $in: NUMERIC_TYPES },
    assetId: { $exists: true, $ne: [] },
    "ranges.minValue": { $type: "number" },
    "ranges.maxValue": { $type: "number" },
  })
    .select(
      "_id displayName tagname datatype latestValue unit plcName assetId ranges",
    )
    .sort({ displayName: 1, tagname: 1 })
    .lean();

  return tags
    .filter((tag) => tag.ranges.minValue < tag.ranges.maxValue)
    .map(serializeTag);
}

// Fetch Boolean condition tags.
// No assetId, isActive, or ranges filter is applied.
async function getConditionTags() {
  const tags = await TagLive.find({
    datatype: { $in: BOOLEAN_TYPES },
  })
    .select("_id displayName tagname datatype latestValue unit plcName")
    .sort({ displayName: 1, tagname: 1 })
    .lean();

  return tags.map(serializeTag);
}

// Return saved configurations with readable tag information.
async function getAllConfigurations() {
  const configs = await DeviationConditionConfig.find()
    .sort({ updatedAt: -1 })
    .lean();

  const tagIds = [
    ...new Set(
      configs.flatMap((config) => [
        config.numericTagId.toString(),
        ...config.conditionTagIds.map((id) => id.toString()),
      ]),
    ),
  ];

  const tags = await TagLive.find({
    _id: { $in: tagIds },
  })
    .select("_id displayName tagname datatype latestValue unit plcName ranges")
    .lean();

  const tagMap = new Map(
    tags.map((tag) => [tag._id.toString(), serializeTag(tag)]),
  );

  return configs.map((config) => ({
    _id: config._id.toString(),
    numericTag: tagMap.get(config.numericTagId.toString()) || {
      _id: config.numericTagId.toString(),
      displayName: config.numericTagId.toString(),
      tagname: "",
    },
    conditionTags: config.conditionTagIds.map(
      (id) =>
        tagMap.get(id.toString()) || {
          _id: id.toString(),
          displayName: id.toString(),
          tagname: "",
        },
    ),
    isEnabled: config.isEnabled,
    createdBy: config.createdBy?.toString() || null,
    updatedBy: config.updatedBy?.toString() || null,
    createdAt: config.createdAt,
    updatedAt: config.updatedAt,
  }));
}

async function validateTagSelection(numericTagId, conditionTagIds) {
  if (!isValidObjectId(numericTagId)) {
    throw new Error("Invalid numericTagId.");
  }

  if (!Array.isArray(conditionTagIds) || conditionTagIds.length === 0) {
    throw new Error("Select at least one condition tag.");
  }

  if (!conditionTagIds.every(isValidObjectId)) {
    throw new Error("One or more condition tag IDs are invalid.");
  }

  const uniqueConditionIds = [
    ...new Set(conditionTagIds.map((id) => id.toString())),
  ];

  const numericTag = await TagLive.findOne({
    _id: numericTagId,
    datatype: { $in: NUMERIC_TYPES },
    assetId: { $exists: true, $ne: [] },
    "ranges.minValue": { $type: "number" },
    "ranges.maxValue": { $type: "number" },
  }).lean();

  if (!numericTag || numericTag.ranges.minValue >= numericTag.ranges.maxValue) {
    throw new Error(
      "The selected numeric tag must have datatype number, an asset ID, and a valid range.",
    );
  }

  const validConditions = await TagLive.find({
    _id: { $in: uniqueConditionIds },
    datatype: { $in: BOOLEAN_TYPES },
  })
    .select("_id")
    .lean();

  if (validConditions.length !== uniqueConditionIds.length) {
    throw new Error(
      "One or more selected condition tags are not valid Boolean tags.",
    );
  }

  return {
    numericTagId: numericTag._id,
    conditionTagIds: uniqueConditionIds,
  };
}

async function createConfiguration(data, userId) {
  const { numericTagId, conditionTagIds } = await validateTagSelection(
    data.numericTagId,
    data.conditionTagIds,
  );

  const existing = await DeviationConditionConfig.findOne({
    numericTagId,
  });

  if (existing) {
    throw new Error(
      "A configuration already exists for this numeric tag. Update the existing configuration instead.",
    );
  }

  return DeviationConditionConfig.create({
    numericTagId,
    conditionTagIds,
    isEnabled: data.isEnabled ?? true,
    createdBy: userId || null,
    updatedBy: userId || null,
  });
}

async function updateConfiguration(id, data, userId) {
  if (!isValidObjectId(id)) {
    throw new Error("Invalid configuration ID.");
  }

  const config = await DeviationConditionConfig.findById(id);

  if (!config) {
    throw new Error("Configuration not found.");
  }

  const { numericTagId, conditionTagIds } = await validateTagSelection(
    data.numericTagId ?? config.numericTagId.toString(),
    data.conditionTagIds ?? config.conditionTagIds.map((id) => id.toString()),
  );

  const duplicate = await DeviationConditionConfig.findOne({
    numericTagId,
    _id: { $ne: config._id },
  });

  if (duplicate) {
    throw new Error(
      "Another configuration already exists for this numeric tag.",
    );
  }

  config.numericTagId = numericTagId;
  config.conditionTagIds = conditionTagIds;

  if (typeof data.isEnabled === "boolean") {
    config.isEnabled = data.isEnabled;
  }

  config.updatedBy = userId || null;

  await config.save();

  return config;
}

async function updateConfigurationStatus(id, isEnabled, userId) {
  if (!isValidObjectId(id)) {
    throw new Error("Invalid configuration ID.");
  }

  if (typeof isEnabled !== "boolean") {
    throw new Error("isEnabled must be a boolean.");
  }

  const config = await DeviationConditionConfig.findById(id);

  if (!config) {
    throw new Error("Configuration not found.");
  }

  config.isEnabled = isEnabled;
  config.updatedBy = userId || null;

  await config.save();

  return config;
}

module.exports = {
  getNumericTags,
  getConditionTags,
  getAllConfigurations,
  createConfiguration,
  updateConfiguration,
  updateConfigurationStatus,
};
