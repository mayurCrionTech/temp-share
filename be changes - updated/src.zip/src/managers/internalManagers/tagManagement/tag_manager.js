const mongoose = require("mongoose");
const forecastDefects = require("../../../models/mongoDB/forecastDefect/forecastDefect-model");
const {TagLive,TagHistory} = require("../../../models/mongoDB/tags/tagsModel");
const TagSummary = require("../../../models/mongoDB/tags/tagSummary");
const SetpointDeviationEvent = require("../../../models/mongoDB/logManagement/setpointDeviationEvent_model");
const TagAnomalyCache = require("../../../models/mongoDB/cache/tagAnomalyCache_model");
// const {sendForeCastDefects} = require("../../../utils/socket/socketHandler")
const {
  updateOne,
} = require("../../dBManagers/mongoDB_manager");


function parseISODuration(duration) {
  const regex = /^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?)?$/;
  const matches = duration.match(regex);

  if (!matches) {
    throw new Error("Invalid ISO8601 duration format");
  }

  const days = parseInt(matches[1] || 0, 10);
  const hours = parseInt(matches[2] || 0, 10);
  const minutes = parseInt(matches[3] || 0, 10);

  const totalMs =
    (days * 24 * 60 * 60 * 1000) +
    (hours * 60 * 60 * 1000) +
    (minutes * 60 * 1000);

  if (totalMs <= 0) {
    throw new Error("Interval must be greater than zero");
  }

  return totalMs;
}

// async function getTagHistory (
//   tagId,
//   startTime,
//   endTime,
//   interval,
//   aggregation,
//   limit = 100)
// {
//   console.log("tttt",tagId,startTime,endTime,interval,aggregation,limit)

//   if (!tagId || !startTime || !endTime || !interval || !aggregation) {
//     throw new Error("Missing required query parameters");
//   }

//   const start = new Date(startTime);
//   const end = new Date(endTime);

//   if (isNaN(start) || isNaN(end)) {
//     throw new Error("Invalid date format");
//   }

//   if (start >= end) {
//     throw new Error("startTime must be less than endTime");
//   }

//   const intervalMs = parseISODuration(interval);
//   const tagObjectId = new mongoose.Types.ObjectId(tagId);

//   // 🔹 Fetch hourly aggregated data
//   const hourlyData = await TagSummary.find({
//     tagId: tagObjectId,
//     startTime: { $gte: start, $lt: end }
//   })
//     .sort({ startTime: 1 })
//     .lean();

//   if (!hourlyData.length) {
//     return {
//       tagId,
//       interval,
//       aggregation,
//       points: []
//     };
//   }

//   const bucketMap = new Map();

//   for (let record of hourlyData) {

//     const recordTime = new Date(record.startTime);
//     const diff = recordTime - start;

//     if (diff < 0) continue;

//     const bucketIndex = Math.floor(diff / intervalMs);
//     const bucketStart = new Date(start.getTime() + bucketIndex * intervalMs);
//     const key = bucketStart.toISOString();

//     if (!bucketMap.has(key)) {
//       bucketMap.set(key, {
//         timestamp: bucketStart,
//         sum: 0,
//         count: 0,
//         minValue: Infinity,
//         maxValue: -Infinity,
//         first: record.first,
//         last: record.last
//       });
//     }

//     const bucket = bucketMap.get(key);

//     bucket.sum += record.sum;
//     bucket.count += record.count;
//     bucket.minValue = Math.min(bucket.minValue, record.minValue);
//     bucket.maxValue = Math.max(bucket.maxValue, record.maxValue);
//     bucket.last = record.last;
//   }

//   const points = [];

//   for (let bucket of bucketMap.values()) {

//     let value;

//     switch (aggregation) {
//       case "avg":
//         value = bucket.count ? bucket.sum / bucket.count : 0;
//         break;
//       case "sum":
//         value = bucket.sum;
//         break;
//       case "min":
//         value = bucket.minValue === Infinity ? 0 : bucket.minValue;
//         break;
//       case "max":
//         value = bucket.maxValue === -Infinity ? 0 : bucket.maxValue;
//         break;
//       case "count":
//         value = bucket.count;
//         break;
//       case "first":
//         value = bucket.first;
//         break;
//       case "last":
//         value = bucket.last;
//         break;
//       default:
//         throw new Error("Invalid aggregation type");
//     }

//     points.push({
//       timestamp: bucket.timestamp.toISOString(),
//       value
//     });
//   }

//   return {
//     tagId,
//     interval,
//     aggregation,
//     points: points.slice(0, limit)
//   };
// };

// function parseUserDate(dateString) {
//   if (!dateString) {
//     throw new Error("Date is required");
//   }

//   // If timezone already present → use directly
//   if (dateString.includes("Z") || dateString.includes("+")) {
//     const d = new Date(dateString);
//     if (isNaN(d)) throw new Error("Invalid date format");
//     return d;
//   }

//   // If no timezone → assume IST by appending +05:30
//   const d = new Date(dateString + "+05:30");

//   if (isNaN(d)) {
//     throw new Error("Invalid date format");
//   }

//   return d;
// }

function parseUserDate(dateString) {
  if (!dateString) {
    throw new Error("Date is required");
  }

  // If timezone explicitly provided
  if (/[zZ]|[+-]\d{2}:\d{2}$/.test(dateString)) {
    const d = new Date(dateString);
    if (isNaN(d)) throw new Error("Invalid date format");
    return d;
  }

  // Force IST if no timezone
  const d = new Date(dateString + "+05:30");

  if (isNaN(d)) {
    throw new Error("Invalid date format");
  }

  return d;
}

function floorToInterval(date, intervalMs) {
  const time = date.getTime();
  const floored = Math.floor(time / intervalMs) * intervalMs;
  return new Date(floored);
}

// async function getTagHistory(
//   tagId,
//   startTime,
//   endTime,
//   interval,
//   aggregation,
//   limit = 100
// ) {

//   if (!tagId || !startTime || !endTime || !interval || !aggregation) {
//     throw new Error("Missing required query parameters");
//   }

//   // const start = parseUserDate(startTime);
//   // const end = parseUserDate(endTime);

//   const rawStart = parseUserDate(startTime);
// const rawEnd = parseUserDate(endTime);

// const intervalMs = parseISODuration(interval);

// // FLOOR both start and end
// // const start = floorToInterval(rawStart, intervalMs);
// // const end = floorToInterval(rawEnd, intervalMs);

// function floorToHourUTC(date) {
//   const d = new Date(date);
//   d.setUTCMinutes(0, 0, 0);
//   return d;
// }

// const start = floorToHourUTC(rawStart);
// const end = floorToHourUTC(rawEnd);

// // console.log("FLOORED START UTC:", start.toISOString());
// // console.log("FLOORED END UTC:", end.toISOString());

// //   console.log("START UTC:", start.toISOString());
// // console.log("END UTC:", end.toISOString());

// // console.log("RAW START:", rawStart.toISOString());
// // console.log("RAW END:", rawEnd.toISOString());

//   if (isNaN(start) || isNaN(end)) {
//     throw new Error("Invalid date format");
//   }

//   if (start >= end) {
//     throw new Error("startTime must be less than endTime");
//   }

//   // const intervalMs = parseISODuration(interval);
//   const tagObjectId = new mongoose.Types.ObjectId(tagId);

//   const hourlyData = await TagSummary.find({
//     tagId: tagObjectId,
//     startTime: { $gte: start, $lt: end }
//   })
//     .sort({ startTime: 1 })
//     .lean();

//   if (!hourlyData.length) {
//     return {
//       tagId,
//       interval,
//       aggregation,
//       points: []
//     };
//   }

//   const bucketMap = new Map();

//   for (let record of hourlyData) {
//     const recordTime = new Date(record.startTime);
//     const diff = recordTime - start;

//     if (diff < 0) continue;

//     const bucketIndex = Math.floor(diff / intervalMs);
//     const bucketStart = new Date(start.getTime() + bucketIndex * intervalMs);
//     const key = bucketStart.toISOString();

//     if (!bucketMap.has(key)) {
//       bucketMap.set(key, {
//         timestamp: bucketStart,
//         sum: 0,
//         count: 0,
//         minValue: Infinity,
//         maxValue: -Infinity,
//         first: record.first,
//         last: record.last
//       });
//     }

//     const bucket = bucketMap.get(key);

//     bucket.sum += record.sum;
//     bucket.count += record.count;
//     bucket.minValue = Math.min(bucket.minValue, record.minValue);
//     bucket.maxValue = Math.max(bucket.maxValue, record.maxValue);
//     bucket.last = record.last;
//   }

//   // const points = [];

//   // for (let bucket of bucketMap.values()) {
//   //   let value;

//   //   switch (aggregation) {
//   //     case "avg":
//   //       value = bucket.count ? bucket.sum / bucket.count : 0;
//   //       break;
//   //     case "sum":
//   //       value = bucket.sum;
//   //       break;
//   //     case "min":
//   //       value =
//   //         bucket.minValue === Infinity ? 0 : bucket.minValue;
//   //       break;
//   //     case "max":
//   //       value =
//   //         bucket.maxValue === -Infinity ? 0 : bucket.maxValue;
//   //       break;
//   //     case "count":
//   //       value = bucket.count;
//   //       break;
//   //     case "first":
//   //       value = bucket.first;
//   //       break;
//   //     case "last":
//   //       value = bucket.last;
//   //       break;
//   //     default:
//   //       throw new Error("Invalid aggregation type");
//   //   }

//   //   points.push({
//   //     timestamp: bucket.timestamp.toISOString(),
//   //     value
//   //   });
//   // }

//   // return {
//   //   tagId,
//   //   interval,
//   //   aggregation,
//   //   points: points.slice(0, limit)
//   // };
//   const points = [];

// let currentBucketStart = new Date(start);

// while (currentBucketStart <= end) {
//   const currentBucketEnd = new Date(currentBucketStart.getTime() + intervalMs);

//   // Get records inside this bucket
//   const records = hourlyData.filter(r => {
//     const t = new Date(r.startTime);
//     return t >= currentBucketStart && t < currentBucketEnd;
//   });

//   // if (records.length > 0) {
//   const expectedHours = intervalMs / (60 * 60 * 1000);

// if (records.length === expectedHours){
//     let sum = 0;
//     let count = 0;
//     let minValue = Infinity;
//     let maxValue = -Infinity;
//     let first = records[0].first;
//     let last = records[records.length - 1].last;

//     for (let r of records) {
//       sum += r.sum;
//       count += r.count;
//       minValue = Math.min(minValue, r.minValue);
//       maxValue = Math.max(maxValue, r.maxValue);
//     }

//     let value;

//     switch (aggregation) {
//       case "avg":
//         value = count ? sum / count : 0;
//         break;
//       case "sum":
//         value = sum;
//         break;
//       case "min":
//         value = minValue;
//         break;
//       case "max":
//         value = maxValue;
//         break;
//       case "count":
//         value = count;
//         break;
//       case "first":
//         value = first;
//         break;
//       case "last":
//         value = last;
//         break;
//       default:
//         throw new Error("Invalid aggregation type");
//     }

//     points.push({
//       timestamp: currentBucketStart.toISOString(),
//       value
//     });
//   }

//   // Move to next bucket
//   currentBucketStart = currentBucketEnd;
// }
//  return {
//     tagId,
//     interval,
//     aggregation,
//     points: points.slice(0, limit)
//   };
// }

const ALLOWED_HISTORY_AGGREGATIONS = ["avg", "sum", "min", "max", "count", "first", "last"];

// Ladder of "nice" intervals, smallest to largest.
// Auto-selection picks the smallest one that keeps bucket count under targetPoints.
const AUTO_INTERVAL_LADDER = [
  { iso: "PT1M",  ms: 60 * 1000 },
  { iso: "PT5M",  ms: 5 * 60 * 1000 },
  { iso: "PT15M", ms: 15 * 60 * 1000 },
  { iso: "PT30M", ms: 30 * 60 * 1000 },
  { iso: "PT1H",  ms: 60 * 60 * 1000 },
  { iso: "PT3H",  ms: 3 * 60 * 60 * 1000 },
  { iso: "PT6H",  ms: 6 * 60 * 60 * 1000 },
  { iso: "PT12H", ms: 12 * 60 * 60 * 1000 },
  { iso: "P1D",   ms: 24 * 60 * 60 * 1000 },
];

function pickAutoInterval(durationMs, targetPoints = 150) {
  for (const step of AUTO_INTERVAL_LADDER) {
    if (durationMs / step.ms <= targetPoints) {
      return step;
    }
  }
  // Range is huge even at daily buckets — fall back to daily anyway.
  return AUTO_INTERVAL_LADDER[AUTO_INTERVAL_LADDER.length - 1];
}

async function getTagHistory(
  tagId,
  startTime,
  endTime,
  interval,
  aggregation,
  limit = 100
) {
  if (!tagId || !startTime || !endTime || !aggregation) {
    throw new Error("Missing required query parameters");
  }

  if (!mongoose.Types.ObjectId.isValid(tagId)) {
    throw new Error("Invalid tagId format");
  }

  if (!ALLOWED_HISTORY_AGGREGATIONS.includes(aggregation)) {
    throw new Error("Invalid aggregation type");
  }

  const start = parseUserDate(startTime);
  let end = parseUserDate(endTime);

  if (isNaN(start) || isNaN(end)) {
    throw new Error("Invalid date format");
  }

  if (start >= end) {
    throw new Error("startTime must be less than endTime");
  }

  // ── If the requested end is close to "now", trust server time instead ──
  // Prevents the current/in-progress interval from being silently cut off
  // due to client clock lag or request latency.
  const now = new Date();
  const CURRENT_WINDOW_BUFFER_MS = 5 * 60 * 1000; // 5 min tolerance
  if (now.getTime() - end.getTime() < CURRENT_WINDOW_BUFFER_MS) {
    end = now;
  }

  // ── Resolve interval ──
  let resolvedIntervalIso;
  let intervalMs;

  if (!interval || interval === "auto") {
    const auto = pickAutoInterval(end.getTime() - start.getTime());
    resolvedIntervalIso = auto.iso;
    intervalMs = auto.ms;
  } else {
    resolvedIntervalIso = interval;
    intervalMs = parseISODuration(interval);
  }

  const tagObjectId = new mongoose.Types.ObjectId(tagId);
  const anchorMs = start.getTime();
  const limitNum = Math.min(10000, Math.max(1, parseInt(limit, 10) || 100));

  const docs = await TagHistory.aggregate([
    {
      $match: {
        tag_id: tagObjectId,
        timestamp: { $gte: start, $lte: end }, // ← inclusive now
        value: { $type: "number" }
      }
    },
    { $sort: { timestamp: 1 } },
    {
      $group: {
        _id: {
          bucket: {
            $toDate: {
              $subtract: [
                { $toLong: "$timestamp" },
                {
                  $mod: [
                    { $subtract: [{ $toLong: "$timestamp" }, anchorMs] },
                    intervalMs
                  ]
                }
              ]
            }
          }
        },
        avg: { $avg: "$value" },
        sum: { $sum: "$value" },
        min: { $min: "$value" },
        max: { $max: "$value" },
        count: { $sum: 1 },
        first: { $first: "$value" },
        last: { $last: "$value" }
      }
    },
    { $sort: { "_id.bucket": 1 } },
    { $limit: limitNum }
  ]);

  const points = docs.map((d) => ({
    timestamp: d._id.bucket.toISOString(),
    value: d[aggregation]
  }));

  return {
    tagId,
    interval: resolvedIntervalIso,
    aggregation,
    points
  };
}

/**
 * Fetch all tags and map to API format
 */
async function fetchAllTags() {
  const tags = await TagLive.find();

  // map to frontend API format
  const formattedTags = tags.map((tag) => ({
    id: tag._id.toString(),
    tagname: tag.tagname,
    description: tag.description,
    dataType: tag.datatype,
    val: tag.latestValue,
    timestamp: tag.updatedAt,
    health: tag.health,
    plcMetadata: tag.plcMetadata || { dbAddress: "" },
  }));

  return formattedTags;
}

async function fetchTagsByAssetId(assetId, reqData) {
  const mongoose = require("mongoose");

  const assetObjectId = new mongoose.Types.ObjectId(assetId);

  const tags = await TagLive.find({ assetId: assetObjectId });

  return tags.map((tag) => ({
    id: tag._id.toString(),
    tagname: tag.tagname,
    description: tag.description,
    dataType: tag.datatype,
    val: tag.latestValue,
    timestamp: tag.updatedAt,
    health: tag.health,
    plcMetadata: tag.plcMetadata || { dbAddress: "" },
  }));
}

// async function getTagHistory({
//   tagId,
//   startTime,
//   endTime,
//   interval,
//   aggregation,
//   limit = 100
// }) {
//   try {

//     // -------- VALIDATION --------
//     if (!tagId || !mongoose.Types.ObjectId.isValid(tagId)) {
//       throw new Error("Invalid Tag ID");
//     }

//     if (!startTime || !endTime) {
//       throw new Error("StartTime and EndTime are required");
//     }

//     const allowedAgg = ["avg", "min", "max", "sum", "count", "first", "last"];
//     if (!allowedAgg.includes(aggregation)) {
//       throw new Error("Invalid aggregation type");
//     }

//     // -------- AGGREGATION OPERATOR --------
//     const aggMap = {
//       avg: { $avg: "$value" },
//       min: { $min: "$value" },
//       max: { $max: "$value" },
//       sum: { $sum: "$value" },
//       count: { $sum: 1 },
//       first: { $first: "$value" },
//       last: { $last: "$value" }
//     };

//     // -------- PIPELINE --------
//     const pipeline = [
//       {
//         $match: {
//           tag_id: new mongoose.Types.ObjectId(tagId),
//           timestamp: {
//             $gte: new Date(startTime),
//             $lte: new Date(endTime)
//           }
//         }
//       },
//       {
//         $sort: { timestamp: 1 }
//       },
//       {
//         $group: {
//           _id: {
//             $dateTrunc: {
//               date: "$timestamp",
//               unit: "hour"
//             }
//           },
//           value: aggMap[aggregation]
//         }
//       },
//       {
//         $limit: parseInt(limit)
//       }
//     ];

//     // -------- EXECUTE --------
//     const rawData = await mongoDbManager.aggregation(TagHistory, pipeline);

//     // -------- FORMAT --------
//     const points = rawData.map(r => ({
//       timestamp: r._id,
//       value: r.value
//     }));

//     return {
//       tagId,
//       interval,
//       aggregation,
//       count: points.length,
//       points
//     };

//   } catch (error) {
//     throw error;
//   }
// }

async function getAllLiveTags  (tagIds) {
  const tags = await TagLive.find(
    { _id: { $in: tagIds }, isActive: true },
    { tagname: 1, latestValue: 1, health: 1, updatedAt: 1 }
  ).lean();

  // Map to the required response structure
  const result = tags.map((tag) => ({
    tagId: tag._id,
    val: tag.latestValue ?? null,
    health: tag.health || true,   
    timestamp: tag.updatedAt,            
  }));

  return result;
};

// const { Assets }             = require("../../../models/mongoDB/assetManagement/asset_model");
// const { TagHistory }         = require("../../../models/mongoDB/tags/tagsModel");
// const SetpointDeviationEvent = require("../../../models/mongoDB/logManagement/setpointDeviationEvent_model");
// const { AssetParameters }    = require("../../../models/mongoDB/assetManagement/assetParameter_model");

// async function getTagAnomalies({ tagId, startTime, endTime, limit = 10, page = 1 }) {

//   if (!mongoose.Types.ObjectId.isValid(tagId)) {
//     throw new Error("Invalid tagId format. Must be a valid ObjectId.");
//   }

//   const start = new Date(startTime);
//   const end   = new Date(endTime);

//   if (isNaN(start.getTime()) || isNaN(end.getTime())) {
//     throw new Error("Invalid startTime or endTime. Must be valid ISO 8601 dates.");
//   }

//   if (start >= end) {
//     throw new Error("startTime must be before endTime.");
//   }

//   const pageNum   = Math.max(1, parseInt(page));
//   const limitNum  = Math.min(100, Math.max(1, parseInt(limit)));
//   const skipCount = (pageNum - 1) * limitNum;

//   const emptyResult = {
//     currentPage:    pageNum,
//     totalPageCount: 0,
//     totalDataCount: 0,
//     data:           [],
//   };

//   // ── STEP 1: Find deviation events by sourceDetails.tagId + time range ──
//   const deviationEvents = await SetpointDeviationEvent.find({
//     "sourceDetails.tagId": new mongoose.Types.ObjectId(tagId),
//     triggeredAt:           { $gte: start, $lte: end },
//   }).lean();

//   if (!deviationEvents.length) return emptyResult;

//   // ── STEP 2: Collect unique assetIds ────────────────────────────────────
//   const assetIds = [
//     ...new Set(
//       deviationEvents.filter((e) => e.assetId).map((e) => e.assetId.toString())
//     ),
//   ].map((id) => new mongoose.Types.ObjectId(id));

//   if (!assetIds.length) return emptyResult;

//   // ── STEP 3: Fetch assets → extract locationAndHierarchyDetails.hierarchy.parent ──
//   const assets = await Assets.find(
//     { _id: { $in: assetIds }, isDeleted: false },
//     { "locationAndHierarchyDetails.hierarchy.parent": 1 }
//   ).lean();

//   const parentIds = [
//     ...new Set(
//       assets
//         .map((a) => a.locationAndHierarchyDetails?.hierarchy?.parent?.toString())
//         .filter(Boolean)
//     ),
//   ].map((id) => new mongoose.Types.ObjectId(id));

//   if (!parentIds.length) return emptyResult;

//   // ── STEP 4: Fetch assetParameters for parent assets ────────────────────
//   const assetParameters = await AssetParameters.find(
//     { asset: { $in: parentIds }, isDeleted: false },
//     { name: 1, tagId: 1, asset: 1 }
//   ).lean();

//   if (!assetParameters.length) return emptyResult;

//   const tagLive = await TagLive.findOne(
//     { _id: new mongoose.Types.ObjectId(tagId), isActive: true },
//     { ranges: 1, unit: 1 }
//   ).lean();

//   const setPointLimit = tagLive
//   ?`${tagLive.ranges?.minValue ?? "?"}-${tagLive.ranges?.maxValue ?? "?"}`.trim()
//     // ? `${tagLive.ranges?.minValue ?? "?"}-${tagLive.ranges?.maxValue ?? "?"} ${tagLive.unit ?? ""}`.trim()
//     : null;

//   // ── Build lookup maps ──────────────────────────────────────────────────

//   const tagIdToParamName = {};
//   assetParameters.forEach((p) => {
//     tagIdToParamName[p.tagId.toString()] = p.name;
//   });

//   const parentToTagIds = {};
//   assetParameters.forEach((p) => {
//     const pid = p.asset.toString();
//     if (!parentToTagIds[pid]) parentToTagIds[pid] = [];
//     parentToTagIds[pid].push(p.tagId.toString());
//   });

//   const tagIdToAssetId = {};
//   assets.forEach((asset) => {
//     const parentId = asset.locationAndHierarchyDetails?.hierarchy?.parent?.toString();
//     if (!parentId) return;
//     (parentToTagIds[parentId] || []).forEach((tid) => {
//       tagIdToAssetId[tid] = asset._id.toString();
//     });
//   });

//   const assetIdToDeviation = {};
//   deviationEvents.forEach((evt) => {
//     if (evt.assetId) assetIdToDeviation[evt.assetId.toString()] = evt;
//   });

//   const paramTagObjectIds = assetParameters.map(
//     (p) => new mongoose.Types.ObjectId(p.tagId)
//   );

//   // ── STEP 5: Count for pagination ───────────────────────────────────────
//   const totalDataCount = await TagHistory.countDocuments({
//     tag_id:    { $in: paramTagObjectIds },
//     timestamp: { $gte: start, $lte: end },
//   });

//   if (totalDataCount === 0) return emptyResult;

//   const totalPageCount = Math.ceil(totalDataCount / limitNum);

//   // ── STEP 6: Fetch paginated liveData records ───────────────────────────
//   const liveDataRecords = await TagHistory.find({
//     tag_id:    { $in: paramTagObjectIds },
//     timestamp: { $gte: start, $lte: end },
//   })
//     .sort({ timestamp: -1 })
//     .skip(skipCount)
//     .limit(limitNum)
//     .lean();

//   // ── STEP 7: Group by assetId → build flat fields ──────────────────────
//   const assetTagAccumulator = new Map();

//   liveDataRecords.forEach((record) => {
//     const tagIdStr   = record.tag_id.toString();
//     const paramName  = tagIdToParamName[tagIdStr];
//     const assetIdStr = tagIdToAssetId[tagIdStr];

//     if (!paramName || !assetIdStr) return;

//     const deviation = assetIdToDeviation[assetIdStr] || null;

//     if (!assetTagAccumulator.has(assetIdStr)) {
//       assetTagAccumulator.set(assetIdStr, {
//         id:             record._id,
//         timestamp:      record.timestamp,
//         severity:       "warning",
//         fault:          deviation?.deviationType ?? null,
//         breachDateTime: deviation?.triggeredAt   ?? null,   // renamed from triggeredAt
//         setPointBreach: deviation?.value         ?? null,   // deviation value
//         unit:tagLive?.unit ?? "",
//         // setPointBreach: deviation?.value != null ? `${deviation.value} ${tagLive?.unit ?? ""}`.trim() : null,
//         setPointLimit,
//         message:        deviation
//           ? `${deviation.sourceDetails?.tagname ?? "Tag"} deviated from setpoint (${deviation.deviationType}) with value ${deviation.value}`
//           : "Anomaly detected",
//       });
//     }

//     const entry = assetTagAccumulator.get(assetIdStr);

//     // Trim prefix → "PT_WR34_CabinNumber" becomes "CabinNumber"
//     const shortName = paramName.includes("_")
//       ? paramName.substring(paramName.lastIndexOf("_") + 1)
//       : paramName;

//     // Flat at root — no nested tags object
//     entry[shortName] = record.value ?? null;

//     if (new Date(record.timestamp) > new Date(entry.timestamp)) {
//       entry.timestamp = record.timestamp;
//     }
//   });

//   return {
//     currentPage:    pageNum,
//     totalPageCount,
//     totalDataCount,
//     data: Array.from(assetTagAccumulator.values()),
//   };
// }
// module.exports = { fetchAllTags, fetchTagsByAssetId,getTagHistory,getAllLiveTags };


// async function getTagAnomalies({ tagId, startTime, endTime, limit = 10, page = 1 }) {

//   if (!mongoose.Types.ObjectId.isValid(tagId)) {
//     throw new Error("Invalid tagId format. Must be a valid ObjectId.");
//   }

//   const start = new Date(startTime);
//   const end   = new Date(endTime);

//   if (isNaN(start.getTime()) || isNaN(end.getTime())) {
//     throw new Error("Invalid startTime or endTime. Must be valid ISO 8601 dates.");
//   }

//   if (start >= end) {
//     throw new Error("startTime must be before endTime.");
//   }

//   const pageNum   = Math.max(1, parseInt(page));
//   const limitNum  = Math.min(100, Math.max(1, parseInt(limit)));
//   const skipCount = (pageNum - 1) * limitNum;

//   const emptyResult = {
//     currentPage:    pageNum,
//     totalPageCount: 0,
//     totalDataCount: 0,
//     data:           [],
//   };

//   // ── Fetch TagLive for unit + setPointLimit ─────────────────────────────
//   const tagLive = await TagLive.findOne(
//     { _id: new mongoose.Types.ObjectId(tagId), isActive: true },
//     { ranges: 1, unit: 1 }
//   ).lean();

//   const unit                   = tagLive?.unit ?? "";
//   const { minValue, maxValue } = tagLive?.ranges || {};
//   const setPointLimit          = (minValue != null && maxValue != null)
//     ? `${minValue}-${maxValue} ${unit}`.trim()
//     : null;

//   const matchStage = {
//     "sourceDetails.tagId": new mongoose.Types.ObjectId(tagId),
//     triggeredAt:           { $gte: start, $lte: end },
//   };

//   // ── Count total for pagination ─────────────────────────────────────────
//   const totalDataCount = await SetpointDeviationEvent.countDocuments(matchStage);
//   if (!totalDataCount) return emptyResult;

//   const totalPageCount = Math.ceil(totalDataCount / limitNum);

//   // ── Aggregation pipeline ───────────────────────────────────────────────
//   const deviationDocs = await SetpointDeviationEvent.aggregate([

//     // STEP 1: Filter by tagId + time range
//     { $match: matchStage },

//     // STEP 2: Sort + paginate
//     { $sort:  { triggeredAt: -1 } },
//     { $skip:  skipCount },
//     { $limit: limitNum },

//     // STEP 3: Join liveData_test using liveDataRefs array
//     {
//       $lookup: {
//         from:         "liveData_test",
//         localField:   "liveDataRefs",
//         foreignField: "_id",
//         as:           "liveDataDocs",
//       },
//     },

//     // STEP 4: Join tag_lives using tag_id from each liveData doc
//     {
//       $lookup: {
//         from: "tag_lives",
//         let:  { liveDataDocs: "$liveDataDocs" },
//         pipeline: [
//           {
//             $match: {
//               $expr: {
//                 $in: [
//                   "$_id",
//                   {
//                     $map: {
//                       input: "$$liveDataDocs",
//                       as:    "ld",
//                       in:    "$$ld.tag_id",
//                     },
//                   },
//                 ],
//               },
//             },
//           },
//           {
//             $project: {
//               tagname:     1,
//               unit:        1,
//               ranges:      1,
//               plcName:     1,
//               isActive:    1,
//               latestValue: 1,
//               datatype:    1,
//               health:      1,
//             },
//           },
//         ],
//         as: "tagDocs",
//       },
//     },

//     // STEP 5: Merge tagDetails into each liveData doc
//     {
//       $addFields: {
//         liveDataRefs: {
//           $map: {
//             input: "$liveDataDocs",
//             as:    "ld",
//             in: {
//               _id:       "$$ld._id",
//               value:     "$$ld.value",
//               timestamp: "$$ld.timestamp",
//               tagDetails: {
//                 $arrayElemAt: [
//                   {
//                     $filter: {
//                       input: "$tagDocs",
//                       as:    "tag",
//                       cond:  { $eq: ["$$tag._id", "$$ld.tag_id"] },
//                     },
//                   },
//                   0,
//                 ],
//               },
//             },
//           },
//         },
//       },
//     },

//     // STEP 6: Clean up raw arrays
//     {
//       $project: {
//         liveDataDocs: 0,
//         tagDocs:      0,
//       },
//     },
//   ]);

//   // ── Format response ────────────────────────────────────────────────────
//   const data = deviationDocs.map((doc) => ({
//     id:             doc._id,
//     severity:       "warning",
//     fault:          doc.deviationType ?? null,
//     breachDateTime: doc.triggeredAt   ?? null,
//     setPointBreach: doc.value         ?? null,
//     unit,
//     setPointLimit,
//     message:        `${doc.sourceDetails?.tagname ?? "Tag"} deviated from setpoint (${doc.deviationType}) with value ${doc.value}`,
//     liveDataRefs:   (doc.liveDataRefs || []).map((ld) => ({
//       _id:       ld._id,
//       value:     ld.value     ?? null,
//       timestamp: ld.timestamp ?? null,
//       tagDetails: ld.tagDetails
//         ? {
//             _id:         ld.tagDetails._id,
//             tagname:     ld.tagDetails.tagname     ?? null,
//             latestValue: ld.tagDetails.latestValue ?? null,
//             unit:        ld.tagDetails.unit        ?? null,
//             ranges:      ld.tagDetails.ranges      ?? null,
//             plcName:     ld.tagDetails.plcName     ?? null,
//             isActive:    ld.tagDetails.isActive    ?? null,
//             datatype:    ld.tagDetails.datatype    ?? null,
//             health:      ld.tagDetails.health      ?? null,
//           }
//         : null,
//     })),
//   }));

//   return {
//     currentPage:    pageNum,
//     totalPageCount,
//     totalDataCount,
//     data,
//   };
// }



// async function getTagAnomalies({ tagId, startTime, endTime, limit = 10, page = 1 }) {

//   if (!mongoose.Types.ObjectId.isValid(tagId)) {
//     throw new Error("Invalid tagId format. Must be a valid ObjectId.");
//   }

//   const start = new Date(startTime);
//   const end   = new Date(endTime);

//   if (isNaN(start.getTime()) || isNaN(end.getTime())) {
//     throw new Error("Invalid startTime or endTime. Must be valid ISO 8601 dates.");
//   }

//   if (start >= end) {
//     throw new Error("startTime must be before endTime.");
//   }

//   const pageNum   = Math.max(1, parseInt(page));
//   const limitNum  = Math.min(100, Math.max(1, parseInt(limit)));
//   const skipCount = (pageNum - 1) * limitNum;

//   const emptyResult = {
//     currentPage:    pageNum,
//     totalPageCount: 0,
//     totalDataCount: 0,
//     data:           [],
//   };

//   // ── Fetch TagLive for unit + setPointLimit ─────────────────────────────
//   const tagLive = await TagLive.findOne(
//     { _id: new mongoose.Types.ObjectId(tagId), isActive: true },
//     { ranges: 1, unit: 1 }
//   ).lean();

//   const unit                   = tagLive?.unit ?? "";
//   const { minValue, maxValue } = tagLive?.ranges || {};
//   const setPointLimit          = (minValue != null && maxValue != null)
//     ? `${minValue}-${maxValue}`.trim()
//     : null;

//   // ── sourceDetails.tagId is stored as STRING in DB ──────────────────────
//   const matchStage = {
//     "sourceDetails.tagId": new mongoose.Types.ObjectId(tagId),               // ← string not ObjectId
//     triggeredAt:           { $gte: start, $lte: end },
//   };

//   console.log("???",matchStage)


//   // ── Count total for pagination ─────────────────────────────────────────
//   const totalDataCount = await SetpointDeviationEvent.countDocuments(matchStage);
//   if (!totalDataCount) return emptyResult;

//   console.log("TTTT",totalDataCount)

//   const totalPageCount = Math.ceil(totalDataCount / limitNum);

//   // ── Aggregation pipeline ───────────────────────────────────────────────
//   // const deviationDocs = await SetpointDeviationEvent.aggregate([
//   //   { $match: matchStage },
//   //   { $sort:  { triggeredAt: -1 } },
//   //   { $skip:  skipCount },
//   //   { $limit: limitNum },
//   //   // Join liveData_test using liveDataRefs array
//   //   {
//   //     $lookup: {
//   //       from:         "liveData_test",
//   //       localField:   "liveDataRefs",
//   //       foreignField: "_id",
//   //       as:           "liveDataDocs",
//   //     },
//   //   },
//   //   // Join tag_lives using tag_id from each liveData doc
//   //   {
//   //     $lookup: {
//   //       from: "tag_lives",
//   //       let:  { liveDataDocs: "$liveDataDocs" },
//   //       pipeline: [
//   //         {
//   //           $match: {
//   //             $expr: {
//   //               $in: [
//   //                 "$_id",
//   //                 {
//   //                   $map: {
//   //                     input: "$$liveDataDocs",
//   //                     as:    "ld",
//   //                     in:    "$$ld.tag_id",
//   //                   },
//   //                 },
//   //               ],
//   //             },
//   //           },
//   //         },
//   //         {
//   //           $project: {
//   //             tagname:     1,
//   //             unit:        1,
//   //             ranges:      1,
//   //             plcName:     1,
//   //             isActive:    1,
//   //             latestValue: 1,
//   //             datatype:    1,
//   //             health:      1,
//   //           },
//   //         },
//   //       ],
//   //       as: "tagDocs",
//   //     },
//   //   },
//   //   // Merge tagDetails into each liveData doc
//   //   {
//   //     $addFields: {
//   //       liveDataRefs: {
//   //         $map: {
//   //           input: "$liveDataDocs",
//   //           as:    "ld",
//   //           in: {
//   //             _id:       "$$ld._id",
//   //             value:     "$$ld.value",
//   //             timestamp: "$$ld.timestamp",
//   //             tagDetails: {
//   //               $arrayElemAt: [
//   //                 {
//   //                   $filter: {
//   //                     input: "$tagDocs",
//   //                     as:    "tag",
//   //                     cond:  { $eq: ["$$tag._id", "$$ld.tag_id"] },
//   //                   },
//   //                 },
//   //                 0,
//   //               ],
//   //             },
//   //           },
//   //         },
//   //       },
//   //     },
//   //   },
//   //   // Remove raw joined arrays
//   //   {
//   //     $project: {
//   //       liveDataDocs: 0,
//   //       tagDocs:      0,
//   //     },
//   //   },
//   // ]);

//   // const deviationDocs = await SetpointDeviationEvent.aggregate([
//   //   { $match: matchStage },
//   //   { $sort:  { triggeredAt: -1 } },
//   //   { $skip:  skipCount },
//   //   { $limit: limitNum },

//   //   // STEP 1: Join liveData_test using liveDataRefs array
//   //   {
//   //     $lookup: {
//   //       from:         "liveData_test",
//   //       localField:   "liveDataRefs",
//   //       foreignField: "_id",
//   //       as:           "joinedLiveData",
//   //     },
//   //   },

//   //   // STEP 2: Extract tag_ids from joined liveData into a temp field
//   //   {
//   //     $addFields: {
//   //       _tagIds: {
//   //         $map: {
//   //           input: "$joinedLiveData",
//   //           as:    "ld",
//   //           in:    "$$ld.tag_id",
//   //         },
//   //       },
//   //     },
//   //   },

//   //   // STEP 3: Simple $lookup on tag_lives using extracted _tagIds
//   //   {
//   //     $lookup: {
//   //       from:         "tag_lives",
//   //       localField:   "_tagIds",
//   //       foreignField: "_id",
//   //       as:           "joinedTagDocs",
//   //     },
//   //   },

//   //   // STEP 4: Merge tagDetails into each liveData item
//   //   {
//   //     $addFields: {
//   //       liveDataRefs: {
//   //         $map: {
//   //           input: "$joinedLiveData",
//   //           as:    "ld",
//   //           in: {
//   //             _id:       "$$ld._id",
//   //             value:     "$$ld.value",
//   //             timestamp: "$$ld.timestamp",
//   //             tagDetails: {
//   //               $arrayElemAt: [
//   //                 {
//   //                   $filter: {
//   //                     input: "$joinedTagDocs",
//   //                     as:    "tag",
//   //                     cond:  { $eq: ["$$tag._id", "$$ld.tag_id"] },
//   //                   },
//   //                 },
//   //                 0,
//   //               ],
//   //             },
//   //           },
//   //         },
//   //       },
//   //     },
//   //   },

//   //   // STEP 5: Clean up temp fields
//   //   {
//   //     $project: {
//   //       joinedLiveData: 0,
//   //       joinedTagDocs:  0,
//   //       _tagIds:        0,
//   //     },
//   //   },
//   // ]);

//   const deviationDocs = await SetpointDeviationEvent.aggregate([
//     { $match: matchStage },
//     { $sort:  { triggeredAt: -1 } },
//     { $skip:  skipCount },
//     { $limit: limitNum },

//     // STEP 1: Join liveData_test using liveDataRefs array
//     {
//       $lookup: {
//         from:         "liveData_test",
//         localField:   "liveDataRefs",
//         foreignField: "_id",
//         as:           "joinedLiveData",
//       },
//     },

//     // STEP 2: Join tag_lives directly using liveDataRefs → tag_id
//     {
//       $lookup: {
//         from:         "tag_lives",
//         localField:   "joinedLiveData.tag_id",  // ← direct path, no $map needed
//         foreignField: "_id",
//         as:           "joinedTagDocs",
//       },
//     },

//     // STEP 3: Merge tagDetails into each liveData item
//     {
//       $addFields: {
//         liveDataRefs: {
//           $map: {
//             input: "$joinedLiveData",
//             as:    "ld",
//             in: {
//               _id:       "$$ld._id",
//               value:     "$$ld.value",
//               timestamp: "$$ld.timestamp",
//               tagDetails: {
//                 $arrayElemAt: [
//                   {
//                     $filter: {
//                       input: "$joinedTagDocs",
//                       as:    "tag",
//                       cond:  { $eq: ["$$tag._id", "$$ld.tag_id"] },
//                     },
//                   },
//                   0,
//                 ],
//               },
//             },
//           },
//         },
//       },
//     },

//     // STEP 4: Clean up
//     {
//       $project: {
//         joinedLiveData: 0,
//         joinedTagDocs:  0,
//       },
//     },
//   ]);


//   // console.log("<<<<<>>>>>",deviationDocs)

// // return

//   // ── Format response ────────────────────────────────────────────────────
//   const data = deviationDocs.map((doc) => ({
//     id:             doc._id,
//     severity:       "warning",
//     fault:          doc.deviationType ?? null,
//     breachDateTime: doc.triggeredAt   ?? null,
//     setPointBreach: doc.value         ?? null,
//     unit,
//     setPointLimit,
//     message:        `${doc.sourceDetails?.tagname ?? "Tag"} deviated from setpoint (${doc.deviationType}) with value ${doc.value}`,
//     liveDataRefs:   (doc.liveDataRefs || []).map((ld) => ({
//       _id:       ld._id,
//       value:     ld.value     ?? null,
//       timestamp: ld.timestamp ?? null,
//       tagDetails: ld.tagDetails
//         ? {
//             _id:         ld.tagDetails._id,
//             tagname:     ld.tagDetails.tagname     ?? null,
//             latestValue: ld.tagDetails.latestValue ?? null,
//             unit:        ld.tagDetails.unit        ?? null,
//             ranges:      ld.tagDetails.ranges      ?? null,
//             plcName:     ld.tagDetails.plcName     ?? null,
//             isActive:    ld.tagDetails.isActive    ?? null,
//             datatype:    ld.tagDetails.datatype    ?? null,
//             health:      ld.tagDetails.health      ?? null,
//           }
//         : null,
//     })),
//   }));

//   return {
//     currentPage:    pageNum,
//     totalPageCount,
//     totalDataCount,
//     data,
//   };
// }

// new fast - cache anomaly 
async function getTagAnomaliesFast({ tagIds, startTime, endTime, limit = 10, page = 1 }) {
  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(100, Math.max(1, parseInt(limit)));
  const skip = (pageNum - 1) * limitNum;

  const objectIds = tagIds.map((id) => new mongoose.Types.ObjectId(id));

  const match = {
    tagId: objectIds.length === 1 ? objectIds[0] : { $in: objectIds },
    breachDateTime: {
      $gte: new Date(startTime),
      $lte: new Date(endTime),
    },
  };

  const [rows, total] = await Promise.all([
    TagAnomalyCache.find(match)
      // .sort({ breachDateTime: -1 })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum)
      .lean(),

    TagAnomalyCache.countDocuments(match),
  ]);

  return {
    currentPage: pageNum,
    totalPageCount: Math.ceil(total / limitNum),
    totalDataCount: total,
    data: rows.map((r) => ({
      ...r.payload,
      acknowledged: r.acknowledged ?? false,
    })),
  };
}

// old
async function getTagAnomalies({ tagId, startTime, endTime, limit = 10, page = 1 }) {
 
  if (!mongoose.Types.ObjectId.isValid(tagId)) {
    throw new Error("Invalid tagId format. Must be a valid ObjectId.");
  }
 
  const start = new Date(startTime);
  const end   = new Date(endTime);
 
  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    throw new Error("Invalid startTime or endTime. Must be valid ISO 8601 dates.");
  }
 
  if (start >= end) {
    throw new Error("startTime must be before endTime.");
  }
 
  const pageNum   = Math.max(1, parseInt(page));
  const limitNum  = Math.min(100, Math.max(1, parseInt(limit)));
  const skipCount = (pageNum - 1) * limitNum;
 
  const emptyResult = {
    currentPage:    pageNum,
    totalPageCount: 0,
    totalDataCount: 0,
    data:           [],
  };
 
  // ── STEP 1: Fetch TagLive for unit + setPointLimit ─────────────────────
  const tagLive = await TagLive.findOne(
    { _id: new mongoose.Types.ObjectId(tagId), isActive: true },
    { ranges: 1, unit: 1 }
  ).lean();
 
  const unit                   = tagLive?.unit ?? "";
  const { minValue, maxValue } = tagLive?.ranges || {};
  const setPointLimit          = (minValue != null && maxValue != null)
    ? `${minValue}-${maxValue} ${unit}`.trim()
    : null;
 
  const matchStage = {
    "sourceDetails.tagId": new mongoose.Types.ObjectId(tagId),
    triggeredAt:           { $gte: start, $lte: end },
  };
 
  // ── STEP 2: Count for pagination ───────────────────────────────────────
  const totalDataCount = await SetpointDeviationEvent.countDocuments(matchStage);
  if (!totalDataCount) return emptyResult;
 
  const totalPageCount = Math.ceil(totalDataCount / limitNum);
 
  // ── STEP 3: Fetch paginated deviation events (no $lookup) ──────────────
  const deviationDocs = await SetpointDeviationEvent.find(matchStage)
    .sort({ triggeredAt: -1 })
    .skip(skipCount)
    .limit(limitNum)
    .lean();
 
  // ── STEP 4: Collect all liveDataRef ids from deviation docs ────────────
  const allRefIds = deviationDocs
    .flatMap((d) => d.liveDataRefs || [])
    .map((id) => new mongoose.Types.ObjectId(id));
 
  // ── STEP 5: Fetch liveData records by _id (fast — uses _id index) ──────
  const liveDataRecords = await TagHistory.find(
    { _id: { $in: allRefIds } },
    { tag_id: 1, value: 1, timestamp: 1 }
  ).lean();
 
  // ── STEP 6: Collect unique tag_ids from liveData records ───────────────
  const uniqueTagIds = [
    ...new Set(liveDataRecords.map((r) => r.tag_id?.toString()).filter(Boolean)),
  ].map((id) => new mongoose.Types.ObjectId(id));
 
  // ── STEP 7: Fetch tag_lives for those tag_ids ──────────────────────────
  const tagLiveDocs = await TagLive.find(
    { _id: { $in: uniqueTagIds } },
    { tagname: 1, unit: 1, ranges: 1, plcName: 1, isActive: 1, latestValue: 1, datatype: 1, health: 1 }
  ).lean();
 
  // ── Build lookup maps ──────────────────────────────────────────────────
  // liveData _id → record
  const liveDataMap = {};
  liveDataRecords.forEach((r) => {
    liveDataMap[r._id.toString()] = r;
  });
 
  // tag _id → tag details
  const tagLiveMap = {};
  tagLiveDocs.forEach((t) => {
    tagLiveMap[t._id.toString()] = t;
  });
 
  // ── STEP 8: Format response ────────────────────────────────────────────
  const data = deviationDocs.map((doc) => ({
    id:             doc._id,
    severity:       "warning",
    fault:          doc.deviationType ?? null,
    breachDateTime: doc.triggeredAt   ?? null,
    setPointBreach: doc.value         ?? null,
    unit,
    setPointLimit,
    message:        `${doc.sourceDetails?.tagname ?? "Tag"} deviated from setpoint (${doc.deviationType}) with value ${doc.value}`,
    tagDetails: {
      tagId: doc.sourceDetails?.tagId ?? null,
      tagname: doc.sourceDetails?.tagname ?? null,
      unit: doc.sourceDetails?.unit ?? null,
      ranges: doc.sourceDetails?.ranges ?? null,
    },
    liveDataRefs:   (doc.liveDataRefs || []).map((refId) => {
      const rec     = liveDataMap[refId.toString()];
      const tagDetail = rec?.tag_id ? tagLiveMap[rec.tag_id.toString()] : null;
      return {
        _id:       refId,
        value:     rec?.value     ?? null,
        timestamp: rec?.timestamp ?? null,
        tagDetails: tagDetail
          ? {
              _id:         tagDetail._id,
              tagname:     tagDetail.tagname     ?? null,
              latestValue: tagDetail.latestValue ?? null,
              unit:        tagDetail.unit        ?? null,
              ranges:      tagDetail.ranges      ?? null,
              plcName:     tagDetail.plcName     ?? null,
              isActive:    tagDetail.isActive    ?? null,
              datatype:    tagDetail.datatype    ?? null,
              health:      tagDetail.health      ?? null,
            }
          : null,
      };
    }),
  }));
 
  return {
    currentPage:    pageNum,
    totalPageCount,
    totalDataCount,
    data,
  };
}


// 2
// async function getTagAnomalies({
//   tagId,
//   startTime,
//   endTime,
//   limit = 10,
//   page = 1,
//   maxRefsPerEvent = 50, // 🔥 NEW: Limit refs per event
// }) {
//   if (!mongoose.Types.ObjectId.isValid(tagId)) {
//     throw new Error("Invalid tagId format. Must be a valid ObjectId.");
//   }

//   const start = new Date(startTime);
//   const end = new Date(endTime);

//   if (isNaN(start.getTime()) || isNaN(end.getTime())) {
//     throw new Error("Invalid startTime or endTime. Must be valid ISO 8601 dates.");
//   }

//   if (start >= end) {
//     throw new Error("startTime must be before endTime.");
//   }

//   const pageNum = Math.max(1, parseInt(page));
//   const limitNum = Math.min(100, Math.max(1, parseInt(limit)));
//   const skipCount = (pageNum - 1) * limitNum;

//   const emptyResult = {
//     currentPage: pageNum,
//     totalPageCount: 0,
//     totalDataCount: 0,
//     data: [],
//   };

//   const tagObjectId = new mongoose.Types.ObjectId(tagId);
//   const matchStage = {
//     "sourceDetails.tagId": tagObjectId,
//     triggeredAt: { $gte: start, $lte: end },
//   };

//   // 🔥 OPTIMIZATION 1: Parallel queries for Step 1 & 2
//   const [tagLive, totalDataCount] = await Promise.all([
//     TagLive.findOne(
//       { _id: tagObjectId, isActive: true },
//       { ranges: 1, unit: 1 }
//     ).lean(),
//     SetpointDeviationEvent.countDocuments(matchStage),
//   ]);

//   if (!totalDataCount) return emptyResult;

//   const unit = tagLive?.unit ?? "";
//   const { minValue, maxValue } = tagLive?.ranges || {};
//   const setPointLimit =
//     minValue != null && maxValue != null
//       ? `${minValue}-${maxValue} ${unit}`.trim()
//       : null;

//   const totalPageCount = Math.ceil(totalDataCount / limitNum);

//   // 🔥 OPTIMIZATION 2: Limit liveDataRefs in projection
//   const deviationDocs = await SetpointDeviationEvent.find(matchStage, {
//     _id: 1,
//     deviationType: 1,
//     triggeredAt: 1,
//     value: 1,
//     "sourceDetails.tagId": 1,
//     "sourceDetails.tagname": 1,
//     "sourceDetails.unit": 1,
//     "sourceDetails.ranges": 1,
//     liveDataRefs: { $slice: maxRefsPerEvent }, // 🔥 Limit refs
//   })
//     .sort({ triggeredAt: -1 })
//     .skip(skipCount)
//     .limit(limitNum)
//     .lean();

//   // 🔥 OPTIMIZATION 3: Collect limited refs
//   const allRefIds = deviationDocs
//     .flatMap((d) => (d.liveDataRefs || []).slice(0, maxRefsPerEvent))
//     .map((id) => new mongoose.Types.ObjectId(id));

//   if (!allRefIds.length) {
//     return {
//       currentPage: pageNum,
//       totalPageCount,
//       totalDataCount,
//       data: deviationDocs.map((doc) => ({
//         id: doc._id,
//         severity: "warning",
//         fault: doc.deviationType ?? null,
//         breachDateTime: doc.triggeredAt ?? null,
//         setPointBreach: doc.value ?? null,
//         unit,
//         setPointLimit,
//         message: `${doc.sourceDetails?.tagname ?? "Tag"} deviated from setpoint (${doc.deviationType}) with value ${doc.value}`,
//         tagDetails: {
//           tagId: doc.sourceDetails?.tagId ?? null,
//           tagname: doc.sourceDetails?.tagname ?? null,
//           unit: doc.sourceDetails?.unit ?? null,
//           ranges: doc.sourceDetails?.ranges ?? null,
//         },
//         liveDataRefs: [],
//       })),
//     };
//   }

//   // 🔥 OPTIMIZATION 4: Fetch liveData and extract tag_ids in one pass
//   const liveDataRecords = await TagHistory.find(
//     { _id: { $in: allRefIds } },
//     { tag_id: 1, value: 1, timestamp: 1 }
//   ).lean();

//   // Build liveData map and collect unique tag_ids simultaneously
//   const liveDataMap = new Map();
//   const uniqueTagIdsSet = new Set();

//   liveDataRecords.forEach((r) => {
//     liveDataMap.set(r._id.toString(), r);
//     if (r.tag_id) {
//       uniqueTagIdsSet.add(r.tag_id.toString());
//     }
//   });

//   const uniqueTagIds = Array.from(uniqueTagIdsSet).map(
//     (id) => new mongoose.Types.ObjectId(id)
//   );

//   // 🔥 OPTIMIZATION 5: Fetch only if we have tag_ids
//   let tagLiveMap = new Map();
  
//   if (uniqueTagIds.length > 0) {
//     const tagLiveDocs = await TagLive.find(
//       { _id: { $in: uniqueTagIds } },
//       {
//         tagname: 1,
//         unit: 1,
//         ranges: 1,
//         plcName: 1,
//         isActive: 1,
//         latestValue: 1,
//         datatype: 1,
//         health: 1,
//       }
//     ).lean();

//     tagLiveDocs.forEach((t) => {
//       tagLiveMap.set(t._id.toString(), t);
//     });
//   }

//   // 🔥 OPTIMIZATION 6: Format response with Map lookups (faster than object)
//   const data = deviationDocs.map((doc) => ({
//     id: doc._id,
//     severity: "warning",
//     fault: doc.deviationType ?? null,
//     breachDateTime: doc.triggeredAt ?? null,
//     setPointBreach: doc.value ?? null,
//     unit,
//     setPointLimit,
//     message: `${doc.sourceDetails?.tagname ?? "Tag"} deviated from setpoint (${doc.deviationType}) with value ${doc.value}`,
//     tagDetails: {
//       tagId: doc.sourceDetails?.tagId ?? null,
//       tagname: doc.sourceDetails?.tagname ?? null,
//       unit: doc.sourceDetails?.unit ?? null,
//       ranges: doc.sourceDetails?.ranges ?? null,
//     },
//     liveDataRefs: (doc.liveDataRefs || [])
//       .slice(0, maxRefsPerEvent)
//       .map((refId) => {
//         const refIdStr = refId.toString();
//         const rec = liveDataMap.get(refIdStr);
//         const tagDetail = rec?.tag_id ? tagLiveMap.get(rec.tag_id.toString()) : null;
        
//         return {
//           _id: refId,
//           value: rec?.value ?? null,
//           timestamp: rec?.timestamp ?? null,
//           tagDetails: tagDetail
//             ? {
//                 _id: tagDetail._id,
//                 tagname: tagDetail.tagname ?? null,
//                 latestValue: tagDetail.latestValue ?? null,
//                 unit: tagDetail.unit ?? null,
//                 ranges: tagDetail.ranges ?? null,
//                 plcName: tagDetail.plcName ?? null,
//                 isActive: tagDetail.isActive ?? null,
//                 datatype: tagDetail.datatype ?? null,
//                 health: tagDetail.health ?? null,
//               }
//             : null,
//         };
//       }),
//   }));

//   return {
//     currentPage: pageNum,
//     totalPageCount,
//     totalDataCount,
//     data,
//   };
// }


// these code is added for getting the data from 6am to 7pm (this is commented as the format compact & points came into functionality - recently commented)
// async function getRawPoints({ tagId, startTime, endTime }) {

//   if (!mongoose.Types.ObjectId.isValid(tagId)) {
//     throw new Error("Invalid tagId format");
//   }

//   const start = new Date(startTime);
//   const end   = new Date(endTime);

//   const tagObjectId = new mongoose.Types.ObjectId(tagId);

//   // =========================
//   // RAW WINDOW (UNCHANGED)
//   // =========================
//   const rawStart = new Date(start);
//   rawStart.setUTCHours(0, 30, 0, 0);

//   const now = new Date();

//   const rawEnd = new Date(start);
//   rawEnd.setUTCHours(
//     now.getUTCHours(),
//     now.getUTCMinutes(),
//     now.getUTCSeconds(),
//     now.getUTCMilliseconds()
//   );

//   const maxRawEnd = new Date(start);
//   maxRawEnd.setUTCHours(13, 30, 0, 0);

//   if (rawEnd > maxRawEnd) {
//     rawEnd.setTime(maxRawEnd.getTime());
//   }

//   console.log("Raw Query Range:", rawStart, "to", rawEnd);

//   // =========================
//   // FUTURE WINDOW (UNCHANGED)
//   // =========================
//   const futureStart = new Date(start);
//   futureStart.setUTCHours(0, 30, 0, 0);

//   const futureEnd = new Date(start);
//   futureEnd.setUTCHours(13, 30, 0, 0);

//   console.log("Future Query Range:", futureStart, "to", futureEnd);

//   const forecastCollection =
//     mongoose.connection.db.collection("aiforecast");

//   // =========================
//   // OPTIMIZED QUERIES
//   // =========================
//   const [rawDocs, futureDocs] = await Promise.all([

//     // 🔥 RAW (aggregation instead of cursor + JS Set)
//     TagHistory.aggregate([
//       {
//         $match: {
//           tag_id: tagObjectId,
//           timestamp: { $gte: rawStart, $lte: rawEnd },
//         },
//       },
//       { $sort: { timestamp: 1 } },

//       // remove duplicates at DB level
//       {
//         $group: {
//           _id: {
//             timestamp: "$timestamp",
//             value: "$value",
//           },
//           timestamp: { $first: "$timestamp" },
//           value: { $first: "$value" },
//         },
//       },
//       { $sort: { timestamp: 1 } },

//       // { $limit: 10000 } // safety cap
//     ]),

//     // 🔥 FUTURE (toArray instead of cursor loop)
//     forecastCollection
//       .find(
//         {
//           tagId: tagObjectId,
//           timestamp: {
//             $gte: futureStart,
//             $lt: futureEnd,
//           },
//         },
//         {
//           projection: {
//             timestamp: 1,
//             predictedValue: 1,
//             _id: 0,
//           },
//         }
//       )
//       .sort({ timestamp: 1 })
//       // .limit(10000) // prevent large scan
//       .toArray()
//   ]);

//   // =========================
//   // FORMAT OUTPUT
//   // =========================
//   // const rawPoints = rawDocs.map((doc) => ({
//   //   timestamp: doc.timestamp,
//   //   value: doc.value,
//   // }));

//   // format output change for demo - size decrease
//   const rawPoints = rawDocs.map(doc => doc.value);
//   const futureValues = futureDocs.map(doc => doc.predictedValue);

//   const futureStartTime = futureDocs.length ? futureDocs[0].timestamp : null;
//   const futureEndTime = futureDocs.length ? futureDocs[futureDocs.length - 1].timestamp : null;

//   // const future = futureDocs.map((doc) => ({
//   //   timestamp: doc.timestamp,
//   //   value: doc.predictedValue,
//   // }));

//   return {
//     tagId,
//     rawPoints,
//     future: {
//     start: futureStartTime,
//     end: futureEndTime,
//     values: futureValues // [3.1, 3.2, 3.3...]
//     }
//   };
// }

// these are commented as the above code is used staticly, if required for production uncomment these

// async function getRawPoints({ tagId, startTime, endTime }) {

//   if (!mongoose.Types.ObjectId.isValid(tagId)) {
//     throw new Error("Invalid tagId format");
//   }

//   const start = new Date(startTime);
//   const end   = new Date(endTime);

//   if (isNaN(start) || isNaN(end)) {
//     throw new Error("Invalid dates");
//   }

//   if (start >= end) {
//     throw new Error("startTime must be before endTime");
//   }

//   const tagObjectId = new mongoose.Types.ObjectId(tagId);

//   // 🔹 RAW POINTS
//   const rawCursor = TagHistory.find({
//     tag_id: tagObjectId,
//     timestamp: { $gte: start, $lte: end },
//   })
//     .sort({ timestamp: 1 })
//     .select({ timestamp: 1, value: 1, _id: 0 })
//     .lean()
//     .cursor();

//   const rawPoints = [];
//   const MAX_POINTS = 5000;

//   for (let doc = await rawCursor.next(); doc != null; doc = await rawCursor.next()) {
//     rawPoints.push({
//       timestamp: doc.timestamp,
//       value: doc.value,
//     });

//     // if (rawPoints.length >= MAX_POINTS) break;
//   }

//   // 🔹 FUTURE (aiforecast collection)
//   const forecastCollection = mongoose.connection.db.collection("aiforecast");

//   const futureCursor = forecastCollection.find(
//     {
//       tagId: tagObjectId,
//       timestamp: { $gte: start, $lte: end },
//     },
//     {
//       projection: { timestamp: 1, predictedValue: 1, _id: 0 },
//     }
//   ).sort({ timestamp: 1 });

//   const future = [];

//   for (let doc = await futureCursor.next(); doc != null; doc = await futureCursor.next()) {
//     future.push({
//       timestamp: doc.timestamp,
//       value: doc.predictedValue,
//     });
//   }
//   console.log("countssss",future.length,rawPoints.length)

//   return {
//     tagId,
//     rawPoints,
//     future,
//   };
// }

// old forcast api
// async function getRawPoints({
//   tagId,
//   startTime,
//   endTime,
//   interval,
//   aggregation,
//   format = "compact"
// }) {

//   if (!tagId ||!startTime ||!endTime ||!interval ||!aggregation) {
//     throw new Error("Missing required parameters");
//   }

//   if (!mongoose.Types.ObjectId.isValid(tagId)) {
//     throw new Error("Invalid tagId");
//   }

//   const allowedAggregations = ["avg","sum","min","max","count","first","last"];

//   if (!allowedAggregations.includes(aggregation)) {
//     throw new Error("Invalid aggregation");
//   }

//   const intervalMs = parseISODuration(interval);

//   const tagObjectId = new mongoose.Types.ObjectId(tagId);

//   const start = new Date(startTime);
//   const end = new Date(endTime);

//   if (isNaN(start) || isNaN(end)) {
//     throw new Error("Invalid date");
//   }

//   const rawStart = new Date(start);

//   const rawEnd = new Date(end);
//  // if only date is passed
// // if (startTime.length === 10) {
// //   rawStart.setUTCHours(0, 0, 0, 0);
// // }

// // if (endTime.length === 10) {
// //   rawEnd.setUTCHours(23, 59, 59, 999);
// // }


//   const forecastCollection =mongoose.connection.db.collection("aiforecast");

//   // =========================
//   // RAW DATA AGGREGATION
//   // =========================

//   const rawPromise = TagHistory.aggregate([

//     {
//       $match: {
//         tag_id: tagObjectId,
//         timestamp: {
//           $gte: rawStart,
//           $lte: rawEnd
//         }
//       }
//     },

//     {
//       $project: {
//         timestamp: 1,
//         value: 1
//       }
//     },

//     {
//       $sort: {
//         timestamp: 1
//       }
//     },

//     {
//       $group: {

//         _id: {
//           bucket: {
//             $toDate: {
//               // $subtract: [
//               //   { $toLong: "$timestamp" },
//               //   {
//               //     $mod: [
//               //       { $toLong: "$timestamp" },
//               //       intervalMs
//               //     ]
//               $subtract: [
//                 { $toLong: "$timestamp" },
//                 {
//                   $mod: [
//                     {
//                       $subtract: [
//                         { $toLong: "$timestamp" },
//                         rawStart.getTime()
//                       ]
//                     },
//                     intervalMs
//                   ]
//                 }
//               ]
//             }
//           }
//         },

//         avg: { $avg: "$value" },
//         sum: { $sum: "$value" },
//         min: { $min: "$value" },
//         max: { $max: "$value" },
//         count: { $sum: 1 },
//         first: { $first: "$value" },
//         last: { $last: "$value" },
//         firstTimestamp: { $first: "$timestamp" },
//         lastTimestamp: { $last: "$timestamp" }
//       }
//     },

//     {
//       $sort: {
//         "_id.bucket": 1
//       }
//     }

//   ]);

//   // =========================
//   // FORECAST AGGREGATION
//   // =========================

//   const forecastPromise = forecastCollection.aggregate([

//     {
//       $match: {
//         tagId: tagObjectId,
//         timestamp: {
//           $gte: rawStart,
//           $lte: rawEnd
//         }
//       }
//     },

//     {
//       $project: {
//         timestamp: 1,
//         value: "$predictedValue"
//       }
//     },

//     {
//       $sort: {
//         timestamp: 1
//       }
//     },

//     {
//       $group: {

//         _id: {
//           bucket: {
//             $toDate: {
//               $subtract: [
//                 { $toLong: "$timestamp" },
//                 {
//                   $mod: [
//                     { $toLong: "$timestamp" },
//                     intervalMs
//                   ]
//                 }
//               ]
//             }
//           }
//         },

//         avg: { $avg: "$value" },
//         sum: { $sum: "$value" },
//         min: { $min: "$value" },
//         max: { $max: "$value" },
//         count: { $sum: 1 },
//         first: { $first: "$value" },
//         last: { $last: "$value" },
//         firstTimestamp: { $first: "$timestamp" },
//         lastTimestamp: { $last: "$timestamp" }
//       }
//     },

//     {
//       $sort: {
//         "_id.bucket": 1
//       }
//     }

//   ]).toArray();

//   // =========================
//   // EXECUTE IN PARALLEL
//   // =========================

//   const [rawDocs, futureDocs] = await Promise.all([
//     rawPromise,
//     forecastPromise
//   ]);

//   // =========================
//   // AGGREGATION VALUE PICKER
//   // =========================

//   function getValue(doc) {

//     switch (aggregation) {

//       case "avg":
//         return doc.avg;

//       case "sum":
//         return doc.sum;

//       case "min":
//         return doc.min;

//       case "max":
//         return doc.max;

//       case "count":
//         return doc.count;

//       case "first":
//         return doc.first;

//       case "last":
//         return doc.last;

//       default:
//         return null;
//     }
//   }

//   // =========================
//   // FORMAT HISTORICAL
//   // =========================

//   const historicalPoints = rawDocs.map(doc => ({
//     ts: doc._id.bucket.toISOString(),
//     value: Number(Number(getValue(doc)))
//   }));

//   // =========================
//   // FORMAT FORECAST
//   // =========================

//   const forecastPoints = futureDocs.map(doc => ({
//     ts: doc._id.bucket.toISOString(),
//     value: Number(Number(getValue(doc)))
//   }));

//   // =========================
//   // RESPONSE
//   // =========================

//   if (format === "points") {
//     return {
//       tagId,
//       meta: {
//         aggregation,
//         interval
//       },
//       historical: historicalPoints,
//       forecast: forecastPoints
//     };
//   }

//   // =========================
//   // COMPACT FORMAT
//   // =========================

//   return {
//     tagId,
//     meta: {
//       aggregation,
//       interval
//     },
//     historical: {

//   start:
//     rawDocs.length
//       ? rawDocs[0].firstTimestamp.toISOString()
//       : null,

//   end:
//     rawDocs.length
//       ? rawDocs[rawDocs.length - 1].lastTimestamp.toISOString()
//       : null,

//   values:
//     historicalPoints.map(p => p.value)
// },
//     forecast: {

//   start:
//     futureDocs.length
//       ? futureDocs[0].firstTimestamp
//       : null,

//   end:
//     futureDocs.length
//       ? futureDocs[futureDocs.length - 1].lastTimestamp
//       : null,

//   values:
//     forecastPoints.map(p => p.value)
// }
//   };
// }

// 007
// new forcast api

const RAW_WINDOW_MS = 3.5 * 60 * 60 * 1000; // last 3.5h
const FORECAST_WINDOW_MS = 30 * 60 * 1000;  // next 30min
const DEFAULT_INTERVAL_MS = 60 * 1000;      // 1-min buckets

const ALLOWED_AGGREGATIONS = ["avg", "sum", "min", "max", "count", "first", "last"];

async function getForecastWindow({
  tagId,
  interval,
  aggregation = "avg",
  format = "compact"
}) {

  if (!tagId) {
    throw new Error("Missing required parameter: tagId");
  }

  if (!mongoose.Types.ObjectId.isValid(tagId)) {
    throw new Error("Invalid tagId");
  }

  if (!ALLOWED_AGGREGATIONS.includes(aggregation)) {
    throw new Error("Invalid aggregation");
  }

  const intervalMs = interval ? parseISODuration(interval) : DEFAULT_INTERVAL_MS;

  const tagObjectId = new mongoose.Types.ObjectId(tagId);

  // ==========================================================
  // ANCHOR: everything derives from server time, not the client.
  // Not exposed in the response — kept internal only.
  // ==========================================================
  const now = new Date();
  const rawStart = new Date(now.getTime() - RAW_WINDOW_MS);
  const forecastEnd = new Date(now.getTime() + FORECAST_WINDOW_MS);

  // Both pipelines bucket relative to the SAME anchor (rawStart) so
  // bucket boundaries line up across the raw/forecast join at `now`.
  const anchorMs = rawStart.getTime();

  const buildBucketStage = () => ({
    $group: {
      _id: {
        bucket: {
          $toDate: {
            $subtract: [
              { $toLong: "$timestamp" },
              {
                $mod: [
                  { $subtract: [{ $toLong: "$timestamp" }, anchorMs] },
                  intervalMs
                ]
              }
            ]
          }
        }
      },
      avg: { $avg: "$value" },
      sum: { $sum: "$value" },
      min: { $min: "$value" },
      max: { $max: "$value" },
      count: { $sum: 1 },
      first: { $first: "$value" },
      last: { $last: "$value" },
      firstTimestamp: { $first: "$timestamp" },
      lastTimestamp: { $last: "$timestamp" }
    }
  });

  // =========================
  // RAW DATA (liveData_test) — last 3.5h
  // =========================

  const rawPromise = TagHistory.aggregate([
    {
      $match: {
        tag_id: tagObjectId,
        timestamp: { $gte: rawStart, $lte: now }
      }
    },
    { $project: { timestamp: 1, value: 1 } },
    { $sort: { timestamp: 1 } },
    buildBucketStage(),
    { $sort: { "_id.bucket": 1 } }
  ]);

  // =========================
  // FORECAST DATA (aiforecast) — next 30min
  // =========================

  const forecastCollection = mongoose.connection.db.collection("aiforecast");

  const forecastPromise = forecastCollection.aggregate([
    {
      $match: {
        tagId: tagObjectId,
        timestamp: { $gte: now, $lte: forecastEnd }
      }
    },
    { $project: { timestamp: 1, value: "$predictedValue" } },
    { $sort: { timestamp: 1 } },
    buildBucketStage(),
    { $sort: { "_id.bucket": 1 } }
  ]).toArray();

  // =========================
  // EXECUTE IN PARALLEL
  // =========================

  const [rawDocs, futureDocs] = await Promise.all([rawPromise, forecastPromise]);

  // =========================
  // AGGREGATION VALUE PICKER
  // =========================

  function getValue(doc) {
    switch (aggregation) {
      case "avg": return doc.avg;
      case "sum": return doc.sum;
      case "min": return doc.min;
      case "max": return doc.max;
      case "count": return doc.count;
      case "first": return doc.first;
      case "last": return doc.last;
      default: return null;
    }
  }

  const historicalPoints = rawDocs.map(doc => ({
    ts: doc._id.bucket.toISOString(),
    value: Number(getValue(doc))
  }));

  const forecastPoints = futureDocs.map(doc => ({
    ts: doc._id.bucket.toISOString(),
    value: Number(getValue(doc))
  }));

  // =========================
  // RESPONSE — same shape frontend already consumes
  // =========================

  const meta = {
    aggregation,
    interval: interval || "PT1M"
  };

  if (format === "points") {
    return {
      tagId,
      meta,
      historical: historicalPoints,
      forecast: forecastPoints
    };
  }

  // COMPACT FORMAT
  return {
    tagId,
    meta,
    historical: {
      start: rawDocs.length ? rawDocs[0].firstTimestamp.toISOString() : null,
      end: rawDocs.length ? rawDocs[rawDocs.length - 1].lastTimestamp.toISOString() : null,
      values: historicalPoints.map(p => p.value)
    },
    forecast: {
      start: futureDocs.length ? futureDocs[0].firstTimestamp.toISOString() : null,
      end: futureDocs.length ? futureDocs[futureDocs.length - 1].lastTimestamp.toISOString() : null,
      values: forecastPoints.map(p => p.value)
    }
  };
}

async function getDefectPoints(pageNumber) {

  const forecastDefectCollection =mongoose.connection.db.collection("forecastDefects");
  let page = parseInt(pageNumber, 10);
  if (isNaN(page) || page < 1) {
   page = 1;
  }
  const pageSize = 15;   // records per page
  const skip = (page - 1) * pageSize;
const forecastDefects = await forecastDefectCollection.aggregate([
    { $sort: { forecastTimestamp: -1 } },
    { $skip: skip },
    { $limit: pageSize },
    {
        $lookup: {
          from: "defects",
          let: { defectIds: "$detectedDefects.defectId" },
          pipeline: [
            { $match: { $expr: { $in: ["$_id", "$$defectIds"] } } },
            { $project: { _id: 1, name: 1 } }, // adjust "name" to your actual field
          ],
          as: "defectsInfo",
        },
      },
  {
    $project: {
      _id: 1,
      forecastTimestamp: 1,
      status: 1,
      firstDetectedAt: 1,
      lastStatusChangeAt: 1,
      lastUpdatedAt: 1,
      detectedDefects: {
        $map: {
              input: "$detectedDefects",
              as: "defect",
              in: {
                defectId: "$$defect.defectId",
                defectName: {
                  $let: {
                    vars: {
                      matched: {
                        $arrayElemAt: [
                          {
                            $filter: {
                              input: "$defectsInfo",
                              as: "d",
                              cond: { $eq: ["$$d._id", "$$defect.defectId"] },
                            },
                          },
                          0,
                        ],
                      },
                    },
                    in: "$$matched.name", // adjust "name" to your actual field
                  },
                },
            probabilityScore: "$$defect.probabilityScore",
            riskLevel: "$$defect.riskLevel",
            acknowledged: { $ifNull: ["$$defect.acknowledged", false] },
            acknowledgedBy: "$$defect.acknowledgedBy",
            acknowledgedAt: "$$defect.acknowledgedAt",
            triggeredRules: {
              $map: {
                input: "$$defect.triggeredRules",
                as: "rule",
                in: {
                  tag_id: "$$rule.tag_id",
                  tagName: "$$rule.tagName",
                  forecastedValue: "$$rule.forecastedValue",
                },
              },
            },
          },
        },
      },
    },
  },

]).toArray();
return forecastDefects; 

// await sendForeCastDefects("forecastdefects", forecastDefects)

}

async function updateforecastAcknowledged(reqbody, forecastDefectId, defectId, userId) {
  try {

    const { acknowledged } = reqbody;
    const result = await forecastDefects.updateOne(
      { _id: forecastDefectId,   "detectedDefects.defectId": defectId},
      {
        $set: {
          "detectedDefects.$.acknowledged": acknowledged,
          "detectedDefects.$.acknowledgedBy": userId,
          "detectedDefects.$.acknowledgedAt": new Date(),
        },
      }
    );
    return result;
  } catch (error) {
    throw error;
  }
}

async function updateAnomalyAcknowledged(reqbody, anomalyId, userId) {
  try {

    const { acknowledged } = reqbody;
    const result = await TagAnomalyCache.updateOne(
      { "payload.id": new mongoose.Types.ObjectId(anomalyId) },
      {
        $set: {
          acknowledged,
          acknowledgedBy: userId,
          acknowledgedAt: Date.now(),
          updatedAt: Date.now()
        },
      }
    );
    return result;
  } catch (error) {
    throw error;
  }
}

// CR0128
async function fetchLogTags(reqData = {}) {
  const query = { source: "LOG", isActive: true };
  if (reqData.search) {
    query.tagname = { $regex: reqData.search, $options: "i" };
  }
  const tags = await TagLive.find(
    query,
    { tagname: 1, unit: 1, datatype: 1, ranges: 1, plcName: 1 }
  ).lean();

  return tags.map((tag) => ({
    id: tag._id.toString(),
    tagname: tag.tagname,
    unit: tag.unit,
    dataType: tag.datatype,
    ranges: tag.ranges,
  }));
}

async function updateTagLiveFromLog(tagId, value, entryCreatedAt) {
  try {
    if (!tagId || !mongoose.Types.ObjectId.isValid(tagId)) return null;
    if (!entryCreatedAt) return null;

    const result = await TagLive.updateOne(
      {
        _id: new mongoose.Types.ObjectId(tagId),
        source: "LOG", // guard: never touch a PLC-fed tag from a log fill
        $or: [
          { "logSource.entryCreatedAt": { $exists: false } },
          { "logSource.entryCreatedAt": { $lt: new Date(entryCreatedAt) } },
        ],
      },
      {
        $set: {
          latestValue: value,
          lastUpdated: new Date(),
          "logSource.entryCreatedAt": new Date(entryCreatedAt),
        },
      }
    );
    return result;
  } catch (error) {
    console.error("Error updating tag live from log:", error);
    return null;
  }
}

// QID_165
async function getTagDashboard() {
  const kpiTags = [
    // =========================
    // PT - 15 Parameters
    // =========================
    {
      tagId: "699426acbfb07d6db09a050d",
      section: "PT",
      subStage: "Degreasing Spray",
      parameter: "Bath Temperature",
      minValue: 50,
      maxValue: 60,
      setRange: "50–60 °C",
    },
    {
      tagId: "699426acbfb07d6db09a0519",
      section: "PT",
      subStage: "Degreasing Spray",
      parameter: "Free Alkali",
      minValue: 16,
      maxValue: 19,
      setRange: "16–19 Points",
    },
    {
      tagId: "699426acbfb07d6db09a052b",
      section: "PT",
      subStage: "Degreasing Dip",
      parameter: "Bath Temperature",
      minValue: 50,
      maxValue: 60,
      setRange: "50–60 °C",
    },
    {
      tagId: "699426acbfb07d6db09a0543",
      section: "PT",
      subStage: "Degreasing Dip",
      parameter: "Free Alkali",
      minValue: 16,
      maxValue: 19,
      setRange: "16–19 Points",
    },
    {
      tagId: "699426acbfb07d6db09a0564",
      section: "PT",
      subStage: "Water Rinse 1",
      parameter: "Free Alkali",
      maxValue: 5,
      setRange: "≤5 Points",
    },
    {
      tagId: "699426acbfb07d6db09a056a",
      section: "PT",
      subStage: "Water Rinse 2",
      parameter: "Free Alkali",
      maxValue: 2,
      setRange: "≤2 Points",
    },
    {
      tagId: "699426acbfb07d6db09a0573",
      section: "PT",
      subStage: "Activation",
      parameter: "Total Concentration",
      minValue: 3.0,
      maxValue: 3.9,
      setRange: "3.0–3.9 Points",
    },
    {
      tagId: "699426acbfb07d6db09a0576",
      section: "PT",
      subStage: "Activation",
      parameter: "pH",
      minValue: 9.0,
      maxValue: 11.0,
      unit: "",
      setRange: "9.0–11.0",
    },
    {
      tagId: "699426acbfb07d6db09a057c",
      section: "PT",
      subStage: "Phosphate",
      parameter: "Bath Temperature",
      minValue: 40,
      maxValue: 45,
      setRange: "40–45 °C",
    },
    {
      tagId: "699426acbfb07d6db09a058b",
      section: "PT",
      subStage: "Phosphate",
      parameter: "Total Acidity",
      minValue: 22,
      maxValue: 24,
      setRange: "22–24 Points",
    },
    {
      tagId: "699426acbfb07d6db09a058e",
      section: "PT",
      subStage: "Phosphate",
      parameter: "Free Acidity",
      minValue: 0.7,
      maxValue: 1.2,
      setRange: "0.7–1.2 Points",
    },
    {
      tagId: "699426acbfb07d6db09a0591",
      section: "PT",
      subStage: "Phosphate",
      parameter: "Accelerator Content",
      minValue: 3.0,
      maxValue: 4.0,
      setRange: "3.0–4.0 Points",
    },
    {
      tagId: "6a9e9e7fa4169be4f0f3df41",
      section: "PT",
      subStage: "Water Rinse 3",
      parameter: "Total Acid",
      maxValue: 5,
      unit: "Points",
      setRange: "≤5 Points",
    },
    {
      tagId: "6a9e9e7fa4169be4f0f3df42",
      section: "PT",
      subStage: "Water Rinse 4",
      parameter: "Total Acid",
      maxValue: 2,
      setRange: "≤2 Points",
    },
    {
      tagId: "699426acbfb07d6db09a05c1",
      section: "PT",
      subStage: "Water Rinse 5",
      parameter: "Conductivity",
      maxValue: 30,
      setRange: "<30 µs/cm",
    },

    // =========================
    // ED - 9 Parameters
    // =========================
    {
      tagId: "69c27c8a553da24f123e689f",
      section: "ED",
      subStage: "ED Bath",
      parameter: "Solids Content",
      minValue: 22,
      maxValue: 24,
      setRange: "22–24 %",
    },
    {
      tagId: "69c27c8d553da24f123fba20",
      section: "ED",
      subStage: "ED Bath",
      parameter: "Ash Content",
      minValue: 22,
      maxValue: 24,
      setRange: "22–24 %",
    },
    {
      tagId: "69c27c8f553da24f12410ba1",
      section: "ED",
      subStage: "ED Bath",
      parameter: "pH",
      minValue: 5.5,
      maxValue: 6.1,
      setRange: "5.5–6.1",
    },
    {
      tagId: "69c27c92553da24f12425d22",
      section: "ED",
      subStage: "ED Bath",
      parameter: "Conductivity",
      minValue: 1200,
      maxValue: 2400,
      setRange: "1200–2400 µs/cm",
    },
    {
      tagId: "69c27cd8553da24f1264a43c",
      section: "ED",
      subStage: "UF Rinse 1",
      parameter: "pH",
      minValue: 5.2,
      maxValue: 5.9,
      setRange: "5.2–5.9",
    },
    {
      tagId: "69c27cd4553da24f126352bb",
      section: "ED",
      subStage: "UF Rinse 1",
      parameter: "Solids Content",
      maxValue: 2,
      setRange: "≤2 %",
    },
    {
      tagId: "69c27ceb553da24f126f3044",
      section: "ED",
      subStage: "UF Rinse 2",
      parameter: "pH",
      minValue: 5.2,
      maxValue: 5.9,
      setRange: "5.2–5.9",
    },
    {
      tagId: "69c27ce9553da24f126ddec3",
      section: "ED",
      subStage: "UF Rinse 2",
      parameter: "Solids Content",
      maxValue: 2,
      setRange: "≤2 %",
    },
    {
      tagId: "699d79ccefe574e9bb8b1961",
      section: "ED",
      subStage: "After DI Rinse",
      parameter: "DI Water Spray Flow",
      minValue: 80,
      maxValue: 120,
      setRange: "80–120 LPM",
    },
  ];

  const tagIds = [
    ...new Set(kpiTags.map((item) => item.tagId)),
  ].map((id) => new mongoose.Types.ObjectId(id));

  const tags = await TagLive.find(
    {
      _id: { $in: tagIds },
      isActive: true,
    },
    {
      tagname: 1,
      latestValue: 1,
      unit: 1,
      health: 1,
      source: 1,
      lastUpdated: 1,
      updatedAt: 1,
    }
  ).lean();

  const tagMap = new Map(
    tags.map((tag) => [tag._id.toString(), tag])
  );

  const formatTag = (config) => {
    const tag = tagMap.get(config.tagId);

    if (!tag) {
      return {
        tagId: config.tagId,
        section: config.section,
        subStage: config.subStage,
        parameter: config.parameter,
        value: null,
        unit: null,
        range: {
          minValue: config.minValue ?? null,
          maxValue: config.maxValue ?? null,
        },
        setRange: config.setRange,
        status: "No Data",
        health: false,
        source: null,
        timestamp: null,
      };
    }

    const value = Number(tag.latestValue);

    let status = "In limit";

    if (Number.isNaN(value)) {
      status = "No Data";
    } else {
      const belowMin =
        config.minValue !== undefined &&
        value < config.minValue;

      const aboveMax =
        config.maxValue !== undefined &&
        value > config.maxValue;

      if (belowMin || aboveMax) {
        status = "Out of limit";
      }
    }

    return {
      tagId: config.tagId,
      section: config.section,
      subStage: config.subStage,
      parameter: config.parameter,

      value: tag.latestValue ?? null,
      // unit: tag.unit ?? null,
      unit: config.unit !== undefined ? config.unit : (tag.unit ?? null),

      range: {
        minValue: config.minValue ?? null,
        maxValue: config.maxValue ?? null,
      },

      setRange: config.setRange,

      status,

      health: tag.health ?? false,
      source: tag.source ?? null,
      timestamp: tag.lastUpdated || tag.updatedAt || null,
    };
  };

  const result = kpiTags.map(formatTag);

  return {
    total: result.length,
    pt: result.filter((tag) => tag.section === "PT"),
    ed: result.filter((tag) => tag.section === "ED"),
  };
}


module.exports = {
  fetchAllTags,
  fetchTagsByAssetId,
  getTagHistory,
  getAllLiveTags,
  getTagAnomalies,
  // getRawPoints,
  getForecastWindow,  
  getTagAnomaliesFast,
  getDefectPoints,
  updateforecastAcknowledged,
  updateAnomalyAcknowledged,
  fetchLogTags, // CR0128
  updateTagLiveFromLog, // CR0128
  getTagDashboard, // QID_165
};