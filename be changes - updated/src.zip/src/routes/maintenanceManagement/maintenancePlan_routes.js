const express = require("express");
const maintenancePlanController = require("../../controllers/maintenanceManagement/maintenancePlan_controller");
const fileController = require("../../controllers/fileSystem/fileSystem_controller");
const workOrderTaskController = require("../../controllers/maintenanceManagement/workOrderTask_controller");
const workOrderRemarkController = require("../../controllers/maintenanceManagement/workOrderRemark_controller");
const {
  businessUnitMiddleware,
  assetMiddleware,
  workOrderMiddleware,
  departmentMiddleWare,
  maintenancePlanMiddleware,
} = require("../../middlewares/index");
const maintenancePlanRouter = express.Router();

maintenancePlanRouter.post(
  "/",
  [
    businessUnitMiddleware.verifyBusinessUnit,
    maintenancePlanMiddleware.validateReqBody,
    maintenancePlanMiddleware.validateCreateMaintenancePlan,
    assetMiddleware.validateAsset,
    departmentMiddleWare.validateDepartments,
    maintenancePlanMiddleware.verifyPriority,
    maintenancePlanMiddleware.validateMaintenancePlanRecurrence,
    maintenancePlanMiddleware.verifyDuplicates,
    maintenancePlanMiddleware.checkExistingAssigneeInDepartment,
    maintenancePlanMiddleware.verifyStartDateAndEndDateTime,
    maintenancePlanMiddleware.verifyEstimatedDaysAndHours,
    maintenancePlanMiddleware.checkExistingTeamInDepartment,
    maintenancePlanMiddleware.validateMaintenancePlanDocuments,
    maintenancePlanMiddleware.validateMaintenancePlanImages,
  ],
  maintenancePlanController.createMaintenancePlan
);

maintenancePlanRouter.get("/", [
  businessUnitMiddleware.verifyBusinessUnit,
  maintenancePlanMiddleware.validateAssetForMaintenancePlan,
  departmentMiddleWare.validateDepartment,
],
  maintenancePlanController.fetchMaintenancePlans);

maintenancePlanRouter.get(
  "/statusCount", [ businessUnitMiddleware.verifyBusinessUnit,],
  maintenancePlanController.maintenanceCount
);

maintenancePlanRouter.get(
  "/:maintenancePlan",
  [
    businessUnitMiddleware.verifyBusinessUnit,
    maintenancePlanMiddleware.validateMaintenancePlan,
  ],
  maintenancePlanController.fetchMaintenancePlan
);


maintenancePlanRouter.delete(
  "/",
  [maintenancePlanMiddleware.validateMaintenancePlans],
  maintenancePlanController.deleteMaintenancePlan
);

maintenancePlanRouter.patch(
  "/:maintenancePlan",
  [
    maintenancePlanMiddleware.validateMaintenancePlan,
    maintenancePlanMiddleware.validateReqBody,
    maintenancePlanMiddleware.verifyPriority,
    maintenancePlanMiddleware.validateMaintenancePlanRecurrence,
    // workOrderMiddleware.verifyStatus,
    maintenancePlanMiddleware.verifyDuplicates,
    maintenancePlanMiddleware.checkExistingAssigneeInDepartment,
    maintenancePlanMiddleware.validateEditStartDate,
    maintenancePlanMiddleware.verifyStartDateAndEndDateTime,
    maintenancePlanMiddleware.verifyEstimatedDaysAndHours,
    maintenancePlanMiddleware.checkExistingTeamInDepartment,
    maintenancePlanMiddleware.validateMaintenancePlanDocuments,
    maintenancePlanMiddleware.validateTask,
    maintenancePlanMiddleware.validateMaintenancePlanImages,
  ],
  maintenancePlanController.editMaintenancePlan
);

maintenancePlanRouter.get(
  "/:maintenancePlan/versions",
  [
    businessUnitMiddleware.verifyBusinessUnit,
    maintenancePlanMiddleware.validateMaintenancePlan,
  ],
  maintenancePlanController.getVersionByMaintenanceId
);

maintenancePlanRouter.get(
  "/:maintenancePlan/versions/:version",
  [
    businessUnitMiddleware.verifyBusinessUnit,
    maintenancePlanMiddleware.validateMaintenancePlan,
    maintenancePlanMiddleware.validateMaintenancePlanVersion,
  ],
  maintenancePlanController.getMaintenancePlanVersion
);

maintenancePlanRouter.post(
  "/:maintenancePlan/pause",
  [
    businessUnitMiddleware.verifyBusinessUnit,
    maintenancePlanMiddleware.validateMaintenancePlan,
  ],
  maintenancePlanController.pauseMaintenancePlan
);

maintenancePlanRouter.post(
  "/:maintenancePlan/resume",
  [
    businessUnitMiddleware.verifyBusinessUnit,
    maintenancePlanMiddleware.validateMaintenancePlan,
  ],
  maintenancePlanController.resumeMaintenancePlan
);

module.exports = { maintenancePlanRouter };
