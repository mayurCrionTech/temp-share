const express = require("express");
const preventiveRuleController = require("../../controllers/maintenanceManagement/preventiveRule_controller");
const { businessUnitMiddleware, preventiveRuleMiddleware } = require("../../middlewares/index");
const preventiveRuleRouter = express.Router();

preventiveRuleRouter.post(
  "/",
  [businessUnitMiddleware.verifyBusinessUnit, preventiveRuleMiddleware.validateCreatePreventiveRule],
  preventiveRuleController.createPreventiveRule
);

preventiveRuleRouter.get(
  "/",
  [businessUnitMiddleware.verifyBusinessUnit],
  preventiveRuleController.fetchPreventiveRules
);

preventiveRuleRouter.get(
  "/:preventiveRule",
  [businessUnitMiddleware.verifyBusinessUnit, preventiveRuleMiddleware.validatePreventiveRule],
  preventiveRuleController.fetchPreventiveRule
);

preventiveRuleRouter.patch(
  "/:preventiveRule",
  [preventiveRuleMiddleware.validatePreventiveRule, preventiveRuleMiddleware.validateEditPreventiveRule],
  preventiveRuleController.editPreventiveRule
);

preventiveRuleRouter.delete(
  "/",
  [preventiveRuleMiddleware.validatePreventiveRules],
  preventiveRuleController.deletePreventiveRules
);

module.exports = { preventiveRuleRouter };