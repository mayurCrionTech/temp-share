const express = require("express");
const workOrderController = require('../../controllers/maintenanceManagement/workOrder_controller');
const fileController = require("../../controllers/fileSystem/fileSystem_controller");
const workOrderTaskController = require('../../controllers/maintenanceManagement/workOrderTask_controller');
const workOrderRemarkController = require('../../controllers/maintenanceManagement/workOrderRemark_controller');
const {authJwtMiddleware, assetMiddleware, workOrderMiddleware, departmentMiddleWare,fileMiddleware,maintenancePlanMiddleware, businessUnitMiddleware} = require('../../middlewares/index')
const workOrderRouter = express.Router();

workOrderRouter.post("/",
    [
        authJwtMiddleware.verifyToken,
        businessUnitMiddleware.verifyBusinessUnit,
        workOrderMiddleware.validateReqBody,
        workOrderMiddleware.createWorkOrder,
        assetMiddleware.validateAsset,
        departmentMiddleWare.validateDepartments,
        workOrderMiddleware.verifyPriority,
        workOrderMiddleware.verifyStatus,
        workOrderMiddleware.verifyDuplicates,
        workOrderMiddleware.checkExistingAssigneeInDepartment,
        workOrderMiddleware.verifyStartDateAndEndDateTime,
        workOrderMiddleware.verifyEstimatedDaysAndHours,
        workOrderMiddleware.checkExistingTeamInDepartment,
        workOrderMiddleware.validateWorkOrderDocuments,
        workOrderMiddleware.validateWorkOrderImages,
    ],
    workOrderController.createWorkOrder);
    
    workOrderRouter.get("/constants",
        [
            authJwtMiddleware.verifyToken,
        ],
        workOrderController.workOrderConstants
    )
    
    workOrderRouter.get("/statusCount",
        [
            authJwtMiddleware.verifyToken,
            businessUnitMiddleware.verifyBusinessUnit,
        ],
        workOrderController.workOrderCount
    )
    
    workOrderRouter.patch("/:workOrder", 
        [
            authJwtMiddleware.verifyToken,
            workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateReqBody,
        workOrderMiddleware.verifyPriority,
        workOrderMiddleware.verifyStatus,
        workOrderMiddleware.verifyDuplicates,
        workOrderMiddleware.checkExistingAssigneeInDepartment,
        workOrderMiddleware.validateEditStartDate,
        workOrderMiddleware.verifyStartDateAndEndDateTime,
        workOrderMiddleware.verifyEstimatedDaysAndHours,
        workOrderMiddleware.checkExistingTeamInDepartment,
        workOrderMiddleware.validateWorkOrderDocuments,
        workOrderMiddleware.validateWorkOrderTask,
        workOrderMiddleware.validateWorkOrderImages,
        workOrderMiddleware.validateStatusForEdit,
    ],
    workOrderController.editWorkOrder
);

workOrderRouter.get("/",
    [
        authJwtMiddleware.verifyToken,
        departmentMiddleWare.validateDepartment,
        businessUnitMiddleware.verifyBusinessUnit,
        workOrderMiddleware.validateAssetForWorkOrder,
        maintenancePlanMiddleware.validateMaintenancePlan
    ],
    workOrderController.fetchWorkOrders
)

workOrderRouter.get("/:workOrder/tasks/:task/images",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateWorkOrderTask,
    ],
    workOrderTaskController.getTaskDetails
)

workOrderRouter.post("/:workOrder/tasks/:task/images",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateWorkOrderTask,
        fileMiddleware.uploadMultiple,
		fileMiddleware.validateMultipleFileExtensionAndSize,
		fileMiddleware.validateFileUpload
    ],
    workOrderTaskController.addImages
)

workOrderRouter.post('/:workOrder/remarks', 
    [
        authJwtMiddleware.verifyToken,
        businessUnitMiddleware.verifyBusinessUnit,
        workOrderMiddleware.validateWorkOrder
],
 workOrderRemarkController.createWorkOrderRemarks)

 workOrderRouter.get('/:workOrder/remarks', 
    [
        authJwtMiddleware.verifyToken,
        businessUnitMiddleware.verifyBusinessUnit,
        workOrderMiddleware.validateWorkOrder
],
 workOrderRemarkController.fetchWorkOrderRemarks)

 workOrderRouter.get("/:workOrder",
    [
        authJwtMiddleware.verifyToken,
        businessUnitMiddleware.verifyBusinessUnit,
        workOrderMiddleware.validateWorkOrder
    ],
    workOrderController.fetchWorkOrder
 )

 workOrderRouter.post("/:workOrder/accept",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateStatusForAccept,
    ],
    workOrderController.acceptWorkOrder
 )

 workOrderRouter.post("/:workOrder/putOnHold",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateStatusForOnHold
    ],
    workOrderController.holdWorkOrder
 )

 workOrderRouter.post("/:workOrder/complete",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateStatusForComplete
    ],
    workOrderController.completeWorkOrder
 )

 // #QID_076
// Bulk verify workorder tasks
workOrderRouter.patch(
    "/:workOrder/tasks/verify",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
    ],
    workOrderController.verifyTasks
)

 // #QID_076
 // Single verify workorder tasks
 workOrderRouter.patch(
    "/:workOrder/tasks/:task/verify",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateWorkOrderTask,
    ],
    workOrderController.verifyTask
)

 workOrderRouter.patch("/:workOrder/tasks/:task",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
        workOrderMiddleware.validateWorkOrderTask,
        workOrderMiddleware.validateWorkOrderImages,
    ],
    workOrderTaskController.updateTaskStatus
 )

// #QID_076
// Manager final approval for workorder completion

workOrderRouter.post(
    "/:workOrder/approve",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
    ],
    workOrderController.approveWorkOrder
)

 workOrderRouter.post(
	"/:workOrder/images",
	[
		authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
		fileMiddleware.uploadSingle,
		fileMiddleware.validateFileExtensionAndSize,
		fileMiddleware.validateFileUpload,
	],
	workOrderController.addImage
);

workOrderRouter.post(
	"/:workOrder/images/bulkUpload",
	[
		authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
		fileMiddleware.uploadMultiple,
		fileMiddleware.validateMultipleFileExtensionAndSize,
		fileMiddleware.validateFileUpload,
	],
	workOrderController.addImages)

workOrderRouter.get(
    "/:workOrder/spares",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrder,
    ],
    workOrderController.getSpareByWorkOrder
)


workOrderRouter.get("/:workOrder/images",
    [
        authJwtMiddleware.verifyToken,
        businessUnitMiddleware.verifyBusinessUnit,
        workOrderMiddleware.validateWorkOrder,
    ],
    workOrderController.getImages
)

workOrderRouter.delete("/",
    [
        authJwtMiddleware.verifyToken,
        workOrderMiddleware.validateWorkOrders,
    ],
    workOrderController.deleteWorkOrder
)

workOrderRouter.get("/:workOrder/copy",
    [
        authJwtMiddleware.verifyToken,
        businessUnitMiddleware.verifyBusinessUnit,
        workOrderMiddleware.validateWorkOrder,
    ],
    workOrderController.copyWorkOrder
)





module.exports = { workOrderRouter }; 