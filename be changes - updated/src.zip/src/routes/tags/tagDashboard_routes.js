const express = require("express");

const tagDashboardRouter = express.Router();

const tagController = require("../../controllers/tagManagement/tagController");
const analyticsController = require("../../controllers/analyticsManagement/analytics.controller"); // QID_166
const trendController = require("../../controllers/trendManagement/trend_controller"); // QID_167

// ============================================================
// QID_165 - KPI DASHBOARD
// ============================================================

// GET /api/v1/tags/dashboard/kpiDashboard
tagDashboardRouter.get("/kpiDashboard", tagController.getTagDashboard); // QID_165

// ============================================================
// QID_166 - ANALYTICS
// ============================================================

// GET /api/v1/tags/dashboard/analytics/overview?limit=20
tagDashboardRouter.get(
  "/analytics/overview",
  analyticsController.getAnalyticsOverview,
);

// QID_166 - Analytics (vehicle / hanger / skid search, stage journey, stage readings)
// GET /api/v1/tags/dashboard/analytics/search?searchBy=hanger|skid|cabin&value=..&from=ISO&to=ISO
tagDashboardRouter.get("/analytics/search", analyticsController.searchVehicles);
// GET /api/v1/tags/dashboard/analytics/journey?cabinNumber=..&skid=..[&includeStatus=true]
tagDashboardRouter.get(
  "/analytics/journey",
  analyticsController.getVehicleJourney,
);
// GET /api/v1/tags/dashboard/analytics/stage-readings?cabinNumber=..&skid=..&stageId=PT-1
tagDashboardRouter.get(
  "/analytics/stage-readings",
  analyticsController.getStageReadings,
);

tagDashboardRouter.get(
  "/analytics/reports/correlation",
  analyticsController.generateCorrelationReport,
);

tagDashboardRouter.get(
  "/analytics/reports/process",
  analyticsController.generateProcessReport,
);

// ============================================================
// QID_167 - TREND ANALYSIS
// ============================================================

// Get available trend parameters
// GET /api/v1/tags/dashboard/trend/parameters
tagDashboardRouter.get("/trend/parameters", trendController.getTrendParameters);

// Get complete trend parameter master
// GET /api/v1/tags/dashboard/trend/parameter-master
tagDashboardRouter.get(
  "/trend/parameter-master",
  trendController.getTrendParameterMaster,
);

// Get current live values
// GET /api/v1/tags/dashboard/trend/live?tagIds=id1,id2
tagDashboardRouter.get("/trend/live", trendController.getTrendLiveData);

// Get historical trend data
// GET /api/v1/tags/dashboard/trend/history?tagIds=id1,id2&startDate=ISO&endDate=ISO
tagDashboardRouter.get("/trend/history", trendController.getTrendHistory);

// Get trend statistics / summary
// GET /api/v1/tags/dashboard/trend/summary?tagIds=id1,id2&startDate=ISO&endDate=ISO
tagDashboardRouter.get("/trend/summary", trendController.getTrendSummary);

// Get latest values
// GET /api/v1/tags/dashboard/trend/latest?tagIds=id1,id2
tagDashboardRouter.get("/trend/latest", trendController.getTrendLatestValues);

module.exports = { tagDashboardRouter };
