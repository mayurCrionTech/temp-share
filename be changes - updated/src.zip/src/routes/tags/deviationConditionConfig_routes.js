// #QID_174 

const express = require("express");
const router = express.Router();

const deviationConditionConfigController = require("../../controllers/tagManagement/deviationConditionConfig_controller");

const {
  verifyToken,
  verifyIsSuperAdmin,
} = require("../../middlewares/usermanagement/authJwt_middleware");

// All endpoints are restricted to authenticated Super Admins.
router.use(verifyToken, verifyIsSuperAdmin);

// Fetch eligible tags for the configuration UI.
router.get("/numeric-tags", deviationConditionConfigController.getNumericTags);

router.get(
  "/condition-tags",
  deviationConditionConfigController.getConditionTags,
);

// Configuration CRUD operations.
router.get("/", deviationConditionConfigController.getAllConfigurations);

router.post("/", deviationConditionConfigController.createConfiguration);

router.put("/:id", deviationConditionConfigController.updateConfiguration);

router.patch(
  "/:id/status",
  deviationConditionConfigController.updateConfigurationStatus,
);

module.exports = router;
