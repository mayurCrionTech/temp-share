const apiResponseHandler = require("../../managers/common/apiResponseHandler_manager");
const { preventiveRule } = require("../../models/mongoDB/maintenanceManagement/preventiveRule_model");
const preventiveRuleManager = require("../../managers/internalManagers/maintenanceManagement/preventiveRule_manager");
const operatorEnum = Object.values(preventiveRule.operator);
const priorityEnum = Object.values(preventiveRule.priority);
const statusEnum = Object.values(preventiveRule.status);

const validateCreatePreventiveRule = async (req, res, next) => {
  try {
    const { tagId, parameter, operator, cutoffValue } = req.body;

    if (!tagId || typeof tagId !== "string") {
      return apiResponseHandler.errorResponse(null, req, res, "Failed! tagId is required.", 400, null);
    }
    if (!parameter || typeof parameter !== "string") {
      return apiResponseHandler.errorResponse(null, req, res, "Failed! parameter is required.", 400, null);
    }
    if (operator && !operatorEnum.includes(operator)) {
      return apiResponseHandler.errorResponse(null, req, res, `Failed! operator must be one of: ${operatorEnum.join(", ")}.`, 400, null);
    }
    if (cutoffValue === undefined || cutoffValue === null || typeof cutoffValue !== "number" || cutoffValue <= 0) {
      return apiResponseHandler.errorResponse(null, req, res, "Failed! cutoffValue must be a number greater than 0.", 400, null);
    }
    if (req.body.priority && !priorityEnum.includes(req.body.priority)) {
      return apiResponseHandler.errorResponse(null, req, res, `Failed! priority must be one of: ${priorityEnum.join(", ")}.`, 400, null);
    }
    return next();
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

const validatePreventiveRule = async (req, res, next) => {
  try {
    const ruleId = req.params.preventiveRule || req.body.preventiveRule;
    if (!ruleId || typeof ruleId !== "string") {
      return apiResponseHandler.errorResponse(null, req, res, "preventiveRule id must be a non-empty string in req.params or req.body", 400, null);
    }
    const existingRule = await preventiveRuleManager.fetchPreventiveRule(ruleId);
    if (!existingRule) {
      return apiResponseHandler.errorResponse(null, req, res, "Failed! Preventive Rule not found.", 404, null);
    }
    req.preventiveRule = ruleId;
    req.preventiveRuleObj = existingRule;
    return next();
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

const validatePreventiveRules = async (req, res, next) => {
  try {
    if (!req.body.preventiveRules || !Array.isArray(req.body.preventiveRules) || req.body.preventiveRules.length === 0) {
      return apiResponseHandler.errorResponse(null, req, res, "Failed! preventiveRules must be a non-empty array of ids.", 400, null);
    }
    return next();
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

const validateEditPreventiveRule = async (req, res, next) => {
  try {
    if (req.body.operator && !operatorEnum.includes(req.body.operator)) {
      return apiResponseHandler.errorResponse(null, req, res, `Failed! operator must be one of: ${operatorEnum.join(", ")}.`, 400, null);
    }
    if (req.body.cutoffValue !== undefined && (typeof req.body.cutoffValue !== "number" || req.body.cutoffValue <= 0)) {
      return apiResponseHandler.errorResponse(null, req, res, "Failed! cutoffValue must be a number greater than 0.", 400, null);
    }
    if (req.body.priority && !priorityEnum.includes(req.body.priority)) {
      return apiResponseHandler.errorResponse(null, req, res, `Failed! priority must be one of: ${priorityEnum.join(", ")}.`, 400, null);
    }
    if (req.body.status && !statusEnum.includes(req.body.status)) {
      return apiResponseHandler.errorResponse(null, req, res, `Failed! status must be one of: ${statusEnum.join(", ")}.`, 400, null);
    }
    return next();
  } catch (error) {
    return apiResponseHandler.errorResponse(error, req, res, "Internal server error", 500, null);
  }
};

module.exports = {
  validateCreatePreventiveRule,
  validatePreventiveRule,
  validatePreventiveRules,
  validateEditPreventiveRule,
};