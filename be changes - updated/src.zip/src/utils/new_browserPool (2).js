const puppeteer = require("puppeteer");

let browserInstance = null;
let activePages = 0;
const MAX_CONCURRENT_PAGES = 2;
const IDLE_TIMEOUT_MS = 60000;
const MAX_RETRIES = 2;
let idleTimer = null;

async function getBrowser() {
  if (!browserInstance || !browserInstance.isConnected()) {
    // Kill stale browser if it exists but disconnected
    if (browserInstance) {
      await browserInstance.close().catch(() => {});
      browserInstance = null;
    }
    browserInstance = await puppeteer.launch({
      headless: true,
      args: [
        // "--no-sandbox",
        // "--disable-setuid-sandbox",
        // "--disable-dev-shm-usage",
        "--disable-gpu",
        // "--single-process",
        // "--no-zygote",
      ],
    });
    browserInstance.on("disconnected", () => {
      browserInstance = null;
      activePages = 0;
    });
  }
  clearTimeout(idleTimer);
  return browserInstance;
}

async function generatePDFFromHTML(htmlContent, pdfOptions = {}, _retryCount = 0) {
  // Wait if too many pages are open
  const waitStart = Date.now();
  while (activePages >= MAX_CONCURRENT_PAGES) {
    if (Date.now() - waitStart > 120000) {
      throw new Error("browserPool: timed out waiting for available page slot");
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }

  activePages++;
  let page = null;
  try {
    const browser = await getBrowser();
    page = await browser.newPage();

    // Use domcontentloaded instead of networkidle0 to avoid Navigation timeout
    await page.setContent(htmlContent, { waitUntil: "domcontentloaded", timeout: 30000 });

    const defaultOptions = {
      format: "A3",
      timeout: 60000,
      margin: { top: "0.3in", right: "0.3in", bottom: "0.3in", left: "0.3in" },
    };

    const buffer = await page.pdf({ ...defaultOptions, ...pdfOptions });
    return buffer;
  } catch (err) {
    // On Protocol error or Navigation timeout, kill browser and retry once
    if (_retryCount < MAX_RETRIES && (
      err.message.includes("Protocol error") ||
      err.message.includes("Navigation timeout") ||
      err.message.includes("Printing failed") ||
      err.message.includes("Target closed")
    )) {
      console.warn(`browserPool: retrying PDF generation (attempt ${_retryCount + 1}): ${err.message}`);
      // Force-kill corrupted browser
      if (browserInstance) {
        await browserInstance.close().catch(() => {});
        browserInstance = null;
      }
      activePages = 0;
      if (page) {
        page = null;
      }
      return generatePDFFromHTML(htmlContent, pdfOptions, _retryCount + 1);
    }
    throw err;
  } finally {
    if (page) {
      await page.close().catch(() => {});
    }
    activePages = Math.max(0, activePages - 1);

    // Close browser after idle period to free memory
    if (activePages === 0) {
      idleTimer = setTimeout(async () => {
        if (browserInstance && activePages === 0) {
          await browserInstance.close().catch(() => {});
          browserInstance = null;
        }
      }, IDLE_TIMEOUT_MS);
    }
  }
}

async function closeBrowser() {
  if (browserInstance) {
    await browserInstance.close().catch(() => {});
    browserInstance = null;
  }
}

process.on("exit", closeBrowser);
process.on("SIGINT", async () => { await closeBrowser(); process.exit(); });
process.on("SIGTERM", async () => { await closeBrowser(); process.exit(); });

module.exports = { generatePDFFromHTML, closeBrowser };




// const puppeteer = require("puppeteer");

// let browserInstance = null;
// let browserLaunchPromise = null;
// let activePages = 0;

// const MAX_CONCURRENT_PAGES = 2;
// const IDLE_TIMEOUT_MS = 60000;
// const MAX_RETRIES = 2;

// let idleTimer = null;

// const sleep = (ms) =>
//   new Promise((resolve) => setTimeout(resolve, ms));

// function isRetryableError(err) {
//   const message = `${err?.message || ""} ${
//     err?.cause?.message || ""
//   }`.toLowerCase();

//   return (
//     message.includes("protocol error") ||
//     message.includes("navigation timeout") ||
//     message.includes("printing failed") ||
//     message.includes("target closed") ||
//     message.includes("targetcloseerror") ||
//     message.includes("session closed") ||
//     message.includes("browser has disconnected")
//   );
// }

// async function getBrowser() {
//   clearTimeout(idleTimer);
//   idleTimer = null;

//   if (browserInstance && browserInstance.isConnected()) {
//     return browserInstance;
//   }

//   if (browserLaunchPromise) {
//     return browserLaunchPromise;
//   }

//   browserLaunchPromise = (async () => {
//     const browser = await puppeteer.launch({
//       headless: true,
//       args: [
//         "--no-sandbox",
//         "--disable-setuid-sandbox",
//         "--disable-dev-shm-usage",
//         "--disable-gpu",
//       ],
//     });

//     browserInstance = browser;

//     browser.on("disconnected", () => {
//       if (browserInstance === browser) {
//         browserInstance = null;
//       }
//     });

//     return browser;
//   })();

//   try {
//     return await browserLaunchPromise;
//   } finally {
//     browserLaunchPromise = null;
//   }
// }

// async function generatePDFFromHTML(htmlContent, pdfOptions = {}) {
//   const waitStart = Date.now();

//   // Reserve a page slot before starting PDF generation.
//   while (activePages >= MAX_CONCURRENT_PAGES) {
//     if (Date.now() - waitStart > 120000) {
//       throw new Error(
//         "browserPool: timed out waiting for available page slot"
//       );
//     }

//     await sleep(250);
//   }

//   activePages++;

//   try {
//     let lastError;

//     for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
//       let browser = null;
//       let page = null;

//       try {
//         browser = await getBrowser();

//         page = await browser.newPage();

//         await page.setContent(htmlContent, {
//           waitUntil: "domcontentloaded",
//           timeout: 30000,
//         });

//         const defaultOptions = {
//           format: "A3",
//           timeout: 60000,
//           margin: {
//             top: "0.3in",
//             right: "0.3in",
//             bottom: "0.3in",
//             left: "0.3in",
//           },
//         };

//         const buffer = await page.pdf({
//           ...defaultOptions,
//           ...pdfOptions,
//         });

//         return buffer;
//       } catch (err) {
//         lastError = err;

//         if (
//           attempt >= MAX_RETRIES ||
//           !isRetryableError(err)
//         ) {
//           throw err;
//         }

//         console.warn(
//           `browserPool: retrying PDF generation ` +
//             `(attempt ${attempt + 1}/${MAX_RETRIES}):`,
//           err.message
//         );

//         // Do not close the shared browser here.
//         // Other requests may still be using it.
//         if (browser && !browser.isConnected()) {
//           if (browserInstance === browser) {
//             browserInstance = null;
//           }
//         }

//         await sleep(300 * (attempt + 1));
//       } finally {
//         if (page) {
//           await page.close().catch(() => {});
//         }
//       }
//     }

//     throw lastError;
//   } finally {
//     activePages = Math.max(0, activePages - 1);

//     // Schedule browser cleanup only when no requests remain.
//     if (activePages === 0) {
//       clearTimeout(idleTimer);

//       idleTimer = setTimeout(() => {
//         if (activePages !== 0) {
//           return;
//         }

//         const browser = browserInstance;

//         // Release the shared reference before closing.
//         if (browserInstance === browser) {
//           browserInstance = null;
//         }

//         if (browser) {
//           browser.close().catch(() => {});
//         }
//       }, IDLE_TIMEOUT_MS);
//     }
//   }
// }

// async function closeBrowser() {
//   clearTimeout(idleTimer);
//   idleTimer = null;

//   const browser = browserInstance;
//   browserInstance = null;

//   if (browser) {
//     await browser.close().catch(() => {});
//   }
// }

// process.on("exit", () => {
//   // The exit event cannot reliably await asynchronous cleanup.
//   if (browserInstance) {
//     browserInstance.process()?.kill();
//     browserInstance = null;
//   }
// });

// process.on("SIGINT", async () => {
//   await closeBrowser();
//   process.exit(0);
// });

// process.on("SIGTERM", async () => {
//   await closeBrowser();
//   process.exit(0);
// });

// module.exports = {
//   generatePDFFromHTML,
//   closeBrowser,
// };