/**
 * occurrenceSegmenter.js
 *
 * Pure logic (no DB) that turns raw identity-tag history for ONE line asset
 * into vehicle dwell segments: "cabin X / skid Y was here from A to B".
 *
 * Input samples: [{ timestamp, field, value }] sorted by timestamp, where
 * field is one of: hanger | vin1 | vin2 | skid | type | colour.
 *
 * Rules (all confirmed against the PT-1 dry run):
 *  - All tags of an asset are written by the same receiver tick (~10-11s), so
 *    samples within TICK_GROUP_MS of each other are one tick. Each field's last
 *    value is carried forward within the window.
 *  - A vehicle is PRESENT when skid > 0 and vin2 is non-empty.
 *  - Segment identity = cabinNumber + skid. It changes -> new segment, even if
 *    there was no blank tick between two vehicles.
 *  - Hanger / type / colour are read imperfectly (hanger RFID sometimes
 *    misses), so they are NOT part of the identity; the most common non-blank
 *    value seen during the segment is used.
 *  - A gap longer than MAX_TICK_GAP_MS (data outage) closes the segment.
 */

const TICK_GROUP_MS = 2000;
const MAX_TICK_GAP_MS = 60 * 1000;

/**
 * ASSUMPTION TO CONFIRM: the cabin number is Serial_No_VIN_1 followed by
 * Serial_No_VIN_2 (e.g. "2963" + "57" -> "296357"). Change here if the real
 * format differs (padding, separator, etc). Used everywhere.
 */
function buildCabinNumber(vin1, vin2) {
  return `${vin1}${vin2}`;
}

const asText = (v) => (v === null || v === undefined ? "" : String(v).trim());
const asNumber = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

function mode(counts) {
  let best = "";
  let bestCount = 0;
  for (const [value, count] of Object.entries(counts)) {
    if (count > bestCount) {
      best = value;
      bestCount = count;
    }
  }
  return best;
}

function segmentSamples(samples) {
  const segments = [];
  const state = { hanger: "", vin1: "", vin2: "", skid: 0, type: "", colour: "" };
  let current = null;
  let tickStart = null;
  let tickTime = null;

  const closeCurrent = (isOpen) => {
    if (!current) return;
    segments.push({
      cabinNumber: current.cabinNumber,
      vin1: current.vin1,
      vin2: current.vin2,
      skid: current.skid,
      hanger: mode(current.hanger),
      type: mode(current.type),
      colour: mode(current.colour),
      entryTime: new Date(current.entryTime),
      exitTime: new Date(current.lastTime),
      dwellSeconds: Math.round((current.lastTime - current.entryTime) / 1000),
      samples: current.samples,
      isOpen: Boolean(isOpen),
    });
    current = null;
  };

  const evaluateTick = (time) => {
    const present = state.skid > 0 && state.vin2 !== "";
    const cabinNumber = present ? buildCabinNumber(state.vin1, state.vin2) : null;
    const key = present ? `${cabinNumber}|${state.skid}` : null;

    if (current && (key !== current.key || time - current.lastTime > MAX_TICK_GAP_MS)) {
      closeCurrent(false);
    }
    if (!present) return;

    if (!current) {
      current = {
        key,
        cabinNumber,
        vin1: state.vin1,
        vin2: state.vin2,
        skid: state.skid,
        entryTime: time,
        lastTime: time,
        samples: 0,
        hanger: {},
        type: {},
        colour: {},
      };
    }
    current.lastTime = time;
    current.samples += 1;
    for (const f of ["hanger", "type", "colour"]) {
      if (state[f] !== "") current[f][state[f]] = (current[f][state[f]] || 0) + 1;
    }
  };

  for (const s of samples) {
    const ts = new Date(s.timestamp).getTime();
    if (tickStart === null) {
      tickStart = ts;
      tickTime = ts;
    } else if (ts - tickStart > TICK_GROUP_MS) {
      evaluateTick(tickTime);
      tickStart = ts;
      tickTime = ts;
    }
    if (s.field === "skid") state.skid = asNumber(s.value);
    else if (s.field in state) state[s.field] = asText(s.value);
  }
  if (tickStart !== null) evaluateTick(tickTime);
  closeCurrent(true); // whatever is still present when data ends

  return segments;
}

module.exports = {
  segmentSamples,
  buildCabinNumber,
  TICK_GROUP_MS,
  MAX_TICK_GAP_MS,
};
