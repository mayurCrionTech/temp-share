/**
 * passBuilder.js — pure helpers (no DB) for the Analytics search + journey APIs.
 */

const PT_FIRST = { PT: 0, ED: 1 };

function firstNonEmpty(values) {
  return values.find((v) => v !== undefined && v !== null && v !== "") ?? "";
}

/**
 * Group per-stage occurrence rows into vehicle "passes" (one row per
 * cabinNumber + skid). Used by the search results list.
 */
function groupPasses(occurrences) {
  const byKey = new Map();
  for (const o of occurrences) {
    const key = `${o.cabinNumber}|${o.skid}`;
    if (!byKey.has(key)) byKey.set(key, []);
    byKey.get(key).push(o);
  }

  const rows = [];
  for (const [key, list] of byKey.entries()) {
    list.sort((a, b) => new Date(a.entryTime) - new Date(b.entryTime));
    const stageIds = new Set(list.flatMap((o) => o.stageIds || []));
    rows.push({
      passKey: key,
      cabinNumber: list[0].cabinNumber,
      skid: list[0].skid,
      hanger: firstNonEmpty(list.map((o) => o.hanger)),
      type: firstNonEmpty(list.map((o) => o.type)),
      colour: firstNonEmpty(list.map((o) => o.colour)),
      firstEntryTime: list[0].entryTime,
      lastExitTime: list.reduce(
        (max, o) => (new Date(o.exitTime) > new Date(max) ? o.exitTime : max),
        list[0].exitTime,
      ),
      stagesSeen: stageIds.size,
    });
  }
  rows.sort((a, b) => new Date(a.firstEntryTime) - new Date(b.firstEntryTime));
  return rows;
}

/**
 * Lay one vehicle's occurrences over the ordered stage master.
 * mappedStageIds = stages that HAVE an occupancy asset (so a missing
 * occurrence means "not seen", vs. "we can't track this stage at all").
 */
function buildJourney(stages, occurrences, mappedStageIds) {
  const ordered = [...stages].sort(
    (a, b) => PT_FIRST[a.line] - PT_FIRST[b.line] || a.order - b.order,
  );
  const sorted = [...occurrences].sort(
    (a, b) => new Date(a.entryTime) - new Date(b.entryTime),
  );

  const lines = { PT: [], ED: [] };
  for (const stage of ordered) {
    const occ = sorted.find((o) => (o.stageIds || []).includes(stage.stageId));
    const base = {
      stageId: stage.stageId,
      order: stage.order,
      name: stage.name,
      tagCount: (stage.tags || []).length,
    };

    if (occ) {
      lines[stage.line].push({
        ...base,
        status: "visited",
        entryTime: occ.entryTime,
        exitTime: occ.exitTime,
        dwellSeconds: occ.dwellSeconds,
        sharedAsset: (occ.stageIds || []).length > 1,
      });
    } else if (stage.isManualInspection) {
      lines[stage.line].push({ ...base, status: "manual", reason: "Manual inspection, no PLC tags" });
    } else if (!mappedStageIds.has(stage.stageId)) {
      lines[stage.line].push({ ...base, status: "untracked", reason: "No occupancy asset mapped for this stage" });
    } else {
      lines[stage.line].push({ ...base, status: "not_seen" });
    }
  }
  return lines;
}

module.exports = { groupPasses, buildJourney };
