/**
 * logSampleFinder.js — pure helper for LOG-source tags.
 *
 * Log tags (bath chemistry etc.) are typed in by operators on log forms
 * ("logtotag" fields). tag_lives only keeps the LATEST value, so history lives
 * in the log entries: logEntries.data[] = { tagId, type, fieldValue,
 * fieldEnteredAt, isFilled }.
 *
 * For each wanted tagId this returns the most recently ENTERED value at or
 * before `at`. A value entered after the vehicle had left is ignored.
 */
function pickLogSamples(entries, tagIds, at) {
  const wanted = new Set((tagIds || []).map(String));
  const atMs = new Date(at).getTime();
  const found = new Map();

  for (const entry of entries || []) {
    for (const item of entry.data || []) {
      if (!item || item.tagId === null || item.tagId === undefined) continue;
      const id = String(item.tagId);
      if (!wanted.has(id)) continue;
      if (item.type && item.type !== "logtotag") continue;
      if (item.isFilled === false) continue;
      if (item.fieldValue === "" || item.fieldValue === null || item.fieldValue === undefined) continue;

      const capturedAt = new Date(item.fieldEnteredAt || entry.entryCreatedAt);
      if (isNaN(capturedAt) || capturedAt.getTime() > atMs) continue;

      const prev = found.get(id);
      if (!prev || capturedAt > prev.timestamp) {
        found.set(id, { timestamp: capturedAt, value: item.fieldValue });
      }
    }
  }
  return found;
}

module.exports = { pickLogSamples };
