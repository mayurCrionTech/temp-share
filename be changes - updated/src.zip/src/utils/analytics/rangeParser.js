/**
 * rangeParser.js — parses the reference-range strings used in the functional
 * doc (Section 10). Handles every format present in the 108 tags:
 *   "50-60 ºC"  "0.9 - 1.1 Bar"  "0.9 to 1.1 Bar"  "1.5 -1.8 Bar"
 *   "< 0.7 Bar" "<= 10 µs/cm"    "> 1950 LPH"      "270 ± 30 mm"  "9.0-11.0"
 * Returns { min, max, minInclusive, maxInclusive, unit } (min/max null when
 * open-ended) or null when the string is empty / "—" / not a range.
 */
const NUM = "(\\d+(?:\\.\\d+)?)";

function parseRange(raw) {
  if (raw === undefined || raw === null) return null;
  const text = String(raw).trim();
  if (!text || text === "—" || text === "-") return null;

  let m = text.match(new RegExp(`^${NUM}\\s*±\\s*${NUM}\\s*(.*)$`));
  if (m) {
    const centre = Number(m[1]);
    const delta = Number(m[2]);
    return { min: centre - delta, max: centre + delta, minInclusive: true, maxInclusive: true, unit: m[3].trim() };
  }

  m = text.match(new RegExp(`^(<=|>=|<|>)\\s*${NUM}\\s*(.*)$`));
  if (m) {
    const op = m[1];
    const n = Number(m[2]);
    const unit = m[3].trim();
    if (op === "<") return { min: null, max: n, minInclusive: false, maxInclusive: false, unit };
    if (op === "<=") return { min: null, max: n, minInclusive: false, maxInclusive: true, unit };
    if (op === ">") return { min: n, max: null, minInclusive: false, maxInclusive: false, unit };
    return { min: n, max: null, minInclusive: true, maxInclusive: false, unit };
  }

  m = text.match(new RegExp(`^${NUM}\\s*(?:-|–|to)\\s*${NUM}\\s*(.*)$`, "i"));
  if (m) {
    const a = Number(m[1]);
    const b = Number(m[2]);
    return { min: Math.min(a, b), max: Math.max(a, b), minInclusive: true, maxInclusive: true, unit: m[3].trim() };
  }

  return null;
}

module.exports = { parseRange };
