/**
 * readingEvaluator.js — pure helpers that compare readings with a parsed range.
 *
 * Status per tag: in_range | out_of_range | no_data.
 * Live tags are read over the vehicle's dwell window; the headline value is the
 * LAST sample in the window, and min/max/avg + `breached` (any sample outside
 * the range) are returned alongside so a brief excursion is not hidden.
 * Log tags use the latest sample taken at or before the vehicle entered.
 */

// Values are float32 in the PLC (1.1 arrives as 1.100000023...), so allow a
// tiny tolerance at the boundaries.
const tol = (bound) => 1e-6 * Math.max(1, Math.abs(bound));
const round = (n) => Number(n.toFixed(4));

function isInRange(value, range) {
  if (!range) return null; // no range defined -> cannot judge
  if (range.min !== null) {
    const below = range.minInclusive ? value < range.min - tol(range.min) : value <= range.min + tol(range.min);
    if (below) return false;
  }
  if (range.max !== null) {
    const above = range.maxInclusive ? value > range.max + tol(range.max) : value >= range.max - tol(range.max);
    if (above) return false;
  }
  return true;
}

const numeric = (samples) =>
  samples
    .map((s) => ({ timestamp: s.timestamp, value: typeof s.value === "number" ? s.value : Number(s.value) }))
    .filter((s) => s.value !== null && Number.isFinite(s.value) && s.value === s.value);

function statusOf(value, range) {
  const ok = isInRange(value, range);
  if (ok === null) return "no_data";
  return ok ? "in_range" : "out_of_range";
}

function evaluateLive(samples, range) {
  const nums = numeric(samples || []);
  if (!nums.length) return { status: "no_data", value: null, capturedAt: null, samples: 0 };
  const last = nums[nums.length - 1];
  const values = nums.map((s) => s.value);
  return {
    status: statusOf(last.value, range),
    value: round(last.value),
    capturedAt: last.timestamp,
    min: round(Math.min(...values)),
    max: round(Math.max(...values)),
    avg: round(values.reduce((a, b) => a + b, 0) / values.length),
    samples: values.length,
    breached: range ? values.some((v) => isInRange(v, range) === false) : false,
  };
}

function evaluateLog(sample, range) {
  const nums = sample ? numeric([sample]) : [];
  if (!nums.length) return { status: "no_data", value: null, capturedAt: null, samples: 0 };
  return {
    status: statusOf(nums[0].value, range),
    value: round(nums[0].value),
    capturedAt: nums[0].timestamp,
    samples: 1,
  };
}

/** Stage colour: red if any tag is out of range, green if all judged tags are in range, else no_data. */
function summariseStage(tagResults) {
  const statuses = tagResults.map((t) => t.status);
  if (statuses.includes("out_of_range")) return "out_of_range";
  if (statuses.includes("in_range")) return "in_range";
  return "no_data";
}

module.exports = { isInRange, evaluateLive, evaluateLog, summariseStage };
