const { sendEmail } = require('../emailService');
const Handlebars = require('handlebars');
const path = require('path');
const fs = require('fs').promises;
const EmailDeliveryStatus = require('../../../models/mongoDB/emailSystem/emailDelivertStatus_model');
const { generateWorkOrderReportPDF } = require('../../../managers/internalManagers/maintenanceManagement/workOrderPdfReport_manager'); // adjust path

Handlebars.registerHelper('formatDate', (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-GB', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: false, timeZone: 'Asia/Kolkata'
    }) + ' IST';
});

const sendPreventiveWorkOrderEmail = async (to, subject, workOrderId, user, cc = []) => {
    try {
        // Step 1: Generate PDF
        const pdfData = await generateWorkOrderReportPDF(workOrderId, user);

        // Step 2: Read PDF as base64
        const pdfBuffer = await fs.readFile(pdfData.filePath);
        const pdfBase64 = pdfBuffer.toString('base64');

        // Step 3: Build simple email HTML (same style as log report)
        const templatePath = path.join(__dirname, './', 'preventiveWorkOrderEmailTemplate.html');
        const templateStr = await fs.readFile(templatePath, 'utf8');
        const template = Handlebars.compile(templateStr);
        const emailHtml = template({
            receiverName: user.name,
            generationDate: new Date().toISOString()
        });

        // Step 4: Save to DB as PENDING
        const emailDeliveryRecord = await EmailDeliveryStatus.create({
            to,
            subject,
            htmlContent: emailHtml,
            cc,
            attachments: [{ filename: pdfData.name, filePath: pdfData.filePath }],
            type: 'PREVENTIVE_WORK_ORDER',
            status: 'PENDING'
        });

        // Step 5: Send email
        try {
            await sendEmail(to, subject, emailHtml, {
                attachments: [{
                    filename: pdfData.name + '.pdf' || 'WorkOrder_Report.pdf',
                    content: pdfBuffer
                }],
                cc
            });

            await EmailDeliveryStatus.findByIdAndUpdate(emailDeliveryRecord._id, {
                status: 'SENT',
                sentAt: new Date()
            });

        } catch (sendError) {
            console.log('Email sending failed, saved to DB for retry:', sendError);
            await EmailDeliveryStatus.findByIdAndUpdate(emailDeliveryRecord._id, {
                errorMessage: sendError.message || String(sendError)
            });
        }
    } catch (error) {
        console.error('Failed to send work order report email:', error);
        throw error;
    }
};

module.exports = { sendPreventiveWorkOrderEmail };