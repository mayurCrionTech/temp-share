// #QID_174 

const mongoose = require("mongoose");

const deviationConditionConfigSchema = new mongoose.Schema(
  {
    // Numeric tag whose deviation depends on operating conditions
    numericTagId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Tag_Live",
      required: true,
    },

    // Multiple condition tags; any TRUE condition satisfies the OR logic
    conditionTagIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Tag_Live",
        required: true,
      },
    ],

    // Allows a configuration to be temporarily disabled
    isEnabled: {
      type: Boolean,
      default: true,
    },

    // Users who created or last updated this configuration
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
    },
  },
  {
    timestamps: true,
    collection: "deviation_condition_configs",
  },
);

// Only one configuration per numeric tag
deviationConditionConfigSchema.index({ numericTagId: 1 }, { unique: true });

const DeviationConditionConfig = mongoose.model(
  "DeviationConditionConfig",
  deviationConditionConfigSchema,
);

module.exports = DeviationConditionConfig;
