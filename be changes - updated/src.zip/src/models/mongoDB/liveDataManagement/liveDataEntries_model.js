// In liveData-model.js
const mongoose = require("mongoose");
const liveDataEntriesSchema = new mongoose.Schema({
  tagId: {
    type: mongoose.SchemaTypes.ObjectId,
    ref:"liveData"},
  value: Number,
  orgId: String,
  businessUnitId: String,
  timestamp: Date,
});

const LiveDataEntries = mongoose.model("LiveDataEntries", liveDataEntriesSchema, "liveDataEntries"); // 3rd arg forces the exact collection name

module.exports = LiveDataEntries;