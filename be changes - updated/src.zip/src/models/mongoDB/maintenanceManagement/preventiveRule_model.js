const mongoose = require("mongoose");

const preventiveRule = preventiveRuleConstants();
const priorityEnum = Object.values(preventiveRule.priority);
const statusEnum = Object.values(preventiveRule.status);
const operatorEnum = Object.values(preventiveRule.operator);

const preventiveRuleSchema = new mongoose.Schema({
  ruleName: {
    type: String,
    // required: true,
  },
//   maintenancePlan: {
//     type: mongoose.SchemaTypes.ObjectId,
//     ref: "MaintenancePlan",
//     required: true,
//   },
  // asset: {
  //   type: mongoose.SchemaTypes.ObjectId,
  //   ref: "Asset",
  //   required: true,
  // },
  // businessUnit: {
  //   type: mongoose.SchemaTypes.ObjectId,
  //   ref: "BusinessUnit",
  //   required: true,
  // },
  tagId: {
    type: String,
    required: false,
  },
  parameter: {
    type: String,
    required: true,
  },
  operator: {
    type: String,
    enum: operatorEnum,
    required: true,
    default: ">",
  },
  cutoffValue: {
    type: Number,
    required: true,
    min: 0,
  },
  unit: {
    type: String,
  },
  evaluationFrequency: {
    type: String,
    default: "onUpdate", // "onUpdate" | "15min" | etc.
  },
  autoRearm: {
    type: Boolean,
    default: true,
  },
  priority: {
    type: String,
    enum: priorityEnum,
    default: "Medium-P2",
  },
  status:{
    type: String,
    enum: statusEnum,
    default: "Active"
  },
  version: {
    type: Number,
    default: 1,
  },
  lastTriggeredValue: {
    type: Number,
    default: null,
  },
  accumulatedValue: {
  type: Number,
  default: 0,
  },
 lastEvaluatedAt: {
   type: Date,
   default: null,
 },
  lastWorkOrderId: {
    type: mongoose.SchemaTypes.ObjectId,
    ref: "WorkOrder",
    default: null,
  },
  isDeleted: {
    type: Boolean,
    required: true,
    default: false,
  },
  createdBy: {
    type: mongoose.SchemaTypes.ObjectId,
    ref: "User",
  },
  updatedBy: {
    type: mongoose.SchemaTypes.ObjectId,
    ref: "User",
  },
}, { timestamps: true });

preventiveRuleSchema.index({ isDeleted: 1, businessUnit: 1, asset: 1 });
preventiveRuleSchema.index({ isDeleted: 1, businessUnit: 1 });
preventiveRuleSchema.index({ isDeleted: 1, tagId: 1 }); // hot path for evaluation loop

const PreventiveRule = mongoose.model("PreventiveRule", preventiveRuleSchema, "preventiveRules");

function preventiveRuleConstants() {
  return {
    priority: {
      High_P1: "High-P1",
      Medium_P2: "Medium-P2",
      Low_P3: "Low-P3",
    },
    status:{
      Active: "Active",
      Paused: "Paused"
    },
    operator: {
      GT: ">",
      GTE: ">=",
      LT: "<",
      LTE: "<=",
    },
  };
}

module.exports = { preventiveRule, PreventiveRule };