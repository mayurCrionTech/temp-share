/**
 * vehicleStageOccurrence_model.js
 * Place at: src/models/mongoDB/analyticsManagement/vehicleStageOccurrence_model.js
 *
 * Materialised "vehicle X was at line asset Y from A to B" records, derived
 * from identity-tag history in liveData_test. Search/journey APIs read this
 * collection instead of scanning raw tag history on every request.
 *
 * One row per (asset, vehicle pass). A shared asset (e.g. WATER RINSE 1&2)
 * lists both of its stages in stageIds.
 */
const mongoose = require("mongoose");

const vehicleStageOccurrenceSchema = new mongoose.Schema(
  {
    assetId: { type: mongoose.Schema.Types.ObjectId, ref: "Asset", required: true },
    assetNumber: { type: String, required: true }, // e.g. "40201"
    assetName: { type: String, default: "" },
    stageIds: { type: [String], required: true }, // e.g. ["PT-3","PT-4"]

    cabinNumber: { type: String, required: true }, // Serial_No_VIN_1 + Serial_No_VIN_2
    vin1: { type: String, default: "" },
    vin2: { type: String, default: "" },
    skid: { type: Number, required: true },
    hanger: { type: String, default: "" },
    type: { type: String, default: "" }, // Cab_Body_Code
    colour: { type: String, default: "" }, // Color_Code1

    entryTime: { type: Date, required: true },
    exitTime: { type: Date, required: true }, // last tick the vehicle was seen
    dwellSeconds: { type: Number, default: 0 },
    samples: { type: Number, default: 0 },
    isOpen: { type: Boolean, default: false }, // still present when data ended
  },
  { timestamps: true },
);

vehicleStageOccurrenceSchema.index({ entryTime: 1 });
vehicleStageOccurrenceSchema.index({ assetNumber: 1, entryTime: 1 });
vehicleStageOccurrenceSchema.index({ cabinNumber: 1, skid: 1, entryTime: 1 });
vehicleStageOccurrenceSchema.index({ hanger: 1, entryTime: 1 });
vehicleStageOccurrenceSchema.index({ skid: 1, entryTime: 1 });

module.exports = mongoose.model(
  "VehicleStageOccurrence",
  vehicleStageOccurrenceSchema,
  "vehicle_stage_occurrences",
);
