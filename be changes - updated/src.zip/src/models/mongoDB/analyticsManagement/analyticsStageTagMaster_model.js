/**
 * analyticsStageTagMaster_model.js
 *
 * Source-of-truth master data for the Analytics tab (Section 10 of the
 * functional doc — 19 stages, 108 tags across PT + ED lines).
 *
 * Drop this in: src/models/mongoDB/analyticsManagement/analyticsStageTagMaster_model.js
 *
 * One document per STAGE. Each stage embeds its own tag list so a single
 * find() gives you everything needed to render one stage's tag table —
 * no join required for the hot path (rendering the stage journey).
 */

const mongoose = require("mongoose");

const stageTagSchema = new mongoose.Schema(
  {
    // Human label shown in the UI, e.g. "Bath Temperature"
    name: { type: String, required: true },

    // Real ObjectId in the Tag_Live collection (tag_lives), resolved at
    // seed time from the functional doc's abbreviated tag ID. Null when
    // the doc's Source column says "Not mapped" (see doc tables 10 & 14).
    tagId: { type: mongoose.Schema.Types.ObjectId, ref: "Tag_Live", default: null },

    // Raw range string as written in the doc, e.g. "50-60 ºC", "< 0.8",
    // "270 ± 30 mm". Parsed at read-time with the shared range parser —
    // kept raw here so the doc stays the single source of truth.
    rangeRaw: { type: String, default: "" },

    // "Live" (direct PLC, has a real-time timestamp) | "Log" (periodic
    // lab/batch sample) | "Not mapped" (no PLC tag exists yet).
    source: {
      type: String,
      enum: ["Live", "Log", "Not mapped"],
      required: true,
    },
  },
  { _id: false },
);

const stageSchema = new mongoose.Schema(
  {
    // "PT-6" / "ED-3" — matches the doc's stage numbering exactly.
    stageId: { type: String, required: true, unique: true, index: true },

    // "PT" | "ED"
    line: { type: String, enum: ["PT", "ED"], required: true },

    // Position within the line's own sequence (1-11 for PT, 1-8 for ED).
    // Two horizontal timelines are rendered in this order (Section 6).
    order: { type: Number, required: true },

    // "Degreasing Spray", "Phosphating", etc.
    name: { type: String, required: true },

    // true for PT-11 (PT Wet Inspection) and ED-8 (EC Wet Inspection) —
    // manual visual checks, no tags, rendered as dashed-grey nodes.
    isManualInspection: { type: Boolean, default: false },

    tags: { type: [stageTagSchema], default: [] },
  },
  { timestamps: true },
);

module.exports = mongoose.model(
  "AnalyticsStageTagMaster",
  stageSchema,
  "analytics_stage_tag_master",
);
