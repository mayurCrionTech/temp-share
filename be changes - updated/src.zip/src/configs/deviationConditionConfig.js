/**
 * File: src/configs/deviationConditionConfig.js
 *
 * Purpose:
 * Maps numeric tag MongoDB IDs to associated operating-condition
 * tag MongoDB IDs for conditional deviation monitoring.
 *
 * Behaviour:
 * - If ANY associated condition tag has latestValue === true,
 *   the existing deviation-registration flow continues.
 * - If all associated conditions are false, null, or unavailable,
 *   deviation registration is skipped for that configured tag.
 * - Tags not present in this configuration retain existing behaviour.
 *
 * IMPORTANT:
 * - All IDs are MongoDB document IDs, not PLC tag names.
 * - Some numeric tags are shared across stages. Their condition IDs
 *   are combined to avoid duplicate object keys overwriting mappings.
 */

module.exports = {
  // ============================================================
  // DEGREASING SPRAY
  // Condition: P001_PUS_211.ConfirmOn
  // Condition ID: 6a7c688863f1464aebae764a
  // ============================================================

  // Spray Pressure Bottom | PT_I5_1 | Range: 0.9–1.1 Bar
  "699426acbfb07d6db09a050a": ["6a7c688863f1464aebae764a"],

  // Spray Pressure Top | PT_I5_0 | Range: 0.9–1.1 Bar
  "699426acbfb07d6db09a0507": ["6a7c688863f1464aebae764a"],

  // ============================================================
  // WATER RINSE 1 + WATER RINSE 2
  //
  // Shared numeric tags:
  // PT_I1_3 -> 699426acbfb07d6db09a055b
  // PT_I1_4 -> 699426acbfb07d6db09a055e
  //
  // WATER RINSE 1 conditions (OR):
  // Pump: P001_PUS_311.ConfirmOn
  // ID:   6a7c688863f1464aebae76dd
  // Valve: P001_VAA_311.Open_FB
  // ID:    6a7c688863f1464aebae76d7
  //
  // WATER RINSE 2 conditions (OR):
  // Pump: P001_PUS_321.ConfirmOn
  // ID:   6a7c688863f1464aebae7704
  // Valve: P001_VAA_321.Open_FB
  // ID:    6a7c688863f1464aebae76fe
  //
  // Because these numeric tags are shared, all four condition IDs
  // are included. Any one condition being true enables checking.
  // ============================================================

  // Spray Pressure Top | PT_I1_3
  "699426acbfb07d6db09a055b": [
    "6a7c688863f1464aebae76dd", // WR1 pump
    "6a7c688863f1464aebae76d7", // WR1 valve open
    "6a7c688863f1464aebae7704", // WR2 pump
    "6a7c688863f1464aebae76fe", // WR2 valve open
  ],

  // Spray Pressure Bottom | PT_I1_4
  "699426acbfb07d6db09a055e": [
    "6a7c688863f1464aebae76dd", // WR1 pump
    "6a7c688863f1464aebae76d7", // WR1 valve open
    "6a7c688863f1464aebae7704", // WR2 pump
    "6a7c688863f1464aebae76fe", // WR2 valve open
  ],

  // ============================================================
  // WATER RINSE 3 + WATER RINSE 4
  //
  // Shared numeric tags:
  // PT_I3_0 -> 699426acbfb07d6db09a05a6
  // PT_I3_1 -> 699426acbfb07d6db09a05a9
  //
  // WATER RINSE 3 conditions (OR):
  // Pump: P001_PUS_611.ConfirmOn
  // ID:   6a7c688863f1464aebae77ce
  // Valve: P001_VAA_611.Open_FB
  // ID:    6a7c688863f1464aebae77d1
  //
  // WATER RINSE 4 conditions (OR):
  // Pump: P001_PUS_621.ConfirmOn
  // ID:   6a7c688963f1464aebae77f5
  // Valve: P001_VAA_621.Open_FB
  // ID:    6a7c688963f1464aebae77f8
  //
  // Because these numeric tags are shared, all four condition IDs
  // are included. Any one condition being true enables checking.
  // ============================================================

  // Spray Pressure Top | PT_I3_0
  "699426acbfb07d6db09a05a6": [
    "6a7c688863f1464aebae77ce", // WR3 pump
    "6a7c688863f1464aebae77d1", // WR3 valve open
    "6a7c688963f1464aebae77f5", // WR4 pump
    "6a7c688963f1464aebae77f8", // WR4 valve open
  ],

  // Spray Pressure Bottom | PT_I3_1
  "699426acbfb07d6db09a05a9": [
    "6a7c688863f1464aebae77ce", // WR3 pump
    "6a7c688863f1464aebae77d1", // WR3 valve open
    "6a7c688963f1464aebae77f5", // WR4 pump
    "6a7c688963f1464aebae77f8", // WR4 valve open
  ],

  // ============================================================
  // UF RINSE-1 (SPRAY)
  // Conditions (OR):
  // Pump: P101_PUS_221.ConfirmOn
  // ID:   6a7c688963f1464aebae78ce
  // Valve: P101_VAA_211.Open_FB
  // ID:    6a7c688963f1464aebae78d1
  // ============================================================

  // Spray Pressure - Bottom | ED_I3_2 | Range: 0.9–1.1
  "699d79eaefe574e9bb9999ec": [
    "6a7c688963f1464aebae78ce", // Pump running feedback
    "6a7c688963f1464aebae78d1", // Valve open feedback
  ],

  // Spray Pressure - Side 1 | ED_I3_3 | Range: 0.9–1.1
  "699d79edefe574e9bb9aeb6d": [
    "6a7c688963f1464aebae78ce",
    "6a7c688963f1464aebae78d1",
  ],

  // Spray Pressure - Side 2 | ED_I3_4 | Range: 0.9–1.1
  "699d79f0efe574e9bb9c3cee": [
    "6a7c688963f1464aebae78ce",
    "6a7c688963f1464aebae78d1",
  ],

  // Spray Pressure - Side 3 | ED_I3_5 | Range: 1.4–1.6
  "699d79f2efe574e9bb9d8e6f": [
    "6a7c688963f1464aebae78ce",
    "6a7c688963f1464aebae78d1",
  ],

  // Spray Pressure - Side 4 | ED_I3_6 | Range: 0.9–1.1
  "699d79f5efe574e9bb9edff0": [
    "6a7c688963f1464aebae78ce",
    "6a7c688963f1464aebae78d1",
  ],

  // ============================================================
  // UF RINSE-2 (DIP)
  // Conditions (OR):
  // Pump: P101_PUS_221.ConfirmOn
  // ID:   6a7c688963f1464aebae78ce
  // Valve: P101_VAA_211.Open_FB
  // ID:    6a7c688963f1464aebae78d1
  // ============================================================

  // Circulation Pressure - Bottom 1 | ED_I3_7 | Range: 1.3–1.7
  "699d79ffefe574e9bba425f4": [
    "6a7c688963f1464aebae78ce",
    "6a7c688963f1464aebae78d1",
  ],

  // Circulation Pressure - Bottom 2 | ED_I4_0 | Range: 1.3–1.7
  "699d7a01efe574e9bba57775": [
    "6a7c688963f1464aebae78ce",
    "6a7c688963f1464aebae78d1",
  ],

  // Circulation Pressure - Bottom 3 | ED_I4_1 | Range: 1.3–1.7
  "699d7a04efe574e9bba6c8f6": [
    "6a7c688963f1464aebae78ce",
    "6a7c688963f1464aebae78d1",
  ],
};
