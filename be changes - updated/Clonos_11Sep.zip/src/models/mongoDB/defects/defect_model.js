const mongoose = require("mongoose");
const { Schema } = mongoose;

const ruleSchema = new Schema(
  {
    stage: {
      type: String,
      required: true,
    },
    operator: {
      type: String,
      required: true,
    },
    threshold: {
      type: Number,
      required: true,
    },
    tag_id: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    tagName: {
      type: String,
      required: true,
    },
  },
  { _id: false } // sub-documents here don't have their own _id, matching your sample
);

const defectRuleSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true, // e.g. "CRATER", "RUSTING" — assuming defect names are unique
    },
    rules: {
      type: [ruleSchema],
      default: [],
    },
  },
);

const Defect = mongoose.model("Defect", defectRuleSchema, "defects");

module.exports = { Defect };