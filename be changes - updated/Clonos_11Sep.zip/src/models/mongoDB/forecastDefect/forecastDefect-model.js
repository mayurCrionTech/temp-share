const mongoose = require("mongoose");

const TriggeredRuleSchema = new mongoose.Schema(
  {
    tag_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "TagLive",
      required: true,
      index: true,
    },
    tagName:{
      type: String,
    },
    operator: {
      type: String,
      required: true,
      enum: ["<", ">", "<=", ">=", "==", "!="],
    },
    threshold: {
      type: Number,
      required: true,
    },
    forecastedValue: {
      type: Number,
      required: true,
    },
  },
  { _id: false }
);

const DetectedDefectSchema = new mongoose.Schema(
  {
    defectId: {
      type: mongoose.Schema.Types.ObjectId,
      ref:"Defect",
      required: true,
    },
    triggeredRules: {
      type: [TriggeredRuleSchema],
      default: [],
    },
    probabilityScore: {
      type: Number,
      required: true,
    },
    riskLevel: {
      type: String,
      required: true,
      enum: ["LOW", "MEDIUM", "HIGH", "CRITICAL"],
    },
    acknowledged:{
      type: Boolean,
      default: false
    },
    acknowledgedBy: {
      type: String
    },
    acknowledgedAt:{
      type: Date
    }
  },
  { _id: false }
);

const ForecastDefectSchema = new mongoose.Schema(
  {
    forecastTimestamp: {
      type: Date,
      required: true,
    },
    detectedDefects: {
      type: [DetectedDefectSchema],
      default: [],
    },
    firstDetectedAt: {
      type: Date,
    },
    lastStatusChangeAt: {
      type: Date,
    },
    lastUpdatedAt: {
      type: Date,
      default: Date.now,
    },
    status: {
      type: String,
      required: true,
      enum: ["ACTIVE", "RESOLVED", "INACTIVE"],
      default: "ACTIVE",
    }
  },
  {
    timestamps: true, // Set to true if you want createdAt and updatedAt automatically
    collection: "forecastDefects",
  }
);

module.exports = mongoose.model("ForecastDefect", ForecastDefectSchema, "forecastDefects");