/**
 * backfillStageOccurrences.js
 * Place at: scripts/backfillStageOccurrences.js
 *
 *   node backfillStageOccurrences.js <fromISO> <toISO> [assetNumber]
 *   node backfillStageOccurrences.js 2026-08-13T00:00:00Z 2026-08-13T23:59:59Z
 *   node backfillStageOccurrences.js 2026-08-13T00:00:00Z 2026-08-13T23:59:59Z 40201
 *
 * Builds vehicle_stage_occurrences for every PT/ED line asset (or one asset).
 * Safe to re-run for the same window: rows that start in the window are replaced.
 */
// node scripts/backfillStageOccurrences.js 2026-08-13T00:00:00Z 2026-09-29T00:00:00Z
// can run this one time fill
const mongoose = require("mongoose");
const dbConfig = require("../src/configs/mongoDb_config");

const ANALYTICS_MONGO_URL =
  process.env.ANALYTICS_MONGO_URL || "mongodb://localhost:27017/paintddt";
const resolvedMongoUrl =
  dbConfig.MONGO_DB_URL && !dbConfig.MONGO_DB_URL.startsWith("undefined://")
    ? dbConfig.MONGO_DB_URL
    : ANALYTICS_MONGO_URL;

const { backfillOccurrences } = require("../src/managers/internalManagers/analyticsManagement/analyticsOccurrence.service");

const [, , fromArg, toArg, assetArg] = process.argv;
if (!fromArg || !toArg) {
  console.error("Usage: node backfillStageOccurrences.js <fromISO> <toISO> [assetNumber]");
  process.exit(1);
}

async function run() {
  const from = new Date(fromArg);
  const to = new Date(toArg);
  if (isNaN(from) || isNaN(to)) throw new Error("from/to must be valid ISO dates");

  await mongoose.connect(resolvedMongoUrl);
  console.log(`Connected. Backfilling ${from.toISOString()} -> ${to.toISOString()}\n`);

  const summary = await backfillOccurrences({
    from,
    to,
    assetNumbers: assetArg ? [assetArg] : undefined,
  });

  for (const s of summary) {
    console.log(
      `#${s.assetNumber} ${String(s.assetName).trim().padEnd(22)} ${s.stageIds.join("+").padEnd(10)} ${String(s.occurrences).padStart(4)} occurrences` +
        (s.missingOptionalTags.length ? `   (no tag for: ${s.missingOptionalTags.join(", ")})` : ""),
    );
  }
  console.log(`\nTotal: ${summary.reduce((n, s) => n + s.occurrences, 0)} occurrences written.`);
  await mongoose.disconnect();
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});


// old -> 
// /**
//  * backfillStageOccurrences.js
//  * Place at: scripts/backfillStageOccurrences.js
//  *
//  *   node backfillStageOccurrences.js <fromISO> <toISO> [assetNumber]
//  *   node backfillStageOccurrences.js 2026-08-13T00:00:00Z 2026-08-13T23:59:59Z
//  *   node backfillStageOccurrences.js 2026-08-13T00:00:00Z 2026-08-13T23:59:59Z 40201
//  *
//  * Builds vehicle_stage_occurrences for every PT/ED line asset (or one asset).
//  * Safe to re-run for the same window: rows that start in the window are replaced.
//  */
// const mongoose = require("mongoose");
// const dbConfig = require("../src/configs/mongoDb_config");

// const ANALYTICS_MONGO_URL =
//   process.env.ANALYTICS_MONGO_URL || "mongodb://localhost:27017/paintddt";
// const resolvedMongoUrl =
//   dbConfig.MONGO_DB_URL && !dbConfig.MONGO_DB_URL.startsWith("undefined://")
//     ? dbConfig.MONGO_DB_URL
//     : ANALYTICS_MONGO_URL;

// const { backfillOccurrences } = require("../src/managers/internalManagers/analyticsManagement/analyticsOccurrence.service");

// const [, , fromArg, toArg, assetArg] = process.argv;
// if (!fromArg || !toArg) {
//   console.error("Usage: node backfillStageOccurrences.js <fromISO> <toISO> [assetNumber]");
//   process.exit(1);
// }

// async function run() {
//   const from = new Date(fromArg);
//   const to = new Date(toArg);
//   if (isNaN(from) || isNaN(to)) throw new Error("from/to must be valid ISO dates");

//   await mongoose.connect(resolvedMongoUrl);
//   console.log(`Connected. Backfilling ${from.toISOString()} -> ${to.toISOString()}\n`);

//   const summary = await backfillOccurrences({
//     from,
//     to,
//     assetNumbers: assetArg ? [assetArg] : undefined,
//   });

//   for (const s of summary) {
//     console.log(
//       `#${s.assetNumber} ${String(s.assetName).trim().padEnd(22)} ${s.stageIds.join("+").padEnd(10)} ${String(s.occurrences).padStart(4)} occurrences` +
//         (s.missingOptionalTags.length ? `   (no tag for: ${s.missingOptionalTags.join(", ")})` : ""),
//     );
//   }
//   console.log(`\nTotal: ${summary.reduce((n, s) => n + s.occurrences, 0)} occurrences written.`);
//   await mongoose.disconnect();
// }

// run().catch((err) => {
//   console.error(err);
//   process.exit(1);
// });
