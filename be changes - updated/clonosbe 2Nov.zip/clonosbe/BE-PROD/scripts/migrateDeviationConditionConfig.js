// one time script only to migrate deviation condition config to new format

/**
 * File: scripts/migrateDeviationConditionConfig.js
 *
 * Purpose:
 * Migrate static deviation condition mappings into MongoDB.
 *
 * Run from the backend project root:
 *   node scripts/migrateDeviationConditionConfig.js
 *
 * Environment:
 *   MONGO_URI or MONGODB_URI in your .env file
 *
 * Safety:
 * - Does not overwrite existing configurations.
 * - Skips numeric tags that already have a configuration.
 * - Validates numeric and condition tag IDs.
 * - Reports migration results.
 */

require("dotenv").config();

const mongoose = require("mongoose");

const staticMappings = require("../src/configs/deviationConditionConfig");

const { TagLive } = require("../src/models/mongoDB/tags/tagsModel");

const DeviationConditionConfig = require("../src/models/mongoDB/tags/deviationConditionConfig_model");

const mongoUri = "mongodb://appadmindtd:4BhJJq4TH%2F%2AYinZk%21EkQ@sascpche0159.che.dc.tbintra.net:12001/paintddt?authSource=admin";

async function main() {
  if (!mongoUri) {
    throw new Error(
      "MongoDB URI not found. Set MONGO_URI or MONGODB_URI in your .env file.",
    );
  }

  await mongoose.connect(mongoUri);

  console.log("Connected to MongoDB.");

  const entries = Object.entries(staticMappings);

  let migrated = 0;
  let alreadyConfigured = 0;
  let missingNumericTags = 0;
  let missingConditionTags = 0;
  let failed = 0;

  console.log(`Found ${entries.length} static numeric-tag mappings.\n`);

  for (const [numericTagId, conditionTagIds] of entries) {
    try {
      if (!mongoose.isValidObjectId(numericTagId)) {
        console.error(`[INVALID NUMERIC ID] ${numericTagId}`);
        failed++;
        continue;
      }

      // Preserve any configuration already created through the UI or API.
      const existing = await DeviationConditionConfig.findOne({
        numericTagId: new mongoose.Types.ObjectId(numericTagId),
      }).lean();

      if (existing) {
        console.log(`[SKIPPED: EXISTS] ${numericTagId} -> ${existing._id}`);
        alreadyConfigured++;
        continue;
      }

      // Validate that the numeric tag exists.
      const numericTag = await TagLive.findById(numericTagId)
        .select("_id tagname displayName")
        .lean();

      if (!numericTag) {
        console.error(`[MISSING NUMERIC TAG] ${numericTagId}`);
        missingNumericTags++;
        continue;
      }

      if (!Array.isArray(conditionTagIds) || conditionTagIds.length === 0) {
        console.error(`[NO CONDITIONS] ${numericTagId}`);
        failed++;
        continue;
      }

      // Remove duplicate condition IDs without changing their order.
      const uniqueConditionIds = [...new Set(conditionTagIds)];

      const invalidIds = uniqueConditionIds.filter(
        (id) => !mongoose.isValidObjectId(id),
      );

      if (invalidIds.length > 0) {
        console.error(
          `[INVALID CONDITION IDS] ${numericTagId}: ${invalidIds.join(", ")}`,
        );
        failed++;
        continue;
      }

      // Validate that all referenced condition tags exist.
      const conditionTags = await TagLive.find({
        _id: {
          $in: uniqueConditionIds.map((id) => new mongoose.Types.ObjectId(id)),
        },
      })
        .select("_id")
        .lean();

      const foundIds = new Set(conditionTags.map((tag) => tag._id.toString()));

      const missingIds = uniqueConditionIds.filter((id) => !foundIds.has(id));

      if (missingIds.length > 0) {
        console.error(
          `[MISSING CONDITION TAGS] Numeric tag ${numericTagId}: ${missingIds.join(", ")}`,
        );
        missingConditionTags++;
        continue;
      }

      // Insert the mapping. Existing mappings are never overwritten.
      await DeviationConditionConfig.create({
        numericTagId: new mongoose.Types.ObjectId(numericTagId),
        conditionTagIds: uniqueConditionIds.map(
          (id) => new mongoose.Types.ObjectId(id),
        ),
        isEnabled: true,
      });

      const label =
        (typeof numericTag.displayName === "string" &&
          numericTag.displayName.trim()) ||
        (typeof numericTag.tagname === "string" && numericTag.tagname.trim()) ||
        numericTagId;

      console.log(
        `[MIGRATED] ${label} (${numericTagId}) -> ${uniqueConditionIds.length} condition tag(s)`,
      );

      migrated++;
    } catch (error) {
      if (error.code === 11000) {
        console.warn(
          `[SKIPPED: DUPLICATE] ${numericTagId} already has a configuration.`,
        );
        alreadyConfigured++;
      } else {
        console.error(`[ERROR] ${numericTagId}: ${error.message}`);
        failed++;
      }
    }
  }

  const finalCount = await DeviationConditionConfig.countDocuments({});

  console.log("\n========== Migration Summary ==========");
  console.log(`Static mappings found:          ${entries.length}`);
  console.log(`Successfully migrated:          ${migrated}`);
  console.log(`Skipped (already configured):   ${alreadyConfigured}`);
  console.log(`Missing numeric tags:           ${missingNumericTags}`);
  console.log(`Missing condition tag mappings: ${missingConditionTags}`);
  console.log(`Other failures:                 ${failed}`);
  console.log(`Total MongoDB configurations:   ${finalCount}`);
  console.log("=======================================\n");

  if (missingNumericTags > 0 || missingConditionTags > 0 || failed > 0) {
    process.exitCode = 1;
  }
}

main()
  .catch((error) => {
    console.error("Migration failed:", error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.disconnect();
    }
  });
