/**
 * seedAnalyticsStageTagMaster.js
 *
 * One-time (re-runnable) seed script for the Analytics stage/tag master.
 * Follows the same shape as scripts/backfillTagAnomalyCache.js already in
 * the repo — run it the same way:
 *
 *   node scripts/seedAnalyticsStageTagMaster.js
 *
 * What it does:
 *   1. Loads analyticsStageTagMasterData.json — the 19 stages / 108 tags
 *      extracted directly from the functional doc's Section 10 tables.
 *   2. For every tag whose Source isn't "Not mapped", the doc only gives
 *      an ABBREVIATED tag id, e.g. "699426ac...09a050d" (first 8 + last 7
 *      hex chars — that's literally how the doc was authored). This
 *      script resolves each one against the real Tag_Live (tag_lives)
 *      collection by matching that prefix+suffix against the full
 *      24-char ObjectId, and reports anything that doesn't resolve to
 *      exactly one tag.
 *   3. Upserts one AnalyticsStageTagMaster document per stage, with tags[]
 *      carrying the *resolved* ObjectId (or null if unmapped/unresolved).
 *
 * Place analyticsStageTagMasterData.json next to this script, or update
 * DATA_PATH below.
 */

const path = require("path");
const fs = require("fs");
const mongoose = require("mongoose");

const dbConfig = require("../src/configs/mongoDb_config");

// mongoDb_config.js builds its URL from process.env.MONGO_DB_PROTOCOL directly
// (not the resolved default), so if .env isn't found in the current working
// directory (e.g. you ran `cd scripts` first) MONGO_DB_URL comes out as
// "undefined://...". ANALYTICS_MONGO_URL is a plain override for these
// diagnostic/seed scripts only — set it once here (or export it as an env
// var) to whatever connection string you've confirmed works, and it's used
// regardless of where you run the script from.
const ANALYTICS_MONGO_URL =
  process.env.ANALYTICS_MONGO_URL || "mongodb://localhost:27017/paintddt";
const resolvedMongoUrl =
  dbConfig.MONGO_DB_URL && !dbConfig.MONGO_DB_URL.startsWith("undefined://")
    ? dbConfig.MONGO_DB_URL
    : ANALYTICS_MONGO_URL;
const { TagLive } = require("../src/models/mongoDB/tags/tagsModel");
const AnalyticsStageTagMaster = require("../src/models/mongoDB/analyticsManagement/analyticsStageTagMaster_model");

const DATA_PATH = path.join(__dirname, "analyticsStageTagMasterData.json");

const ABBREV_RE = /^([0-9a-f]+)\.\.\.([0-9a-f]+)$/i;

/**
 * The functional doc lists one abbreviated id (699426ac...09a05b5) for "Total
 * Acid" under BOTH PT-7 and PT-8, but they are two different tags. The real ids
 * come from getTagDashboard (QID_165) in tag_manager.js. Keyed "stageId|tag name".
 */
const TAG_ID_OVERRIDES = {
  "PT-7|Total Acid": "6a9e9e7fa4169be4f0f3df41",
  "PT-8|Total Acid": "6a9e9e7fa4169be4f0f3df42",
};

/**
 * Resolve one doc tag entry to a real Tag_Live _id.
 * Returns { tagId, status } where status is one of:
 *   "resolved"      — exactly one Tag_Live matched the prefix+suffix
 *   "not_mapped"     — doc says "Not mapped" (tagId === "—"), expected, no action needed
 *   "unresolved"     — abbreviation matched zero tags — needs a human look
 *   "ambiguous"      — abbreviation matched more than one tag — needs a human look
 */
async function resolveTagId(rawTagId, tagName, stageId) {
  const override = TAG_ID_OVERRIDES[`${stageId}|${tagName}`];
  if (override) {
    const exists = await TagLive.exists({ _id: override });
    if (exists) return { tagId: override, status: "resolved" };
    console.warn(`  [unresolved] ${stageId} "${tagName}" override ${override} not found in Tag_Live.`);
    return { tagId: null, status: "unresolved" };
  }
  if (!rawTagId || rawTagId === "—") {
    return { tagId: null, status: "not_mapped" };
  }

  const m = rawTagId.match(ABBREV_RE);
  if (!m) {
    // Already a full 24-char id (in case the doc gets updated later).
    if (mongoose.Types.ObjectId.isValid(rawTagId)) {
      return { tagId: rawTagId, status: "resolved" };
    }
    return { tagId: null, status: "unresolved" };
  }

  const [, prefix, suffix] = m;

  // $expr + $toString lets us prefix/suffix-match on the string form of
  // an ObjectId directly in the query instead of pulling every tag home.
  const candidates = await TagLive.find({
    $expr: {
      $and: [
        { $eq: [{ $substrCP: [{ $toString: "$_id" }, 0, prefix.length] }, prefix] },
        {
          $eq: [
            { $substrCP: [{ $toString: "$_id" }, 24 - suffix.length, suffix.length] },
            suffix,
          ],
        },
      ],
    },
  })
    .select("_id tagname")
    .lean();

  if (candidates.length === 1) {
    return { tagId: candidates[0]._id, status: "resolved" };
  }
  if (candidates.length === 0) {
    console.warn(
      `  [unresolved] ${stageId} "${tagName}" (${rawTagId}) — no Tag_Live matched this prefix/suffix.`,
    );
    return { tagId: null, status: "unresolved" };
  }
  console.warn(
    `  [ambiguous] ${stageId} "${tagName}" (${rawTagId}) — ${candidates.length} tags matched: ` +
      candidates.map((c) => `${c.tagname} (${c._id})`).join(", "),
  );
  return { tagId: null, status: "ambiguous" };
}

async function run() {
  const stages = JSON.parse(fs.readFileSync(DATA_PATH, "utf8"));

  await mongoose.connect(resolvedMongoUrl);
  console.log(`Connected. Seeding ${stages.length} stages...`);

  const tally = { resolved: 0, not_mapped: 0, unresolved: 0, ambiguous: 0 };

  for (const stage of stages) {
    const resolvedTags = [];

    for (const tag of stage.tags) {
      const { tagId, status } = await resolveTagId(tag.tagId, tag.name, stage.stageId);
      tally[status]++;

      resolvedTags.push({
        name: tag.name,
        tagId,
        rangeRaw: tag.range,
        source: tag.source === "Not mapped" ? "Not mapped" : tag.source,
      });
    }

    await AnalyticsStageTagMaster.updateOne(
      { stageId: stage.stageId },
      {
        $set: {
          stageId: stage.stageId,
          line: stage.line,
          order: stage.order,
          name: stage.name,
          isManualInspection: resolvedTags.length === 0,
          tags: resolvedTags,
        },
      },
      { upsert: true },
    );

    console.log(`  seeded ${stage.stageId} — ${stage.name} (${resolvedTags.length} tags)`);
  }

  console.log("\nDone.");
  console.log(
    `Resolved: ${tally.resolved}  Not mapped (expected): ${tally.not_mapped}  ` +
      `Unresolved: ${tally.unresolved}  Ambiguous: ${tally.ambiguous}`,
  );
  if (tally.unresolved || tally.ambiguous) {
    console.log(
      "→ Anything unresolved/ambiguous above needs a manual check against the doc — " +
        "send me the tag names and I'll help track them down.",
    );
  }

  await mongoose.disconnect();
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
