# tag-csv-exporter

Polls `liveData_test` and writes one CSV per tag, for all tags belonging to
`PT Production_PLC` and `ED Production_PLC` in `tag_lives`.

## Setup

```bash
cd tag-csv-exporter
npm install
cp .env.example .env
# edit .env: set MONGO_URI and DB_NAME
```

## Run

```bash
npm start
```

Leave it running (e.g. under PM2, same as your other services) — it polls on
an interval and appends new rows as they arrive.

```bash
pm2 start index.js --name tag-csv-exporter
```

## Output

```
output/
  PT/
    PT_I5_0.csv
    PT_I5_1.csv
    ...
  ED/
    ED_XXX.csv
    ...
  _state.json      <- internal bookkeeping, don't edit
```

Each CSV has the header:

```
tagname,tagid,value,timestamp_utc,timestamp_ist
```

One row per `liveData_test` document for that tag.

## Notes / things to double check

- **Filter**: only tags where `plcName` is exactly `PT Production_PLC` or
  `ED Production_PLC` **and** `isActive: true`. Remove the `isActive` line in
  `loadTags()` in `index.js` if you also want inactive tags.
- **Frequency**: `POLL_INTERVAL_MS` in `.env` — 30000 (30s) or 60000 (1min)
  both work fine against a 10s write cadence; each poll just picks up
  whatever's new since the last one.
- **No duplicates on restart**: last-written timestamp per tag is saved in
  `_state.json`, so stopping/restarting the script won't re-write or skip
  rows.
- **First run**: starts from "now" by default (pure live stream). Set
  `BACKFILL_MINUTES=60` in `.env` before the first run if you also want the
  last hour of history pulled into each file.
- **New/renamed tags**: the tag list is re-read from `tag_lives` every 10
  minutes, so tags added later start getting their own file automatically
  without a restart.
- Filenames are the `tagname` with any character outside `A-Z a-z 0-9 _ -`
  replaced with `_`, so names like `PT_I5_0` map straight through.
